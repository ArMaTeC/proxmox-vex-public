# ProxmoxVEx

Modern Multi-Cluster Management for Proxmox VE, ESXi & XCP-ng

---

ProxmoxVEx is a web-based management layer for Proxmox VE, VMware ESXi, and XCP-ng clusters. It provides a single dashboard to monitor, operate, and automate virtual machines, containers, storage, backups, and users across multiple clusters from one place.

![ProxmoxVEx UI](https://proxmoxvex.com/images/screenshots/dashboard-1200.webp?v=20260910-1)

## Contents

- [What is ProxmoxVEx](#what-is-proxmoxvex)
- [Why ProxmoxVEx](#why-proxmoxvex)
- [Key Capabilities](#key-capabilities)
- [Screenshots](#screenshots)
- [Architecture and Tech Stack](#architecture-and-tech-stack)
- [Plugin API](#plugin-api)
- [Requirements](#requirements)
- [Quick Start](#quick-start)
- [Demo Mode](#demo-mode)
- [Installation](#installation)
- [Reverse Proxy](#reverse-proxy)
- [Cloudflare Tunnel](#cloudflare-tunnel)
- [Initial Configuration](#initial-configuration)
- [Environment Variables](#environment-variables)
- [API and Monitoring](#api-and-monitoring)
- [Security](#security)
- [Updating](#updating)
- [Directory Structure](#directory-structure)
- [Troubleshooting](#troubleshooting)
- [Development and Testing](#development-and-testing)
- [Support](#support)
- [License](#license)

## What is ProxmoxVEx

ProxmoxVEx sits between your browser and one or more Proxmox VE, ESXi, or XCP-ng clusters, exposing a unified interface for day-to-day virtualization operations. It is designed for homelabs, small service providers, and operations teams that need multi-tenant access control, scheduled automation, and centralized observability without logging into each cluster individually.

The project combines a Python/Flask backend with a React-based single-page frontend, a PostgreSQL database, noVNC and xterm.js consoles, and a plugin architecture for extensibility. A fixture-backed demo mode lets you evaluate the full UI without connecting real infrastructure.

## Why ProxmoxVEx

- **One dashboard for many clusters** — see health, resource usage, and alerts across all sites in real time.
- **Multi-hypervisor** — manage Proxmox VE, ESXi/vCenter, and XCP-ng side by side, including cross-hypervisor migration.
- **Built for teams** — role-based access, multi-tenancy, LDAP/OIDC, and audit logging keep operations secure and accountable.
- **Automation out of the box** — schedule snapshots, rolling updates, backups, and cross-cluster replication.
- **Compliance and cost visibility** — cost chargeback, carbon estimates, right-sizing recommendations, and BSI/ISO/NIS2/SOC 2 mapping.
- **Air-gap ready** — all static assets are bundled locally; offline mode disables external lookups for classified networks.
- **Try before you deploy** — a self-contained demo mode serves a realistic fixture-backed environment.

## Key Capabilities

### Multi-Cluster Operations

- Unified dashboard for Proxmox VE, ESXi, and XCP-ng resources
- Live CPU, RAM, storage, and network metrics via Server-Sent Events and WebSockets
- One-click VM power actions and live migration
- Cross-cluster load balancing and storage-agnostic snapshot replication
- Cross-hypervisor migration from ESXi, including near-zero-downtime and offline options

### Lifecycle and Scheduling

- VM and LXC configuration editing, snapshots, and backups
- Tag-based or per-VMID snapshot schedules with retention pruning
- Backup verification: restore, boot, health-check, and cleanup
- Cloud-Init template library for fast provisioning
- Rolling node updates with automatic evacuation
- Maintenance windows, disaster-recovery plans, and site-recovery runbooks

### Access and Security

- Role-based access control with built-in and custom roles
- Multi-tenancy, IP allow/block lists, and VM-level ACLs
- TOTP and WebAuthn / FIDO2 two-factor authentication
- LDAP and OIDC support for Active Directory, Entra ID, Keycloak, Authentik, and others
- API tokens with bearer authentication
- PostgreSQL backend with field-level AES-256-GCM encryption for sensitive columns; volume/disk encryption is the operator's responsibility
- HMAC-signed, tamper-evident audit log
- CVE scanning and CIS hardening baseline checks

### Monitoring, Reporting, and Alerting

- Prometheus-compatible `/api/metrics` endpoint
- Cost and chargeback reporting, power and carbon estimates
- Right-sizing recommendations and capacity forecasts
- Network topology visualization
- Compliance dashboards for BSI Grundschutz, ISO 27001, NIS2, and SOC 2
- Integrated syslog receiver and SIEM forwarding
- Config drift detection with alerting
- IDS/IPS with behavioral anomaly detection (scapy + scikit-learn)
- Alert correlation, incident timelines, and web push notifications
- Multi-channel notifications (Slack, Teams, Discord, webhooks, ntfy, Apprise, PagerDuty)

### Storage, Networking, and Integrations

- Ceph, ZFS, TrueNAS, NetApp, and Proxmox Backup Server management
- Software-defined networking, VLANs, bridges, and firewall rules
- IPAM (incl. phpIPAM), DNS sync, and certificate lifecycle management
- VPN access portal and network topology visualization
- Native integrations for Active Directory, Docker, Git, Grafana, Kubernetes, LDAP, Packer, PBS, Prometheus, S3, Terraform, Vault, VMware, and generic webhooks

### Plugins and Extensibility

- 70+ bundled plugin extensions (Ansible runner, UPS monitoring, IPMI/Redfish BMC, tape libraries, Veeam, Hyper-V, Nutanix AHV, and more)
- Client portal for customer self-service and a public status page for NOC screens
- Plugin API for third-party extensions; license-gated plugins are delivered from the license server after activation
- Infrastructure as code via the Ansible runner and Terraform sync

For a complete feature list, see the [documentation site](https://proxmoxvex.com/docs).

## Screenshots

![ProxmoxVEx screenshot](https://proxmoxvex.com/pictures/ProxmoxVEx.png)

## Architecture and Tech Stack

ProxmoxVEx is a Python web application with a single-page React frontend. It uses gevent for high-concurrency I/O, PostgreSQL for persistence, and Paramiko-based SSH for cluster operations.

### Component Overview

```mermaid
flowchart LR
    Browser -->|HTTPS / WebSocket| Server[Flask / gevent WSGI]
    Server --> API[REST API blueprints]
    Server --> WS[WebSocket / SSE realtime]
    API --> Core[Core services]
    Core --> DB[(PostgreSQL)]
    Core --> SSH[Paramiko SSH to PVE/ESXi/XCP-ng nodes]
    Core --> VNC[noVNC / xterm.js consoles]
    Core --> BG[Background workers]
    Core --> Plugins[Plugin registry & native integrations]
```

### Backend

- **Python 3.8+** with **Flask 3** and **Werkzeug 3**
- **gevent** for asynchronous, high-concurrency request handling
- **PostgreSQL** (psycopg2) as the only supported database backend, with field-level AES-256-GCM encryption for sensitive columns
- **Paramiko** for SSH, **websockets** / **flask-sock** for console and realtime tunnels
- **pyvmomi** for ESXi/vCenter and **XenAPI** for XCP-ng
- **cryptography**, **argon2-cffi**, **pyotp**, **fido2** for security primitives
- **ldap3**, **PyJWT** for LDAP and OIDC authentication
- **kubernetes** client, **scapy**, **scikit-learn**, and **pandas** for integrations and IDS anomaly detection

### Frontend

- **React** single-page application (bundled to `web/app.bundle.js`)
- **Tailwind CSS** (prebuilt) and **Chart.js** for UI and metrics
- **noVNC** for QEMU graphical console
- **xterm.js** for LXC and SSH terminal sessions
- Namespaced i18n with 14 locales (`web/i18n/`)

### Protocols and Ports

| Port | Env override             | Description                           |
| ---- | ------------------------ | ------------------------------------- |
| 5000 | `PROXMOXVEX_PORT`        | Main web UI and REST API              |
| 5001 | `PROXMOXVEX_VNC_WS_PORT` | noVNC WebSocket (QEMU console)        |
| 5002 | `PROXMOXVEX_SSH_WS_PORT` | xterm.js WebSocket (LXC/SSH terminal) |

## Plugin API

Plugins are Python packages dropped into `plugins/`. A valid plugin exports a `register(app)` function and a `manifest.json` file that declares its id, frontend route, and compatibility. Plugins run in-process and are trusted by default; `plugins/directory.json` is the catalog and `plugins/untrusted_plugins.json` lists known-bad entries.

Layout:

```text
plugins/{plugin-name}/
├── manifest.json       # Required. Contract metadata.
├── __init__.py         # Required. Must export `register(app)`.
├── ui.html             # Optional. Frontend iframe markup (shared `plugin-ui.css` is injected automatically).
└── config.json         # Optional. Default configuration.
```

Plugin UIs automatically receive the shared `/static/css/plugin-ui.css` stylesheet; native plugins should include the same `<link>` manually. See [docs/architecture/plugin-contract.md](docs/architecture/plugin-contract.md) for the full contract.

## Requirements

- Python 3.8 or newer (Docker image ships Python 3.12)
- PostgreSQL 13+ (the provided `docker-compose.yml` runs `postgres:15-alpine`)
- Proxmox VE 8.0+ or 9.0+, and/or ESXi/vCenter, and/or XCP-ng
- A modern web browser
- `openssh-client` and `sshpass` for node-level SSH operations and password auth fallback

## Quick Start

The fastest way to try ProxmoxVEx is with Docker Compose, which starts both the app and a PostgreSQL container:

```bash
docker compose up -d --build
```

Then open `http://<host>:5000` and complete the first-run setup.

> The shipped `docker-compose.yml` sets `PROXMOXVEX_BEHIND_PROXY=true`, so the container serves plain HTTP on port 5000 and expects TLS to be terminated by your reverse proxy. For direct HTTPS access, remove that variable and the app will generate a self-signed certificate instead.

To run against an external database instead of the bundled container, override `PROXMOXVEX_DATABASE_URL` in the compose `environment:` section (or via a `.env`/override file) before `docker compose up -d`.

## Demo Mode

ProxmoxVEx ships a fixture-backed demo sandbox that simulates a realistic Proxmox environment (nodes, QEMU/LXC guests, storage, Ceph, SDN, tasks, recorded 24h metrics) without touching real infrastructure:

```bash
docker compose -f docker-compose.yml -f docker-compose.demo-override.yml up --build -d
```

Demo mode sets `PROXMOXVEX_DEMO_MODE=true`, seeds the database from `fixtures/demo/`, and blocks destructive API calls at the sandbox guard. `PROXMOXVEX_DEMO_TOKEN_SECRET` and `PROXMOXVEX_DEMO_RESET_INTERVAL` control the login token and periodic reset.

## Installation

### Option 1: Automated Install Script

The `deploy.sh` script fetches the current state of the main branch, creates a dedicated service user, and installs ProxmoxVEx to `/opt/ProxmoxVEx`.

```bash
# ISS-093: replace the host with your ProxmoxVEx instance or the project mirror
curl -O https://<your-proxmoxvex-host>/deploy.sh
chmod +x deploy.sh
sudo ./deploy.sh
```

For a non-interactive install on a specific port:

```bash
sudo ./deploy.sh --port=443 --no-interactive
```

### Option 2: Debian Package

```bash
curl -fsSL https://git.gyptazy.com/api/packages/gyptazy/debian/repository.key -o /etc/apt/keyrings/gyptazy.asc
echo "deb [signed-by=/etc/apt/keyrings/gyptazy.asc] https://packages.gyptazy.com/api/packages/gyptazy/debian trixie main" | sudo tee /etc/apt/sources.list.d/gyptazy.list
sudo apt-get update
sudo apt-get install -y ProxmoxVEx
```

### Option 3: Docker

Use the pre-built image (you still need a reachable PostgreSQL instance):

```bash
docker run -d --name ProxmoxVEx \
  -p 5000:5000 \
  -p 5001:5001 \
  -p 5002:5002 \
  -e PROXMOXVEX_DATABASE_URL=postgresql://user:pass@dbhost:5432/proxmoxvex \
  -v ProxmoxVEx-config:/app/config \
  -v ProxmoxVEx-logs:/app/logs \
  --restart unless-stopped \
  ghcr.io/armatec/proxmoxvex:latest
```

Or build and run locally — the compose file is the simplest path since it brings up PostgreSQL with a health-checked dependency:

```bash
# replace with the real git remote for your deployment/mirror
git clone https://<your-git-remote>/ProxmoxVEx.git
cd ProxmoxVEx
docker compose up -d --build
```

### Option 4: From Source

For development, testing, or full control over the deployment. A running PostgreSQL instance is required — set `PROXMOXVEX_DATABASE_URL` or the standard `PG*` variables before first start:

```bash
# replace with the real git remote for your deployment/mirror
git clone https://<your-git-remote>/ProxmoxVEx.git
cd ProxmoxVEx
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
export PROXMOXVEX_DATABASE_URL=postgresql://user:pass@localhost:5432/proxmoxvex
python3 ProxmoxVEx_multi_cluster.py
```

Installing the package (`pip install .`) also provides a `proxmoxvex` console command equivalent to `python3 ProxmoxVEx_multi_cluster.py`.

### Running as a Systemd Service

After installation from the deploy script or .deb, ProxmoxVEx is usually managed by systemd (units also live in `systemd/`):

```bash
sudo systemctl start ProxmoxVEx
sudo systemctl enable ProxmoxVEx
sudo systemctl status ProxmoxVEx
```

Logs are written to `logs/` and to the systemd journal:

```bash
sudo journalctl -u ProxmoxVEx -f
```

## Reverse Proxy

To run ProxmoxVEx behind nginx, enable reverse-proxy mode with `PROXMOXVEX_BEHIND_PROXY=true`. This disables the built-in HTTPS redirect and trusts `X-Forwarded-For` / `X-Forwarded-Proto` from the configured proxies.

Example nginx snippet:

```nginx
server {
    listen 443 ssl http2;
    server_name proxmoxvex.example.com;

    ssl_certificate     /etc/nginx/ssl/cert.pem;
    ssl_certificate_key /etc/nginx/ssl/key.pem;

    location / {
        proxy_pass http://127.0.0.1:5000;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_read_timeout 86400;
    }
}
```

Then start ProxmoxVEx with:

```bash
PROXMOXVEX_BEHIND_PROXY=true PROXMOXVEX_TRUSTED_PROXIES="10.0.0.0/8,127.0.0.1" python3 ProxmoxVEx_multi_cluster.py
```

## Cloudflare Tunnel

ProxmoxVEx runs three separate listeners:

- Main web/API server on `127.0.0.1:5000`
- VNC console WebSocket server on `127.0.0.1:5001`
- SSH/LXC terminal WebSocket server on `127.0.0.1:5002`

When `PROXMOXVEX_BEHIND_PROXY=true` is set, the frontend connects to the same public port (e.g. `443`) for all three. A Cloudflare Tunnel **must** route the WebSocket paths to the correct origin ports, and this only works reliably with a **locally-managed** `cloudflared` tunnel. Remotely-managed/token tunnels can duplicate the `101 Switching Protocols` handshake, causing the browser to fail with `Invalid frame header`.

### Create a local tunnel

```bash
cloudflared tunnel login
cloudflared tunnel create proxmoxvex-local
cloudflared tunnel route dns proxmoxvex-local proxmoxvex.example.com
```

This writes a `credentials.json` file, for example `/root/.cloudflared/<tunnel-uuid>.json`.

### Local `cloudflared` config

Edit `/etc/cloudflared/config.yml`:

```yaml
tunnel: <tunnel-uuid>
credentials-file: /root/.cloudflared/<tunnel-uuid>.json

ingress:
  - hostname: proxmoxvex.example.com
    path: "^/api/clusters/.*/(shellws|termwebsocket)"
    service: http://127.0.0.1:5002
    originRequest:
      noTLSVerify: true

  - hostname: proxmoxvex.example.com
    path: "^/api/clusters/.*/vms/.*/vncwebsocket"
    service: http://127.0.0.1:5001
    originRequest:
      noTLSVerify: true

  - hostname: proxmoxvex.example.com
    service: http://127.0.0.1:5000
    originRequest:
      noTLSVerify: true

  - service: http_status:404
```

Then point the systemd `ExecStart` at the config file:

```ini
ExecStart=/usr/bin/cloudflared --no-autoupdate --config /etc/cloudflared/config.yml tunnel run
```

Finally:

```bash
systemctl daemon-reload
systemctl restart cloudflared
```

### Notes

- Do not use `--token-file` / remotely-managed Cloudflare Tunnels for the WebSocket paths; they are known to produce double `101` responses (`Invalid frame header`) on `shellws`, `termwebsocket`, and `vncwebsocket`.
- `PROXMOXVEX_BEHIND_PROXY=true` and `PROXMOXVEX_TRUSTED_PROXIES="127.0.0.1"` should be set so the app trusts `X-Forwarded-*` headers from `cloudflared`.
- The VNC console uses port `5001` and the terminal uses port `5002`. Make sure both are explicitly routed; falling through to the `5000` Flask app will not work for these WebSocket endpoints.

## Initial Configuration

After starting ProxmoxVEx, open the web interface:

```text
https://<server-ip>:5000
```

(`http://` when running behind a proxy or the shipped compose file.)

1. Complete the first-run setup wizard to create the administrator account.
2. Go to **Settings > Clusters** and add your Proxmox VE, ESXi, or XCP-ng credentials.
3. Start managing your clusters.

### First-Run Security Notes

- A self-signed certificate is generated automatically if no custom certificate is provided and the app is not behind a proxy. Replace it with a trusted certificate for production.
- The master key used for field-level database encryption is resolved at first boot by the keystore (`PROXMOXVEX_DB_KEY`, systemd `LoadCredentialEncrypted`, `PROXMOXVEX_KEY_FILE`, or a generated key file). Back up the key separately from the `config/` directory — without it, encrypted columns are unrecoverable.
- The app refuses to start if no encryption backend is available.

## Environment Variables

The following environment variables tune ProxmoxVEx runtime behavior. New deployments should use the `PROXMOXVEX_*` form; legacy mixed-case aliases are still accepted as compatibility shims.

### Networking

| Variable                     | Default                                                      | Description                                                          |
| ---------------------------- | ------------------------------------------------------------ | -------------------------------------------------------------------- |
| `PROXMOXVEX_HOST`            | `127.0.0.1` (or `0.0.0.0` / `::` with `PROXMOXVEX_BIND_ALL`) | IP address to bind the main web server.                              |
| `PROXMOXVEX_PORT`            | `5000` (or **Settings > Server**)                            | Main web/API port; the console ports default to `PORT+1`/`PORT+2`.   |
| `PROXMOXVEX_BIND_ALL`        | unset                                                        | Set to `1`, `true`, or `yes` to bind all interfaces.                 |
| `PROXMOXVEX_BEHIND_PROXY`    | unset                                                        | Set to `1`, `true`, or `yes` to disable SSL and trust proxy headers. |
| `PROXMOXVEX_TRUSTED_PROXIES` | unset                                                        | Comma-separated list of trusted proxy IPs or CIDRs.                  |
| `PROXMOXVEX_ALLOWED_ORIGINS` | unset                                                        | Comma-separated list of allowed CORS origins.                        |
| `PROXMOXVEX_HTTP_PORT`       | `80` (root) or `-1` (non-root)                               | HTTP redirect port. Use `-1` to disable.                             |
| `PROXMOXVEX_FIREWALL_KEY`    | unset                                                        | Shared `LICENCE_ANALYTICS_INGEST_KEY` secret — enables enforcement of the licensing-service firewall blocklist (early `403` for banned IPs). |
| `PROXMOXVEX_FIREWALL_BLOCKLIST_URL` | `<LICENCE_SERVICE_URL>/v1/internal/firewall/blocklist` | Override for the blocklist endpoint (e.g. `http://172.17.0.1:8001/...` for a same-host licensing container). |
| `PROXMOXVEX_ANALYTICS_INGEST_URL` | derived from the blocklist URL (`.../v1/usage/report`) | Override for the analytics ingest endpoint that receives error/blocked-hit reports for the licensing detector. |

### Database and Encryption

| Variable                             | Default                                                                        | Description                                                            |
| ------------------------------------ | ------------------------------------------------------------------------------ | ---------------------------------------------------------------------- |
| `PROXMOXVEX_DATABASE_URL`            | `postgresql://proxmoxvex:proxmoxvex@localhost:5432/proxmoxvex` (or `PG*` vars) | PostgreSQL DSN. Required — PostgreSQL is the only supported backend.   |
| `PROXMOXVEX_DB_KEY`                  | unset                                                                          | Base64- or hex-encoded 32-byte master key.                             |
| `PROXMOXVEX_KEY_FILE`                | unset                                                                          | Filesystem path to the master key.                                     |
| `PROXMOXVEX_VERIFY_SSL`              | `1`                                                                            | Set to `0` to disable outbound TLS verification to cluster APIs.       |
| `PROXMOXVEX_SSH_HOST_KEY_POLICY`     | `tofu`                                                                         | SSH host-key policy: `tofu` (persisted) or `strict`.                   |
| `PROXMOXVEX_SCHEDULED_CMD_ALLOWLIST` | unset                                                                          | Comma-separated allowlist for scheduled command execution.             |

With `tofu`, unknown SSH host keys are trusted on first use and persisted to `known_hosts`; `strict` rejects them.

When `PROXMOXVEX_DATABASE_URL` is unset, the DSN is assembled from the standard `PGUSER`/`PGPASSWORD`/`PGHOST`/`PGPORT`/`PGDATABASE` variables.

### Concurrency and Performance

| Variable                            | Default                   | Description                                        |
| ----------------------------------- | ------------------------- | -------------------------------------------------- |
| `PROXMOXVEX_SERVER`                 | `auto`                    | WSGI mode: `gevent`, `flask`, or `auto`.           |
| `PROXMOXVEX_WORKERS`                | `max(32, cpu_count * 16)` | Number of gevent greenlets for request handling.   |
| `PROXMOXVEX_NO_GEVENT`              | unset                     | Set to `1`, `true`, or `yes` to disable gevent.    |
| `PROXMOXVEX_NOFILE`                 | system hard limit         | Target `RLIMIT_NOFILE` for the process.            |
| `PROXMOXVEX_THREADPOOL_SIZE`        | `50`                      | Size of the gevent threadpool.                     |
| `PROXMOXVEX_NODE_POOL_SIZE`         | `100`                     | Gevent pool for node status calls.                 |
| `PROXMOXVEX_NODE_STATUS_TTL`        | `5` (seconds)             | Cache TTL for node status; set `0` to disable.     |
| `PROXMOXVEX_TASKS_TTL`              | `3` (seconds)             | Cache TTL for task resolution; set `0` to disable. |
| `PROXMOXVEX_HEAVY_READ_TTL`         | `60` (seconds)            | Cache TTL for expensive DB reads.                  |
| `PROXMOXVEX_HEAVY_READ_CONCURRENCY` | `4`                       | Parallel workers for heavy read queries.           |
| `PROXMOXVEX_SSH_MAX_CONCURRENT`     | `25`                      | Maximum concurrent SSH connections.                |
| `PROXMOXVEX_MAX_REQUEST_SIZE`       | `10 MB`                   | Maximum API request body size.                     |
| `PROXMOXVEX_MAX_UPLOAD_SIZE`        | `100 GB`                  | Maximum upload body size.                          |
| `PROXMOXVEX_METRICS_RETENTION_DAYS` | `30`                      | How long collected metrics are kept.               |

### Logging and Auditing

| Variable                      | Default | Description                                                  |
| ----------------------------- | ------- | ------------------------------------------------------------ |
| `PROXMOXVEX_LOG_LEVEL`        | unset   | Console logging level (`DEBUG`, `INFO`, `WARNING`, `ERROR`). |
| `PROXMOXVEX_FILE_LOG_LEVEL`   | `DEBUG` | File logging level.                                          |
| `PROXMOXVEX_DISABLE_FILE_LOG` | unset   | Set to `1` to disable file logging.                          |

### Rate Limiting

| Variable                     | Default | Description                       |
| ---------------------------- | ------- | --------------------------------- |
| `PROXMOXVEX_API_RATE_LIMIT`  | `1200`  | Maximum requests per rate window. |
| `PROXMOXVEX_API_RATE_WINDOW` | `60`    | Rate-limit window in seconds.     |

### Consoles

| Variable                         | Default                 | Description                                       |
| -------------------------------- | ----------------------- | ------------------------------------------------- |
| `PROXMOXVEX_VNC_CONNECT_TIMEOUT` | `15` (seconds)          | VNC connect timeout.                              |
| `PROXMOXVEX_VNC_WS_PORT`         | `PROXMOXVEX_PORT + 1`   | noVNC WebSocket port.                             |
| `PROXMOXVEX_SSH_WS_PORT`         | `PROXMOXVEX_PORT + 2`   | SSH WebSocket port.                               |
| `PROXMOXVEX_SSH_WS_HOST`         | `127.0.0.1`             | SSH WebSocket bind host.                          |
| `PROXMOXVEX_SSH_WS_SSL_CERT`     | unset                   | SSH WebSocket SSL certificate.                    |
| `PROXMOXVEX_SSH_WS_SSL_KEY`      | unset                   | SSH WebSocket SSL key.                            |
| `PROXMOXVEX_WS_FALLBACK_HOST`    | `0.0.0.0`               | Fallback bind host for console WebSockets.        |
| `PROXMOXVEX_URL`                 | `http://127.0.0.1:5000` | ProxmoxVEx URL used by the SSH WebSocket backend. |

### Demo Mode

| Variable                          | Default                            | Description                                              |
| --------------------------------- | ---------------------------------- | -------------------------------------------------------- |
| `PROXMOXVEX_DEMO_MODE`            | unset                              | Set to `1`/`true` to enable the fixture-backed demo.     |
| `PROXMOXVEX_DEMO_TOKEN_SECRET`    | `demo-secret-change-in-production` | Secret used to sign demo login tokens.                   |
| `PROXMOXVEX_DEMO_FIXTURE_DIR`     | `fixtures/demo`                    | Fixture directory loaded by the demo.                    |
| `PROXMOXVEX_DEMO_RESET_INTERVAL`  | `900` (seconds)                    | Interval between automatic demo resets.                  |
| `PROXMOXVEX_DEMO_ALLOWED_ORIGINS` | unset                              | Extra CORS origins allowed in demo mode.                 |

### Internal / Advanced

| Variable                        | Default     | Description                                               |
| ------------------------------- | ----------- | --------------------------------------------------------- |
| `PROXMOXVEX_CONFIG_DIR`         | `config/`   | Override for the runtime configuration directory.         |
| `PROXMOXVEX_REMOTE_TMP`         | `/tmp`      | Temporary directory for remote operations.                |
| `PROXMOXVEX_SYSLOG_BIND`        | `127.0.0.1` | Syslog receiver bind address.                             |
| `PROXMOXVEX_SYSLOG_BIND_ALL`    | unset       | Set to `1` to bind the syslog receiver on all interfaces. |
| `PROXMOXVEX_SYSLOG_TCP_MAX`     | `1024`      | Maximum concurrent TCP syslog clients.                    |
| `PROXMOXVEX_PKG_BASE`           | auto        | Custom package base path for plugin loading.              |

`PROXMOXVEX_SSL_CERT_FILE` and `PROXMOXVEX_HEALTHCHECK_UNSAFE` also exist but are consumed by the release pipeline (`scripts/full-pipeline.sh`), not by the runtime server.

## API and Monitoring

### REST API

All API routes live under `/api/` and are protected by session cookie or `Authorization: Bearer pgx_<token>` header, except for the public prefixes listed below. API tokens are created in **Settings > API Tokens** and can be scoped to a role.

| Area                                              | Blueprint prefix                                                                                                              | Purpose                                          |
| ------------------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------ |
| `auth`                                            | `/api/auth`                                                                                                                   | Login, logout, 2FA, WebAuthn, password reset     |
| `users`, `groups`                                 | `/api/users`, `/api/groups`                                                                                                   | User, group, and role management                 |
| `clusters`                                        | `/api/clusters`                                                                                                               | Cluster CRUD and credentials                     |
| `vms`                                             | `/api/vms`                                                                                                                    | VM and container operations, consoles, migration |
| `nodes`                                           | `/api/nodes`                                                                                                                  | Node status, metrics, and commands               |
| `storage`, `ceph`, `pbs`                          | `/api/storage`, `/api/ceph`, `/api/pbs`                                                                                       | Storage, Ceph, and Proxmox Backup Server         |
| `snapshots`, `schedules`                          | `/api/snapshots`, `/api/schedules`                                                                                            | Snapshot schedules, retention, scheduled tasks   |
| `converter`, `site_recovery`, `disaster_recovery` | `/api/converter`, `/api/site-recovery`                                                                                        | ESXi→PVE conversion and DR plans                 |
| `alerts`, `siem`, `ids`                           | `/api/alerts`, `/api/siem`, `/api/ids`                                                                                        | Alert rules, SIEM forwarding, IDS                |
| `reports`, `costs`, `insights`                    | `/api/reports`, `/api/costs`                                                                                                  | Cost, power, compliance, CVE reporting           |
| `topology`, `drift`, `datacenter`                 | `/api/topology`, `/api/drift`                                                                                                 | Topology maps, config drift, datacenter view     |
| `metrics_exporter`                                | `/api/metrics`                                                                                                                | Prometheus OpenMetrics endpoint                  |
| `realtime`                                        | `/api/sse/updates`, `/api/ws/updates`                                                                                         | SSE and WebSocket live data                      |
| `settings`                                        | `/api/settings`                                                                                                               | Server, CORS, and branding settings              |
| `plugins`, `native`                               | `/api/plugins`, `/api/<module>`                                                                                               | Plugin registry and native integrations          |
| `licence`, `mirror`                               | `/api/licence`, `/api/version.json`, `/api/trees`                                                                             | Licensing and update mirror                      |
| integrations                                      | `/api/{terraform,kubernetes,grafana,prometheus,phpipam,vault,s3,docker,git,ldap,active-directory,vmware,webhooks,packer,pbs}` | Third-party integration APIs                     |

### Public Endpoints

Only the explicitly listed path prefixes bypass authentication; every other `/api/` route requires a session or token:

- `/api/health` — health check
- `/api/auth/login`, `/api/auth/setup`, `/api/auth/check`, `/api/auth/validate`, `/api/auth/logout`, `/api/auth/oidc/` — login flow
- `/api/demo/token`, `/api/demo/login`, `/api/demo/auto-login`, `/api/config` — demo entry
- `/api/webauthn/auth/`, `/api/webauthn/available` — WebAuthn login ceremony
- `/api/sse/updates`, `/api/ws/updates`, `/api/ws/token/validate` — realtime (self-authenticated via token)
- `/api/metrics` — self-authenticates via Bearer token (can be toggled fully public)
- `/api/version.json`, `/api/trees/` — update mirror metadata

### Live Data

- **Server-Sent Events**: `GET /api/sse/updates?token=<sse_token>` for cluster and node metrics.
- **WebSocket**: `GET /api/ws/updates` for low-latency live updates; authenticate with a `session_id` JSON message after connect.

### Prometheus Metrics

Scrape `https://<host>:5000/api/metrics` with an API token:

```bash
curl -H "Authorization: Bearer pgx_<token>" \
     https://proxmoxvex.example.com:5000/api/metrics
```

The endpoint can also be made public in **Settings > Server** if you place ProxmoxVEx behind a mutual-TLS reverse proxy.

### Health Check

```bash
curl -k https://<host>:5000/api/health
```

## Security

Security is documented in detail in [`docs/SECURITY.md`](docs/SECURITY.md) and the [threat model](docs/security/threat-model.md). Highlights include:

- **Field-level encryption**: sensitive columns are encrypted with AES-256-GCM (Fernet for legacy data). PostgreSQL volume/disk encryption is the operator's responsibility.
- **Master key custody**: multi-tier keystore supporting `PROXMOXVEX_DB_KEY`, systemd `LoadCredentialEncrypted` (TPM2 or host-key bound), `PROXMOXVEX_KEY_FILE`, and filesystem paths. The key should be backed up separately from `config/`; the app refuses to start without an encryption backend.
- **Password storage**: Argon2id.
- **API token storage**: SHA-256 with constant-time comparison.
- **Transport**: HTTPS for production use; self-signed certificates are generated automatically if no certificate is provided.
- **Session management**: time-limited sessions, optional IP binding, and per-endpoint rate limiting.
- **Input and access control**: an auth guard on every `/api/` blueprint with an explicit public-prefix allowlist, server-side RBAC on every route, origin validation, and input sanitization.

## Updating

The recommended update path is the `update.sh` script:

```bash
cd /opt/ProxmoxVEx
# replace the host with your ProxmoxVEx instance or project mirror
curl -O https://<your-proxmoxvex-host>/update.sh
chmod +x update.sh
sudo ./update.sh
```

You can also check for updates from the web UI at **Settings > Updates**.

## Directory Structure

```text
/opt/ProxmoxVEx/
├── ProxmoxVEx_multi_cluster.py   # Entry point
├── ProxmoxVEx/                   # Backend application package
│   ├── app.py                    # Flask app factory and server startup
│   ├── constants.py              # Configuration constants
│   ├── globals.py                # Shared runtime state
│   ├── api/                      # REST API blueprints
│   ├── core/                     # Business logic, DB layer, keystore, cache
│   ├── background/               # Background workers (metrics, scheduler, syslog)
│   ├── converter/                # ESXi → Proxmox migration engine
│   ├── demo/                     # Demo-mode sandbox and fixtures wiring
│   ├── ids/                      # IDS/IPS detection engine
│   ├── integrations/             # Third-party integration blueprints
│   ├── native/                   # Native plugin-style integrations
│   ├── models/                   # Data models and permissions
│   ├── plugins/                  # In-process plugin runtime helpers
│   ├── services/                 # Licensing and shared services
│   ├── updater/                  # Self-update machinery
│   └── utils/                    # Auth, RBAC, SSH, concurrency helpers
├── web/                          # Frontend
│   ├── index.html                # Compiled UI entry
│   ├── app.bundle.js             # Built bundle (from web/Dev/build.sh)
│   ├── src/                      # Frontend source modules
│   └── i18n/                     # Namespace-aware translations (14 locales)
├── plugins/                      # Plugin packages + directory.json catalog
├── fixtures/                     # Demo-mode fixtures
├── config/                       # Runtime configuration (keys, certs, settings)
├── static/                       # Offline JS/CSS libraries
├── docs/                         # Security, architecture, operations docs
├── scripts/                      # Build, release, and maintenance scripts
├── packaging/                    # Docker/Debian/Helm packaging helpers
├── systemd/                      # systemd unit files
├── tests/                        # pytest suite
├── logs/                         # Application logs
└── update.sh                     # Update script
```

## Troubleshooting

### Cannot reach the web UI

1. Verify the process is running: `sudo systemctl status ProxmoxVEx` or `docker ps`.
2. Check the bind address: by default the server binds `127.0.0.1` unless `PROXMOXVEX_BIND_ALL=true` or `PROXMOXVEX_HOST` is set.
3. Confirm the firewall allows TCP 5000, 5001, and 5002.
4. Remember the shipped `docker-compose.yml` serves **HTTP** (`PROXMOXVEX_BEHIND_PROXY=true`), not HTTPS.

### Database connection failures

- PostgreSQL is required; the app aborts early if it cannot reach the DSN. Check the logs for `DB initialized (PostgreSQL)`.
- Verify `PROXMOXVEX_DATABASE_URL` or the `PG*` variables, and that the database accepts connections (`pg_isready -h <dbhost> -U proxmoxvex`).
- With compose, the app waits for the `postgres` service health check before starting.

### Self-signed certificate warning

A self-signed certificate is generated on first start if no certificate is provided. Replace `config/ssl/cert.pem` and `config/ssl/key.pem` with a trusted certificate, or place ProxmoxVEx behind a reverse proxy that terminates TLS.

### Consoles (noVNC / xterm.js) do not work

- noVNC and the SSH terminal require a valid certificate on the WebSocket ports 5001 and 5002, or a reverse proxy that terminates TLS.
- Ensure ports 5001 and 5002 are reachable from the client.
- Set `PROXMOXVEX_BEHIND_PROXY=true` when running behind nginx and add WebSocket `Upgrade` headers.

### Master key and encryption

- If the master key is lost, encrypted columns are unreadable. Back up the key separately from `config/`.
- Inspect which keystore tier is active: `python3 ProxmoxVEx_multi_cluster.py --keystore-status`.
- Print the resolved key (handle with care): `python3 ProxmoxVEx_multi_cluster.py --print-key`.
- The app refuses to start when no encryption backend is available — check the logs for `FATAL: No encryption backend available`.

### Rate limiting or session issues

- `PROXMOXVEX_API_RATE_LIMIT` and `PROXMOXVEX_API_RATE_WINDOW` control request throttling.
- Sessions expire after inactivity. Enable strict-IP binding in **Settings > Server** if required.
- A transient database outage returns `503 LOOKUP_FAILED` rather than logging sessions out; if every session is force-logged-out, check database health first.

### Low file-descriptor limit

For 20+ clusters, increase the process limit:

```bash
# In the systemd unit override

[Service]
LimitNOFILE=65536
```

or set `PROXMOXVEX_NOFILE=65536`.

### Useful CLI flags

```text
python3 ProxmoxVEx_multi_cluster.py --debug            # verbose logging
python3 ProxmoxVEx_multi_cluster.py --requirements     # show requirements
python3 ProxmoxVEx_multi_cluster.py --download-static  # fetch JS libs for offline mode
python3 ProxmoxVEx_multi_cluster.py --print-key        # print resolved master key (base64)
python3 ProxmoxVEx_multi_cluster.py --keystore-status  # JSON dump of key-source + DB-backend status
```

## Development and Testing

Install development dependencies and run the test suite:

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt -r requirements-dev.txt
pytest
```

Linting and type checking:

```bash
ruff check ProxmoxVEx/
mypy --config-file pyproject.toml ProxmoxVEx/
```

Frontend and i18n:

```bash
bash web/Dev/build.sh            # rebuild web/app.bundle.js from web/src/
python3 web/i18n/validate.py     # check translation completeness (--strict to fail)
bash scripts/ui-tests.sh         # build + Playwright E2E playtest
```

### Release / CI tooling

The full release pipeline (`scripts/full-pipeline.sh`) and the packaging
helpers under `packaging/` require:

- `helm` — Helm 3 chart linting, templating, and signing
- `trivy` — container and chart vulnerability scanning
- `hadolint` — Dockerfile linting

`deploy.sh` installs these tools automatically. If you are not using the
deploy script, install them manually before running the release pipeline.

## Support

- GitHub Issues: [ArMaTeC/proxmoxVEx/issues](https://github.com/ArMaTeC/proxmoxVEx/issues)
- Email: [contact@proxmoxvex.com](mailto:contact@proxmoxvex.com)

## License

ProxmoxVEx is **source-available, not open source**. It is distributed under the [ProxmoxVEx Source-Available License](LICENSE): you may view, audit, and modify the code and run it for evaluation and other non-production use, but **production use requires a commercial license**.

The **"Powered by ProxmoxVEx"** attribution shown in the client portal is a required author attribution and must be preserved in every copy and derivative version. See [NOTICE](NOTICE) for attribution terms and third-party notices.

Commercial licensing: [contact@proxmoxvex.com](mailto:contact@proxmoxvex.com)

Versions released before this license took effect were distributed under AGPL-3.0; those earlier releases remain governed by AGPL-3.0 for the copies conveyed at the time.

---

Made by the ProxmoxVEx Team
