# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/ids/models.py
# Project:     ProxmoxVEx
# Version:     1.2.479
# Build:       2026.09.20
# Description: Domain models and persistence helpers for the IDS/IPS...
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-20
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Domain models and persistence helpers for the IDS/IPS module."""

import json
import logging
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from ProxmoxVEx.core.db import get_db

logger = logging.getLogger(__name__)


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _row_to_dict(row) -> Dict[str, Any]:
    keys = list(row.keys())
    return {k: row[k] for k in keys}


# ---------------------------------------------------------------------------
# MonitoredSegment
# ---------------------------------------------------------------------------


def create_segment(data: Dict[str, Any]) -> int:
    conn = get_db().conn
    cursor = conn.cursor()
    now = _now()
    cursor.execute(
        """
        INSERT INTO ids_monitored_segments
        (name, node_id, bridge, vlan, interface, capture_mode, enabled, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    """,
        (
            data.get("name", ""),
            data.get("node_id"),
            data.get("bridge"),
            data.get("vlan"),
            data.get("interface"),
            data.get("capture_mode", "packet"),
            1 if data.get("enabled", True) else 0,
            now,
            now,
        ),
    )
    conn.commit()
    return cursor.lastrowid


def get_segment(segment_id: int) -> Optional[Dict[str, Any]]:
    conn = get_db().conn
    cursor = conn.cursor()
    cursor.execute(
        "SELECT * FROM ids_monitored_segments WHERE id = ?",
        (segment_id,),
    )
    row = cursor.fetchone()
    return _row_to_dict(row) if row else None


def list_segments() -> List[Dict[str, Any]]:
    conn = get_db().conn
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM ids_monitored_segments ORDER BY id DESC")
    return [_row_to_dict(row) for row in cursor.fetchall()]


def update_segment(segment_id: int, data: Dict[str, Any]) -> bool:
    conn = get_db().conn
    cursor = conn.cursor()
    fields = []
    values = []
    for key in ("name", "node_id", "bridge", "vlan", "interface", "capture_mode"):
        if key in data:
            fields.append(f"{key} = ?")
            values.append(data[key])
    if "enabled" in data:
        fields.append("enabled = ?")
        values.append(1 if data["enabled"] else 0)
    if not fields:
        return False
    values.append(_now())
    values.append(segment_id)
    query = f"UPDATE ids_monitored_segments SET {', '.join(fields)}, updated_at = ? WHERE id = ?"  # nosec: B608 - column names are from a hardcoded allowlist and values use ? placeholders
    cursor.execute(query, values)
    conn.commit()
    return cursor.rowcount > 0


def delete_segment(segment_id: int) -> bool:
    conn = get_db().conn
    cursor = conn.cursor()
    # Remove dependent rows first to avoid FK constraint failures.
    cursor.execute(
        "DELETE FROM ids_prevention_actions WHERE alert_id IN (SELECT id FROM ids_alerts WHERE segment_id = ?)",
        (segment_id,),
    )
    cursor.execute("DELETE FROM ids_alerts WHERE segment_id = ?", (segment_id,))
    cursor.execute("DELETE FROM ids_capture_jobs WHERE segment_id = ?", (segment_id,))
    cursor.execute("DELETE FROM ids_detection_policies WHERE segment_id = ?", (segment_id,))
    cursor.execute("DELETE FROM ids_monitored_segments WHERE id = ?", (segment_id,))
    conn.commit()
    return cursor.rowcount > 0


# ---------------------------------------------------------------------------
# CaptureJob
# ---------------------------------------------------------------------------


def get_capture_job(segment_id: int) -> Optional[Dict[str, Any]]:
    conn = get_db().conn
    cursor = conn.cursor()
    cursor.execute(
        "SELECT * FROM ids_capture_jobs WHERE segment_id = ?",
        (segment_id,),
    )
    row = cursor.fetchone()
    return _row_to_dict(row) if row else None


def upsert_capture_job(segment_id: int, node_id: str, status: str, error: Optional[str] = None) -> int:
    conn = get_db().conn
    cursor = conn.cursor()
    existing = get_capture_job(segment_id)
    now = _now()
    if existing:
        cursor.execute(
            "UPDATE ids_capture_jobs SET node_id = ?, status = ?, last_seen_at = ?, error_message = ? WHERE id = ?",
            (node_id, status, now, error, existing["id"]),
        )
        conn.commit()
        return existing["id"]
    cursor.execute(
        "INSERT INTO ids_capture_jobs (segment_id, node_id, status, last_seen_at, error_message) VALUES (?, ?, ?, ?, ?)",
        (segment_id, node_id, status, now, error),
    )
    conn.commit()
    return cursor.lastrowid


# ---------------------------------------------------------------------------
# Rule
# ---------------------------------------------------------------------------


def create_rule(data: Dict[str, Any], created_by: str) -> int:
    conn = get_db().conn
    cursor = conn.cursor()
    now = _now()
    cursor.execute(
        """
        INSERT INTO ids_rules
        (name, enabled, rule_type, signature, anomaly_config, severity, threat_type, description, created_by, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """,
        (
            data.get("name", ""),
            1 if data.get("enabled", True) else 0,
            data.get("rule_type", "signature"),
            data.get("signature"),
            json.dumps(data.get("anomaly_config")) if data.get("anomaly_config") is not None else None,
            data.get("severity", "medium"),
            data.get("threat_type", ""),
            data.get("description", ""),
            created_by,
            now,
        ),
    )
    conn.commit()
    return cursor.lastrowid


# ---------------------------------------------------------------------------
# Alert
# ---------------------------------------------------------------------------


def create_alert(data: Dict[str, Any]) -> int:
    conn = get_db().conn
    cursor = conn.cursor()
    now = _now()
    cursor.execute(
        """
        INSERT INTO ids_alerts
        (segment_id, rule_id, threat_type, severity, source, destination, context, action_taken, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    """,
        (
            data["segment_id"],
            data.get("rule_id"),
            data.get("threat_type", ""),
            data.get("severity", "low"),
            data.get("source", ""),
            data.get("destination", ""),
            json.dumps(data.get("context", {})),
            data.get("action_taken"),
            now,
        ),
    )
    conn.commit()
    return cursor.lastrowid


def list_rules(
    enabled_only: bool = True, limit: Optional[int] = None, offset: Optional[int] = None, search: Optional[str] = None
) -> List[Dict[str, Any]]:
    conn = get_db().conn
    cursor = conn.cursor()
    query = "SELECT * FROM ids_rules"
    params: List[Any] = []
    conditions = []
    if enabled_only:
        conditions.append("enabled = 1")
    if search:
        conditions.append("(name LIKE ? OR signature LIKE ? OR threat_type LIKE ?)")
        term = f"%{search}%"
        params.extend([term, term, term])
    if conditions:
        query += " WHERE " + " AND ".join(conditions)
    query += " ORDER BY id"
    if limit is not None:
        query += " LIMIT ?"
        params.append(limit)
        if offset is not None:
            query += " OFFSET ?"
            params.append(offset)
    cursor.execute(query, params)
    return [_row_to_dict(row) for row in cursor.fetchall()]


def count_rules(enabled_only: bool = True, search: Optional[str] = None) -> int:
    conn = get_db().conn
    cursor = conn.cursor()
    query = "SELECT COUNT(*) FROM ids_rules"
    params = []
    conditions = []
    if enabled_only:
        conditions.append("enabled = 1")
    if search:
        conditions.append("(name LIKE ? OR signature LIKE ? OR threat_type LIKE ?)")
        term = f"%{search}%"
        params.extend([term, term, term])
    if conditions:
        query += " WHERE " + " AND ".join(conditions)
    cursor.execute(query, params)
    row = cursor.fetchone()
    return row[0] if row else 0


def get_rule(rule_id: int) -> Optional[Dict[str, Any]]:
    conn = get_db().conn
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM ids_rules WHERE id = ?", (rule_id,))
    row = cursor.fetchone()
    return _row_to_dict(row) if row else None


def update_rule(rule_id: int, data: Dict[str, Any]) -> bool:
    conn = get_db().conn
    cursor = conn.cursor()
    fields = []
    values = []
    for key in ("name", "rule_type", "signature", "anomaly_config", "severity", "threat_type", "description"):
        if key in data:
            fields.append(f"{key} = ?")
            values.append(json.dumps(data[key]) if key == "anomaly_config" and data[key] is not None else data[key])
    if "enabled" in data:
        fields.append("enabled = ?")
        values.append(1 if data["enabled"] else 0)
    if not fields:
        return False
    values.append(_now())
    values.append(rule_id)
    query = f"UPDATE ids_rules SET {', '.join(fields)}, updated_at = ? WHERE id = ?"  # nosec: B608 - column names are from a hardcoded allowlist and values use ? placeholders
    cursor.execute(query, values)
    conn.commit()
    return cursor.rowcount > 0


def delete_rule(rule_id: int) -> bool:
    conn = get_db().conn
    cursor = conn.cursor()
    cursor.execute("DELETE FROM ids_rules WHERE id = ?", (rule_id,))
    conn.commit()
    return cursor.rowcount > 0


# ---------------------------------------------------------------------------
# DetectionPolicy
# ---------------------------------------------------------------------------


def create_policy(data: Dict[str, Any]) -> int:
    conn = get_db().conn
    cursor = conn.cursor()
    now = _now()
    cursor.execute(
        """
        INSERT INTO ids_detection_policies
        (name, segment_id, rule_ids, default_action, enabled, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    """,
        (
            data.get("name", ""),
            data.get("segment_id"),
            json.dumps(data.get("rule_ids", [])),
            data.get("default_action", "alert"),
            1 if data.get("enabled", True) else 0,
            now,
            now,
        ),
    )
    conn.commit()
    return cursor.lastrowid


def list_policies() -> List[Dict[str, Any]]:
    conn = get_db().conn
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM ids_detection_policies ORDER BY id DESC")
    return [_row_to_dict(row) for row in cursor.fetchall()]


def get_policy(policy_id: int) -> Optional[Dict[str, Any]]:
    conn = get_db().conn
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM ids_detection_policies WHERE id = ?", (policy_id,))
    row = cursor.fetchone()
    return _row_to_dict(row) if row else None


def update_policy(policy_id: int, data: Dict[str, Any]) -> bool:
    conn = get_db().conn
    cursor = conn.cursor()
    fields = []
    values = []
    for key in ("name", "segment_id", "default_action"):
        if key in data:
            fields.append(f"{key} = ?")
            values.append(data[key])
    if "rule_ids" in data:
        fields.append("rule_ids = ?")
        values.append(json.dumps(data["rule_ids"]))
    if "enabled" in data:
        fields.append("enabled = ?")
        values.append(1 if data["enabled"] else 0)
    if not fields:
        return False
    values.append(_now())
    values.append(policy_id)
    query = f"UPDATE ids_detection_policies SET {', '.join(fields)}, updated_at = ? WHERE id = ?"  # nosec: B608 - column names are from a hardcoded allowlist and values use ? placeholders
    cursor.execute(query, values)
    conn.commit()
    return cursor.rowcount > 0


def delete_policy(policy_id: int) -> bool:
    conn = get_db().conn
    cursor = conn.cursor()
    cursor.execute("DELETE FROM ids_detection_policies WHERE id = ?", (policy_id,))
    conn.commit()
    return cursor.rowcount > 0


def find_policy_for_segment(segment_id: int) -> Optional[Dict[str, Any]]:
    conn = get_db().conn
    cursor = conn.cursor()
    cursor.execute(
        "SELECT * FROM ids_detection_policies WHERE (segment_id = ? OR segment_id IS NULL) AND enabled = 1 ORDER BY segment_id DESC LIMIT 1",
        (segment_id,),
    )
    row = cursor.fetchone()
    return _row_to_dict(row) if row else None


def list_alerts(segment_id: Optional[int] = None, severity: Optional[str] = None, limit: int = 100) -> List[Dict[str, Any]]:
    conn = get_db().conn
    cursor = conn.cursor()
    query = "SELECT * FROM ids_alerts WHERE 1=1"
    params: List[Any] = []
    if segment_id is not None:
        query += " AND segment_id = ?"
        params.append(segment_id)
    if severity is not None:
        query += " AND severity = ?"
        params.append(severity)
    query += " ORDER BY id DESC LIMIT ?"
    params.append(limit)
    cursor.execute(query, params)
    return [_row_to_dict(row) for row in cursor.fetchall()]


def get_alert(alert_id: int) -> Optional[Dict[str, Any]]:
    conn = get_db().conn
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM ids_alerts WHERE id = ?", (alert_id,))
    row = cursor.fetchone()
    return _row_to_dict(row) if row else None


# ---------------------------------------------------------------------------
# Blocked IP
# ---------------------------------------------------------------------------


def block_ip(ip: str, alert_id: Optional[int] = None) -> bool:
    """Add an IP to the IDS/IPS block list if it is not already present."""
    if not ip:
        return False
    conn = get_db().conn
    cursor = conn.cursor()
    try:
        cursor.execute(
            "INSERT OR IGNORE INTO ids_blocked_ips (ip, alert_id, created_at) VALUES (?, ?, ?)",
            (ip, alert_id, _now()),
        )
        conn.commit()
        return cursor.rowcount > 0
    except Exception:
        logger.exception("Failed to block IP %s", ip)
        return False


def unblock_ip(ip: str) -> bool:
    """Remove an IP from the IDS/IPS block list."""
    if not ip:
        return False
    conn = get_db().conn
    cursor = conn.cursor()
    cursor.execute("DELETE FROM ids_blocked_ips WHERE ip = ?", (ip,))
    conn.commit()
    return cursor.rowcount > 0


def is_blocked(ip: Optional[str]) -> bool:
    """Check whether the given IP is on the IDS/IPS block list."""
    if not ip:
        return False
    conn = get_db().conn
    cursor = conn.cursor()
    cursor.execute("SELECT 1 FROM ids_blocked_ips WHERE ip = ? LIMIT 1", (ip,))
    return cursor.fetchone() is not None


def list_blocked_ips() -> List[Dict[str, Any]]:
    """Return all blocked IPs."""
    conn = get_db().conn
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM ids_blocked_ips ORDER BY id DESC")
    return [_row_to_dict(row) for row in cursor.fetchall()]


# ---------------------------------------------------------------------------
# AuditLog
# ---------------------------------------------------------------------------


def log_ids_event(event_type: str, actor: str, details: Dict[str, Any]) -> int:
    conn = get_db().conn
    cursor = conn.cursor()
    now = _now()
    cursor.execute(
        "INSERT INTO ids_audit_log (event_type, actor, details, created_at) VALUES (?, ?, ?, ?)",
        (event_type, actor, json.dumps(details), now),
    )
    conn.commit()
    return cursor.lastrowid
