# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/ids/db.py
# Project:     ProxmoxVEx
# Version:     1.2.479
# Build:       2026.09.20
# Description: Database schema helpers for the IDS/IPS module.
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-20
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Database schema helpers for the IDS/IPS module."""


def ensure_ids_tables(conn):
    """Create IDS/IPS related tables if they do not exist."""
    cursor = conn.cursor()

    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS ids_monitored_segments (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            node_id TEXT,
            bridge TEXT,
            vlan INTEGER,
            interface TEXT,
            capture_mode TEXT NOT NULL DEFAULT 'packet',
            enabled INTEGER NOT NULL DEFAULT 0,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL
        )
    """
    )

    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS ids_capture_jobs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            segment_id INTEGER NOT NULL,
            node_id TEXT NOT NULL,
            status TEXT NOT NULL DEFAULT 'running',
            last_seen_at TEXT,
            error_message TEXT,
            FOREIGN KEY (segment_id) REFERENCES ids_monitored_segments (id)
        )
    """
    )

    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS ids_rules (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL UNIQUE,
            enabled INTEGER NOT NULL DEFAULT 1,
            rule_type TEXT NOT NULL,
            signature TEXT,
            anomaly_config TEXT,
            severity TEXT NOT NULL,
            threat_type TEXT,
            description TEXT,
            created_by TEXT,
            updated_at TEXT NOT NULL
        )
    """
    )

    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS ids_detection_policies (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL UNIQUE,
            segment_id INTEGER,
            rule_ids TEXT NOT NULL,
            default_action TEXT NOT NULL DEFAULT 'alert',
            enabled INTEGER NOT NULL DEFAULT 1,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            FOREIGN KEY (segment_id) REFERENCES ids_monitored_segments (id)
        )
    """
    )

    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS ids_alerts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            segment_id INTEGER NOT NULL,
            rule_id INTEGER,
            threat_type TEXT,
            severity TEXT NOT NULL,
            source TEXT,
            destination TEXT,
            context TEXT,
            action_taken TEXT,
            created_at TEXT NOT NULL,
            resolved_at TEXT,
            FOREIGN KEY (segment_id) REFERENCES ids_monitored_segments (id),
            FOREIGN KEY (rule_id) REFERENCES ids_rules (id)
        )
    """
    )

    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS ids_prevention_actions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            alert_id INTEGER NOT NULL,
            action_type TEXT NOT NULL,
            status TEXT NOT NULL DEFAULT 'pending',
            operator TEXT,
            reason TEXT,
            created_at TEXT NOT NULL,
            applied_at TEXT,
            FOREIGN KEY (alert_id) REFERENCES ids_alerts (id)
        )
    """
    )

    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS ids_audit_log (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            event_type TEXT NOT NULL,
            actor TEXT,
            details TEXT,
            created_at TEXT NOT NULL
        )
    """
    )

    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS ids_blocked_ips (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            ip TEXT NOT NULL UNIQUE,
            alert_id INTEGER,
            created_at TEXT NOT NULL,
            FOREIGN KEY (alert_id) REFERENCES ids_alerts (id)
        )
    """
    )

    cursor.execute("CREATE INDEX IF NOT EXISTS idx_ids_alerts_segment ON ids_alerts(segment_id)")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_ids_alerts_created ON ids_alerts(created_at)")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_ids_prevention_alert ON ids_prevention_actions(alert_id)")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_ids_blocked_ip ON ids_blocked_ips(ip)")
