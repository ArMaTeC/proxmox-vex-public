# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/ids/scheduler.py
# Project:     ProxmoxVEx
# Version:     1.2.479
# Build:       2026.09.20
# Description: Simple background scheduler for periodic IDS rule feed...
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-20
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Simple background scheduler for periodic IDS rule feed updates."""

import logging
import threading
import time
from typing import Any, Dict

from ProxmoxVEx.ids import feed

logger = logging.getLogger(__name__)

_state: Dict[str, Any] = {
    "enabled": False,
    "interval_hours": 24,
    "last_check": None,
    "last_version": None,
    "last_imported": 0,
    "last_error": None,
    "running": False,
    "thread": None,
    "app": None,
}


def _run_once() -> None:
    """Fetch and import the rule feed once."""
    app = _state["app"]
    if app is None:
        return
    try:
        with app.app_context():
            result = feed.update_from_feed()
        _state["last_check"] = time.time()
        _state["last_version"] = result.get("version")
        _state["last_imported"] = result.get("imported", 0)
        if "error" in result:
            _state["last_error"] = result["error"]
        else:
            _state["last_error"] = None
            logger.info("IDS scheduled feed imported %s rules", result.get("imported"))
    except Exception as e:
        _state["last_check"] = time.time()
        _state["last_error"] = str(e)
        logger.exception("IDS scheduled feed update failed")


def _scheduler_loop() -> None:
    """Background loop that wakes up at the configured interval."""
    while _state["running"]:
        if _state["enabled"]:
            try:
                _run_once()
            except Exception:
                logger.exception("IDS scheduler run failed")
            interval = _state["interval_hours"] * 3600
            time.sleep(interval)
        else:
            time.sleep(5)


def start_scheduler(app, enabled: bool = False, interval_hours: int = 24) -> bool:
    """Start the background feed update scheduler if not already running."""
    if _state["thread"] and _state["thread"].is_alive():
        return False
    _state["app"] = app
    _state["enabled"] = enabled
    _state["interval_hours"] = max(1, interval_hours)
    _state["running"] = True
    _state["thread"] = threading.Thread(target=_scheduler_loop, name="ids-feed-scheduler", daemon=True)
    _state["thread"].start()
    logger.info("IDS feed scheduler started: enabled=%s, interval=%sh", enabled, _state["interval_hours"])
    return True


def stop_scheduler() -> None:
    """Stop the background scheduler."""
    _state["running"] = False
    _state["enabled"] = False
    thread = _state["thread"]
    if thread:
        _state["thread"] = None
        if thread.is_alive():
            thread.join(timeout=1.0)


def configure(enabled: bool, interval_hours: int = 24) -> Dict[str, Any]:
    """Enable/disable or change the update interval."""
    _state["enabled"] = enabled
    _state["interval_hours"] = max(1, interval_hours)
    return get_status()


def record_import(version: Any, imported: int = 0, error: Any = None) -> None:
    """Record the result of a manual or scheduled feed import."""
    _state["last_check"] = time.time()
    _state["last_version"] = version
    _state["last_imported"] = imported
    _state["last_error"] = error


def get_status() -> Dict[str, Any]:
    """Return the current scheduler status."""
    return {
        "enabled": _state["enabled"],
        "interval_hours": _state["interval_hours"],
        "last_check": _state["last_check"],
        "last_version": _state["last_version"],
        "last_imported": _state["last_imported"],
        "last_error": _state["last_error"],
        "running": bool(_state["thread"] and _state["thread"].is_alive()),
    }
