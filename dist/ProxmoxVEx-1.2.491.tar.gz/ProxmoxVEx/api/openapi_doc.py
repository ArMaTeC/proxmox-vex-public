# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/api/openapi_doc.py
# Project:     ProxmoxVEx
# Version:     1.2.479
# Build:       2026.09.20
# Description: Spec 092/US033: machine-readable OpenAPI document for...
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-20
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Spec 092/US033: machine-readable OpenAPI document for the REST API.

Rather than a decorator registry retrofitted onto ~40 blueprints (the spec
sketch's approach — hundreds of routes would each need an annotation), the
document is generated from Flask's URL map at request time: every /api/
rule contributes its methods, Flask converters become {param} path
parameters, and the view's docstring becomes the operation summary. It can
never drift from the routes actually registered — new endpoints appear
automatically.

Authenticated like every other /api/ route: the document reveals the full
API surface, so anonymous discovery is refused.
"""

import logging
import re

from flask import Blueprint, current_app, jsonify

from ProxmoxVEx.utils.auth import require_auth

bp = Blueprint("openapi_doc", __name__)

_FLASK_PARAM = re.compile(r"<(?:(\w+):)?(\w+)>")
_METHODS = ("get", "post", "put", "delete", "patch")
_CONVERTER_TYPES = {"int": "integer", "float": "number", "path": "string", "string": "string", "uuid": "string"}


def _rule_to_path(rule) -> tuple:
    """'/api/vms/<int:vmid>' -> ('/api/vms/{vmid}', [{'name':'vmid',...}])."""
    params = []

    def _sub(m):
        conv, name = m.group(1), m.group(2)
        params.append({
            "name": name,
            "in": "path",
            "required": True,
            "schema": {"type": _CONVERTER_TYPES.get(conv or "string", "string")},
        })
        return "{" + name + "}"

    return _FLASK_PARAM.sub(_sub, rule.rule), params


# spec 092/US065: hand-pinned response schemas merged into the generated
# document. The URL map yields routes/methods mechanically, but response
# bodies can't be inferred — declaring them here makes the spec a real
# contract that tests/contract-style tests can validate live responses
# against. Keys are (method, spec-path); values map status -> JSON-Schema.
_OBJECT = {"type": "object"}
_STRING = {"type": "string"}
_STR_OR_NULL = {"type": ["string", "null"]}
_BOOL = {"type": "boolean"}
_INT = {"type": "integer"}

_VM_ITEM = {
    "type": "object",
    "required": ["vmid", "name", "type", "status"],
    "properties": {
        "vmid": _INT, "name": _STRING, "node": _STR_OR_NULL,
        "type": _STRING, "status": _STRING,
    },
}

_USER_ITEM = {
    "type": "object",
    "required": ["username", "role"],
    "properties": {
        "username": _STRING, "role": _STRING, "display_name": _STRING,
        "email": _STRING, "enabled": _BOOL, "tenant_id": _STRING,
        "created_at": _STR_OR_NULL, "last_login": _STR_OR_NULL,
    },
}

RESPONSE_SCHEMAS = {
    ("get", "/api/auth/check"): {
        "200": {
            "type": "object",
            "required": ["authenticated"],
            "properties": {
                "authenticated": _BOOL,
                "user": {"type": ["object", "null"]},
            },
        },
    },
    ("get", "/api/status/public"): {
        "200": {
            "type": "object",
            "required": ["status", "components"],
            "properties": {
                "status": {"type": "string", "enum": ["operational", "degraded"]},
                "components": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "required": ["name", "status"],
                        "properties": {"name": _STRING, "status": _STRING},
                    },
                },
                "incidents": {"type": "array"},
                "generated": _STRING,
            },
        },
    },
    ("get", "/api/clusters/{cluster_id}/vms"): {
        "200": {
            "type": "object",
            "required": ["vms"],
            "properties": {
                "vms": {"type": "array", "items": _VM_ITEM},
                "from_cache": _BOOL,
            },
        },
    },
    ("get", "/api/users"): {
        "200": {"type": "array", "items": _USER_ITEM},
    },
}


def build_openapi(app) -> dict:
    from ProxmoxVEx.constants import ProxmoxVEx_VERSION

    paths: dict = {}
    for rule in app.url_map.iter_rules():
        if not rule.rule.startswith("/api/"):
            continue
        methods = [m for m in _METHODS if m.upper() in (rule.methods or ())]
        if not methods:
            continue
        path, params = _rule_to_path(rule)
        view = app.view_functions.get(rule.endpoint)
        doc = (getattr(view, "__doc__", None) or "").strip().split("\n")[0].strip()
        item = paths.setdefault(path, {})
        if params:
            # merge — the same {param} may appear on several methods
            existing = {p["name"] for p in item.get("parameters", [])}
            item.setdefault("parameters", []).extend(p for p in params if p["name"] not in existing)
        for m in methods:
            item[m] = {
                "summary": doc or f"{m.upper()} {path}",
                "operationId": f"{rule.endpoint}",
                "responses": {"200": {"description": "Successful response"}},
            }
            # spec 092/US065: attach the pinned response schema when one exists
            # so the document doubles as the machine-checkable API contract.
            for status, schema in RESPONSE_SCHEMAS.get((m, path), {}).items():
                resp = item[m]["responses"].setdefault(
                    status, {"description": "Declared response"})
                resp.setdefault("content", {}).setdefault(
                    "application/json", {})["schema"] = schema
    return {
        "openapi": "3.0.3",
        "info": {
            "title": "ProxmoxVEx API",
            "version": ProxmoxVEx_VERSION,
            "description": "Generated from the registered Flask routes.",
        },
        "paths": dict(sorted(paths.items())),
    }


@bp.route("/api/openapi.json", methods=["GET"])
@require_auth()
def openapi_json():
    try:
        return jsonify(build_openapi(current_app))
    except Exception as e:
        logging.error("[openapi] generation failed: %s", e)
        return jsonify({"error": "spec generation failed"}), 500
