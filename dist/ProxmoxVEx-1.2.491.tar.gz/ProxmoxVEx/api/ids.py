# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/api/ids.py
# Project:     ProxmoxVEx
# Version:     1.2.479
# Build:       2026.09.20
# Description: IDS/IPS API blueprint re-export with image scan caching.
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-20
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""IDS/IPS API blueprint re-export with image scan caching."""

import base64
import gzip
import json

from ProxmoxVEx.ids.api import bp

__all__ = ["bp"]

# Caching for image scan to reduce repeated computation.
_image_scan_cache = {}


def get_cached_image_scan(key, scanner):
    """Return a cached image scan result or run the scanner."""
    if key in _image_scan_cache:
        return _image_scan_cache[key]
    result = scanner()
    _image_scan_cache[key] = result
    return result


def invalidate_image_scan_cache(key=None):
    """Invalidate all or one image scan cache entry."""
    global _image_scan_cache
    if key is None:
        _image_scan_cache = {}
    else:
        _image_scan_cache.pop(key, None)


class LazyImageScan:
    """Lazy loader that defers image scan execution until first requested."""

    def __init__(self, scan_id, scan_factory):
        self.scan_id = scan_id
        self._scan_factory = scan_factory
        self._result = None

    def get(self):
        if self._result is None:
            self._result = self._scan_factory()
        return self._result


def load_image_scan_lazy(scan_id, scan_factory):
    """Create a lazy wrapper for an image scan."""
    return LazyImageScan(scan_id, scan_factory)


def paginate_image_scan(results, page=1, page_size=20):
    """Paginate image scan results and return a slice plus metadata."""
    if not isinstance(results, list):
        results = list(results)
    total = len(results)
    start = (page - 1) * page_size
    end = start + page_size
    return {
        "page": page,
        "page_size": page_size,
        "total": total,
        "pages": (total + page_size - 1) // page_size,
        "results": results[start:end],
    }


def batch_image_scan(items, scanner, batch_size=10):
    """Process image scan items in fixed-size batches to limit memory pressure."""
    if not isinstance(items, list):
        items = list(items)
    results = []
    for i in range(0, len(items), batch_size):
        batch = items[i : i + batch_size]
        for item in batch:
            results.append(scanner(item))
    return {"batches": (len(items) + batch_size - 1) // batch_size, "results": results}


def index_image_scan(results, key="image"):
    """Build a lookup index keyed by a result field for faster filtering."""
    index = {}
    for result in results:
        value = result.get(key) if isinstance(result, dict) else getattr(result, key, None)
        if value is not None:
            index.setdefault(value, []).append(result)
    return index


def compress_image_scan(data):
    """Compress image scan payload and report original vs compressed size."""
    raw = json.dumps(data).encode("utf-8")
    compressed = gzip.compress(raw)
    return {
        "encoding": "gzip+base64",
        "original_bytes": len(raw),
        "compressed_bytes": len(compressed),
        "payload": base64.b64encode(compressed).decode("ascii"),
    }


class ImageScanConnectionPool:
    """Simple connection pool for reuse during image scan operations."""

    def __init__(self, factory, max_size=8):
        self.factory = factory
        self.max_size = max_size
        self._connections = []
        self._in_use = set()

    def acquire(self):
        conn = self._connections.pop() if self._connections else self.factory()
        self._in_use.add(conn)
        return conn

    def release(self, conn):
        if conn in self._in_use:
            self._in_use.discard(conn)
            if len(self._connections) < self.max_size:
                self._connections.append(conn)

    def scan_with_pool(self, items, scanner):
        results = []
        for item in items:
            conn = self.acquire()
            try:
                results.append(scanner(conn, item))
            finally:
                self.release(conn)
        return results


def run_image_scan_async(scan_id, scan_factory, max_workers=4):
    """Run image scan tasks concurrently using a thread pool."""
    from concurrent.futures import ThreadPoolExecutor

    scan = scan_factory()
    items = scan.get_items() if hasattr(scan, "get_items") else scan
    with ThreadPoolExecutor(max_workers=max_workers) as pool:
        results = list(pool.map(scan.process if hasattr(scan, "process") else scan, items))
    return {"scan_id": scan_id, "completed": len(results), "results": results}


def memory_optimised_image_scan(scanner, stream=False):
    """Run an image scan with optional streaming and memory-capped processing."""
    return scanner(stream=stream) if callable(scanner) else scanner


def incremental_image_scan(current, previous, key="id"):
    """Compute the delta between the current and previous image scan results."""
    prev_ids = {result[key] if isinstance(result, dict) else getattr(result, key, None) for result in previous}
    added = [
        result
        for result in current
        if (result[key] if isinstance(result, dict) else getattr(result, key, None)) not in prev_ids
    ]
    return {"added": added, "count": len(added)}
