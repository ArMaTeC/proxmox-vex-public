# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/api/mirror.py
# Project:     ProxmoxVEx
# Version:     1.2.479
# Build:       2026.09.20
# Description: Local release, documentation, and asset mirror endpoints.
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-20
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Local release, documentation, and asset mirror endpoints.

Implements the routes required for an air-gapped/local deployment to serve
release artifacts, documentation, source trees, and support pages without
reaching GitHub.
"""

import hashlib
import html
import json
import mimetypes
import os
import re
from pathlib import Path

from flask import (
    Blueprint,
    Response,
    abort,
    current_app,
    jsonify,
    request,
    send_file,
    send_from_directory,
)
from werkzeug.utils import safe_join

bp = Blueprint("mirror", __name__)

# Directories and files that should not appear in the public source tree API.
_TREE_EXCLUDE_DIRS = {
    ".git",
    ".venv",
    "venv",
    "node_modules",
    "__pycache__",
    ".pytest_cache",
    ".mypy_cache",
    ".ruff_cache",
    ".test-venv",
    "config",
    "ssl",
    "logs",
    "backups",
    "dist",
    "images",
    "packaging",
    "htmlcov",
    "audit-run",
    ".audit",
}

_TREE_EXCLUDE_PATTERNS = (
    r"^\.",
    r"^__pycache__$",
    r"\.db$",
    r"\.pem$",
    r"\.key$",
    r"\.crt$",
    r"\.enc$",
    r"\.pyc$",
)

# Simple markdown renderer used when the ``markdown`` package is not installed.
_MD_CODE_FENCE = re.compile(r"^```(.*)$")
_MD_HEADING = re.compile(r"^(#{1,6})\s+(.*)$")
_MD_UNORDERED_LIST = re.compile(r"^\s*[-*]\s+(.*)$")
_MD_ORDERED_LIST = re.compile(r"^\s*\d+\.\s+(.*)$")
_MD_BLOCKQUOTE = re.compile(r"^>\s+(.*)$")
_MD_HR = re.compile(r"^\s*([-_*])\s*\1\s*\1\s*$")


def _escape_html(text):
    return html.escape(text, quote=True)


def _inline_format(text):
    """Apply inline markdown formatting to a single line/paragraph."""
    text = _escape_html(text)
    # code spans first so content inside is not interpreted.
    text = re.sub(r"`([^`]+)`", r"<code>\1</code>", text)
    text = re.sub(r"\*\*\*(.+?)\*\*\*", r"<strong><em>\1</em></strong>", text)
    text = re.sub(r"\*\*(.+?)\*\*", r"<strong>\1</strong>", text)
    text = re.sub(r"(?<!\*)\*(?!\*)(.+?)(?<!\*)\*(?!\*)", r"<em>\1</em>", text)
    text = re.sub(r"\[([^\]]+)\]\(([^)]+)\)", r'<a href="\2">\1</a>', text)
    return text


def _markdown_to_html(text):
    """Convert markdown to a safe HTML subset.

    Tries the ``markdown`` library first, then falls back to a small built-in
    renderer so the endpoint always returns HTML even in minimal environments.
    """
    if not text:
        return ""

    try:
        import markdown as _markdown

        return _markdown.markdown(
            text,
            extensions=["fenced_code", "tables", "toc"],
            safe_mode="escape",
        )
    except Exception:  # noqa: S110
        pass

    lines = text.splitlines()
    blocks = []
    i = 0
    n = len(lines)

    while i < n:
        line = lines[i]
        stripped = line.strip()

        # fenced code blocks
        if _MD_CODE_FENCE.match(stripped):
            lang = stripped[3:].strip()
            i += 1
            body = []
            while i < n and not _MD_CODE_FENCE.match(lines[i].strip()):
                body.append(lines[i])
                i += 1
            i += 1  # skip closing fence
            code = _escape_html("\n".join(body))
            blocks.append(f'<pre><code class="language-{lang}">{code}</code></pre>')
            continue

        # headings
        m = _MD_HEADING.match(stripped)
        if m:
            level = len(m.group(1))
            content = _inline_format(m.group(2))
            blocks.append(f"<h{level}>{content}</h{level}>")
            i += 1
            continue

        # horizontal rule
        if _MD_HR.match(stripped):
            blocks.append("<hr>")
            i += 1
            continue

        # blockquotes
        if _MD_BLOCKQUOTE.match(stripped):
            parts = []
            while i < n and _MD_BLOCKQUOTE.match(lines[i].strip()):
                parts.append(_MD_BLOCKQUOTE.match(lines[i].strip()).group(1))
                i += 1
            content = _inline_format(" ".join(parts))
            blocks.append(f"<blockquote>{content}</blockquote>")
            continue

        # unordered lists
        if _MD_UNORDERED_LIST.match(stripped):
            items = []
            while i < n and _MD_UNORDERED_LIST.match(lines[i].strip()):
                items.append(_MD_UNORDERED_LIST.match(lines[i].strip()).group(1))
                i += 1
            lis = "".join(f"<li>{_inline_format(item)}</li>" for item in items)
            blocks.append(f"<ul>{lis}</ul>")
            continue

        # ordered lists
        if _MD_ORDERED_LIST.match(stripped):
            items = []
            while i < n and _MD_ORDERED_LIST.match(lines[i].strip()):
                items.append(_MD_ORDERED_LIST.match(lines[i].strip()).group(1))
                i += 1
            lis = "".join(f"<li>{_inline_format(item)}</li>" for item in items)
            blocks.append(f"<ol>{lis}</ol>")
            continue

        # blank lines
        if stripped == "":
            i += 1
            continue

        # paragraph
        para = []
        while i < n and lines[i].strip() != "":
            para.append(lines[i])
            i += 1
        content = _inline_format(" ".join(para))
        blocks.append(f"<p>{content}</p>")

    return "\n".join(blocks)


def _project_root():
    """Return the project root directory (parent of ProxmoxVEx/)."""
    return Path(current_app.root_path)


def _paid_plugin_slugs(root):
    """Return slugs marked paid/download-gated in the plugin directory.

    Paid plugin source is delivered exclusively by the license server after
    entitlement checks. The mirror must not expose it through the tree or raw
    endpoints — otherwise the per-file update fallback (and any unauthenticated
    client) could pull paid plugin code straight off an install that has it.
    """
    try:
        data = json.loads((Path(root) / "plugins" / "directory.json").read_text(encoding="utf-8"))
    except Exception:
        return set()
    return {
        entry["slug"]
        for entry in data.get("plugins", [])
        if entry.get("slug") and (entry.get("is_paid") or entry.get("download_required"))
    }


def _is_paid_plugin_path(rel, paid_slugs):
    """Return True when `rel` is inside a license-gated plugin directory."""
    parts = Path(rel).parts
    return len(parts) >= 2 and parts[0] == "plugins" and parts[1] in paid_slugs


def _is_excluded_path(rel):
    """Check whether a relative path should be omitted from the public tree."""
    parts = Path(rel).parts
    if any(part in _TREE_EXCLUDE_DIRS for part in parts):
        return True
    for part in parts:
        for pattern in _TREE_EXCLUDE_PATTERNS:
            if re.search(pattern, part):
                return True
    return False


def _file_sha(path):
    """Return a short sha of the file content (or path hash for directories)."""
    # git tree-object compat: sha1 is the algorithm this API mirrors, not a
    # security control — flag it so the bandit gate stays meaningful.
    h = hashlib.sha1(usedforsecurity=False)
    if path.is_file():
        h.update(path.read_bytes())
    else:
        h.update(str(path).encode("utf-8"))
    return h.hexdigest()


def _build_tree(root, recursive=False):
    """Build a GitHub-style tree payload for the given root directory."""
    tree = []
    paid_slugs = _paid_plugin_slugs(root)
    if recursive:
        for dirpath, dirnames, filenames in os.walk(root):
            # Filter excluded directories in-place to avoid descending into them.
            dirnames[:] = [d for d in dirnames if d not in _TREE_EXCLUDE_DIRS and not d.startswith(".")]
            for d in dirnames:
                full = Path(dirpath) / d
                rel = full.relative_to(root).as_posix()
                if _is_excluded_path(rel) or _is_paid_plugin_path(rel, paid_slugs):
                    continue
                tree.append(
                    {
                        "path": rel,
                        "type": "tree",
                        "sha": _file_sha(full),
                        "url": f"/api/trees/{rel}",
                    }
                )
            for f in filenames:
                full = Path(dirpath) / f
                rel = full.relative_to(root).as_posix()
                if _is_excluded_path(rel) or _is_paid_plugin_path(rel, paid_slugs):
                    continue
                tree.append(
                    {
                        "path": rel,
                        "type": "blob",
                        "size": full.stat().st_size,
                        "sha": _file_sha(full),
                        "url": f"/raw/main/{rel}",
                    }
                )
    else:
        for entry in sorted(root.iterdir()):
            rel = entry.relative_to(root).as_posix()
            if _is_excluded_path(rel) or _is_paid_plugin_path(rel, paid_slugs):
                continue
            tree.append(
                {
                    "path": rel,
                    "type": "tree" if entry.is_dir() else "blob",
                    "size": entry.stat().st_size if entry.is_file() else None,
                    "sha": _file_sha(entry),
                    "url": f"/api/trees/{rel}" if entry.is_dir() else f"/raw/main/{rel}",
                }
            )
    return tree


def _docs_page(page="wiki"):
    """Return the path to the requested docs page, or abort 404."""
    root = _project_root() / "docs"
    filename = f"{page}.md"
    full = safe_join(str(root), filename)
    if not full or not Path(full).is_file():
        abort(404)
    return Path(full)


def _render_docs_html(page="wiki"):
    path = _docs_page(page)
    text = path.read_text(encoding="utf-8")
    body = _markdown_to_html(text)
    html_doc = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>{_escape_html(page.title())} - ProxmoxVEx Docs</title>
    <style>
        body {{ font-family: system-ui, -apple-system, sans-serif; line-height: 1.6; max-width: 900px; margin: 2rem auto; padding: 0 1rem; color: #111; background: #fff; }}
        a {{ color: #0366d6; }}
        pre {{ background: #f6f8fa; padding: 1rem; border-radius: 6px; overflow-x: auto; }}
        code {{ font-family: ui-monospace, SFMono-Regular, monospace; background: #f6f8fa; padding: 0.2rem 0.4rem; border-radius: 3px; }}
        pre code {{ padding: 0; background: transparent; }}
        blockquote {{ border-left: 4px solid #dfe2e5; padding-left: 1rem; color: #6a737d; }}
        hr {{ border: none; border-top: 1px solid #dfe2e5; }}
        h1, h2, h3, h4, h5, h6 {{ color: #24292e; }}
    </style>
</head>
<body>
    {body}
</body>
</html>"""
    return Response(html_doc, mimetype="text/html")


@bp.route("/docs")
@bp.route("/docs/<path:page>")
def docs(page="wiki"):
    """Render a markdown documentation page as HTML."""
    page = page.rstrip("/") if not page.endswith(".md") else page[:-3]
    return _render_docs_html(page)


@bp.route("/version.json")
@bp.route("/api/version.json")
def version_json():
    """Serve the project's version.json file."""
    root = _project_root()
    return send_from_directory(str(root), "version.json")


@bp.route("/dist/<path:artifact>")
def dist_artifact(artifact):
    """Serve release artifacts and third-party tools from the mirror directory."""
    root = _project_root()
    dist_dir = os.environ.get("PROXMOXVEX_DIST_DIR", str(root / "dist"))
    try:
        return send_from_directory(dist_dir, artifact)
    except FileNotFoundError:
        abort(404)


@bp.route("/api/trees/<branch>")
def tree(branch):
    """Return a GitHub-style tree listing for a branch."""
    root = _project_root()
    recursive = request.args.get("recursive", "0") in ("1", "true", "yes")
    tree_data = _build_tree(root, recursive=recursive)
    tree_hash = hashlib.sha1(
        ",".join(t["path"] for t in tree_data).encode("utf-8"),
        usedforsecurity=False,  # git tree-object compat, not a security control
    ).hexdigest()
    return jsonify(
        {
            "sha": tree_hash,
            "url": f"/api/trees/{branch}",
            "tree": tree_data,
            "truncated": False,
        }
    )


@bp.route("/raw/<branch>/<path:filename>")
def raw_file(branch, filename):
    """Serve an individual raw file from the repository tree."""
    root = _project_root()
    # License-gated plugin source is never served raw — it is only distributed
    # by the license server as a verified artifact (spec 036).
    if _is_paid_plugin_path(filename, _paid_plugin_slugs(root)):
        abort(404)
    full = safe_join(str(root), *filename.split("/"))
    if not full or not Path(full).is_file():
        abort(404)
    mime, _ = mimetypes.guess_type(str(full))
    if not mime:
        mime = "text/plain"
    return send_file(
        str(full),
        mimetype=mime,
        as_attachment=False,
        download_name=Path(filename).name,
    )


@bp.route("/images/<name>")
def images(name):
    """Serve static image assets used by packaging and the UI."""
    root = _project_root()
    try:
        return send_from_directory(str(root / "images"), name)
    except FileNotFoundError:
        abort(404)


@bp.route("/support")
def support():
    """Local support/issue form placeholder."""
    html_doc = """<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>ProxmoxVEx Support</title>
    <style>
        body { font-family: system-ui, -apple-system, sans-serif; max-width: 600px; margin: 3rem auto; padding: 0 1rem; color: #111; }
        h1 { color: #24292e; }
        label { display: block; margin-top: 1rem; font-weight: 600; }
        input, textarea { width: 100%; padding: 0.5rem; margin-top: 0.25rem; border: 1px solid #d1d5da; border-radius: 6px; box-sizing: border-box; }
        button { margin-top: 1rem; padding: 0.6rem 1.2rem; background: #2ea44f; color: #fff; border: none; border-radius: 6px; cursor: pointer; }
    </style>
</head>
<body>
    <h1>Report an Issue</h1>
    <p>Use this form to open a support request. In air-gapped deployments the submission is handled by your local administrator.</p>
    <form>
        <label for="subject">Subject</label>
        <input id="subject" name="subject" type="text" required>
        <label for="body">Description</label>
        <textarea id="body" name="body" rows="6" required></textarea>
        <button type="submit">Submit</button>
    </form>
    <p><a href="/docs">Return to documentation</a></p>
</body>
</html>"""
    return Response(html_doc, mimetype="text/html")


@bp.route("/team")
def team():
    """Local team/contributors placeholder."""
    html_doc = """<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>ProxmoxVEx Team</title>
    <style>
        body { font-family: system-ui, -apple-system, sans-serif; max-width: 600px; margin: 3rem auto; padding: 0 1rem; color: #111; }
        h1 { color: #24292e; }
        ul { line-height: 2; }
    </style>
</head>
<body>
    <h1>ProxmoxVEx Team</h1>
    <p>This page lists the contributors and support contacts configured for your local deployment.</p>
    <ul>
        <li>Local Administrator (replace in your team configuration)</li>
        <li>Operations Team</li>
        <li>See <a href="/docs">/docs</a> for documentation.</li>
    </ul>
    <p><a href="/support">Open a support request</a></p>
</body>
</html>"""
    return Response(html_doc, mimetype="text/html")
