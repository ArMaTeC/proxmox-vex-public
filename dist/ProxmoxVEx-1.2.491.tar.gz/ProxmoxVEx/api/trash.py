# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/api/trash.py
# Project:     ProxmoxVEx
# Version:     1.2.479
# Build:       2026.09.20
# Description: GET /api/trash — the 'recently deleted' view for soft-...
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-20
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""GET /api/trash — the 'recently deleted' view for soft-deleted entities
(spec 092/US075). Lists trashed clusters, users and scheduled actions so an
admin can find and restore them inside the retention window.
"""

import logging

from flask import Blueprint, jsonify

from ProxmoxVEx.core.db import get_db
from ProxmoxVEx.utils.auth import require_auth

bp = Blueprint("trash", __name__)


@bp.route("/api/trash", methods=["GET"])
@require_auth(perms=["admin.users"])
def list_trash():
    """All trashed entities, newest first. Admin-only: deleted user rows still
    carry roles/tenant data that shouldn't leak to ordinary users."""
    try:
        db = get_db()
        clusters = [
            {"id": r["id"], "name": r.get("name", ""), "host": r.get("host", ""),
             "deleted_at": r.get("deleted_at")}
            for r in db.list_deleted("clusters")
        ]
        users = [
            {"username": r["username"], "role": r.get("role", ""),
             "tenant_id": r.get("tenant_id", ""), "deleted_at": r.get("deleted_at")}
            for r in db.list_deleted("users")
        ]
        schedules = [
            {"id": r["id"], "cluster_id": r.get("cluster_id", ""), "vmid": r.get("vmid"),
             "action": r.get("action", ""), "name": r.get("name") or "",
             "deleted_at": r.get("deleted_at")}
            for r in db.list_deleted("scheduled_actions")
        ]
        return jsonify({"clusters": clusters, "users": users, "schedules": schedules})
    except Exception as e:
        logging.error(f"Failed to list trash: {e}", exc_info=True)
        return jsonify({"error": "Failed to list trash"}), 500
