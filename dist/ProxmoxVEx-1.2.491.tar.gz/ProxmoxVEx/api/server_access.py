# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/api/server_access.py
# Project:     ProxmoxVEx
# Version:     1.2.479
# Build:       2026.09.20
# Description: Server Access Groups API - per-server RBAC.
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-20
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Server Access Groups API - per-server RBAC."""

import csv
import io
import json
import logging

from flask import Blueprint, jsonify, request

from ProxmoxVEx.models import server_access
from ProxmoxVEx.models.permissions import ROLE_ADMIN
from ProxmoxVEx.utils.auth import get_user_record, require_auth

bp = Blueprint("server_access", __name__)

_VALID_TYPES = {"cluster", "vmware", "pbs"}


def _current_user():
    return getattr(request, "session", {}).get("user", "")


def _user():
    # (perf) indexed single-row fetch — load_users() decrypted all users here
    return get_user_record(_current_user())


def _is_admin(user):
    return user.get("role") == ROLE_ADMIN


def _log(action, target_type, target_id, details=None):
    server_access.log_server_access_event(_current_user(), action, target_type, target_id, details or {})


@bp.route("/api/server-access-groups", methods=["GET"])
@require_auth(perms=["admin.groups"])
def get_groups():
    """List all server access groups."""
    try:
        groups = server_access.list_groups()
        return jsonify(groups)
    except Exception as e:
        logging.error(f"Error listing server access groups: {e}")
        return jsonify({"error": "Failed to load server access groups"}), 500


@bp.route("/api/server-access-groups", methods=["POST"])
@require_auth(perms=["admin.groups"])
def create_group():
    """Create a new server access group."""
    data = request.json or {}
    name = (data.get("name") or "").strip()
    if not name:
        return jsonify({"error": "Name required"}), 400

    try:
        group_id = server_access.save_group({"name": name, "description": data.get("description", "")})
        _log("create_group", "group", group_id, {"name": name})
        return jsonify({"id": group_id, "name": name}), 201
    except Exception as e:
        logging.error(f"Error creating server access group: {e}")
        return jsonify({"error": "Failed to create server access group"}), 500


@bp.route("/api/server-access-groups/<group_id>", methods=["PUT"])
@require_auth(perms=["admin.groups"])
def update_group(group_id):
    """Rename/update a server access group."""
    data = request.json or {}
    name = (data.get("name") or "").strip()
    if not name:
        return jsonify({"error": "Name required"}), 400

    try:
        existing = server_access.get_group(group_id)
        if not existing:
            return jsonify({"error": "Group not found"}), 404
        server_access.save_group({"id": group_id, "name": name, "description": data.get("description", "")})
        _log("update_group", "group", group_id, {"name": name})
        return jsonify({"id": group_id, "name": name})
    except Exception as e:
        logging.error(f"Error updating server access group: {e}")
        return jsonify({"error": "Failed to update server access group"}), 500


@bp.route("/api/server-access-groups/<group_id>", methods=["DELETE"])
@require_auth(perms=["admin.groups"])
def delete_group(group_id):
    """Delete a server access group."""
    try:
        if not server_access.delete_group(group_id):
            return jsonify({"error": "Group not found"}), 404
        _log("delete_group", "group", group_id, {})
        return jsonify({"ok": True})
    except Exception as e:
        logging.error(f"Error deleting server access group: {e}")
        return jsonify({"error": "Failed to delete server access group"}), 500


@bp.route("/api/server-access-groups/<group_id>/members", methods=["GET"])
@require_auth(perms=["admin.groups"])
def get_members(group_id):
    """List members of a server access group."""
    try:
        members = server_access.list_members(group_id)
        return jsonify(members)
    except Exception as e:
        logging.error(f"Error listing members: {e}")
        return jsonify({"error": "Failed to load members"}), 500


@bp.route("/api/server-access-groups/<group_id>/members", methods=["POST"])
@require_auth(perms=["admin.groups"])
def add_member(group_id):
    """Add one or more users to a group."""
    data = request.json or {}
    usernames = data.get("usernames") or []
    if not isinstance(usernames, list):
        usernames = [data.get("username")] if data.get("username") else []
    if not usernames:
        return jsonify({"error": "At least one username required"}), 400

    try:
        for username in usernames:
            if username:
                server_access.add_member(group_id, username)
        _log("add_member", "group", group_id, {"usernames": usernames})
        return jsonify({"ok": True})
    except Exception as e:
        logging.error(f"Error adding member: {e}")
        return jsonify({"error": "Failed to add member"}), 500


@bp.route("/api/server-access-groups/<group_id>/members/<username>", methods=["DELETE"])
@require_auth(perms=["admin.groups"])
def remove_member(group_id, username):
    """Remove a user from a group."""
    try:
        if not server_access.remove_member(group_id, username):
            return jsonify({"error": "Member not found"}), 404
        _log("remove_member", "group", group_id, {"username": username})
        return jsonify({"ok": True})
    except Exception as e:
        logging.error(f"Error removing member: {e}")
        return jsonify({"error": "Failed to remove member"}), 500


@bp.route("/api/server-access/<server_type>/<server_id>", methods=["GET"])
@require_auth(perms=["admin.groups"])
def get_assignments(server_type, server_id):
    """List server access group assignments for a server."""
    if server_type not in _VALID_TYPES:
        return jsonify({"error": "Invalid server type"}), 400
    try:
        assignments = server_access.get_server_assignments(server_type, server_id)
        return jsonify(assignments)
    except Exception as e:
        logging.error(f"Error getting assignments: {e}")
        return jsonify({"error": "Failed to load assignments"}), 500


@bp.route("/api/server-access/<server_type>/<server_id>", methods=["PUT"])
@require_auth(perms=["admin.groups"])
def set_assignment(server_type, server_id):
    """Assign a group to a server with a permission level."""
    if server_type not in _VALID_TYPES:
        return jsonify({"error": "Invalid server type"}), 400
    data = request.json or {}
    group_id = data.get("group_id")
    level = data.get("permission_level")
    if not group_id or not level:
        return jsonify({"error": "group_id and permission_level required"}), 400
    if level not in server_access.VALID_PERMISSION_LEVELS:
        return jsonify({"error": "Invalid permission level"}), 400

    try:
        server_access.set_assignment(server_type, server_id, group_id, level)
        _log(
            "set_assignment",
            server_type,
            server_id,
            {"group_id": group_id, "level": level},
        )
        return jsonify({"ok": True})
    except Exception as e:
        logging.error(f"Error setting assignment: {e}")
        return jsonify({"error": "Failed to set assignment"}), 500


@bp.route("/api/server-access/<server_type>/<server_id>/<group_id>", methods=["DELETE"])
@require_auth(perms=["admin.groups"])
def delete_assignment(server_type, server_id, group_id):
    """Remove a group assignment from a server."""
    if server_type not in _VALID_TYPES:
        return jsonify({"error": "Invalid server type"}), 400
    try:
        if not server_access.remove_assignment(server_type, server_id, group_id):
            return jsonify({"error": "Assignment not found"}), 404
        _log("remove_assignment", server_type, server_id, {"group_id": group_id})
        return jsonify({"ok": True})
    except Exception as e:
        logging.error(f"Error removing assignment: {e}")
        return jsonify({"error": "Failed to remove assignment"}), 500


@bp.route("/api/server-access-audit", methods=["GET"])
@require_auth(perms=["admin.audit"])
def get_audit():
    """Query the server access audit log."""
    args = request.args
    actor = args.get("actor") or None
    action = args.get("action") or None
    target_type = args.get("target_type") or None
    target_id = args.get("target_id") or None
    try:
        limit = min(int(args.get("limit", 100)), 1000)
        offset = max(int(args.get("offset", 0)), 0)
    except ValueError:
        return jsonify({"error": "Invalid limit or offset"}), 400

    try:
        events = server_access.list_audit_events(
            actor=actor,
            action=action,
            target_type=target_type,
            target_id=target_id,
            limit=limit,
            offset=offset,
        )
        return jsonify(events)
    except Exception as e:
        logging.error(f"Error fetching server access audit: {e}")
        return jsonify({"error": "Failed to load audit log"}), 500


@bp.route("/api/server-access-audit/export", methods=["GET"])
@require_auth(perms=["admin.audit"])
def export_audit():
    """Export the server access audit log to JSON or CSV."""
    fmt = (request.args.get("format") or "json").lower()
    if fmt not in {"json", "csv"}:
        return jsonify({"error": "format must be json or csv"}), 400

    try:
        events = server_access.list_audit_events(limit=10000)
    except Exception as e:
        logging.error(f"Error exporting server access audit: {e}")
        return jsonify({"error": "Failed to export audit log"}), 500

    if fmt == "json":
        return jsonify(events)

    # CSV export
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["id", "timestamp", "actor", "action", "target_type", "target_id", "details"])
    for event in events:
        writer.writerow([
            event["id"],
            event["timestamp"],
            event["actor"],
            event["action"],
            event["target_type"],
            event["target_id"],
            json.dumps(event.get("details", {})),
        ])
    return (
        output.getvalue(),
        200,
        {"Content-Type": "text/csv", "Content-Disposition": "attachment; filename=server_access_audit.csv"},
    )
