# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/api/demo.py
# Project:     ProxmoxVEx
# Version:     1.2.479
# Build:       2026.09.20
# Description: Public demo entry routes.
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-20
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Public demo entry routes.

``/api/demo/token`` issues a short-lived anonymous token that the landing
page can hand to ``/api/demo/login`` to obtain a real Flask session for the
synthetic demo user.  These routes are only functional when demo mode is
enabled and are listed in the public allow-list.
"""

import logging

from flask import Blueprint, jsonify, make_response, redirect, request

from ProxmoxVEx.demo import (
    DEMO_CAPACITY,
    DEMO_RESET_INTERVAL,
    DEMO_USERNAME,
    is_demo_mode,
)
from ProxmoxVEx.demo.token import issue_demo_token, verify_demo_token
from ProxmoxVEx.utils.auth import create_session

bp = Blueprint("demo", __name__)


@bp.route("/api/demo/token", methods=["GET"])
def demo_token():
    """Issue a short-lived anonymous token for the demo sandbox."""
    if not is_demo_mode():
        return jsonify({"error": "Demo mode is not enabled"}), 403
    token = issue_demo_token()
    return jsonify({"token": token, "username": DEMO_USERNAME})


@bp.route("/api/demo/login", methods=["POST"])
def demo_login():
    """Exchange a demo token for a real Flask session."""
    if not is_demo_mode():
        return jsonify({"error": "Demo mode is not enabled"}), 403

    token = request.json.get("token") if request.json else None
    if not token:
        token = request.form.get("token") or request.args.get("token")

    payload = verify_demo_token(token) if token else None
    if not payload:
        return jsonify({"error": "Invalid or expired demo token"}), 401

    try:
        session_id = create_session(DEMO_USERNAME, "viewer", remember=False)
        response = make_response(jsonify({"success": True, "username": DEMO_USERNAME, "role": "viewer"}))
        response.set_cookie(
            "session_id",
            session_id,
            httponly=True,
            secure=request.is_secure,
            samesite="Lax",
            max_age=3600,
        )
        logging.info(f"[DEMO_LOGIN] Issued session for {DEMO_USERNAME}")
        return response
    except Exception as e:
        logging.error(f"[DEMO_LOGIN] Failed to create demo session: {e}")
        return jsonify({"error": "Failed to create session"}), 500


@bp.route("/api/demo/auto-login", methods=["GET"])
def demo_auto_login():
    """Public one-click demo entry point.

    Issues a fresh demo token, validates it immediately, creates a real
    Flask session for the demo user, and redirects to the application root.
    This lets the marketing site use a plain anchor tag to launch the demo.
    """
    if not is_demo_mode():
        return jsonify({"error": "Demo mode is not enabled"}), 403

    token = issue_demo_token()
    payload = verify_demo_token(token)
    if not payload:
        return jsonify({"error": "Failed to issue demo token"}), 500

    try:
        session_id = create_session(DEMO_USERNAME, "viewer", remember=False)
        response = redirect(request.args.get("redirect", "/"), code=302)
        response.set_cookie(
            "session_id",
            session_id,
            httponly=True,
            secure=request.is_secure,
            samesite="Lax",
            max_age=3600,
        )
        logging.info(f"[DEMO_AUTO_LOGIN] Issued session for {DEMO_USERNAME}")
        return response
    except Exception as e:
        logging.error(f"[DEMO_AUTO_LOGIN] Failed to create demo session: {e}")
        return jsonify({"error": "Failed to create session"}), 500


@bp.route("/api/config", methods=["GET"])
def demo_config():
    """Public demo/sandbox configuration used by the React frontend.

    The UI reads these keys on boot to toggle demo-mode UI affordances
    (read-only banner, disabled destructive buttons) without needing an
    authenticated session first.
    """
    # spec 092/US030: the plugin-error telemetry flush checks this flag before
    # sending — non-sensitive boolean, same public-config channel as demo_mode.
    from ProxmoxVEx.api.helpers import load_server_settings

    try:
        telemetry_opt_in = bool(load_server_settings().get("telemetry_opt_in"))
    except Exception:
        telemetry_opt_in = False
    return jsonify(
        {
            "demo_mode": is_demo_mode(),
            "demo_read_only": is_demo_mode(),
            "demo_reset_in_seconds": DEMO_RESET_INTERVAL if is_demo_mode() else 0,
            "demo_capacity": DEMO_CAPACITY if is_demo_mode() else "n/a",
            "telemetry_opt_in": telemetry_opt_in,
        }
    )
