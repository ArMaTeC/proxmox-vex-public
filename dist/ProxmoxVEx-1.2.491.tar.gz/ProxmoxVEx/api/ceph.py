# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/api/ceph.py
# Project:     ProxmoxVEx
# Version:     1.2.479
# Build:       2026.09.20
# Description: ProxmoxVEx Ceph API Routes - Layer 6
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-20
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""
ProxmoxVEx Ceph API Routes - Layer 6
Ceph cluster management: status, OSDs, monitors, pools, CephFS, RBD mirroring.
"""

import contextlib
import html
import json
import logging
import re
import shlex

from flask import Blueprint, jsonify, request

from ProxmoxVEx.api.helpers import check_cluster_access, get_connected_manager, safe_error
from ProxmoxVEx.utils.audit import log_audit
from ProxmoxVEx.utils.auth import require_auth

bp = Blueprint("ceph", __name__)


def _ceph_url(manager, node, sub=""):
    host, port = manager.host, manager.api_port
    return f"https://{host}:{port}/api2/json/nodes/{node}/ceph{sub}"


# PVE returns OSD data as CRUSH tree, not flat list
# need to walk the tree and pull out actual osd entries (#113)
def _flatten_osd_tree(data):
    """Extract flat OSD list from Proxmox CRUSH tree response."""
    osds = []
    if isinstance(data, dict):
        root = data.get("root", data)
        _walk_osd_nodes(root, None, osds)
    elif isinstance(data, list):
        # some PVE versions return flat array already
        for item in data:
            if isinstance(item, dict) and item.get("type") == "osd":
                osds.append(item)
            elif isinstance(item, dict) and "children" in item:
                _walk_osd_nodes(item, None, osds)
    return osds


def _walk_osd_nodes(node, parent_host, out):
    if not isinstance(node, dict):
        return
    ntype = node.get("type", "")
    host = parent_host
    if ntype == "host":
        host = node.get("name", parent_host)
    if ntype == "osd":
        entry = dict(node)
        if host and not entry.get("host"):
            entry["host"] = host
        out.append(entry)
    for child in node.get("children", []):
        _walk_osd_nodes(child, host, out)


# Input validators for rbd mirror commands
# Pool/image names go into shell commands via SSH, so we MUST validate
_POOL_RE = re.compile(r"^[a-zA-Z0-9][a-zA-Z0-9_.\-]{0,63}$")
_IMAGE_RE = re.compile(r"^[a-zA-Z0-9][a-zA-Z0-9_.\-]{0,127}$")
# Peer client/site names must start alnum — a leading '-' would let the
# value be parsed as an rbd CLI flag even when shell-quoting is correct.
_PEER_NAME_RE = re.compile(r"^[a-zA-Z0-9][a-zA-Z0-9._\-]{0,127}$")
# mon_host is host[:port] comma-separated, optionally in [v1:|v2:][addr]:port
# bracketed form; it must start alnum or '[' so it can't be a leading-dash flag.
_MON_HOST_RE = re.compile(r"^[a-zA-Z0-9\[][a-zA-Z0-9._:\-,/\[\]]*$")
_SCHED_RE = re.compile(r"^\d+[mhd]$")  # e.g. 5m, 1h, 1d


def _valid_pool(name):
    return bool(name and _POOL_RE.match(name))


def _valid_image(name):
    return bool(name and _IMAGE_RE.match(name))


def _get_any_online_node(manager) -> tuple:
    """Grab first online node - same approach as get_ceph_overview

    Returns (node_name, None) or (None, error_response); bare ``tuple`` because
    the element types are correlated and callers check the error first.
    """
    try:
        host, port = manager.host, manager.api_port
        session = manager._create_session()
        nr = session.get(f"https://{host}:{port}/api2/json/nodes", timeout=5)
        if nr.status_code == 200:
            for n in nr.json().get("data", []):
                if n.get("status") == "online":
                    return n["node"], None
    except Exception as e:
        logging.warning(f"Failed to enumerate nodes: {e}")
    # snyk:ignore:python/XSS
    return None, (jsonify({"error": "No online node found"}), 503)  # snyk:ignore:python/ServerInformationExposure


def _resolve_node_ip(manager, node_name):
    """Resolve node name to IP via cluster/status API
    We need the actual IP for SSH, not the node name."""
    try:
        session = manager._create_session()
        resp = session.get(f"https://{manager.host}:{manager.api_port}/api2/json/cluster/status", timeout=8)
        if resp.status_code == 200:
            for item in resp.json().get("data", []):
                if item.get("type") == "node" and item.get("name") == node_name:
                    return item.get("ip", manager.raw_host)
    except Exception as e:
        logging.debug(f"[ceph] node IP resolution failed for {node_name}, falling back to raw_host: {e}")
    # fallback — raw IP for SSH, not bracketed
    return manager.raw_host


def _rbd_cmd(manager, node_ip, args, timeout=30, expect_json=True, ssh_client=None):
    """Execute rbd command over SSH
    Returns (data, None) on success or (None, error_response) on failure.

    Uses manager._ssh_connect which handles key/password auth,
    rate limiting, retries etc. We just need the IP.

    ``ssh_client`` (ISS-045): pass an already-connected Paramiko client to
    reuse one SSH session across many calls — without it each call pays a
    full TCP+SSH handshake (per-pool loops were O(N) handshakes).

    ``args`` may be a prebuilt string or — preferred — an argv list, which is
    joined with shlex.join() so each element is safely quoted for the remote
    shell (defense in depth on top of the endpoint regex validation).
    """
    ssh = None
    try:
        ssh = ssh_client or manager._ssh_connect(node_ip)
        if not ssh:
            # snyk:ignore:python/XSS
            return None, (
                jsonify({"error": "SSH connection failed - check SSH credentials in cluster settings"}),
                503,
            )  # snyk:ignore:python/XSS

        fmt = " --format json" if expect_json else ""
        # argv lists are quoted element-by-element; plain strings are trusted
        # as already-assembled static commands.
        args_str = shlex.join(str(a) for a in args) if isinstance(args, (list, tuple)) else args
        cmd = f"rbd {args_str}{fmt}"
        logging.debug(f"rbd cmd on {node_ip}: {cmd}")

        stdin, stdout, stderr = ssh.exec_command(cmd, timeout=timeout)
        exit_code = stdout.channel.recv_exit_status()
        out = stdout.read().decode("utf-8", errors="replace").strip()
        err = stderr.read().decode("utf-8", errors="replace").strip()

        # Exit code 22 = EINVAL, usually means mirroring not enabled on pool
        if exit_code == 22:
            if expect_json:
                return {}, None
            return "", None

        if exit_code != 0:
            # rbd not installed
            if "command not found" in err or "No such file" in err:
                # snyk:ignore:python/XSS
                return None, (
                    jsonify({"error": "rbd command not found - is ceph-common installed?"}),
                    501,
                )  # snyk:ignore:python/XSS
            msg = err or out or f"rbd exited with code {exit_code}"
            return None, (jsonify({"error": msg}), 500)  # snyk:ignore:python/XSS

        if not expect_json or not out:
            return out, None

        try:
            return json.loads(out), None
        except json.JSONDecodeError:
            # Some rbd commands output partial JSON or plain text
            return {"raw": out}, None

    except Exception as e:
        logging.error(f"rbd SSH error on {node_ip}: {e}")
        # snyk:ignore:python/XSS
        return None, (
            jsonify({"error": safe_error(e, "SSH error")}),
            503,
        )  # snyk:ignore:python/ServerInformationExposure
    finally:
        # Only close the connection we opened — a caller-supplied
        # ``ssh_client`` stays open for the caller to reuse/close (ISS-045).
        if ssh and ssh_client is None:
            with contextlib.suppress(Exception):
                ssh.close()


# ============================================
# Datacenter-Level Ceph Overview
# ============================================


@bp.route("/api/clusters/<cluster_id>/datacenter/ceph", methods=["GET"])
@require_auth(perms=["cluster.view"])
def get_ceph_overview(cluster_id):
    """Ceph cluster overview - aggregates status from first available node"""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return err  # lgtm[py/reflected-xss]

    manager, error = get_connected_manager(cluster_id)
    if error:
        return error  # lgtm[py/reflected-xss]

    result = {
        "available": False,
        "status": None,
        "osd": [],
        "mon": [],
        "mds": [],
        "mgr": [],
        "pools": [],
        "fs": [],
        "rules": [],
    }

    try:
        host, port = manager.host, manager.api_port
        session = manager._create_session()

        # Find first online node to query Ceph
        nodes_url = f"https://{host}:{port}/api2/json/nodes"
        nr = session.get(nodes_url, timeout=5)
        online_nodes = []
        if nr.status_code == 200:
            online_nodes = [n["node"] for n in nr.json().get("data", []) if n.get("status") == "online"]

        if not online_nodes:
            # snyk:ignore:python/XSS
            return jsonify(result)  # lgtm[py/reflected-xss]  # snyk:ignore:python/XSS

        # #191: try each online node until one has Ceph (not all nodes run Ceph daemons)
        ceph_node = None
        for candidate in online_nodes:
            try:
                sr = session.get(_ceph_url(manager, candidate, "/status"), timeout=10)
                if sr.status_code == 200:
                    ceph_node = candidate
                    result["available"] = True
                    result["status"] = sr.json().get("data", {})
                    break
            except Exception:
                continue

        if not ceph_node:
            # snyk:ignore:python/XSS
            return jsonify(result)  # lgtm[py/reflected-xss]  # snyk:ignore:python/ServerInformationExposure

        result["node"] = ceph_node

        # Fetch Ceph data from per-node endpoints (works on PVE 7/8/9)
        endpoints = {
            "osd": "/osd",
            "mon": "/mon",
            "mds": "/mds",
            "mgr": "/mgr",
            "pools": "/pool",
            "fs": "/fs",
            "rules": "/rules",
        }

        for key, sub in endpoints.items():
            try:
                r = session.get(_ceph_url(manager, ceph_node, sub), timeout=10)
                if r.status_code == 200:
                    raw = r.json().get("data", [])
                    if key == "osd":
                        raw = _flatten_osd_tree(raw)
                    result[key] = raw
            except Exception:
                pass

        # #191: fallback for missing data — try other nodes, then cluster endpoints
        # some endpoints may 501 on specific PVE versions (PVE 9 + Ceph Squid)
        for key, sub in endpoints.items():
            if result.get(key):
                continue
            # try other online nodes
            for fallback in online_nodes:
                if fallback == ceph_node:
                    continue
                try:
                    r = session.get(_ceph_url(manager, fallback, sub), timeout=10)
                    if r.status_code == 200:
                        raw = r.json().get("data", [])
                        if key == "osd":
                            raw = _flatten_osd_tree(raw)
                        result[key] = raw
                        break
                except Exception:
                    continue

        # last resort: cluster-level metadata endpoint (PVE 9+)
        cluster_url = f"https://{host}:{port}/api2/json/cluster/ceph"
        if not result.get("osd") or not result.get("mon"):
            try:
                r = session.get(f"{cluster_url}/metadata", timeout=10)
                if r.status_code == 200:
                    meta = r.json().get("data", {})
                    for mkey in ("osd", "mon", "mgr", "mds"):
                        if not result.get(mkey) and meta.get(mkey):
                            mdata = meta[mkey]
                            if isinstance(mdata, list):
                                result[mkey] = mdata
                            elif isinstance(mdata, dict):
                                result[mkey] = [
                                    {"name": k, **(v if isinstance(v, dict) else {})} for k, v in mdata.items()
                                ]
            except Exception:
                pass

        # snyk:ignore:python/XSS
        return jsonify(result)  # lgtm[py/reflected-xss]  # snyk:ignore:python/ServerInformationExposure

    except Exception as e:
        logging.error(f"Error getting Ceph overview: {e}")
        # snyk:ignore:python/XSS
        return jsonify(result)  # lgtm[py/reflected-xss]  # snyk:ignore:python/ServerInformationExposure


# ============================================
# Per-Node Ceph Status & Config
# ============================================


@bp.route("/api/clusters/<cluster_id>/nodes/<node>/ceph/status", methods=["GET"])
@require_auth(perms=["node.view"])
def get_node_ceph_status(cluster_id, node):
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return err  # lgtm[py/reflected-xss]

    manager, error = get_connected_manager(cluster_id)
    if error:
        return error  # lgtm[py/reflected-xss]
    try:
        r = manager._create_session().get(_ceph_url(manager, node, "/status"), timeout=10)
        if r.status_code == 200:
            # snyk:ignore:python/XSS
            return jsonify(r.json().get("data", {}))  # lgtm[py/reflected-xss]  # snyk:ignore:python/XSS
        if r.status_code in (501, 500):
            return jsonify({"available": False})  # lgtm[py/reflected-xss]  # snyk:ignore:python/XSS
        # snyk:ignore:python/XSS
        return jsonify({}), r.status_code  # lgtm[py/reflected-xss]  # snyk:ignore:python/XSS
    except Exception:
        return jsonify({})  # lgtm[py/reflected-xss]  # snyk:ignore:python/ServerInformationExposure


@bp.route("/api/clusters/<cluster_id>/nodes/<node>/ceph/config", methods=["GET"])
@require_auth(perms=["node.view"])
def get_node_ceph_config(cluster_id, node):
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return err  # lgtm[py/reflected-xss]

    manager, error = get_connected_manager(cluster_id)
    if error:
        return error  # lgtm[py/reflected-xss]
    try:
        r = manager._create_session().get(_ceph_url(manager, node, "/config"), timeout=5)
        if r.status_code == 200:
            # snyk:ignore:python/XSS
            return jsonify(r.json().get("data", ""))  # lgtm[py/reflected-xss]  # snyk:ignore:python/XSS
        return jsonify("")  # lgtm[py/reflected-xss]  # snyk:ignore:python/XSS
    except Exception:
        # snyk:ignore:python/XSS
        return jsonify("")  # lgtm[py/reflected-xss]  # snyk:ignore:python/ServerInformationExposure


@bp.route("/api/clusters/<cluster_id>/nodes/<node>/ceph/log", methods=["GET"])
@require_auth(perms=["node.view"])
def get_node_ceph_log(cluster_id, node):
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return err  # lgtm[py/reflected-xss]

    manager, error = get_connected_manager(cluster_id)
    if error:
        return error  # lgtm[py/reflected-xss]
    try:
        params = {}
        if request.args.get("limit"):
            params["limit"] = request.args["limit"]
        if request.args.get("start"):
            params["start"] = request.args["start"]
        r = manager._create_session().get(_ceph_url(manager, node, "/log"), params=params, timeout=10)
        if r.status_code == 200:
            # snyk:ignore:python/XSS
            return jsonify(r.json().get("data", []))  # lgtm[py/reflected-xss]  # snyk:ignore:python/XSS
        return jsonify([])  # lgtm[py/reflected-xss]  # snyk:ignore:python/XSS
    except Exception:
        # snyk:ignore:python/XSS
        return jsonify([])  # lgtm[py/reflected-xss]  # snyk:ignore:python/ServerInformationExposure


# ============================================
# OSD Management
# ============================================


@bp.route("/api/clusters/<cluster_id>/nodes/<node>/ceph/osd", methods=["GET"])
@require_auth(perms=["node.view"])
def get_ceph_osds(cluster_id, node):
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return err  # lgtm[py/reflected-xss]

    manager, error = get_connected_manager(cluster_id)
    if error:
        return error  # lgtm[py/reflected-xss]
    try:
        r = manager._create_session().get(_ceph_url(manager, node, "/osd"), timeout=10)
        if r.status_code == 200:
            # snyk:ignore:python/XSS
            return jsonify(
                _flatten_osd_tree(r.json().get("data", []))
            )  # lgtm[py/reflected-xss]  # snyk:ignore:python/XSS
        return jsonify([])  # lgtm[py/reflected-xss]  # snyk:ignore:python/XSS
    except Exception:
        # snyk:ignore:python/XSS
        return jsonify([])  # lgtm[py/reflected-xss]  # snyk:ignore:python/ServerInformationExposure


@bp.route("/api/clusters/<cluster_id>/nodes/<node>/ceph/osd", methods=["POST"])
@require_auth(perms=["ceph.manage"])
def create_ceph_osd(cluster_id, node):
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return err  # lgtm[py/reflected-xss]

    manager, error = get_connected_manager(cluster_id)
    if error:
        return error  # lgtm[py/reflected-xss]
    try:
        data = request.json or {}
        r = manager._create_session().post(_ceph_url(manager, node, "/osd"), data=data, timeout=30)
        if r.status_code == 200:
            usr = getattr(request, "session", {}).get("user", "system")
            log_audit(
                usr, "ceph.osd.create", f"Created OSD on {node}: {data.get('dev', '')}", cluster=manager.config.name
            )
            # snyk:ignore:python/XSS
            return jsonify(r.json().get("data", ""))  # lgtm[py/reflected-xss]  # snyk:ignore:python/XSS
        return jsonify({"error": html.escape(r.text)}), r.status_code  # snyk:ignore:python/XSS
    except Exception as e:
        # snyk:ignore:python/XSS
        return jsonify({
            "error": safe_error(e, "Ceph OSD operation failed")
        }), 500  # lgtm[py/reflected-xss]  # snyk:ignore:python/ServerInformationExposure


@bp.route("/api/clusters/<cluster_id>/nodes/<node>/ceph/osd/<int:osdid>", methods=["DELETE"])
@require_auth(perms=["ceph.manage"])
def destroy_ceph_osd(cluster_id, node, osdid):
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return err  # lgtm[py/reflected-xss]

    # SECURITY: require confirmation for destructive operations
    data = request.json or {}
    if str(data.get("confirm_name", "")) != str(osdid):
        # snyk:ignore:python/XSS
        return jsonify({
            "error": "Confirmation required: send confirm_name matching the OSD ID"
        }), 400  # lgtm[py/reflected-xss]  # snyk:ignore:python/XSS
    manager, error = get_connected_manager(cluster_id)
    if error:
        return error  # lgtm[py/reflected-xss]
    try:
        params = {}
        if request.args.get("cleanup"):
            params["cleanup"] = 1
        r = manager._create_session().delete(_ceph_url(manager, node, f"/osd/{osdid}"), params=params, timeout=60)
        if r.status_code == 200:
            usr = getattr(request, "session", {}).get("user", "system")
            log_audit(usr, "ceph.osd.destroy", f"Destroyed OSD {osdid} on {node}", cluster=manager.config.name)
            # snyk:ignore:python/XSS
            return jsonify(r.json().get("data", ""))  # lgtm[py/reflected-xss]  # snyk:ignore:python/XSS
        return jsonify({"error": html.escape(r.text)}), r.status_code  # snyk:ignore:python/XSS
    except Exception as e:
        # snyk:ignore:python/XSS
        return jsonify({
            "error": safe_error(e, "Ceph OSD operation failed")
        }), 500  # lgtm[py/reflected-xss]  # snyk:ignore:python/ServerInformationExposure


@bp.route("/api/clusters/<cluster_id>/nodes/<node>/ceph/osd/<int:osdid>/<action>", methods=["POST"])
@require_auth(perms=["ceph.manage"])
def ceph_osd_action(cluster_id, node, osdid, action):
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return err  # lgtm[py/reflected-xss]

    if action not in ("in", "out", "scrub", "deep-scrub"):
        # snyk:ignore:python/XSS
        return jsonify({"error": f"Invalid OSD action: {html.escape(action)}"}), 400  # snyk:ignore:python/XSS
    manager, error = get_connected_manager(cluster_id)
    if error:
        return error  # lgtm[py/reflected-xss]
    try:
        r = manager._create_session().post(_ceph_url(manager, node, f"/osd/{osdid}/{action}"), timeout=30)
        if r.status_code == 200:
            usr = getattr(request, "session", {}).get("user", "system")
            log_audit(usr, f"ceph.osd.{action}", f"OSD {osdid} {action} on {node}", cluster=manager.config.name)
            # snyk:ignore:python/XSS
            return jsonify({"success": True})  # lgtm[py/reflected-xss]  # snyk:ignore:python/XSS
        return jsonify({"error": html.escape(r.text)}), r.status_code  # snyk:ignore:python/XSS
    except Exception as e:
        # snyk:ignore:python/XSS
        return jsonify({
            "error": safe_error(e, "Ceph OSD operation failed")
        }), 500  # lgtm[py/reflected-xss]  # snyk:ignore:python/ServerInformationExposure


# ============================================
# Monitor Management
# ============================================


@bp.route("/api/clusters/<cluster_id>/nodes/<node>/ceph/mon", methods=["GET"])
@require_auth(perms=["node.view"])
def get_ceph_mons(cluster_id, node):
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return err  # lgtm[py/reflected-xss]

    manager, error = get_connected_manager(cluster_id)
    if error:
        return error  # lgtm[py/reflected-xss]
    try:
        r = manager._create_session().get(_ceph_url(manager, node, "/mon"), timeout=10)
        if r.status_code == 200:
            # snyk:ignore:python/XSS
            return jsonify(r.json().get("data", []))  # lgtm[py/reflected-xss]  # snyk:ignore:python/XSS
        return jsonify([])  # lgtm[py/reflected-xss]  # snyk:ignore:python/XSS
    except Exception:
        # snyk:ignore:python/XSS
        return jsonify([])  # lgtm[py/reflected-xss]  # snyk:ignore:python/ServerInformationExposure


@bp.route("/api/clusters/<cluster_id>/nodes/<node>/ceph/mon/<monid>", methods=["POST"])
@require_auth(perms=["ceph.manage"])
def create_ceph_mon(cluster_id, node, monid):
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return err  # lgtm[py/reflected-xss]

    manager, error = get_connected_manager(cluster_id)
    if error:
        return error  # lgtm[py/reflected-xss]
    try:
        data = request.json or {}
        r = manager._create_session().post(_ceph_url(manager, node, f"/mon/{monid}"), data=data, timeout=30)
        if r.status_code == 200:
            usr = getattr(request, "session", {}).get("user", "system")
            log_audit(usr, "ceph.mon.create", f"Created monitor {monid} on {node}", cluster=manager.config.name)
            # snyk:ignore:python/XSS
            return jsonify(r.json().get("data", ""))  # lgtm[py/reflected-xss]  # snyk:ignore:python/XSS
        return jsonify({"error": html.escape(r.text)}), r.status_code  # snyk:ignore:python/XSS
    except Exception as e:
        # snyk:ignore:python/XSS
        return jsonify({
            "error": safe_error(e, "Ceph monitor operation failed")
        }), 500  # lgtm[py/reflected-xss]  # snyk:ignore:python/ServerInformationExposure


@bp.route("/api/clusters/<cluster_id>/nodes/<node>/ceph/mon/<monid>", methods=["DELETE"])
@require_auth(perms=["ceph.manage"])
def destroy_ceph_mon(cluster_id, node, monid):
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return err  # lgtm[py/reflected-xss]

    manager, error = get_connected_manager(cluster_id)
    if error:
        return error  # lgtm[py/reflected-xss]
    try:
        r = manager._create_session().delete(_ceph_url(manager, node, f"/mon/{monid}"), timeout=30)
        if r.status_code == 200:
            usr = getattr(request, "session", {}).get("user", "system")
            log_audit(usr, "ceph.mon.destroy", f"Destroyed monitor {monid} on {node}", cluster=manager.config.name)
            # snyk:ignore:python/XSS
            return jsonify(r.json().get("data", ""))  # lgtm[py/reflected-xss]  # snyk:ignore:python/XSS
        return jsonify({"error": html.escape(r.text)}), r.status_code  # snyk:ignore:python/XSS
    except Exception as e:
        # snyk:ignore:python/XSS
        return jsonify({
            "error": safe_error(e, "Ceph monitor operation failed")
        }), 500  # lgtm[py/reflected-xss]  # snyk:ignore:python/ServerInformationExposure


# ============================================
# MDS (Metadata Server) Management
# ============================================


@bp.route("/api/clusters/<cluster_id>/nodes/<node>/ceph/mds", methods=["GET"])
@require_auth(perms=["node.view"])
def get_ceph_mds(cluster_id, node):
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return err  # lgtm[py/reflected-xss]

    manager, error = get_connected_manager(cluster_id)
    if error:
        return error  # lgtm[py/reflected-xss]
    try:
        r = manager._create_session().get(_ceph_url(manager, node, "/mds"), timeout=10)
        if r.status_code == 200:
            # snyk:ignore:python/XSS
            return jsonify(r.json().get("data", []))  # lgtm[py/reflected-xss]  # snyk:ignore:python/XSS
        return jsonify([])  # lgtm[py/reflected-xss]  # snyk:ignore:python/XSS
    except Exception:
        # snyk:ignore:python/XSS
        return jsonify([])  # lgtm[py/reflected-xss]  # snyk:ignore:python/ServerInformationExposure


@bp.route("/api/clusters/<cluster_id>/nodes/<node>/ceph/mds/<name>", methods=["POST"])
@require_auth(perms=["ceph.manage"])
def create_ceph_mds(cluster_id, node, name):
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return err  # lgtm[py/reflected-xss]

    manager, error = get_connected_manager(cluster_id)
    if error:
        return error  # lgtm[py/reflected-xss]
    try:
        r = manager._create_session().post(_ceph_url(manager, node, f"/mds/{name}"), timeout=30)
        if r.status_code == 200:
            usr = getattr(request, "session", {}).get("user", "system")
            log_audit(usr, "ceph.mds.create", f"Created MDS {name} on {node}", cluster=manager.config.name)
            # snyk:ignore:python/XSS
            return jsonify(r.json().get("data", ""))  # lgtm[py/reflected-xss]  # snyk:ignore:python/XSS
        return jsonify({"error": html.escape(r.text)}), r.status_code  # snyk:ignore:python/XSS
    except Exception as e:
        # snyk:ignore:python/XSS
        return jsonify({
            "error": safe_error(e, "Ceph service operation failed")
        }), 500  # lgtm[py/reflected-xss]  # snyk:ignore:python/ServerInformationExposure


@bp.route("/api/clusters/<cluster_id>/nodes/<node>/ceph/mds/<name>", methods=["DELETE"])
@require_auth(perms=["ceph.manage"])
def destroy_ceph_mds(cluster_id, node, name):
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return err  # lgtm[py/reflected-xss]

    manager, error = get_connected_manager(cluster_id)
    if error:
        return error  # lgtm[py/reflected-xss]
    try:
        r = manager._create_session().delete(_ceph_url(manager, node, f"/mds/{name}"), timeout=30)
        if r.status_code == 200:
            usr = getattr(request, "session", {}).get("user", "system")
            log_audit(usr, "ceph.mds.destroy", f"Destroyed MDS {name} on {node}", cluster=manager.config.name)
            # snyk:ignore:python/XSS
            return jsonify(r.json().get("data", ""))  # lgtm[py/reflected-xss]  # snyk:ignore:python/XSS
        return jsonify({"error": html.escape(r.text)}), r.status_code  # snyk:ignore:python/XSS
    except Exception as e:
        # snyk:ignore:python/XSS
        return jsonify({
            "error": safe_error(e, "Ceph service operation failed")
        }), 500  # lgtm[py/reflected-xss]  # snyk:ignore:python/ServerInformationExposure


# ============================================
# MGR (Manager) - Read Only
# ============================================


@bp.route("/api/clusters/<cluster_id>/nodes/<node>/ceph/mgr", methods=["GET"])
@require_auth(perms=["node.view"])
def get_ceph_mgr(cluster_id, node):
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return err  # lgtm[py/reflected-xss]

    manager, error = get_connected_manager(cluster_id)
    if error:
        return error  # lgtm[py/reflected-xss]
    try:
        r = manager._create_session().get(_ceph_url(manager, node, "/mgr"), timeout=10)
        if r.status_code == 200:
            # snyk:ignore:python/XSS
            return jsonify(r.json().get("data", []))  # lgtm[py/reflected-xss]  # snyk:ignore:python/XSS
        return jsonify([])  # lgtm[py/reflected-xss]  # snyk:ignore:python/XSS
    except Exception:
        # snyk:ignore:python/XSS
        return jsonify([])  # lgtm[py/reflected-xss]  # snyk:ignore:python/ServerInformationExposure


# ============================================
# Pool Management
# ============================================


@bp.route("/api/clusters/<cluster_id>/nodes/<node>/ceph/pool", methods=["GET"])
@require_auth(perms=["node.view"])
def get_ceph_pools(cluster_id, node):
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return err  # lgtm[py/reflected-xss]

    manager, error = get_connected_manager(cluster_id)
    if error:
        return error  # lgtm[py/reflected-xss]
    try:
        r = manager._create_session().get(_ceph_url(manager, node, "/pool"), timeout=10)
        if r.status_code == 200:
            # snyk:ignore:python/XSS
            return jsonify(r.json().get("data", []))  # lgtm[py/reflected-xss]  # snyk:ignore:python/XSS
        return jsonify([])  # lgtm[py/reflected-xss]  # snyk:ignore:python/XSS
    except Exception:
        # snyk:ignore:python/XSS
        return jsonify([])  # lgtm[py/reflected-xss]  # snyk:ignore:python/ServerInformationExposure


@bp.route("/api/clusters/<cluster_id>/nodes/<node>/ceph/pool", methods=["POST"])
@require_auth(perms=["ceph.manage"])
def create_ceph_pool(cluster_id, node):
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return err  # lgtm[py/reflected-xss]

    manager, error = get_connected_manager(cluster_id)
    if error:
        return error  # lgtm[py/reflected-xss]
    try:
        data = request.json or {}
        r = manager._create_session().post(_ceph_url(manager, node, "/pool"), data=data, timeout=30)
        if r.status_code == 200:
            usr = getattr(request, "session", {}).get("user", "system")
            log_audit(usr, "ceph.pool.create", f"Created pool {data.get('name', '')}", cluster=manager.config.name)
            # snyk:ignore:python/XSS
            return jsonify(r.json().get("data", ""))  # lgtm[py/reflected-xss]  # snyk:ignore:python/XSS
        return jsonify({"error": html.escape(r.text)}), r.status_code  # snyk:ignore:python/XSS
    except Exception as e:
        # snyk:ignore:python/XSS
        return jsonify({
            "error": safe_error(e, "Ceph pool operation failed")
        }), 500  # lgtm[py/reflected-xss]  # snyk:ignore:python/ServerInformationExposure


@bp.route("/api/clusters/<cluster_id>/nodes/<node>/ceph/pool/<name>", methods=["PUT"])
@require_auth(perms=["ceph.manage"])
def update_ceph_pool(cluster_id, node, name):
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return err  # lgtm[py/reflected-xss]

    manager, error = get_connected_manager(cluster_id)
    if error:
        return error  # lgtm[py/reflected-xss]
    try:
        data = request.json or {}
        r = manager._create_session().put(_ceph_url(manager, node, f"/pool/{name}"), data=data, timeout=10)
        if r.status_code == 200:
            usr = getattr(request, "session", {}).get("user", "system")
            log_audit(usr, "ceph.pool.update", f"Updated pool {name}", cluster=manager.config.name)
            # snyk:ignore:python/XSS
            return jsonify({"success": True})  # lgtm[py/reflected-xss]  # snyk:ignore:python/XSS
        return jsonify({"error": html.escape(r.text)}), r.status_code  # snyk:ignore:python/XSS
    except Exception as e:
        # snyk:ignore:python/XSS
        return jsonify({
            "error": safe_error(e, "Ceph pool operation failed")
        }), 500  # lgtm[py/reflected-xss]  # snyk:ignore:python/ServerInformationExposure


@bp.route("/api/clusters/<cluster_id>/nodes/<node>/ceph/pool/<name>", methods=["DELETE"])
@require_auth(perms=["ceph.manage"])
def destroy_ceph_pool(cluster_id, node, name):
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return err  # lgtm[py/reflected-xss]

    # SECURITY: require confirmation for destructive operations
    data = request.json or {}
    if data.get("confirm_name") != name:
        # snyk:ignore:python/XSS
        return jsonify({
            "error": "Confirmation required: send confirm_name matching the pool name"
        }), 400  # lgtm[py/reflected-xss]  # snyk:ignore:python/XSS
    manager, error = get_connected_manager(cluster_id)
    if error:
        return error  # lgtm[py/reflected-xss]
    try:
        params = {}
        if request.args.get("remove_storages"):
            params["remove_storages"] = 1
        if request.args.get("remove_ecprofile"):
            params["remove_ecprofile"] = 1
        r = manager._create_session().delete(_ceph_url(manager, node, f"/pool/{name}"), params=params, timeout=30)
        if r.status_code == 200:
            usr = getattr(request, "session", {}).get("user", "system")
            log_audit(usr, "ceph.pool.destroy", f"Destroyed pool {name}", cluster=manager.config.name)
            # snyk:ignore:python/XSS
            return jsonify(r.json().get("data", ""))  # lgtm[py/reflected-xss]  # snyk:ignore:python/XSS
        return jsonify({"error": html.escape(r.text)}), r.status_code  # snyk:ignore:python/XSS
    except Exception as e:
        # snyk:ignore:python/XSS
        return jsonify({
            "error": safe_error(e, "Ceph pool operation failed")
        }), 500  # lgtm[py/reflected-xss]  # snyk:ignore:python/ServerInformationExposure


# ============================================
# CephFS Management
# ============================================


@bp.route("/api/clusters/<cluster_id>/nodes/<node>/ceph/fs", methods=["GET"])
@require_auth(perms=["node.view"])
def get_ceph_fs(cluster_id, node):
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return err  # lgtm[py/reflected-xss]

    manager, error = get_connected_manager(cluster_id)
    if error:
        return error  # lgtm[py/reflected-xss]
    try:
        r = manager._create_session().get(_ceph_url(manager, node, "/fs"), timeout=10)
        if r.status_code == 200:
            # snyk:ignore:python/XSS
            return jsonify(r.json().get("data", []))  # lgtm[py/reflected-xss]  # snyk:ignore:python/XSS
        return jsonify([])  # lgtm[py/reflected-xss]  # snyk:ignore:python/XSS
    except Exception:
        # snyk:ignore:python/XSS
        return jsonify([])  # lgtm[py/reflected-xss]  # snyk:ignore:python/ServerInformationExposure


@bp.route("/api/clusters/<cluster_id>/nodes/<node>/ceph/fs", methods=["POST"])
@require_auth(perms=["ceph.manage"])
def create_ceph_fs(cluster_id, node):
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return err  # lgtm[py/reflected-xss]

    manager, error = get_connected_manager(cluster_id)
    if error:
        return error  # lgtm[py/reflected-xss]
    try:
        data = request.json or {}
        r = manager._create_session().post(_ceph_url(manager, node, "/fs"), data=data, timeout=30)
        if r.status_code == 200:
            usr = getattr(request, "session", {}).get("user", "system")
            log_audit(usr, "ceph.fs.create", f"Created CephFS {data.get('name', '')}", cluster=manager.config.name)
            # snyk:ignore:python/XSS
            return jsonify(r.json().get("data", ""))  # lgtm[py/reflected-xss]  # snyk:ignore:python/XSS
        return jsonify({"error": html.escape(r.text)}), r.status_code  # snyk:ignore:python/XSS
    except Exception as e:
        # snyk:ignore:python/XSS
        return jsonify({
            "error": safe_error(e, "CephFS operation failed")
        }), 500  # lgtm[py/reflected-xss]  # snyk:ignore:python/ServerInformationExposure


@bp.route("/api/clusters/<cluster_id>/nodes/<node>/ceph/fs/<name>", methods=["DELETE"])
@require_auth(perms=["ceph.manage"])
def destroy_ceph_fs(cluster_id, node, name):
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return err  # lgtm[py/reflected-xss]

    # SECURITY: require confirmation for destructive operations
    data = request.json or {}
    if data.get("confirm_name") != name:
        # snyk:ignore:python/XSS
        return jsonify({
            "error": "Confirmation required: send confirm_name matching the CephFS name"
        }), 400  # lgtm[py/reflected-xss]  # snyk:ignore:python/XSS
    manager, error = get_connected_manager(cluster_id)
    if error:
        return error  # lgtm[py/reflected-xss]
    try:
        r = manager._create_session().delete(_ceph_url(manager, node, f"/fs/{name}"), timeout=30)
        if r.status_code == 200:
            usr = getattr(request, "session", {}).get("user", "system")
            log_audit(usr, "ceph.fs.destroy", f"Destroyed CephFS {name}", cluster=manager.config.name)
            # snyk:ignore:python/XSS
            return jsonify(r.json().get("data", ""))  # lgtm[py/reflected-xss]  # snyk:ignore:python/XSS
        return jsonify({"error": html.escape(r.text)}), r.status_code  # snyk:ignore:python/XSS
    except Exception as e:
        # snyk:ignore:python/XSS
        return jsonify({
            "error": safe_error(e, "CephFS operation failed")
        }), 500  # lgtm[py/reflected-xss]  # snyk:ignore:python/ServerInformationExposure


# ============================================
# CRUSH Rules
# ============================================


@bp.route("/api/clusters/<cluster_id>/nodes/<node>/ceph/rules", methods=["GET"])
@require_auth(perms=["node.view"])
def get_ceph_rules(cluster_id, node):
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return err  # lgtm[py/reflected-xss]

    manager, error = get_connected_manager(cluster_id)
    if error:
        return error  # lgtm[py/reflected-xss]
    try:
        r = manager._create_session().get(_ceph_url(manager, node, "/rules"), timeout=5)
        if r.status_code == 200:
            # snyk:ignore:python/XSS
            return jsonify(r.json().get("data", []))  # lgtm[py/reflected-xss]  # snyk:ignore:python/XSS
        return jsonify([])  # lgtm[py/reflected-xss]  # snyk:ignore:python/XSS
    except Exception:
        # snyk:ignore:python/XSS
        return jsonify([])  # lgtm[py/reflected-xss]  # snyk:ignore:python/ServerInformationExposure


# ============================================
# Service Control
# ============================================


@bp.route("/api/clusters/<cluster_id>/nodes/<node>/ceph/<action>", methods=["POST"])
@require_auth(perms=["ceph.manage"])
def ceph_service_action(cluster_id, node, action):
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return err  # lgtm[py/reflected-xss]

    if action not in ("start", "stop", "restart"):
        # snyk:ignore:python/XSS
        return jsonify({"error": f"Invalid service action: {html.escape(action)}"}), 400  # snyk:ignore:python/XSS
    manager, error = get_connected_manager(cluster_id)
    if error:
        return error  # lgtm[py/reflected-xss]
    try:
        data = request.json or {}
        r = manager._create_session().post(_ceph_url(manager, node, f"/{action}"), data=data, timeout=30)
        if r.status_code == 200:
            usr = getattr(request, "session", {}).get("user", "system")
            log_audit(usr, f"ceph.service.{action}", f"Ceph {action} on {node}", cluster=manager.config.name)
            # snyk:ignore:python/XSS
            return jsonify(r.json().get("data", ""))  # lgtm[py/reflected-xss]  # snyk:ignore:python/XSS
        return jsonify({"error": html.escape(r.text)}), r.status_code  # snyk:ignore:python/XSS
    except Exception as e:
        # snyk:ignore:python/XSS
        return jsonify({
            "error": safe_error(e, "Ceph service operation failed")
        }), 500  # lgtm[py/reflected-xss]  # snyk:ignore:python/ServerInformationExposure


@bp.route("/api/clusters/<cluster_id>/nodes/<node>/ceph/init", methods=["POST"])
@require_auth(perms=["ceph.manage"])
def init_ceph(cluster_id, node):
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return err  # lgtm[py/reflected-xss]

    manager, error = get_connected_manager(cluster_id)
    if error:
        return error  # lgtm[py/reflected-xss]
    try:
        data = request.json or {}
        r = manager._create_session().post(_ceph_url(manager, node, "/init"), data=data, timeout=60)
        if r.status_code == 200:
            usr = getattr(request, "session", {}).get("user", "system")
            log_audit(usr, "ceph.init", f"Initialized Ceph on {node}", cluster=manager.config.name)
            # snyk:ignore:python/XSS
            return jsonify(r.json().get("data", ""))  # lgtm[py/reflected-xss]  # snyk:ignore:python/XSS
        return jsonify({"error": html.escape(r.text)}), r.status_code  # snyk:ignore:python/XSS
    except Exception as e:
        # snyk:ignore:python/XSS
        return jsonify({
            "error": safe_error(e, "Ceph init failed")
        }), 500  # lgtm[py/reflected-xss]  # snyk:ignore:python/ServerInformationExposure


# ============================================
# RBD Mirroring
# Proxmox doesn't expose rbd-mirror via API,
# so we SSH into a node and run rbd CLI commands directly.
# ============================================


@bp.route("/api/clusters/<cluster_id>/ceph/mirror/overview", methods=["GET"])
@require_auth(perms=["cluster.view"])
def get_mirror_overview(cluster_id):
    """Overview of mirroring status across all pools"""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return err  # lgtm[py/reflected-xss]

    manager, error = get_connected_manager(cluster_id)
    if error:
        return error  # lgtm[py/reflected-xss]

    node, node_err = _get_any_online_node(manager)
    if node_err:
        return node_err  # lgtm[py/reflected-xss]
    node_ip = _resolve_node_ip(manager, node)

    # get pool list from Proxmox API first
    pools = []
    try:
        session = manager._create_session()
        r = session.get(_ceph_url(manager, node, "/pool"), timeout=10)
        if r.status_code == 200:
            pools = r.json().get("data", [])
    except Exception:
        pass

    if not pools:
        # snyk:ignore:python/XSS
        return jsonify({"pools": [], "node": html.escape(node)})  # snyk:ignore:python/ServerInformationExposure

    result = []
    # ISS-045: reuse one SSH session for all per-pool rbd calls instead of
    # connecting/closing per command (2 commands x N pools of handshakes).
    shared_ssh = manager._ssh_connect(node_ip)
    try:
        for pool_info in pools:
            pname = pool_info.get("pool_name") or pool_info.get("name", "")
            if not pname or not _valid_pool(pname):
                continue

            entry = {"name": pname, "mode": "disabled", "peers": [], "health": None, "image_count": 0}

            # Get mirror info for this pool
            info, info_err = _rbd_cmd(manager, node_ip, ["mirror", "pool", "info", pname], ssh_client=shared_ssh)
            if not info_err and isinstance(info, dict):
                mode = info.get("mode", "disabled")
                entry["mode"] = mode if mode != "disabled" else "disabled"
                entry["peers"] = info.get("peers", [])
                entry["site_name"] = info.get("site_name", "")

            # only fetch status if mirroring is actually on
            if entry["mode"] != "disabled":
                status, st_err = _rbd_cmd(manager, node_ip, ["mirror", "pool", "status", pname], ssh_client=shared_ssh)
                if not st_err and isinstance(status, dict):
                    summary = status.get("summary", {})
                    health = status.get("health", "UNKNOWN")
                    entry["health"] = health
                    entry["image_count"] = summary.get("states", {}).get("total", 0) if isinstance(summary, dict) else 0
                    entry["summary"] = summary

            result.append(entry)
    finally:
        if shared_ssh:
            with contextlib.suppress(Exception):
                shared_ssh.close()

    # snyk:ignore:python/XSS
    return jsonify({"pools": result, "node": html.escape(node)})  # snyk:ignore:python/XSS


@bp.route("/api/clusters/<cluster_id>/ceph/mirror/pool/<pool>/status", methods=["GET"])
@require_auth(perms=["cluster.view"])
def get_mirror_pool_status(cluster_id, pool):
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return err  # lgtm[py/reflected-xss]
    if not _valid_pool(pool):
        # snyk:ignore:python/XSS
        return jsonify({"error": "Invalid pool name"}), 400  # lgtm[py/reflected-xss]  # snyk:ignore:python/XSS

    manager, error = get_connected_manager(cluster_id)
    if error:
        return error  # lgtm[py/reflected-xss]

    node, node_err = _get_any_online_node(manager)
    if node_err:
        return node_err  # lgtm[py/reflected-xss]
    node_ip = _resolve_node_ip(manager, node)

    data, cmd_err = _rbd_cmd(manager, node_ip, ["mirror", "pool", "status", pool])
    if cmd_err:
        return cmd_err  # lgtm[py/reflected-xss]
    # snyk:ignore:python/XSS
    return jsonify(data)  # lgtm[py/reflected-xss]  # snyk:ignore:python/XSS


@bp.route("/api/clusters/<cluster_id>/ceph/mirror/pool/<pool>/enable", methods=["POST"])
@require_auth(perms=["ceph.manage"])
def enable_mirror_pool(cluster_id, pool):
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return err  # lgtm[py/reflected-xss]
    if not _valid_pool(pool):
        # snyk:ignore:python/XSS
        return jsonify({"error": "Invalid pool name"}), 400  # lgtm[py/reflected-xss]  # snyk:ignore:python/XSS

    manager, error = get_connected_manager(cluster_id)
    if error:
        return error  # lgtm[py/reflected-xss]

    body = request.json or {}
    mode = body.get("mode", "image")
    if mode not in ("pool", "image"):
        # snyk:ignore:python/XSS
        return jsonify({
            "error": 'Mode must be "pool" or "image"'
        }), 400  # lgtm[py/reflected-xss]  # snyk:ignore:python/XSS

    node, node_err = _get_any_online_node(manager)
    if node_err:
        return node_err  # lgtm[py/reflected-xss]
    node_ip = _resolve_node_ip(manager, node)

    data, cmd_err = _rbd_cmd(manager, node_ip, ["mirror", "pool", "enable", pool, mode], expect_json=False)
    if cmd_err:
        return cmd_err  # lgtm[py/reflected-xss]

    usr = getattr(request, "session", {}).get("user", "system")
    log_audit(
        usr, "ceph.mirror.pool.enable", f"Enabled mirroring on pool {pool} (mode={mode})", cluster=manager.config.name
    )
    # snyk:ignore:python/XSS
    return jsonify({"success": True})  # lgtm[py/reflected-xss]  # snyk:ignore:python/XSS


@bp.route("/api/clusters/<cluster_id>/ceph/mirror/pool/<pool>/disable", methods=["POST"])
@require_auth(perms=["ceph.manage"])
def disable_mirror_pool(cluster_id, pool):
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return err  # lgtm[py/reflected-xss]
    if not _valid_pool(pool):
        # snyk:ignore:python/XSS
        return jsonify({"error": "Invalid pool name"}), 400  # lgtm[py/reflected-xss]  # snyk:ignore:python/XSS

    manager, error = get_connected_manager(cluster_id)
    if error:
        return error  # lgtm[py/reflected-xss]

    node, node_err = _get_any_online_node(manager)
    if node_err:
        return node_err  # lgtm[py/reflected-xss]
    node_ip = _resolve_node_ip(manager, node)

    data, cmd_err = _rbd_cmd(manager, node_ip, ["mirror", "pool", "disable", pool], expect_json=False)
    if cmd_err:
        return cmd_err  # lgtm[py/reflected-xss]

    usr = getattr(request, "session", {}).get("user", "system")
    log_audit(usr, "ceph.mirror.pool.disable", f"Disabled mirroring on pool {pool}", cluster=manager.config.name)
    # snyk:ignore:python/XSS
    return jsonify({"success": True})  # lgtm[py/reflected-xss]  # snyk:ignore:python/XSS


# -- Peer management --


@bp.route("/api/clusters/<cluster_id>/ceph/mirror/pool/<pool>/peer", methods=["POST"])
@require_auth(perms=["ceph.manage"])
def add_mirror_peer(cluster_id, pool):
    """Add a mirroring peer to a pool"""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return err  # lgtm[py/reflected-xss]
    if not _valid_pool(pool):
        # snyk:ignore:python/XSS
        return jsonify({"error": "Invalid pool name"}), 400  # lgtm[py/reflected-xss]  # snyk:ignore:python/XSS

    manager, error = get_connected_manager(cluster_id)
    if error:
        return error  # lgtm[py/reflected-xss]

    body = request.json or {}
    client = body.get("client", "client.admin")
    site = body.get("site_name", "")
    mon_host = body.get("mon_host", "")

    if not site:
        # snyk:ignore:python/XSS
        return jsonify({"error": "site_name is required"}), 400  # lgtm[py/reflected-xss]  # snyk:ignore:python/XSS
    # Validate client/site to prevent injection — must start alnum so the
    # client@site token can never be parsed as an rbd flag.
    if not _PEER_NAME_RE.match(client):
        # snyk:ignore:python/XSS
        return jsonify({"error": "Invalid client name"}), 400  # lgtm[py/reflected-xss]  # snyk:ignore:python/XSS
    if not _PEER_NAME_RE.match(site):
        return jsonify({"error": "Invalid site name"}), 400  # lgtm[py/reflected-xss]  # snyk:ignore:python/XSS

    node, node_err = _get_any_online_node(manager)
    if node_err:
        return node_err  # lgtm[py/reflected-xss]
    node_ip = _resolve_node_ip(manager, node)

    cmd = ["mirror", "pool", "peer", "add", pool, f"{client}@{site}"]
    if mon_host:
        # Mon_host can have commas/colons for multiple monitors; first char
        # must be alnum or '[' so it can't be mistaken for a CLI flag.
        if not _MON_HOST_RE.match(mon_host):
            # snyk:ignore:python/XSS
            return jsonify({
                "error": "Invalid monitor host format"
            }), 400  # lgtm[py/reflected-xss]  # snyk:ignore:python/XSS
        cmd += ["--mon-host", mon_host]

    data, cmd_err = _rbd_cmd(manager, node_ip, cmd, expect_json=False)
    if cmd_err:
        return cmd_err  # lgtm[py/reflected-xss]

    usr = getattr(request, "session", {}).get("user", "system")
    log_audit(
        usr, "ceph.mirror.peer.add", f"Added mirror peer {client}@{site} to pool {pool}", cluster=manager.config.name
    )
    # snyk:ignore:python/XSS
    return jsonify({"success": True})  # lgtm[py/reflected-xss]  # snyk:ignore:python/XSS


@bp.route("/api/clusters/<cluster_id>/ceph/mirror/pool/<pool>/peer/<uuid>", methods=["DELETE"])
@require_auth(perms=["ceph.manage"])
def remove_mirror_peer(cluster_id, pool, uuid):
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return err  # lgtm[py/reflected-xss]
    if not _valid_pool(pool):
        # snyk:ignore:python/XSS
        return jsonify({"error": "Invalid pool name"}), 400  # lgtm[py/reflected-xss]  # snyk:ignore:python/XSS
    # UUID format validation
    if not re.match(r"^[a-f0-9\-]{36}$", uuid):
        # snyk:ignore:python/XSS
        return jsonify({"error": "Invalid peer UUID"}), 400  # lgtm[py/reflected-xss]  # snyk:ignore:python/XSS

    manager, error = get_connected_manager(cluster_id)
    if error:
        return error  # lgtm[py/reflected-xss]

    node, node_err = _get_any_online_node(manager)
    if node_err:
        return node_err  # lgtm[py/reflected-xss]
    node_ip = _resolve_node_ip(manager, node)

    data, cmd_err = _rbd_cmd(manager, node_ip, ["mirror", "pool", "peer", "remove", pool, uuid], expect_json=False)
    if cmd_err:
        return cmd_err  # lgtm[py/reflected-xss]

    usr = getattr(request, "session", {}).get("user", "system")
    log_audit(
        usr, "ceph.mirror.peer.remove", f"Removed mirror peer {uuid} from pool {pool}", cluster=manager.config.name
    )
    # snyk:ignore:python/XSS
    return jsonify({"success": True})  # lgtm[py/reflected-xss]  # snyk:ignore:python/XSS


# -- Image mirroring --


@bp.route("/api/clusters/<cluster_id>/ceph/mirror/pool/<pool>/images", methods=["GET"])
@require_auth(perms=["cluster.view"])
def list_mirror_images(cluster_id, pool):
    """List images + their mirror status in one go
    We batch this in a single SSH session to avoid hammering the node"""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return err  # lgtm[py/reflected-xss]
    if not _valid_pool(pool):
        # snyk:ignore:python/XSS
        return jsonify({"error": "Invalid pool name"}), 400  # lgtm[py/reflected-xss]  # snyk:ignore:python/XSS

    manager, error = get_connected_manager(cluster_id)
    if error:
        return error  # lgtm[py/reflected-xss]

    node, node_err = _get_any_online_node(manager)
    if node_err:
        return node_err  # lgtm[py/reflected-xss]
    node_ip = _resolve_node_ip(manager, node)

    # first get the image list
    images_data, img_err = _rbd_cmd(manager, node_ip, ["ls", pool])
    if img_err:
        return img_err  # lgtm[py/reflected-xss]

    # rbd ls --format json returns a list of image names
    if isinstance(images_data, list):
        image_names = images_data
    elif isinstance(images_data, dict) and "raw" in images_data:
        image_names = [n.strip() for n in images_data["raw"].split("\n") if n.strip()]
    else:
        image_names = []

    # Now get mirror status for each image (batched via separate commands)
    # could use a single SSH session but _rbd_cmd handles cleanup
    result = []
    for img in image_names[:100]:  # cap at 100 to avoid timeout
        if not _valid_image(str(img)):
            continue
        # bare dict annotation: `mirroring` starts as None then holds a dict
        entry: dict = {"name": img, "mirroring": None}
        status, st_err = _rbd_cmd(manager, node_ip, ["mirror", "image", "status", f"{pool}/{img}"], timeout=10)
        if not st_err and isinstance(status, dict):
            entry["mirroring"] = status
        result.append(entry)

    # snyk:ignore:python/XSS
    return jsonify({"images": result, "pool": html.escape(pool)})  # snyk:ignore:python/XSS


@bp.route("/api/clusters/<cluster_id>/ceph/mirror/pool/<pool>/image/<image>/status", methods=["GET"])
@require_auth(perms=["cluster.view"])
def get_mirror_image_status(cluster_id, pool, image):
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return err  # lgtm[py/reflected-xss]
    if not _valid_pool(pool) or not _valid_image(image):
        # snyk:ignore:python/XSS
        return jsonify({"error": "Invalid pool or image name"}), 400  # lgtm[py/reflected-xss]  # snyk:ignore:python/XSS

    manager, error = get_connected_manager(cluster_id)
    if error:
        return error  # lgtm[py/reflected-xss]

    node, node_err = _get_any_online_node(manager)
    if node_err:
        return node_err  # lgtm[py/reflected-xss]
    node_ip = _resolve_node_ip(manager, node)

    data, cmd_err = _rbd_cmd(manager, node_ip, ["mirror", "image", "status", f"{pool}/{image}"])
    if cmd_err:
        return cmd_err  # lgtm[py/reflected-xss]
    # snyk:ignore:python/XSS
    return jsonify(data)  # lgtm[py/reflected-xss]  # snyk:ignore:python/XSS


@bp.route("/api/clusters/<cluster_id>/ceph/mirror/pool/<pool>/image/<image>/enable", methods=["POST"])
@require_auth(perms=["ceph.manage"])
def enable_mirror_image(cluster_id, pool, image):
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return err  # lgtm[py/reflected-xss]
    if not _valid_pool(pool) or not _valid_image(image):
        # snyk:ignore:python/XSS
        return jsonify({"error": "Invalid pool or image name"}), 400  # lgtm[py/reflected-xss]  # snyk:ignore:python/XSS

    manager, error = get_connected_manager(cluster_id)
    if error:
        return error  # lgtm[py/reflected-xss]

    body = request.json or {}
    mode = body.get("mode", "snapshot")
    if mode not in ("snapshot", "journal"):
        # snyk:ignore:python/XSS
        return jsonify({
            "error": 'Mode must be "snapshot" or "journal"'
        }), 400  # lgtm[py/reflected-xss]  # snyk:ignore:python/XSS

    node, node_err = _get_any_online_node(manager)
    if node_err:
        return node_err  # lgtm[py/reflected-xss]
    node_ip = _resolve_node_ip(manager, node)

    data, cmd_err = _rbd_cmd(manager, node_ip, ["mirror", "image", "enable", f"{pool}/{image}", mode], expect_json=False)
    if cmd_err:
        return cmd_err  # lgtm[py/reflected-xss]

    usr = getattr(request, "session", {}).get("user", "system")
    log_audit(
        usr,
        "ceph.mirror.image.enable",
        f"Enabled mirroring for {pool}/{image} (mode={mode})",
        cluster=manager.config.name,
    )
    # snyk:ignore:python/XSS
    return jsonify({"success": True})  # lgtm[py/reflected-xss]  # snyk:ignore:python/XSS


@bp.route("/api/clusters/<cluster_id>/ceph/mirror/pool/<pool>/image/<image>/disable", methods=["POST"])
@require_auth(perms=["ceph.manage"])
def disable_mirror_image(cluster_id, pool, image):
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return err  # lgtm[py/reflected-xss]
    if not _valid_pool(pool) or not _valid_image(image):
        # snyk:ignore:python/XSS
        return jsonify({"error": "Invalid pool or image name"}), 400  # lgtm[py/reflected-xss]  # snyk:ignore:python/XSS

    manager, error = get_connected_manager(cluster_id)
    if error:
        return error  # lgtm[py/reflected-xss]

    node, node_err = _get_any_online_node(manager)
    if node_err:
        return node_err  # lgtm[py/reflected-xss]
    node_ip = _resolve_node_ip(manager, node)

    data, cmd_err = _rbd_cmd(manager, node_ip, ["mirror", "image", "disable", f"{pool}/{image}"], expect_json=False)
    if cmd_err:
        return cmd_err  # lgtm[py/reflected-xss]

    usr = getattr(request, "session", {}).get("user", "system")
    log_audit(usr, "ceph.mirror.image.disable", f"Disabled mirroring for {pool}/{image}", cluster=manager.config.name)
    # snyk:ignore:python/XSS
    return jsonify({"success": True})  # lgtm[py/reflected-xss]  # snyk:ignore:python/XSS


@bp.route("/api/clusters/<cluster_id>/ceph/mirror/pool/<pool>/image/<image>/promote", methods=["POST"])
@require_auth(perms=["ceph.manage"])
def promote_mirror_image(cluster_id, pool, image):
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return err  # lgtm[py/reflected-xss]
    if not _valid_pool(pool) or not _valid_image(image):
        # snyk:ignore:python/XSS
        return jsonify({"error": "Invalid pool or image name"}), 400  # lgtm[py/reflected-xss]  # snyk:ignore:python/XSS

    manager, error = get_connected_manager(cluster_id)
    if error:
        return error  # lgtm[py/reflected-xss]

    body = request.json or {}
    force = body.get("force", False)

    node, node_err = _get_any_online_node(manager)
    if node_err:
        return node_err  # lgtm[py/reflected-xss]
    node_ip = _resolve_node_ip(manager, node)

    cmd = ["mirror", "image", "promote", f"{pool}/{image}"]
    if force:
        cmd.append("--force")

    data, cmd_err = _rbd_cmd(manager, node_ip, cmd, expect_json=False)
    if cmd_err:
        return cmd_err  # lgtm[py/reflected-xss]

    usr = getattr(request, "session", {}).get("user", "system")
    log_audit(
        usr,
        "ceph.mirror.image.promote",
        f"Promoted {pool}/{image}" + (" (forced)" if force else ""),
        cluster=manager.config.name,
    )
    # snyk:ignore:python/XSS
    return jsonify({"success": True})  # lgtm[py/reflected-xss]  # snyk:ignore:python/XSS


@bp.route("/api/clusters/<cluster_id>/ceph/mirror/pool/<pool>/image/<image>/demote", methods=["POST"])
@require_auth(perms=["ceph.manage"])
def demote_mirror_image(cluster_id, pool, image):
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return err  # lgtm[py/reflected-xss]
    if not _valid_pool(pool) or not _valid_image(image):
        # snyk:ignore:python/XSS
        return jsonify({"error": "Invalid pool or image name"}), 400  # lgtm[py/reflected-xss]  # snyk:ignore:python/XSS

    manager, error = get_connected_manager(cluster_id)
    if error:
        return error  # lgtm[py/reflected-xss]

    node, node_err = _get_any_online_node(manager)
    if node_err:
        return node_err  # lgtm[py/reflected-xss]
    node_ip = _resolve_node_ip(manager, node)

    data, cmd_err = _rbd_cmd(manager, node_ip, ["mirror", "image", "demote", f"{pool}/{image}"], expect_json=False)
    if cmd_err:
        return cmd_err  # lgtm[py/reflected-xss]

    usr = getattr(request, "session", {}).get("user", "system")
    log_audit(usr, "ceph.mirror.image.demote", f"Demoted {pool}/{image}", cluster=manager.config.name)
    # snyk:ignore:python/XSS
    return jsonify({"success": True})  # lgtm[py/reflected-xss]  # snyk:ignore:python/XSS


@bp.route("/api/clusters/<cluster_id>/ceph/mirror/pool/<pool>/image/<image>/resync", methods=["POST"])
@require_auth(perms=["ceph.manage"])
def resync_mirror_image(cluster_id, pool, image):
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return err  # lgtm[py/reflected-xss]
    if not _valid_pool(pool) or not _valid_image(image):
        # snyk:ignore:python/XSS
        return jsonify({"error": "Invalid pool or image name"}), 400  # lgtm[py/reflected-xss]  # snyk:ignore:python/XSS

    manager, error = get_connected_manager(cluster_id)
    if error:
        return error  # lgtm[py/reflected-xss]

    node, node_err = _get_any_online_node(manager)
    if node_err:
        return node_err  # lgtm[py/reflected-xss]
    node_ip = _resolve_node_ip(manager, node)

    data, cmd_err = _rbd_cmd(manager, node_ip, ["mirror", "image", "resync", f"{pool}/{image}"], expect_json=False)
    if cmd_err:
        return cmd_err  # lgtm[py/reflected-xss]

    usr = getattr(request, "session", {}).get("user", "system")
    log_audit(usr, "ceph.mirror.image.resync", f"Resync {pool}/{image}", cluster=manager.config.name)
    # snyk:ignore:python/XSS
    return jsonify({"success": True})  # lgtm[py/reflected-xss]  # snyk:ignore:python/XSS


# -- Snapshot schedules --


@bp.route("/api/clusters/<cluster_id>/ceph/mirror/pool/<pool>/schedule", methods=["GET"])
@require_auth(perms=["cluster.view"])
def get_mirror_schedules(cluster_id, pool):
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return err  # lgtm[py/reflected-xss]
    if not _valid_pool(pool):
        # snyk:ignore:python/XSS
        return jsonify({"error": "Invalid pool name"}), 400  # lgtm[py/reflected-xss]  # snyk:ignore:python/XSS

    manager, error = get_connected_manager(cluster_id)
    if error:
        return error  # lgtm[py/reflected-xss]

    node, node_err = _get_any_online_node(manager)
    if node_err:
        return node_err  # lgtm[py/reflected-xss]
    node_ip = _resolve_node_ip(manager, node)

    data, cmd_err = _rbd_cmd(manager, node_ip, ["mirror", "snapshot", "schedule", "list", "--pool", pool])
    if cmd_err:
        return cmd_err  # lgtm[py/reflected-xss]
    # snyk:ignore:python/XSS
    return jsonify(data if isinstance(data, list) else [])  # lgtm[py/reflected-xss]  # snyk:ignore:python/XSS


@bp.route("/api/clusters/<cluster_id>/ceph/mirror/pool/<pool>/schedule", methods=["POST"])
@require_auth(perms=["ceph.manage"])
def add_mirror_schedule(cluster_id, pool):
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return err  # lgtm[py/reflected-xss]
    if not _valid_pool(pool):
        # snyk:ignore:python/XSS
        return jsonify({"error": "Invalid pool name"}), 400  # lgtm[py/reflected-xss]  # snyk:ignore:python/XSS

    manager, error = get_connected_manager(cluster_id)
    if error:
        return error  # lgtm[py/reflected-xss]

    body = request.json or {}
    interval = body.get("interval", "")
    if not _SCHED_RE.match(interval):
        # snyk:ignore:python/XSS
        return jsonify({
            "error": "Invalid interval format (e.g. 5m, 1h, 1d)"
        }), 400  # lgtm[py/reflected-xss]  # snyk:ignore:python/XSS

    node, node_err = _get_any_online_node(manager)
    if node_err:
        return node_err  # lgtm[py/reflected-xss]
    node_ip = _resolve_node_ip(manager, node)

    data, cmd_err = _rbd_cmd(
        manager, node_ip, ["mirror", "snapshot", "schedule", "add", "--pool", pool, interval], expect_json=False
    )
    if cmd_err:
        return cmd_err  # lgtm[py/reflected-xss]

    usr = getattr(request, "session", {}).get("user", "system")
    log_audit(usr, "ceph.mirror.schedule.add", f"Added schedule {interval} on pool {pool}", cluster=manager.config.name)
    # snyk:ignore:python/XSS
    return jsonify({"success": True})  # lgtm[py/reflected-xss]  # snyk:ignore:python/XSS


@bp.route("/api/clusters/<cluster_id>/ceph/mirror/pool/<pool>/schedule", methods=["DELETE"])
@require_auth(perms=["ceph.manage"])
def remove_mirror_schedule(cluster_id, pool):
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return err  # lgtm[py/reflected-xss]
    if not _valid_pool(pool):
        # snyk:ignore:python/XSS
        return jsonify({"error": "Invalid pool name"}), 400  # lgtm[py/reflected-xss]  # snyk:ignore:python/XSS

    manager, error = get_connected_manager(cluster_id)
    if error:
        return error  # lgtm[py/reflected-xss]

    body = request.json or {}
    interval = body.get("interval", "")
    if not _SCHED_RE.match(interval):
        # snyk:ignore:python/XSS
        return jsonify({
            "error": "Invalid interval format (e.g. 5m, 1h, 1d)"
        }), 400  # lgtm[py/reflected-xss]  # snyk:ignore:python/XSS

    node, node_err = _get_any_online_node(manager)
    if node_err:
        return node_err  # lgtm[py/reflected-xss]
    node_ip = _resolve_node_ip(manager, node)

    data, cmd_err = _rbd_cmd(
        manager, node_ip, ["mirror", "snapshot", "schedule", "remove", "--pool", pool, interval], expect_json=False
    )
    if cmd_err:
        return cmd_err  # lgtm[py/reflected-xss]

    usr = getattr(request, "session", {}).get("user", "system")
    log_audit(
        usr, "ceph.mirror.schedule.remove", f"Removed schedule {interval} from pool {pool}", cluster=manager.config.name
    )
    # snyk:ignore:python/XSS
    return jsonify({"success": True})  # lgtm[py/reflected-xss]  # snyk:ignore:python/XSS
