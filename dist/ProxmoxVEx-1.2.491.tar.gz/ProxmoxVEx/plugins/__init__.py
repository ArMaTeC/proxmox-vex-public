# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/plugins/__init__.py
# Project:     ProxmoxVEx
# Version:     1.2.479
# Build:       2026.09.20
# Description: Plugin loading helpers with license tier enforcement.
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-20
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Plugin loading helpers with license tier enforcement."""

import re

from ProxmoxVEx.core.db import get_db
from ProxmoxVEx.services.licensing import LicensingService

# Spec 092/US053: manifest contract enforced at discovery so malformed or
# hostile manifests fail closed with field-level errors. Hand-rolled (the
# codebase does not depend on jsonschema). `id` allows underscores because
# shipped plugins (client_portal, hello_world, status_page) use them.
_ID_RE = re.compile(r"^[a-z0-9_-]+$")
_VERSION_RE = re.compile(r"^\d+\.\d+\.\d+$")

_MANIFEST_REQUIRED = ("id", "name", "version")
_MANIFEST_STRING_FIELDS = (
    "author",
    "description",
    "category",
    "frontend_route",
    "min_ProxmoxVEx",
    "min_app_version",
    "min_license_tier",
    "entrypoint",
)
_MANIFEST_BOOL_FIELDS = ("has_frontend", "enabled", "trusted")


def validate_manifest(manifest: dict) -> list[str]:
    """Return field-level validation errors for a plugin manifest (empty = valid)."""
    if not isinstance(manifest, dict):
        return ["manifest: expected a JSON object"]
    errors: list[str] = []
    for field in _MANIFEST_REQUIRED:
        if field not in manifest:
            errors.append(f"{field}: required field is missing")
            continue
        if not isinstance(manifest[field], str) or not manifest[field].strip():
            errors.append(f"{field}: must be a non-empty string")
    if isinstance(manifest.get("id"), str) and not _ID_RE.match(manifest["id"]):
        errors.append("id: must match ^[a-z0-9_-]+$")
    if isinstance(manifest.get("version"), str) and not _VERSION_RE.match(manifest["version"]):
        errors.append("version: must be semantic MAJOR.MINOR.PATCH")
    if "permissions" in manifest:
        perms = manifest["permissions"]
        if not isinstance(perms, list) or not all(isinstance(p, str) for p in perms):
            errors.append("permissions: must be an array of strings")
    for field in _MANIFEST_STRING_FIELDS:
        if field in manifest and not isinstance(manifest[field], str):
            errors.append(f"{field}: must be a string")
    for field in _MANIFEST_BOOL_FIELDS:
        if field in manifest and not isinstance(manifest[field], bool):
            errors.append(f"{field}: must be a boolean")
    return errors


def can_use_plugin(plugin_slug: str) -> bool:
    """Return whether the active license allows this plugin."""
    return LicensingService().can_use_plugin(get_db(), plugin_slug)
