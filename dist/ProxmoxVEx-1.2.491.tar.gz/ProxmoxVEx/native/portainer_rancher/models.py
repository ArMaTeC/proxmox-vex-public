# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/native/portainer_rancher/models.py
# Project:     ProxmoxVEx
# Version:     1.2.479
# Build:       2026.09.20
# Description: Portainer + Rancher native integration data models and...
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-20
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Portainer + Rancher native integration data models and SQLite persistence.

Implements the data model from specs/006-portainer-rancher/data-model.md:
two connection tables (Portainer / Rancher), per-manager inventory caches
(endpoints, stacks, containers, images, clusters, projects, workloads,
catalog apps), the ``unified_workloads`` inventory, manager alerts,
operations and resource links.

Credentials are stored as encrypted references via ``get_db()._encrypt``;
plaintext tokens are never persisted.
"""

import json
import logging
import re
import uuid as uuid_mod
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from ProxmoxVEx.core.db import get_db

log = logging.getLogger("native.portainer_rancher.models")

CONNECTIVITY_STATES = {"unknown", "reachable", "degraded", "unreachable"}
PORTAINER_AUTH_TYPES = {"api_token", "oauth"}
RANCHER_AUTH_TYPES = {"api_token", "bearer"}
ENDPOINT_TYPES = {"docker", "swarm", "kubernetes", "edge_agent", "unknown"}
CONTAINER_ACTIONS = {"start", "stop", "restart", "pause", "unpause", "kill"}
STACK_ACTIONS = {"start", "stop"}
ALERT_CATEGORIES = {
    "container_health",
    "endpoint_down",
    "heartbeat_missed",
    "cluster_error",
    "cluster_provisioning_stuck",
    "manager_unreachable",
}
ALERT_SEVERITIES = {"critical", "warning", "info"}
WORKLOAD_KINDS = {
    "container", "service", "deployment", "statefulset", "daemonset",
    "pod", "job", "cronjob", "replicaset", "unknown",
}

# Accepts http(s) URLs plus the ``mock://`` test transport scheme used by the
# built-in deterministic mock sessions in the connectors.
_RX_URL = re.compile(r"^(https?|mock)://[^\s]+$", re.IGNORECASE)


# --- dataclasses -------------------------------------------------------------


@dataclass
class PortainerConnection:
    id: Optional[int] = None
    display_name: str = ""
    base_url: str = ""
    tls_verify: bool = True
    auth_type: str = "api_token"
    credential_ref: str = ""
    edition: str = ""
    version: str = ""
    proxmox_cluster_id: str = ""
    connectivity_status: str = "unknown"
    scope_limited: bool = False
    last_successful_contact: Optional[str] = None
    last_error: str = ""
    created_at: Optional[str] = None
    updated_at: Optional[str] = None

    def to_dict(self, include_credentials: bool = False) -> Dict[str, Any]:
        data = asdict(self)
        if not include_credentials:
            data.pop("credential_ref", None)
        return data


@dataclass
class RancherConnection:
    id: Optional[int] = None
    display_name: str = ""
    server_url: str = ""
    tls_verify: bool = True
    auth_type: str = "api_token"
    credential_ref: str = ""
    version: str = ""
    proxmox_cluster_id: str = ""
    connectivity_status: str = "unknown"
    scope_limited: bool = False
    last_successful_contact: Optional[str] = None
    last_error: str = ""
    created_at: Optional[str] = None
    updated_at: Optional[str] = None

    def to_dict(self, include_credentials: bool = False) -> Dict[str, Any]:
        data = asdict(self)
        if not include_credentials:
            data.pop("credential_ref", None)
        return data


@dataclass
class PortainerEndpoint:
    id: Optional[int] = None
    connection_id: int = 0
    endpoint_id: int = 0
    name: str = ""
    endpoint_type: str = "unknown"
    status: str = "unknown"
    url: str = ""
    engine_id: str = ""
    last_heartbeat: Optional[str] = None
    container_count: int = 0
    tags: str = "[]"
    groups: str = "[]"
    last_seen: Optional[str] = None


@dataclass
class PortainerStack:
    id: Optional[int] = None
    connection_id: int = 0
    endpoint_pk: int = 0
    stack_id: int = 0
    name: str = ""
    status: str = "unknown"
    source: str = "unknown"
    services: str = "[]"
    last_seen: Optional[str] = None


@dataclass
class PortainerContainer:
    id: Optional[int] = None
    connection_id: int = 0
    endpoint_pk: int = 0
    container_id: str = ""
    name: str = ""
    image: str = ""
    state: str = "unknown"
    status_text: str = ""
    health: str = "unknown"
    restart_count: int = 0
    stack_name: str = ""
    node_name: str = ""
    ports: str = "[]"
    labels: str = "{}"
    created: Optional[str] = None
    last_seen: Optional[str] = None


@dataclass
class PortainerImage:
    id: Optional[int] = None
    connection_id: int = 0
    endpoint_pk: int = 0
    image_id: str = ""
    tags: str = "[]"
    size_bytes: int = 0
    in_use: bool = False
    last_seen: Optional[str] = None


@dataclass
class RancherCluster:
    id: Optional[int] = None
    connection_id: int = 0
    cluster_id: str = ""
    name: str = ""
    kubernetes_version: str = ""
    provider: str = ""
    state: str = "unknown"
    state_message: str = ""
    api_endpoint: str = ""
    node_count: int = 0
    direct_k8s_connection_id: str = ""
    last_seen: Optional[str] = None


@dataclass
class RancherProject:
    id: Optional[int] = None
    connection_id: int = 0
    cluster_pk: int = 0
    project_id: str = ""
    name: str = ""
    namespaces: str = "[]"
    last_seen: Optional[str] = None


@dataclass
class RancherWorkload:
    id: Optional[int] = None
    connection_id: int = 0
    cluster_pk: int = 0
    project_pk: int = 0
    workload_id: str = ""
    name: str = ""
    kind: str = "unknown"
    namespace: str = ""
    state: str = "unknown"
    image: str = ""
    replicas: int = 0
    ready_replicas: int = 0
    restart_count: int = 0
    health: str = "unknown"
    last_seen: Optional[str] = None


@dataclass
class RancherCatalogApp:
    id: Optional[int] = None
    connection_id: int = 0
    cluster_pk: int = 0
    app_id: str = ""
    name: str = ""
    namespace: str = ""
    chart_version: str = ""
    app_version: str = ""
    status: str = "unknown"
    last_seen: Optional[str] = None


@dataclass
class UnifiedWorkload:
    id: Optional[int] = None
    global_id: str = ""
    name: str = ""
    kind: str = "unknown"
    state: str = "unknown"
    image: str = ""
    source_platform: str = "unknown"
    source_manager: str = "direct"
    connection_id: Optional[int] = None
    endpoint_id: Optional[int] = None
    cluster_id: Optional[int] = None
    namespace: str = ""
    health: str = "unknown"
    restart_count: int = 0
    linked: bool = False
    last_sync: Optional[str] = None


@dataclass
class Alert:
    id: Optional[int] = None
    manager_type: str = "portainer"
    category: str = "container_health"
    connection_id: int = 0
    entity_type: str = ""
    entity_id: str = ""
    severity: str = "warning"
    message: str = ""
    raised_time: Optional[str] = None
    resolved_time: Optional[str] = None


@dataclass
class Operation:
    id: Optional[int] = None
    operation_id: str = ""
    manager_type: str = "portainer"
    connection_id: int = 0
    action: str = ""
    target: str = ""
    status: str = "pending"
    result: str = ""
    error: str = ""
    actor: str = ""
    created_at: Optional[str] = None
    finished_at: Optional[str] = None


@dataclass
class ResourceLink:
    id: Optional[int] = None
    local_type: str = ""
    local_id: str = ""
    remote_type: str = ""
    remote_id: str = ""
    link_type: str = "automatic"
    match_confidence: float = 0.0
    created_at: Optional[str] = None


# --- helpers -----------------------------------------------------------------


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _table_columns(conn: Any) -> set:
    rows = conn.execute(
        "SELECT name FROM sqlite_master WHERE type='table'"
    ).fetchall()
    return {r["name"] if isinstance(r, dict) or hasattr(r, "keys") else r[0] for r in rows}


def table_exists(name: str) -> bool:
    try:
        row = get_db().query_one(
            "SELECT name FROM sqlite_master WHERE type='table' AND name = ?", (name,)
        )
        return bool(row)
    except Exception:
        return False


def ensure_tables(conn: Any) -> None:
    """Create all Portainer/Rancher integration tables if they do not exist."""
    cursor = conn.cursor()
    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS portainer_connections (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            display_name TEXT NOT NULL,
            base_url TEXT NOT NULL,
            tls_verify INTEGER DEFAULT 1,
            auth_type TEXT NOT NULL DEFAULT 'api_token',
            credential_ref TEXT NOT NULL,
            edition TEXT,
            version TEXT,
            proxmox_cluster_id TEXT,
            connectivity_status TEXT DEFAULT 'unknown',
            scope_limited INTEGER DEFAULT 0,
            last_successful_contact TEXT,
            last_error TEXT,
            created_at TEXT,
            updated_at TEXT,
            UNIQUE(display_name)
        )
        """
    )
    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS rancher_connections (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            display_name TEXT NOT NULL,
            server_url TEXT NOT NULL,
            tls_verify INTEGER DEFAULT 1,
            auth_type TEXT NOT NULL DEFAULT 'api_token',
            credential_ref TEXT NOT NULL,
            version TEXT,
            proxmox_cluster_id TEXT,
            connectivity_status TEXT DEFAULT 'unknown',
            scope_limited INTEGER DEFAULT 0,
            last_successful_contact TEXT,
            last_error TEXT,
            created_at TEXT,
            updated_at TEXT,
            UNIQUE(display_name)
        )
        """
    )
    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS portainer_endpoints (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            connection_id INTEGER NOT NULL,
            endpoint_id INTEGER NOT NULL,
            name TEXT NOT NULL,
            endpoint_type TEXT DEFAULT 'unknown',
            status TEXT DEFAULT 'unknown',
            url TEXT,
            engine_id TEXT,
            last_heartbeat TEXT,
            container_count INTEGER DEFAULT 0,
            tags TEXT DEFAULT '[]',
            groups TEXT DEFAULT '[]',
            last_seen TEXT,
            UNIQUE(connection_id, endpoint_id)
        )
        """
    )
    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS portainer_stacks (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            connection_id INTEGER NOT NULL,
            endpoint_pk INTEGER NOT NULL,
            stack_id INTEGER NOT NULL,
            name TEXT NOT NULL,
            status TEXT DEFAULT 'unknown',
            source TEXT DEFAULT 'unknown',
            services TEXT DEFAULT '[]',
            last_seen TEXT,
            UNIQUE(connection_id, endpoint_pk, stack_id)
        )
        """
    )
    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS portainer_containers (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            connection_id INTEGER NOT NULL,
            endpoint_pk INTEGER NOT NULL,
            container_id TEXT NOT NULL,
            name TEXT NOT NULL,
            image TEXT,
            state TEXT DEFAULT 'unknown',
            status_text TEXT,
            health TEXT DEFAULT 'unknown',
            restart_count INTEGER DEFAULT 0,
            stack_name TEXT,
            node_name TEXT,
            ports TEXT DEFAULT '[]',
            labels TEXT DEFAULT '{}',
            created TEXT,
            last_seen TEXT,
            UNIQUE(connection_id, endpoint_pk, container_id)
        )
        """
    )
    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS portainer_images (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            connection_id INTEGER NOT NULL,
            endpoint_pk INTEGER NOT NULL,
            image_id TEXT NOT NULL,
            tags TEXT DEFAULT '[]',
            size_bytes INTEGER DEFAULT 0,
            in_use INTEGER DEFAULT 0,
            last_seen TEXT,
            UNIQUE(connection_id, endpoint_pk, image_id)
        )
        """
    )
    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS rancher_clusters (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            connection_id INTEGER NOT NULL,
            cluster_id TEXT NOT NULL,
            name TEXT NOT NULL,
            kubernetes_version TEXT,
            provider TEXT,
            state TEXT DEFAULT 'unknown',
            state_message TEXT,
            api_endpoint TEXT,
            node_count INTEGER DEFAULT 0,
            direct_k8s_connection_id TEXT,
            last_seen TEXT,
            UNIQUE(connection_id, cluster_id)
        )
        """
    )
    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS rancher_projects (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            connection_id INTEGER NOT NULL,
            cluster_pk INTEGER NOT NULL,
            project_id TEXT NOT NULL,
            name TEXT NOT NULL,
            namespaces TEXT DEFAULT '[]',
            last_seen TEXT,
            UNIQUE(connection_id, cluster_pk, project_id)
        )
        """
    )
    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS rancher_workloads (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            connection_id INTEGER NOT NULL,
            cluster_pk INTEGER NOT NULL,
            project_pk INTEGER DEFAULT 0,
            workload_id TEXT NOT NULL,
            name TEXT NOT NULL,
            kind TEXT DEFAULT 'unknown',
            namespace TEXT,
            state TEXT DEFAULT 'unknown',
            image TEXT,
            replicas INTEGER DEFAULT 0,
            ready_replicas INTEGER DEFAULT 0,
            restart_count INTEGER DEFAULT 0,
            health TEXT DEFAULT 'unknown',
            last_seen TEXT,
            UNIQUE(connection_id, cluster_pk, workload_id)
        )
        """
    )
    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS rancher_catalog_apps (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            connection_id INTEGER NOT NULL,
            cluster_pk INTEGER NOT NULL,
            app_id TEXT NOT NULL,
            name TEXT NOT NULL,
            namespace TEXT,
            chart_version TEXT,
            app_version TEXT,
            status TEXT DEFAULT 'unknown',
            last_seen TEXT,
            UNIQUE(connection_id, cluster_pk, app_id)
        )
        """
    )
    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS unified_workloads (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            global_id TEXT NOT NULL UNIQUE,
            name TEXT NOT NULL,
            kind TEXT DEFAULT 'unknown',
            state TEXT DEFAULT 'unknown',
            image TEXT,
            source_platform TEXT DEFAULT 'unknown',
            source_manager TEXT DEFAULT 'direct',
            connection_id INTEGER,
            endpoint_id INTEGER,
            cluster_id INTEGER,
            namespace TEXT,
            health TEXT DEFAULT 'unknown',
            restart_count INTEGER DEFAULT 0,
            linked INTEGER DEFAULT 0,
            last_sync TEXT
        )
        """
    )
    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS portainer_rancher_alerts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            manager_type TEXT NOT NULL,
            category TEXT NOT NULL,
            connection_id INTEGER NOT NULL,
            entity_type TEXT,
            entity_id TEXT,
            severity TEXT DEFAULT 'warning',
            message TEXT,
            raised_time TEXT,
            resolved_time TEXT,
            UNIQUE(manager_type, category, connection_id, entity_id)
        )
        """
    )
    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS portainer_rancher_operations (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            operation_id TEXT NOT NULL UNIQUE,
            manager_type TEXT NOT NULL,
            connection_id INTEGER,
            action TEXT NOT NULL,
            target TEXT,
            status TEXT DEFAULT 'pending',
            result TEXT,
            error TEXT,
            actor TEXT,
            created_at TEXT,
            finished_at TEXT
        )
        """
    )
    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS portainer_rancher_resource_links (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            local_type TEXT NOT NULL,
            local_id TEXT NOT NULL,
            remote_type TEXT NOT NULL,
            remote_id TEXT NOT NULL,
            link_type TEXT DEFAULT 'automatic',
            match_confidence REAL DEFAULT 0.0,
            created_at TEXT,
            UNIQUE(local_type, local_id, remote_type, remote_id)
        )
        """
    )
    for index in (
        "CREATE INDEX IF NOT EXISTS idx_pr_endpoints_conn ON portainer_endpoints(connection_id)",
        "CREATE INDEX IF NOT EXISTS idx_pr_containers_ep ON portainer_containers(endpoint_pk)",
        "CREATE INDEX IF NOT EXISTS idx_pr_clusters_conn ON rancher_clusters(connection_id)",
        "CREATE INDEX IF NOT EXISTS idx_pr_workloads_cluster ON rancher_workloads(cluster_pk)",
        "CREATE INDEX IF NOT EXISTS idx_unified_state ON unified_workloads(state)",
        "CREATE INDEX IF NOT EXISTS idx_unified_source ON unified_workloads(source_manager)",
        "CREATE INDEX IF NOT EXISTS idx_pr_alerts_conn ON portainer_rancher_alerts(connection_id)",
    ):
        cursor.execute(index)
    conn.commit()


# --- credentials -------------------------------------------------------------


def _encrypt_credential(credential: Dict[str, Any]) -> str:
    if not credential:
        return ""
    payload = json.dumps(credential)
    return get_db()._encrypt(payload)


def _decrypt_credential(ref: str) -> Dict[str, Any]:
    if not ref:
        return {}
    try:
        return json.loads(get_db()._decrypt(ref))
    except Exception as e:
        log.error("[portainer_rancher] Failed to decrypt credential reference: %s", e)
        return {}


def _mask_connection(row_dict: Dict[str, Any]) -> Dict[str, Any]:
    row_dict.pop("credential_ref", None)
    row_dict["tls_verify"] = bool(row_dict.get("tls_verify", 1))
    row_dict["scope_limited"] = bool(row_dict.get("scope_limited", 0))
    return row_dict


# --- validation --------------------------------------------------------------


def _validate_common(data: Dict[str, Any], url_field: str, auth_types: set) -> Dict[str, str]:
    errors: Dict[str, str] = {}
    name = (data.get("display_name") or "").strip()
    if not name or len(name) > 128:
        errors["display_name"] = "Required and must be <= 128 characters"
    url = (data.get(url_field) or "").strip()
    if not url or not _RX_URL.match(url):
        errors[url_field] = "Required and must be a valid http(s) URL"
    auth_type = data.get("auth_type") or next(iter(sorted(auth_types)))
    if auth_type not in auth_types:
        errors["auth_type"] = f"Must be one of {sorted(auth_types)}"
    cred = data.get("credential") or {}
    # OAuth-capable credentials (Portainer) may use username/password instead.
    if not cred.get("token") and not (
        auth_type == "oauth" and cred.get("username") and cred.get("password")
    ):
        errors["credential.token"] = "API token required"
    # FR-004: TLS verification is on by default; disabling it must be an
    # explicit, acknowledged opt-in.
    if not data.get("tls_verify", True) and not data.get("tls_insecure_ack"):
        errors["tls_verify"] = "Disabling TLS verification requires tls_insecure_ack"
    return errors


def validate_portainer_input(data: Dict[str, Any]) -> Dict[str, str]:
    return _validate_common(data, "base_url", PORTAINER_AUTH_TYPES)


def validate_rancher_input(data: Dict[str, Any]) -> Dict[str, str]:
    return _validate_common(data, "server_url", RANCHER_AUTH_TYPES)


# --- generic row helpers -----------------------------------------------------

_ALLOWED_TABLES = {
    "portainer_connections", "rancher_connections",
    "portainer_endpoints", "portainer_stacks", "portainer_containers",
    "portainer_images", "rancher_clusters", "rancher_projects",
    "rancher_workloads", "rancher_catalog_apps", "unified_workloads",
    "portainer_rancher_alerts", "portainer_rancher_operations",
    "portainer_rancher_resource_links",
}


def _check_table(table: str) -> str:
    if table not in _ALLOWED_TABLES:
        raise ValueError(f"table {table!r} not allowed")
    return table


def _upsert(table: str, conflict: List[str], fields: Dict[str, Any]) -> int:
    """INSERT ... ON CONFLICT upsert keyed on ``conflict`` columns; returns row id."""
    _check_table(table)
    db = get_db()
    cols = list(fields.keys())
    placeholders = ", ".join(["?"] * len(cols))
    conflict_cols = ", ".join(conflict)
    updates = ", ".join(f"{c} = excluded.{c}" for c in cols if c not in conflict)
    sql = (
        f"INSERT INTO {table} ({', '.join(cols)}) VALUES ({placeholders}) "  # nosec: B608
        f"ON CONFLICT({conflict_cols}) DO UPDATE SET {updates}"
    )
    db.execute(sql, tuple(fields.values()))
    where = " AND ".join(f"{c} = ?" for c in conflict)
    row = db.query_one(
        f"SELECT id FROM {table} WHERE {where} ORDER BY id DESC LIMIT 1",  # nosec: B608
        tuple(fields[c] for c in conflict),
    )
    return int(row["id"]) if row else 0


def list_rows(table: str, connection_id: Optional[int] = None, **filters: Any) -> List[Dict[str, Any]]:
    _check_table(table)
    sql = f"SELECT * FROM {table}"  # nosec: B608
    params: List[Any] = []
    clauses: List[str] = []
    if connection_id is not None:
        clauses.append("connection_id = ?")
        params.append(connection_id)
    for key, value in filters.items():
        if not re.match(r"^[a-z_]+$", key):
            raise ValueError(f"invalid filter column {key!r}")
        clauses.append(f"{key} = ?")
        params.append(value)
    if clauses:
        sql += " WHERE " + " AND ".join(clauses)
    sql += " ORDER BY id"
    return [dict(r) for r in get_db().query(sql, tuple(params))]


def get_row(table: str, row_id: int) -> Optional[Dict[str, Any]]:
    _check_table(table)
    row = get_db().query_one(f"SELECT * FROM {table} WHERE id = ?", (row_id,))  # nosec: B608
    return dict(row) if row else None


def prune_stale(table: str, marker: str, connection_id: Optional[int] = None, **filters: Any) -> int:
    """Delete cached rows not refreshed in this cycle (last_seen < marker)."""
    _check_table(table)
    sql = f"DELETE FROM {table} WHERE last_seen < ?"  # nosec: B608
    params: List[Any] = [marker]
    if connection_id is not None:
        sql += " AND connection_id = ?"
        params.append(connection_id)
    for key, value in filters.items():
        if not re.match(r"^[a-z_]+$", key):
            raise ValueError(f"invalid filter column {key!r}")
        sql += f" AND {key} = ?"
        params.append(value)
    cur = get_db().execute(sql, tuple(params))
    return getattr(cur, "rowcount", 0) or 0


# --- Portainer connections ---------------------------------------------------


def create_portainer_connection(data: Dict[str, Any]) -> PortainerConnection:
    db = get_db()
    now = _now_iso()
    ref = _encrypt_credential(data.get("credential") or {})
    db.execute(
        """
        INSERT INTO portainer_connections
        (display_name, base_url, tls_verify, auth_type, credential_ref,
         edition, version, proxmox_cluster_id, connectivity_status,
         scope_limited, last_successful_contact, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (
            data["display_name"].strip(),
            data["base_url"].strip().rstrip("/"),
            1 if data.get("tls_verify", True) else 0,
            data.get("auth_type", "api_token"),
            ref,
            data.get("edition", ""),
            data.get("version", ""),
            str(data.get("proxmox_cluster_id", "")),
            data.get("connectivity_status", "unknown"),
            0,
            data.get("last_successful_contact"),
            now,
            now,
        ),
    )
    row = db.query_one(
        "SELECT * FROM portainer_connections WHERE rowid = last_insert_rowid()"
    )
    conn = _row_to_portainer(row)
    assert conn is not None
    return conn


def _row_to_portainer(row: Optional[Any]) -> Optional[PortainerConnection]:
    if not row:
        return None
    data = dict(row)
    data["tls_verify"] = bool(data.get("tls_verify", 1))
    data["scope_limited"] = bool(data.get("scope_limited", 0))
    fields = PortainerConnection.__dataclass_fields__
    return PortainerConnection(**{k: v for k, v in data.items() if k in fields})


def get_portainer_connection(conn_id: int) -> Optional[PortainerConnection]:
    row = get_db().query_one(
        "SELECT * FROM portainer_connections WHERE id = ?", (conn_id,)
    )
    return _row_to_portainer(row)


def list_portainer_connections(cluster_id: Optional[str] = None) -> List[PortainerConnection]:
    db = get_db()
    if cluster_id:
        rows = db.query(
            "SELECT * FROM portainer_connections WHERE proxmox_cluster_id = ?",
            (cluster_id,),
        )
    else:
        rows = db.query("SELECT * FROM portainer_connections ORDER BY display_name")
    return [c for c in (_row_to_portainer(r) for r in rows) if c is not None]


def update_portainer_status(
    conn_id: int,
    status: str,
    last_contact: Optional[str] = None,
    version: Optional[str] = None,
    edition: Optional[str] = None,
    error: Optional[str] = None,
    scope_limited: Optional[bool] = None,
) -> None:
    get_db().execute(
        """
        UPDATE portainer_connections
        SET connectivity_status = ?, last_successful_contact = ?,
            version = COALESCE(?, version), edition = COALESCE(?, edition),
            scope_limited = COALESCE(?, scope_limited),
            last_error = ?, updated_at = ?
        WHERE id = ?
        """,
        (
            status,
            last_contact,
            version,
            edition,
            None if scope_limited is None else (1 if scope_limited else 0),
            error or "",
            _now_iso(),
            conn_id,
        ),
    )


def delete_portainer_connection(conn_id: int) -> bool:
    db = get_db()
    db.execute(
        "DELETE FROM portainer_containers WHERE endpoint_pk IN "
        "(SELECT id FROM portainer_endpoints WHERE connection_id = ?)",
        (conn_id,),
    )
    db.execute(
        "DELETE FROM portainer_stacks WHERE endpoint_pk IN "
        "(SELECT id FROM portainer_endpoints WHERE connection_id = ?)",
        (conn_id,),
    )
    db.execute(
        "DELETE FROM portainer_images WHERE endpoint_pk IN "
        "(SELECT id FROM portainer_endpoints WHERE connection_id = ?)",
        (conn_id,),
    )
    for table, col in (
        ("portainer_endpoints", "connection_id"),
        ("portainer_stacks", "connection_id"),
        ("portainer_containers", "connection_id"),
        ("portainer_images", "connection_id"),
        ("unified_workloads", "connection_id"),
        ("portainer_rancher_alerts", "connection_id"),
        ("portainer_rancher_operations", "connection_id"),
        ("portainer_connections", "id"),
    ):
        db.execute(
            f"DELETE FROM {table} WHERE {col} = ? AND "  # nosec: B608
            + (
                "source_manager = 'portainer'"
                if table == "unified_workloads"
                else "manager_type = 'portainer'"
                if table in ("portainer_rancher_alerts", "portainer_rancher_operations")
                else "1=1"
            ),
            (conn_id,),
        )
    return True


def get_portainer_credential(conn_id: int) -> Dict[str, Any]:
    conn = get_portainer_connection(conn_id)
    return _decrypt_credential(conn.credential_ref) if conn else {}


# --- Rancher connections -----------------------------------------------------


def create_rancher_connection(data: Dict[str, Any]) -> RancherConnection:
    db = get_db()
    now = _now_iso()
    ref = _encrypt_credential(data.get("credential") or {})
    db.execute(
        """
        INSERT INTO rancher_connections
        (display_name, server_url, tls_verify, auth_type, credential_ref,
         version, proxmox_cluster_id, connectivity_status, scope_limited,
         last_successful_contact, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (
            data["display_name"].strip(),
            data["server_url"].strip().rstrip("/"),
            1 if data.get("tls_verify", True) else 0,
            data.get("auth_type", "api_token"),
            ref,
            data.get("version", ""),
            str(data.get("proxmox_cluster_id", "")),
            data.get("connectivity_status", "unknown"),
            0,
            data.get("last_successful_contact"),
            now,
            now,
        ),
    )
    row = db.query_one(
        "SELECT * FROM rancher_connections WHERE rowid = last_insert_rowid()"
    )
    conn = _row_to_rancher(row)
    assert conn is not None
    return conn


def _row_to_rancher(row: Optional[Any]) -> Optional[RancherConnection]:
    if not row:
        return None
    data = dict(row)
    data["tls_verify"] = bool(data.get("tls_verify", 1))
    data["scope_limited"] = bool(data.get("scope_limited", 0))
    fields = RancherConnection.__dataclass_fields__
    return RancherConnection(**{k: v for k, v in data.items() if k in fields})


def get_rancher_connection(conn_id: int) -> Optional[RancherConnection]:
    row = get_db().query_one(
        "SELECT * FROM rancher_connections WHERE id = ?", (conn_id,)
    )
    return _row_to_rancher(row)


def list_rancher_connections(cluster_id: Optional[str] = None) -> List[RancherConnection]:
    db = get_db()
    if cluster_id:
        rows = db.query(
            "SELECT * FROM rancher_connections WHERE proxmox_cluster_id = ?",
            (cluster_id,),
        )
    else:
        rows = db.query("SELECT * FROM rancher_connections ORDER BY display_name")
    return [c for c in (_row_to_rancher(r) for r in rows) if c is not None]


def update_rancher_status(
    conn_id: int,
    status: str,
    last_contact: Optional[str] = None,
    version: Optional[str] = None,
    error: Optional[str] = None,
    scope_limited: Optional[bool] = None,
) -> None:
    get_db().execute(
        """
        UPDATE rancher_connections
        SET connectivity_status = ?, last_successful_contact = ?,
            version = COALESCE(?, version),
            scope_limited = COALESCE(?, scope_limited),
            last_error = ?, updated_at = ?
        WHERE id = ?
        """,
        (
            status,
            last_contact,
            version,
            None if scope_limited is None else (1 if scope_limited else 0),
            error or "",
            _now_iso(),
            conn_id,
        ),
    )


def delete_rancher_connection(conn_id: int) -> bool:
    db = get_db()
    for child in ("rancher_projects", "rancher_workloads", "rancher_catalog_apps"):
        db.execute(
            f"DELETE FROM {child} WHERE cluster_pk IN "  # nosec: B608
            "(SELECT id FROM rancher_clusters WHERE connection_id = ?)",
            (conn_id,),
        )
    for table, col in (
        ("rancher_clusters", "connection_id"),
        ("rancher_projects", "connection_id"),
        ("rancher_workloads", "connection_id"),
        ("rancher_catalog_apps", "connection_id"),
        ("unified_workloads", "connection_id"),
        ("portainer_rancher_alerts", "connection_id"),
        ("portainer_rancher_operations", "connection_id"),
        ("rancher_connections", "id"),
    ):
        db.execute(
            f"DELETE FROM {table} WHERE {col} = ? AND "  # nosec: B608
            + (
                "source_manager = 'rancher'"
                if table == "unified_workloads"
                else "manager_type = 'rancher'"
                if table in ("portainer_rancher_alerts", "portainer_rancher_operations")
                else "1=1"
            ),
            (conn_id,),
        )
    return True


def get_rancher_credential(conn_id: int) -> Dict[str, Any]:
    conn = get_rancher_connection(conn_id)
    return _decrypt_credential(conn.credential_ref) if conn else {}


# --- inventory upserts -------------------------------------------------------


def upsert_endpoint(connection_id: int, ep: Dict[str, Any]) -> int:
    return _upsert(
        "portainer_endpoints",
        ["connection_id", "endpoint_id"],
        {
            "connection_id": connection_id,
            "endpoint_id": int(ep.get("endpoint_id", 0)),
            "name": ep.get("name", ""),
            "endpoint_type": ep.get("endpoint_type", "unknown"),
            "status": ep.get("status", "unknown"),
            "url": ep.get("url", ""),
            "engine_id": ep.get("engine_id", ""),
            "last_heartbeat": ep.get("last_heartbeat"),
            "container_count": int(ep.get("container_count", 0)),
            "tags": json.dumps(ep.get("tags") or []),
            "groups": json.dumps(ep.get("groups") or []),
            "last_seen": ep.get("last_seen") or _now_iso(),
        },
    )


def upsert_stack(connection_id: int, endpoint_pk: int, stack: Dict[str, Any]) -> int:
    return _upsert(
        "portainer_stacks",
        ["connection_id", "endpoint_pk", "stack_id"],
        {
            "connection_id": connection_id,
            "endpoint_pk": endpoint_pk,
            "stack_id": int(stack.get("stack_id", 0)),
            "name": stack.get("name", ""),
            "status": stack.get("status", "unknown"),
            "source": stack.get("source", "unknown"),
            "services": json.dumps(stack.get("services") or []),
            "last_seen": stack.get("last_seen") or _now_iso(),
        },
    )


def upsert_container(connection_id: int, endpoint_pk: int, c: Dict[str, Any]) -> int:
    return _upsert(
        "portainer_containers",
        ["connection_id", "endpoint_pk", "container_id"],
        {
            "connection_id": connection_id,
            "endpoint_pk": endpoint_pk,
            "container_id": c.get("container_id", ""),
            "name": c.get("name", ""),
            "image": c.get("image", ""),
            "state": c.get("state", "unknown"),
            "status_text": c.get("status_text", ""),
            "health": c.get("health", "unknown"),
            "restart_count": int(c.get("restart_count", 0)),
            "stack_name": c.get("stack_name", ""),
            "node_name": c.get("node_name", ""),
            "ports": json.dumps(c.get("ports") or []),
            "labels": json.dumps(c.get("labels") or {}),
            "created": c.get("created"),
            "last_seen": c.get("last_seen") or _now_iso(),
        },
    )


def upsert_image(connection_id: int, endpoint_pk: int, img: Dict[str, Any]) -> int:
    return _upsert(
        "portainer_images",
        ["connection_id", "endpoint_pk", "image_id"],
        {
            "connection_id": connection_id,
            "endpoint_pk": endpoint_pk,
            "image_id": img.get("image_id", ""),
            "tags": json.dumps(img.get("tags") or []),
            "size_bytes": int(img.get("size_bytes", 0)),
            "in_use": 1 if img.get("in_use") else 0,
            "last_seen": img.get("last_seen") or _now_iso(),
        },
    )


def upsert_cluster(connection_id: int, cl: Dict[str, Any]) -> int:
    return _upsert(
        "rancher_clusters",
        ["connection_id", "cluster_id"],
        {
            "connection_id": connection_id,
            "cluster_id": cl.get("cluster_id", ""),
            "name": cl.get("name", ""),
            "kubernetes_version": cl.get("kubernetes_version", ""),
            "provider": cl.get("provider", ""),
            "state": cl.get("state", "unknown"),
            "state_message": cl.get("state_message", ""),
            "api_endpoint": cl.get("api_endpoint", ""),
            "node_count": int(cl.get("node_count", 0)),
            "direct_k8s_connection_id": cl.get("direct_k8s_connection_id", ""),
            "last_seen": cl.get("last_seen") or _now_iso(),
        },
    )


def upsert_project(connection_id: int, cluster_pk: int, p: Dict[str, Any]) -> int:
    return _upsert(
        "rancher_projects",
        ["connection_id", "cluster_pk", "project_id"],
        {
            "connection_id": connection_id,
            "cluster_pk": cluster_pk,
            "project_id": p.get("project_id", ""),
            "name": p.get("name", ""),
            "namespaces": json.dumps(p.get("namespaces") or []),
            "last_seen": p.get("last_seen") or _now_iso(),
        },
    )


def upsert_workload(connection_id: int, cluster_pk: int, w: Dict[str, Any]) -> int:
    return _upsert(
        "rancher_workloads",
        ["connection_id", "cluster_pk", "workload_id"],
        {
            "connection_id": connection_id,
            "cluster_pk": cluster_pk,
            "project_pk": int(w.get("project_pk", 0)),
            "workload_id": w.get("workload_id", ""),
            "name": w.get("name", ""),
            "kind": w.get("kind", "unknown"),
            "namespace": w.get("namespace", ""),
            "state": w.get("state", "unknown"),
            "image": w.get("image", ""),
            "replicas": int(w.get("replicas", 0)),
            "ready_replicas": int(w.get("ready_replicas", 0)),
            "restart_count": int(w.get("restart_count", 0)),
            "health": w.get("health", "unknown"),
            "last_seen": w.get("last_seen") or _now_iso(),
        },
    )


def upsert_catalog_app(connection_id: int, cluster_pk: int, app: Dict[str, Any]) -> int:
    return _upsert(
        "rancher_catalog_apps",
        ["connection_id", "cluster_pk", "app_id"],
        {
            "connection_id": connection_id,
            "cluster_pk": cluster_pk,
            "app_id": app.get("app_id", ""),
            "name": app.get("name", ""),
            "namespace": app.get("namespace", ""),
            "chart_version": app.get("chart_version", ""),
            "app_version": app.get("app_version", ""),
            "status": app.get("status", "unknown"),
            "last_seen": app.get("last_seen") or _now_iso(),
        },
    )


# --- unified workloads -------------------------------------------------------


def upsert_unified(w: Dict[str, Any]) -> int:
    return _upsert(
        "unified_workloads",
        ["global_id"],
        {
            "global_id": w.get("global_id", ""),
            "name": w.get("name", ""),
            "kind": w.get("kind", "unknown"),
            "state": w.get("state", "unknown"),
            "image": w.get("image", ""),
            "source_platform": w.get("source_platform", "unknown"),
            "source_manager": w.get("source_manager", "direct"),
            "connection_id": w.get("connection_id"),
            "endpoint_id": w.get("endpoint_id"),
            "cluster_id": w.get("cluster_id"),
            "namespace": w.get("namespace", ""),
            "health": w.get("health", "unknown"),
            "restart_count": int(w.get("restart_count", 0)),
            "linked": 1 if w.get("linked") else 0,
            "last_sync": w.get("last_sync") or _now_iso(),
        },
    )


def clear_unified(source_manager: Optional[str] = None) -> None:
    db = get_db()
    if source_manager:
        db.execute(
            "DELETE FROM unified_workloads WHERE source_manager = ?",
            (source_manager,),
        )
    else:
        db.execute("DELETE FROM unified_workloads")


def list_unified(filters: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
    """Filtered unified inventory query (source/state/name/image)."""
    sql = "SELECT * FROM unified_workloads"
    clauses: List[str] = []
    params: List[Any] = []
    f = filters or {}
    if f.get("source"):
        clauses.append("source_manager = ?")
        params.append(f["source"])
    if f.get("state"):
        clauses.append("state = ?")
        params.append(f["state"])
    if f.get("kind"):
        clauses.append("kind = ?")
        params.append(f["kind"])
    if f.get("name"):
        clauses.append("name LIKE ?")
        params.append(f"%{f['name']}%")
    if f.get("image"):
        clauses.append("image LIKE ?")
        params.append(f"%{f['image']}%")
    if clauses:
        sql += " WHERE " + " AND ".join(clauses)
    sql += " ORDER BY name"
    return [dict(r) for r in get_db().query(sql, tuple(params))]


# --- alerts ------------------------------------------------------------------


def raise_alert(
    manager_type: str,
    category: str,
    connection_id: int,
    message: str,
    severity: str = "warning",
    entity_type: str = "",
    entity_id: str = "",
) -> None:
    db = get_db()
    existing = db.query_one(
        """
        SELECT id FROM portainer_rancher_alerts
        WHERE manager_type = ? AND category = ? AND connection_id = ?
          AND entity_id = ? AND resolved_time IS NULL
        """,
        (manager_type, category, connection_id, entity_id),
    )
    if existing:
        db.execute(
            "UPDATE portainer_rancher_alerts SET message = ?, severity = ? WHERE id = ?",
            (message, severity, existing["id"]),
        )
        return
    db.execute(
        """
        INSERT INTO portainer_rancher_alerts
        (manager_type, category, connection_id, entity_type, entity_id,
         severity, message, raised_time)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (
            manager_type,
            category,
            connection_id,
            entity_type,
            entity_id,
            severity if severity in ALERT_SEVERITIES else "warning",
            message,
            _now_iso(),
        ),
    )


def resolve_alert(
    manager_type: str, category: str, connection_id: int, entity_id: str = ""
) -> None:
    get_db().execute(
        """
        UPDATE portainer_rancher_alerts SET resolved_time = ?
        WHERE manager_type = ? AND category = ? AND connection_id = ?
          AND entity_id = ? AND resolved_time IS NULL
        """,
        (_now_iso(), manager_type, category, connection_id, entity_id),
    )


def list_alerts(
    manager_type: Optional[str] = None,
    category: Optional[str] = None,
    resolved: Optional[bool] = None,
) -> List[Dict[str, Any]]:
    sql = "SELECT * FROM portainer_rancher_alerts"
    clauses: List[str] = []
    params: List[Any] = []
    if manager_type:
        clauses.append("manager_type = ?")
        params.append(manager_type)
    if category:
        clauses.append("category = ?")
        params.append(category)
    if resolved is not None:
        clauses.append("resolved_time IS " + ("NOT NULL" if resolved else "NULL"))
    if clauses:
        sql += " WHERE " + " AND ".join(clauses)
    sql += " ORDER BY raised_time DESC"
    return [dict(r) for r in get_db().query(sql, tuple(params))]


# --- operations ----------------------------------------------------------------


def create_operation(data: Dict[str, Any]) -> str:
    op_id = data.get("operation_id") or uuid_mod.uuid4().hex
    get_db().execute(
        """
        INSERT INTO portainer_rancher_operations
        (operation_id, manager_type, connection_id, action, target, status,
         result, error, actor, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (
            op_id,
            data.get("manager_type", "portainer"),
            data.get("connection_id"),
            data.get("action", ""),
            data.get("target", ""),
            data.get("status", "pending"),
            data.get("result", ""),
            data.get("error", ""),
            data.get("actor", ""),
            _now_iso(),
        ),
    )
    return op_id


def finish_operation(op_id: str, status: str, result: str = "", error: str = "") -> None:
    get_db().execute(
        """
        UPDATE portainer_rancher_operations
        SET status = ?, result = ?, error = ?, finished_at = ?
        WHERE operation_id = ?
        """,
        (status, result, error, _now_iso(), op_id),
    )


def list_operations(limit: int = 50) -> List[Dict[str, Any]]:
    rows = get_db().query(
        "SELECT * FROM portainer_rancher_operations ORDER BY id DESC LIMIT ?",
        (int(limit),),
    )
    return [dict(r) for r in rows]


# --- resource links ------------------------------------------------------------


def create_resource_link(
    local_type: str,
    local_id: str,
    remote_type: str,
    remote_id: str,
    link_type: str = "automatic",
    confidence: float = 0.0,
) -> int:
    db = get_db()
    db.execute(
        """
        INSERT INTO portainer_rancher_resource_links
        (local_type, local_id, remote_type, remote_id, link_type,
         match_confidence, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?)
        ON CONFLICT(local_type, local_id, remote_type, remote_id)
        DO UPDATE SET match_confidence = excluded.match_confidence,
                      link_type = excluded.link_type
        """,
        (
            local_type,
            str(local_id),
            remote_type,
            str(remote_id),
            link_type,
            float(confidence),
            _now_iso(),
        ),
    )
    row = db.query_one(
        """
        SELECT id FROM portainer_rancher_resource_links
        WHERE local_type = ? AND local_id = ? AND remote_type = ? AND remote_id = ?
        """,
        (local_type, str(local_id), remote_type, str(remote_id)),
    )
    return int(row["id"]) if row else 0


def list_resource_links(local_type: Optional[str] = None) -> List[Dict[str, Any]]:
    if local_type:
        rows = get_db().query(
            "SELECT * FROM portainer_rancher_resource_links WHERE local_type = ?",
            (local_type,),
        )
    else:
        rows = get_db().query("SELECT * FROM portainer_rancher_resource_links")
    return [dict(r) for r in rows]


def delete_resource_link(link_id: int) -> bool:
    get_db().execute(
        "DELETE FROM portainer_rancher_resource_links WHERE id = ?", (link_id,)
    )
    return True


def find_resource_link(local_type: str, local_id: str) -> List[Dict[str, Any]]:
    rows = get_db().query(
        """
        SELECT * FROM portainer_rancher_resource_links
        WHERE local_type = ? AND local_id = ?
        """,
        (local_type, str(local_id)),
    )
    return [dict(r) for r in rows]
