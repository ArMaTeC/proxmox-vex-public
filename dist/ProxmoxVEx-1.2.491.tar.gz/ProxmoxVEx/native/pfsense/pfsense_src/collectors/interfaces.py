# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/native/pfsense/pfsense_src/collectors/interfaces.py
# Project:     ProxmoxVEx
# Version:     1.2.479
# Build:       2026.09.20
# Description: Interface collector for pfSense — normalized to the...
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-20
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Interface collector for pfSense — normalized to the OPNsense shape."""

from __future__ import annotations

from typing import Any

from pfsense_src.client import PFsenseClient


def _unwrap(resp: Any) -> Any:
    if isinstance(resp, dict):
        return resp.get("data", resp)
    return resp


def _as_list(data: Any) -> list[dict[str, Any]]:
    if data is None:
        return []
    if isinstance(data, list):
        return [dict(item) for item in data if isinstance(item, dict)]
    if isinstance(data, dict):
        out: list[dict[str, Any]] = []
        for key, value in data.items():
            if isinstance(value, dict):
                out.append({"name": key, **value})
            else:
                out.append({"name": key, "value": value})
        return out
    return []


def _stats_map(client: PFsenseClient) -> dict[str, dict[str, Any]]:
    """interface_stats keyed by ifname; best-effort (absent on some builds)."""
    try:
        raw = _unwrap(client.interface_stats())
    except Exception:
        return {}
    out: dict[str, dict[str, Any]] = {}
    for row in _as_list(raw):
        name = str(row.get("name") or row.get("interface") or row.get("ifname") or "")
        if name:
            out[name] = row
    return out


def collect_interfaces(client: PFsenseClient) -> list[dict[str, Any]]:
    """Normalized interface rows: {name, descr, link, mac, ipaddr, ...}."""
    rows = _as_list(_unwrap(client.interface_list()))
    stats = _stats_map(client)
    out: list[dict[str, Any]] = []
    for r in rows:
        name = str(r.get("name") or r.get("if") or r.get("descr") or "")
        st = stats.get(name, {})
        out.append({
            "name": name,
            "descr": str(r.get("descr") or r.get("description") or name),
            "link": str(r.get("link") or r.get("status") or ("up" if r.get("enable") else "unknown")),
            "mac": str(r.get("mac") or r.get("macaddr") or ""),
            "ipaddr": str(r.get("ipaddr") or r.get("ip") or ""),
            "subnet": str(r.get("subnet") or r.get("mask") or ""),
            "in_kbps": st.get("in_kbps") or st.get("inbytes") or 0,
            "out_kbps": st.get("out_kbps") or st.get("outbytes") or 0,
            "mtu": r.get("mtu"),
            "raw": r,
        })
    return out
