# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/native/pfsense/pfsense_src/collectors/hasync.py
# Project:     ProxmoxVEx
# Version:     1.2.479
# Build:       2026.09.20
# Description: HA sync settings collector — reads the `hasync` config...
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-20
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""HA sync settings collector — reads the `hasync` config section plus
pfsync VIP configuration to mirror the OPNsense HASyncSnapshot shape."""

from __future__ import annotations

import logging
from typing import Any, TypedDict

from pfsense_src.client import PFsenseClient

log = logging.getLogger(__name__)


class HASyncSnapshot(TypedDict, total=False):
    enabled: bool
    sync_peer: str
    pfsync_interface: str
    pfsync_version: str
    sync_compatibility: str
    sections: list[str]


def _truthy(v: Any) -> bool:
    return str(v).strip().lower() in ("1", "true", "yes", "on", "enabled")


def collect_hasync(client: PFsenseClient) -> dict[str, Any]:
    try:
        cfg = client.config_section("hasync")
    except Exception as e:
        log.debug("hasync read failed: %s", e)
        return {"enabled": False, "sections": []}
    if not isinstance(cfg, dict):
        return {"enabled": False, "sections": []}

    peer = str(cfg.get("synchronizetoip") or cfg.get("syncpeer") or "")
    enabled = bool(peer) or _truthy(cfg.get("enablesync"))
    sync_sections = [
        k[len("synchronize"):].lower()
        for k, v in cfg.items()
        if k.startswith("synchronize") and _truthy(v) and k != "synchronizetoip"
    ]
    return {
        "enabled": enabled,
        "sync_peer": peer,
        "pfsync_interface": str(cfg.get("pfsyncinterface") or ""),
        "pfsync_version": str(cfg.get("pfsyncversion") or cfg.get("version") or ""),
        "sync_compatibility": str(cfg.get("pfsyncpeerip") or ""),
        "sections": sorted(sync_sections),
    }
