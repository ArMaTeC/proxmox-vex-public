# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/native/pfsense/pfsense_src/collectors/gateways.py
# Project:     ProxmoxVEx
# Version:     1.2.479
# Build:       2026.09.20
# Description: Gateway status collector — FauxAPI `gateway_status` →...
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-20
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Gateway status collector — FauxAPI `gateway_status` → canonical
GatewayStatus rows {name, monitor_ip, rtt_ms, loss_pct, status}."""

from __future__ import annotations

from typing import Any

from pfsense_src.client import PFsenseClient


def _unwrap(resp: Any) -> Any:
    if isinstance(resp, dict):
        return resp.get("data", resp)
    return resp


def _as_list(data: Any) -> list[dict[str, Any]]:
    if isinstance(data, list):
        return [d for d in data if isinstance(d, dict)]
    if isinstance(data, dict):
        return [{"name": k, **v} if isinstance(v, dict) else {"name": k, "status": v} for k, v in data.items()]
    return []


def _metric(v: Any) -> float:
    if v is None:
        return 0.0
    try:
        return float(str(v).rstrip("ms%"))
    except ValueError:
        return 0.0


def collect_gateways(client: PFsenseClient) -> list[dict[str, Any]]:
    rows = _as_list(_unwrap(client.gateway_status()))
    out: list[dict[str, Any]] = []
    for r in rows:
        status = str(r.get("status") or r.get("state") or "unknown").lower()
        out.append({
            "name": str(r.get("name") or r.get("gateway") or ""),
            "monitor_ip": str(r.get("monitorip") or r.get("monitor_ip") or ""),
            "rtt_ms": _metric(r.get("delay") or r.get("rtt") or r.get("rtt_ms")),
            "loss_pct": _metric(r.get("loss") or r.get("loss_pct")),
            "status": status,
            "raw": r,
        })
    return out
