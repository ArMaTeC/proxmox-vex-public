# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/native/pfsense/pfsense_src/routes/ops.py
# Project:     ProxmoxVEx
# Version:     1.2.479
# Build:       2026.09.20
# Description: Platform-ops route payloads for pfSense.
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-20
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Platform-ops route payloads for pfSense.

Destructive ops (restore, reboot, firmware) require `confirm: "<hostname>"`
in the request body (FR-017); the route also runs the step-up MFA guard via
the plugin handler before dispatching.
"""

from __future__ import annotations

import logging
from typing import Any

from pfsense_src._fwkit import ensure_fwkit_importable
from pfsense_src.client import PFsenseHost
from pfsense_src.routes._domain import make_writer
from pfsense_src.writers import OpsWriter

ensure_fwkit_importable()

from ProxmoxVEx.native.fwkit.payloads import (  # noqa: E402
    client_error_envelope,
    confirm_token_ok,
    err,
    ok,
)

log = logging.getLogger(__name__)

_DESTRUCTIVE = {"restore", "reboot", "firmware_update"}


def build_ops_payload(
    host: PFsenseHost,
    plugin_dir: str,
    body: dict[str, Any],
    *,
    actor: str = "plugin",
) -> tuple[int, dict[str, Any]]:
    writer = make_writer(OpsWriter, host, None, plugin_dir, actor)
    action = str(body.get("action", "")).lower()

    if action in _DESTRUCTIVE and not confirm_token_ok(body, host.name):
        return err(
            "confirm_required",
            f"destructive action requires confirm: \"{host.name}\"",
            400,
        )

    try:
        if action == "apply":
            result = writer.apply()
        elif action == "backup":
            out = writer.backup()
            return (200, {"ok": True, "data": out}) if out.get("ok") else err("upstream", str(out.get("detail", "backup failed")), 502)
        elif action == "list_backups":
            out = writer.list_backups()
            return ok(out)
        elif action == "restore":
            # accept both key names: shared manager sends `backup_id`.
            result = writer.restore(str(body.get("backup_file") or body.get("backup_id") or ""))
        elif action == "reboot":
            result = writer.reboot()
        elif action == "halt":
            result = writer.halt()
        elif action == "firmware_check":
            return ok(writer.firmware_check())
        elif action in ("firmware_update", "firmware_upgrade"):
            # FauxAPI has no firmware-install action — honest unsupported.
            return err("unsupported", "firmware updates are not exposed by FauxAPI; use the pfSense GUI or pkg over SSH", 400)
        else:
            return err("bad_request", "action must be one of apply|backup|list_backups|restore|reboot|halt|firmware_check|firmware_update|firmware_upgrade")
    except Exception as e:
        return client_error_envelope(e, log_label=f"pfsense ops {action}")

    d = result.to_dict()
    if not result.ok:
        code = "unsupported" if result.detail.startswith("unsupported") else "upstream"
        return err(code, result.detail or "operation failed", 502)
    return 200, {"ok": True, "data": d}
