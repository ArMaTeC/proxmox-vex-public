# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/native/pfsense/pfsense_src/routes/__init__.py
# Project:     ProxmoxVEx
# Version:     1.2.479
# Build:       2026.09.20
# Description: REST routes exposed by the pfSense plugin to the...
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-20
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""REST routes exposed by the pfSense plugin to the ProxmoxVEx dashboard."""

from .aliases import build_aliases_action_payload, build_aliases_list_payload  # noqa: F401
from .audit import build_audit_payload  # noqa: F401
from .dhcp import build_dhcp_action_payload, build_dhcp_list_payload  # noqa: F401
from .dns import build_dns_action_payload, build_dns_list_payload  # noqa: F401
from .logs import build_logs_payload  # noqa: F401
from .nat import build_nat_action_payload, build_nat_list_payload  # noqa: F401
from .network import build_network, build_network_payload  # noqa: F401
from .ops import build_ops_payload  # noqa: F401
from .overview import build_overview, build_overview_payload, build_overview_payload_cluster  # noqa: F401
from .rules import build_rules_action_payload, build_rules_list_payload  # noqa: F401
from .services import build_services_action_payload, build_services_list_payload  # noqa: F401
from .vpn import build_vpn_action_payload, build_vpn_list_payload  # noqa: F401
