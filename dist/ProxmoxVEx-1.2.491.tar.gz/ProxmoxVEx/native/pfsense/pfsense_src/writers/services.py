# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/native/pfsense/pfsense_src/writers/services.py
# Project:     ProxmoxVEx
# Version:     1.2.479
# Build:       2026.09.20
# Description: Service control for pfSense — start/stop/restart/reload...
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-20
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Service control for pfSense — start/stop/restart/reload via
`function_call` → `service_control`."""

from __future__ import annotations

import re
from dataclasses import asdict
from typing import Any

from pfsense_src._fwkit import ensure_fwkit_importable
from pfsense_src.client import PFsenseClient

ensure_fwkit_importable()

from ProxmoxVEx.native.fwkit.audit import AuditEntry, AuditLog, TimedAction, hash_payload  # noqa: E402
from ProxmoxVEx.native.fwkit.results import WriteResult  # noqa: E402

_SVC_RE = re.compile(r"^[a-z][a-z0-9_-]{0,31}$")
_ACTIONS = ("start", "stop", "restart", "reload")


class ServiceWriter:
    def __init__(self, client: PFsenseClient, audit: AuditLog, actor: str = "plugin", **_kw: Any) -> None:
        self.client = client
        self.audit = audit
        self.actor = actor

    def _record(self, action: str, service: str, result: str, t: TimedAction, detail: str = "") -> dict[str, Any]:
        entry = AuditEntry.now(
            user=self.actor,
            action=f"service.{action}",
            target=f"pfsense/service.{service}",
            host=self.client.host.name,
            result=result,
            duration_ms=t.elapsed_ms,
            detail=detail[:200],
            payload_sha256=hash_payload({"service": service, "action": action}),
        )
        try:
            self.audit.append(entry)
        except OSError as e:
            import logging

            logging.getLogger(__name__).warning("audit write failed: %s", e)
        return asdict(entry)

    def control(self, service: str, action: str) -> WriteResult:
        with TimedAction() as t:
            if action not in _ACTIONS:
                entry = self._record(action or "?", service, "error", t, f"action must be one of {_ACTIONS}")
                return WriteResult(ok=False, detail=entry["detail"], audit=entry)
            if not _SVC_RE.match(service):
                entry = self._record(action, service, "error", t, "invalid service name")
                return WriteResult(ok=False, detail=entry["detail"], audit=entry)

            try:
                self.client.function_call({
                    "function": "service_control",
                    "args": [service, "restart" if action == "reload" else action],
                })
            except Exception as e:
                entry = self._record(action, service, "error", t, str(e))
                return WriteResult(ok=False, detail=str(e), audit=entry)

        entry = self._record(action, service, "ok", t)
        return WriteResult(ok=True, uuid=service, audit=entry)
