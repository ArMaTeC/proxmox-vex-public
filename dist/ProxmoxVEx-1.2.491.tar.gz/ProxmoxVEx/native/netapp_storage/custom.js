/* --- ProxmoxVEx auto-header start ---
 * -------------------------------------------------------------------
 * File:        ProxmoxVEx/native/netapp_storage/custom.js
 * Project:     ProxmoxVEx
 * Version:     1.2.479
 * Build:       2026.09.20
 * Description: Custom JS source
 * Docs:        https://proxmoxvex.com/docs
 * Generated:   2026-09-20
 * -------------------------------------------------------------------
 * --- ProxmoxVEx auto-header end --- */

/*
 * Put any custom JavaScript overrides or helpers here.
 * This file is loaded after ui.js so you can extend or override existing behaviour.
 */
