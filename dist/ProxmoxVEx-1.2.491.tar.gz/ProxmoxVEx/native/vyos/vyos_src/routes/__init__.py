# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/native/vyos/vyos_src/routes/__init__.py
# Project:     ProxmoxVEx
# Version:     1.2.479
# Build:       2026.09.20
# Description: Read-only route payload builders for VyOS.
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-20
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Read-only route payload builders for VyOS."""

from __future__ import annotations

from .overview import (  # noqa: F401
    build_interfaces_payload,
    build_overview_payload,
    build_routes_payload,
)
