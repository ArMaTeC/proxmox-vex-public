# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/native/zabbix/zabbix_src/client/__init__.py
# Project:     ProxmoxVEx
# Version:     1.2.479
# Build:       2026.09.20
# Description: Zabbix JSON-RPC client package.
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-20
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Zabbix JSON-RPC client package."""

from __future__ import annotations

from .zabbix_client import (  # noqa: F401
    ZabbixClient,
    ZabbixHost,
)
