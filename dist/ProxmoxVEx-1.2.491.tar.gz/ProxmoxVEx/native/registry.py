# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/native/registry.py
# Project:     ProxmoxVEx
# Version:     1.2.479
# Build:       2026.09.20
# Description: Native integration route registry and catch-all API...
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-20
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Native integration route registry and catch-all API dispatcher."""

import importlib
import importlib.util
import json
import logging
import os
import re
import threading

from flask import Blueprint, Response, request, send_file
from flask import g as flask_g

from ProxmoxVEx.core.db import get_db
from ProxmoxVEx.services.licensing import LicensingService
from ProxmoxVEx.utils.auth import require_auth

_native_lock = threading.RLock()
_native_routes = {}

# Module IDs are sub-package names under ProxmoxVEx.native. Only allow
# Python-identifier-like names; block path traversal and dot-walking.
_VALID_MODULE_ID = re.compile(r"\A[A-Za-z_][A-Za-z0-9_]{0,99}\Z")
# Subpaths are route keys registered by native modules (e.g. "config", "config/save").
_VALID_SUBPATH = re.compile(r"\A[A-Za-z0-9_/.-]{1,200}\Z")

bp = Blueprint("native", __name__)


def _json_response(data, status=200):
    """Return a JSON Response without taint-carrying formatting."""
    return Response(json.dumps(data, default=str), status=status, mimetype="application/json")


def _bad_request(message):
    """Return a 400 JSON Response with a static message."""
    return _json_response({"error": message}, status=400)


def _dispatch_handler_result(result):
    """Normalize a native handler's return value into a safe Flask Response.

    Lists/dicts are JSON-encoded.  Explicit Response objects are passed
    through (so a handler can still return HTML or files via send_file).
    Bare strings are served as text/plain so a user-influenced string
    cannot be rendered as HTML in the browser.
    """
    if isinstance(result, (dict, list)):
        return _json_response(result)
    if isinstance(result, Response):
        return _apply_ui_csp(result)
    if isinstance(result, str):
        return Response(result, mimetype="text/plain")
    return result


def _apply_ui_csp(resp):
    """Adapt a native-integration HTML response to the nonce'd CSP.

    (#084) Native UI documents (netapp_storage/ui.html etc.) ship inline
    event-handler attributes that CSP nonces cannot authorise — flag the
    request so app.py emits the script-src-attr 'unsafe-inline' split, and
    stamp the per-request nonce onto <script> tags so inline blocks still
    run under script-src-elem while injected scripts stay blocked.
    Non-HTML responses pass through untouched.
    """
    if "text/html" not in (resp.mimetype or ""):
        return resp
    try:
        from ProxmoxVEx.utils.csp import apply_nonce_to_scripts

        flask_g.csp_inline_handlers = True
        nonce = getattr(flask_g, "csp_nonce", "")
        # send_file responses stream in direct_passthrough mode — get_data()
        # raises unless the file wrapper is loaded into memory first. Native
        # UI html files are small, so buffering is cheap.
        resp.direct_passthrough = False
        html = resp.get_data(as_text=True)
        resp.set_data(apply_nonce_to_scripts(html, nonce))
    except Exception as e:
        # Never let nonce plumbing break a native UI — flag stays set so
        # handlers still run under script-src-attr on CSP3 browsers.
        logging.warning("[NATIVE] CSP nonce stamping failed: %s", e)
    return resp


def register_native_route(module_id, path, handler):
    """Register a native integration route handler."""
    with _native_lock:
        _native_routes.setdefault(module_id, {})[path] = handler


def _license_gate(module_id):
    """Check the active license tier before dispatching a native integration request.

    Re-checked on every request so a tier downgrade/expiry blocks new
    activity immediately (native integrations are always registered at
    import time, so there's no separate "load" step to gate like plugins/).
    Returns None if allowed, or a Response if blocked.
    """
    try:
        allowed = LicensingService().can_use_native(get_db(), module_id)
    except Exception as e:
        # Fail open on licensing-service errors so an outage doesn't take
        # down unrelated native integrations.
        logging.warning("[NATIVE] License guard skipped for %s: %s", module_id, e)
        return None
    if allowed:
        return None
    from ProxmoxVEx.models.plugins import get_native_tier_requirement

    required = get_native_tier_requirement(module_id)
    return _json_response(
        {"error": "License upgrade required for this integration", "required_tier": required},
        status=402,
    )


@bp.route("/api/<module_id>/<path:subpath>", methods=["GET", "POST", "PUT", "DELETE"])
@require_auth(perms=["plugins.view"])
def native_proxy(module_id, subpath):
    """Dispatch native integration API requests."""
    if not _VALID_MODULE_ID.match(module_id):
        return _bad_request("Invalid module_id")
    if not _VALID_SUBPATH.match(subpath):
        return _bad_request("Invalid subpath")

    blocked = _license_gate(module_id)
    if blocked:
        return blocked

    # Fully disabled integrations are blocked at the gateway, but the
    # config/disabled endpoints remain reachable so they can be re-enabled.
    try:
        cfg_path = _native_config_path(module_id)
        if os.path.exists(cfg_path):
            with open(cfg_path) as f:
                if json.load(f).get("disabled"):
                    return _json_response({"error": "Integration disabled"}, status=403)
    except Exception:
        pass

    with _native_lock:
        handler = _native_routes.get(module_id, {}).get(subpath)

    if not handler:
        # Serve any sibling .css/.js asset from the native module directory.
        # This supports the standard ui.css/ui.js as well as named assets that
        # match the native HTML page (e.g. active_directory.css, vyos.js).
        if (
            request.method == "GET"
            and subpath.endswith((".css", ".js"))
            and "/" not in subpath
            and ".." not in subpath
            and not subpath.startswith(".")
        ):
            spec = importlib.util.find_spec(f"ProxmoxVEx.native.{module_id}")
            if spec and spec.origin:
                static_path = os.path.join(os.path.dirname(spec.origin), subpath)
                if os.path.isfile(static_path):
                    mimetype = "text/css" if subpath.endswith(".css") else "text/javascript"
                    return send_file(static_path, mimetype=mimetype)
        logging.info("[NATIVE] Route not found: %s", subpath)
        return _json_response({"error": "Route not found"}, status=404)

    try:
        result = handler()
        return _dispatch_handler_result(result)
    except Exception as e:
        logging.error("[NATIVE] %s/%s error: %s", module_id, subpath, e)
        return _json_response({"error": "Native request failed"}, status=500)


def _native_module_dir(module_id):
    """Return the on-disk directory of a native module."""
    mod = importlib.import_module(f"ProxmoxVEx.native.{module_id}")
    # __file__ is Optional in typeshed (namespace/frozen modules can lack it);
    # a file-less module can't hold config.json or i18n files anyway.
    if not mod.__file__:
        raise ValueError(f"Native module {module_id} has no file-backed path")
    return os.path.dirname(mod.__file__)


def _native_config_path(module_id):
    """Resolve the config.json path for a native module."""
    if not _VALID_MODULE_ID.match(module_id):
        raise ValueError("Invalid module_id")
    return os.path.join(_native_module_dir(module_id), "config.json")


@bp.route("/api/native/<module_id>/config", methods=["GET", "POST"])
@require_auth(perms=["admin.settings"])
def native_config(module_id):
    """Read or write a native integration's config.

    Delegates to module-specific ``config`` / ``config/save`` handlers when
    they are registered so encryption, masking and validation are preserved.
    Falls back to raw ``config.json`` read/write for modules without custom
    handlers.
    """
    if not _VALID_MODULE_ID.match(module_id):
        return _bad_request("Invalid module_id")

    with _native_lock:
        module_routes = _native_routes.get(module_id, {})
        config_handler = module_routes.get("config")
        save_handler = module_routes.get("config/save")

    if request.method == "GET" and config_handler:
        try:
            result = config_handler()
            return _dispatch_handler_result(result)
        except Exception as e:
            logging.error("[NATIVE] %s config handler error: %s", module_id, e)
            return _json_response({"error": "Failed to load config"}, status=500)

    if request.method == "POST" and save_handler:
        try:
            result = save_handler()
            return _dispatch_handler_result(result)
        except Exception as e:
            logging.error("[NATIVE] %s config/save handler error: %s", module_id, e)
            return _json_response({"error": "Failed to save config"}, status=500)

    cfg_path = _native_config_path(module_id)
    if request.method == "GET":
        if not os.path.exists(cfg_path):
            return _json_response({})
        try:
            with open(cfg_path) as f:
                return _json_response(json.load(f))
        except Exception as e:
            logging.error("[NATIVE] %s config read error: %s", module_id, e)
            return _json_response({"error": "Failed to read config"}, status=500)

    data = request.get_json(silent=True)
    if data is None:
        return _bad_request("Invalid JSON body")
    try:
        os.makedirs(os.path.dirname(cfg_path), exist_ok=True)
        with open(cfg_path, "w") as f:
            json.dump(data, f, indent=2)
        return _json_response({"ok": True})
    except Exception as e:
        logging.error("[NATIVE] %s config write error: %s", module_id, e)
        return _json_response({"error": "Failed to write config"}, status=500)


def _native_i18n_path(module_id, lang):
    """Resolve a native integration i18n JSON path."""
    if not _VALID_MODULE_ID.match(module_id):
        raise ValueError("Invalid module_id")
    return os.path.join(_native_module_dir(module_id), "i18n", f"{lang}.json")


@bp.route("/api/native/<module_id>/i18n/<lang>.json", methods=["GET"])
@require_auth(perms=["plugins.view"])
def native_i18n(module_id, lang):
    """Serve a native integration's per-language i18n JSON from its i18n/ directory."""
    if not _VALID_MODULE_ID.match(module_id):
        return _bad_request("Invalid module_id")
    if not re.match(r"^[a-zA-Z]{2,3}(?:-[a-zA-Z0-9]+)*$", lang):
        return _bad_request("Invalid language")
    i18n_path = _native_i18n_path(module_id, lang)
    if not os.path.isfile(i18n_path):
        return _json_response({}, status=404)
    try:
        with open(i18n_path, encoding="utf-8") as f:
            data = json.load(f)
        return _json_response(data)
    except Exception as e:
        logging.error("[NATIVE] i18n/%s/%s.json error: %s", module_id, lang, e)
        return _json_response({"error": "Failed to read i18n file"}, status=500)


@bp.route("/api/native/<module_id>/disabled", methods=["GET"])
@require_auth(perms=["admin.settings"])
def native_disabled_get(module_id):
    """Return whether a native integration is explicitly disabled."""
    if not _VALID_MODULE_ID.match(module_id):
        return _bad_request("Invalid module_id")
    try:
        cfg_path = _native_config_path(module_id)
        if os.path.exists(cfg_path):
            with open(cfg_path) as f:
                return _json_response({"disabled": bool(json.load(f).get("disabled"))})
    except Exception as e:
        logging.error("[NATIVE] %s disabled read error: %s", module_id, e)
    return _json_response({"disabled": False})


@bp.route("/api/native/<module_id>/disabled", methods=["POST", "PUT"])
@require_auth(perms=["admin.settings"])
def native_disabled_set(module_id):
    """Explicitly enable or disable a native integration."""
    if not _VALID_MODULE_ID.match(module_id):
        return _bad_request("Invalid module_id")
    data = request.get_json(silent=True) or {}
    disabled = bool(data.get("disabled", False))
    cfg_path = _native_config_path(module_id)
    cfg = {}
    if os.path.exists(cfg_path):
        try:
            with open(cfg_path) as f:
                cfg = json.load(f)
        except Exception as e:
            logging.error("[NATIVE] %s disabled read before write error: %s", module_id, e)
            return _json_response({"error": "Failed to read existing config"}, status=500)
    cfg["disabled"] = disabled
    try:
        os.makedirs(os.path.dirname(cfg_path), exist_ok=True)
        with open(cfg_path, "w") as f:
            json.dump(cfg, f, indent=2)
    except Exception as e:
        logging.error("[NATIVE] %s disabled write error: %s", module_id, e)
        return _json_response({"error": "Failed to save disabled state"}, status=500)
    return _json_response({"disabled": disabled})
