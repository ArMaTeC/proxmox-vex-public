# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/native/opnsense/opnsense_src/divergence.py
# Project:     ProxmoxVEx
# Version:     1.2.479
# Build:       2026.09.20
# Description: Compat shim — the divergence detector moved to
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-20
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Compat shim — the divergence detector moved to
`ProxmoxVEx.native.fwkit.divergence` (extended with config-section drift)
so the pfSense plugin shares it.
"""

from opnsense_src._fwkit import ensure_fwkit_importable

ensure_fwkit_importable()

from ProxmoxVEx.native.fwkit.divergence import (  # noqa: E402,F401
    CONFIG_SECTIONS,
    Divergence,
    Severity,
    compute_divergence,
)
