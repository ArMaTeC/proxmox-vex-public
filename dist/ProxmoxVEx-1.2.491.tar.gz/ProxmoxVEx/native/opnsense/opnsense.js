/* --- ProxmoxVEx auto-header start ---
 * -------------------------------------------------------------------
 * File:        ProxmoxVEx/native/opnsense/opnsense.js
 * Project:     ProxmoxVEx
 * Version:     1.2.479
 * Build:       2026.09.20
 * Description: Opnsense JS source
 * Docs:        https://proxmoxvex.com/docs
 * Generated:   2026-09-20
 * -------------------------------------------------------------------
 * --- ProxmoxVEx auto-header end --- */
/* OPNsense boot: the entire UI is the shared firewall-manager (spec 003 —
   both appliances render identical tabs/actions from the same module).
   Replaces the bespoke ui.js shell. */
(function () {
    'use strict';

    window.FirewallManager.boot({
        pluginId: 'opnsense',
        apiBase: '/api/opnsense',
        i18nBase: '/api/native/opnsense/i18n',
        title: 'OPNsense Manager'
    });
})();
