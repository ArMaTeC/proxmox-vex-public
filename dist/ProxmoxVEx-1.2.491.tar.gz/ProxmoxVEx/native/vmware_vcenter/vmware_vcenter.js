/* --- ProxmoxVEx auto-header start ---
 * -------------------------------------------------------------------
 * File:        ProxmoxVEx/native/vmware_vcenter/vmware_vcenter.js
 * Project:     ProxmoxVEx
 * Version:     1.2.479
 * Build:       2026.09.20
 * Description: Vmware Vcenter JS source
 * Docs:        https://proxmoxvex.com/docs
 * Generated:   2026-09-20
 * -------------------------------------------------------------------
 * --- ProxmoxVEx auto-header end --- */
/* vCenter view: declarative tabs rendered by the shared NativeDataView shell
   (replaces the previous raw JSON <pre> dump). */
(function () {
  'use strict';

  var V = window.NativeDataView;

  function moRef(v) {
    return v ? V.el('span', { class: 'ndv-muted ndv-mono', text: v }) : null;
  }

  function powerBadge(v) {
    return V.badge(v || 'unknown');
  }

  NativeDataView.boot({
    ns: 'vmware_vcenter',
    apiBase: '/api/vmware_vcenter',
    i18nBase: '/api/native/vmware_vcenter/i18n',
    tabs: [
      {
        id: 'overview', label: 'overview', endpoint: 'overview',
        render: function (h, data) {
          var row = (data && data[0]) || {};
          h.root.appendChild(h.kpis([
            { label: h.t('vms'), value: row.vms_count },
            { label: h.t('hosts'), value: row.hosts_count },
            { label: h.t('datastores'), value: row.datastores_count }
          ]));
          h.section(h.t('connection'), h.kv([
            [h.t('name'), row.name],
            [h.t('host'), row.host],
            [h.t('port'), row.port],
            [h.t('username'), row.username]
          ]));
          var dss = row.datastores || [];
          if (dss.length) {
            h.section(h.t('datastores'), h.table(dss, [
              { key: 'name', label: h.t('name') },
              { key: 'type', label: h.t('type') },
              {
                key: 'used_gb', label: h.t('used'),
                render: function (v, r) {
                  return h.el('div', {},
                    h.meter(Number(r.used_gb) || 0, Number(r.capacity_gb) || 0),
                    h.el('span', { class: 'ndv-muted', text: h.fmtNum(r.used_gb) + ' / ' + h.fmtNum(r.capacity_gb) + ' GB' }));
                }
              },
              { key: 'free_gb', label: h.t('free'), render: function (v) { return h.fmtNum(v) + ' GB'; } }
            ]));
          }
        }
      },
      {
        id: 'vms', label: 'vms', endpoint: 'vms',
        render: function (h, data) {
          h.root.appendChild(h.table(data || [], [
            { key: 'name', label: h.t('name') },
            { key: 'power_state', label: h.t('power'), render: function (v) { return powerBadge(v); } },
            { key: 'cpu_count', label: h.t('cpus'), render: function (v) { return v == null ? null : h.fmtNum(v); } },
            {
              key: 'memory_size_MiB', label: h.t('memory'),
              render: function (v) { return v == null ? null : h.fmtNum(Math.round(Number(v) / 1024 * 10) / 10) + ' GB'; }
            },
            { key: 'mo_ref', label: 'MoRef', render: moRef }
          ]));
        }
      },
      {
        id: 'hosts', label: 'hosts', endpoint: 'hosts',
        render: function (h, data) {
          h.root.appendChild(h.table(data || [], [
            { key: 'name', label: h.t('name') },
            { key: 'connection_state', label: h.t('connection_state'), render: function (v) { return h.badge(v); } },
            { key: 'power_state', label: h.t('power'), render: function (v) { return powerBadge(v); } },
            { key: 'status', label: h.t('status'), render: function (v) { return h.badge(v); } },
            { key: 'mo_ref', label: 'MoRef', render: moRef }
          ]));
        }
      },
      {
        id: 'datastores', label: 'datastores', endpoint: 'datastores',
        render: function (h, data) {
          h.root.appendChild(h.table(data || [], [
            { key: 'name', label: h.t('name') },
            { key: 'type', label: h.t('type') },
            {
              key: 'used_gb', label: h.t('used'),
              render: function (v, r) {
                return h.el('div', {},
                  h.meter(Number(r.used_gb) || 0, Number(r.capacity_gb) || 0),
                  h.el('span', { class: 'ndv-muted', text: h.fmtNum(r.used_gb) + ' / ' + h.fmtNum(r.capacity_gb) + ' GB' }));
              }
            },
            { key: 'free_gb', label: h.t('free'), render: function (v) { return h.fmtNum(v) + ' GB'; } },
            { key: 'accessible', label: h.t('accessible'), render: function (v) { return h.badge(v ? 'Yes' : 'No', v ? 'ok' : 'err'); } }
          ]));
        }
      }
    ]
  });
})();
