# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/native/fwkit/divergence.py
# Project:     ProxmoxVEx
# Version:     1.2.479
# Build:       2026.09.20
# Description: Cross-node divergence detector shared by the...
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-20
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Cross-node divergence detector shared by the pfSense/OPNsense HA pairs.

Moved from `opnsense_src/divergence.py` (that module is now a compat shim)
and extended to cover config sections, not just runtime state: when a
snapshot carries a `sections` map of `{section: [rows...]}` — produced by
each platform's `collect_config_sections` — the detector compares
fingerprints/counts per section so rule/alias/NAT/DHCP/DNS/VPN drift
surfaces in the cluster view.

Categories covered:
- system          config_revision drift, version mismatch
- carp            split-brain (both master / both backup / one unknown)
- hasync          pfSync/XMLRPC disabled on one side
- services        running set difference
- gateways        status mismatch (online on A, offline on B)
- interfaces      link state mismatch on the same iface name
- certs           cert present on one side only, by SHA256 fingerprint
- config          per-section drift: rules, aliases, nat, dhcp, dns,
                  wireguard, ipsec, openvpn (fingerprint + row count)
"""

from __future__ import annotations

import hashlib
import json
from typing import Any, Literal, TypedDict, cast

Severity = Literal["info", "warning", "error"]


class Divergence(TypedDict):
    category: str
    key: str
    severity: Severity
    a: Any
    b: Any
    detail: str


def _eq_or_diff(category: str, key: str, a: Any, b: Any, severity: Severity, detail: str) -> Divergence | None:
    if a == b:
        return None
    return Divergence(category=category, key=key, severity=severity, a=a, b=b, detail=detail)


def _fp(payload: Any) -> str:
    blob = json.dumps(payload, sort_keys=True, ensure_ascii=False, default=str).encode("utf-8")
    return hashlib.sha256(blob).hexdigest()[:16]


def _diff_system(a: dict, b: dict) -> list[Divergence]:
    out: list[Divergence] = []
    a_sys, b_sys = a.get("system", {}) or {}, b.get("system", {}) or {}
    for field, sev, detail in (
        ("config_revision", "warning", "Config revision drift — config sync may be falling behind."),
        ("version", "info", "Firmware version mismatch between peers."),
        ("product_id", "info", "Product/edition mismatch between peers."),
    ):
        d = _eq_or_diff("system", field, a_sys.get(field), b_sys.get(field), cast(Severity, sev), detail)
        if d:
            out.append(d)
    return out


def _diff_carp(a: dict, b: dict) -> list[Divergence]:
    a_c, b_c = a.get("carp", {}) or {}, b.get("carp", {}) or {}
    role_a, role_b = a_c.get("role"), b_c.get("role")
    out: list[Divergence] = []
    if not role_a or not role_b:
        return out
    # Healthy pair: exactly one master + one backup. Anything else flags.
    healthy = {role_a, role_b} == {"master", "backup"}
    if not healthy and (role_a, role_b) != ("disabled", "disabled"):
        sev: Severity = "error" if (role_a == "master" and role_b == "master") else "warning"
        out.append(
            Divergence(
                category="carp",
                key="role_pair",
                severity=sev,
                a=role_a,
                b=role_b,
                detail=(
                    "Split-brain: both nodes report MASTER."
                    if sev == "error"
                    else f"Unexpected CARP roles ({role_a} / {role_b}); expected master+backup."
                ),
            )
        )
    # Maintenance mode toggled on one side only is usually intentional but worth surfacing.
    if a_c.get("maintenance_mode") != b_c.get("maintenance_mode"):
        out.append(
            Divergence(
                category="carp",
                key="maintenance_mode",
                severity="info",
                a=a_c.get("maintenance_mode"),
                b=b_c.get("maintenance_mode"),
                detail="Maintenance mode enabled on one node only.",
            )
        )
    # Demotion delta: negative values indicate CARP demoted the node due to
    # interface trouble. If either side reports demotion != 0, surface it.
    dem_a, dem_b = a_c.get("demotion", 0), b_c.get("demotion", 0)
    if dem_a != dem_b and (dem_a or dem_b):
        out.append(
            Divergence(
                category="carp",
                key="demotion",
                severity="warning",
                a=dem_a,
                b=dem_b,
                detail="CARP demotion values differ — at least one node has been demoted by a link/service issue.",
            )
        )
    return out


def _diff_hasync(a: dict, b: dict) -> list[Divergence]:
    a_h, b_h = a.get("hasync", {}) or {}, b.get("hasync", {}) or {}
    out: list[Divergence] = []
    if a_h.get("enabled") != b_h.get("enabled"):
        out.append(
            Divergence(
                category="hasync",
                key="enabled",
                severity="error",
                a=a_h.get("enabled"),
                b=b_h.get("enabled"),
                detail="Config sync enabled on one node only — config drift will accumulate.",
            )
        )
    for field, sev, detail in (
        ("pfsync_interface", "warning", "pfSync interface differs between peers."),
        ("pfsync_version", "info", "pfSync version mismatch."),
        ("sync_compatibility", "info", "Sync compatibility setting differs."),
    ):
        d = _eq_or_diff("hasync", field, a_h.get(field), b_h.get(field), cast(Severity, sev), detail)
        if d:
            out.append(d)
    return out


def _diff_services(a: dict, b: dict) -> list[Divergence]:
    a_s = a.get("services", {}) or {}
    b_s = b.get("services", {}) or {}
    items_a = {svc.get("name"): svc for svc in (a_s.get("items", []) or []) if svc.get("name")}
    items_b = {svc.get("name"): svc for svc in (b_s.get("items", []) or []) if svc.get("name")}
    out: list[Divergence] = []
    for name in sorted(set(items_a) | set(items_b), key=str):
        ra = items_a.get(name, {}).get("running")
        rb = items_b.get(name, {}).get("running")
        if ra != rb:
            out.append(
                Divergence(
                    category="services",
                    key=name,
                    severity="warning",
                    a=ra,
                    b=rb,
                    detail=f"Service '{name}' running state differs.",
                )
            )
    return out


def _diff_gateways(a: dict, b: dict) -> list[Divergence]:
    a_g = {g.get("name"): g for g in (a.get("gateways", []) or []) if isinstance(g, dict)}
    b_g = {g.get("name"): g for g in (b.get("gateways", []) or []) if isinstance(g, dict)}
    out: list[Divergence] = []
    for name in sorted(set(a_g) | set(b_g), key=str):
        sa = a_g.get(name, {}).get("status")
        sb = b_g.get(name, {}).get("status")
        if sa != sb:
            out.append(
                Divergence(
                    category="gateways",
                    key=name or "<unnamed>",
                    severity="warning",
                    a=sa,
                    b=sb,
                    detail=f"Gateway '{name}' reports different status on each node.",
                )
            )
    return out


def _diff_interfaces(a: dict, b: dict) -> list[Divergence]:
    a_i = {i.get("name"): i for i in (a.get("interfaces", []) or []) if isinstance(i, dict)}
    b_i = {i.get("name"): i for i in (b.get("interfaces", []) or []) if isinstance(i, dict)}
    out: list[Divergence] = []
    for name in sorted(set(a_i) | set(b_i), key=str):
        la = a_i.get(name, {}).get("link")
        lb = b_i.get(name, {}).get("link")
        if la != lb and {la, lb} <= {"up", "down", None, ""}:
            out.append(
                Divergence(
                    category="interfaces",
                    key=name or "<unnamed>",
                    severity="warning",
                    a=la,
                    b=lb,
                    detail=f"Interface '{name}' link state differs.",
                )
            )
    return out


def _diff_certs(a: dict, b: dict) -> list[Divergence]:
    a_c = a.get("certs", {}) or {}
    b_c = b.get("certs", {}) or {}
    list_a = a_c.get("expiring_soon", []) or []
    list_b = b_c.get("expiring_soon", []) or []
    fps_a = {c.get("fingerprint") or c.get("descr"): c for c in list_a if isinstance(c, dict)}
    fps_b = {c.get("fingerprint") or c.get("descr"): c for c in list_b if isinstance(c, dict)}
    out: list[Divergence] = []
    only_a = set(fps_a) - set(fps_b)
    only_b = set(fps_b) - set(fps_a)
    for k in sorted(only_a, key=str):
        out.append(
            Divergence(
                category="certs",
                key=str(k),
                severity="info",
                a="present",
                b="missing",
                detail="Certificate (expiring soon) present on A only.",
            )
        )
    for k in sorted(only_b, key=str):
        out.append(
            Divergence(
                category="certs",
                key=str(k),
                severity="info",
                a="missing",
                b="present",
                detail="Certificate (expiring soon) present on B only.",
            )
        )
    return out


# ---------------------------------------------------------------------------
# Config-section drift (parity feature: rules/aliases/NAT/DHCP/DNS/VPN)
# ---------------------------------------------------------------------------

#: Section keys a snapshot may carry under `sections` → human label.
CONFIG_SECTIONS = {
    "rules": "firewall rules",
    "aliases": "aliases",
    "nat": "NAT rules",
    "dhcp": "DHCP scopes/mappings",
    "dns": "DNS overrides",
    "wireguard": "WireGuard peers",
    "ipsec": "IPsec tunnels",
    "openvpn": "OpenVPN instances",
}


def _diff_config_sections(a: dict, b: dict) -> list[Divergence]:
    """Fingerprint-compare each config section both snapshots carry.

    Sections are `{section_name: [row, ...]}` maps on each snapshot. A row
    count delta is a `warning` (clearly drifted); same-count different-
    fingerprint is also `warning` — content changed, likely a concurrent
    edit the config sync didn't reconcile.
    """
    a_s = a.get("sections", {}) or {}
    b_s = b.get("sections", {}) or {}
    out: list[Divergence] = []
    for key, label in CONFIG_SECTIONS.items():
        rows_a = a_s.get(key)
        rows_b = b_s.get(key)
        if rows_a is None and rows_b is None:
            continue
        na, nb = len(rows_a or []), len(rows_b or [])
        fa, fb = _fp(rows_a or []), _fp(rows_b or [])
        if fa == fb:
            continue
        if na != nb:
            detail = f"{label} count differs ({na} vs {nb}) — config sync drift."
        else:
            detail = f"{label} content differs (same count, different fingerprint)."
        out.append(
            Divergence(
                category="config",
                key=key,
                severity="warning",
                a=f"{na} rows ({fa})",
                b=f"{nb} rows ({fb})",
                detail=detail,
            )
        )
    return out


def compute_divergence(snapshot_a: dict, snapshot_b: dict) -> list[Divergence]:
    """Compare two per-node overview snapshots. Empty list = nodes are in sync."""
    out: list[Divergence] = []
    out.extend(_diff_system(snapshot_a, snapshot_b))
    out.extend(_diff_carp(snapshot_a, snapshot_b))
    out.extend(_diff_hasync(snapshot_a, snapshot_b))
    out.extend(_diff_services(snapshot_a, snapshot_b))
    out.extend(_diff_gateways(snapshot_a, snapshot_b))
    out.extend(_diff_interfaces(snapshot_a, snapshot_b))
    out.extend(_diff_certs(snapshot_a, snapshot_b))
    out.extend(_diff_config_sections(snapshot_a, snapshot_b))
    # Stable order: severity desc (error > warning > info), then category, then key.
    rank = {"error": 0, "warning": 1, "info": 2}
    out.sort(key=lambda d: (rank.get(d["severity"], 9), d["category"], d["key"]))
    return out
