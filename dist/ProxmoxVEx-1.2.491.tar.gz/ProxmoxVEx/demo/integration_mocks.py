# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/demo/integration_mocks.py
# Project:     ProxmoxVEx
# Version:     1.2.479
# Build:       2026.09.20
# Description: Serve synthetic data for integrations whose transports...
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-20
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Serve synthetic data for integrations whose transports can't be
intercepted at the requests layer (pyvmomi SOAP, TrueNAS websockets,
LDAP, paramiko SSH). HTTP-based integrations are handled instead by
hostname interception in cluster_mock._demo_request.

Installed only when PROXMOXVEX_DEMO_MODE is on; data comes from
fixtures/demo/integrations.json so nothing here touches a real host.
"""

import json
import logging
import os

log = logging.getLogger(__name__)

_FX: dict = {}


def _fixture() -> dict:
    global _FX
    if not _FX:
        here = os.path.dirname(os.path.abspath(__file__))
        for cand in (
            os.path.join(here, "..", "..", "fixtures", "demo", "integrations.json"),
            os.path.join(here, "..", "fixtures", "demo", "integrations.json"),
            "/app/fixtures/demo/integrations.json",
        ):
            p = os.path.normpath(cand)
            if os.path.exists(p):
                with open(p, encoding="utf-8") as f:
                    _FX = json.load(f)
                break
    return _FX


def _section(name: str) -> dict:
    return _fixture().get(name, {})


# ---------------------------------------------------------------------------
# VMware vCenter (pyvmomi — no HTTP path to intercept)
# ---------------------------------------------------------------------------

def _import_plugin_module(plugin_dir_name: str, module_path: str):
    """Import a native plugin's internal module on its own top-level path.

    Native plugins prepend their directory to sys.path and import internals
    as e.g. ``vcenter_src.client`` — a different module object than
    ``ProxmoxVEx.native.<id>.vcenter_src.client``. Patching must hit the
    same module object the plugin's routes use.
    """
    import importlib
    import sys

    here = os.path.dirname(os.path.abspath(__file__))
    pdir = os.path.normpath(os.path.join(here, "..", "native", plugin_dir_name))
    if os.path.isdir(pdir) and pdir not in sys.path:
        sys.path.insert(0, pdir)
    return importlib.import_module(module_path)


def _patch(cls, name: str, fn) -> None:
    """Install a canned method on a client class (demo mode).

    Goes through a variable attribute name so neither mypy
    ([method-assign] on class attribute assignment) nor ruff (B010 on
    setattr with a constant name) fires — while remaining ordinary
    monkey-patching at runtime.
    """
    setattr(cls, name, fn)


def _patch_vcenter() -> None:
    vc = _import_plugin_module("vmware_vcenter", "vcenter_src.client.vcenter_client")

    fx = _section("vcenter")

    def _connect(self):
        return {"ok": True, "data": []}

    def _list_vms(self):
        _ps = {"POWERED_ON": "poweredOn", "POWERED_OFF": "poweredOff"}
        return {"ok": True, "data": [
            {"name": v["name"], "power_state": _ps.get(v["power_state"], "poweredOn"), "mo_ref": v["vm"]}
            for v in fx.get("vms", [])
        ]}

    def _list_hosts(self):
        return {"ok": True, "data": [
            {"name": h["name"], "connection_state": "connected", "power_state": "poweredOn", "status": "green", "mo_ref": h["host"]}
            for h in fx.get("hosts", [])
        ]}

    def _list_datastores(self):
        return {"ok": True, "data": [
            {"name": d["name"], "type": d["type"], "accessible": True,
             "capacity_gb": round(d["capacity"] / (1024**3), 2),
             "free_gb": round(d["free_space"] / (1024**3), 2),
             "used_gb": round((d["capacity"] - d["free_space"]) / (1024**3), 2),
             "mo_ref": d["datastore"]}
            for d in fx.get("datastores", [])
        ]}

    _patch(vc.VCenterClient, "connect", _connect)
    _patch(vc.VCenterClient, "list_vms", _list_vms)
    _patch(vc.VCenterClient, "list_hosts", _list_hosts)
    _patch(vc.VCenterClient, "list_datastores", _list_datastores)


# ---------------------------------------------------------------------------
# TrueNAS (websocket JSON-RPC — patch the single call() entry point)
# ---------------------------------------------------------------------------

def _patch_truenas() -> None:
    # truenas adds its truenas_src dir itself to sys.path and imports bare
    # ``core.ws_client`` — patch that module object, not truenas_src.core.*.
    here = os.path.dirname(os.path.abspath(__file__))
    src_dir = os.path.normpath(os.path.join(here, "..", "native", "truenas", "truenas_src"))
    import importlib
    import sys
    if os.path.isdir(src_dir) and src_dir not in sys.path:
        sys.path.insert(0, src_dir)
    ws_client = importlib.import_module("core.ws_client")

    fx = _section("truenas")

    def _call(self, method, params=None, timeout=None):  # noqa: ARG001
        return fx.get(method, [] if method.endswith(".query") else {})

    def _noop_true(self, *a, **k):
        return True

    def _connect(self, *a, **k):
        self._connected = True
        return True

    _patch(ws_client.TrueNASWSClient, "call", _call)
    _patch(ws_client.TrueNASWSClient, "connect", _connect)
    _patch(ws_client.TrueNASWSClient, "login", _noop_true)
    _patch(ws_client.TrueNASWSClient, "ensure_logged_in", _noop_true)
    if hasattr(ws_client.TrueNASWSClient, "is_connected"):
        _patch(ws_client.TrueNASWSClient, "is_connected", _noop_true)


# ---------------------------------------------------------------------------
# Active Directory (ldap3)
# ---------------------------------------------------------------------------

def _patch_ad() -> None:
    ldap_client = _import_plugin_module("active_directory", "ad_src.client.ldap_client")

    fx = _section("ad")

    def _test(self):
        return {"ok": True, "data": [{"name": self.host.name, "server": self.host.server, "base_dn": self.host.base_dn}]}

    def _users(self):
        return {"ok": True, "data": fx.get("users", [])}

    def _groups(self):
        return {"ok": True, "data": fx.get("groups", [])}

    _patch(ldap_client.ADClient, "test_connection", _test)
    _patch(ldap_client.ADClient, "list_users", _users)
    _patch(ldap_client.ADClient, "list_groups", _groups)


# ---------------------------------------------------------------------------
# Docker Swarm (paramiko SSH → canned docker CLI output)
# ---------------------------------------------------------------------------

def _patch_swarm() -> None:
    from ProxmoxVEx.native import docker_swarm as swarm

    fx = _section("swarm")

    # Command fragments -> fixture key. Order matters: check specific
    # subcommands before generic ones (service ps before service ls, etc).
    table = [
        ("swarm.localnodestate", "docker info --format '{{.Swarm.LocalNodeState}}'"),
        ("docker info", "docker info --format \"{{json .}}\""),
        ("node inspect", "docker node ls"),
        ("node ls", "docker node ls"),
        ("service ps", "docker service ps"),
        ("service inspect", "docker service ls"),
        ("service ls", "docker service ls"),
        ("stack ls", "docker stack ls"),
        ("system df", "docker system df --format \"{{json .}}\""),
        ("ps -a", "docker ps -a --format \"{{json .}}\" --no-trunc"),
        ("image ls", "docker image ls --format \"{{json .}}\" --no-trunc"),
        ("network inspect", "docker network inspect"),
        ("network ls", "docker network inspect"),
        ("volume inspect", "docker volume inspect"),
        ("volume ls", "docker volume inspect"),
    ]

    def _emit(key):
        val = fx.get(key)
        if val is None:
            return ""
        if isinstance(val, list):
            return "\n".join(json.dumps(v) for v in val) + "\n"
        if isinstance(val, dict):
            return json.dumps(val) + "\n"
        return str(val)

    def _ssh_exec(host_cfg_or_host, user=None, password=None, command="", timeout=15):  # noqa: ARG001
        low = command.lower()
        for frag, key in table:
            if frag in low:
                return _emit(key), "", 0
        return "", "", 0

    swarm._ssh_exec = _ssh_exec


def install_integration_mocks() -> None:
    """Install client-level mocks for non-HTTP integration transports."""
    for name, fn in (("vcenter", _patch_vcenter), ("truenas", _patch_truenas), ("ad", _patch_ad), ("swarm", _patch_swarm)):
        try:
            fn()
            log.info("[DEMO_MOCK] Patched %s integration client", name)
        except Exception as e:
            # Missing optional dep (pyvmomi/ldap3/...) — the plugin already
            # reports 'not installed' which is fine for the demo.
            log.info("[DEMO_MOCK] %s mock skipped: %s", name, e)
