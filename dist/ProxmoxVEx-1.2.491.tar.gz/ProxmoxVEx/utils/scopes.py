# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/utils/scopes.py
# Project:     ProxmoxVEx
# Version:     1.2.479
# Build:       2026.09.20
# Description: API-token scope model (#085).
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-20
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""API-token scope model (#085).

A scoped token carries a list of ``<area>:<read|write>`` grants. On every
token-authenticated request, ``require_auth`` derives the scope the endpoint
requires from (method, path) and rejects the call when the token does not
cover it — a leaked ``vms:read`` token can no longer mutate state.

Conventions:

- Canonical form is ``area:action`` (``vms:read``). The api-token-manager
  plugin historically used action-first (``read:vms``); ``normalize_scope``
  accepts that form so plugin-issued scopes stay valid.
- ``*`` covers everything, ``<area>:*`` covers an area, ``*:<action>``
  covers an action across areas.
- Tokens with no scope list (NULL column) are *unscoped* — legacy full
  access until revoked. An empty list ``[]`` means a fully scoped token
  with zero grants: everything is denied.
"""

import re

# Method buckets: reads never mutate; everything else is a write.
_READ_METHODS = {"GET", "HEAD", "OPTIONS"}

# Canonical scope grammar. `*` alone is a full grant; otherwise the scope is
# `<area>:<action>` where area is a lowercase identifier-ish path bucket and
# action is read|write|*.
_SCOPE_RE = re.compile(r"^([a-z0-9_-]{1,64}):(read|write|\*)$|^\*$")
_LEGACY_ACTION_FIRST = {"read", "write"}

# Areas exposed to the UI as selectable grants. required_scope() derives the
# area dynamically from the request path, so tokens can also carry scopes for
# areas not listed here (e.g. a native integration module id) — this catalog
# is for display/validation hints, not an exhaustive allowlist.
SCOPE_CATALOG = {
    "vms": "VMs & containers",
    "nodes": "Cluster nodes",
    "storage": "Storage & datastores",
    "snapshots": "Snapshots",
    "backups": "Backups",
    "pools": "Resource pools",
    "clusters": "Cluster management",
    "users": "Users & groups",
    "settings": "Server settings",
    "plugins": "Plugin APIs",
    "native": "Native integrations",
    "auth": "Sessions & tokens",
    "audit": "Audit log",
    "alerts": "Alerts & notifications",
    "reports": "Reports",
    "metrics": "Metrics & monitoring",
    "tasks": "Tasks & schedules",
    "network": "Network & SDN",
    "firewall": "Firewall rules",
    "isos": "ISO & template images",
}

# Segments that never name a scope area by themselves — the real area sits
# one segment deeper (e.g. /api/clusters/<id>/vms -> vms).
_CONTAINER_SEGMENTS = {"clusters"}


def normalize_scope(scope: str) -> str | None:
    """Return the canonical ``area:action`` form of *scope*, or None.

    Accepts canonical (``vms:read``), the plugin's legacy action-first form
    (``read:vms``), and ``*``. Anything outside the grammar is rejected.
    """
    if not isinstance(scope, str):
        return None
    s = scope.strip()
    if s == "*":
        return s
    area, sep, action = s.partition(":")
    if not sep:
        return None
    # Legacy action-first form used by the api-token-manager plugin.
    if area in _LEGACY_ACTION_FIRST:
        area, action = action, area
    candidate = f"{area}:{action}"
    return candidate if _SCOPE_RE.match(candidate) else None


def validate_scopes(scopes) -> list[str]:
    """Validate + normalize a requested scope list.

    Returns the canonical scope list. Raises ValueError on malformed input
    (non-list, non-string entries, duplicates, unknown grammar).
    """
    if not isinstance(scopes, list):
        raise ValueError("scopes must be a list")
    if len(scopes) > 64:
        raise ValueError("too many scopes (max 64)")
    out, seen = [], set()
    for s in scopes:
        canon = normalize_scope(s)
        if canon is None:
            raise ValueError(f"invalid scope: {s!r} (expected '<area>:read|write' or '*')")
        if canon in seen:
            raise ValueError(f"duplicate scope: {canon}")
        seen.add(canon)
        out.append(canon)
    return out


def required_scope(method: str, path: str) -> str | None:
    """Derive the scope a request requires, e.g. ``vms:write``.

    Only ``/api/*`` routes are scope-gated — document-serving paths (the SPA
    shell, /portal, /status) are session-auth territory. Under
    ``/api/clusters/<id>/...`` the cluster id is a container segment and the
    real area is the following segment (``.../vms`` -> ``vms``); every other
    route's area is its first path segment, which also gives native
    integrations per-module scopes (``/api/netapp_storage/...`` ->
    ``netapp_storage``) and plugin-proxied calls a ``plugins`` scope.
    """
    if not path or not path.startswith("/api/"):
        return None
    segments = [s for s in path[len("/api/"):].split("/") if s]
    if not segments:
        return None
    area = segments[0]
    if area in _CONTAINER_SEGMENTS:
        area = segments[2] if len(segments) > 2 else area
    action = "read" if method in _READ_METHODS else "write"
    return f"{area}:{action}"


def scope_allows(token_scopes: list[str] | None, required: str | None) -> bool:
    """True when *token_scopes* covers *required*.

    Matching rules: exact scope, ``<area>:*``, ``*:<action>``, or the
    full-access ``*``. A ``None`` required scope (non-API path) is always
    allowed — the scope gate only guards API routes.
    """
    if required is None:
        return True
    area, _, action = required.partition(":")
    return any(s == "*" or s == required or s == f"{area}:*" or s == f"*:{action}" for s in token_scopes or [])
