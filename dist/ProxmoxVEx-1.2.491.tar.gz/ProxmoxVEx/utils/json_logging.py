# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/utils/json_logging.py
# Project:     ProxmoxVEx
# Version:     1.2.479
# Build:       2026.09.20
# Description: (spec 092/US023) Structured JSON logging across the...
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-20
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""(spec 092/US023) Structured JSON logging across the backend.

One JSON object per log line with consistent fields — ts, level, logger,
msg, request_id — so stdout/file output is machine-queryable in a SIEM
instead of needing regex parsing of free-text lines.

- ``JsonFormatter`` renders the record; secret-ish extras (password, token,
  secret, ticket) are redacted so a stray ``extra=`` can't leak creds.
- ``RequestContextFilter`` hoists the ``request_id_var`` contextvar onto
  every record, so plain ``logging.*`` calls carry request_id once request
  middleware (spec 092/US024) sets it per request.
- ``make_formatter()`` returns JsonFormatter by default;
  ``PROXMOXVEX_LOG_FORMAT=text`` opts back into the human-readable line for
  local dev. ``install_json_logging()`` applies the formatter + filter to
  the root logger's handlers (adding a StreamHandler when none exist) so it
  works under any entrypoint — service main(), WSGI workers, or tests.
"""

import contextvars
import json
import logging
import os

# Per-request correlation id; populated by request middleware (US024) and
# read by RequestContextFilter for every emitted record.
# annotated explicitly: default=None alone infers ContextVar[None], which
# makes every .set(str) call a type error
request_id_var: contextvars.ContextVar[str | None] = contextvars.ContextVar("proxmoxvex_request_id", default=None)


def set_request_id(value):
    """Store the current request id; returns a token for reset."""
    return request_id_var.set(value)


def get_request_id():
    return request_id_var.get()


class RequestContextFilter(logging.Filter):
    """Inject request_id (and future request-scoped fields) into records."""

    def filter(self, record):
        if getattr(record, "request_id", None) is None:
            record.request_id = request_id_var.get()
        return True


class JsonFormatter(logging.Formatter):
    REDACT = ("password", "token", "secret", "ticket")

    # param named `record` (not `rec`) to match Formatter.format's signature —
    # an override that renames it breaks keyword callers
    def format(self, record):
        out = {
            "ts": round(record.created, 3),
            "level": record.levelname,
            "logger": record.name,
            "msg": record.getMessage(),
            "request_id": getattr(record, "request_id", None),
        }
        for k, v in (getattr(record, "extra", None) or {}).items():
            if not any(s in k.lower() for s in self.REDACT):
                out[k] = v
        # hoist non-secret custom attributes set directly on the record —
        # the stdlib reserves its own names, so only extras lands here; the
        # explicit `extra` dict above is the sanctioned channel.
        if record.exc_info:
            out["exc"] = self.formatException(record.exc_info)
        try:
            return json.dumps(out, default=str)
        except Exception:
            # A formatter must never raise — emit() would funnel the error
            # through handleError and, under a broken json.dumps, recurse.
            # Fall back to a minimal plain line so the record still lands.
            return '{"level": "ERROR", "msg": "log record serialization failed"}'


def make_formatter():
    """JSON by default; PROXMOXVEX_LOG_FORMAT=text restores the text line."""
    fmt = (os.environ.get("PROXMOXVEX_LOG_FORMAT") or "json").strip().lower()
    if fmt == "text":
        return logging.Formatter("[%(asctime)s] [%(name)s] %(levelname)s: %(message)s")
    return JsonFormatter()


def install_json_logging():
    """Apply the structured formatter + request filter to the root logger.

    Idempotent: swaps formatter on existing handlers (so a later
    logging.basicConfig's handlers get upgraded too) and adds a stream
    handler only when nothing is attached yet.
    """
    root = logging.getLogger()
    fmt = make_formatter()
    if not root.handlers:
        root.addHandler(logging.StreamHandler())
    for h in root.handlers:
        h.setFormatter(fmt)
    if not any(isinstance(f, RequestContextFilter) for f in root.filters):
        root.addFilter(RequestContextFilter())
