# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/utils/trusted_devices.py
# Project:     ProxmoxVEx
# Version:     1.2.479
# Build:       2026.09.20
# Description: Trusted-device ("remember this computer") keys for 2FA.
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-20
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Trusted-device keys for 2FA ("don't ask for the second factor again on
this computer").

Model:
  - The client generates a stable ``device_id`` (random UUID in localStorage)
    and sends it with every login.
  - After a login that satisfied a second factor, the server mints a random
    ``device_key`` and stores only its SHA-256 hash in ``trusted_devices``
    together with the username, the ``device_id`` and the client IP. The raw
    key goes to the client (localStorage).
  - A later login may skip the second factor only when it presents a key
    whose hash matches a non-expired, non-revoked row for the SAME username,
    SAME device_id and SAME source IP. A stolen key is therefore useless
    from another machine or another network location, and clearing browser
    storage (or logging out on a wiped profile) destroys the client half.

Only the hash is stored server-side so a database leak cannot mint
bypass keys.
"""

import hashlib
import hmac
import logging
import re
import secrets
from datetime import datetime, timedelta

from ProxmoxVEx.core.db import get_db

# Devices stay trusted for 30 days — long enough to avoid daily re-prompts,
# short enough that a forgotten device eventually ages out on its own.
TRUSTED_DEVICE_TTL_DAYS = 30

# Cap stored keys per user so a loop of fresh device_ids can't grow the
# table without bound.
_MAX_DEVICES_PER_USER = 10

_DEVICE_ID_RE = re.compile(r"^[A-Za-z0-9_-]{8,64}$")
_TOKEN_RE = re.compile(r"^[A-Za-z0-9_-]{20,128}$")


def _hash_token(token: str) -> str:
    return hashlib.sha256(token.encode("utf-8")).hexdigest()


def _ua_hash() -> str:
    """Best-effort UA hash — recorded for audit display, never enforced
    (browser updates would otherwise silently break trust)."""
    try:
        from flask import request

        ua = request.headers.get("User-Agent", "") if request else ""
        return hashlib.sha256(ua.encode("utf-8")).hexdigest() if ua else ""
    except Exception:
        return ""


def issue_trusted_device(username: str, device_id: str, ip_address: str | None) -> str | None:
    """Create a server record + client key pair. Returns the raw client key
    (shown once, stored in the client's localStorage) or None on failure."""
    if not username or not _DEVICE_ID_RE.match(device_id or ""):
        return None
    token = secrets.token_urlsafe(32)
    now = datetime.now()
    expires = now + timedelta(days=TRUSTED_DEVICE_TTL_DAYS)
    try:
        db = get_db()
        # Re-trusting the same device replaces its previous key so the table
        # doesn't accumulate one row per login.
        db.execute(
            "DELETE FROM trusted_devices WHERE username = ? AND device_id = ?",
            (username, device_id),
        )
        db.execute(
            "INSERT INTO trusted_devices (username, device_id, token_hash, ip_address, user_agent_hash, created_at, expires_at)"
            " VALUES (?, ?, ?, ?, ?, ?, ?)",
            (
                username,
                device_id,
                _hash_token(token),
                ip_address or "",
                _ua_hash(),
                now.isoformat(),
                expires.isoformat(),
            ),
        )
        # Bound growth: drop expired rows, then oldest beyond the cap.
        db.execute("DELETE FROM trusted_devices WHERE expires_at < ?", (now.isoformat(),))
        rows = db.query(
            "SELECT id FROM trusted_devices WHERE username = ? ORDER BY created_at DESC",
            (username,),
        )
        for row in rows[_MAX_DEVICES_PER_USER:]:
            db.execute("DELETE FROM trusted_devices WHERE id = ?", (row["id"],))
        return token
    except Exception as e:
        logging.warning(f"trusted device issue failed for {username}: {e}")
        return None


def check_trusted_device(username: str, device_id: str, token: str, ip_address: str | None) -> bool:
    """True when (username + device_id + token + ip) matches a live record.

    All four must agree — a mismatched device_id or a changed IP means the
    client half is stale and the caller must complete 2FA again."""
    if not username or not _DEVICE_ID_RE.match(device_id or "") or not _TOKEN_RE.match(token or ""):
        return False
    try:
        db = get_db()
        row = db.query_one(
            "SELECT id, device_id, ip_address, expires_at, revoked FROM trusted_devices"
            " WHERE token_hash = ? AND username = ?",
            (_hash_token(token), username),
        )
        if not row or row["revoked"]:
            return False
        if not hmac.compare_digest(str(row["device_id"]), str(device_id)):
            return False
        if (row["ip_address"] or "") != (ip_address or ""):
            return False
        try:
            if datetime.fromisoformat(row["expires_at"]) < datetime.now():
                return False
        except Exception:
            return False
        db.execute(
            "UPDATE trusted_devices SET last_used_at = ? WHERE id = ?",
            (datetime.now().isoformat(), row["id"]),
        )
        return True
    except Exception as e:
        logging.warning(f"trusted device check failed for {username}: {e}")
        return False


def revoke_trusted_devices(username: str, device_id: str | None = None) -> int:
    """Revoke a user's trusted devices (all of them, or one device_id).
    Called on TOTP disable/re-enroll and password change so a stolen client
    key dies with the credential change."""
    if not username:
        return 0
    try:
        db = get_db()
        if device_id:
            db.execute(
                "UPDATE trusted_devices SET revoked = 1 WHERE username = ? AND device_id = ?",
                (username, device_id),
            )
        else:
            db.execute("UPDATE trusted_devices SET revoked = 1 WHERE username = ?", (username,))
        return 1
    except Exception as e:
        logging.warning(f"trusted device revoke failed for {username}: {e}")
        return 0


def revoke_all_trusted_devices() -> int:
    """Revoke every trusted device — counterpart to kill-all-sessions for a
    full session clear (e.g. suspected credential compromise)."""
    try:
        db = get_db()
        db.execute("UPDATE trusted_devices SET revoked = 1")
        return 1
    except Exception as e:
        logging.warning(f"trusted device revoke-all failed: {e}")
        return 0
