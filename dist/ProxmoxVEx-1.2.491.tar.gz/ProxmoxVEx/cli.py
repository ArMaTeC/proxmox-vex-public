# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/cli.py
# Project:     ProxmoxVEx
# Version:     1.2.479
# Build:       2026.09.20
# Description: spec 092/US087: disaster-recovery as a documented command.
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-20
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""spec 092/US087: disaster-recovery as a documented command.

``python -m ProxmoxVEx.cli backup <dest.tar.gz>`` writes a tar.gz holding
a consistent ``pg_dump -Fc`` snapshot (``db.dump``), the config directory
(``config/`` — settings, keys, keystore material), and a ``MANIFEST``
identifying the app version that produced it.

``python -m ProxmoxVEx.cli restore <src.tar.gz>`` gates on the manifest's
version (cross-version restores need ``--force`` — schema epochs differ),
unpacks config/, and ``pg_restore --clean --if-exists`` the dump into the
configured PostgreSQL DSN.
"""

import argparse
import io
import json
import logging
import os
import subprocess
import sys
import tarfile
import tempfile
from datetime import datetime, timezone
from pathlib import Path

from ProxmoxVEx.constants import CONFIG_DIR, ProxmoxVEx_BUILD, ProxmoxVEx_VERSION


class RestoreError(Exception):
    """Fatal restore problem — carries the actionable reason."""


def _dsn() -> str:
    from ProxmoxVEx.core.db_pg import _pg_dsn

    return _pg_dsn()


def create_backup(dest, config_dir=CONFIG_DIR) -> Path:
    """Write a backup archive: consistent DB dump + config dir + manifest."""
    dest = Path(dest)
    dest.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory() as tmp:
        dump = Path(tmp) / "db.dump"
        # consistent snapshot — same custom format the pre-migration
        # backups use, restorable by pg_restore.
        subprocess.run(
            ["pg_dump", "-Fc", "-f", str(dump), _dsn()],
            check=True, timeout=600, capture_output=True,
        )
        if not dump.exists() or dump.stat().st_size == 0:
            raise RestoreError(f"pg_dump produced an empty/missing dump: {dump}")

        manifest = {
            "version": ProxmoxVEx_VERSION,
            "build": ProxmoxVEx_BUILD,
            "created": datetime.now(timezone.utc).isoformat(),
        }
        with tarfile.open(dest, "w:gz") as tar:
            tar.add(dump, arcname="db.dump")
            cfg = Path(config_dir)
            if cfg.is_dir():
                tar.add(cfg, arcname="config")
            manifest_bytes = json.dumps(manifest, indent=2).encode()
            ti = tarfile.TarInfo("MANIFEST")
            ti.size = len(manifest_bytes)  # required — bare TarInfo sizes 0
            tar.addfile(ti, io.BytesIO(manifest_bytes))
    logging.info("[backup] wrote %s", dest)
    return dest


def check_archive(src) -> dict:
    """Read + return the archive MANIFEST — missing/bad archives fail here."""
    try:
        with tarfile.open(src) as tar:
            f = tar.extractfile("MANIFEST")
            if f is None:
                raise RestoreError(f"{src}: no MANIFEST — not a ProxmoxVEx backup archive")
            manifest = json.loads(f.read())
            tar.getmember("db.dump")
    except (tarfile.TarError, KeyError, json.JSONDecodeError) as e:
        raise RestoreError(f"{src}: unreadable backup archive ({e})") from e
    return manifest


def _safe_extract_config(tar, config_dir: Path):
    """Extract config/ members only, stripped of the prefix — a crafted
    archive member like config/../../etc/passwd must never escape the
    target dir."""
    target = config_dir.resolve()
    for m in tar.getmembers():
        if not m.name.startswith("config/") or m.name == "config/":
            continue
        rel = m.name[len("config/") :]
        dest_path = (target / rel).resolve()
        if not str(dest_path).startswith(str(target) + os.sep):
            raise RestoreError(f"archive member escapes config dir: {m.name}")
        if m.isdir():
            dest_path.mkdir(parents=True, exist_ok=True)
        elif m.isfile():
            # write the payload directly — no tar.extract path semantics,
            # so the config/ prefix can't leak into the target layout
            dest_path.parent.mkdir(parents=True, exist_ok=True)
            dest_path.write_bytes(tar.extractfile(m).read())
            os.chmod(dest_path, m.mode & 0o777)


def apply_backup(src, config_dir=CONFIG_DIR, force=False) -> None:
    """Restore an archive: version gate → config unpack → pg_restore."""
    manifest = check_archive(src)
    version = manifest.get("version", "unknown")
    if version != ProxmoxVEx_VERSION and not force:
        raise RestoreError(
            f"backup was made by version {version}, this install is {ProxmoxVEx_VERSION} — "
            "restore only onto a matching version, or pass --force to attempt it anyway"
        )

    config_dir = Path(config_dir)
    config_dir.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory() as tmp:
        with tarfile.open(src) as tar:
            _safe_extract_config(tar, config_dir)
            tar.extract("db.dump", path=tmp, filter="data")
        subprocess.run(
            ["pg_restore", "--clean", "--if-exists", "--no-owner", "--no-privileges",
             "-d", _dsn(), str(Path(tmp) / "db.dump")],
            check=True, timeout=600, capture_output=True,
        )
    logging.info("[restore] restored backup created %s (version %s)", manifest.get("created"), version)


def main(argv=None):
    ap = argparse.ArgumentParser(prog="proxmoxvex", description="ProxmoxVEx backup/restore")
    sub = ap.add_subparsers(dest="cmd", required=True)
    for name in ("backup", "restore"):
        p = sub.add_parser(name)
        p.add_argument("archive")
        p.add_argument("--config-dir", default=CONFIG_DIR)
    sub.choices["restore"].add_argument("--force", action="store_true")
    args = ap.parse_args(argv)

    try:
        if args.cmd == "backup":
            create_backup(args.archive, config_dir=args.config_dir)
            print(f"backup written: {args.archive}")
        else:
            apply_backup(args.archive, config_dir=args.config_dir, force=args.force)
            print(f"restored: {args.archive}")
    except (RestoreError, subprocess.CalledProcessError) as e:
        print(f"{args.cmd} failed: {e}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
