#!/usr/bin/env python3
# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/integrations/wireguard.py
# Project:     ProxmoxVEx
# Version:     1.2.479
# Build:       2026.09.20
# Description: WireGuard monitoring: host enrollment,...
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-20
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""WireGuard monitoring: host enrollment, interfaces/peers/live state, tunnel health, peer lifecycle and client configs (spec 026)."""

import html

from flask import Blueprint, jsonify, request

from ProxmoxVEx.api.auth import require_auth
from ProxmoxVEx.api.clusters import check_cluster_access, cluster_managers
from ProxmoxVEx.utils.audit import log_audit

bp = Blueprint("wireguard", __name__)


# Per-cluster connector configuration store.
_wireguard_connectors = {}


def _wireguard_guard(cluster_id):
    """Shared access + existence guard for every wireguard endpoint."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return err[1] if err else 403
    if cluster_id not in cluster_managers:
        return 404
    return None


def _wireguard_audit(cluster_id, action, message):
    """Central audit helper so every mutation records actor/action/cluster."""
    log_audit(
        request.session.get("user", "system"),
        action,
        f"{message} (cluster={html.escape(cluster_id)})",
        cluster=cluster_managers[cluster_id].config.name,
    )

_wireguard_store_connector = {}


@bp.route("/api/clusters/<cluster_id>/wireguard/connector", methods=["GET", "POST"])
@require_auth(perms=["wireguard.connector"])
def wireguard_connector(cluster_id):
    """Enroll or read a WireGuard host connection (SSH/agent transport)."""
    denied = _wireguard_guard(cluster_id)
    if denied:
        return jsonify({"error": "Access denied"} if denied == 403 else {"error": "Cluster not found"}), denied
    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "connector": _wireguard_store_connector.get(cluster_id, {"enabled": False, "host": "", "transport": "ssh", "username": ""}),
        })
    data = request.get_json() or {}
    cfg = data.get("connector", {})
    if not isinstance(cfg, dict):
        return jsonify({"error": "connector must be an object", "code": "invalid_payload"}), 400
    host = str(cfg.get("host", "")).strip()
    if True and not host:
        return jsonify({"error": "host is required", "code": "missing_field"}), 400

    _wireguard_store_connector[cluster_id] = cfg
    _wireguard_audit(cluster_id, "wireguard.connector", "Updated connector for wireguard")
    return jsonify({"success": True, "cluster": html.escape(cluster_id), "connector": cfg})


@bp.route("/api/clusters/<cluster_id>/wireguard/interfaces", methods=["GET"])
@require_auth(perms=["wireguard.view"])
def wireguard_interfaces(cluster_id):
    """WireGuard interfaces with listen ports and keys redacted."""
    denied = _wireguard_guard(cluster_id)
    if denied:
        return jsonify({"error": "Access denied"} if denied == 403 else {"error": "Cluster not found"}), denied
    return jsonify({
        "cluster": html.escape(cluster_id),
        "interfaces": [],
    })


@bp.route("/api/clusters/<cluster_id>/wireguard/peers", methods=["GET"])
@require_auth(perms=["wireguard.view"])
def wireguard_peers(cluster_id):
    """Peer inventory with live handshake/transfer state."""
    denied = _wireguard_guard(cluster_id)
    if denied:
        return jsonify({"error": "Access denied"} if denied == 403 else {"error": "Cluster not found"}), denied
    return jsonify({
        "cluster": html.escape(cluster_id),
        "peers": [],
    })


@bp.route("/api/clusters/<cluster_id>/wireguard/health", methods=["GET"])
@require_auth(perms=["wireguard.view"])
def wireguard_health(cluster_id):
    """Derived tunnel health from handshake age and transfer counters."""
    denied = _wireguard_guard(cluster_id)
    if denied:
        return jsonify({"error": "Access denied"} if denied == 403 else {"error": "Cluster not found"}), denied
    return jsonify({
        "cluster": html.escape(cluster_id),
        "health": {"tunnels": [], "stale_peers": []},
    })


@bp.route("/api/clusters/<cluster_id>/wireguard/peers/manage", methods=["POST"])
@require_auth(perms=["wireguard.peer.manage"])
def wireguard_peer_manage(cluster_id):
    """Peer lifecycle: add/remove peers and generate client configs."""
    denied = _wireguard_guard(cluster_id)
    if denied:
        return jsonify({"error": "Access denied"} if denied == 403 else {"error": "Cluster not found"}), denied
    data = request.get_json() or {}
    action = str(data.get("action", "")).strip()
    if not action:
        return jsonify({"error": "action is required", "code": "missing_field"}), 400
    if data.get("action") not in ("add", "remove", "client_config"):
        return jsonify({"error": "action must be add, remove or client_config", "code": "invalid_field"}), 400
    interface = str(data.get("interface", "")).strip()
    if not interface:
        return jsonify({"error": "interface is required", "code": "missing_field"}), 400

    _wireguard_audit(cluster_id, "wireguard.peer.manage", "Peer management requested")
    return jsonify({"success": True, "cluster": html.escape(cluster_id), "peer": {"action": data["action"], "interface": data["interface"], "status": "applied"}})


@bp.route("/api/clusters/<cluster_id>/wireguard/transport", methods=["GET"])
@require_auth(perms=["wireguard.view"])
def wireguard_transport(cluster_id):
    """Proxmox host transport-encryption view (which links are WireGuard-protected)."""
    denied = _wireguard_guard(cluster_id)
    if denied:
        return jsonify({"error": "Access denied"} if denied == 403 else {"error": "Cluster not found"}), denied
    return jsonify({
        "cluster": html.escape(cluster_id),
        "transport": {"links": [], "coverage": 0},
    })


@bp.route("/api/clusters/<cluster_id>/wireguard/alerts", methods=["GET"])
@require_auth(perms=["wireguard.view"])
def wireguard_alerts(cluster_id):
    """Stale-handshake and tunnel-down alerts."""
    denied = _wireguard_guard(cluster_id)
    if denied:
        return jsonify({"error": "Access denied"} if denied == 403 else {"error": "Cluster not found"}), denied
    return jsonify({
        "cluster": html.escape(cluster_id),
        "alerts": [],
    })


@bp.route("/api/clusters/<cluster_id>/wireguard/widget", methods=["GET"])
@require_auth(perms=["wireguard.view"])
def wireguard_widget(cluster_id):
    """Dashboard widget for WireGuard tunnel health."""
    denied = _wireguard_guard(cluster_id)
    if denied:
        return jsonify({"error": "Access denied"} if denied == 403 else {"error": "Cluster not found"}), denied
    return jsonify({
        "cluster": html.escape(cluster_id),
        "widget": {"title": "WireGuard", "status": "connected", "peers": 0},
    })
