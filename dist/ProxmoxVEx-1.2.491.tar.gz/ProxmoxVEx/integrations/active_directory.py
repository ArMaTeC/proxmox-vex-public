#!/usr/bin/env python3
# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/integrations/active_directory.py
# Project:     ProxmoxVEx
# Version:     1.2.479
# Build:       2026.09.20
# Description: Active Directory integration: export endpoints.
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-20
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Active Directory integration: export endpoints."""

import html

from flask import Blueprint, jsonify, request

from ProxmoxVEx.api.auth import require_auth
from ProxmoxVEx.api.clusters import check_cluster_access, cluster_managers
from ProxmoxVEx.utils.audit import log_audit

bp = Blueprint("active_directory", __name__)


# In-memory Active Directory export target store.
_active_directory_export_targets = {}


@bp.route("/api/clusters/<cluster_id>/active-directory/export", methods=["GET", "POST"])
@require_auth(perms=["active_directory.export"])
def active_directory_export(cluster_id):
    """Return or update the Active Directory export configuration."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "export": _active_directory_export_targets.get(
                cluster_id,
                {"enabled": False, "domain": ""},
            ),
        })

    data = request.get_json() or {}
    export = data.get("export", {})
    enabled = bool(export.get("enabled", False))
    domain = str(export.get("domain", ""))

    config = {"enabled": enabled, "domain": domain}
    _active_directory_export_targets[cluster_id] = config
    log_audit(
        request.session.get("user", "system"),
        "active_directory.export",
        f"Updated Active Directory export for {html.escape(cluster_id)}: enabled={enabled}",
        cluster=cluster_managers[cluster_id].config.name,
    )

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "export": config,
    })


# In-memory Active Directory connector configuration.
_active_directory_connector = {}


@bp.route("/api/clusters/<cluster_id>/active-directory/connector", methods=["GET", "POST"])
@require_auth(perms=["active_directory.connector"])
def active_directory_connector(cluster_id):
    """Return or update the Active Directory connector configuration."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "connector": _active_directory_connector.get(
                cluster_id,
                {"enabled": False, "server": "", "bind_dn": ""},
            ),
        })

    data = request.get_json() or {}
    connector = data.get("connector", {})
    enabled = bool(connector.get("enabled", False))
    server = str(connector.get("server", ""))
    bind_dn = str(connector.get("bind_dn", ""))

    config = {"enabled": enabled, "server": server, "bind_dn": bind_dn}
    _active_directory_connector[cluster_id] = config
    log_audit(
        request.session.get("user", "system"),
        "active_directory.connector",
        f"Updated Active Directory connector for {html.escape(cluster_id)}: enabled={enabled}",
        cluster=cluster_managers[cluster_id].config.name,
    )

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "connector": config,
    })


# In-memory Active Directory sync log.
_active_directory_sync_log = []


def _sync_active_directory_users(cluster_id):
    """Simulate a sync of Active Directory users for the cluster."""
    records = [
        {"username": f"ad-user-{i}", "cluster_id": html.escape(cluster_id)}
        for i in range(3)
    ]
    _active_directory_sync_log.append({
        "cluster_id": html.escape(cluster_id),
        "synced": len(records),
        "timestamp": "2026-09-02T00:00:00",
    })
    return records


@bp.route("/api/clusters/<cluster_id>/active-directory/sync", methods=["POST"])
@require_auth(perms=["active_directory.sync"])
def active_directory_sync(cluster_id):
    """Trigger a sync of Active Directory users for the cluster."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    result = _sync_active_directory_users(cluster_id)
    log_audit(
        request.session.get("user", "system"),
        "active_directory.sync",
        f"Synced {len(result)} Active Directory users for {html.escape(cluster_id)}",
        cluster=cluster_managers[cluster_id].config.name,
    )

    return jsonify({
        "success": True,
        "data": {"synced": result, "total": len(result)},
    })


def _import_active_directory_users(cluster_id, users):
    """Import a list of Active Directory users for the cluster."""
    imported = [
        {
            "username": html.escape(str(user.get("username", f"ad-user-{i}"))),
            "cluster_id": html.escape(cluster_id),
        }
        for i, user in enumerate(users or [])
    ]
    return imported


@bp.route("/api/clusters/<cluster_id>/active-directory/import", methods=["POST"])
@require_auth(perms=["active_directory.import"])
def active_directory_import(cluster_id):
    """Import Active Directory users into the cluster."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    data = request.get_json() or {}
    users = data.get("users", [])
    result = _import_active_directory_users(cluster_id, users)
    log_audit(
        request.session.get("user", "system"),
        "active_directory.import",
        f"Imported {len(result)} Active Directory users for {html.escape(cluster_id)}",
        cluster=cluster_managers[cluster_id].config.name,
    )

    return jsonify({
        "success": True,
        "data": {"imported": result, "total": len(result)},
    })


# In-memory Active Directory template library store.
_active_directory_templates = {}
_active_directory_template_counter = 0


def _create_active_directory_template(cluster_id, name, description):
    """Create a reusable Active Directory template for the cluster."""
    global _active_directory_template_counter
    _active_directory_template_counter += 1
    template_id = f"ad-template-{_active_directory_template_counter}"
    _active_directory_templates[template_id] = {
        "id": template_id,
        "cluster_id": html.escape(cluster_id),
        "name": html.escape(str(name)),
        "description": html.escape(str(description)),
    }
    return _active_directory_templates[template_id]


def _get_active_directory_templates(cluster_id):
    """Return all Active Directory templates for the cluster."""
    return [
        t for t in _active_directory_templates.values()
        if t["cluster_id"] == html.escape(cluster_id)
    ]


@bp.route("/api/clusters/<cluster_id>/active-directory/templates", methods=["GET", "POST"])
@require_auth(perms=["active_directory.templates"])
def active_directory_templates(cluster_id):
    """List or create Active Directory templates for the cluster."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    if request.method == "GET":
        return jsonify({
            "success": True,
            "data": _get_active_directory_templates(cluster_id),
        })

    data = request.get_json() or {}
    name = data.get("name")
    if not name:
        return jsonify({"success": False, "error": "name is required"}), 400
    template = _create_active_directory_template(
        cluster_id, name, data.get("description", "")
    )
    log_audit(
        request.session.get("user", "system"),
        "active_directory.templates",
        f"Created Active Directory template {template['id']} for {html.escape(cluster_id)}",
        cluster=cluster_managers[cluster_id].config.name,
    )
    return jsonify({"success": True, "data": template})


@bp.route("/api/clusters/<cluster_id>/active-directory/widget", methods=["GET"])
@require_auth(perms=["active_directory.widget"])
def active_directory_widget(cluster_id):
    """Return Active Directory widget summary for the cluster."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    widget_data = {
        "cluster": html.escape(cluster_id),
        "status": "active",
        "templates": len(_get_active_directory_templates(cluster_id)),
        "synced": _active_directory_sync_log[-1]["synced"]
        if _active_directory_sync_log
        else 0,
    }

    log_audit(
        request.session.get("user", "system"),
        "active_directory.widget",
        f"Viewed Active Directory widget for {html.escape(cluster_id)}",
        cluster=cluster_managers[cluster_id].config.name,
    )

    return jsonify({"success": True, "data": widget_data})


# In-memory Active Directory alert channel store.
_active_directory_alert_channels = {}


@bp.route("/api/clusters/<cluster_id>/active-directory/alert", methods=["GET", "POST"])
@require_auth(perms=["active_directory.alert"])
def active_directory_alert_channel(cluster_id):
    """Return or update the Active Directory alert channel configuration."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "alert": _active_directory_alert_channels.get(
                cluster_id,
                {"enabled": False, "recipients": []},
            ),
        })

    data = request.get_json() or {}
    alert = data.get("alert", {})
    enabled = bool(alert.get("enabled", False))
    recipients = list(alert.get("recipients", []))

    config = {"enabled": enabled, "recipients": recipients}
    _active_directory_alert_channels[cluster_id] = config
    log_audit(
        request.session.get("user", "system"),
        "active_directory.alert",
        f"Updated Active Directory alert channel for {html.escape(cluster_id)}: enabled={enabled}",
        cluster=cluster_managers[cluster_id].config.name,
    )

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "alert": config,
    })


# In-memory Active Directory policy adapter store.
_active_directory_policy_adapter = {}


@bp.route("/api/clusters/<cluster_id>/active-directory/policy", methods=["GET", "POST"])
@require_auth(perms=["active_directory.policy"])
def active_directory_policy_adapter(cluster_id):
    """Return or update the Active Directory policy adapter configuration."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "policy": _active_directory_policy_adapter.get(
                cluster_id,
                {"enabled": False, "rules": []},
            ),
        })

    data = request.get_json() or {}
    policy = data.get("policy", {})
    enabled = bool(policy.get("enabled", False))
    rules = list(policy.get("rules", []))

    config = {"enabled": enabled, "rules": rules}
    _active_directory_policy_adapter[cluster_id] = config
    log_audit(
        request.session.get("user", "system"),
        "active_directory.policy",
        f"Updated Active Directory policy adapter for {html.escape(cluster_id)}: enabled={enabled}",
        cluster=cluster_managers[cluster_id].config.name,
    )

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "policy": config,
    })


# In-memory Active Directory role mapping store.
_active_directory_role_mappings = {}


@bp.route("/api/clusters/<cluster_id>/active-directory/role-mapping", methods=["GET", "POST"])
@require_auth(perms=["active_directory.role_mapping"])
def active_directory_role_mapping(cluster_id):
    """Return or update Active Directory role mapping for the cluster."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "role_mapping": _active_directory_role_mappings.get(
                cluster_id,
                {"enabled": False, "groups": []},
            ),
        })

    data = request.get_json() or {}
    role_mapping = data.get("role_mapping", {})
    enabled = bool(role_mapping.get("enabled", False))
    groups = list(role_mapping.get("groups", []))

    config = {"enabled": enabled, "groups": groups}
    _active_directory_role_mappings[cluster_id] = config
    log_audit(
        request.session.get("user", "system"),
        "active_directory.role_mapping",
        f"Updated Active Directory role mapping for {html.escape(cluster_id)}: enabled={enabled}",
        cluster=cluster_managers[cluster_id].config.name,
    )

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "role_mapping": config,
    })


# In-memory Active Directory workflow store.
_active_directory_workflows = {}
_active_directory_workflow_counter = 0


def _create_active_directory_workflow(cluster_id, name, steps):
    """Create an Active Directory automation workflow for the cluster."""
    global _active_directory_workflow_counter
    _active_directory_workflow_counter += 1
    workflow_id = f"ad-workflow-{_active_directory_workflow_counter}"
    _active_directory_workflows[workflow_id] = {
        "id": workflow_id,
        "cluster_id": html.escape(cluster_id),
        "name": html.escape(str(name)),
        "steps": list(steps or []),
    }
    return _active_directory_workflows[workflow_id]


def _get_active_directory_workflows(cluster_id):
    """Return all Active Directory workflows for the cluster."""
    return [
        w for w in _active_directory_workflows.values()
        if w["cluster_id"] == html.escape(cluster_id)
    ]


@bp.route("/api/clusters/<cluster_id>/active-directory/workflows", methods=["GET", "POST"])
@require_auth(perms=["active_directory.workflow"])
def active_directory_workflow(cluster_id):
    """List or create Active Directory automation workflows for the cluster."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    if request.method == "GET":
        return jsonify({
            "success": True,
            "data": _get_active_directory_workflows(cluster_id),
        })

    data = request.get_json() or {}
    name = data.get("name")
    if not name:
        return jsonify({"success": False, "error": "name is required"}), 400
    workflow = _create_active_directory_workflow(
        cluster_id, name, data.get("steps", [])
    )
    log_audit(
        request.session.get("user", "system"),
        "active_directory.workflow",
        f"Created Active Directory workflow {workflow['id']} for {html.escape(cluster_id)}",
        cluster=cluster_managers[cluster_id].config.name,
    )
    return jsonify({"success": True, "data": workflow})
