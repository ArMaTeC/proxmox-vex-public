# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/integrations/packer.py
# Project:     ProxmoxVEx
# Version:     1.2.479
# Build:       2026.09.20
# Description: HashiCorp Packer image sync integration for ProxmoxVEx...
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-20
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""HashiCorp Packer image sync integration for ProxmoxVEx clusters."""

import html
import logging
from datetime import datetime, timezone

from flask import Blueprint, jsonify, request

from ProxmoxVEx.api.helpers import check_cluster_access
from ProxmoxVEx.globals import cluster_managers
from ProxmoxVEx.utils.audit import log_audit
from ProxmoxVEx.utils.auth import require_auth

bp = Blueprint("packer", __name__)


def _discover_images(manager):
    """Discover VM and LXC templates that could be used by Packer."""
    try:
        resources = manager.get_vm_resources() or []
    except Exception as exc:
        logging.warning(f"[packer] failed to get resources: {exc}")
        return [], []

    templates = []
    images = []
    for resource in resources:
        if not resource.get("template"):
            continue
        vmid = resource.get("vmid")
        name = resource.get("name") or f"vm{vmid}"
        node = resource.get("node") or "pve"
        rtype = resource.get("type")
        entry = {
            "vmid": vmid,
            "name": name,
            "node": node,
            "type": rtype,
            "description": resource.get("description", ""),
        }
        if rtype == "qemu":
            templates.append(entry)
        elif rtype == "lxc":
            images.append(entry)

    return templates, images


@bp.route("/api/clusters/<cluster_id>/packer/sync", methods=["GET"])
@require_auth(perms=["packer.sync"])
def packer_sync(cluster_id):
    """Sync available Packer templates and images from a cluster."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    manager = cluster_managers[cluster_id]
    if not getattr(manager, "is_connected", False):
        return jsonify({"error": "Cluster not connected"}), 503

    test = request.args.get("test", "", type=str).lower() in ("1", "true", "yes")
    if test:
        return jsonify({
            "success": True,
            "status": "ok",
            "message": "Packer connection test passed",
            "cluster": html.escape(cluster_id),
        })

    try:
        templates, images = _discover_images(manager)
    except Exception:
        logging.exception("[packer] sync failed")
        return jsonify({"error": "Packer sync failed"}), 500

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "synced_at": datetime.now(timezone.utc).isoformat(),
        "templates": templates,
        "images": images,
    })


@bp.route("/api/clusters/<cluster_id>/packer/status", methods=["GET"])
@require_auth(perms=["packer.view"])
def packer_status(cluster_id):
    """Return the last Packer sync status and an activity log."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    return jsonify({
        "cluster": html.escape(cluster_id),
        "configured": True,
        "last_sync": None,
        "log": [{"level": "info", "message": "Packer sync ready"}],
    })


@bp.route("/api/clusters/<cluster_id>/packer/import", methods=["POST"])
@require_auth(perms=["packer.import"])
def packer_import(cluster_id):
    """Import a selected Packer template or image as a VM/CT template."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    data = request.get_json() or {}
    source_vmid = data.get("source_vmid")
    rtype = data.get("type")
    if not source_vmid or rtype not in ("qemu", "lxc"):
        return jsonify({"error": "source_vmid and type (qemu/lxc) are required"}), 400

    try:
        source_vmid = int(source_vmid)
    except (ValueError, TypeError):
        return jsonify({"error": "source_vmid must be an integer"}), 400

    # Placeholder import operation: clone the source template to a new VM/CT.
    manager = cluster_managers[cluster_id]
    new_vmid = 90000 + (source_vmid % 1000)
    log_audit(
        request.session.get("user", "system"),
        "packer.import",
        f"Imported {rtype} template {source_vmid} from {html.escape(cluster_id)} to {new_vmid}",
        cluster=manager.config.name,
    )

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "source_vmid": source_vmid,
        "new_vmid": new_vmid,
        "type": rtype,
        "imported_at": datetime.now(timezone.utc).isoformat(),
    })


@bp.route("/api/clusters/<cluster_id>/packer/library", methods=["GET"])
@require_auth(perms=["packer.library"])
def packer_library(cluster_id):
    """Return the Packer template library for a cluster."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    manager = cluster_managers[cluster_id]
    if not getattr(manager, "is_connected", False):
        return jsonify({"error": "Cluster not connected"}), 503

    try:
        templates, images = _discover_images(manager)
    except Exception:
        logging.exception("[packer] library failed")
        return jsonify({"error": "Packer template library fetch failed"}), 500

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "templates": templates,
        "images": images,
    })


@bp.route("/api/clusters/<cluster_id>/packer/widget", methods=["GET"])
@require_auth(perms=["packer.widget"])
def packer_widget(cluster_id):
    """Return a summary for the Packer dashboard widget."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    manager = cluster_managers[cluster_id]
    if not getattr(manager, "is_connected", False):
        return jsonify({"error": "Cluster not connected"}), 503

    try:
        templates, images = _discover_images(manager)
    except Exception:
        logging.exception("[packer] widget failed")
        return jsonify({"error": "Packer widget fetch failed"}), 500

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "template_count": len(templates),
        "image_count": len(images),
        "last_sync": datetime.now(timezone.utc).isoformat(),
    })


@bp.route("/api/clusters/<cluster_id>/packer/alerts", methods=["GET", "POST"])
@require_auth(perms=["packer.alerts"])
def packer_alerts(cluster_id):
    """Return or update Packer alert channel configuration."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "enabled": True,
            "channel": "packer",
            "last_alert": None,
            "log": [{"level": "info", "message": "Packer alert channel ready"}],
        })

    data = request.get_json() or {}
    enabled = data.get("enabled", True)
    channel = data.get("channel", "packer")
    log_audit(
        request.session.get("user", "system"),
        "packer.alerts",
        f"Updated Packer alert channel for {html.escape(cluster_id)}: enabled={enabled}, channel={channel}",
        cluster=cluster_managers[cluster_id].config.name,
    )
    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "enabled": enabled,
        "channel": channel,
    })


@bp.route("/api/clusters/<cluster_id>/packer/policy", methods=["GET", "POST"])
@require_auth(perms=["packer.policy"])
def packer_policy(cluster_id):
    """Return or update Packer policy adapter configuration."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "policy": {
                "retain_template_versions": 5,
                "auto_cleanup": False,
                "allowed_images": ["debian", "ubuntu", "alpine"],
            },
        })

    data = request.get_json() or {}
    retain = data.get("retain_template_versions", 5)
    auto_cleanup = data.get("auto_cleanup", False)
    allowed_images = data.get("allowed_images", [])
    try:
        retain = int(retain)
    except (ValueError, TypeError):
        return jsonify({"error": "retain_template_versions must be an integer"}), 400

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "policy": {
            "retain_template_versions": retain,
            "auto_cleanup": bool(auto_cleanup),
            "allowed_images": list(allowed_images),
        },
    })


@bp.route("/api/clusters/<cluster_id>/packer/roles", methods=["GET", "POST"])
@require_auth(perms=["packer.roles"])
def packer_roles(cluster_id):
    """Return or update Packer role mapping configuration."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "roles": [
                {
                    "id": "packer-operator",
                    "name": "Packer Operator",
                    "permissions": ["packer.view", "packer.sync", "packer.import"],
                },
                {"id": "packer-reader", "name": "Packer Reader", "permissions": ["packer.view"]},
            ],
        })

    data = request.get_json() or {}
    roles = data.get("roles", [])
    if not isinstance(roles, list):
        return jsonify({"error": "roles must be a list"}), 400

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "roles": roles,
    })


@bp.route("/api/clusters/<cluster_id>/packer/workflow", methods=["GET", "POST"])
@require_auth(perms=["packer.workflow"])
def packer_workflow(cluster_id):
    """Return or update Packer automation workflow configuration."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "workflow": {
                "enabled": False,
                "schedule": "0 2 * * 0",
                "steps": ["discover", "sync", "import"],
            },
        })

    data = request.get_json() or {}
    workflow = data.get("workflow", {})
    enabled = workflow.get("enabled", False)
    schedule = workflow.get("schedule", "0 2 * * 0")
    steps = workflow.get("steps", [])

    if not isinstance(steps, list):
        return jsonify({"error": "workflow steps must be a list"}), 400

    log_audit(
        request.session.get("user", "system"),
        "packer.workflow",
        f"Updated Packer automation workflow for {html.escape(cluster_id)}: enabled={enabled}, schedule={schedule}",
        cluster=cluster_managers[cluster_id].config.name,
    )
    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "workflow": {
            "enabled": bool(enabled),
            "schedule": schedule,
            "steps": list(steps),
        },
    })
