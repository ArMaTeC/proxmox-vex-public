# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/integrations/terraform.py
# Project:     ProxmoxVEx
# Version:     1.2.479
# Build:       2026.09.20
# Description: Terraform HCL export integration for ProxmoxVEx clusters.
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-20
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Terraform HCL export integration for ProxmoxVEx clusters."""

import html
import json
import logging
from datetime import datetime, timezone

from flask import Blueprint, Response, jsonify

from ProxmoxVEx.api.helpers import check_cluster_access
from ProxmoxVEx.globals import cluster_managers
from ProxmoxVEx.utils.auth import require_auth

bp = Blueprint("terraform", __name__)


def _hcl_value(value):
    """Format a Python value as an HCL literal."""
    if isinstance(value, str):
        return json.dumps(value)
    if isinstance(value, bool):
        return "true" if value else "false"
    if value is None:
        return "null"
    return str(value)


def _generate_hcl(cluster_id, resources, manager):
    """Generate Terraform HCL for the given cluster resources."""
    host = "localhost"
    if manager and hasattr(manager, "config"):
        host = getattr(manager.config, "host", "localhost")

    lines = [
        "terraform {",
        "  required_providers {",
        "    proxmox = {",
        '      source  = "Telmate/proxmox"',
        '      version = "2.9.14"',
        "    }",
        "  }",
        "}",
        "",
        'provider "proxmox" {',
        f"  pm_api_url      = {_hcl_value(f'https://{host}:8006/api2/json')}",
        "  pm_tls_insecure = true",
        "}",
        "",
        f"# Exported from ProxmoxVEx at {datetime.now(timezone.utc).isoformat()}",
        "",
    ]

    for resource in resources:
        vmid = resource.get("vmid")
        name = resource.get("name") or f"vm{vmid}"
        node = resource.get("node") or "pve"
        rtype = resource.get("type")

        if rtype == "qemu":
            lines.append(f'resource "proxmox_vm_qemu" "vm_{vmid}" {{')
            lines.append(f"  name        = {_hcl_value(name)}")
            lines.append(f"  target_node = {_hcl_value(node)}")
            lines.append(f"  vmid        = {vmid}")
            maxmem = resource.get("maxmem") or 1073741824
            lines.append(f"  memory      = {int(maxmem) // 1048576}")
            lines.append(f"  cores       = {resource.get('maxcpu') or 1}")
            lines.append("}")
            lines.append("")
        elif rtype == "lxc":
            lines.append(f'resource "proxmox_lxc" "ct_{vmid}" {{')
            lines.append(f"  hostname    = {_hcl_value(name)}")
            lines.append(f"  target_node = {_hcl_value(node)}")
            lines.append(f"  vmid        = {vmid}")
            lines.append('  ostemplate  = "local:vztmpl/debian-12-standard_12.2-1_amd64.tar.zst"')
            lines.append("}")
            lines.append("")

    return "\n".join(lines)


@bp.route("/api/clusters/<cluster_id>/terraform/export", methods=["GET"])
@require_auth(perms=["terraform.export"])
def terraform_export(cluster_id):
    """Export the cluster's VM/LXC resources as Terraform HCL."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return err

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    manager = cluster_managers[cluster_id]
    if not getattr(manager, "is_connected", False):
        return jsonify({"error": "Cluster not connected"}), 503

    try:
        resources = manager.get_vm_resources(max_age=60)
    except Exception as exc:
        logging.warning(f"[terraform] failed to get resources for {cluster_id}: {exc}")
        return jsonify({"error": "Failed to fetch cluster resources"}), 500

    hcl = _generate_hcl(cluster_id, resources, manager)
    safe_id = html.escape(cluster_id).replace('"', "")
    return Response(
        hcl,
        mimetype="text/plain",
        headers={"Content-Disposition": f'attachment; filename="{safe_id}.tf"'},
    )
