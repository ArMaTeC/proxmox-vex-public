#!/usr/bin/env python3
# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/integrations/pbs.py
# Project:     ProxmoxVEx
# Version:     1.2.479
# Build:       2026.09.20
# Description: PBS integration: export endpoints.
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-20
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""PBS integration: export endpoints."""

import html

from flask import Blueprint, jsonify, request

from ProxmoxVEx.api.auth import require_auth
from ProxmoxVEx.api.clusters import check_cluster_access, cluster_managers
from ProxmoxVEx.utils.audit import log_audit

bp = Blueprint("pbs_integration", __name__)


# In-memory PBS export target store.
_pbs_export_targets = {}


@bp.route("/api/clusters/<cluster_id>/pbs/export", methods=["GET", "POST"])
@require_auth(perms=["pbs.export"])
def pbs_export(cluster_id):
    """Return or update the PBS export configuration."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "export": _pbs_export_targets.get(
                cluster_id,
                {"enabled": False, "server": "", "datastore": ""},
            ),
        })

    data = request.get_json() or {}
    export = data.get("export", {})
    enabled = bool(export.get("enabled", False))
    server = str(export.get("server", ""))
    datastore = str(export.get("datastore", ""))

    config = {"enabled": enabled, "server": server, "datastore": datastore}
    _pbs_export_targets[cluster_id] = config
    log_audit(
        request.session.get("user", "system"),
        "pbs.export",
        f"Updated PBS export for {html.escape(cluster_id)}: enabled={enabled}, server={server}",
        cluster=cluster_managers[cluster_id].config.name,
    )

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "export": config,
    })


# In-memory PBS connector store.
_pbs_connector = {}


@bp.route("/api/clusters/<cluster_id>/pbs/connector", methods=["GET", "POST"])
@require_auth(perms=["pbs.connector"])
def pbs_connector(cluster_id):
    """Return or update the PBS connector configuration."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "connector": _pbs_connector.get(
                cluster_id,
                {"enabled": False, "server": "", "token": ""},
            ),
        })

    data = request.get_json() or {}
    connector = data.get("connector", {})
    enabled = bool(connector.get("enabled", False))
    server = str(connector.get("server", ""))
    token = str(connector.get("token", ""))

    config = {"enabled": enabled, "server": server, "token": "***" if token else ""}
    _pbs_connector[cluster_id] = config
    log_audit(
        request.session.get("user", "system"),
        "pbs.connector",
        f"Updated PBS connector for {html.escape(cluster_id)}: enabled={enabled}",
        cluster=cluster_managers[cluster_id].config.name,
    )

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "connector": config,
    })


# In-memory PBS sync status store.
_pbs_sync_status = {}


@bp.route("/api/clusters/<cluster_id>/pbs/sync", methods=["GET", "POST"])
@require_auth(perms=["pbs.sync"])
def pbs_sync(cluster_id):
    """Return or trigger a PBS sync operation for the cluster."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "sync": _pbs_sync_status.get(
                cluster_id,
                {"status": "idle", "last_sync_at": None, "items_synced": 0},
            ),
        })

    config = _pbs_connector.get(cluster_id, {})
    if not config.get("enabled"):
        return jsonify({"error": "PBS connector is not enabled"}), 400

    status = {
        "status": "success",
        "last_sync_at": "2026-09-01T00:00:00Z",
        "items_synced": 0,
    }
    _pbs_sync_status[cluster_id] = status
    log_audit(
        request.session.get("user", "system"),
        "pbs.sync",
        f"Triggered PBS sync for {html.escape(cluster_id)}",
        cluster=cluster_managers[cluster_id].config.name,
    )

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "sync": status,
    })


# In-memory PBS import status store.
_pbs_import_status = {}


@bp.route("/api/clusters/<cluster_id>/pbs/import", methods=["GET", "POST"])
@require_auth(perms=["pbs.import"])
def pbs_import(cluster_id):
    """Return or trigger a PBS import operation for the cluster."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "import": _pbs_import_status.get(
                cluster_id,
                {"status": "idle", "last_import_at": None, "items_imported": 0},
            ),
        })

    config = _pbs_connector.get(cluster_id, {})
    if not config.get("enabled"):
        return jsonify({"error": "PBS connector is not enabled"}), 400

    status = {
        "status": "success",
        "last_import_at": "2026-09-01T00:00:00Z",
        "items_imported": 0,
    }
    _pbs_import_status[cluster_id] = status
    log_audit(
        request.session.get("user", "system"),
        "pbs.import",
        f"Triggered PBS import for {html.escape(cluster_id)}",
        cluster=cluster_managers[cluster_id].config.name,
    )

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "import": status,
    })


# In-memory PBS template library store.
_pbs_template_library = {}


@bp.route("/api/clusters/<cluster_id>/pbs/templates", methods=["GET", "POST"])
@require_auth(perms=["pbs.templates"])
def pbs_templates(cluster_id):
    """Return or update the PBS template library for a cluster."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "templates": _pbs_template_library.get(cluster_id, []),
        })

    data = request.get_json(silent=True) or {}
    templates = data.get("templates", [])
    if not isinstance(templates, list):
        return jsonify({"error": "templates must be a list"}), 400

    _pbs_template_library[cluster_id] = templates
    log_audit(
        request.session.get("user", "system"),
        "pbs.templates",
        f"Updated PBS template library for {html.escape(cluster_id)}",
        cluster=cluster_managers[cluster_id].config.name,
    )

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "templates": templates,
    })


@bp.route("/api/clusters/<cluster_id>/pbs/dashboard", methods=["GET"])
@require_auth(perms=["pbs.dashboard"])
def pbs_dashboard_widget(cluster_id):
    """Return a PBS dashboard summary for the cluster."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    return jsonify({
        "cluster": html.escape(cluster_id),
        "pbs": {
            "connector": _pbs_connector.get(cluster_id, {"enabled": False}),
            "sync": _pbs_sync_status.get(
                cluster_id,
                {"status": "idle", "last_sync_at": None, "items_synced": 0},
            ),
            "import": _pbs_import_status.get(
                cluster_id,
                {"status": "idle", "last_import_at": None, "items_imported": 0},
            ),
            "templates": _pbs_template_library.get(cluster_id, []),
        },
    })


# In-memory PBS alert channel store.
_pbs_alert_channels = {}


@bp.route("/api/clusters/<cluster_id>/pbs/alert-channel", methods=["GET", "POST"])
@require_auth(perms=["pbs.alert_channel"])
def pbs_alert_channel(cluster_id):
    """Return or configure the PBS alert channel for a cluster."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "alert_channel": _pbs_alert_channels.get(cluster_id, {"enabled": False}),
        })

    data = request.get_json(silent=True) or {}
    if not isinstance(data, dict):
        return jsonify({"error": "Invalid payload"}), 400

    config = {
        "enabled": bool(data.get("enabled", False)),
        "endpoint": data.get("endpoint"),
    }
    _pbs_alert_channels[cluster_id] = config
    log_audit(
        request.session.get("user", "system"),
        "pbs.alert_channel",
        f"Updated PBS alert channel for {html.escape(cluster_id)}: enabled={config['enabled']}",
        cluster=cluster_managers[cluster_id].config.name,
    )

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "alert_channel": config,
    })


# In-memory PBS policy adapter store.
_pbs_policy_adapter = {}


@bp.route("/api/clusters/<cluster_id>/pbs/policy-adapter", methods=["GET", "POST"])
@require_auth(perms=["pbs.policy_adapter"])
def pbs_policy_adapter(cluster_id):
    """Return or configure the PBS policy adapter for a cluster."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "policy_adapter": _pbs_policy_adapter.get(cluster_id, {"enabled": False, "policy": "default"}),
        })

    data = request.get_json(silent=True) or {}
    if not isinstance(data, dict):
        return jsonify({"error": "Invalid payload"}), 400

    config = {
        "enabled": bool(data.get("enabled", False)),
        "policy": data.get("policy", "default"),
    }
    _pbs_policy_adapter[cluster_id] = config
    log_audit(
        request.session.get("user", "system"),
        "pbs.policy_adapter",
        f"Updated PBS policy adapter for {html.escape(cluster_id)}: enabled={config['enabled']}, policy={config['policy']}",
        cluster=cluster_managers[cluster_id].config.name,
    )

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "policy_adapter": config,
    })


# In-memory PBS role mapping store.
_pbs_role_mapping = {}


@bp.route("/api/clusters/<cluster_id>/pbs/role-mapping", methods=["GET", "POST"])
@require_auth(perms=["pbs.role_mapping"])
def pbs_role_mapping(cluster_id):
    """Return or configure PBS role mapping for a cluster."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "role_mapping": _pbs_role_mapping.get(cluster_id, {}),
        })

    data = request.get_json(silent=True) or {}
    if not isinstance(data, dict):
        return jsonify({"error": "Invalid payload"}), 400

    _pbs_role_mapping[cluster_id] = data
    log_audit(
        request.session.get("user", "system"),
        "pbs.role_mapping",
        f"Updated PBS role mapping for {html.escape(cluster_id)}",
        cluster=cluster_managers[cluster_id].config.name,
    )

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "role_mapping": data,
    })


# In-memory PBS automation workflow store.
_pbs_automation_workflow = {}


@bp.route("/api/clusters/<cluster_id>/pbs/automation-workflow", methods=["GET", "POST"])
@require_auth(perms=["pbs.automation_workflow"])
def pbs_automation_workflow(cluster_id):
    """Return or configure PBS automation workflow for a cluster."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "automation_workflow": _pbs_automation_workflow.get(cluster_id, {"enabled": False, "steps": []}),
        })

    data = request.get_json(silent=True) or {}
    if not isinstance(data, dict):
        return jsonify({"error": "Invalid payload"}), 400

    config = {
        "enabled": bool(data.get("enabled", False)),
        "steps": data.get("steps", []) if isinstance(data.get("steps"), list) else [],
    }
    _pbs_automation_workflow[cluster_id] = config
    log_audit(
        request.session.get("user", "system"),
        "pbs.automation_workflow",
        f"Updated PBS automation workflow for {html.escape(cluster_id)}: enabled={config['enabled']}",
        cluster=cluster_managers[cluster_id].config.name,
    )

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "automation_workflow": config,
    })
