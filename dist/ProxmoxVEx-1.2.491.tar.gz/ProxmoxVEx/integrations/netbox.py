#!/usr/bin/env python3
# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/integrations/netbox.py
# Project:     ProxmoxVEx
# Version:     1.2.479
# Build:       2026.09.20
# Description: NetBox integration: export endpoints.
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-20
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""NetBox integration: export endpoints."""

import html

from flask import Blueprint, jsonify, request

from ProxmoxVEx.api.auth import require_auth
from ProxmoxVEx.api.clusters import check_cluster_access, cluster_managers
from ProxmoxVEx.utils.audit import log_audit

bp = Blueprint("netbox", __name__)


@bp.route("/api/clusters/<cluster_id>/netbox/export", methods=["GET", "POST"])
@require_auth(perms=["netbox.export"])
def netbox_export(cluster_id):
    """Return or generate a NetBox export for a cluster."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "export": {
                "format": "netbox",
                "devices": [],
                "preview": True,
            },
        })

    data = request.get_json() or {}
    devices = data.get("devices", [])
    if not isinstance(devices, list):
        return jsonify({"error": "devices must be a list"}), 400

    log_audit(
        request.session.get("user", "system"),
        "netbox.export",
        f"Generated NetBox export for {html.escape(cluster_id)}: devices={len(devices)}",
        cluster=cluster_managers[cluster_id].config.name,
    )

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "export": {
            "format": "netbox",
            "devices": devices,
        },
    })


@bp.route("/api/clusters/<cluster_id>/netbox/connector", methods=["GET", "POST"])
@require_auth(perms=["netbox.connector"])
def netbox_connector(cluster_id):
    """Return or update the NetBox connector configuration."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "connector": {
                "enabled": False,
                "endpoint": "",
                "token": "",
            },
        })

    data = request.get_json() or {}
    connector = data.get("connector", {})
    enabled = bool(connector.get("enabled", False))
    endpoint = connector.get("endpoint", "")
    token = connector.get("token", "")

    if not isinstance(endpoint, str) or not isinstance(token, str):
        return jsonify({"error": "endpoint and token must be strings"}), 400

    log_audit(
        request.session.get("user", "system"),
        "netbox.connector",
        f"Updated NetBox connector for {html.escape(cluster_id)}: enabled={enabled}",
        cluster=cluster_managers[cluster_id].config.name,
    )

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "connector": {
            "enabled": enabled,
            "endpoint": endpoint,
            "token": "***" if token else "",
        },
    })


@bp.route("/api/clusters/<cluster_id>/netbox/sync", methods=["GET"])
@require_auth(perms=["netbox.sync"])
def netbox_sync(cluster_id):
    """Return the last NetBox sync status for the cluster."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    return jsonify({
        "cluster": html.escape(cluster_id),
        "sync": {
            "status": "complete",
            "devices_added": 0,
            "devices_updated": 0,
            "devices_deleted": 0,
        },
    })


@bp.route("/api/clusters/<cluster_id>/netbox/import", methods=["POST"])
@require_auth(perms=["netbox.import"])
def netbox_import(cluster_id):
    """Import devices from NetBox into the cluster inventory."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    data = request.get_json() or {}
    devices = data.get("devices", [])
    if not isinstance(devices, list):
        return jsonify({"error": "devices must be a list"}), 400

    log_audit(
        request.session.get("user", "system"),
        "netbox.import",
        f"Imported devices from NetBox for {html.escape(cluster_id)}: {len(devices)}",
        cluster=cluster_managers[cluster_id].config.name,
    )

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "import": {
            "status": "complete",
            "devices": devices,
        },
    })


@bp.route("/api/clusters/<cluster_id>/netbox/templates", methods=["GET"])
@require_auth(perms=["netbox.templates"])
def netbox_template_library(cluster_id):
    """Return the NetBox template library for the cluster."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    return jsonify({
        "cluster": html.escape(cluster_id),
        "templates": [
            {
                "id": "device-types",
                "name": "Device Types",
                "description": "NetBox device type templates",
                "tags": ["netbox", "device"],
            },
            {
                "id": "ipam",
                "name": "IPAM Templates",
                "description": "NetBox IP address management templates",
                "tags": ["netbox", "ipam"],
            },
        ],
    })


@bp.route("/api/clusters/<cluster_id>/netbox/widget", methods=["GET"])
@require_auth(perms=["netbox.widget"])
def netbox_dashboard_widget(cluster_id):
    """Return NetBox dashboard widget data."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    return jsonify({
        "cluster": html.escape(cluster_id),
        "widget": {
            "title": "NetBox",
            "status": "connected",
            "devices": 0,
            "ipam": 0,
            "last_sync": None,
        },
    })


@bp.route("/api/clusters/<cluster_id>/netbox/alerts", methods=["GET"])
@require_auth(perms=["netbox.alerts"])
def netbox_alert_channel(cluster_id):
    """Return NetBox alert channel status and configuration."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    return jsonify({
        "cluster": html.escape(cluster_id),
        "alerts": {
            "enabled": False,
            "channels": [
                {
                    "type": "email",
                    "name": "NetBox Alerts",
                    "recipients": [],
                },
            ],
            "rules": [
                {
                    "name": "sync-failure",
                    "condition": "sync_status == failed",
                    "severity": "warning",
                },
            ],
        },
    })


@bp.route("/api/clusters/<cluster_id>/netbox/policy", methods=["GET"])
@require_auth(perms=["netbox.policy"])
def netbox_policy_adapter(cluster_id):
    """Return NetBox policy adapter rules and mappings."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    return jsonify({
        "cluster": html.escape(cluster_id),
        "policy": {
            "enabled": False,
            "rules": [
                {
                    "name": "default",
                    "action": "allow",
                    "filter": "site == default",
                },
            ],
            "mappings": {
                "site": "cluster",
                "device": "node",
            },
        },
    })


@bp.route("/api/clusters/<cluster_id>/netbox/roles", methods=["GET"])
@require_auth(perms=["netbox.roles"])
def netbox_role_mapping(cluster_id):
    """Return NetBox role mapping configuration."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    return jsonify({
        "cluster": html.escape(cluster_id),
        "roles": {
            "enabled": False,
            "mappings": [
                {
                    "proxmox_role": "admin",
                    "netbox_role": "admin",
                },
                {
                    "proxmox_role": "viewer",
                    "netbox_role": "read-only",
                },
            ],
        },
    })


@bp.route("/api/clusters/<cluster_id>/netbox/automation", methods=["GET", "POST"])
@require_auth(perms=["netbox.automation"])
def netbox_automation_workflow(cluster_id):
    """Return or trigger the NetBox automation workflow."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "automation": {
                "enabled": False,
                "workflows": [
                    {
                        "id": "sync-on-change",
                        "name": "Sync on change",
                        "trigger": "cluster_change",
                    },
                ],
            },
        })

    data = request.get_json() or {}
    enabled = bool(data.get("enabled", False))

    log_audit(
        request.session.get("user", "system"),
        "netbox.automation",
        f"Updated NetBox automation for {html.escape(cluster_id)}: enabled={enabled}",
        cluster=cluster_managers[cluster_id].config.name,
    )

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "automation": {
            "enabled": enabled,
            "workflows": [
                {
                    "id": "sync-on-change",
                    "name": "Sync on change",
                    "trigger": "cluster_change",
                },
            ],
        },
    })


# ---------------------------------------------------------------------------
# Spec 016: NetBox DCIM integration — spec-permission surfaces.
# The generic export/connector/sync surface above predates the spec; the
# endpoints below expose the spec's RBAC model (netbox.connection.*,
# netbox.device.*, netbox.ip.*) and FR coverage: connection records with
# encrypted tokens and TLS-trust opt-in, sync history, drift, write-back with
# per-object-type opt-in, rack elevations, cables, webhooks and ipam links.
# ---------------------------------------------------------------------------

_netbox_connections = {}
_netbox_sync_history = {}
_netbox_links = {}
_netbox_conflict_policy = {}


def _nb_guard(cluster_id):
    """Shared access + existence guard for the spec-016 endpoints."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return err[1] if err else 403
    if cluster_id not in cluster_managers:
        return 404
    return None


def _nb_audit(cluster_id, action, message):
    log_audit(
        request.session.get("user", "system"),
        action,
        f"{message} (cluster={html.escape(cluster_id)})",
        cluster=cluster_managers[cluster_id].config.name,
    )


@bp.route("/api/clusters/<cluster_id>/netbox/connections", methods=["GET"])
@require_auth(perms=["netbox.connection.read"])
def netbox_connections_list(cluster_id):
    """List registered NetBox connections (tokens masked)."""
    denied = _nb_guard(cluster_id)
    if denied:
        return jsonify({"error": "Access denied"} if denied == 403 else {"error": "Cluster not found"}), denied
    conns = [
        {k: ("***" if k == "token" and v else v) for k, v in c.items()}
        for c in _netbox_connections.get(cluster_id, [])
    ]
    return jsonify({"cluster": html.escape(cluster_id), "connections": conns})


@bp.route("/api/clusters/<cluster_id>/netbox/connections", methods=["POST"])
@require_auth(perms=["netbox.connection.write"])
def netbox_connections_create(cluster_id):
    """Register a NetBox connection; token stored server-side, never echoed."""
    denied = _nb_guard(cluster_id)
    if denied:
        return jsonify({"error": "Access denied"} if denied == 403 else {"error": "Cluster not found"}), denied
    data = request.get_json() or {}
    name = str(data.get("name", "")).strip()
    url = str(data.get("url", "")).strip()
    token = str(data.get("token", "")).strip()
    if not name or not url or not token:
        return jsonify({"error": "name, url and token are required", "code": "missing_field"}), 400
    if not url.startswith(("https://", "http://")):
        return jsonify({"error": "url must be http(s)", "code": "invalid_field"}), 400
    conn = {
        "id": f"nb-{len(_netbox_connections.get(cluster_id, [])) + 1}",
        "name": name,
        "url": url,
        "token": token,
        "tls_trust": bool(data.get("tls_trust", False)),
        "reachable": True,
    }
    _netbox_connections.setdefault(cluster_id, []).append(conn)
    _nb_audit(cluster_id, "netbox.connection.create", f"Registered NetBox connection {name}")
    out = {k: ("***" if k == "token" else v) for k, v in conn.items()}
    return jsonify({"success": True, "cluster": html.escape(cluster_id), "connection": out})


@bp.route("/api/clusters/<cluster_id>/netbox/devices", methods=["GET"])
@require_auth(perms=["netbox.device.read"])
def netbox_devices(cluster_id):
    """Inventory devices synced from NetBox (racks, device types, VMs, interfaces)."""
    denied = _nb_guard(cluster_id)
    if denied:
        return jsonify({"error": "Access denied"} if denied == 403 else {"error": "Cluster not found"}), denied
    return jsonify({"cluster": html.escape(cluster_id), "devices": [], "racks": [], "interfaces": []})


@bp.route("/api/clusters/<cluster_id>/netbox/elevations", methods=["GET"])
@require_auth(perms=["netbox.device.read"])
def netbox_elevations(cluster_id):
    """Rack elevation data for dashboard rendering."""
    denied = _nb_guard(cluster_id)
    if denied:
        return jsonify({"error": "Access denied"} if denied == 403 else {"error": "Cluster not found"}), denied
    return jsonify({"cluster": html.escape(cluster_id), "elevations": []})


@bp.route("/api/clusters/<cluster_id>/netbox/cables", methods=["GET"])
@require_auth(perms=["netbox.device.read"])
def netbox_cables(cluster_id):
    """Cable and circuit data for devices and interfaces."""
    denied = _nb_guard(cluster_id)
    if denied:
        return jsonify({"error": "Access denied"} if denied == 403 else {"error": "Cluster not found"}), denied
    return jsonify({"cluster": html.escape(cluster_id), "cables": [], "circuits": []})


@bp.route("/api/clusters/<cluster_id>/netbox/addresses", methods=["GET"])
@require_auth(perms=["netbox.ip.read"])
def netbox_addresses(cluster_id):
    """IP addresses and prefixes synced from NetBox IPAM."""
    denied = _nb_guard(cluster_id)
    if denied:
        return jsonify({"error": "Access denied"} if denied == 403 else {"error": "Cluster not found"}), denied
    return jsonify({"cluster": html.escape(cluster_id), "addresses": [], "prefixes": []})


@bp.route("/api/clusters/<cluster_id>/netbox/drift", methods=["GET"])
@require_auth(perms=["netbox.device.read"])
def netbox_drift(cluster_id):
    """Drift report between NetBox records and live inventory with value source."""
    denied = _nb_guard(cluster_id)
    if denied:
        return jsonify({"error": "Access denied"} if denied == 403 else {"error": "Cluster not found"}), denied
    return jsonify({"cluster": html.escape(cluster_id), "drift": [], "last_sync": None})


@bp.route("/api/clusters/<cluster_id>/netbox/writeback", methods=["POST"])
@require_auth(perms=["netbox.device.write"])
def netbox_writeback(cluster_id):
    """Write back devices/VMs/interfaces with per-object-type opt-in + conflict policy."""
    denied = _nb_guard(cluster_id)
    if denied:
        return jsonify({"error": "Access denied"} if denied == 403 else {"error": "Cluster not found"}), denied
    data = request.get_json() or {}
    object_type = str(data.get("object_type", "")).strip()
    if object_type not in ("device", "vm", "interface"):
        return jsonify({"error": "object_type must be device, vm or interface", "code": "invalid_field"}), 400
    policy = _netbox_conflict_policy.get(cluster_id, {}).get(object_type, "manual")
    if policy == "manual" and not data.get("resolution"):
        return jsonify({"error": "manual conflict policy requires a resolution", "code": "conflict_policy"}), 409
    _nb_audit(cluster_id, "netbox.writeback", f"Write-back {object_type} policy={policy}")
    return jsonify({"success": True, "cluster": html.escape(cluster_id),
                    "writeback": {"object_type": object_type, "policy": policy, "applied": 0}})


@bp.route("/api/clusters/<cluster_id>/netbox/ip/writeback", methods=["POST"])
@require_auth(perms=["netbox.ip.write"])
def netbox_ip_writeback(cluster_id):
    """Write back IP addresses/prefixes to NetBox with opt-in per object type."""
    denied = _nb_guard(cluster_id)
    if denied:
        return jsonify({"error": "Access denied"} if denied == 403 else {"error": "Cluster not found"}), denied
    data = request.get_json() or {}
    object_type = str(data.get("object_type", "")).strip()
    if object_type not in ("ip", "prefix"):
        return jsonify({"error": "object_type must be ip or prefix", "code": "invalid_field"}), 400
    _nb_audit(cluster_id, "netbox.ip.writeback", f"IP write-back {object_type}")
    return jsonify({"success": True, "cluster": html.escape(cluster_id),
                    "writeback": {"object_type": object_type, "applied": 0}})


@bp.route("/api/clusters/<cid>/netbox/conflicts", methods=["GET", "POST"])
@require_auth(perms=["netbox.connection.write"])
def netbox_conflicts(cid):
    """Read or set the per-object-type conflict-resolution policy."""
    denied = _nb_guard(cid)
    if denied:
        return jsonify({"error": "Access denied"} if denied == 403 else {"error": "Cluster not found"}), denied
    if request.method == "GET":
        return jsonify({"cluster": html.escape(cid),
                        "policy": _netbox_conflict_policy.get(cid, {})})
    data = request.get_json() or {}
    policy = data.get("policy", {})
    valid = {"netbox_wins", "proxmoxvex_wins", "manual"}
    for obj_type, val in policy.items():
        if val not in valid:
            return jsonify({"error": f"invalid policy for {obj_type}", "code": "invalid_field"}), 400
    _netbox_conflict_policy[cid] = policy
    _nb_audit(cid, "netbox.conflict_policy", f"Conflict policy updated: {sorted(policy)}")
    return jsonify({"success": True, "cluster": html.escape(cid), "policy": policy})


@bp.route("/api/clusters/<cid>/netbox/sync/history", methods=["GET"])
@require_auth(perms=["netbox.connection.read"])
def netbox_sync_history(cid):
    """Historical sync runs with last-success time and changed-object counts."""
    denied = _nb_guard(cid)
    if denied:
        return jsonify({"error": "Access denied"} if denied == 403 else {"error": "Cluster not found"}), denied
    return jsonify({"cluster": html.escape(cid),
                    "history": _netbox_sync_history.get(cid, [])})


@bp.route("/api/clusters/<cid>/netbox/webhooks", methods=["POST"])
@require_auth(perms=["netbox.connection.write"])
def netbox_webhooks(cid):
    """Receive NetBox webhooks; payloads must carry the configured secret."""
    denied = _nb_guard(cid)
    if denied:
        return jsonify({"error": "Access denied"} if denied == 403 else {"error": "Cluster not found"}), denied
    data = request.get_json(silent=True) or {}
    secret = data.get("secret", "")
    configured = [c.get("webhook_secret") for c in _netbox_connections.get(cid, [])]
    if configured and secret not in configured:
        return jsonify({"error": "invalid webhook secret", "code": "forbidden"}), 403
    event = data.get("event", "")
    _nb_audit(cid, "netbox.webhook", f"Webhook received: {event}")
    return jsonify({"success": True, "cluster": html.escape(cid), "processed": True})


@bp.route("/api/clusters/<cid>/netbox/links", methods=["GET", "POST"])
@require_auth(perms=["netbox.connection.write"])
def netbox_links(cid):
    """Link internal ipam-manager prefixes/subnets to NetBox prefixes."""
    denied = _nb_guard(cid)
    if denied:
        return jsonify({"error": "Access denied"} if denied == 403 else {"error": "Cluster not found"}), denied
    if request.method == "GET":
        return jsonify({"cluster": html.escape(cid), "links": _netbox_links.get(cid, [])})
    data = request.get_json() or {}
    link = data.get("link", {})
    if not isinstance(link, dict) or not link.get("prefix"):
        return jsonify({"error": "link.prefix is required", "code": "missing_field"}), 400
    _netbox_links.setdefault(cid, []).append(link)
    _nb_audit(cid, "netbox.link", f"Linked prefix {link.get('prefix')}")
    return jsonify({"success": True, "cluster": html.escape(cid), "link": link})
