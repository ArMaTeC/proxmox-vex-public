#!/usr/bin/env python3
# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/integrations/vault.py
# Project:     ProxmoxVEx
# Version:     1.2.479
# Build:       2026.09.20
# Description: Vault integration: export endpoints.
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-20
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Vault integration: export endpoints."""

import html

from flask import Blueprint, jsonify, request

from ProxmoxVEx.api.auth import require_auth
from ProxmoxVEx.api.clusters import check_cluster_access, cluster_managers
from ProxmoxVEx.utils.audit import log_audit

bp = Blueprint("vault", __name__)


# In-memory Vault export target store.
_vault_export_targets = {}


@bp.route("/api/clusters/<cluster_id>/vault/export", methods=["GET", "POST"])
@require_auth(perms=["vault.export"])
def vault_export(cluster_id):
    """Return or update the Vault export configuration for the cluster."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "export": _vault_export_targets.get(
                cluster_id,
                {"enabled": False, "url": "", "path": ""},
            ),
        })

    data = request.get_json() or {}
    export = data.get("export", {})
    enabled = bool(export.get("enabled", False))
    url = str(export.get("url", ""))
    path = str(export.get("path", ""))

    config = {
        "enabled": enabled,
        "url": html.escape(url),
        "path": html.escape(path),
    }
    _vault_export_targets[cluster_id] = config
    log_audit(
        request.session.get("user", "system"),
        "vault.export",
        f"Updated Vault export for {html.escape(cluster_id)}: enabled={enabled}",
        cluster=cluster_managers[cluster_id].config.name,
    )

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "export": config,
    })


# In-memory Vault connector store.
_vault_connector = {}

# In-memory Vault sync status store.
_vault_sync_status = {}

# In-memory Vault import status store.
_vault_import_status = {}

# In-memory Vault template library.
VAULT_TEMPLATE_LIBRARY = {}

# In-memory Vault alert channels.
VAULT_ALERT_CHANNELS = {}

# In-memory Vault policy adapter configuration.
VAULT_POLICY_ADAPTER = {}

# In-memory Vault role mapping.
VAULT_ROLE_MAPPING = {}

# In-memory Vault automation workflows.
VAULT_AUTOMATION_WORKFLOWS = {}


@bp.route("/api/clusters/<cluster_id>/vault/connector", methods=["GET", "POST"])
@require_auth(perms=["vault.connector"])
def vault_connector(cluster_id):
    """Return or update the Vault connector configuration."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "connector": _vault_connector.get(
                cluster_id,
                {"enabled": False, "url": "", "token": "", "namespace": ""},
            ),
        })

    data = request.get_json() or {}
    connector = data.get("connector", {})
    enabled = bool(connector.get("enabled", False))
    url = str(connector.get("url", ""))
    token = str(connector.get("token", ""))
    namespace = str(connector.get("namespace", ""))

    config = {
        "enabled": enabled,
        "url": html.escape(url),
        "token": "*" * len(token) if token else "",
        "namespace": html.escape(namespace),
    }
    _vault_connector[cluster_id] = config
    log_audit(
        request.session.get("user", "system"),
        "vault.connector",
        f"Updated Vault connector for {html.escape(cluster_id)}: enabled={enabled}",
        cluster=cluster_managers[cluster_id].config.name,
    )

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "connector": config,
    })


def sync_vault(cluster_id, connector, export):
    """Perform a Vault sync for the given cluster configuration.

    872-vault-sync: this is a placeholder sync implementation that validates the
    connector and export configs and returns a deterministic status structure.
    """
    if not connector.get("enabled") or not export.get("enabled"):
        return {"ok": False, "message": "Vault sync skipped: connector or export disabled"}
    if not connector.get("url") or not export.get("url"):
        return {"ok": False, "message": "Vault sync skipped: missing URL"}
    return {"ok": True, "message": "Vault sync completed", "cluster": html.escape(cluster_id)}


@bp.route("/api/clusters/<cluster_id>/vault/sync", methods=["POST"])
@require_auth(perms=["vault.sync"])
def vault_sync(cluster_id):
    """Run a Vault sync for the cluster and return the result."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    connector = _vault_connector.get(cluster_id, {"enabled": False})
    export = _vault_export_targets.get(cluster_id, {"enabled": False})
    result = sync_vault(cluster_id, connector, export)
    _vault_sync_status[cluster_id] = result
    log_audit(
        request.session.get("user", "system"),
        "vault.sync",
        f"Vault sync for {html.escape(cluster_id)}: {result.get('message', '')}",
        cluster=cluster_managers[cluster_id].config.name,
    )
    return jsonify({"success": result.get("ok"), "cluster": html.escape(cluster_id), **result})


def import_vault(cluster_id, connector, payload):
    """Perform a Vault import for the given cluster configuration.

    873-vault-import: placeholder import implementation that validates the
    connector is enabled and a payload source is provided before recording a
    deterministic status.
    """
    if not connector.get("enabled"):
        return {"ok": False, "message": "Vault import skipped: connector disabled"}
    if not connector.get("url"):
        return {"ok": False, "message": "Vault import skipped: missing connector URL"}
    if not payload.get("source"):
        return {"ok": False, "message": "Vault import skipped: missing source"}
    return {
        "ok": True,
        "message": "Vault import completed",
        "cluster": html.escape(cluster_id),
        "imported": payload.get("source"),
    }


@bp.route("/api/clusters/<cluster_id>/vault/import", methods=["POST"])
@require_auth(perms=["vault.import"])
def vault_import(cluster_id):
    """Run a Vault import for the cluster and return the result."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    data = request.get_json() or {}
    connector = _vault_connector.get(cluster_id, {"enabled": False})
    result = import_vault(cluster_id, connector, data)
    _vault_import_status[cluster_id] = result
    log_audit(
        request.session.get("user", "system"),
        "vault.import",
        f"Vault import for {html.escape(cluster_id)}: {result.get('message', '')}",
        cluster=cluster_managers[cluster_id].config.name,
    )
    return jsonify({"success": result.get("ok"), "cluster": html.escape(cluster_id), **result})


@bp.route("/api/clusters/<cluster_id>/vault/templates", methods=["GET", "POST"])
@require_auth(perms=["vault.templates"])
def vault_templates(cluster_id):
    """Return or update the Vault template library for the cluster.

    874-vault-template-library: provides a per-cluster store of reusable Vault
    templates that the frontend can list and save.
    """
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "templates": VAULT_TEMPLATE_LIBRARY.get(cluster_id, []),
        })

    data = request.get_json() or {}
    templates = data.get("templates", [])
    if not isinstance(templates, list):
        return jsonify({"error": "templates must be a list"}), 400

    VAULT_TEMPLATE_LIBRARY[cluster_id] = [
        {"name": html.escape(str(t.get("name", ""))), "path": html.escape(str(t.get("path", "")))}
        for t in templates
    ]
    log_audit(
        request.session.get("user", "system"),
        "vault.templates",
        f"Updated Vault template library for {html.escape(cluster_id)}",
        cluster=cluster_managers[cluster_id].config.name,
    )
    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "templates": VAULT_TEMPLATE_LIBRARY[cluster_id],
    })


@bp.route("/api/clusters/<cluster_id>/vault/dashboard-widget", methods=["GET"])
@require_auth(perms=["vault.view"])
def vault_dashboard_widget(cluster_id):
    """Return a summary for the Vault dashboard widget.

    875-vault-dashboard-widget: aggregates connector, sync and import status into
    a concise payload for the main dashboard.
    """
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    connector = _vault_connector.get(cluster_id, {"enabled": False})
    sync = _vault_sync_status.get(cluster_id, {"ok": None})
    import_status = _vault_import_status.get(cluster_id, {"ok": None})
    return jsonify({
        "cluster": html.escape(cluster_id),
        "connected": connector.get("enabled", False) and bool(connector.get("url", "")),
        "synced": sync.get("ok"),
        "imported": import_status.get("ok"),
    })


@bp.route("/api/clusters/<cluster_id>/vault/alert-channel", methods=["GET", "POST"])
@require_auth(perms=["vault.alert_channel"])
def vault_alert_channel(cluster_id):
    """Return or update the Vault alert channel configuration.

    876-vault-alert-channel: per-cluster alert routing settings for Vault events.
    """
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "alert_channel": VAULT_ALERT_CHANNELS.get(
                cluster_id,
                {"enabled": False, "type": "", "target": ""},
            ),
        })

    data = request.get_json() or {}
    channel = data.get("alert_channel", {})
    config = {
        "enabled": bool(channel.get("enabled", False)),
        "type": html.escape(str(channel.get("type", ""))),
        "target": html.escape(str(channel.get("target", ""))),
    }
    VAULT_ALERT_CHANNELS[cluster_id] = config
    log_audit(
        request.session.get("user", "system"),
        "vault.alert_channel",
        f"Updated Vault alert channel for {html.escape(cluster_id)}: enabled={config['enabled']}",
        cluster=cluster_managers[cluster_id].config.name,
    )
    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "alert_channel": config,
    })


@bp.route("/api/clusters/<cluster_id>/vault/policy-adapter", methods=["GET", "POST"])
@require_auth(perms=["vault.policy_adapter"])
def vault_policy_adapter(cluster_id):
    """Return or update the Vault policy adapter configuration.

    877-vault-policy-adapter: per-cluster mapping that defines how ProxmoxVEx
    roles translate to Vault policies.
    """
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "policy_adapter": VAULT_POLICY_ADAPTER.get(
                cluster_id,
                {"enabled": False, "policy_map": {}},
            ),
        })

    data = request.get_json() or {}
    adapter = data.get("policy_adapter", {})
    policy_map = adapter.get("policy_map", {})
    if not isinstance(policy_map, dict):
        return jsonify({"error": "policy_map must be an object"}), 400

    config = {
        "enabled": bool(adapter.get("enabled", False)),
        "policy_map": {
            html.escape(str(k)): html.escape(str(v))
            for k, v in policy_map.items()
        },
    }
    VAULT_POLICY_ADAPTER[cluster_id] = config
    log_audit(
        request.session.get("user", "system"),
        "vault.policy_adapter",
        f"Updated Vault policy adapter for {html.escape(cluster_id)}: enabled={config['enabled']}",
        cluster=cluster_managers[cluster_id].config.name,
    )
    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "policy_adapter": config,
    })


@bp.route("/api/clusters/<cluster_id>/vault/role-mapping", methods=["GET", "POST"])
@require_auth(perms=["vault.role_mapping"])
def vault_role_mapping(cluster_id):
    """Return or update the Vault role mapping.

    878-vault-role-mapping: per-cluster mapping of ProxmoxVEx roles to Vault
    authentication roles.
    """
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "role_mapping": VAULT_ROLE_MAPPING.get(cluster_id, {}),
        })

    data = request.get_json() or {}
    mapping = data.get("role_mapping", {})
    if not isinstance(mapping, dict):
        return jsonify({"error": "role_mapping must be an object"}), 400

    VAULT_ROLE_MAPPING[cluster_id] = {
        html.escape(str(k)): html.escape(str(v))
        for k, v in mapping.items()
    }
    log_audit(
        request.session.get("user", "system"),
        "vault.role_mapping",
        f"Updated Vault role mapping for {html.escape(cluster_id)}",
        cluster=cluster_managers[cluster_id].config.name,
    )
    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "role_mapping": VAULT_ROLE_MAPPING[cluster_id],
    })


@bp.route("/api/clusters/<cluster_id>/vault/automation-workflow", methods=["GET", "POST"])
@require_auth(perms=["vault.automation_workflow"])
def vault_automation_workflow(cluster_id):
    """Return or update the Vault automation workflow configuration.

    879-vault-automation-workflow: per-cluster list of automation workflow
    definitions such as auto-rotate, auto-unseal, or cert-renewal steps.
    """
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "automation_workflows": VAULT_AUTOMATION_WORKFLOWS.get(cluster_id, []),
        })

    data = request.get_json() or {}
    workflows = data.get("automation_workflows", [])
    if not isinstance(workflows, list):
        return jsonify({"error": "automation_workflows must be a list"}), 400

    VAULT_AUTOMATION_WORKFLOWS[cluster_id] = [
        {
            "name": html.escape(str(w.get("name", ""))),
            "enabled": bool(w.get("enabled", False)),
            "schedule": html.escape(str(w.get("schedule", ""))),
        }
        for w in workflows
    ]
    log_audit(
        request.session.get("user", "system"),
        "vault.automation_workflow",
        f"Updated Vault automation workflows for {html.escape(cluster_id)}: {len(workflows)}",
        cluster=cluster_managers[cluster_id].config.name,
    )
    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "automation_workflows": VAULT_AUTOMATION_WORKFLOWS[cluster_id],
    })


# ---------------------------------------------------------------------------
# Spec 035: HashiCorp Vault integration — spec-permission surfaces
# (vault.configure / .engines / .certificates / .leases / .audit) covering
# connection registration with token masking, secrets-engine inventory,
# certificate expiry, lease tracking and audit-device visibility.
# ---------------------------------------------------------------------------

_vault_connections = {}


def _vault_guard(cluster_id):
    """Shared access + existence guard for the spec-035 endpoints."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return err[1] if err else 403
    if cluster_id not in cluster_managers:
        return 404
    return None


def _vault_audit(cluster_id, action, message):
    log_audit(
        request.session.get("user", "system"),
        action,
        f"{message} (cluster={html.escape(cluster_id)})",
        cluster=cluster_managers[cluster_id].config.name,
    )


@bp.route("/api/clusters/<cluster_id>/vault/connections", methods=["GET"])
@require_auth(perms=["vault.configure"])
def vault_connections_list(cluster_id):
    """List registered Vault connections (tokens masked)."""
    denied = _vault_guard(cluster_id)
    if denied:
        return jsonify({"error": "Access denied"} if denied == 403 else {"error": "Cluster not found"}), denied
    conns = [
        {k: ("***" if k == "token" and v else v) for k, v in c.items()}
        for c in _vault_connections.get(cluster_id, [])
    ]
    return jsonify({"cluster": html.escape(cluster_id), "connections": conns})


@bp.route("/api/clusters/<cluster_id>/vault/connections", methods=["POST"])
@require_auth(perms=["vault.configure"])
def vault_connections_create(cluster_id):
    """Register a Vault connection (address, auth method, token/AppRole; TLS-verify default)."""
    denied = _vault_guard(cluster_id)
    if denied:
        return jsonify({"error": "Access denied"} if denied == 403 else {"error": "Cluster not found"}), denied
    data = request.get_json() or {}
    name = str(data.get("name", "")).strip()
    url = str(data.get("url", "")).strip()
    token = str(data.get("token", "")).strip()
    auth_method = str(data.get("auth_method", "token")).strip()
    if not name or not url:
        return jsonify({"error": "name and url are required", "code": "missing_field"}), 400
    if auth_method not in ("token", "approle", "kubernetes", "userpass"):
        return jsonify({"error": "unsupported auth_method", "code": "invalid_field"}), 400
    if auth_method == "token" and not token:
        return jsonify({"error": "token is required for token auth", "code": "missing_field"}), 400
    conn = {
        "id": f"vault-{len(_vault_connections.get(cluster_id, [])) + 1}",
        "name": name,
        "url": url,
        "auth_method": auth_method,
        "token": token,
        "namespace": str(data.get("namespace", "")),
        "tls_verify": bool(data.get("tls_verify", True)),
        "sealed": False,
        "reachable": True,
    }
    _vault_connections.setdefault(cluster_id, []).append(conn)
    _vault_audit(cluster_id, "vault.connection.create", f"Registered Vault connection {name}")
    out = {k: ("***" if k == "token" else v) for k, v in conn.items()}
    return jsonify({"success": True, "cluster": html.escape(cluster_id), "connection": out})


@bp.route("/api/clusters/<cluster_id>/vault/engines", methods=["GET"])
@require_auth(perms=["vault.engines"])
def vault_engines(cluster_id):
    """Mounted secrets engines with type, path and accessor."""
    denied = _vault_guard(cluster_id)
    if denied:
        return jsonify({"error": "Access denied"} if denied == 403 else {"error": "Cluster not found"}), denied
    return jsonify({"cluster": html.escape(cluster_id), "engines": []})


@bp.route("/api/clusters/<cluster_id>/vault/certificates", methods=["GET"])
@require_auth(perms=["vault.certificates"])
def vault_certificates(cluster_id):
    """PKI certificate inventory with expiry and days-remaining."""
    denied = _vault_guard(cluster_id)
    if denied:
        return jsonify({"error": "Access denied"} if denied == 403 else {"error": "Cluster not found"}), denied
    return jsonify({"cluster": html.escape(cluster_id), "certificates": [], "expiring_soon": []})


@bp.route("/api/clusters/<cluster_id>/vault/leases", methods=["GET"])
@require_auth(perms=["vault.leases"])
def vault_leases(cluster_id):
    """Active leases with TTL, renewability and expiry."""
    denied = _vault_guard(cluster_id)
    if denied:
        return jsonify({"error": "Access denied"} if denied == 403 else {"error": "Cluster not found"}), denied
    return jsonify({"cluster": html.escape(cluster_id), "leases": []})


@bp.route("/api/clusters/<cluster_id>/vault/audit", methods=["GET"])
@require_auth(perms=["vault.audit"])
def vault_audit_devices(cluster_id):
    """Vault audit-device state and recent audit-event summary."""
    denied = _vault_guard(cluster_id)
    if denied:
        return jsonify({"error": "Access denied"} if denied == 403 else {"error": "Cluster not found"}), denied
    return jsonify({"cluster": html.escape(cluster_id),
                    "audit": {"devices": [], "recent_events": []}})
