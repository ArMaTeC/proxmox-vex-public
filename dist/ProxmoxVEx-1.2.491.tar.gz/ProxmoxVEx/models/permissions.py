# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/models/permissions.py
# Project:     ProxmoxVEx
# Version:     1.2.479
# Build:       2026.09.20
# Description: ProxmoxVEx Permissions & Roles - Layer 0
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-20
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""
ProxmoxVEx Permissions & Roles - Layer 0
No ProxmoxVEx imports allowed.
"""

# User roles
ROLE_ADMIN = "admin"
ROLE_USER = "user"
ROLE_VIEWER = "viewer"
# Read-only role reserved for the auto-provisioned demo sandbox account
# (spec 037). Granted only viewer-level permissions; the demo guard blocks
# all mutating API calls before RBAC is even consulted.
ROLE_DEMO_VIEWER = "demo-viewer"

# Builtin roles - cannot be deleted
BUILTIN_ROLES = [ROLE_ADMIN, ROLE_USER, ROLE_VIEWER, ROLE_DEMO_VIEWER]

PERMISSIONS = {
    # vm stuff
    "vm.view": "View VMs and containers",
    "vm.start": "Start VMs and containers",
    "vm.stop": "Stop VMs and containers",
    "vm.restart": "Restart VMs and containers",
    "vm.console": "Access VM console",
    "vm.migrate": "Migrate VMs between nodes",
    "vm.clone": "Clone VMs",
    "vm.delete": "Delete VMs and containers",
    "vm.create": "Create new VMs and containers",
    "vm.config": "Modify VM configuration",
    "vm.snapshot": "Create/delete snapshots",
    "vm.backup": "Backup VMs",
    "vm.template": "Convert to/from template",
    # Converter permissions
    "converter.view": "View conversion/resize jobs and presets",
    "converter.run": "Run conversion/resize jobs",
    "converter.admin": "Manage converter presets, hooks, and cancel any job",
    # Cluster permissions
    "cluster.view": "View cluster info",
    "cluster.add": "Add new clusters",
    "cluster.delete": "Remove clusters",
    "cluster.config": "Modify cluster settings",
    "cluster.join": "Join nodes to cluster",
    "cluster.admin": "Full cluster administration (join/remove nodes)",
    # Node permissions
    "node.view": "View node status",
    "node.shell": "Access node shell",
    "node.maintenance": "Toggle maintenance mode",
    "node.update": "Update node packages",
    "node.reboot": "Reboot nodes",
    "node.network": "Modify network config",
    "node.config": "Change node options",
    "node.certificate": "Manage SSL certificates",
    "node.power": "Shutdown/wake nodes",
    # Storage permissions
    "storage.view": "View storage",
    "storage.upload": "Upload files to storage",
    "storage.delete": "Delete files from storage",
    "storage.config": "Modify storage config",
    "storage.create": "Add new storage",
    "storage.download": "Download ISOs/templates",
    # Backup permissions
    "backup.view": "View backups",
    "backup.create": "Create backups",
    "backup.restore": "Restore from backup",
    "backup.delete": "Delete backups",
    "backup.schedule": "Manage backup schedules",
    "backup.config": "Configure backup storage",
    # HA permissions
    "ha.view": "View HA status",
    "ha.config": "Configure HA settings",
    "ha.groups": "Manage HA groups",
    "ha.resources": "Add/remove HA resources",
    # Firewall permissions
    "firewall.view": "View firewall rules",
    "firewall.edit": "Modify firewall rules",
    "firewall.aliases": "Manage aliases/IPsets",
    # Pool/Resource permissions
    "pool.view": "View resource pools",
    "pool.manage": "Create/delete pools",
    "pool.assign": "Assign VMs to pools",
    # Replication
    "replication.view": "View replication jobs",
    "replication.manage": "Create/delete replication",
    # Ceph
    "ceph.manage": "Manage Ceph OSD, pools, monitors, MDS",
    # SDN
    "sdn.manage": "Manage SDN zones, vnets, subnets, controllers",
    # Alerts
    "alert.manage": "Create, edit, delete alert rules",
    # IDS/IPS permissions
    "ids.view": "View IDS/IPS alerts, rules, and reports",
    "ids.rules": "Create, edit, and delete IDS/IPS detection rules",
    "ids.policies": "Create, edit, and delete IDS/IPS response policies",
    "ids.admin": "Manage IDS/IPS configuration and monitored segments",
    # Site Recovery - Mar 2026
    "site_recovery.view": "View recovery plans and events",
    "site_recovery.manage": "Create/edit/delete recovery plans and VMs",
    "site_recovery.failover": "Execute failover, failback and test operations",
    # Terraform / IaC permissions
    "terraform.view": "View Terraform exports",
    "terraform.export": "Export cluster state to Terraform HCL",
    # Ansible / IaC permissions
    "ansible.view": "View Ansible exports",
    "ansible.export": "Export cluster state to Ansible playbooks",
    # Packer / IaC permissions
    "packer.view": "View Packer sync status",
    "packer.sync": "Sync Packer templates and images",
    "packer.import": "Import Packer templates and images",
    "packer.library": "View Packer template library",
    "packer.widget": "View Packer dashboard widget",
    "packer.alerts": "Manage Packer alert channel",
    "packer.policy": "Manage Packer policy adapter",
    "packer.roles": "Manage Packer role mapping",
    "packer.workflow": "Manage Packer automation workflow",
    # Kubernetes / integrations permissions
    "kubernetes.view": "View Kubernetes clusters and resources",
    "kubernetes.export": "Export cluster state to Kubernetes manifests",
    "kubernetes.connector": "Manage Kubernetes connector configuration",
    "kubernetes.sync": "Sync cluster state to Kubernetes",
    "kubernetes.import": "Import Kubernetes manifests into the cluster",
    "kubernetes.library": "View Kubernetes template library",
    "kubernetes.widget": "View Kubernetes dashboard widget",
    "kubernetes.dashboard": "View Kubernetes dashboard widget",
    "kubernetes.alerts": "Manage Kubernetes alert channel",
    "kubernetes.policy": "Manage Kubernetes policy adapter",
    "kubernetes.roles": "Manage Kubernetes role mapping",
    "kubernetes.workflow": "Manage Kubernetes automation workflow",
    # Docker / integrations permissions
    "docker.export": "Export cluster state to Docker assets",
    "docker.connector": "Manage Docker connector configuration",
    # Plugin permissions
    "plugins.view": "View installed plugins",
    "plugins.manage": "Enable, disable and configure plugins",
    # LDAP permissions
    "ldap.export": "Export cluster state to LDAP assets",
    "ldap.connector": "Manage LDAP connector configuration",
    "ldap.sync": "Sync users from LDAP",
    "ldap.import": "Import users from LDAP",
    "ldap.templates": "Manage LDAP templates",
    "ldap.widget": "View LDAP dashboard widget",
    "ldap.alert": "Manage LDAP alert channel",
    "ldap.policy": "Manage LDAP policy adapter",
    "ldap.role_mapping": "Manage LDAP role mapping",
    "ldap.workflow": "Manage LDAP automation workflows",
    # Active Directory permissions
    "active_directory.export": "Export cluster state to Active Directory assets",
    "active_directory.connector": "Manage Active Directory connector configuration",
    "active_directory.sync": "Sync users from Active Directory",
    "active_directory.import": "Import users from Active Directory",
    "active_directory.templates": "Manage Active Directory templates",
    "active_directory.widget": "View Active Directory dashboard widget",
    "active_directory.alert": "Manage Active Directory alert channel",
    "active_directory.policy": "Manage Active Directory policy adapter",
    "active_directory.role_mapping": "Manage Active Directory role mapping",
    "active_directory.workflow": "Manage Active Directory automation workflows",
    "vault.export": "Export cluster state to Vault",
    "vault.connector": "Manage Vault connector configuration",
    # Vendor integration permissions (specs 018-034)
    "ceph_external.connector": "Manage external Ceph cluster connections",
    "ceph_external.view": "View external Ceph health, OSDs, pools and capacity",
    "ceph_external.osd.manage": "Run gated OSD out/reweight operations on external Ceph",
    "synology.connector": "Manage Synology DSM connections and datastore links",
    "synology.view": "View Synology devices, storage, shares, services and backups",
    "routeros.connector": "Manage MikroTik RouterOS device connections",
    "routeros.view": "View RouterOS interfaces, routes, tunnels and health",
    "routeros.backup": "Run RouterOS configuration backups",
    "cisco.connector": "Manage Cisco device connections",
    "cisco.view": "View Cisco interfaces, fabric topology and chassis health",
    "cisco.backup": "Run Cisco configuration backups",
    "cisco.interface.admin": "Change Cisco interface admin state",
    "eos.connector": "Manage Arista EOS device connections",
    "eos.view": "View Arista interfaces, fabric and environment state",
    "eos.backup": "Run Arista EOS configuration backups",
    "junos.connector": "Manage Juniper Junos device connections",
    "junos.view": "View Junos interfaces, routing and chassis state",
    "junos.backup": "Run Junos configuration backups",
    "tailscale.connector": "Manage Tailscale tailnet connections and workload links",
    "tailscale.view": "View tailnet devices, routers and policy drift",
    "wireguard.connector": "Manage WireGuard host connections",
    "wireguard.view": "View WireGuard interfaces, peers and tunnel health",
    "wireguard.peer.manage": "Add/remove WireGuard peers and generate client configs",
    "metrics.victoriametrics.connector": "Manage VictoriaMetrics connections",
    "metrics.victoriametrics.query": "Run MetricsQL/PromQL queries against VictoriaMetrics",
    "metrics.victoriametrics.widget": "View VictoriaMetrics health and dashboard widgets",
    "uptimekuma.connector": "Manage Uptime Kuma instances, links and maintenance windows",
    "uptimekuma.view": "View Uptime Kuma monitors, heartbeats and alerts",
    "uptimekuma.monitor.create": "Create Uptime Kuma monitors from the service catalog",
    "freeipa.configure": "Manage FreeIPA connections and provider settings",
    "freeipa.user": "View FreeIPA users and sync state",
    "freeipa.group": "View FreeIPA groups and role mappings",
    "freeipa.host": "View FreeIPA enrolled hosts and DNS",
    "freeipa.hbac": "View FreeIPA HBAC rules",
    "freeipa.sudo": "View FreeIPA sudo rules",
    "freeipa.topology": "View FreeIPA replication topology",
    "freeipa.cert": "View FreeIPA certificate and CA expiry",
    "authentik.configure": "Manage Authentik OIDC provider configuration",
    "authentik.user": "View Authentik users and invalidate sessions",
    "authentik.group": "View Authentik groups and role mappings",
    "authentik.inventory": "View Authentik flows, stages, providers and outposts",
    "authentik.events": "View Authentik event and audit ingestion",
    "keycloak.configure": "Manage Keycloak OIDC providers and secret rotation",
    "keycloak.user": "View Keycloak users/sessions and force logout",
    "keycloak.group": "View Keycloak groups and role mappings",
    "keycloak.inventory": "View Keycloak realms, clients, roles and federation",
    "keycloak.events": "View Keycloak admin and user events",
    # Spec-named RBAC surfaces for pre-existing integration modules
    "netbox.connection.read": "View NetBox connections and sync history",
    "netbox.connection.write": "Manage NetBox connections, conflict policy, webhooks and links",
    "netbox.device.read": "View NetBox devices, elevations, cables and drift",
    "netbox.device.write": "Write back NetBox devices/VMs/interfaces",
    "netbox.ip.read": "View NetBox IP addresses and prefixes",
    "netbox.ip.write": "Write back NetBox IP addresses and prefixes",
    "phpipam.connection.read": "View phpIPAM connections and sync history",
    "phpipam.connection.write": "Manage phpIPAM connections",
    "phpipam.subnet.read": "View phpIPAM subnets",
    "phpipam.subnet.write": "Write back phpIPAM subnets",
    "phpipam.ip.read": "View phpIPAM IP addresses",
    "phpipam.ip.write": "Write back phpIPAM IP addresses",
    "metrics.prometheus.connector": "Manage Prometheus connections and run queries",
    "metrics.prometheus.mapping": "Map Prometheus metrics to inventory objects",
    "metrics.prometheus.widget": "View Prometheus health and dashboard widgets",
    "grafana.embed": "View Grafana dashboard embeds",
    "grafana.link": "Link Grafana dashboards to inventory objects",
    "grafana.annotate": "Push Grafana annotations",
    "grafana.render": "Render Grafana panels",
    "vault.configure": "Manage Vault connections",
    "vault.engines": "View Vault secrets engines",
    "vault.certificates": "View Vault PKI certificates and expiry",
    "vault.leases": "View Vault leases",
    "vault.audit": "View Vault audit devices and events",
    "openldap.configure": "Manage OpenLDAP connection profiles",
    "openldap.user": "View OpenLDAP users",
    "openldap.group": "View OpenLDAP groups and role mappings",
    "openldap.browse": "Browse the OpenLDAP directory",
    "openldap.ppolicy": "View OpenLDAP password-policy state",
    "openldap.replication": "View OpenLDAP replication health",
    # Pre-existing integration module permissions (declared so non-admin roles can be granted them)
    "s3.export": "Export cluster state to S3",
    "s3.connector": "Manage S3/MinIO endpoints, quotas, links and cost rates",
    "s3.sync": "Sync cluster state to S3",
    "s3.import": "Import S3 assets into Proxmox cluster",
    "s3.templates": "Manage S3 template library",
    "s3.dashboard": "View S3 dashboard widget",
    "s3.alerts": "Manage S3 alert channel",
    "s3.policies": "Manage S3 policy adapter",
    "s3.roles": "Manage S3 role mapping",
    "s3.workflows": "Manage S3 automation workflows",
    "prometheus.export": "Export cluster state to Prometheus",
    "prometheus.connector": "Manage Prometheus connector configuration",
    "prometheus.sync": "Sync metrics to Prometheus",
    "prometheus.import": "Import Prometheus metrics",
    "prometheus.templates": "Manage Prometheus template library",
    "prometheus.widget": "View Prometheus dashboard widget",
    "prometheus.alert": "Manage Prometheus alert channel",
    "prometheus.policy": "Manage Prometheus policy adapter",
    "prometheus.roles": "Manage Prometheus role mapping",
    "prometheus.workflow": "Manage Prometheus automation workflows",
    "grafana.export": "Export cluster state to Grafana",
    "grafana.connector": "Manage Grafana connections",
    "grafana.sync": "Sync dashboards with Grafana",
    "grafana.import": "Import Grafana dashboards",
    "grafana.templates": "Manage Grafana template library",
    "grafana.widget": "View Grafana dashboard widget",
    "grafana.alerts": "Manage Grafana alert channel",
    "grafana.policy": "Manage Grafana policy adapter",
    "grafana.roles": "Manage Grafana role mapping",
    "grafana.automation": "Manage Grafana automation workflows",
    "netbox.export": "Export cluster state to NetBox",
    "netbox.connector": "Manage NetBox connector configuration",
    "netbox.sync": "Sync cluster state with NetBox",
    "netbox.import": "Import NetBox assets",
    "netbox.templates": "Manage NetBox template library",
    "netbox.widget": "View NetBox dashboard widget",
    "netbox.alerts": "Manage NetBox alert channel",
    "netbox.policy": "Manage NetBox policy adapter",
    "netbox.roles": "Manage NetBox role mapping",
    "netbox.automation": "Manage NetBox automation workflows",
    "phpipam.export": "Export cluster state to phpIPAM",
    "phpipam.connector": "Manage phpIPAM connector configuration",
    "phpipam.sync": "Sync cluster state with phpIPAM",
    "phpipam.import": "Import phpIPAM assets",
    "phpipam.templates": "Manage phpIPAM template library",
    "phpipam.dashboard": "View phpIPAM dashboard widget",
    "phpipam.alerts": "Manage phpIPAM alert channel",
    "phpipam.policy": "Manage phpIPAM policy adapter",
    "phpipam.roles": "Manage phpIPAM role mapping",
    "phpipam.workflows": "Manage phpIPAM automation workflows",
    # Admin permissions
    "admin.users": "Manage users",
    "admin.roles": "Manage custom roles",
    "admin.tenants": "Manage tenants",
    "admin.groups": "Manage cluster groups",
    "admin.settings": "Modify system settings",
    "admin.scripts": "Manage and execute custom scripts",
    "admin.audit": "View audit logs",
    "admin.api": "Manage API tokens",
    # Security permissions (2026-06-10: RBAC-ification of admin-only endpoints)
    "security.lockout.view": "View IP / user brute-force lockouts",
    "security.lockout.manage": "Clear IP / user lockouts and reset password expiry",
    "security.settings.manage": "Edit security settings (IP whitelist, CORS, key rotation, compliance)",
    "update.manage": "Run and configure the in-app updater",
    # PBS permissions
    "pbs.view": "View PBS servers and datastores",
    "pbs.config": "Modify PBS server settings",
    "pbs.datastore.view": "View datastore details and snapshots",
    "pbs.datastore.create": "Create new datastores on PBS",
    "pbs.datastore.modify": "Modify datastore configuration",
    "pbs.datastore.delete": "Delete datastores from PBS",
    "pbs.datastore.gc": "Run garbage collection on datastores",
    "pbs.datastore.verify": "Run verification on datastores",
    "pbs.datastore.prune": "Prune snapshots from datastores",
    "pbs.snapshot.delete": "Delete individual snapshots",
    "pbs.snapshot.protect": "Toggle snapshot protection",
    "pbs.snapshot.notes": "Edit snapshot/group notes",
    "pbs.snapshot.browse": "Browse and download snapshot files",
    "pbs.jobs.view": "View sync/verify/prune jobs",
    "pbs.jobs.run": "Manually trigger jobs",
    "pbs.tasks.view": "View PBS tasks",
    "pbs.tasks.stop": "Stop running PBS tasks",
    "pbs.jobs.create": "Create sync/verify/prune jobs",
    "pbs.jobs.modify": "Modify existing jobs",
    "pbs.jobs.delete": "Delete jobs",
    "pbs.notifications.view": "View notification config",
    "pbs.notifications.manage": "Create/modify/delete notifications",
    "pbs.traffic.view": "View traffic control config",
    "pbs.traffic.manage": "Create/modify/delete traffic controls",
    "pbs.disks.view": "View disk information",
    "pbs.disks.smart": "View disk SMART data",
    "pbs.subscription.view": "View subscription status",
    "pbs.subscription.set": "Set subscription key",
    # VMware/vCenter permissions
    "vmware.view": "View vCenter/ESXi servers",
    "vmware.config": "Add/edit/remove vCenter connections",
    "vmware.vm.view": "View VMware VMs and details",
    "vmware.vm.power": "Start/stop/restart VMware VMs",
    "vmware.vm.snapshot": "Create/delete VMware VM snapshots",
    "vmware.vm.migrate": "Migrate VMs to Proxmox (V2V)",
    "vmware.host.view": "View ESXi host details",
    "vmware.datastore.view": "View VMware datastores",
    "vmware.network.view": "View VMware networks",
    "vmware.vm.manage": "Modify VMware VM configuration",
    "vmware.cluster.manage": "Manage VMware cluster settings (DRS, HA)",
    "vmware.export": "Export cluster state to VMware assets",
    "vmware.connector": "Manage VMware connector configuration",
    "vmware.sync": "Sync VMware state with Proxmox cluster",
    "vmware.import": "Import VMware assets into Proxmox cluster",
    "vmware.templates": "Manage VMware template library",
    "vmware.dashboard": "View VMware dashboard widget",
    "vmware.alerts": "Manage VMware alert channel",
    "vmware.policy": "Manage VMware policy adapter",
    "vmware.roles": "Manage VMware role mapping",
    "vmware.workflow": "Manage VMware automation workflow",
}

HYPERV = {
    "hyperv.connector": "Register and manage Hyper-V connections",
    "hyperv.read": "View Hyper-V inventory and events",
    "hyperv.power": "Start, stop, pause, resume and reset Hyper-V VMs",
    "hyperv.migrate": "Migrate Hyper-V VMs and storage",
    "hyperv.checkpoint": "Create and delete Hyper-V checkpoints",
    "hyperv.provision": "Provision Hyper-V VMs",
    "hyperv.configure": "Configure Hyper-V settings",
}

PERMISSIONS.update(HYPERV)

# Destructive-action categories for step-up MFA (spec 038). Each category maps to
# the permissions that gate its endpoints; admins toggle categories individually
# via the `mfa_stepup_categories` server setting. Missing keys default to enabled.
DESTRUCTIVE_CATEGORIES = {
    "guest.delete": ["vm.delete"],
    "guest.power": ["vm.stop", "vm.restart"],
    "snapshot": ["vm.snapshot"],
    "backup.delete": ["backup.delete"],
    "storage.delete": ["storage.delete", "storage.config"],
    "users.security": ["admin.users", "admin.roles", "admin.tenants"],
    "node.power": ["node.reboot", "node.power"],
    "cluster.remove": ["cluster.delete", "cluster.admin"],
    # Appliance destructive ops (reboot/halt, config restore, firmware
    # updates) — gated by the integrations' `ops` permission (spec 003).
    "firewall.ops": ["opnsense.ops", "pfsense.ops"],
    # Spec 089: SDN destruction (zones, vnets, fabrics, …) — deleting network
    # infra drops production traffic, same blast-radius class as storage.
    "network.delete": ["sdn.manage"],
}

XCP = {
    "xcp.connector": "Register and manage XCP-ng / Xen Orchestra connections and resource links",
    "xcp.viewer": "View XCP-ng pools, hosts, VMs, storage, networks, metrics and backup jobs",
    "xcp.vm.power": "Start, shutdown, reboot, suspend and resume XCP-ng VMs and manage snapshots",
    "xcp.vm.provision": "Provision XCP-ng VMs (reserved for P3 scope)",
}

PERMISSIONS.update(XCP)

NUTANIX = {
    "nutanix.viewer": "View Nutanix AHV clusters, hosts, VMs, storage, networks, categories, protection and alerts",
    "nutanix.connector": "Register, edit, test and delete Nutanix Prism connections and manage resource links",
    "nutanix.vm.power": "Power on, ACPI shutdown, power off, reboot, suspend and resume AHV VMs",
    "nutanix.vm.provision": "Provision/clone AHV VMs",
    "nutanix.alert.ack": "Acknowledge Nutanix alerts",
}

PERMISSIONS.update(NUTANIX)

VEEAM = {
    "veeam.viewer": "View Veeam jobs, sessions, protected objects, restore points, repositories, compliance and alerts",
    "veeam.connector": "Register, edit, test and delete Veeam Backup & Replication connections",
    "veeam.configure": "Configure Veeam RPO rules and alert thresholds",
    "veeam.job.run": "Start or stop Veeam backup jobs",
    "veeam.restore.view": "Browse Veeam restore points",
}

PERMISSIONS.update(VEEAM)

PORTAINER = {
    "portainer.viewer": "View Portainer endpoints, stacks, containers and images",
    "portainer.connector": "Register, edit, test and delete Portainer connections",
    "portainer.container.power": "Start, stop, restart, pause and unpause Portainer containers",
    "portainer.stack.deploy": "Deploy, start and stop Portainer stacks",
}

PERMISSIONS.update(PORTAINER)

RANCHER = {
    "rancher.viewer": "View Rancher clusters, projects, workloads and catalog apps",
    "rancher.connector": "Register, edit, test and delete Rancher connections",
    "rancher.workload.manage": "Redeploy, scale and restart Rancher workloads and delete pods",
    "rancher.app.deploy": "Deploy Rancher catalog/helm apps (reserved for P3 scope)",
}

PERMISSIONS.update(RANCHER)

# Firewall-appliance integrations (spec 003 parity): two parallel families so
# operators can express e.g. "manage pfSense, view-only OPNsense". `view` is
# the read floor; `ops` gates destructive appliance actions (reboot, restore,
# firmware) and pairs with the `firewall.ops` step-up category below.
OPNSENSE = {
    "opnsense.view": "View OPNsense appliance status and configuration",
    "opnsense.connector": "Manage OPNsense connection configuration",
    "opnsense.rules": "Create/modify/delete OPNsense firewall rules",
    "opnsense.aliases": "Create/modify/delete OPNsense aliases",
    "opnsense.nat": "Create/modify/delete OPNsense NAT rules",
    "opnsense.dhcp": "Manage OPNsense DHCP scopes and static mappings",
    "opnsense.dns": "Manage OPNsense DNS overrides",
    "opnsense.vpn": "Provision OPNsense VPN tunnels (WireGuard/IPsec/OpenVPN)",
    "opnsense.services": "Start/stop/restart OPNsense services",
    "opnsense.ops": "Reboot/restore/update OPNsense appliances (destructive)",
    "opnsense.audit": "View OPNsense integration audit log",
}

PERMISSIONS.update(OPNSENSE)

PFSENSE = {
    "pfsense.view": "View pfSense appliance status and configuration",
    "pfsense.connector": "Manage pfSense connection configuration",
    "pfsense.rules": "Create/modify/delete pfSense firewall rules",
    "pfsense.aliases": "Create/modify/delete pfSense aliases",
    "pfsense.nat": "Create/modify/delete pfSense NAT rules",
    "pfsense.dhcp": "Manage pfSense DHCP scopes and static mappings",
    "pfsense.dns": "Manage pfSense DNS overrides",
    "pfsense.vpn": "Provision pfSense VPN tunnels (WireGuard/IPsec/OpenVPN)",
    "pfsense.services": "Start/stop/restart pfSense services",
    "pfsense.ops": "Reboot/restore/update pfSense appliances (destructive)",
    "pfsense.audit": "View pfSense integration audit log",
}

PERMISSIONS.update(PFSENSE)

# Default permissions per role
ROLE_PERMISSIONS = {
    ROLE_ADMIN: list(PERMISSIONS.keys()),
    ROLE_USER: [
        "vm.view",
        "vm.start",
        "vm.stop",
        "vm.restart",
        "vm.console",
        "vm.migrate",
        "vm.clone",
        "vm.config",
        "vm.snapshot",
        "vm.backup",
        "converter.view",
        "converter.run",
        "cluster.view",
        "node.view",
        "storage.view",
        "storage.upload",
        "storage.download",
        "backup.view",
        "backup.create",
        "backup.restore",
        "backup.delete",
        "ha.view",
        "firewall.view",
        "pool.view",
        "pool.assign",
        "replication.view",
        "site_recovery.view",
        "plugins.view",
        "pbs.view",
        "pbs.datastore.view",
        "pbs.datastore.gc",
        "pbs.datastore.verify",
        "pbs.snapshot.notes",
        "pbs.snapshot.browse",
        "pbs.jobs.view",
        "pbs.tasks.view",
        "pbs.notifications.view",
        "pbs.traffic.view",
        "pbs.disks.view",
        "pbs.subscription.view",
        "vmware.view",
        "vmware.vm.view",
        "vmware.vm.power",
        "vmware.vm.snapshot",
        "vmware.vm.migrate",
        "vmware.vm.manage",
        "vmware.host.view",
        "vmware.datastore.view",
        "vmware.network.view",
        # Kubernetes / integration permissions
        "kubernetes.view",
        "kubernetes.export",
        "kubernetes.connector",
        "kubernetes.sync",
        "kubernetes.import",
        "kubernetes.library",
        "kubernetes.widget",
        "kubernetes.dashboard",
        "kubernetes.alerts",
        "kubernetes.policy",
        "kubernetes.roles",
        "kubernetes.workflow",
        # Hyper-V / Azure Stack HCI permissions
        "hyperv.read",
        # XCP-ng / Xen Orchestra viewer access
        "xcp.viewer",
        # Veeam viewer + optional job run access
        "veeam.viewer",
        "veeam.job.run",
        # Portainer + Rancher viewer access and day-2 container/workload ops
        "portainer.viewer",
        "portainer.container.power",
        "rancher.viewer",
        "rancher.workload.manage",
        # Firewall-appliance integrations: read-only by default; mutations
        # require explicit custom-role grants (spec 003).
        "opnsense.view",
        "pfsense.view",
    ],
    ROLE_VIEWER: [
        "vm.view",
        "vm.console",
        "converter.view",
        "cluster.view",
        "node.view",
        "storage.view",
        "backup.view",
        "ha.view",
        "firewall.view",
        "pool.view",
        "replication.view",
        "site_recovery.view",
        "plugins.view",
        "pbs.view",
        "pbs.datastore.view",
        "pbs.jobs.view",
        "pbs.tasks.view",
        "pbs.notifications.view",
        "pbs.traffic.view",
        "pbs.disks.view",
        "pbs.subscription.view",
        "vmware.view",
        "vmware.vm.view",
        "vmware.host.view",
        "vmware.datastore.view",
        "vmware.network.view",
        # Kubernetes / integration permissions (viewer access)
        "kubernetes.view",
        "kubernetes.export",
        "kubernetes.library",
        "kubernetes.widget",
        "kubernetes.dashboard",
        # Hyper-V viewer access
        "hyperv.read",
        # XCP-ng viewer access
        "xcp.viewer",
        # Veeam read-only access
        "veeam.viewer",
        # Portainer + Rancher read-only access
        "portainer.viewer",
        "rancher.viewer",
        # Firewall-appliance read-only access (spec 003)
        "opnsense.view",
        "pfsense.view",
    ],
    # demo-viewer mirrors viewer read coverage; the demo guard enforces
    # read-only behaviour so the role itself never carries write perms.
    ROLE_DEMO_VIEWER: [
        "vm.view",
        "vm.console",
        "converter.view",
        "cluster.view",
        "node.view",
        "storage.view",
        "backup.view",
        "ha.view",
        "firewall.view",
        "pool.view",
        "replication.view",
        "site_recovery.view",
        "plugins.view",
        "pbs.view",
        "pbs.datastore.view",
        "pbs.jobs.view",
        "pbs.tasks.view",
        "pbs.notifications.view",
        "pbs.traffic.view",
        "pbs.disks.view",
        "pbs.subscription.view",
        "vmware.view",
        "vmware.vm.view",
        "vmware.host.view",
        "vmware.datastore.view",
        "vmware.network.view",
        "kubernetes.view",
        "kubernetes.export",
        "kubernetes.library",
        "kubernetes.widget",
        "kubernetes.dashboard",
        "hyperv.read",
        "xcp.viewer",
        "veeam.viewer",
        "portainer.viewer",
        "rancher.viewer",
        # Firewall-appliance read-only access (spec 003)
        "opnsense.view",
        "pfsense.view",
    ],
}

REDFISH = {
    "redfish.bmc.enroll": "Enroll and manage Redfish BMC connections",
    "redfish.viewer": "View Redfish BMC inventory and status",
    "redfish.connector": "Register, edit, test and delete Redfish BMC connections",
    "redfish.sensor.read": "Read Redfish thermal, power and voltage sensor data",
    "redfish.log.read": "Read Redfish System Event Log (SEL) entries",
    "redfish.host.power": "Issue chassis and system power actions",
    "redfish.event.subscribe": "Create and manage Redfish EventService subscriptions",
    "redfish.firmware.read": "Read Redfish firmware and virtual media inventory",
    "redfish.alert.ack": "Acknowledge Redfish BMC alerts",
}

PERMISSIONS.update(REDFISH)

DELL = {
    "dell.viewer": "View Dell iDRAC inventory and status",
    "dell.connector": "Register, edit, test and delete Dell iDRAC connections",
    "dell.host.power": "Issue Dell iDRAC chassis and system power actions",
    "dell.sensor.read": "Read Dell iDRAC thermal, power and voltage sensor data",
    "dell.log.read": "Read Dell iDRAC System Event Log (SEL) entries",
    "dell.job.read": "View Dell iDRAC Lifecycle Controller jobs",
    "dell.firmware.read": "Read Dell iDRAC firmware inventory",
    "dell.catalog.read": "Compare Dell iDRAC firmware against the catalog",
}

PERMISSIONS.update(DELL)

IDRAC = {
    "idrac.bmc.enroll": "Enroll and manage Dell iDRAC BMC connections",
    "idrac.viewer": "View Dell iDRAC inventory and status",
    "idrac.connector": "Register, edit, test and delete Dell iDRAC connections",
    "idrac.sensor.read": "Read Dell iDRAC thermal, power and voltage sensor data",
    "idrac.log.read": "Read Dell iDRAC System Event Log (SEL) entries",
    "idrac.host.power": "Issue Dell iDRAC chassis and system power actions",
    "idrac.job.read": "View Dell iDRAC Lifecycle Controller jobs",
    "idrac.firmware.read": "Read Dell iDRAC firmware inventory",
    "idrac.catalog.read": "Compare Dell iDRAC firmware against the catalog",
}

PERMISSIONS.update(IDRAC)

HPE = {
    "hpe.viewer": "View HPE iLO inventory and status",
    "hpe.connector": "Register, edit, test and delete HPE iLO connections",
    "hpe.host.power": "Issue HPE iLO chassis and system power actions",
    "hpe.sensor.read": "Read HPE iLO thermal, power and voltage sensor data",
    "hpe.log.read": "Read HPE iLO Integrated Management Log (IML) entries",
    "hpe.firmware.read": "Read HPE iLO firmware inventory",
    "hpe.federation.read": "Read HPE iLO Federation group health",
    "hpe.security.read": "Read HPE iLO security dashboard and Silicon Root of Trust",
    "hpe.bmc.enroll": "Enroll and manage HPE iLO BMC connections",
    "hpe.alert.ack": "Acknowledge HPE iLO alerts",
}

PERMISSIONS.update(HPE)

ILO = {
    "ilo.bmc.enroll": "Enroll and manage HPE iLO BMC connections",
    "ilo.viewer": "View HPE iLO inventory and status",
    "ilo.connector": "Register, edit, test and delete HPE iLO connections",
    "ilo.sensor.read": "Read HPE iLO thermal, power and voltage sensor data",
    "ilo.log.read": "Read HPE iLO Integrated Management Log (IML) entries",
    "ilo.host.power": "Issue HPE iLO chassis and system power actions",
    "ilo.federation.read": "Read HPE iLO Federation group health",
    "ilo.firmware.read": "Read HPE iLO firmware inventory",
    "ilo.security.read": "Read HPE iLO security dashboard and Silicon Root of Trust",
    "ilo.alert.ack": "Acknowledge HPE iLO alerts",
}

PERMISSIONS.update(ILO)


LENOVO = {
    "lenovo.viewer": "View Lenovo XClarity inventory and status",
    "lenovo.connector": "Register, edit, test and delete Lenovo XClarity connections",
    "lenovo.alert.ack": "Acknowledge Lenovo XClarity alerts",
    "xcc.bmc.enroll": "Enroll and manage XCC Redfish BMC connections",
    "xcc.sensor.read": "Read XCC thermal, power and voltage sensor data",
    "xcc.log.read": "Read XCC System Event Log (SEL) entries",
    "xcc.host.power": "Issue XCC chassis and system power actions",
    "xcc.firmware.read": "Read XCC firmware inventory",
    "xcc.compliance.read": "Read XCC firmware compliance status",
    "xcc.lxca.read": "Read LXCA fleet and managed node data",
}

XCLARITY = {
    "lxca.discover": "Discover and import LXCA managed nodes",
}

PERMISSIONS.update(LENOVO)
PERMISSIONS.update(XCLARITY)

IPMI = {
    "ipmi.bmc.enroll": "Enroll and manage Generic IPMI BMC connections",
    "ipmi.viewer": "View Generic IPMI inventory and status",
    "ipmi.connector": "Register, edit, test and delete Generic IPMI connections",
    "ipmi.sensor.read": "Read Generic IPMI thermal, power, voltage and current sensor data",
    "ipmi.log.read": "Read Generic IPMI System Event Log (SEL) entries",
    "ipmi.host.power": "Issue Generic IPMI chassis and system power actions",
    "ipmi.watchdog.read": "Read Generic IPMI watchdog status",
    "ipmi.firmware.read": "Read Generic IPMI firmware and FRU inventory",
    "ipmi.alert.ack": "Acknowledge Generic IPMI alerts",
}

PERMISSIONS.update(IPMI)

APC = {
    "apc.viewer": "View APC / Schneider UPS inventory and status",
    "apc.connector": "Register, edit, test and delete APC / Schneider UPS connections",
    "apc.ups.read": "View APC / Schneider UPS device details and metrics",
    "apc.ups.write": "Create, edit and delete APC / Schneider UPS devices",
    "apc.outlet.read": "View APC / Schneider UPS outlet and outlet group status",
    "apc.outlet.write": "Control APC / Schneider UPS outlets and outlet groups",
    "apc.alert.ack": "Acknowledge APC / Schneider UPS alerts",
}

PERMISSIONS.update(APC)

EATON = {
    "eaton.viewer": "View Eaton UPS inventory and status",
    "eaton.ups.read": "View Eaton UPS device details, metrics, segments and policies",
    "eaton.ups.write": "Register, edit, test, sync and delete Eaton IPM / Network Card-MS sources",
    "eaton.outlet.read": "View Eaton load segment and outlet status",
    "eaton.outlet.write": "Control Eaton load segments and outlets (power on/off/cycle)",
}

PERMISSIONS.update(EATON)

RARITAN = {
    "raritan.viewer": "View Raritan PDU inventory and status",
    "raritan.pdu.read": "View Raritan PDU details, metrics, inlets and sensors",
    "raritan.pdu.write": "Register, edit, test, sync and discover Raritan PDUs",
    "raritan.outlet.read": "View Raritan outlet status",
    "raritan.outlet.write": "Control Raritan outlets (power on/off/cycle)",
}

PERMISSIONS.update(RARITAN)

SERVERTECH = {
    "servertech.viewer": "View ServerTech Sentry PDU inventory and status",
    "servertech.pdu.read": "View ServerTech PDU details, branch and outlet metrics",
    "servertech.pdu.write": "Register, edit, test, sync and discover ServerTech PDUs",
    "servertech.outlet.read": "View ServerTech outlet status",
    "servertech.outlet.write": "Control ServerTech outlets (power on/off/cycle)",
}

PERMISSIONS.update(SERVERTECH)
