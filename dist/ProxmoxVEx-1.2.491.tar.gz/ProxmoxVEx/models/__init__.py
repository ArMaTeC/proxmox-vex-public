# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/models/__init__.py
# Project:     ProxmoxVEx
# Version:     1.2.479
# Build:       2026.09.20
# Description: Model-layer helpers.
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-20
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Model-layer helpers.

spec 092/US075: the app uses raw SQL (no ORM), so the spec's ``SoftDelete``
mixin lands as table-agnostic helpers over a ``deleted_at`` column. The
allowlist below is the ONLY place table/column names are interpolated into
SQL — callers pass a key, never a raw name.
"""

from datetime import datetime, timedelta

# Soft-deletable tables -> primary-key column. Extend deliberately: every
# entry must also be covered by the _ensure_soft_delete_columns convergence
# in core/db.py.
SOFT_DELETE_TABLES = {
    "clusters": "id",
    "users": "username",
    "scheduled_actions": "id",
}

# Boot-time retention window: rows trashed longer than this are hard-purged
# at startup by ProxmoxVExPGDB.purge_soft_deleted().
SOFT_DELETE_RETENTION_DAYS = 30

ACTIVE_WHERE = "deleted_at IS NULL"


def soft_delete_sql(table: str):
    """Return (sql,) marking one row deleted; raises KeyError for unknown tables."""
    pk = SOFT_DELETE_TABLES[table]
    return f"UPDATE {table} SET deleted_at = ? WHERE {pk} = ? AND deleted_at IS NULL"  # nosec: B608 - table/pk come only from the SOFT_DELETE_TABLES allowlist


def restore_sql(table: str):
    pk = SOFT_DELETE_TABLES[table]
    return f"UPDATE {table} SET deleted_at = NULL WHERE {pk} = ?"  # nosec: B608 - allowlisted identifiers only


def list_deleted_sql(table: str):
    SOFT_DELETE_TABLES[table]  # allowlist check only
    return f"SELECT * FROM {table} WHERE deleted_at IS NOT NULL ORDER BY deleted_at DESC"  # nosec: B608 - allowlisted identifiers only


def purge_sql(table: str):
    return f"DELETE FROM {table} WHERE deleted_at IS NOT NULL AND deleted_at < ?"  # nosec: B608 - allowlisted identifiers only


def retention_cutoff(days: int) -> str:
    """ISO cutoff timestamp; rows deleted before it are purge-eligible."""
    return (datetime.now() - timedelta(days=days)).isoformat()


def now_iso() -> str:
    return datetime.now().isoformat()
