<!-- GENERATED:START -->
# Incident Timeline

`incident-timeline` v1.0.0

Reconstruct a timeline of events for a cluster or VM during an incident.

**Author:** ProxmoxVEx Team | **Category:** Monitoring & Health | **License tier:** `basic` | **Requires ProxmoxVEx:** ≥ 1.2.23

## Permissions
_No host scopes declared._

## Configuration
_No config schema declared._

## Events subscribed
_None._
<!-- GENERATED:END -->
