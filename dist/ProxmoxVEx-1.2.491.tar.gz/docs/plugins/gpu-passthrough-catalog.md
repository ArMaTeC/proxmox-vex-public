<!-- GENERATED:START -->
# GPU Passthrough Catalog

`gpu-passthrough-catalog` v1.0.0

Scan and manage live GPU passthrough assignments on Proxmox VE nodes.

**Author:** ProxmoxVEx Team | **Category:** Hardware | **License tier:** `corporate` | **Requires ProxmoxVEx:** ≥ 1.2.23

## Permissions
_No host scopes declared._

## Configuration
_No config schema declared._

## Events subscribed
_None._
<!-- GENERATED:END -->
