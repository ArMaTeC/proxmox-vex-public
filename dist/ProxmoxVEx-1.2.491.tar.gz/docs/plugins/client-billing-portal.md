<!-- GENERATED:START -->
# Client Billing Portal

`client-billing-portal` v1.0.0

Client-facing portal for usage, invoices, and payment status (extends client_portal).

**Author:** ProxmoxVEx Team | **Category:** Cost & Billing | **License tier:** `advanced` | **Requires ProxmoxVEx:** ≥ 1.2.23

## Permissions
_No host scopes declared._

## Configuration
_No config schema declared._

## Events subscribed
_None._
<!-- GENERATED:END -->
