<!-- GENERATED:START -->
# LXC Bulk Deployer

`lxc-bulk-deployer` v1.0.0

Bulk LXC container deployment from declarative specs: template selection, resource sizing, network config, and per-VM rollout status.

**Author:** ProxmoxVEx Team | **Category:** Compute | **License tier:** `advanced` | **Requires ProxmoxVEx:** ≥ 1.2.23

## Permissions
_No host scopes declared._

## Configuration
_No config schema declared._

## Events subscribed
_None._
<!-- GENERATED:END -->
