<!-- GENERATED:START -->
# NetApp Storage

`netapp-storage` v1.0.0

NetApp ONTAP storage management: volume and snapshot inventory, snapshot restore/clone/delete, and snapshot scheduling.

**Author:** ProxmoxVEx Team | **Category:** Storage | **License tier:** `corporate` | **Requires ProxmoxVEx:** ≥ 1.2.23 | **Trusted:** True

## Permissions
_No host scopes declared._

## Configuration
_No config schema declared._

## Events subscribed
_None._
<!-- GENERATED:END -->
