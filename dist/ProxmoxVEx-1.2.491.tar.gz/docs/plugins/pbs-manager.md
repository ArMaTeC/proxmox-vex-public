<!-- GENERATED:START -->
# PBS Manager

`pbs-manager` v1.0.0

Lists PBS datastores, manages backup jobs and simulates datastore verification.

**Author:** ProxmoxVEx Team | **Category:** Backup & Recovery | **License tier:** `advanced` | **Requires ProxmoxVEx:** ≥ 1.2.23

## Permissions
_No host scopes declared._

## Configuration
_No config schema declared._

## Events subscribed
_None._
<!-- GENERATED:END -->
