<!-- GENERATED:START -->
# Ansible Playbook Runner

`ansible-runner` v1.0.0

Run Ansible playbooks against Proxmox nodes/VMs via ProxmoxVEx and report results.

**Author:** ProxmoxVEx Team | **Category:** Automation | **License tier:** `advanced` | **Requires ProxmoxVEx:** ≥ 1.2.23

## Permissions
_No host scopes declared._

## Configuration
_No config schema declared._

## Events subscribed
_None._
<!-- GENERATED:END -->
