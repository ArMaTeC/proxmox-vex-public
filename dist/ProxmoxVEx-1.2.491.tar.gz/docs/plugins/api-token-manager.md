<!-- GENERATED:START -->
# API Token Manager

`api-token-manager` v1.0.0

Create, rotate, and revoke service and user API tokens with scoped permissions.

**Author:** ProxmoxVEx Team | **Category:** Security & Access | **License tier:** `advanced` | **Requires ProxmoxVEx:** ≥ 1.2.23

## Permissions
_No host scopes declared._

## Configuration
_No config schema declared._

## Events subscribed
_None._
<!-- GENERATED:END -->
