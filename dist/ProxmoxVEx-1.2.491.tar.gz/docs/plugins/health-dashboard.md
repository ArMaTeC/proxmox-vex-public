<!-- GENERATED:START -->
# Cluster Health Dashboard

`health-dashboard` v1.0.0

Roll up cluster, node, storage, and VM health into a single scoreboard view.

**Author:** ProxmoxVEx Team | **Category:** Monitoring & Health | **License tier:** `advanced` | **Requires ProxmoxVEx:** ≥ 1.2.23

## Permissions
_No host scopes declared._

## Configuration
_No config schema declared._

## Events subscribed
_None._
<!-- GENERATED:END -->
