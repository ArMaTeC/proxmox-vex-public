<!-- GENERATED:START -->
# Nutanix AHV / Prism Central

`nutanix-ahv` v1.0.0

Discover, monitor and operate Nutanix AHV clusters through Prism Central or Prism Element v3 REST APIs: cluster, host, VM, storage, network, image, category and protection-domain inventory, VM power operations, snapshots and alert ingestion.

**Author:** ProxmoxVEx Team | **Category:** Hypervisor Integrations | **License tier:** `advanced` | **Requires ProxmoxVEx:** ≥ 1.2.23 | **Trusted:** True

## Permissions
- `nutanix.viewer`
- `nutanix.connector`
- `nutanix.vm.power`
- `nutanix.vm.provision`
- `nutanix.alert.ack`

## Configuration
_No config schema declared._

## Events subscribed
_None._
<!-- GENERATED:END -->
