<!-- GENERATED:START -->
# IPAM Manager

`ipam-manager` v1.0.0

IP address management: subnet inventory, IP reservations, allocation tracking, and conflict detection across clusters.

**Author:** ProxmoxVEx Team | **Category:** Network & Security | **License tier:** `basic` | **Requires ProxmoxVEx:** ≥ 1.2.23

## Permissions
_No host scopes declared._

## Configuration
_No config schema declared._

## Events subscribed
_None._
<!-- GENERATED:END -->
