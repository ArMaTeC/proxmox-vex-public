<!-- GENERATED:START -->
# Prometheus Metrics Exporter

`metrics-exporter` v1.0.0

Export Prometheus-compatible metrics from ProxmoxVEx aggregated cluster data.

**Author:** ProxmoxVEx Team | **Category:** Reporting & Analytics | **License tier:** `advanced` | **Requires ProxmoxVEx:** ≥ 1.2.23

## Permissions
_No host scopes declared._

## Configuration
_No config schema declared._

## Events subscribed
_None._
<!-- GENERATED:END -->
