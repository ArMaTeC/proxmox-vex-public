<!-- GENERATED:START -->
# Client Portal

`client_portal` v1.0.0

Self-service portal for hosting customers. Clients see only their assigned VMs.

**Author:** ProxmoxVEx Team | **Category:** Access & Portal | **License tier:** `basic` | **Requires ProxmoxVEx:** ≥ 0.9.4

## Permissions
_No host scopes declared._

## Configuration
_No config schema declared._

## Events subscribed
_None._
<!-- GENERATED:END -->
