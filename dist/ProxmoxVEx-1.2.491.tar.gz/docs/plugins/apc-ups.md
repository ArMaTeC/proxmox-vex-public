<!-- GENERATED:START -->
# APC / Schneider Electric UPS

`apc-ups` v1.0.0

Native APC and Schneider Electric UPS monitoring and control via NUT, apcupsd and SNMP Network Management Cards.

**Author:** ProxmoxVEx Team | **Category:** Monitoring & Health | **License tier:** `corporate` | **Requires ProxmoxVEx:** ≥ 1.2.401 | **Trusted:** True

## Permissions
- `apc.viewer`
- `apc.connector`
- `apc.ups.read`
- `apc.ups.write`
- `apc.outlet.read`
- `apc.outlet.write`
- `apc.alert.ack`

## Configuration
_No config schema declared._

## Events subscribed
_None._
<!-- GENERATED:END -->
