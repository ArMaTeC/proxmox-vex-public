<!-- GENERATED:START -->
# LXC Template Marketplace

`lxc-template-marketplace` v1.0.0

Manage and import LXC templates from a local catalog.

**Author:** ProxmoxVEx Team | **Category:** Compute | **License tier:** `advanced` | **Requires ProxmoxVEx:** ≥ 1.2.23

## Permissions
_No host scopes declared._

## Configuration
_No config schema declared._

## Events subscribed
_None._
<!-- GENERATED:END -->
