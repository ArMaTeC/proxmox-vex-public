<!-- GENERATED:START -->
# OPNsense Manager

`opnsense` v1.0.0

OPNsense firewall management: multi-host status dashboard, interfaces, VPNs, NAT, DNS, gateways, and firewall rules.

**Author:** ProxmoxVEx Team | **Category:** Network & Security | **License tier:** `advanced` | **Requires ProxmoxVEx:** ≥ 1.2.23 | **Trusted:** True

## Permissions
_No host scopes declared._

## Configuration
_No config schema declared._

## Events subscribed
_None._
<!-- GENERATED:END -->
