<!-- GENERATED:START -->
# Disk Usage Explorer

`disk-usage-explorer` v1.0.0

Interactive tree view of the host server's filesystem, showing where disk space is used.

**Author:** ProxmoxVEx Team | **Category:** Storage | **License tier:** `basic` | **Requires ProxmoxVEx:** ≥ 1.2.101

## Permissions
_No host scopes declared._

## Configuration
_No config schema declared._

## Events subscribed
_None._
<!-- GENERATED:END -->
