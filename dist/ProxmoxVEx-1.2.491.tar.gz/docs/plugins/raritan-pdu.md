<!-- GENERATED:START -->
# Raritan PDU

`raritan-pdu` v1.0.0

Raritan PX2/PX3/iX7 rack PDU monitoring and outlet control via JSON-RPC REST and SNMP.

**Author:** ProxmoxVEx Team | **Category:** Monitoring & Health | **License tier:** `corporate` | **Requires ProxmoxVEx:** ≥ 1.2.401 | **Trusted:** True

## Permissions
- `raritan.viewer`
- `raritan.pdu.read`
- `raritan.pdu.write`
- `raritan.outlet.read`
- `raritan.outlet.write`

## Configuration
_No config schema declared._

## Events subscribed
_None._
<!-- GENERATED:END -->
