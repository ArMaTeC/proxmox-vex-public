<!-- GENERATED:START -->
# Backup Verification Runner

`backup-verification-runner` v1.0.0

Simulates backup restore verification and schedules re-verification jobs.

**Author:** ProxmoxVEx Team | **Category:** Backup & Recovery | **License tier:** `advanced` | **Requires ProxmoxVEx:** ≥ 1.2.23

## Permissions
_No host scopes declared._

## Configuration
_No config schema declared._

## Events subscribed
_None._
<!-- GENERATED:END -->
