<!-- GENERATED:START -->
# Backup Retention Guard

`backup-retention-guard` v1.0.0

Defines retention policies and simulates backup pruning and compliance checks.

**Author:** ProxmoxVEx Team | **Category:** Backup & Recovery | **License tier:** `advanced` | **Requires ProxmoxVEx:** ≥ 1.2.23

## Permissions
_No host scopes declared._

## Configuration
_No config schema declared._

## Events subscribed
_None._
<!-- GENERATED:END -->
