<!-- GENERATED:START -->
# Enhanced Audit Search

`audit-search-enhanced` v1.0.0

Full-text, date-range, and user-filtered search over the tamper-evident audit log.

**Author:** ProxmoxVEx Team | **Category:** Security & Access | **License tier:** `advanced` | **Requires ProxmoxVEx:** ≥ 1.2.23

## Permissions
_No host scopes declared._

## Configuration
_No config schema declared._

## Events subscribed
_None._
<!-- GENERATED:END -->
