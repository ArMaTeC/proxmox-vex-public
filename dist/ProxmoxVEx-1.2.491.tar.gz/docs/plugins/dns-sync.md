<!-- GENERATED:START -->
# DNS Sync

`dns-sync` v1.0.0

Sync DNS zones and records with cluster VM hostnames.

**Author:** ProxmoxVEx Team | **Category:** Network & Security | **License tier:** `advanced` | **Requires ProxmoxVEx:** ≥ 1.2.23

## Permissions
_No host scopes declared._

## Configuration
_No config schema declared._

## Events subscribed
_None._
<!-- GENERATED:END -->
