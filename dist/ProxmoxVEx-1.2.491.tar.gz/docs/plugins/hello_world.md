<!-- GENERATED:START -->
# Hello World

`hello_world` v1.0.0

A simple test plugin to verify the plugin system works.

**Author:** ProxmoxVEx Team | **Category:** Tools | **License tier:** `basic` | **Requires ProxmoxVEx:** ≥ 0.9.2

## Permissions
_No host scopes declared._

## Configuration
_No config schema declared._

## Events subscribed
_None._
<!-- GENERATED:END -->
