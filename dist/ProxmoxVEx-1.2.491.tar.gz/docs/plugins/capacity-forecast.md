<!-- GENERATED:START -->
# Capacity Forecaster

`capacity-forecast` v1.0.0

Predict CPU, RAM, storage, and power needs from historical trends.

**Author:** ProxmoxVEx Team | **Category:** Reporting & Analytics | **License tier:** `advanced` | **Requires ProxmoxVEx:** ≥ 1.2.23

## Permissions
_No host scopes declared._

## Configuration
_No config schema declared._

## Events subscribed
_None._
<!-- GENERATED:END -->
