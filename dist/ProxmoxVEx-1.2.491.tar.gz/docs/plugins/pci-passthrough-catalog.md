<!-- GENERATED:START -->
# PCI Passthrough Catalog

`pci-passthrough-catalog` v1.0.0

Scan and simulate PCI passthrough assignments.

**Author:** ProxmoxVEx Team | **Category:** Hardware | **License tier:** `corporate` | **Requires ProxmoxVEx:** ≥ 1.2.23

## Permissions
_No host scopes declared._

## Configuration
_No config schema declared._

## Events subscribed
_None._
<!-- GENERATED:END -->
