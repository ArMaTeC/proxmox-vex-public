<!-- GENERATED:START -->
# Lenovo XClarity

`lenovo-xclarity` v1.0.0

Lenovo XClarity Controller (XCC) Redfish and XClarity Administrator (LXCA) fleet management, monitoring, power control and compliance.

**Author:** ProxmoxVEx Team | **Category:** Hardware Monitoring | **License tier:** `advanced` | **Requires ProxmoxVEx:** ≥ 1.2.401 | **Trusted:** True

## Permissions
- `xcc.bmc.enroll`
- `lxca.discover`
- `xcc.sensor.read`
- `xcc.log.read`
- `xcc.host.power`
- `xcc.firmware.read`
- `xcc.compliance.read`
- `xcc.lxca.read`
- `lenovo.viewer`
- `lenovo.connector`
- `lenovo.alert.ack`

## Configuration
_No config schema declared._

## Events subscribed
_None._
<!-- GENERATED:END -->
