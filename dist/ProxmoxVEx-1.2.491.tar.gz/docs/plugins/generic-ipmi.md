<!-- GENERATED:START -->
# Generic IPMI BMC

`generic-ipmi` v1.0.0

Generic IPMI 2.0 / RMCP+ BMC monitoring, SDR sensors, SEL, chassis control, watchdog and power control for legacy or white-label servers.

**Author:** ProxmoxVEx Team | **Category:** Hardware Monitoring | **License tier:** `advanced` | **Requires ProxmoxVEx:** ≥ 1.2.402 | **Trusted:** True

## Permissions
- `ipmi.bmc.enroll`
- `ipmi.viewer`
- `ipmi.connector`
- `ipmi.sensor.read`
- `ipmi.log.read`
- `ipmi.host.power`
- `ipmi.watchdog.read`
- `ipmi.firmware.read`
- `ipmi.alert.ack`

## Configuration
_No config schema declared._

## Events subscribed
_None._
<!-- GENERATED:END -->
