<!-- GENERATED:START -->
# Eaton UPS (IPM / Network Card-MS)

`eaton-ipm` v1.0.0

Eaton UPS monitoring and outlet control via Intelligent Power Manager REST and Network Card-MS SNMP.

**Author:** ProxmoxVEx Team | **Category:** Monitoring & Health | **License tier:** `corporate` | **Requires ProxmoxVEx:** ≥ 1.2.401 | **Trusted:** True

## Permissions
- `eaton.viewer`
- `eaton.ups.read`
- `eaton.ups.write`
- `eaton.outlet.read`
- `eaton.outlet.write`

## Configuration
_No config schema declared._

## Events subscribed
_None._
<!-- GENERATED:END -->
