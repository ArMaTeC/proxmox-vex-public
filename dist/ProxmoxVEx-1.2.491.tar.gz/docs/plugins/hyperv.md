<!-- GENERATED:START -->
# Microsoft Hyper-V / Azure Stack HCI

`hyperv` v1.0.0

Discover, monitor and operate Microsoft Hyper-V hosts, Windows Server failover clusters and Azure Stack HCI clusters over WinRM/WS-Man: hosts/VMs/network/storage inventory, checkpoint and replica health with alerts, VM power, checkpoint and migration operations, cluster storage health, cluster events and resource correlation.

**Author:** ProxmoxVEx Team | **Category:** Hypervisor Integrations | **License tier:** `advanced` | **Requires ProxmoxVEx:** ≥ 1.2.23 | **Trusted:** True

## Permissions
- `hyperv.read`
- `hyperv.connector`
- `hyperv.power`
- `hyperv.migrate`
- `hyperv.checkpoint`
- `hyperv.provision`
- `hyperv.configure`

## Configuration
_No config schema declared._

## Events subscribed
_None._
<!-- GENERATED:END -->
