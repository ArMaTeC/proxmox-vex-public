<!-- GENERATED:START -->
# Carbon Footprint

`carbon-footprint` v1.0.0

Estimate power consumption and carbon emissions by cluster and tenant.

**Author:** ProxmoxVEx Team | **Category:** Cost & Billing | **License tier:** `advanced` | **Requires ProxmoxVEx:** ≥ 1.2.23

## Permissions
_No host scopes declared._

## Configuration
_No config schema declared._

## Events subscribed
_None._
<!-- GENERATED:END -->
