<!-- GENERATED:START -->
# IDS / IPS

`ids` v1.0.0

Intrusion Detection and Prevention System: monitored segments, signatures, anomaly detection, alerts, and response policies.

**Author:** ProxmoxVEx Team | **Category:** Security | **License tier:** `corporate` | **Requires ProxmoxVEx:** ≥ 1.2.71

## Permissions
_No host scopes declared._

## Configuration
_No config schema declared._

## Events subscribed
_None._
<!-- GENERATED:END -->
