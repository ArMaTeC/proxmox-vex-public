<!-- GENERATED:START -->
# Push Notifications

`notifications` v1.0.0

Send alerts via Ntfy, Apprise (Slack, Discord, Telegram, Gotify, and 80+ services)

**Author:** ProxmoxVEx Team | **Category:** Monitoring & Health | **License tier:** `basic` | **Requires ProxmoxVEx:** ≥ 0.9.5

## Permissions
_No host scopes declared._

## Configuration
_No config schema declared._

## Events subscribed
_None._
<!-- GENERATED:END -->
