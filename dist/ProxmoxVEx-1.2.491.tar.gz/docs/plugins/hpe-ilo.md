<!-- GENERATED:START -->
# HPE iLO BMC

`hpe-ilo` v1.0.0

HPE iLO 5/6 Redfish and iLO 4 RIBCL/XML out-of-band monitoring, IML, thermal map, iLO Federation, security dashboard and power control.

**Author:** ProxmoxVEx Team | **Category:** Hardware Monitoring | **License tier:** `advanced` | **Requires ProxmoxVEx:** ≥ 1.2.401 | **Trusted:** True

## Permissions
- `ilo.bmc.enroll`
- `ilo.viewer`
- `ilo.connector`
- `ilo.sensor.read`
- `ilo.log.read`
- `ilo.host.power`
- `ilo.federation.read`
- `ilo.firmware.read`
- `ilo.security.read`
- `ilo.alert.ack`

## Configuration
_No config schema declared._

## Events subscribed
_None._
<!-- GENERATED:END -->
