<!-- GENERATED:START -->
# Dell iDRAC BMC

`dell-idrac` v1.0.0

Dell iDRAC out-of-band management with Redfish, Dell OEM extensions and WS-Man fallback.

**Author:** ProxmoxVEx Team | **Category:** Hardware Monitoring | **License tier:** `advanced` | **Requires ProxmoxVEx:** ≥ 1.2.401 | **Trusted:** True

## Permissions
- `idrac.bmc.enroll`
- `idrac.viewer`
- `idrac.connector`
- `idrac.sensor.read`
- `idrac.log.read`
- `idrac.host.power`
- `idrac.job.read`
- `idrac.firmware.read`
- `idrac.catalog.read`

## Configuration
_No config schema declared._

## Events subscribed
_None._
<!-- GENERATED:END -->
