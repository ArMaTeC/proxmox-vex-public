<!-- GENERATED:START -->
# Power Manager

`power-manager` v1.0.0

Control PDU and IPMI power outlets for nodes and document power events.

**Author:** ProxmoxVEx Team | **Category:** Infrastructure | **License tier:** `advanced` | **Requires ProxmoxVEx:** ≥ 1.2.23

## Permissions
_No host scopes declared._

## Configuration
_No config schema declared._

## Events subscribed
_None._
<!-- GENERATED:END -->
