<!-- GENERATED:START -->
# Network Topology Map

`network-topology-map` v1.0.0

Build and refresh network topology graphs for clusters.

**Author:** ProxmoxVEx Team | **Category:** Network & Security | **License tier:** `advanced` | **Requires ProxmoxVEx:** ≥ 1.2.23

## Permissions
_No host scopes declared._

## Configuration
_No config schema declared._

## Events subscribed
_None._
<!-- GENERATED:END -->
