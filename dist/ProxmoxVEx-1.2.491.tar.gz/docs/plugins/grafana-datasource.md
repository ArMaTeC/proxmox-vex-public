<!-- GENERATED:START -->
# Grafana Data Source

`grafana-datasource` v1.0.0

Provide a JSON data source and provisioning helper for Grafana dashboards.

**Author:** ProxmoxVEx Team | **Category:** Reporting & Analytics | **License tier:** `advanced` | **Requires ProxmoxVEx:** ≥ 1.2.23

## Permissions
_No host scopes declared._

## Configuration
_No config schema declared._

## Events subscribed
_None._
<!-- GENERATED:END -->
