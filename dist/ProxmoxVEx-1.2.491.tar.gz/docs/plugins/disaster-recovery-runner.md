<!-- GENERATED:START -->
# Disaster Recovery Runner

`disaster-recovery-runner` v1.0.0

Execute and report on disaster recovery drills: failover, verify, failback.

**Author:** ProxmoxVEx Team | **Category:** Automation | **License tier:** `advanced` | **Requires ProxmoxVEx:** ≥ 1.2.23

## Permissions
_No host scopes declared._

## Configuration
_No config schema declared._

## Events subscribed
_None._
<!-- GENERATED:END -->
