<!-- GENERATED:START -->
# Proxmox HA Resources

`proxmox-ha` v1.0.7

Add, update, and remove VMs from Proxmox native HA resources via the cluster manager.

**Author:** Yair Mizrahi | **Category:** Platform | **License tier:** `corporate` | **Requires ProxmoxVEx:** ≥ 0.9.3 | **Trusted:** False

## Permissions
_No host scopes declared._

## Configuration
_No config schema declared._

## Events subscribed
_None._
<!-- GENERATED:END -->
