<!-- GENERATED:START -->
# Docker / Swarm Manager

`docker-swarm` v1.0.0

Docker host and Swarm cluster management: node inventory and drain, service scaling, stack deploy/delete, and container inspection.

**Author:** ProxmoxVEx Team | **Category:** Compute | **License tier:** `advanced` | **Requires ProxmoxVEx:** ≥ 1.2.23 | **Trusted:** True

## Permissions
_No host scopes declared._

## Configuration
_No config schema declared._

## Events subscribed
_None._
<!-- GENERATED:END -->
