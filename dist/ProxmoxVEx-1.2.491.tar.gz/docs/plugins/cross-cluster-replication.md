<!-- GENERATED:START -->
# Cross-Cluster Replication

`cross-cluster-replication` v1.0.0

Schedule and verify VM/LXC snapshot replication across independent Proxmox clusters.

**Author:** ProxmoxVEx Team | **Category:** Backup & Recovery | **License tier:** `advanced` | **Requires ProxmoxVEx:** ≥ 1.2.23

## Permissions
_No host scopes declared._

## Configuration
_No config schema declared._

## Events subscribed
_None._
<!-- GENERATED:END -->
