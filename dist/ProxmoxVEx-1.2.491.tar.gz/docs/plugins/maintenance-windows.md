<!-- GENERATED:START -->
# Maintenance Windows

`maintenance-windows` v1.0.0

Define maintenance windows that suppress alerts and block disruptive operations.

**Author:** ProxmoxVEx Team | **Category:** Automation | **License tier:** `basic` | **Requires ProxmoxVEx:** ≥ 1.2.23

## Permissions
_No host scopes declared._

## Configuration
_No config schema declared._

## Events subscribed
_None._
<!-- GENERATED:END -->
