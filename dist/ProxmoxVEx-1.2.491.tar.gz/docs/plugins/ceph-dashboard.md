<!-- GENERATED:START -->
# Ceph Dashboard

`ceph-dashboard` v1.0.0

Displays Ceph cluster status, pools and OSDs via Proxmox managed Ceph.

**Author:** ProxmoxVEx Team | **Category:** Storage | **License tier:** `corporate` | **Requires ProxmoxVEx:** ≥ 1.2.23

## Permissions
_No host scopes declared._

## Configuration
_No config schema declared._

## Events subscribed
_None._
<!-- GENERATED:END -->
