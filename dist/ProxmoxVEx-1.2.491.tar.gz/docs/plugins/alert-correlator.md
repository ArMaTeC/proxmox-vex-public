<!-- GENERATED:START -->
# Alert Correlator

`alert-correlator` v1.0.0

Deduplicate and correlate incoming alerts into incidents by cluster, node, or VM.

**Author:** ProxmoxVEx Team | **Category:** Monitoring & Health | **License tier:** `advanced` | **Requires ProxmoxVEx:** ≥ 1.2.23

## Permissions

_No host scopes declared._

## Configuration

_No config schema declared._

## Events subscribed

_None._
<!-- GENERATED:END -->
