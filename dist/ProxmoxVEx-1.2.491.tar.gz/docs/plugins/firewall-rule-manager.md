<!-- GENERATED:START -->
# Firewall Rule Manager

`firewall-rule-manager` v1.0.0

Manage firewall rule entries for clusters and networks.

**Author:** ProxmoxVEx Team | **Category:** Network & Security | **License tier:** `advanced` | **Requires ProxmoxVEx:** ≥ 1.2.23

## Permissions
_No host scopes declared._

## Configuration
_No config schema declared._

## Events subscribed
_None._
<!-- GENERATED:END -->
