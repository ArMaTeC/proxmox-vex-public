# Architecture

Core architectural documentation for ProxmoxVEx — the conventions and contracts that every API route, plugin, and integration follows.

- [API Response Envelope Convention](api-response-envelope.md)
- [Plugin API Contract](plugin-contract.md)

See also: [Architecture Decision Records](../adr/README.md) for the rationale behind significant choices.
