# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/background/__init__.py
# Project:     ProxmoxVEx
# Version:     1.2.380
# Build:       2026.09.05
# Description: Package initializer for background
# Docs:        https://proxmoxvex.local/docs
# Generated:   2026-09-05
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
