# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/native/proxmox_backup_server/pbs_src/__init__.py
# Project:     ProxmoxVEx
# Version:     1.2.380
# Build:       2026.09.05
# Description: Proxmox Backup Server plugin source package.
# Docs:        https://proxmoxvex.local/docs
# Generated:   2026-09-05
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Proxmox Backup Server plugin source package."""
