# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/native/pfsense/pfsense_src/__init__.py
# Project:     ProxmoxVEx
# Version:     1.2.380
# Build:       2026.09.05
# Description: pfSense native support modules.
# Docs:        https://proxmoxvex.local/docs
# Generated:   2026-09-05
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""pfSense native support modules."""
