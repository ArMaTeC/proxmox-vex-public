# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        plugins/vm-update-manager/drivers/__init__.py
# Project:     ProxmoxVEx
# Version:     1.2.380
# Build:       2026.09.05
# Description: Drivers package for vm-update-manager
# Docs:        https://proxmoxvex.local/docs
# Generated:   2026-09-05
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
# Drivers package for vm-update-manager
