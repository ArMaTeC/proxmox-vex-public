# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/ux/assets.py
# Project:     ProxmoxVEx
# Version:     1.2.662
# Build:       2026.10.21
# Description: Tracked upload sessions + asset library (spec 128/US2).
# Usage:       import ProxmoxVEx.ux.assets
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-10-21
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Tracked upload sessions + asset library (spec 128/US2).

Browser chunks a large file → each chunk appended server-side to a
temp file tracked in ``upload_sessions`` → on finish the assembled
bytes are verified (size + optional sha256) then forwarded to the PVE
storage in a background thread → the row in ``uploaded_assets`` is the
durable record the asset library + deploy picker read.

Dedup: when an init supplies a sha256 that already exists for the same
(cluster, storage) as a ready asset, the existing asset id is returned
(the client skips the transfer entirely — same file_id).
"""

import hashlib
import json
import logging
import os
import re
import uuid
from datetime import datetime
from pathlib import Path

from ProxmoxVEx.core.db import get_db

log = logging.getLogger(__name__)

CHUNK_SIZE = 8 * 1024 * 1024  # 8 MiB server-suggested chunk size
# Pentest guard, mirrors api/vms/datastores.py: keep 256 MiB reserve.
FREE_SPACE_RESERVE = 256 * 1024 * 1024

ALLOWED_EXTENSIONS = {
    "iso": (".iso",),
    "import": (".vmdk", ".qcow2", ".img", ".raw"),
    "vztmpl": (".tar.gz", ".tar.xz", ".tar.zst"),
}

ASSET_STATES = ("uploading", "processing", "ready", "failed", "aborted")
SESSION_STATES = ("open", "complete", "aborted", "failed")

_FILENAME_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._+\-()]*$")


class UploadStateError(ValueError):
    """Bad chunk order / size / session state (UPLOAD_STATE)."""


class ChecksumMismatchError(ValueError):
    """Assembled bytes don't match the announced sha256 (CHECKSUM_MISMATCH)."""


def upload_tmp_dir():
    """Appliance-local staging dir for in-flight chunked uploads."""
    root = Path(__file__).resolve().parents[2]
    d = root / "tmp" / "uploads"
    d.mkdir(parents=True, mode=0o700, exist_ok=True)
    return str(d)


def _now():
    return datetime.now().isoformat()


def valid_filename(filename, content_type="iso"):
    """Shared upload validation: basename only, charset + extension
    allowlist per content type."""
    if not filename or filename.startswith("."):
        return False, "empty or hidden filename"
    if "/" in filename or "\\" in filename or "\x00" in filename:
        return False, "path components not allowed"
    if not _FILENAME_RE.match(filename):
        return False, "invalid characters in filename"
    allowed = ALLOWED_EXTENSIONS.get(content_type)
    if allowed and not filename.lower().endswith(allowed):
        return False, f"invalid file type; allowed: {', '.join(allowed)}"
    return True, None


def _row(r):
    if r is None:
        return None
    if isinstance(r, dict):
        return r
    try:
        return dict(r)
    except Exception:
        return None


def find_dedupe(cluster_id, storage, sha256):
    """Existing ready asset for the same (cluster, storage, sha256)."""
    if not sha256:
        return None
    c = get_db().conn.cursor()
    c.execute(
        "SELECT * FROM uploaded_assets WHERE cluster_id = ? AND storage = ? "
        "AND sha256 = ? AND state = 'ready' ORDER BY created_at DESC LIMIT 1",
        (cluster_id, storage, sha256.lower()),
    )
    return _row(c.fetchone())


def create_session(cluster_id, node, storage, filename, size_bytes,
                   sha256=None, owner=None, content_type="iso"):
    """Create a new upload session + its uploaded_assets row.

    Returns the session row dict.
    """
    db = get_db()
    c = db.conn.cursor()
    now = _now()
    asset_id = str(uuid.uuid4())
    session_id = str(uuid.uuid4())
    tmp_path = os.path.join(upload_tmp_dir(), f"{session_id}.part")
    c.execute(
        "INSERT INTO uploaded_assets (id, cluster_id, node, storage, filename, "
        "size_bytes, sha256, state, progress, uploaded_by, created_at) "
        "VALUES (?, ?, ?, ?, ?, ?, ?, 'uploading', 0, ?, ?)",
        (asset_id, cluster_id, node, storage, filename,
         int(size_bytes or 0), (sha256 or "").lower() or None, owner, now),
    )
    c.execute(
        "INSERT INTO upload_sessions (id, asset_id, cluster_id, node, storage, "
        "filename, size_bytes, sha256, chunk_size, bytes_received, next_index, "
        "state, owner, tmp_path, created_at, updated_at) "
        "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 0, 0, 'open', ?, ?, ?, ?)",
        (session_id, asset_id, cluster_id, node, storage, filename,
         int(size_bytes or 0), (sha256 or "").lower() or None,
         CHUNK_SIZE, owner, tmp_path, now, now),
    )
    db.conn.commit()
    out = get_session(session_id)
    assert out is not None  # row was inserted above
    out["content_type"] = content_type
    return out


def get_session(session_id):
    c = get_db().conn.cursor()
    c.execute("SELECT * FROM upload_sessions WHERE id = ?", (session_id,))
    return _row(c.fetchone())


def append_chunk(session_id, index, data):
    """Append one chunk. Strict sequential ordering: the client must
    send index == next_index (retry of an already-written chunk is a
    no-op win via next_index skip)."""
    sess = get_session(session_id)
    if not sess:
        raise UploadStateError("session not found")
    if sess["state"] != "open":
        raise UploadStateError(f"session is {sess['state']}")
    index = int(index)
    if index != sess["next_index"]:
        raise UploadStateError(
            f"chunk out of order: expected {sess['next_index']}, got {index}")
    if not data:
        raise UploadStateError("empty chunk")
    new_total = sess["bytes_received"] + len(data)
    if sess["size_bytes"] and new_total > sess["size_bytes"]:
        raise UploadStateError("chunk exceeds declared size")
    with open(sess["tmp_path"], "ab") as fh:
        fh.write(data)

    db = get_db()
    c = db.conn.cursor()
    progress = (new_total / sess["size_bytes"]) if sess["size_bytes"] else 0
    c.execute(
        "UPDATE upload_sessions SET bytes_received = ?, next_index = ?, "
        "updated_at = ? WHERE id = ?",
        (new_total, index + 1, _now(), session_id),
    )
    c.execute(
        "UPDATE uploaded_assets SET progress = ?, size_bytes = GREATEST(size_bytes, ?) "
        "WHERE id = ?",
        (min(progress, 0.95), new_total, sess["asset_id"]),
    )
    db.conn.commit()
    return new_total


def finish_session(session_id):
    """Verify assembled bytes (size + sha256), mark session complete.

    Returns (session, tmp_path). Caller delivers the file to PVE then
    calls mark_asset_processing/done — or mark_session_failed on error.
    """
    sess = get_session(session_id)
    if not sess:
        raise UploadStateError("session not found")
    if sess["state"] != "open":
        raise UploadStateError(f"session is {sess['state']}")
    if sess["size_bytes"] and sess["bytes_received"] != sess["size_bytes"]:
        raise UploadStateError(
            f"incomplete upload: {sess['bytes_received']}/{sess['size_bytes']} bytes")
    if sess["sha256"]:
        h = hashlib.sha256()
        with open(sess["tmp_path"], "rb") as fh:
            for block in iter(lambda: fh.read(CHUNK_SIZE), b""):
                h.update(block)
        if h.hexdigest() != sess["sha256"]:
            abort_session(session_id, keep_asset=False)
            raise ChecksumMismatchError("sha256 mismatch")
    db = get_db()
    c = db.conn.cursor()
    c.execute(
        "UPDATE upload_sessions SET state = 'complete', updated_at = ? WHERE id = ?",
        (_now(), session_id),
    )
    db.conn.commit()
    done = get_session(session_id)
    assert done is not None  # the UPDATE above can't lose the row
    return done, sess["tmp_path"]


def abort_session(session_id, keep_asset=True, error=None):
    """Cancel an in-flight session: delete the partial file, mark the
    asset aborted (or failed when a real error ended it)."""
    sess = get_session(session_id)
    if not sess:
        return
    with _suppress():
        if sess.get("tmp_path") and os.path.exists(sess["tmp_path"]):
            os.unlink(sess["tmp_path"])
    db = get_db()
    c = db.conn.cursor()
    c.execute(
        "UPDATE upload_sessions SET state = 'aborted', updated_at = ? WHERE id = ?",
        (_now(), session_id),
    )
    state = "aborted" if keep_asset else "failed"
    c.execute(
        "UPDATE uploaded_assets SET state = ?, error = ?, finished_at = ? WHERE id = ?",
        (state, error, _now(), sess["asset_id"]),
    )
    db.conn.commit()


def session_progress(session_or_asset_id):
    """Progress payload for GET /api/upload-progress/<id>."""
    c = get_db().conn.cursor()
    c.execute("SELECT * FROM upload_sessions WHERE id = ?", (session_or_asset_id,))
    sess = _row(c.fetchone())
    asset_id = sess["asset_id"] if sess else session_or_asset_id
    asset = get_asset(asset_id)
    if not sess and not asset:
        return None
    src = sess or asset
    assert src is not None  # guard above guarantees one exists
    received = sess["bytes_received"] if sess else (src.get("size_bytes") or 0)
    size = (sess["size_bytes"] if sess else src.get("size_bytes")) or 0
    out = {
        "upload_id": sess["id"] if sess else None,
        "asset_id": asset_id,
        "filename": src.get("filename"),
        "state": asset["state"] if asset else src["state"],
        "bytes_received": received,
        "size_bytes": size,
        "progress": asset["progress"] if asset else (received / size if size else 0),
        "next_index": sess["next_index"] if sess else None,
        "sha256": src.get("sha256"),
        "volid": asset.get("volid") if asset else None,
        "error": asset.get("error") if asset else None,
    }
    return out


def get_asset(asset_id):
    c = get_db().conn.cursor()
    c.execute("SELECT * FROM uploaded_assets WHERE id = ?", (asset_id,))
    return _row(c.fetchone())


def list_assets(cluster_id=None, include_aborted=False):
    c = get_db().conn.cursor()
    if cluster_id:
        c.execute(
            "SELECT * FROM uploaded_assets WHERE cluster_id = ? ORDER BY created_at DESC",
            (cluster_id,),
        )
    else:
        c.execute("SELECT * FROM uploaded_assets ORDER BY created_at DESC")
    rows = [_row(r) for r in c.fetchall()]
    out = []
    for r in rows:
        if not r:
            continue
        if not include_aborted and r["state"] == "aborted":
            continue
        out.append(r)
    return out


def mark_asset_processing(asset_id):
    _asset_update(asset_id, state="processing", progress=0.97)


def mark_asset_ready(asset_id, volid=None, size_bytes=None):
    fields = {"state": "ready", "progress": 1.0, "finished_at": _now()}
    if volid:
        fields["volid"] = volid
    if size_bytes:
        fields["size_bytes"] = int(size_bytes)
    _asset_update(asset_id, **fields)


def mark_asset_failed(asset_id, error):
    _asset_update(asset_id, state="failed", error=str(error)[:500],
                  finished_at=_now())


def delete_asset(asset_id):
    c = get_db().conn.cursor()
    c.execute("DELETE FROM upload_sessions WHERE asset_id = ?", (asset_id,))
    c.execute("DELETE FROM uploaded_assets WHERE id = ?", (asset_id,))
    get_db().conn.commit()


def _asset_update(asset_id, **fields):
    sets = ", ".join(f"{k} = ?" for k in fields)
    vals = list(fields.values()) + [asset_id]
    c = get_db().conn.cursor()
    c.execute(f"UPDATE uploaded_assets SET {sets} WHERE id = ?", vals)  # nosec: B608 - keys are fixed literals
    get_db().conn.commit()


import contextlib  # noqa: E402

_suppress = contextlib.suppress


def sweep_stale_sessions(max_age_hours=24):
    """GC: abort sessions that have seen no chunk activity for
    max_age_hours — guarantees partial files never become orphan GBs."""
    from datetime import timedelta

    cutoff = (datetime.now() - timedelta(hours=max_age_hours)).isoformat()
    c = get_db().conn.cursor()
    c.execute(
        "SELECT id FROM upload_sessions WHERE state = 'open' AND updated_at < ?",
        (cutoff,),
    )
    for r in c.fetchall():
        row = _row(r)
        if row:
            abort_session(row["id"], error="stale upload swept")
            log.info("[ux] swept stale upload session %s", row["id"])


def assets_json(rows):
    out = []
    for r in rows:
        out.append({
            "id": r["id"], "cluster_id": r["cluster_id"], "node": r.get("node"),
            "storage": r.get("storage"), "volid": r.get("volid"),
            "filename": r.get("filename"), "size_bytes": r.get("size_bytes"),
            "sha256": r.get("sha256"), "mime_type": r.get("mime_type"),
            "state": r.get("state"), "progress": r.get("progress"),
            "error": r.get("error"), "uploaded_by": r.get("uploaded_by"),
            "created_at": r.get("created_at"), "finished_at": r.get("finished_at"),
        })
    return out


# keep json import referenced (api layer serializes deploy payloads)
_ = json.dumps  # noqa: F841
