# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/ux/db.py
# Project:     ProxmoxVEx
# Version:     1.2.662
# Build:       2026.10.21
# Description: Database schema helpers for the UX parity pack (spec
#              128).
# Usage:       import ProxmoxVEx.ux.db
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-10-21
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Database schema helpers for the UX parity pack (spec 128)."""

_SCHEMA = """
CREATE TABLE IF NOT EXISTS dashboard_layouts (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL,
    name TEXT NOT NULL,
    widgets TEXT NOT NULL DEFAULT '[]',
    shared INTEGER NOT NULL DEFAULT 0,
    is_default INTEGER NOT NULL DEFAULT 0,
    scope TEXT NOT NULL DEFAULT 'user',
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_dashboard_layouts_user ON dashboard_layouts(user_id);
CREATE INDEX IF NOT EXISTS idx_dashboard_layouts_scope ON dashboard_layouts(scope, is_default);

CREATE TABLE IF NOT EXISTS uploaded_assets (
    id TEXT PRIMARY KEY,
    cluster_id TEXT NOT NULL,
    node TEXT,
    storage TEXT,
    volid TEXT,
    filename TEXT NOT NULL,
    size_bytes INTEGER NOT NULL DEFAULT 0,
    sha256 TEXT,
    mime_type TEXT,
    state TEXT NOT NULL DEFAULT 'uploading',
    progress REAL NOT NULL DEFAULT 0,
    error TEXT,
    uploaded_by TEXT,
    created_at TEXT NOT NULL,
    finished_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_uploaded_assets_cluster ON uploaded_assets(cluster_id);
CREATE INDEX IF NOT EXISTS idx_uploaded_assets_sha256 ON uploaded_assets(cluster_id, storage, sha256);
CREATE INDEX IF NOT EXISTS idx_uploaded_assets_state ON uploaded_assets(state);

CREATE TABLE IF NOT EXISTS upload_sessions (
    id TEXT PRIMARY KEY,
    asset_id TEXT NOT NULL,
    cluster_id TEXT NOT NULL,
    node TEXT NOT NULL,
    storage TEXT NOT NULL,
    filename TEXT NOT NULL,
    size_bytes INTEGER NOT NULL DEFAULT 0,
    sha256 TEXT,
    chunk_size INTEGER NOT NULL DEFAULT 8388608,
    bytes_received INTEGER NOT NULL DEFAULT 0,
    next_index INTEGER NOT NULL DEFAULT 0,
    state TEXT NOT NULL DEFAULT 'open',
    owner TEXT,
    tmp_path TEXT,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_upload_sessions_asset ON upload_sessions(asset_id);

CREATE TABLE IF NOT EXISTS health_score_history (
    id TEXT PRIMARY KEY,
    cluster_id TEXT NOT NULL,
    ts TEXT NOT NULL,
    score REAL NOT NULL,
    components TEXT
);
CREATE INDEX IF NOT EXISTS idx_health_score_history_cluster_ts ON health_score_history(cluster_id, ts);

CREATE TABLE IF NOT EXISTS custom_images (
    id TEXT PRIMARY KEY,
    slug TEXT NOT NULL UNIQUE,
    name TEXT NOT NULL,
    vendor TEXT,
    version TEXT,
    arch TEXT,
    format TEXT,
    source_type TEXT NOT NULL DEFAULT 'url',
    download_url TEXT,
    checksum TEXT,
    checksum_url TEXT,
    volume_id TEXT,
    cluster_id TEXT,
    verified INTEGER NOT NULL DEFAULT 0,
    created_by TEXT,
    created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_custom_images_slug ON custom_images(slug);

CREATE TABLE IF NOT EXISTS blueprints (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    description TEXT,
    image_slug TEXT,
    hardware TEXT NOT NULL DEFAULT '{}',
    cloud_init TEXT NOT NULL DEFAULT '{}',
    tags TEXT NOT NULL DEFAULT '[]',
    is_public INTEGER NOT NULL DEFAULT 0,
    created_by TEXT,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_blueprints_public ON blueprints(is_public);
"""


def ensure_ux_tables(conn):
    """Create UX parity pack tables if they do not exist (idempotent)."""
    cursor = conn.cursor()
    for statement in _SCHEMA.strip().split(";\n"):
        statement = statement.strip()
        if statement:
            cursor.execute(statement + ";")
    conn.commit()
