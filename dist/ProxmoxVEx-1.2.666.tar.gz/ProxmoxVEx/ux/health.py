# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/ux/health.py
# Project:     ProxmoxVEx
# Version:     1.2.662
# Build:       2026.10.21
# Description: Health-score history (spec 128/US4).
# Usage:       import ProxmoxVEx.ux.health
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-10-21
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Health-score history (spec 128/US4).

Every computed cluster score is persisted to ``health_score_history``
(throttled to one row/minute per cluster so dashboard polling doesn't
flood the table), a background worker snapshots all connected clusters
on a fixed cadence so history exists even with no viewers, and a daily
sweep enforces the retention window (default 90 days).
"""

import json
import logging
import threading
import time
import uuid
from datetime import datetime, timedelta

from ProxmoxVEx.core.db import get_db

log = logging.getLogger(__name__)

RETENTION_DAYS_DEFAULT = 90
SNAPSHOT_INTERVAL_S = 15 * 60          # cron cadence
MIN_RECORD_INTERVAL_S = 60             # per-cluster write throttle

_last_record_ts = {}                   # cluster_id -> monotonic ts
_worker_started = False


def _now_iso():
    return datetime.now().isoformat()


def _row(r):
    if r is None:
        return None
    if isinstance(r, dict):
        return r
    try:
        return dict(r)
    except Exception:
        return None


def record_health_snapshot(cluster_id, payload, min_interval_s=MIN_RECORD_INTERVAL_S):
    """Persist one history row for a computed score.

    ``payload`` is the /api/clusters/<id>/health response dict
    ({score, band, factors, issues, computed_at}). Throttled per
    cluster to min_interval_s; pass 0 to force (cron path).
    """
    if not payload or "score" not in payload:
        return None
    now_m = time.monotonic()
    last = _last_record_ts.get(cluster_id, 0)
    if min_interval_s and (now_m - last) < min_interval_s:
        return None
    _last_record_ts[cluster_id] = now_m
    hid = str(uuid.uuid4())
    components = json.dumps({
        "band": payload.get("band"),
        "factors": payload.get("factors"),
        "issues": payload.get("issues"),
    })
    c = get_db().conn.cursor()
    c.execute(
        "INSERT INTO health_score_history (id, cluster_id, ts, score, components) "
        "VALUES (?, ?, ?, ?, ?)",
        (hid, cluster_id, payload.get("computed_at") or _now_iso(),
         float(payload["score"]), components),
    )
    get_db().conn.commit()
    return hid


def get_history(cluster_id, days=30):
    """Rows for a cluster over the last `days` days (ascending ts)."""
    days = max(1, min(int(days or 30), 365))
    cutoff = (datetime.now() - timedelta(days=days)).isoformat()
    c = get_db().conn.cursor()
    c.execute(
        "SELECT id, cluster_id, ts, score, components FROM health_score_history "
        "WHERE cluster_id = ? AND ts >= ? ORDER BY ts ASC",
        (cluster_id, cutoff),
    )
    out = []
    for r in c.fetchall():
        row = _row(r)
        if not row:
            continue
        try:
            comps = json.loads(row.get("components") or "{}")
        except (TypeError, ValueError):
            comps = {}
        out.append({
            "id": row["id"], "cluster_id": row["cluster_id"],
            "ts": row["ts"], "score": row["score"],
            "band": comps.get("band"),
            "factors": comps.get("factors") or [],
            "issues": comps.get("issues") or [],
        })
    return out


def purge_old(retention_days=RETENTION_DAYS_DEFAULT):
    """Retention sweep — delete rows older than the window."""
    cutoff = (datetime.now() - timedelta(days=retention_days)).isoformat()
    c = get_db().conn.cursor()
    c.execute("DELETE FROM health_score_history WHERE ts < ?", (cutoff,))
    n = c.rowcount if c.rowcount and c.rowcount > 0 else 0
    get_db().conn.commit()
    if n:
        log.info("[ux] health history purge: %d rows removed", n)
    return n


def snapshot_all_clusters():
    """Cron tick: compute + record the health score for every connected
    cluster. Uses the same computation as the /health route."""
    from ProxmoxVEx.globals import cluster_managers

    count = 0
    for cid, mgr in list(cluster_managers.items()):
        try:
            if not getattr(mgr, "is_connected", False):
                continue
            from ProxmoxVEx.api.clusters import _compute_health_payload

            payload = _compute_health_payload(cid)
            if payload:
                record_health_snapshot(cid, payload, min_interval_s=0)
                count += 1
        except Exception as e:
            log.debug("[ux] health snapshot for %s failed: %s", cid, e)
    return count


def _is_leader():
    """Leader-election gate — HA deployments must not double-snapshot.
    Missing helper (tests, single node) counts as leader."""
    try:
        from ProxmoxVEx.background import is_leader

        return bool(is_leader())
    except Exception:
        return True


def _worker(interval_s):
    last_purge = 0.0
    while True:
        time.sleep(interval_s)
        try:
            if not _is_leader():
                continue
            snapshot_all_clusters()
            # daily retention sweep
            if time.time() - last_purge > 24 * 3600:
                purge_old()
                last_purge = time.time()
        except Exception as e:
            log.warning("[ux] health history worker tick failed: %s", e)


def start_health_history_worker(interval_s=SNAPSHOT_INTERVAL_S):
    """Start the snapshot+retention thread (idempotent)."""
    global _worker_started
    if _worker_started:
        return
    _worker_started = True
    threading.Thread(
        target=_worker, args=(interval_s,),
        daemon=True, name="ux-health-history").start()
    log.info("[ux] health history worker started (interval=%ss)", interval_s)
