# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/ux/__init__.py
# Project:     ProxmoxVEx
# Version:     1.2.662
# Build:       2026.10.21
# Description: Shared UX/parity pack module.
# Usage:       import ProxmoxVEx.ux
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-10-21
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Shared UX/parity pack module.

Hosts the schema helpers and small domain services behind the
specs/128-ux-parity-pack work: per-user dashboard layouts, tracked
uploads/asset library, health-score history and template blueprints.
"""
