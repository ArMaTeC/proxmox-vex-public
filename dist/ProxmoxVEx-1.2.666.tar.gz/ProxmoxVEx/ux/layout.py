# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/ux/layout.py
# Project:     ProxmoxVEx
# Version:     1.2.662
# Build:       2026.10.21
# Description: Dashboard layout schema validation + widget registry.
# Usage:       import ProxmoxVEx.ux.layout
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-10-21
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Dashboard layout schema validation + widget registry.

The overview dashboard renders a fixed set of sections; a saved layout
re-orders, resizes (grid span) and hides those sections per user.
Unknown widget ids are dropped with a warning rather than rejected so
layouts stay forward/backward compatible (spec FR, schema versioning).
"""

SCHEMA_VERSION = 1

# Widget ids match <DashSection id="…"> wrappers in
# web/src/dashboard_panels.js. Each entry carries its default grid
# span (1..3 columns of the xl:grid-cols-3 overview grid; 3 = full row)
# and default visibility.
DASHBOARD_WIDGETS = {
    # corporate-theme summary strip (hidden in the default theme)
    "summary": {"span": 3, "corp_only": True},
    "services": {"span": 3, "corp_only": True},
    # node cards column (wide left section)
    "nodes": {"span": 2},
    # top consumers + recent tasks (corporate only)
    "consumers": {"span": 3, "corp_only": True},
    # right column: cluster health + migration history
    "side": {"span": 1},
}

DEFAULT_LAYOUT = [
    {"id": "summary", "w": 3, "hidden": False},
    {"id": "services", "w": 3, "hidden": False},
    {"id": "nodes", "w": 2, "hidden": False},
    {"id": "consumers", "w": 3, "hidden": False},
    {"id": "side", "w": 1, "hidden": False},
]

VALID_SCOPES = ("user", "cluster", "global")


class LayoutSchemaError(ValueError):
    """Raised when a posted layout fails schema validation (LAYOUT_SCHEMA)."""


def normalize_widgets(raw):
    """Validate + normalize a posted widget list.

    Returns (widgets, warnings). Raises LayoutSchemaError for
    structurally invalid input; unknown widget ids are skipped with a
    warning instead of failing (schema versioning requirement).
    """
    if not isinstance(raw, list):
        raise LayoutSchemaError("widgets must be a list")
    widgets, warnings, seen = [], [], set()
    for i, entry in enumerate(raw):
        if not isinstance(entry, dict):
            raise LayoutSchemaError(f"widgets[{i}] must be an object")
        wid = entry.get("id")
        if not isinstance(wid, str) or not wid:
            raise LayoutSchemaError(f"widgets[{i}].id missing")
        if wid in seen:
            raise LayoutSchemaError(f"duplicate widget id: {wid}")
        seen.add(wid)
        spec = DASHBOARD_WIDGETS.get(wid)
        if spec is None:
            warnings.append(f"unknown widget dropped: {wid}")
            continue
        w = entry.get("w", spec["span"])
        if not isinstance(w, int) or isinstance(w, bool) or not 1 <= w <= 3:
            raise LayoutSchemaError(f"widgets[{i}].w must be int 1..3")
        widgets.append({
            "id": wid,
            "w": w,
            "hidden": bool(entry.get("hidden", False)),
        })
    if not any(not w["hidden"] for w in widgets) and widgets:
        raise LayoutSchemaError("at least one widget must stay visible")
    return widgets, warnings


def serialize_layout(row):
    """Row dict → API payload."""
    import json

    widgets = []
    try:
        widgets = json.loads(row.get("widgets") or "[]")
    except (TypeError, ValueError):
        widgets = []
    return {
        "id": row["id"],
        "name": row["name"],
        "scope": row.get("scope", "user"),
        "shared": bool(row.get("shared")),
        "is_default": bool(row.get("is_default")),
        "schema_version": SCHEMA_VERSION,
        "widgets": widgets,
        "owner": row.get("user_id"),
        "created_at": row.get("created_at"),
        "updated_at": row.get("updated_at"),
    }
