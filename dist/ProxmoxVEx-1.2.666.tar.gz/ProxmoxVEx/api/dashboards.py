# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/api/dashboards.py
# Project:     ProxmoxVEx
# Version:     1.2.662
# Build:       2026.10.21
# Description: Per-user dashboard layout API.
# Usage:       import ProxmoxVEx.api.dashboards
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-10-21
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Per-user dashboard layout API.

Layouts are a versioned JSON list of widget entries
``[{id, w(1-3), hidden}]`` validated against
``ProxmoxVEx.ux.layout.DASHBOARD_WIDGETS``. Any authenticated user may
have layouts; shared layouts are read-only for everyone but the owner
and admins (viewers get a copy-on-save semantics via PUT /layout).
"""

import json
import logging
import uuid
from datetime import datetime

from flask import Blueprint, request

from ProxmoxVEx.api.helpers import api_error
from ProxmoxVEx.core.db import get_db
from ProxmoxVEx.utils.auth import require_auth
from ProxmoxVEx.ux.layout import (
    DEFAULT_LAYOUT,
    SCHEMA_VERSION,
    VALID_SCOPES,
    LayoutSchemaError,
    normalize_widgets,
    serialize_layout,
)

bp = Blueprint("dashboards", __name__)
log = logging.getLogger(__name__)


def _now():
    return datetime.now().isoformat()


def _cur_user():
    """Current username — request.session['user'] is a plain string."""
    try:
        u = getattr(request, "session", {}).get("user")
        if isinstance(u, dict):
            return u.get("username") or ""
        return u or ""
    except Exception:
        return ""


def _is_admin():
    try:
        sess = getattr(request, "session", {}) or {}
        return sess.get("role") == "admin" or "admin" in (sess.get("roles") or [])
    except Exception:
        return False


def _row_to_dict(row):
    if row is None:
        return None
    if isinstance(row, dict):
        return row
    try:
        return dict(row)
    except Exception:
        cols = [d[0] for d in getattr(row, "description", [])] or []
        return dict(zip(cols, row, strict=False))


def _fetch_layout(lid):
    c = get_db().conn.cursor()
    c.execute("SELECT * FROM dashboard_layouts WHERE id = ?", (lid,))
    return _row_to_dict(c.fetchone())


def _default_layout(user):
    """Resolve the active layout for a user: their default row, then a
    shared scope default, else the built-in default."""
    c = get_db().conn.cursor()
    c.execute(
        "SELECT * FROM dashboard_layouts WHERE user_id = ? AND is_default = 1 "
        "ORDER BY updated_at DESC LIMIT 1",
        (user,),
    )
    row = _row_to_dict(c.fetchone())
    if row:
        return serialize_layout(row), "user"
    # shared defaults (cluster/global scope) a team admin published
    c.execute(
        "SELECT * FROM dashboard_layouts WHERE shared = 1 AND is_default = 1 "
        "AND scope IN ('global', 'cluster') ORDER BY scope = 'global' DESC, updated_at DESC LIMIT 1",
    )
    row = _row_to_dict(c.fetchone())
    if row:
        out = serialize_layout(row)
        out["read_only"] = True
        return out, "shared"
    return {
        "id": None,
        "name": "Default",
        "scope": "builtin",
        "shared": False,
        "is_default": True,
        "schema_version": SCHEMA_VERSION,
        "widgets": DEFAULT_LAYOUT,
        "read_only": True,
    }, "builtin"


def _clear_default(user, scope="user"):
    c = get_db().conn.cursor()
    c.execute(
        "UPDATE dashboard_layouts SET is_default = 0 WHERE user_id = ? AND scope = ?",
        (user, scope),
    )


@bp.route("/api/dashboard/layout", methods=["GET"])
@require_auth()
def get_active_layout():
    """Get the active dashboard layout for the current user.

    Resolution order: the user's default layout → a shared scope
    default → the built-in widget order.
    """
    user = _cur_user()
    if not user:
        return api_error(401, "auth_required", "Unauthorized")
    layout, source = _default_layout(user)
    layout["source"] = source
    return json_body(layout)


@bp.route("/api/dashboard/layout", methods=["PUT"])
@require_auth()
def save_active_layout():
    """Save the current user's active dashboard layout.

    Body: {layout_id?, name?, widgets: [{id,w,hidden}]}.
    When layout_id points at a layout owned by someone else (shared),
    a private copy is created instead (copy-on-save; shared layouts are
    read-only for viewers).
    """
    user = _cur_user()
    body = request.get_json(silent=True) or {}
    raw_widgets = body.get("widgets")
    if raw_widgets is None:
        return api_error(400, "LAYOUT_SCHEMA", "widgets list required")
    try:
        widgets, warnings = normalize_widgets(raw_widgets)
    except LayoutSchemaError as e:
        return api_error(400, "LAYOUT_SCHEMA", str(e))

    lid = body.get("layout_id")
    name = (body.get("name") or "My Layout")[:120]
    db = get_db()
    c = db.conn.cursor()
    now = _now()

    existing = _fetch_layout(lid) if lid else None
    if existing and existing.get("user_id") != user and not _is_admin():
        # copy-on-save for shared layouts owned by someone else
        existing = None
        lid = None

    if existing:
        c.execute(
            "UPDATE dashboard_layouts SET name = ?, widgets = ?, updated_at = ? WHERE id = ?",
            (name, json.dumps(widgets), now, lid),
        )
    else:
        lid = str(uuid.uuid4())
        c.execute(
            "INSERT INTO dashboard_layouts (id, user_id, name, widgets, shared, is_default, scope, created_at, updated_at) "
            "VALUES (?, ?, ?, ?, 0, 1, 'user', ?, ?)",
            (lid, user, name, json.dumps(widgets), now, now),
        )
        _clear_default(user)
        c.execute(
            "UPDATE dashboard_layouts SET is_default = 1 WHERE id = ?", (lid,))
    db.conn.commit()
    out = serialize_layout(_fetch_layout(lid))
    out["warnings"] = warnings
    return json_body(out)


@bp.route("/api/dashboard/layout/reset", methods=["POST"])
@require_auth()
def reset_active_layout():
    """Reset to the default layout: clears the user's default marker so
    resolution falls back to shared/builtin on next GET."""
    user = _cur_user()
    _clear_default(user)
    get_db().conn.commit()
    return json_body({"reset": True, "widgets": DEFAULT_LAYOUT})


@bp.route("/api/dashboard/layouts", methods=["GET"])
@require_auth()
def list_layouts():
    """List the user's layouts plus shared team layouts."""
    user = _cur_user()
    c = get_db().conn.cursor()
    c.execute(
        "SELECT * FROM dashboard_layouts WHERE user_id = ? OR shared = 1 "
        "ORDER BY is_default DESC, updated_at DESC",
        (user,),
    )
    out = []
    for r in c.fetchall():
        row = serialize_layout(_row_to_dict(r))
        row["mine"] = row["owner"] == user
        out.append(row)
    return json_body({"layouts": out, "schema_version": SCHEMA_VERSION})


@bp.route("/api/dashboard/layouts", methods=["POST"])
@require_auth()
def create_layout():
    """Create a named layout. Body: {name, widgets, shared?, scope?}."""
    user = _cur_user()
    body = request.get_json(silent=True) or {}
    name = (body.get("name") or "").strip()[:120]
    if not name:
        return api_error(400, "LAYOUT_SCHEMA", "name required")
    try:
        widgets, warnings = normalize_widgets(body.get("widgets") or [])
    except LayoutSchemaError as e:
        return api_error(400, "LAYOUT_SCHEMA", str(e))
    scope = body.get("scope") or "user"
    if scope not in VALID_SCOPES:
        return api_error(400, "LAYOUT_SCHEMA", f"scope must be one of {VALID_SCOPES}")
    # non-admins cannot publish global/cluster-scope layouts
    if scope != "user" and not _is_admin():
        return api_error(403, "forbidden", "admin role required for shared scopes")
    shared = 1 if body.get("shared") else 0

    lid = str(uuid.uuid4())
    db = get_db()
    c = db.conn.cursor()
    now = _now()
    c.execute(
        "INSERT INTO dashboard_layouts (id, user_id, name, widgets, shared, is_default, scope, created_at, updated_at) "
        "VALUES (?, ?, ?, ?, ?, 0, ?, ?, ?)",
        (lid, user, name, json.dumps(widgets), shared, scope, now, now),
    )
    db.conn.commit()
    out = serialize_layout(_fetch_layout(lid))
    out["warnings"] = warnings
    return json_body(out, 201)


@bp.route("/api/dashboard/layouts/<lid>", methods=["PUT"])
@require_auth()
def update_layout(lid):
    """Update a layout (owner or admin only)."""
    user = _cur_user()
    existing = _fetch_layout(lid)
    if not existing:
        return api_error(404, "not_found", "layout not found")
    if existing.get("user_id") != user and not _is_admin():
        return api_error(403, "forbidden", "shared layouts are read-only")
    body = request.get_json(silent=True) or {}
    db = get_db()
    c = db.conn.cursor()
    warnings = []
    if "widgets" in body:
        try:
            widgets, warnings = normalize_widgets(body["widgets"])
        except LayoutSchemaError as e:
            return api_error(400, "LAYOUT_SCHEMA", str(e))
        c.execute("UPDATE dashboard_layouts SET widgets = ? WHERE id = ?",
                  (json.dumps(widgets), lid))
    if "name" in body:
        name = (body.get("name") or "").strip()[:120]
        if not name:
            return api_error(400, "LAYOUT_SCHEMA", "name required")
        c.execute("UPDATE dashboard_layouts SET name = ? WHERE id = ?", (name, lid))
    if "shared" in body:
        c.execute("UPDATE dashboard_layouts SET shared = ? WHERE id = ?",
                  (1 if body.get("shared") else 0, lid))
    if "scope" in body:
        scope = body.get("scope")
        if scope not in VALID_SCOPES:
            return api_error(400, "LAYOUT_SCHEMA", f"scope must be one of {VALID_SCOPES}")
        if scope != "user" and not _is_admin():
            return api_error(403, "forbidden", "admin role required for shared scopes")
        c.execute("UPDATE dashboard_layouts SET scope = ? WHERE id = ?", (scope, lid))
    c.execute("UPDATE dashboard_layouts SET updated_at = ? WHERE id = ?", (_now(), lid))
    db.conn.commit()
    out = serialize_layout(_fetch_layout(lid))
    out["warnings"] = warnings
    return json_body(out)


@bp.route("/api/dashboard/layouts/<lid>", methods=["DELETE"])
@require_auth()
def delete_layout(lid):
    """Delete a layout (owner or admin only)."""
    user = _cur_user()
    existing = _fetch_layout(lid)
    if not existing:
        return api_error(404, "not_found", "layout not found")
    if existing.get("user_id") != user and not _is_admin():
        return api_error(403, "forbidden", "only the owner may delete this layout")
    db = get_db()
    c = db.conn.cursor()
    c.execute("DELETE FROM dashboard_layouts WHERE id = ?", (lid,))
    db.conn.commit()
    return json_body({"deleted": True})


@bp.route("/api/dashboard/layouts/<lid>/default", methods=["PUT"])
@require_auth()
def set_default_layout(lid):
    """Mark a layout as the user's default for its scope.

    Adopting a shared layout sets it as the caller's personal default
    pointer without mutating the shared row.
    """
    user = _cur_user()
    existing = _fetch_layout(lid)
    if not existing:
        return api_error(404, "not_found", "layout not found")
    db = get_db()
    c = db.conn.cursor()
    if existing.get("user_id") == user:
        _clear_default(user, existing.get("scope", "user"))
        c.execute("UPDATE dashboard_layouts SET is_default = 1 WHERE id = ?", (lid,))
    else:
        # adopting someone else's shared layout: clone as personal default
        if not existing.get("shared"):
            return api_error(403, "forbidden", "layout is private")
        new_id = str(uuid.uuid4())
        now = _now()
        c.execute(
            "INSERT INTO dashboard_layouts (id, user_id, name, widgets, shared, is_default, scope, created_at, updated_at) "
            "VALUES (?, ?, ?, ?, 0, 0, 'user', ?, ?)",
            (new_id, user, existing.get("name") or "Shared copy",
             existing.get("widgets") or "[]", now, now),
        )
        _clear_default(user)
        c.execute("UPDATE dashboard_layouts SET is_default = 1 WHERE id = ?", (new_id,))
        lid = new_id
    db.conn.commit()
    return json_body(serialize_layout(_fetch_layout(lid)))


def json_body(payload, status=200):
    from flask import jsonify

    return jsonify(payload), status
