# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/api/api_reference.py
# Project:     ProxmoxVEx
# Version:     1.2.662
# Build:       2026.10.21
# Description: Spec 128/US3: grouped, searchable API route reference.
# Usage:       import ProxmoxVEx.api.api_reference
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-10-21
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Spec 128/US3: grouped, searchable API route reference.

Generated at request time from Flask's URL map — same source of truth
as /api/openapi.json (T006 decision: reuse the runtime emitter instead
of a hand-maintained manifest, so the reference can never drift from
registered routes). Each route contributes methods, path params, the
view docstring summary, blueprint group and the declared RBAC
permissions/roles (read from the require_auth closure).
"""

import inspect
import logging
from datetime import datetime

from flask import Blueprint, current_app, jsonify

from ProxmoxVEx.api.openapi_doc import _rule_to_path
from ProxmoxVEx.utils.auth import require_auth

bp = Blueprint("api_reference", __name__)
log = logging.getLogger(__name__)

_METHODS = ("GET", "POST", "PUT", "DELETE", "PATCH")


def _perms_for(view):
    """Pull roles/perms out of the require_auth decorator closure."""
    try:
        non = inspect.getclosurevars(view).nonlocals
        perms = list(non.get("perms") or [])
        roles = list(non.get("roles") or [])
        return perms, roles
    except Exception:
        return [], []


def _summary(view):
    try:
        doc = inspect.getdoc(view) or ""
    except Exception:
        doc = ""
    return doc.splitlines()[0].strip() if doc else ""


def collect_reference(app=None):
    """Walk the url map → grouped route list."""
    app = app or current_app
    groups = {}
    count = 0
    for rule in sorted(app.url_map.iter_rules(), key=lambda r: (r.rule)):
        if not rule.rule.startswith("/api/"):
            continue
        view = app.view_functions.get(rule.endpoint)
        if view is None:
            continue
        methods = sorted(m for m in rule.methods or () if m in _METHODS)
        if not methods:
            continue
        path, params = _rule_to_path(rule)
        perms, roles = _perms_for(view)
        bpname = rule.endpoint.split(".", 1)[0]
        entry = {
            "path": path,
            "methods": methods,
            "summary": _summary(view),
            "endpoint": rule.endpoint,
            "permissions": perms,
            "roles": roles,
            "params": params,
        }
        groups.setdefault(bpname, []).append(entry)
        count += 1
    return {
        "generated_at": datetime.now().isoformat(),
        "count": count,
        "groups": [
            {"name": name, "routes": routes}
            for name, routes in sorted(groups.items())
        ],
    }


@bp.route("/api/api-reference", methods=["GET"])
@require_auth()
def api_reference():
    """Grouped route reference for the in-app API docs page."""
    return jsonify(collect_reference())
