# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/api/assets.py
# Project:     ProxmoxVEx
# Version:     1.2.662
# Build:       2026.10.21
# Description: Tracked upload + asset library API.
# Usage:       import ProxmoxVEx.api.assets
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-10-21
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Tracked upload + asset library API.

Chunked flow:
  POST /api/clusters/<cid>/nodes/<node>/storage/<storage>/upload/init
      → {upload_id, asset_id, chunk_size} (or deduplicated asset)
  PUT  /api/clusters/<cid>/nodes/<node>/storage/<storage>/upload/<upload_id>/chunk/<index>
      → raw bytes, strict sequential
  POST .../upload/<upload_id>/finish  → verify + queue PVE delivery
  DELETE .../upload/<upload_id>       → cancel + clean partial

Single-shot compat: POST .../upload with multipart `file` works too —
it runs the same session pipeline synchronously.
"""

import hashlib
import logging
import os
import shutil
import threading

from flask import Blueprint, jsonify, request

from ProxmoxVEx.api.helpers import api_error, check_cluster_access
from ProxmoxVEx.core.db import get_db  # noqa: F401  (kept for parity w/ other api modules)
from ProxmoxVEx.globals import cluster_managers
from ProxmoxVEx.utils.auth import log_audit, require_auth
from ProxmoxVEx.ux import assets as store

bp = Blueprint("assets", __name__)
log = logging.getLogger(__name__)


def _access_denied():
    return api_error(403, "forbidden", "Access denied to this cluster")


def _user():
    try:
        u = getattr(request, "session", {}).get("user")
        name = u.get("username") if isinstance(u, dict) else u
        return str(name or "")
    except Exception:
        return ""


def _validate_target(cluster_id, node, storage):
    from ProxmoxVEx.utils.sanitization import validate_storage_name

    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return None, _access_denied()
    if cluster_id not in cluster_managers:
        return None, api_error(404, "not_found", "Cluster not found")
    if not validate_storage_name(storage):
        return None, api_error(400, "UPLOAD_STATE", "invalid storage name")
    if not node or not isinstance(node, str) or len(node) > 128:
        return None, api_error(400, "UPLOAD_STATE", "invalid node")
    return cluster_managers[cluster_id], None


def _check_free_space():
    try:
        usage = shutil.disk_usage(store.upload_tmp_dir())
        return usage.free > store.FREE_SPACE_RESERVE
    except Exception:
        return True


def _deliver_to_pve(session_id, cluster_id, node, storage_name, content_type):
    """Background: stream the assembled file to PVE storage upload API."""
    sess = store.get_session(session_id)
    if not sess:
        return
    asset_id = sess["asset_id"]
    tmp_path = sess["tmp_path"]
    store.mark_asset_processing(asset_id)
    mgr = cluster_managers.get(cluster_id)
    try:
        if not mgr:
            raise RuntimeError("cluster manager not connected")
        host, port = mgr.host, mgr.api_port
        upload_url = (
            f"https://{host}:{port}/api2/json/nodes/{node}"
            f"/storage/{storage_name}/upload"
        )
        from requests_toolbelt.multipart.encoder import MultipartEncoder

        with open(tmp_path, "rb") as fh:
            encoder = MultipartEncoder(fields=[
                ("content", content_type),
                ("filename", (sess["filename"], fh, "application/octet-stream")),
            ])
            resp = mgr._api_post(
                upload_url, data=encoder,
                headers={"Content-Type": encoder.content_type},
                timeout=3600)
        if resp.status_code == 200:
            volid = f"{storage_name}:{content_type}/{sess['filename']}"
            store.mark_asset_ready(
                asset_id, volid=volid, size_bytes=sess["size_bytes"])
            log_audit(sess.get("owner") or "unknown", "asset.uploaded",
                      f"Uploaded {sess['filename']} to {cluster_id}/{storage_name}",
                      cluster=cluster_id)
        else:
            try:
                msg = resp.json().get("message") or resp.text[:300]
            except Exception:
                msg = resp.text[:300] if resp.text else "upload failed"
            store.mark_asset_failed(asset_id, f"pve: {msg}")
    except Exception as e:
        store.mark_asset_failed(asset_id, e)
        log.warning("[ux] pve delivery failed for %s: %s", asset_id, e)
    finally:
        try:
            if os.path.exists(tmp_path):
                os.unlink(tmp_path)
        except OSError:
            pass


def _start_delivery(session_id, cluster_id, node, storage_name, content_type):
    threading.Thread(
        target=_deliver_to_pve,
        args=(session_id, cluster_id, node, storage_name, content_type),
        daemon=True, name=f"ux-upload-{session_id[:8]}",
    ).start()


# ── chunked init ────────────────────────────────────────────────────
@bp.route("/api/clusters/<cluster_id>/nodes/<node>/storage/<storage>/upload/init",
          methods=["POST"])
@require_auth(perms=["storage.upload"])
def upload_init(cluster_id, node, storage):
    """Init a chunked upload session. Body: {filename, size, sha256?,
    content_type?}. Returns 200 {deduplicated:true, asset} when the
    sha256 already exists for this storage — the client skips sending.
    """
    mgr, err = _validate_target(cluster_id, node, storage)
    if err:
        return err
    body = request.get_json(silent=True) or {}
    # validate the RAW name — silently basename()ing a traversal attempt
    # would hide a client bug; JSON callers must send a plain filename.
    filename = str(body.get("filename") or "")
    content_type = body.get("content_type") or "iso"
    if content_type not in store.ALLOWED_EXTENSIONS:
        return api_error(400, "UPLOAD_STATE",
                         f"content_type must be one of {sorted(store.ALLOWED_EXTENSIONS)}")
    ok, why = store.valid_filename(filename, content_type)
    if not ok:
        return api_error(400, "UPLOAD_STATE", f"invalid filename: {why}")
    size = body.get("size") or body.get("size_bytes") or 0
    try:
        size = int(size)
    except (TypeError, ValueError):
        return api_error(400, "UPLOAD_STATE", "size must be an integer")
    sha256 = (body.get("sha256") or "").strip().lower() or None
    if sha256 and (len(sha256) != 64 or any(c not in "0123456789abcdef" for c in sha256)):
        return api_error(400, "UPLOAD_STATE", "sha256 must be a 64-hex digest")

    if not _check_free_space():
        return api_error(507, "UPLOAD_STATE",
                         "insufficient appliance space to stage upload")

    dedupe = store.find_dedupe(cluster_id, storage, sha256)
    if dedupe:
        out = store.assets_json([dedupe])[0]
        out["deduplicated"] = True
        return jsonify(out), 200

    sess = store.create_session(
        cluster_id, node, storage, filename, size, sha256,
        owner=_user(), content_type=content_type)
    return jsonify({
        "upload_id": sess["id"],
        "asset_id": sess["asset_id"],
        "chunk_size": sess["chunk_size"],
        "deduplicated": False,
    }), 201


# ── chunk ingest ────────────────────────────────────────────────────
@bp.route("/api/clusters/<cluster_id>/nodes/<node>/storage/<storage>/upload/<upload_id>/chunk/<int:index>",
          methods=["PUT", "POST"])
@require_auth(perms=["storage.upload"])
def upload_chunk(cluster_id, node, storage, upload_id, index):
    """Append chunk `index` (raw body). Sequential — retrying the last
    index is a no-op because next_index only advances on success."""
    mgr, err = _validate_target(cluster_id, node, storage)
    if err:
        return err
    sess = store.get_session(upload_id)
    if not sess or sess["cluster_id"] != cluster_id or sess["storage"] != storage:
        return api_error(404, "not_found", "upload session not found")
    if sess["node"] != node:
        return api_error(400, "UPLOAD_STATE", "session bound to another node")
    if index != sess["next_index"]:
        # tolerate idempotent retry of the previous chunk
        if index == sess["next_index"] - 1:
            return jsonify({"received": sess["bytes_received"],
                            "next_index": sess["next_index"], "duplicate": True})
        return api_error(409, "UPLOAD_STATE",
                         f"expected chunk {sess['next_index']}, got {index}")
    # multipart 'chunk' field — octet-stream is rejected by the app's
    # content-type allowlist, so chunks ride a multipart part instead.
    part = request.files.get("chunk")
    data = part.read() if part else request.form.get("chunk", "")
    if isinstance(data, str):
        data = data.encode("utf-8")
    if not data:
        return api_error(400, "UPLOAD_STATE", "empty chunk body")
    try:
        received = store.append_chunk(upload_id, index, data)
    except store.UploadStateError as e:
        return api_error(409, "UPLOAD_STATE", str(e))
    return jsonify({"received": received, "next_index": index + 1})


# ── finish / cancel ─────────────────────────────────────────────────
@bp.route("/api/clusters/<cluster_id>/nodes/<node>/storage/<storage>/upload/<upload_id>/finish",
          methods=["POST"])
@require_auth(perms=["storage.upload"])
def upload_finish(cluster_id, node, storage, upload_id):
    """Verify assembled bytes and queue delivery to PVE storage."""
    mgr, err = _validate_target(cluster_id, node, storage)
    if err:
        return err
    sess = store.get_session(upload_id)
    if not sess or sess["cluster_id"] != cluster_id:
        return api_error(404, "not_found", "upload session not found")
    try:
        sess, _tmp = store.finish_session(upload_id)
    except store.ChecksumMismatchError as e:
        return api_error(422, "CHECKSUM_MISMATCH", str(e))
    except store.UploadStateError as e:
        return api_error(409, "UPLOAD_STATE", str(e))
    body = request.get_json(silent=True) or {}
    _start_delivery(upload_id, cluster_id, node, storage,
                    body.get("content_type") or sess.get("content_type") or "iso")
    return jsonify({"asset_id": sess["asset_id"], "state": "processing"})


@bp.route("/api/clusters/<cluster_id>/nodes/<node>/storage/<storage>/upload/<upload_id>",
          methods=["DELETE"])
@require_auth(perms=["storage.upload"])
def upload_cancel(cluster_id, node, storage, upload_id):
    """Cancel an in-flight upload and remove the partial file."""
    sess = store.get_session(upload_id)
    if not sess or sess["cluster_id"] != cluster_id:
        return api_error(404, "not_found", "upload session not found")
    store.abort_session(upload_id, error="cancelled by user")
    return jsonify({"cancelled": True})


# ── single-shot compat upload (small files / tests) ─────────────────
@bp.route("/api/clusters/<cluster_id>/nodes/<node>/storage/<storage>/upload",
          methods=["POST"])
@require_auth(perms=["storage.upload"])
def upload_single(cluster_id, node, storage):
    """Single-request tracked upload (multipart `file` field). Runs the
    same asset pipeline: dedupe → session → verify → PVE delivery."""
    mgr, err = _validate_target(cluster_id, node, storage)
    if err:
        return err
    if "file" not in request.files:
        return api_error(400, "UPLOAD_STATE", "no file provided")
    f = request.files["file"]
    filename = os.path.basename(f.filename or "")
    content_type = request.form.get("content_type") or "iso"
    if content_type not in store.ALLOWED_EXTENSIONS:
        return api_error(400, "UPLOAD_STATE", "invalid content_type")
    ok, why = store.valid_filename(filename, content_type)
    if not ok:
        return api_error(400, "UPLOAD_STATE", f"invalid filename: {why}")

    data = f.read()
    sha256 = hashlib.sha256(data).hexdigest()
    dedupe = store.find_dedupe(cluster_id, storage, sha256)
    if dedupe:
        out = store.assets_json([dedupe])[0]
        out["deduplicated"] = True
        return jsonify(out), 200

    if not _check_free_space():
        return api_error(507, "UPLOAD_STATE", "insufficient space to stage upload")
    sess = store.create_session(cluster_id, node, storage, filename,
                                len(data), sha256, owner=_user(),
                                content_type=content_type)
    store.append_chunk(sess["id"], 0, data)
    try:
        sess, _tmp = store.finish_session(sess["id"])
    except (store.ChecksumMismatchError, store.UploadStateError) as e:
        return api_error(422, "UPLOAD_STATE", str(e))
    _start_delivery(sess["id"], cluster_id, node, storage, content_type)
    return jsonify({"asset_id": sess["asset_id"], "state": "processing",
                    "sha256": sha256}), 201


# ── progress ────────────────────────────────────────────────────────
@bp.route("/api/upload-progress/<tracking_id>", methods=["GET"])
@require_auth()
def upload_progress(tracking_id):
    """Progress poll — accepts an upload_id or an asset_id. Returns
    bytes_received/size/progress/state + next_index for resumption."""
    info = store.session_progress(tracking_id)
    if not info:
        return api_error(404, "not_found", "upload not found")
    # eta estimate is client-side (bytes/sec from successive polls)
    return jsonify(info)


# ── asset library ───────────────────────────────────────────────────
@bp.route("/api/assets", methods=["GET"])
@require_auth()
def list_assets():
    """List tracked assets. ?cluster=<id> filters; aborted rows hidden
    unless ?all=1."""
    cluster = request.args.get("cluster")
    if cluster:
        ok, _ = check_cluster_access(cluster)
        if not ok:
            return _access_denied()
    rows = store.list_assets(cluster_id=cluster,
                             include_aborted=request.args.get("all") == "1")
    return jsonify({"assets": store.assets_json(rows)})


@bp.route("/api/assets/<asset_id>", methods=["GET"])
@require_auth()
def get_asset(asset_id):
    row = store.get_asset(asset_id)
    if not row:
        return api_error(404, "not_found", "asset not found")
    ok, _ = check_cluster_access(row["cluster_id"])
    if not ok:
        return _access_denied()
    return jsonify(store.assets_json([row])[0])


@bp.route("/api/assets/<asset_id>/deploy", methods=["POST"])
@require_auth(perms=["vm.create"])
def deploy_asset(asset_id):
    """Return the prefill payload a create-VM/LXC dialog consumes for
    this asset (volid + suggested hardware). UI opens the modal with
    these values; this endpoint does not itself create a VM."""
    row = store.get_asset(asset_id)
    if not row:
        return api_error(404, "not_found", "asset not found")
    ok, _ = check_cluster_access(row["cluster_id"])
    if not ok:
        return _access_denied()
    if row["state"] != "ready":
        return api_error(409, "UPLOAD_STATE",
                         f"asset is {row['state']}, not ready")
    name = (row.get("filename") or "asset").rsplit(".", 1)[0]
    return jsonify({
        "asset_id": row["id"],
        "cluster_id": row["cluster_id"],
        "node": row.get("node"),
        "iso": row.get("volid"),
        "storage": row.get("storage"),
        "suggested_name": name,
        "suggested": {"cores": 2, "memory": 2048},
    })


@bp.route("/api/assets/<asset_id>", methods=["DELETE"])
@require_auth(perms=["storage.delete"])
def delete_asset(asset_id):
    """Remove the asset record. Volids on PVE storage are NOT deleted —
    this only drops the library entry (and any stale session parts)."""
    row = store.get_asset(asset_id)
    if not row:
        return api_error(404, "not_found", "asset not found")
    ok, _ = check_cluster_access(row["cluster_id"])
    if not ok:
        return _access_denied()
    store.delete_asset(asset_id)
    log_audit(_user(), "asset.deleted", f"Deleted asset {asset_id}",
              cluster=row["cluster_id"])
    return jsonify({"deleted": True})
