# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/api/azure.py
# Project:     ProxmoxVEx
# Version:     1.2.662
# Build:       2026.10.21
# Description: Azure native integration routes (spec 115).
# Usage:       import ProxmoxVEx.api.azure
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-10-21
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Azure native integration routes (spec 115).

NOTE: unlike api/vmware.py and api/pbs.py — which are historically UNGATED —
this blueprint enforces its own licence gate on every request
(NATIVE_INTEGRATION_TIERS["azure"] = "corporate"). The native-registry gate in
native/registry.py::_license_gate only covers /api/<native-module>/ routes, so
Azure deliberately carries its own before_request check. Divergence documented
in plan.md / research.md.
"""

import contextlib
import logging
import re
import time
import uuid

from flask import Blueprint, jsonify, request

from ProxmoxVEx.api.helpers import check_azure_access, server_access_guard
from ProxmoxVEx.core.db import get_db
from ProxmoxVEx.globals import azure_managers
from ProxmoxVEx.utils.audit import log_audit
from ProxmoxVEx.utils.auth import get_user_record, require_auth
from ProxmoxVEx.utils.rbac import filter_servers_for_user, user_can_access_azure_vm
from ProxmoxVEx.utils.sanitization import sanitize_log_message as _sl

bp = Blueprint("azure", __name__)
bp.before_request(server_access_guard("azure", "azure_id", write_level="edit"))

log = logging.getLogger("azure_api")

MASKED = "********"
# Loose GUID shape per data-model.md — Azure accepts some non-GUID aliases.
_GUID_RE = re.compile(r"^[0-9a-fA-F-]{32,40}$")
# ARM resource IDs are long path strings; bound them so a giant id can't
# pin request parsing.
_MAX_VM_ID_LEN = 1024
_VALID_ACTIONS = {"start", "powerOff", "deallocate", "restart"}


def _err(code, message, status=400):
    return jsonify({"error": message, "code": code}), status


def _license_gate():
    """Licence gate mirroring native/registry.py::_license_gate (fail-open on
    service errors)."""
    try:
        from ProxmoxVEx.services.licensing import LicensingService

        if LicensingService().can_use_native(get_db(), "azure"):
            return None
        from ProxmoxVEx.models.plugins import get_native_tier_requirement

        return jsonify({
            "error": "License upgrade required for this integration",
            "required_tier": get_native_tier_requirement("azure"),
        }), 402
    except Exception as e:
        log.warning("license gate skipped for azure: %s", e)
        return None


@bp.before_request
def _azure_license_gate():
    return _license_gate()


def _manager(azure_id):
    return azure_managers.get(azure_id)


def _current_user():
    try:
        return getattr(request, "session", {}).get("user", "")
    except Exception:
        return ""


def _user_record():
    # get_user_record's dict has no "username" key; filter_servers_for_user and
    # user_can_access_azure_vm resolve grants by username — stamp it on.
    uname = _current_user()
    return dict(get_user_record(uname), username=uname)


def _validate_conn_body(body, partial=False):
    """Validate connection payload. Returns (fields, err_response)."""
    fields = {}
    for key in ("tenant_id", "client_id", "subscription_id"):
        val = (body.get(key) or "").strip()
        if not val and not partial:
            return None, _err("missing_field", f"{key} is required")
        if val and not _GUID_RE.match(val):
            return None, _err("invalid_field", f"{key} must be a GUID")
        if val:
            fields[key] = val
    if not partial:
        secret = body.get("client_secret") or ""
        if not secret:
            return None, _err("missing_field", "client_secret is required")
        fields["client_secret"] = secret
    else:
        if "client_secret" in body:
            fields["client_secret"] = body.get("client_secret") or ""
    fields["name"] = (body.get("name") or "").strip()
    try:
        fields["poll_interval"] = max(15, min(600, int(body.get("poll_interval", 60))))
    except (TypeError, ValueError):
        fields["poll_interval"] = 60
    fields["notes"] = (body.get("notes") or "").strip()
    if "enabled" in body:
        fields["enabled"] = 1 if body.get("enabled") else 0
    return fields, None


# =============================================================================
# Connection CRUD (US1)
# =============================================================================


@bp.route("/api/azure", methods=["GET"])
@require_auth(perms=["azure.view"])
def list_azure_connections():
    """List Azure connections — masked secrets, access-group filtered."""
    from ProxmoxVEx.core.azure import load_azure_connections

    user = _user_record()
    rows = load_azure_connections()
    allowed = filter_servers_for_user(user, "azure", [r["id"] for r in rows])
    out = []
    for row in rows:
        if row["id"] not in allowed:
            continue
        mgr = _manager(row["id"])
        entry = mgr.to_dict() if mgr else {}
        entry.update({
            "id": row["id"],
            "name": row.get("name", ""),
            "tenant_id": row.get("tenant_id", ""),
            "subscription_id": row.get("subscription_id", ""),
            "cloud": row.get("cloud", "public"),
            "poll_interval": row.get("poll_interval", 60),
            "enabled": bool(row.get("enabled", 1)),
            "client_secret": MASKED,
        })
        out.append(entry)
    return jsonify({"connections": out})


@bp.route("/api/azure", methods=["POST"])
@require_auth(perms=["azure.config"])
def create_azure_connection():
    from ProxmoxVEx.core.azure import AzureManager, save_azure_connection

    body = request.get_json(silent=True) or {}
    fields, err = _validate_conn_body(body)
    if err:
        return err
    assert fields is not None
    azure_id = uuid.uuid4().hex[:8]
    mgr = AzureManager(azure_id, fields)
    ok, err_msg = mgr.connect()
    if not ok:
        return _err("connect_failed", f"connection test failed: {err_msg}", 400)
    save_azure_connection(azure_id, fields)
    azure_managers[azure_id] = mgr
    log_audit(_current_user(), "azure.added",
              f"Added Azure connection {fields.get('name') or azure_id} ({azure_id})",
              cluster=azure_id)
    return jsonify({"connection": mgr.to_dict(), "id": azure_id}), 201


@bp.route("/api/azure/<azure_id>", methods=["PUT"])
@require_auth(perms=["azure.config"])
def update_azure_connection(azure_id):
    from ProxmoxVEx.core.azure import AzureManager, load_azure_connections, save_azure_connection

    ok, err_resp = check_azure_access(azure_id)
    if not ok:
        return err_resp
    rows = {r["id"]: r for r in load_azure_connections()}
    row = rows.get(azure_id)
    if not row:
        return _err("not_found", "Azure connection not found", 404)
    body = request.get_json(silent=True) or {}
    fields, err = _validate_conn_body(body, partial=True)
    if err:
        return err
    assert fields is not None

    merged = dict(row)
    merged.update({k: v for k, v in fields.items() if k != "client_secret"})
    identity_changed = any(
        fields.get(k) and fields[k] != row.get(k)
        for k in ("tenant_id", "client_id", "subscription_id", "cloud")
    )
    secret = fields.get("client_secret", "")
    keep_secret = secret == MASKED or secret == ""
    if not keep_secret:
        merged["client_secret"] = secret
    # Cred-exfil guard (FR-011): identity change + preserved secret → do not
    # auto-connect; require an explicit test-connection first.
    auto_connect = not (identity_changed and keep_secret)

    save_azure_connection(azure_id, merged, encrypt_secret=not keep_secret)
    if auto_connect and azure_id in azure_managers:
        del azure_managers[azure_id]
    if auto_connect:
        mgr = AzureManager(azure_id, merged)
        if not keep_secret or not identity_changed:
            mgr.connect()
        azure_managers[azure_id] = mgr
    log_audit(_current_user(), "azure.updated",
              f"Updated Azure connection {azure_id}", cluster=azure_id)
    mgr = azure_managers.get(azure_id)
    return jsonify({"connection": mgr.to_dict() if mgr else {"id": azure_id},
                    "requires_test": not auto_connect})


@bp.route("/api/azure/<azure_id>", methods=["DELETE"])
@require_auth(perms=["azure.config"])
def delete_azure_connection(azure_id):
    from ProxmoxVEx.core.azure import delete_azure_connection as _del

    ok, err_resp = check_azure_access(azure_id)
    if not ok:
        return err_resp
    mgr = azure_managers.pop(azure_id, None)
    if mgr:
        with contextlib.suppress(Exception):
            mgr.stop()
    _del(azure_id)
    log_audit(_current_user(), "azure.deleted",
              f"Deleted Azure connection {azure_id}", cluster=azure_id)
    return jsonify({"deleted": azure_id})


@bp.route("/api/azure/test-connection", methods=["POST"])
@require_auth(perms=["azure.config"])
def test_azure_connection():
    from ProxmoxVEx.core.azure import AzureManager

    body = request.get_json(silent=True) or {}
    fields, err = _validate_conn_body(body)
    if err:
        return err
    assert fields is not None
    mgr = AzureManager("__test__", fields)
    ok, err_msg = mgr.connect()
    if not ok:
        return _err("connect_failed", err_msg or "connection failed", 400)
    return jsonify({"connected": True,
                    "subscription": mgr.subscription_name or fields["subscription_id"]})


@bp.route("/api/azure/list-subscriptions", methods=["POST"])
@require_auth(perms=["azure.config"])
def list_subscriptions():
    """Token + GET /subscriptions so the modal can offer a picker (FR-004)."""
    from ProxmoxVEx.core.azure import AzureManager

    body = request.get_json(silent=True) or {}
    tenant_id = (body.get("tenant_id") or "").strip()
    client_id = (body.get("client_id") or "").strip()
    secret = body.get("client_secret") or ""
    for k, v in (("tenant_id", tenant_id), ("client_id", client_id)):
        if not v or not _GUID_RE.match(v):
            return _err("invalid_field", f"{k} must be a GUID")
    if not secret:
        return _err("missing_field", "client_secret is required")
    mgr = AzureManager("__list__", {"tenant_id": tenant_id, "client_id": client_id,
                                    "client_secret": secret, "subscription_id": ""})
    subs, err_msg = mgr.list_subscriptions()
    if err_msg:
        return _err("list_failed", err_msg, 400)
    return jsonify({"subscriptions": subs})


@bp.route("/api/azure/<azure_id>/diagnose", methods=["GET"])
@require_auth(perms=["azure.view"])
def diagnose_azure(azure_id):
    ok, err_resp = check_azure_access(azure_id)
    if not ok:
        return err_resp
    mgr = _manager(azure_id)
    if not mgr:
        return _err("not_found", "Azure connection not found", 404)
    return jsonify(mgr.diagnose())


# =============================================================================
# VM inventory (US1)
# =============================================================================


@bp.route("/api/azure/<azure_id>/vms", methods=["GET"])
@require_auth(perms=["azure.vm.view"])
def list_azure_vms(azure_id):
    ok, err_resp = check_azure_access(azure_id)
    if not ok:
        return err_resp
    mgr = _manager(azure_id)
    if not mgr:
        return _err("not_found", "Azure connection not found", 404)
    if request.args.get("refresh") == "1":
        mgr.refresh_now()
    vms = mgr.get_vms()
    user = _user_record()
    if user.get("role") != "admin":
        vms = [v for v in vms
               if user_can_access_azure_vm(user, azure_id, v["id"], "azure.vm.view")]
    return jsonify({"vms": vms, "connected": mgr.connected,
                    "last_sync_at": mgr.last_sync_at})


def _norm_vm_id(vm_id):
    """ARM resource IDs start with '/', which Werkzeug's <path:> converter can
    never match — clients send the ID without the leading slash (or URL-encoded
    with %2F, which decodes to a leading slash and also fails). Normalise to the
    canonical '/subscriptions/...' form the inventory cache is keyed on."""
    vm_id = vm_id.lstrip("/")
    return "/" + vm_id if vm_id else vm_id


@bp.route("/api/azure/<azure_id>/vms/<path:vm_id>", methods=["GET"])
@require_auth(perms=["azure.vm.view"])
def get_azure_vm(azure_id, vm_id):
    if len(vm_id) > _MAX_VM_ID_LEN:
        return _err("invalid_id", "vm id too long")
    vm_id = _norm_vm_id(vm_id)
    ok, err_resp = check_azure_access(azure_id)
    if not ok:
        return err_resp
    mgr = _manager(azure_id)
    if not mgr:
        return _err("not_found", "Azure connection not found", 404)
    user = _user_record()
    if not user_can_access_azure_vm(user, azure_id, vm_id, "azure.vm.view"):
        return _err("forbidden", "Access denied to this VM", 403)
    vm = mgr.get_vm_detail(vm_id)
    if not vm:
        return _err("not_found", "VM not found", 404)
    # Register a watch so the broadcast tick pushes azure_vm_detail refreshes
    # while this VM's panel is open (mirrors the vmware /watch pattern).
    with contextlib.suppress(Exception):
        from ProxmoxVEx.background.broadcast import broadcast_resources_loop

        watched = getattr(broadcast_resources_loop, "_azure_watched", None)
        if watched is None:
            watched = {}
            # runtime-attached function attribute (same as _vmw_watched)
            setattr(broadcast_resources_loop, "_azure_watched", watched)  # noqa: B010
        watched[(azure_id, vm_id)] = time.time()
    return jsonify({"vm": vm})


# =============================================================================
# Sync (US2)
# =============================================================================


@bp.route("/api/azure/<azure_id>/sync", methods=["POST"])
@require_auth(perms=["azure.view"])
def sync_azure(azure_id):
    ok, err_resp = check_azure_access(azure_id)
    if not ok:
        return err_resp
    mgr = _manager(azure_id)
    if not mgr:
        return _err("not_found", "Azure connection not found", 404)
    diff = mgr.refresh_now()
    return jsonify({"synced": True, "vm_count": len(mgr.get_vms()), "diff": diff})


# =============================================================================
# Power actions (US3)
# =============================================================================


@bp.route("/api/azure/<azure_id>/vms/<path:vm_id>/power/<action>", methods=["POST"])
@require_auth(perms=["azure.vm.power"])
def azure_vm_power(azure_id, vm_id, action):
    if len(vm_id) > _MAX_VM_ID_LEN:
        return _err("invalid_id", "vm id too long")
    vm_id = _norm_vm_id(vm_id)
    if action not in _VALID_ACTIONS:
        return _err("invalid_action",
                    f"action must be one of {sorted(_VALID_ACTIONS)}")
    ok, err_resp = check_azure_access(azure_id)
    if not ok:
        return err_resp
    mgr = _manager(azure_id)
    if not mgr:
        return _err("not_found", "Azure connection not found", 404)
    user = _user_record()
    if not user_can_access_azure_vm(user, azure_id, vm_id, "azure.vm.power"):
        return _err("forbidden", "Access denied to this VM", 403)
    result = mgr.vm_power_action(vm_id, action)
    log_audit(_current_user(), f"azure.vm.{action}",
              f"VM power {action} on {_sl(vm_id)} -> {result.get('status')}",
              cluster=azure_id)
    if result.get("status") == "error":
        return _err("power_failed", result.get("error", "power action failed"), 502)
    return jsonify(result)
