# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/converter/__init__.py
# Project:     ProxmoxVEx
# Version:     1.2.662
# Build:       2026.10.21
# Description: ProxmoxVEx Converter Module Built-in LXC ↔ VM
#              conversion, disk resize, and clone-replace operations.
# Usage:       import ProxmoxVEx.converter
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-10-21
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""
ProxmoxVEx Converter Module
Built-in LXC ↔ VM conversion, disk resize, and clone-replace operations.
"""
