# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/core/azure.py
# Project:     ProxmoxVEx
# Version:     1.2.662
# Build:       2026.10.21
# Description: Azure native integration (spec 115).
# Usage:       import ProxmoxVEx.core.azure
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-10-21
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Azure native integration (spec 115).

AzureManager talks to Azure Resource Manager with a client-credentials
(service principal) token. State is per-connection: cached VM inventory,
connection health, and a poll interval honoured by the background sync tick
in background/broadcast.py.
"""

import logging
import threading
import time
import uuid
from datetime import UTC, datetime

import requests

from ProxmoxVEx.core.db import get_db
from ProxmoxVEx.globals import azure_managers

log = logging.getLogger("azure")

ARM_BASE = "https://management.azure.com"
ARM_API_VERSION = "2024-07-01"  # stable Compute api-version pinned per spec
TOKEN_SCOPE = "https://management.azure.com/.default"
TOKEN_URL_TMPL = "https://login.microsoftonline.com/{tenant}/oauth2/v2.0/token"
TOKEN_REFRESH_SKEW = 300  # refresh at exp-300s
MASKED = "********"

# Normalise ARM PowerState/* codes to the dashboard's vocabulary.
_POWER_MAP = {
    "PowerState/running": "running",
    "PowerState/starting": "starting",
    "PowerState/stopping": "stopping",
    "PowerState/stopped": "stopped",
    "PowerState/deallocated": "deallocated",
    "PowerState/deallocating": "stopping",
}


def _now_iso():
    return datetime.now(UTC).isoformat()


def _classify_error(status_code, body=""):
    """Map an ARM/AD failure to a stable class for last_error."""
    if status_code in (401,):
        return "auth"
    if status_code in (403,):
        return "rbac"
    if status_code == 404:
        return "not_found"
    if status_code == 429:
        return "throttled"
    if status_code is None:
        return "network"
    return "unknown"


def _parse_resource_group(resource_id):
    parts = (resource_id or "").split("/")
    try:
        return parts[parts.index("resourceGroups") + 1]
    except (ValueError, IndexError):
        return ""


class AzureManager:
    """One Azure connection: token lifecycle, ARM calls, cached inventory."""

    def __init__(self, azure_id, config):
        self.id = azure_id
        self.name = config.get("name", "Azure")
        self.tenant_id = config.get("tenant_id", "")
        self.client_id = config.get("client_id", "")
        self.subscription_id = config.get("subscription_id", "")
        self.cloud = config.get("cloud", "public")
        self.poll_interval = max(15, min(600, int(config.get("poll_interval") or 60)))
        self.enabled = bool(config.get("enabled", True))
        self.notes = config.get("notes", "")
        self._secret = config.get("client_secret") or config.get("secret", "")

        self._token = None
        self._token_exp = 0.0
        self._token_lock = threading.Lock()
        self._auth_failures = 0

        self.connected = False
        self.last_error = None
        self.last_error_class = None
        self.last_sync_at = None
        self._last_sync_epoch = 0.0  # poll_interval checks use this, not the ISO string
        self.sync_fail_count = 0
        self.subscription_name = ""

        self._vms = {}  # arm resource id (lower) -> normalized vm dict
        self._vms_lock = threading.Lock()
        self._actions = {}  # tracking remote async ops

    # ---- token lifecycle --------------------------------------------------

    def _fetch_token(self):
        """client_credentials token from AD v2. Returns (token, expires_epoch)
        or raises AzureError."""
        url = TOKEN_URL_TMPL.format(tenant=self.tenant_id)
        try:
            r = requests.post(url, data={
                "grant_type": "client_credentials",
                "client_id": self.client_id,
                "client_secret": self._secret,
                "scope": TOKEN_SCOPE,
            }, timeout=15)
        except requests.RequestException as e:
            raise AzureError(f"token request failed: {e}", "network") from e
        if r.status_code != 200:
            cls = _classify_error(r.status_code, r.text[:200])
            raise AzureError(f"token request failed ({r.status_code})", cls,
                             status_code=r.status_code)
        payload = r.json()
        return payload["access_token"], time.time() + int(payload.get("expires_in", 3600))

    def _get_token(self):
        with self._token_lock:
            if self._token and time.time() < self._token_exp - TOKEN_REFRESH_SKEW:
                return self._token
            token, exp = self._fetch_token()
            self._token, self._token_exp = token, exp
            self._auth_failures = 0
            return token

    # ---- ARM helpers -------------------------------------------------------

    def _arm(self, method, path_or_url, params=None, retries=2):
        """ARM request with bearer auth, nextLink-free single call. Callers
        page via _arm_paged. Handles 429/Retry-After backoff."""
        url = path_or_url if path_or_url.startswith("http") else f"{ARM_BASE}{path_or_url}"
        delay = 1.0
        for attempt in range(retries + 1):
            try:
                token = self._get_token()
            except AzureError as e:
                self._auth_failures += 1
                self.connected = False
                self.last_error = str(e)
                self.last_error_class = e.cls
                raise
            try:
                r = requests.request(method, url,
                                     headers={"Authorization": f"Bearer {token}"},
                                     params=params, timeout=30)
            except requests.RequestException as e:
                self.last_error = f"network: {e}"
                self.last_error_class = "network"
                raise AzureError(str(e), "network") from e
            if r.status_code == 429 and attempt < retries:
                retry_after = r.headers.get("Retry-After")
                try:
                    wait = float(retry_after) if retry_after else delay
                except ValueError:
                    wait = delay
                time.sleep(min(wait, 30))
                delay *= 2
                continue
            if r.status_code >= 400:
                cls = _classify_error(r.status_code, r.text[:300])
                self.last_error = f"ARM {r.status_code}: {r.text[:200]}"
                self.last_error_class = cls
                raise AzureError(self.last_error, cls, status_code=r.status_code)
            return r
        raise AzureError("ARM request exhausted retries", "unknown")

    def _arm_get(self, path, params=None):
        return self._arm("GET", path, params=params).json()

    def _arm_post(self, path, params=None):
        return self._arm("POST", path, params=params)

    def _arm_paged(self, path, params=None):
        """Follow nextLink paging; returns the concatenated value list."""
        items = []
        url = path
        p = dict(params or {})
        while url:
            data = (self._arm("GET", url).json() if url.startswith("http")
                    else self._arm("GET", url, params=p).json())
            items.extend(data.get("value", []))
            url = data.get("nextLink")
            p = {}  # nextLink embeds its own params
        return items

    # ---- lifecycle ---------------------------------------------------------

    def connect(self):
        """Fetch a token and read the subscription back as a probe.
        Returns (ok, error_message)."""
        try:
            self._get_token()
            sub = self._arm_get(f"/subscriptions/{self.subscription_id}",
                                params={"api-version": "2022-12-01"})
            self.subscription_name = sub.get("displayName", "")
            self.connected = True
            self.last_error = None
            self.last_error_class = None
            return True, None
        except AzureError as e:
            self.connected = False
            return False, str(e)
        except Exception as e:
            self.connected = False
            self.last_error = str(e)
            self.last_error_class = "unknown"
            return False, str(e)

    def stop(self):
        """Release runtime state; nothing persistent to tear down."""
        self.connected = False

    def list_subscriptions(self):
        """Used by the Add-Cluster picker (no subscription_id needed)."""
        try:
            self._get_token()
            subs = self._arm_paged("/subscriptions",
                                   params={"api-version": "2022-12-01"})
            return ([{
                "subscription_id": s.get("subscriptionId"),
                "display_name": s.get("displayName"),
                "state": s.get("state"),
            } for s in subs], None)
        except AzureError as e:
            return None, str(e)
        except Exception as e:
            return None, str(e)

    # ---- inventory ---------------------------------------------------------

    def get_vms(self):
        """Return the cached VM list (does not hit the network)."""
        with self._vms_lock:
            return [dict(v) for v in self._vms.values()]

    def _fetch_vm_inventory(self):
        """Two paged calls joined on resource ID: properties list + statusOnly
        power states. NOTE: $expand=instanceView on List-All is rejected by
        ARM without a VMSS $filter — the statusOnly call is the supported path."""
        base = (f"/subscriptions/{self.subscription_id}/providers/"
                "Microsoft.Compute/virtualMachines")
        props = self._arm_paged(base, params={"api-version": ARM_API_VERSION})
        statuses = self._arm_paged(
            base, params={"api-version": ARM_API_VERSION, "statusOnly": "true"})
        power_by_id = {}
        for s in statuses:
            rid = (s.get("id") or "").lower()
            statuses_list = ((s.get("properties") or {}).get("instanceView") or {}).get("statuses") or []
            code = next((x.get("code") for x in statuses_list
                         if (x.get("code") or "").startswith("PowerState/")), "")
            power_by_id[rid] = _POWER_MAP.get(code, "unknown")
        out = {}
        for vm in props:
            rid = (vm.get("id") or "").lower()
            if not rid:
                continue
            p = vm.get("properties") or {}
            hw = p.get("hardwareProfile") or {}
            st = p.get("storageProfile") or {}
            osd = st.get("osDisk") or {}
            out[rid] = {
                "id": vm.get("id"),
                "name": vm.get("name"),
                "power_state": power_by_id.get(rid, "unknown"),
                "size": hw.get("vmSize", ""),
                "region": vm.get("location", ""),
                "resource_group": _parse_resource_group(vm.get("id")),
                "os_type": osd.get("osType", ""),
                "tags": vm.get("tags") or {},
                "provisioning_state": p.get("provisioningState", ""),
                "last_seen": _now_iso(),
            }
        return out

    def sync_vms(self):
        """Reconcile the cached inventory; returns a diff summary."""
        try:
            fresh = self._fetch_vm_inventory()
        except AzureError as e:
            self.sync_fail_count += 1
            self.last_error = str(e)
            self.last_error_class = e.cls
            return None
        with self._vms_lock:
            old = self._vms
            added = [k for k in fresh if k not in old]
            removed = [k for k in old if k not in fresh]
            changed = [k for k in fresh if k in old and fresh[k] != old[k]]
            self._vms = fresh
        self.last_sync_at = _now_iso()
        self._last_sync_epoch = time.time()
        self.sync_fail_count = 0
        diff = {"added": len(added), "removed": len(removed),
                "changed": len(changed)}
        if added or removed or changed:
            log.info("[AZURE:%s] sync diff +%d -%d ~%d",
                     self.id, len(added), len(removed), len(changed))
        return diff

    def refresh_now(self):
        return self.sync_vms()

    def get_vm_detail(self, vm_id):
        """Detail view enriched with live instanceView."""
        rid = vm_id.lower()
        with self._vms_lock:
            vm = dict(self._vms.get(rid) or self._vms.get(vm_id) or {})
        if not vm:
            return None
        try:
            detail = self._arm_get(f"{vm_id}/instanceView",
                                   params={"api-version": ARM_API_VERSION})
            vm["instance_view"] = detail.get("properties") or detail
        except AzureError:
            pass  # cached fields still answer the detail view
        return vm

    # ---- power actions (US3) ----------------------------------------------

    def vm_power_action(self, vm_id, action):
        """POST the dedicated ARM action endpoint and follow the async op."""
        endpoints = {
            "start": "start",
            "powerOff": "powerOff",
            "deallocate": "deallocate",
            "restart": "restart",
        }
        suffix = endpoints[action]
        try:
            r = self._arm_post(f"{vm_id}/{suffix}",
                               params={"api-version": ARM_API_VERSION})
        except AzureError as e:
            return {"status": "error", "error": str(e), "class": e.cls}
        status = "completed" if r.status_code in (200, 204) else "accepted"
        async_url = (r.headers.get("Azure-AsyncOperation")
                     or r.headers.get("Location"))
        track = {"action": action, "vm_id": vm_id, "status": status,
                 "started_at": _now_iso()}
        if async_url and status == "accepted":
            track["async_url"] = async_url
            final = self._wait_async(async_url)
            track["status"] = final
        self._actions[f"{vm_id}:{action}:{int(time.time())}"] = track
        self.refresh_now()
        return track

    def _wait_async(self, url, timeout=60):
        """Poll an Azure-AsyncOperation/Location URL to terminal state."""
        deadline = time.time() + timeout
        while time.time() < deadline:
            try:
                data = self._arm("GET", url).json()
                st = (data.get("status") or "").lower()
                if st in ("succeeded", "success"):
                    return "completed"
                if st in ("failed", "canceled", "cancelled"):
                    return "failed"
            except AzureError:
                pass
            time.sleep(2)
        return "running"

    # ---- introspection ------------------------------------------------------

    def diagnose(self):
        return {
            "id": self.id,
            "name": self.name,
            "tenant_id": self.tenant_id,
            "subscription_id": self.subscription_id,
            "subscription_name": self.subscription_name,
            "connected": self.connected,
            "last_error": self.last_error,
            "last_error_class": self.last_error_class,
            "last_sync_at": self.last_sync_at,
            "sync_fail_count": self.sync_fail_count,
            "auth_failures": self._auth_failures,
            "vm_count": len(self._vms),
            "poll_interval": self.poll_interval,
            "enabled": self.enabled,
        }

    def to_dict(self):
        d = self.diagnose()
        d["client_secret"] = MASKED
        d["cloud"] = self.cloud
        d["notes"] = self.notes
        return d


class AzureError(Exception):
    """ARM/AD failure with a stable classification."""

    def __init__(self, message, cls="unknown", status_code=None):
        super().__init__(message)
        self.cls = cls
        self.status_code = status_code


# =============================================================================
# Persistence (mirror save_vmware_server / load_vmware_servers)
# =============================================================================


def save_azure_connection(azure_id, config, encrypt_secret=True):
    db = get_db()
    cursor = db.conn.cursor()
    secret = config.get("client_secret", "")
    if encrypt_secret and secret and secret != MASKED:
        secret_enc = db._encrypt(secret)
    else:
        row = cursor.execute(
            "SELECT secret_encrypted FROM azure_connections WHERE id = ?",
            (azure_id,)).fetchone()
        secret_enc = row[0] if row else ""
    now = _now_iso()
    cursor.execute(
        """
        INSERT OR REPLACE INTO azure_connections
        (id, name, tenant_id, client_id, subscription_id, secret_encrypted,
         cloud, poll_interval, enabled, notes, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?,
                COALESCE((SELECT created_at FROM azure_connections WHERE id = ?), ?), ?)
        """,
        (
            azure_id,
            config.get("name", "Azure"),
            config.get("tenant_id", ""),
            config.get("client_id", ""),
            config.get("subscription_id", ""),
            secret_enc,
            config.get("cloud", "public"),
            int(config.get("poll_interval", 60)),
            int(config.get("enabled", True)),
            config.get("notes", ""),
            azure_id,
            now,
            now,
        ),
    )
    db.conn.commit()


def delete_azure_connection(azure_id):
    db = get_db()
    cursor = db.conn.cursor()
    cursor.execute("DELETE FROM azure_connections WHERE id = ?", (azure_id,))
    db.conn.commit()


def load_azure_connections():
    """Return all azure_connections rows as dicts (secret stays encrypted)."""
    db = get_db()
    cursor = db.conn.cursor()
    cursor.execute("SELECT * FROM azure_connections")
    cols = [c[0] for c in (cursor.description or ())]
    return [dict(zip(cols, r, strict=False)) for r in cursor.fetchall()]


def init_azure_managers():
    """Load enabled connections at startup and spawn background connects —
    mirrors load_vmware_servers (connect is off the startup thread so one bad
    tenant can't delay login)."""
    try:
        rows = load_azure_connections()
    except Exception as e:
        logging.warning("[AZURE] Failed to load azure connections: %s", e)
        return
    for row in rows:
        azure_id = row["id"]
        secret = ""
        if row.get("secret_encrypted"):
            try:
                secret = get_db()._decrypt(row["secret_encrypted"])
            except Exception as e:
                logging.warning("[AZURE:%s] secret decryption FAILED: %s",
                                azure_id, e)
        config = dict(row)
        config["client_secret"] = secret
        mgr = AzureManager(azure_id, config)
        azure_managers[azure_id] = mgr
        if row.get("enabled"):
            try:
                import gevent

                gevent.spawn(mgr.connect)
            except Exception:
                threading.Thread(target=mgr.connect, daemon=True).start()
    logging.info("[AZURE] Loaded %d Azure connections", len(rows))


def new_azure_id():
    return uuid.uuid4().hex[:8]
