# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/native/vmware_vcenter/vcenter_src/__init__.py
# Project:     ProxmoxVEx
# Version:     1.2.662
# Build:       2026.10.21
# Description: vcenter_src package for the VMware vCenter native
#              integration.
# Usage:       import ProxmoxVEx.native.vmware_vcenter.vcenter_src
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-10-21
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""vcenter_src package for the VMware vCenter native integration."""
