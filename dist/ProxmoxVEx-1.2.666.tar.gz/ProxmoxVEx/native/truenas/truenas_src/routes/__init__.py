# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/native/truenas/truenas_src/routes/__init__.py
# Project:     ProxmoxVEx
# Version:     1.2.662
# Build:       2026.10.21
# Description: REST routes exposed to the ProxmoxVEx UI under
#              ``/api/truenas/<path>``, plus config load/save/masking.
# Usage:       import ProxmoxVEx.native.truenas.truenas_src.routes
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-10-21
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""REST routes exposed to the ProxmoxVEx UI under
``/api/truenas/<path>``, plus config load/save/masking."""
