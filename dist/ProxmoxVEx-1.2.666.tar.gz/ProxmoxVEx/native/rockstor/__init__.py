# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/native/rockstor/__init__.py
# Project:     ProxmoxVEx
# Version:     1.2.662
# Build:       2026.10.21
# Description: Rockstor — native ProxmoxVEx integration.
# Usage:       import ProxmoxVEx.native.rockstor
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-10-21
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Rockstor — native ProxmoxVEx integration.

Manage Rockstor BTRFS NAS appliances over the Rockstor REST API:
connection management with encrypted credentials (DB-backed, not
config.json), pool inventory plus scrub/balance, share create/resize/delete
and snapshot create/clone/delete.
"""

import logging
import os

from ProxmoxVEx.native.registry import register_native_route

from . import api, models

PLUGIN_ID = "rockstor"
PLUGIN_DIR = os.path.dirname(os.path.abspath(__file__))
log = logging.getLogger(f"native.{PLUGIN_ID}")


def register(app=None):  # noqa: ARG001
    """Register Rockstor's DB tables and native routes."""
    try:
        from ProxmoxVEx.core.db import get_db

        models.ensure_tables(get_db().conn)
    except Exception as e:
        log.error("[rockstor] Failed to ensure tables: %s", e)

    for path, handler in api.ROUTES.items():
        register_native_route(PLUGIN_ID, path, handler)
    log.info("[rockstor] Registered %d routes", len(api.ROUTES))
