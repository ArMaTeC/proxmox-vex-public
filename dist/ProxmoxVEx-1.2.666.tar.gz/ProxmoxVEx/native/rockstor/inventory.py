# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/native/rockstor/inventory.py
# Project:     ProxmoxVEx
# Version:     1.2.662
# Build:       2026.10.21
# Description: Rockstor inventory discovery: pools, shares, snapshots.
# Usage:       import ProxmoxVEx.native.rockstor.inventory
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-10-21
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Rockstor inventory discovery: pools, shares, snapshots.

A refresh pulls the appliance's pools and shares, then walks each share's
``/api/shares/<sid>/snapshots`` collection (there is no flat snapshot list
endpoint). Cached rows are upserted keyed on the appliance's numeric ids and
rows that vanished remotely are pruned so the cache converges to truth.
"""

import logging
from typing import Any, Dict, List, Optional

from . import connector, models

log = logging.getLogger("plugin.rockstor.inventory")


def _kib(value: Any) -> int:
    try:
        return int(value or 0)
    except (TypeError, ValueError):
        return 0


def _pool_ref(obj: Any) -> str:
    """Share.pool serializes as a nested object; tolerate ids/names too."""
    if isinstance(obj, dict):
        return str(obj.get("name") or "")
    return str(obj or "")


def _pool_remote_id(obj: Any) -> int:
    if isinstance(obj, dict):
        try:
            return int(obj.get("id") or 0)
        except (TypeError, ValueError):
            return 0
    try:
        return int(obj or 0)
    except (TypeError, ValueError):
        return 0


def refresh_connection(conn_id: int) -> Dict[str, Any]:
    """Pull pools/shares/snapshots for one connection and upsert the cache."""
    conn = models.get_connection(conn_id)
    if not conn:
        raise connector.ConnectorError("not_found", f"connection {conn_id} not found")
    c = connector.build_connector(conn)

    pools = c.list_pools()
    seen_pool_ids: List[int] = []
    for p in pools:
        rid = _kib(p.get("id"))
        seen_pool_ids.append(rid)
        models.upsert_pool(conn_id, {
            "remote_id": rid,
            "name": str(p.get("name") or ""),
            "uuid": str(p.get("uuid") or ""),
            "raid": str(p.get("raid") or ""),
            "size_kib": _kib(p.get("size")),
            "free_kib": _kib(p.get("free")),
            "used_kib": _kib(p.get("usage")),
            "compression": str(p.get("compression") or ""),
            "role": str(p.get("role") or ""),
            "is_mounted": 1 if p.get("is_mounted") else 0,
        })
    models.remove_stale("rockstor_pools", conn_id, seen_pool_ids)

    shares = c.list_shares()
    seen_share_ids: List[int] = []
    snap_count = 0
    for s in shares:
        rid = _kib(s.get("id"))
        seen_share_ids.append(rid)
        models.upsert_share(conn_id, {
            "remote_id": rid,
            "name": str(s.get("name") or ""),
            "pool_name": _pool_ref(s.get("pool")),
            "pool_remote_id": _pool_remote_id(s.get("pool")),
            "size_kib": _kib(s.get("size")),
            "rusage_kib": _kib(s.get("rusage")),
            "eusage_kib": _kib(s.get("eusage")),
            "compression_algo": str(s.get("compression_algo") or ""),
            "owner": str(s.get("owner") or ""),
            "grp": str(s.get("group") or ""),
            "perms": str(s.get("perms") or ""),
            "replica": 1 if s.get("replica") else 0,
            "is_mounted": 1 if s.get("is_mounted") else 0,
        })
        # Per-share snapshots; a failing share never aborts the whole refresh.
        try:
            snaps = c.list_share_snapshots(rid)
        except connector.ConnectorError as e:
            log.warning("[rockstor] snapshot list failed for share %s: %s", rid, e)
            snaps = []
        seen_names: List[str] = []
        for sn in snaps:
            name = str(sn.get("name") or "")
            seen_names.append(name)
            models.upsert_snapshot(conn_id, rid, {
                "share_name": str(s.get("name") or ""),
                "name": name,
                "writable": 1 if sn.get("writable") else 0,
                "uvisible": 1 if sn.get("uvisible") else 0,
                "snap_type": str(sn.get("snap_type") or "admin"),
                "size_kib": _kib(sn.get("size")),
                "toc": str(sn.get("toc") or ""),
            })
            snap_count += 1
        models.remove_stale_snapshots(conn_id, rid, seen_names)
    models.remove_stale("rockstor_shares", conn_id, seen_share_ids)
    # Snapshots of deleted shares must not linger in the cache.
    stale = models.list_rows("rockstor_snapshots", conn_id)
    for sn in stale:
        if sn.get("share_remote_id") not in seen_share_ids:
            models.remove_stale_snapshots(conn_id, sn["share_remote_id"], [])

    models.update_connection_status(conn_id, "reachable", models._now_iso())
    return {
        "connection_id": conn_id,
        "pools": len(seen_pool_ids),
        "shares": len(seen_share_ids),
        "snapshots": snap_count,
    }


# ---- Cached readers used by api.py ----


def get_cached_pools(connection_id: Optional[int] = None) -> List[Dict[str, Any]]:
    return models.list_rows("rockstor_pools", connection_id)


def get_cached_shares(
    connection_id: Optional[int] = None, pool_name: Optional[str] = None
) -> List[Dict[str, Any]]:
    rows = models.list_rows("rockstor_shares", connection_id)
    if pool_name:
        rows = [r for r in rows if r.get("pool_name") == pool_name]
    return rows


def get_cached_snapshots(
    connection_id: Optional[int] = None, share_remote_id: Optional[int] = None
) -> List[Dict[str, Any]]:
    rows = models.list_rows("rockstor_snapshots", connection_id)
    if share_remote_id is not None:
        rows = [r for r in rows if r.get("share_remote_id") == share_remote_id]
    return rows
