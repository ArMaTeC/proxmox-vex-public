# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/native/rockstor/api.py
# Project:     ProxmoxVEx
# Version:     1.2.665
# Build:       2026.10.21
# Description: Rockstor native-integration route handlers.
# Usage:       import ProxmoxVEx.native.rockstor.api
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-10-21
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Rockstor native-integration route handlers.

Native routes are exact-match subpaths (no Flask path converters), so
per-resource actions take the target id in the JSON body or query string —
the same verb-path convention netapp_storage uses (``endpoints/test`` etc.).
Permission checks run inside each handler via ``_require``; the native proxy
itself only enforces the ``plugins.view`` floor.
"""

import contextlib
import logging
import os
from typing import Any, Dict, List, Optional, Tuple

from flask import jsonify, request, send_file

from ProxmoxVEx.utils.audit import log_audit
from ProxmoxVEx.utils.auth import get_user_record
from ProxmoxVEx.utils.rbac import has_permission

from . import connector, inventory, models, operations

log = logging.getLogger("native.rockstor.api")

MODULE_DIR = os.path.dirname(os.path.abspath(__file__))

PERM_VIEW = "rockstor.viewer"
PERM_CONNECTOR = "rockstor.connector"
PERM_MANAGE = "rockstor.storage.manage"


def _current_user():
    return get_user_record(getattr(request, "session", {}).get("user"))


def _actor() -> str:
    user = _current_user() or {}
    return user.get("username") or getattr(request, "session", {}).get("user") or "unknown"


def _require(perm: str):
    if not has_permission(_current_user(), perm):
        return jsonify({"error": "Permission denied", "required": perm}), 403
    return None


def _paginate(rows: list, page: int, page_size: int) -> Dict[str, Any]:
    page = max(1, page)
    page_size = max(1, min(page_size, 500))
    total = len(rows)
    start = (page - 1) * page_size
    return {
        "page": page,
        "page_size": page_size,
        "total": total,
        "items": rows[start:start + page_size],
    }


def _page_args() -> Tuple[int, int]:
    return (
        request.args.get("page", 1, type=int),
        request.args.get("page_size", 50, type=int),
    )


def _op_error(e: operations.OperationError):
    if e.code == "not_found":
        return jsonify({"error": "not_found", "reason": e.message}), 404
    if e.code == "host.unreachable":
        return jsonify({"error": "host.unreachable", "reason": e.message}), 409
    if e.code == "validation":
        return jsonify({"error": "validation_failed", "reason": e.message}), 400
    if e.code == "conflict":
        return jsonify({"error": "conflict", "reason": e.message}), 409
    return jsonify({"error": e.code, "reason": e.message}), 422


def _body() -> dict:
    return request.get_json(silent=True) or {}


def _body_int(key: str):
    """Int param from JSON body, falling back to the query string."""
    val = _body().get(key, request.args.get(key, type=int))
    try:
        return int(val) if val is not None else None
    except (TypeError, ValueError):
        return None


def _body_str(key: str) -> str:
    val = _body().get(key, request.args.get(key))
    return str(val).strip() if val is not None else ""


# ---- UI / status ----


def ui_handler():
    return send_file(os.path.join(MODULE_DIR, "ui.html"), mimetype="text/html")


def status_handler():
    if err := _require(PERM_VIEW):
        return err
    try:
        conns = models.list_connections()
        return jsonify(
            {
                "plugin": "rockstor",
                "status": "running",
                "connection_count": len(conns),
                "connections": [c.to_dict() for c in conns],
            }
        ), 200
    except Exception as e:
        log.error("[rockstor] status error: %s", e)
        return jsonify({"plugin": "rockstor", "status": "degraded", "error": str(e)}), 500


# ---- Connections ----


def connections_handler():
    if request.method == "POST":
        return _create_connection()
    if err := _require(PERM_VIEW):
        return err
    try:
        conns = models.list_connections()
        return jsonify({"connections": [c.to_dict() for c in conns]}), 200
    except Exception as e:
        log.error("[rockstor] list connections error: %s", e)
        return jsonify({"error": str(e)}), 500


def _create_connection():
    if err := _require(PERM_CONNECTOR):
        return err
    body = _body()
    errors = models.validate_connection_input(body)
    if errors:
        return jsonify({"error": "validation_failed", "details": errors}), 400
    try:
        c = connector.RockstorConnector(
            base_url=body["endpoint_url"].strip(),
            credential=body.get("credential") or {},
            tls_verify=bool(body.get("tls_verify", True)),
        )
        test = c.test_connection()
        conn = models.create_connection(body)
        assert conn.id is not None  # row was just inserted
        models.update_connection_status(
            conn.id, "reachable", models._now_iso(),
            version=test.get("version") or "", hostname=test.get("hostname") or "",
        )
        try:
            inventory.refresh_connection(conn.id)
        except connector.ConnectorError as e:
            log.warning("[rockstor] initial inventory refresh failed: %s", e)
        log_audit(
            _actor(), "rockstor.connection.create",
            f"Created Rockstor connection {conn.id} ({conn.endpoint_url})",
        )
        return jsonify(
            {
                "id": conn.id,
                "status": "created",
                "connectivity_status": "reachable",
                "version": test.get("version", ""),
                "hostname": test.get("hostname", ""),
            }
        ), 201
    except connector.ConnectorError as e:
        code = 401 if e.code == "auth.forbidden" else 422
        return jsonify({"error": e.code, "reason": e.message}), code
    except Exception as e:
        log.error("[rockstor] create connection error: %s", e)
        return jsonify({"error": "unreachable", "reason": str(e)}), 422


def connection_test_handler():
    """POST {connection_id} — probe the appliance and update status."""
    if err := _require(PERM_CONNECTOR):
        return err
    conn_id = _body_int("connection_id")
    conn = models.get_connection(conn_id) if conn_id is not None else None
    if not conn:
        return jsonify({"error": "not_found"}), 404
    try:
        c = connector.build_connector(conn)
        result = c.test_connection()
        models.update_connection_status(
            conn_id, "reachable", models._now_iso(),
            version=result.get("version") or None, hostname=result.get("hostname") or None,
        )
        log_audit(_actor(), "rockstor.connection.test",
                  f"Tested Rockstor connection {conn_id}: reachable")
        return jsonify(result), 200
    except connector.ConnectorError as e:
        models.update_connection_status(conn_id, "unreachable", None)
        log_audit(_actor(), "rockstor.connection.test",
                  f"Tested Rockstor connection {conn_id}: {e.message}")
        return jsonify({"status": "unreachable", "reason": e.message, "code": e.code}), 422


def connection_delete_handler():
    """POST/DELETE {connection_id} — remove a connection and its inventory."""
    if err := _require(PERM_CONNECTOR):
        return err
    conn_id = _body_int("connection_id")
    if conn_id is None or not models.get_connection(conn_id):
        return jsonify({"error": "not_found"}), 404
    try:
        models.delete_connection(conn_id)
        log_audit(_actor(), "rockstor.connection.delete",
                  f"Deleted Rockstor connection {conn_id}")
        return jsonify({"deleted": conn_id}), 200
    except Exception as e:
        log.error("[rockstor] delete connection error: %s", e)
        return jsonify({"error": str(e)}), 500


# ---- Inventory ----


def inventory_refresh_handler():
    if err := _require(PERM_CONNECTOR):
        return err
    conn_id = _body_int("connection_id")
    if conn_id is None:
        return jsonify({"error": "validation_failed", "details": {"connection_id": "required"}}), 400
    if not models.get_connection(conn_id):
        return jsonify({"error": "not_found"}), 404
    try:
        result = inventory.refresh_connection(conn_id)
        log_audit(_actor(), "rockstor.inventory.refresh",
                  f"Refreshed Rockstor connection {conn_id}")
        return jsonify(result), 200
    except connector.ConnectorError as e:
        return jsonify({"error": e.code, "reason": e.message}), 422


def inventory_pools_handler():
    if err := _require(PERM_VIEW):
        return err
    conn_id = request.args.get("connection_id", type=int)
    page, page_size = _page_args()
    return jsonify(_paginate(inventory.get_cached_pools(conn_id), page, page_size)), 200


def inventory_shares_handler():
    if err := _require(PERM_VIEW):
        return err
    conn_id = request.args.get("connection_id", type=int)
    pool_name = request.args.get("pool") or request.args.get("pool_name")
    page, page_size = _page_args()
    return jsonify(_paginate(inventory.get_cached_shares(conn_id, pool_name), page, page_size)), 200


def inventory_snapshots_handler():
    if err := _require(PERM_VIEW):
        return err
    conn_id = request.args.get("connection_id", type=int)
    share_id = request.args.get("share_remote_id", type=int)
    page, page_size = _page_args()
    return jsonify(
        _paginate(inventory.get_cached_snapshots(conn_id, share_id), page, page_size)
    ), 200


def overview_handler():
    """Aggregated dashboard stats across connections, pools, shares and ops."""
    if err := _require(PERM_VIEW):
        return err
    try:
        conns = models.list_connections()
        pools = inventory.get_cached_pools()
        shares = inventory.get_cached_shares()
        snaps = inventory.get_cached_snapshots()
        ops = models.list_operations(None, 500)
        return jsonify({
            "connections": {
                "total": len(conns),
                "reachable": sum(1 for c in conns if c.connectivity_status == "reachable"),
            },
            "pools": {"total": len(pools)},
            "shares": {"total": len(shares)},
            "snapshots": {"total": len(snaps)},
            "capacity": {
                "size_kib": sum(int(p.get("size_kib") or 0) for p in pools),
                "free_kib": sum(int(p.get("free_kib") or 0) for p in pools),
                "used_kib": sum(int(p.get("used_kib") or 0) for p in pools),
            },
            "operations": {
                "recent": len(ops),
                "running": sum(1 for o in ops if o.get("status") in ("pending", "running")),
                "failed": sum(1 for o in ops if o.get("status") == "failed"),
                "latest": ops[:5],
            },
        }), 200
    except Exception as e:
        log.error("[rockstor] overview error: %s", e)
        return jsonify({"error": str(e)}), 500


# ---- Access keys (Rockstor OAuth applications) ----


def _connector_or_404(conn_id):
    conn = models.get_connection(conn_id)
    if conn is None:
        return None, None
    return connector.build_connector(conn), conn


def appliance_handler():
    """GET ?connection_id= — live appliance detail for the overview cards."""
    if err := _require(PERM_VIEW):
        return err
    conn_id = request.args.get("connection_id", type=int)
    if conn_id is None:
        return jsonify({"error": "validation_failed",
                        "details": {"connection_id": "required"}}), 400
    c, conn = _connector_or_404(conn_id)
    if conn is None:
        return jsonify({"error": "not_found", "reason": f"connection {conn_id} not found"}), 404
    try:
        info = c.test_connection()
    except connector.ConnectorError as e:
        return jsonify({"error": e.code, "reason": e.message}), 422
    disks: List[Dict[str, Any]] = []
    keys: List[Dict[str, Any]] = []
    uptime: Optional[int] = None
    try:
        disks = c.list_disks()
        keys = c.list_access_keys()
        uptime = c.uptime_seconds()
    except connector.ConnectorError as e:
        log.warning("[rockstor] appliance detail partially failed: %s", e)
    return jsonify({
        "connection_id": conn.id,
        "reachable": True,
        "hostname": info.get("hostname", ""),
        "version": info.get("version", ""),
        "uuid": info.get("uuid", ""),
        "ip": info.get("ip", ""),
        "uptime_seconds": uptime,
        "access_keys": len(keys),
        "disks": {
            "total": len(disks),
            "offline": sum(1 for d in disks if d.get("offline")),
            "smart_enabled": sum(1 for d in disks if d.get("smart_enabled")),
            "capacity_kib": sum(int(d.get("size") or 0) for d in disks),
            "allocated_kib": sum(int(d.get("allocated") or 0) for d in disks),
            "items": [
                {
                    "name": d.get("name") or d.get("temp_name") or "",
                    "model": d.get("model") or "",
                    "serial": d.get("serial") or "",
                    "transport": d.get("transport") or "",
                    "pool_name": d.get("pool_name") or "",
                    "size_kib": int(d.get("size") or 0),
                    "offline": bool(d.get("offline")),
                    "smart_enabled": bool(d.get("smart_enabled")),
                }
                for d in disks[:16]
            ],
        },
    }), 200


def access_keys_handler():
    """GET ?connection_id= (optional) — access keys merged across connections.

    Keys carry client secrets, so listing requires the connector scope
    rather than the plain viewer scope. `users` maps connection_id →
    candidate system usernames for the create-key modal.
    """
    if err := _require(PERM_CONNECTOR):
        return err
    conn_id = request.args.get("connection_id", type=int)
    conns = models.list_connections()
    if conn_id is not None:
        conns = [c for c in conns if c.id == conn_id]
    items: List[Dict[str, Any]] = []
    users: Dict[str, List[str]] = {}
    errors: List[Dict[str, Any]] = []
    for conn in conns:
        try:
            c = connector.build_connector(conn)
            for k in c.list_access_keys():
                items.append({
                    "id": k.get("id"),
                    "name": k.get("name") or "",
                    "client_id": k.get("client_id") or "",
                    "client_secret": k.get("client_secret") or "",
                    "user_id": k.get("user"),
                    "application": k.get("application"),
                    "is_internal": bool(k.get("is_internal")),
                    "connection_id": conn.id,
                })
            users[str(conn.id)] = sorted(
                u.get("username") for u in c.list_users() if u.get("username")
            )
        except connector.ConnectorError as e:
            errors.append({"connection_id": conn.id, "error": e.code, "reason": e.message})
    return jsonify({"items": items, "total": len(items), "users": users, "errors": errors}), 200


def access_key_create_handler():
    """POST {connection_id, name, username} — create an access key."""
    if err := _require(PERM_MANAGE):
        return err
    conn_id = _body_int("connection_id")
    name = _body_str("name")
    username = _body_str("username")
    details: Dict[str, str] = {}
    if conn_id is None:
        details["connection_id"] = "required"
    if not name:
        details["name"] = "required"
    if not username:
        details["username"] = "required"
    if details:
        return jsonify({"error": "validation_failed", "details": details}), 400
    c, conn = _connector_or_404(conn_id)
    if conn is None:
        return jsonify({"error": "not_found", "reason": f"connection {conn_id} not found"}), 404
    try:
        result = c.create_access_key(name, username)
        log_audit(_actor(), "rockstor.accesskey.create",
                  f"Created Rockstor access key {name} on connection {conn_id}")
        return jsonify(result), 201
    except connector.ConnectorError as e:
        code = 401 if e.code == "auth.forbidden" else 422
        return jsonify({"error": e.code, "reason": e.message}), code


def access_key_delete_handler():
    """POST/DELETE {connection_id, name} — delete an access key."""
    if err := _require(PERM_MANAGE):
        return err
    conn_id = _body_int("connection_id")
    name = _body_str("name")
    if conn_id is None or not name:
        return jsonify({"error": "validation_failed", "details": {
            "connection_id": "required", "name": "required"}}), 400
    c, conn = _connector_or_404(conn_id)
    if conn is None:
        return jsonify({"error": "not_found", "reason": f"connection {conn_id} not found"}), 404
    try:
        c.delete_access_key(name)
        log_audit(_actor(), "rockstor.accesskey.delete",
                  f"Deleted Rockstor access key {name} on connection {conn_id}")
        return jsonify({"ok": True}), 200
    except connector.ConnectorError as e:
        code = 404 if e.code == "not_found" else (401 if e.code == "auth.forbidden" else 422)
        return jsonify({"error": e.code, "reason": e.message}), code


# ---- Pool operations ----


def pool_create_handler():
    if err := _require(PERM_MANAGE):
        return err
    body = _body()
    conn_id = body.get("connection_id")
    name = (body.get("name") or "").strip()
    if conn_id is None or not name:
        return jsonify({"error": "validation_failed",
                        "details": {"connection_id": "required", "name": "required"}}), 400
    try:
        result = operations.create_pool(
            conn_id, name, body.get("disks") or [],
            (body.get("raid_level") or "single").strip(), _actor())
        with contextlib.suppress(connector.ConnectorError):
            inventory.refresh_connection(conn_id)
        log_audit(_actor(), "rockstor.pool.create", f"Created Rockstor pool {name}")
        return jsonify(result), 202
    except operations.OperationError as e:
        return _op_error(e)


def pool_action_handler():
    """POST {connection_id, remote_id, action, force?} — scrub/balance/delete a pool."""
    if err := _require(PERM_MANAGE):
        return err
    body = _body()
    conn_id = _body_int("connection_id")
    remote_id = _body_int("remote_id")
    action = _body_str("action")
    if conn_id is None or remote_id is None or not action:
        return jsonify({"error": "validation_failed", "details": {
            "connection_id": "required", "remote_id": "required", "action": "required"}}), 400
    try:
        result = operations.pool_action(conn_id, remote_id, action, bool(body.get("force")), _actor())
        if action == "delete":
            with contextlib.suppress(connector.ConnectorError):
                inventory.refresh_connection(conn_id)
        log_audit(_actor(), f"rockstor.pool.{action}",
                  f"Rockstor pool {remote_id} action={action}")
        return jsonify(result), 202
    except operations.OperationError as e:
        return _op_error(e)


# ---- Share operations ----


def share_create_handler():
    if err := _require(PERM_MANAGE):
        return err
    body = _body()
    conn_id = body.get("connection_id")
    name = (body.get("name") or "").strip()
    if conn_id is None or not name:
        return jsonify({"error": "validation_failed",
                        "details": {"connection_id": "required", "name": "required"}}), 400
    try:
        result = operations.create_share(
            conn_id, (body.get("pool") or "").strip(), name,
            body.get("size_kib") or body.get("size") or 0,
            (body.get("compression") or "no").strip(), _actor())
        with contextlib.suppress(connector.ConnectorError):
            inventory.refresh_connection(conn_id)
        log_audit(_actor(), "rockstor.share.create", f"Created Rockstor share {name}")
        return jsonify(result), 202
    except operations.OperationError as e:
        return _op_error(e)


def share_resize_handler():
    """POST {connection_id, remote_id, size_kib} — resize a share."""
    if err := _require(PERM_MANAGE):
        return err
    body = _body()
    conn_id = _body_int("connection_id")
    remote_id = _body_int("remote_id")
    size = body.get("size_kib") or body.get("size")
    if conn_id is None or remote_id is None or size is None:
        return jsonify({"error": "validation_failed",
                        "details": {"connection_id": "required", "remote_id": "required",
                                    "size_kib": "required"}}), 400
    try:
        result = operations.resize_share(conn_id, remote_id, size, _actor())
        with contextlib.suppress(connector.ConnectorError):
            inventory.refresh_connection(conn_id)
        log_audit(_actor(), "rockstor.share.resize", f"Resized Rockstor share {remote_id}")
        return jsonify(result), 202
    except operations.OperationError as e:
        return _op_error(e)


def share_delete_handler():
    """POST/DELETE {connection_id, remote_id, force?} — delete a share."""
    if err := _require(PERM_MANAGE):
        return err
    body = _body()
    conn_id = _body_int("connection_id")
    remote_id = _body_int("remote_id")
    if conn_id is None or remote_id is None:
        return jsonify({"error": "validation_failed",
                        "details": {"connection_id": "required", "remote_id": "required"}}), 400
    try:
        result = operations.delete_share(conn_id, remote_id, bool(body.get("force")), _actor())
        with contextlib.suppress(connector.ConnectorError):
            inventory.refresh_connection(conn_id)
        log_audit(_actor(), "rockstor.share.delete", f"Deleted Rockstor share {remote_id}")
        return jsonify(result), 202
    except operations.OperationError as e:
        return _op_error(e)


# ---- Snapshot operations ----


def snapshot_create_handler():
    if err := _require(PERM_MANAGE):
        return err
    body = _body()
    conn_id = body.get("connection_id")
    share_remote_id = body.get("share_remote_id")
    name = (body.get("name") or "").strip()
    if conn_id is None or share_remote_id is None or not name:
        return jsonify({"error": "validation_failed", "details": {
            "connection_id": "required", "share_remote_id": "required", "name": "required"}}), 400
    try:
        result = operations.create_snapshot(
            conn_id, int(share_remote_id), name,
            bool(body.get("writable")), bool(body.get("uvisible")), _actor())
        with contextlib.suppress(connector.ConnectorError):
            inventory.refresh_connection(conn_id)
        log_audit(_actor(), "rockstor.snapshot.create",
                  f"Created Rockstor snapshot {name} on share {share_remote_id}")
        return jsonify(result), 202
    except operations.OperationError as e:
        return _op_error(e)


def snapshot_clone_handler():
    """POST {connection_id, share_remote_id, name, new_name} — clone a snapshot."""
    if err := _require(PERM_MANAGE):
        return err
    body = _body()
    conn_id = _body_int("connection_id")
    share_remote_id = _body_int("share_remote_id")
    name = _body_str("name")
    new_name = (body.get("new_name") or "").strip()
    if conn_id is None or share_remote_id is None or not name or not new_name:
        return jsonify({"error": "validation_failed",
                        "details": {"connection_id": "required", "share_remote_id": "required",
                                    "name": "required", "new_name": "required"}}), 400
    try:
        result = operations.clone_snapshot(conn_id, share_remote_id, name, new_name, _actor())
        with contextlib.suppress(connector.ConnectorError):
            inventory.refresh_connection(conn_id)
        log_audit(_actor(), "rockstor.snapshot.clone",
                  f"Cloned Rockstor snapshot {name} -> {new_name}")
        return jsonify(result), 202
    except operations.OperationError as e:
        return _op_error(e)


def snapshot_delete_handler():
    """POST/DELETE {connection_id, share_remote_id, name} — delete a snapshot."""
    if err := _require(PERM_MANAGE):
        return err
    conn_id = _body_int("connection_id")
    share_remote_id = _body_int("share_remote_id")
    name = _body_str("name")
    if conn_id is None or share_remote_id is None or not name:
        return jsonify({"error": "validation_failed",
                        "details": {"connection_id": "required", "share_remote_id": "required",
                                    "name": "required"}}), 400
    try:
        result = operations.delete_snapshot(conn_id, share_remote_id, name, _actor())
        with contextlib.suppress(connector.ConnectorError):
            inventory.refresh_connection(conn_id)
        log_audit(_actor(), "rockstor.snapshot.delete",
                  f"Deleted Rockstor snapshot {name} on share {share_remote_id}")
        return jsonify(result), 202
    except operations.OperationError as e:
        return _op_error(e)


# ---- Job tracker ----


def operations_list_handler():
    if err := _require(PERM_VIEW):
        return err
    conn_id = request.args.get("connection_id", type=int)
    page, page_size = _page_args()
    return jsonify(_paginate(models.list_operations(conn_id, 500), page, page_size)), 200


def operation_detail_handler():
    """GET ?op_id=<id> — a single operation record."""
    if err := _require(PERM_VIEW):
        return err
    op_id = _body_str("op_id") or _body_str("id")
    op = models.get_operation(op_id) if op_id else None
    if not op:
        return jsonify({"error": "not_found"}), 404
    return jsonify(op), 200


def operation_cancel_handler():
    """POST {op_id} — cancel a pending operation."""
    if err := _require(PERM_MANAGE):
        return err
    op_id = _body_str("op_id") or _body_str("id")
    op = models.get_operation(op_id) if op_id else None
    if not op:
        return jsonify({"error": "not_found"}), 404
    if op.get("status") != "pending":
        return jsonify({"error": "Only pending operations can be cancelled"}), 409
    models.finish_operation(op_id, "cancelled")
    log_audit(_actor(), "rockstor.operation.cancel", f"Cancelled Rockstor operation {op_id}")
    return jsonify({"ok": True, "operation_id": op_id, "status": "cancelled"}), 200


def operation_retry_handler():
    """POST {op_id} — re-run a terminal (failed/cancelled) operation."""
    if err := _require(PERM_MANAGE):
        return err
    op_id = _body_str("op_id") or _body_str("id")
    op = models.get_operation(op_id) if op_id else None
    if not op:
        return jsonify({"error": "not_found"}), 404
    if op.get("status") not in models.TERMINAL_OP_STATUSES:
        return jsonify({"error": "Only terminal operations can be retried"}), 409
    new_id = models.retry_operation(op_id, actor=_actor())
    if not new_id:
        return jsonify({"error": "retry_failed"}), 500
    try:
        result = operations.run_operation(new_id)
        log_audit(_actor(), "rockstor.operation.retry",
                  f"Retried Rockstor operation {op_id} as {new_id}")
        return jsonify({"ok": True, "operation_id": new_id, "status": result.get("status")}), 202
    except operations.OperationError as e:
        return _op_error(e)


# Route → handler table. Every mutating route accepts POST (and DELETE where
# the action is destructive) since the native proxy dispatches all methods to
# the single registered handler per subpath.
ROUTES = {
    "ui": ui_handler,
    "status": status_handler,
    "connections": connections_handler,
    "connections/test": connection_test_handler,
    "connections/delete": connection_delete_handler,
    "inventory/refresh": inventory_refresh_handler,
    "inventory/pools": inventory_pools_handler,
    "inventory/shares": inventory_shares_handler,
    "inventory/snapshots": inventory_snapshots_handler,
    "overview": overview_handler,
    "appliance": appliance_handler,
    "access-keys": access_keys_handler,
    "access-keys/create": access_key_create_handler,
    "access-keys/delete": access_key_delete_handler,
    "operations": operations_list_handler,
    "operations/detail": operation_detail_handler,
    "operations/cancel": operation_cancel_handler,
    "operations/retry": operation_retry_handler,
    "operations/pool": pool_create_handler,
    "operations/pool/action": pool_action_handler,
    "operations/share": share_create_handler,
    "operations/share/resize": share_resize_handler,
    "operations/share/delete": share_delete_handler,
    "operations/snapshot": snapshot_create_handler,
    "operations/snapshot/clone": snapshot_clone_handler,
    "operations/snapshot/delete": snapshot_delete_handler,
}
