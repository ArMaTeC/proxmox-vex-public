# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/native/rockstor/operations.py
# Project:     ProxmoxVEx
# Version:     1.2.662
# Build:       2026.10.21
# Description: Rockstor pool/share/snapshot operations.
# Usage:       import ProxmoxVEx.native.rockstor.operations
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-10-21
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Rockstor pool/share/snapshot operations.

Every remote mutation is recorded in ``rockstor_operations`` and mirrored
into the shared plugin task tray (pending -> running -> terminal), so the
UI's Jobs tab and the main app tray both reflect what ran. Operations
resolve the backing connection from the cached inventory row so the remote
call always lands on the appliance that owns the object.

Each ``*_op`` helper takes an already-persisted operation id so both the
public entry points (which create the row) and the retry path (which
re-runs a row created by ``models.retry_operation``) share one executor.
"""

import logging
from typing import Any, Dict, Optional

from . import connector, models

log = logging.getLogger("plugin.rockstor.operations")

TERMINAL = models.TERMINAL_OP_STATUSES


class OperationError(Exception):
    def __init__(self, code: str, message: str):
        self.code = code
        super().__init__(message)
        self.message = message


def _conn_or_404(conn_id: Optional[int]):
    conn = models.get_connection(conn_id) if conn_id else None
    if conn is None:
        raise OperationError("not_found", f"Connection {conn_id} not found")
    if conn.connectivity_status == "unreachable":
        raise OperationError("host.unreachable", f"Connection {conn.display_name} is unreachable")
    return conn


def _finish(op_id: str, fn) -> Dict[str, Any]:
    """Execute a remote call under the operation lifecycle."""
    models.update_operation(op_id, status="running")
    try:
        result = fn() or {}
        models.finish_operation(op_id, "completed", result=result)
        return {"operation_id": op_id, "status": "completed", "result": result}
    except connector.ConnectorError as e:
        status = "unreachable" if e.code == "connection.unreachable" else "failed"
        models.finish_operation(op_id, status, error=e.message)
        raise OperationError(e.code, e.message) from e


def _exec(op_id: str, action: str, connection_id: int, target: str, params: Dict[str, Any]):
    """Dispatch a persisted operation row to its connector call."""
    conn = _conn_or_404(connection_id)
    assert conn.id is not None  # persisted rows always have an id
    c = connector.build_connector(conn)
    if action == "pool.create":
        return _finish(op_id, lambda: c.create_pool(target, params.get("disks") or [],
                                                  params.get("raid_level") or "single"))
    if action == "pool.scrub":
        return _finish(op_id, lambda: c.scrub_pool(int(params.get("remote_id") or 0),
                                                 force=bool(params.get("force"))))
    if action == "pool.balance":
        return _finish(op_id, lambda: c.balance_pool(int(params.get("remote_id") or 0),
                                                     force=bool(params.get("force"))))
    if action == "pool.delete":
        return _finish(op_id, lambda: c.delete_pool(int(params.get("remote_id") or 0),
                                                    force=bool(params.get("force"))))
    if action == "share.create":
        return _finish(op_id, lambda: c.create_share(params.get("pool") or "", target,
                                                   int(params.get("size_kib") or 0),
                                                   params.get("compression") or "no"))
    if action == "share.resize":
        return _finish(op_id, lambda: c.resize_share(int(params.get("remote_id") or 0),
                                                     int(params.get("size_kib") or 0)))
    if action == "share.delete":
        return _finish(op_id, lambda: c.delete_share(int(params.get("remote_id") or 0),
                                                     force=bool(params.get("force"))))
    if action == "snapshot.create":
        return _finish(op_id, lambda: c.create_snapshot(int(params.get("share_remote_id") or 0),
                                                        target, bool(params.get("writable")),
                                                        bool(params.get("uvisible"))))
    if action == "snapshot.delete":
        return _finish(op_id, lambda: c.delete_snapshot(int(params.get("share_remote_id") or 0),
                                                        target))
    if action == "snapshot.clone":
        return _finish(op_id, lambda: c.clone_snapshot(int(params.get("share_remote_id") or 0),
                                                       target, params.get("new_name") or ""))
    raise OperationError("validation", f"Unknown operation action {action}")


def run_operation(op_id: str) -> Dict[str, Any]:
    """Execute a persisted pending operation row."""
    op = models.get_operation(op_id)
    if not op:
        raise OperationError("not_found", f"Operation {op_id} not found")
    if op.get("status") not in ("pending", "running"):
        raise OperationError("conflict", f"Operation {op_id} already finished")
    return _exec(op_id, op.get("action") or "", op.get("connection_id") or 0,
                 op.get("target") or "", models.operation_params(op))


# ---- Public entry points: validate -> persist -> execute ----


def create_pool(connection_id: int, name: str, disks: list, raid_level: str, actor: str) -> Dict[str, Any]:
    conn = _conn_or_404(connection_id)
    assert conn.id is not None  # persisted rows always have an id
    if not models.valid_name(name):
        raise OperationError("validation", "Invalid pool name")
    clean_disks = [str(d).strip() for d in (disks or []) if str(d or "").strip()]
    if not clean_disks:
        raise OperationError("validation", "disks must be a non-empty list")
    if raid_level not in models.RAID_LEVELS:
        raise OperationError("validation", f"raid_level must be one of {sorted(models.RAID_LEVELS)}")
    op_id = models.create_operation(
        conn.id, "pool.create", "pool", name,
        {"disks": clean_disks, "raid_level": raid_level}, actor)
    return _exec(op_id, "pool.create", conn.id, name,
                 {"disks": clean_disks, "raid_level": raid_level})


def pool_action(connection_id: int, remote_id: int, action: str, force: bool, actor: str) -> Dict[str, Any]:
    conn = _conn_or_404(connection_id)
    assert conn.id is not None  # persisted rows always have an id
    pool = models.get_pool(conn.id, remote_id)
    if pool is None:
        raise OperationError("not_found", f"Pool {remote_id} not found in inventory")
    if action not in models.POOL_ACTIONS:
        raise OperationError("validation", f"action must be one of {sorted(models.POOL_ACTIONS)}")
    op_id = models.create_operation(
        conn.id, f"pool.{action}", "pool", pool.get("name") or str(remote_id),
        {"remote_id": remote_id, "force": bool(force)}, actor)
    return _exec(op_id, f"pool.{action}", conn.id, pool.get("name") or str(remote_id),
                 {"remote_id": remote_id, "force": bool(force)})


def create_share(
    connection_id: int, pool_name: str, name: str, size_kib: int,
    compression: str, actor: str,
) -> Dict[str, Any]:
    conn = _conn_or_404(connection_id)
    assert conn.id is not None  # persisted rows always have an id
    if not models.valid_name(name):
        raise OperationError("validation", "Invalid share name")
    if not (pool_name or "").strip():
        raise OperationError("validation", "pool is required")
    if compression not in models.COMPRESSION_TYPES:
        raise OperationError("validation", f"compression must be one of {sorted(models.COMPRESSION_TYPES)}")
    try:
        size_kib = int(size_kib)
    except (TypeError, ValueError):
        raise OperationError("validation", "size_kib must be an integer") from None
    if size_kib <= 0:
        raise OperationError("validation", "size_kib must be positive")
    op_id = models.create_operation(
        conn.id, "share.create", "share", name,
        {"pool": pool_name, "size_kib": size_kib, "compression": compression}, actor)
    return _exec(op_id, "share.create", conn.id, name,
                 {"pool": pool_name, "size_kib": size_kib, "compression": compression})


def resize_share(connection_id: int, remote_id: int, size_kib: int, actor: str) -> Dict[str, Any]:
    conn = _conn_or_404(connection_id)
    assert conn.id is not None  # persisted rows always have an id
    share = models.get_share(conn.id, remote_id)
    if share is None:
        raise OperationError("not_found", f"Share {remote_id} not found in inventory")
    try:
        size_kib = int(size_kib)
    except (TypeError, ValueError):
        raise OperationError("validation", "size_kib must be an integer") from None
    if size_kib <= 0:
        raise OperationError("validation", "size_kib must be positive")
    op_id = models.create_operation(
        conn.id, "share.resize", "share", share.get("name") or str(remote_id),
        {"remote_id": remote_id, "size_kib": size_kib}, actor)
    return _exec(op_id, "share.resize", conn.id, share.get("name") or str(remote_id),
                 {"remote_id": remote_id, "size_kib": size_kib})


def delete_share(connection_id: int, remote_id: int, force: bool, actor: str) -> Dict[str, Any]:
    conn = _conn_or_404(connection_id)
    assert conn.id is not None  # persisted rows always have an id
    share = models.get_share(conn.id, remote_id)
    if share is None:
        raise OperationError("not_found", f"Share {remote_id} not found in inventory")
    op_id = models.create_operation(
        conn.id, "share.delete", "share", share.get("name") or str(remote_id),
        {"remote_id": remote_id, "force": bool(force)}, actor)
    return _exec(op_id, "share.delete", conn.id, share.get("name") or str(remote_id),
                 {"remote_id": remote_id, "force": bool(force)})


def create_snapshot(
    connection_id: int, share_remote_id: int, name: str,
    writable: bool, uvisible: bool, actor: str,
) -> Dict[str, Any]:
    conn = _conn_or_404(connection_id)
    assert conn.id is not None  # persisted rows always have an id
    share = models.get_share(conn.id, share_remote_id)
    if share is None:
        raise OperationError("not_found", f"Share {share_remote_id} not found in inventory")
    if not models.valid_name(name):
        raise OperationError("validation", "Invalid snapshot name")
    op_id = models.create_operation(
        conn.id, "snapshot.create", "snapshot", name,
        {"share_remote_id": share_remote_id, "share": share.get("name"),
         "writable": bool(writable), "uvisible": bool(uvisible)}, actor)
    return _exec(op_id, "snapshot.create", conn.id, name,
                 {"share_remote_id": share_remote_id, "writable": bool(writable),
                  "uvisible": bool(uvisible)})


def delete_snapshot(connection_id: int, share_remote_id: int, name: str, actor: str) -> Dict[str, Any]:
    conn = _conn_or_404(connection_id)
    assert conn.id is not None  # persisted rows always have an id
    share = models.get_share(conn.id, share_remote_id)
    if share is None:
        raise OperationError("not_found", f"Share {share_remote_id} not found in inventory")
    if not models.valid_name(name):
        raise OperationError("validation", "Invalid snapshot name")
    op_id = models.create_operation(
        conn.id, "snapshot.delete", "snapshot", name,
        {"share_remote_id": share_remote_id, "share": share.get("name")}, actor)
    return _exec(op_id, "snapshot.delete", conn.id, name,
                 {"share_remote_id": share_remote_id})


def clone_snapshot(
    connection_id: int, share_remote_id: int, name: str, new_name: str, actor: str,
) -> Dict[str, Any]:
    conn = _conn_or_404(connection_id)
    assert conn.id is not None  # persisted rows always have an id
    share = models.get_share(conn.id, share_remote_id)
    if share is None:
        raise OperationError("not_found", f"Share {share_remote_id} not found in inventory")
    if not models.valid_name(name) or not models.valid_name(new_name):
        raise OperationError("validation", "Invalid snapshot or clone name")
    op_id = models.create_operation(
        conn.id, "snapshot.clone", "snapshot", name,
        {"share_remote_id": share_remote_id, "share": share.get("name"), "new_name": new_name}, actor)
    return _exec(op_id, "snapshot.clone", conn.id, name,
                 {"share_remote_id": share_remote_id, "new_name": new_name})
