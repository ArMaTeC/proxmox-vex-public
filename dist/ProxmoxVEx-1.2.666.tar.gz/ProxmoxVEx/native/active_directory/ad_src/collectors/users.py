# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/native/active_directory/ad_src/collectors/users.py
# Project:     ProxmoxVEx
# Version:     1.2.662
# Build:       2026.10.21
# Description: Users collector for Active Directory.
# Usage:       import ProxmoxVEx.native.active_directory.ad_src.collec
#              tors.users
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-10-21
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Users collector for Active Directory."""

from __future__ import annotations

from typing import Any

from ad_src.client import ADClient


def collect_users(client: ADClient) -> dict[str, Any]:
    """Return AD users as an ``{'ok': True, 'data': [...]}`` shape."""
    return client.list_users()
