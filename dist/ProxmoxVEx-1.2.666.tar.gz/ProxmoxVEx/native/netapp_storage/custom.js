/* --- ProxmoxVEx auto-header start ---
 * -------------------------------------------------------------------
 * File:        ProxmoxVEx/native/netapp_storage/custom.js
 * Project:     ProxmoxVEx
 * Version:     1.2.662
 * Build:       2026.10.21
 * Description: Custom JS source
 * Docs:        https://proxmoxvex.com/docs
 * Generated:   2026-10-21
 * -------------------------------------------------------------------
 * --- ProxmoxVEx auto-header end --- */

/*
 * Put any custom JavaScript overrides or helpers here.
 * This file is loaded after ui.js so you can extend or override existing behaviour.
 */
