# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/native/netapp_storage/api/settings.py
# Project:     ProxmoxVEx
# Version:     1.2.662
# Build:       2026.10.21
# Description: Settings API — SMTP / email notification configuration
#              + DB export/import.
# Usage:       import ProxmoxVEx.native.netapp_storage.api.settings
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-10-21
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""
Settings API — SMTP / email notification configuration + DB export/import.

  settings/smtp           GET   – load SMTP config (password omitted)
  settings/smtp/save      POST  – save SMTP config
  settings/smtp/test      POST  – test SMTP connection with stored config
  settings/export         GET   – download all netapp_* tables as JSON
  settings/import         POST  – restore from exported JSON (idempotent upsert)
"""

import email.mime.multipart
import email.mime.text
import json
import logging
import os
import smtplib
import ssl
from datetime import UTC, datetime

# Plugin directory (two levels up from this file: api/ → netapp_storage/)
_PLUGIN_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

from flask import Response, jsonify, request  # noqa: E402

from ProxmoxVEx.core.db import get_db  # noqa: E402
from ProxmoxVEx.native.registry import register_native_route  # noqa: E402

log = logging.getLogger(__name__)
from ..core._helpers import PLUGIN_ID  # noqa: E402, F401


def _require_admin():
    from ProxmoxVEx.models.permissions import ROLE_ADMIN
    from ProxmoxVEx.utils.auth import get_user_record

    username = getattr(request, "session", {}).get("user", "")
    if get_user_record(username).get("role") != ROLE_ADMIN:
        return {"error": "Admin access required"}, 403
    return None


def _ensure_smtp_row(db):
    existing = db.query_one("SELECT id FROM netapp_smtp_config WHERE id='default'")
    if not existing:
        db.execute(
            "INSERT INTO netapp_smtp_config (id, updated_at) VALUES ('default', ?)",
            (datetime.now(UTC).isoformat(),),
        )


def _smtp_get():
    db = get_db()
    _ensure_smtp_row(db)
    row = db.query_one("SELECT * FROM netapp_smtp_config WHERE id='default'")
    d = dict(row)
    return jsonify({
        "host": d.get("host", ""),
        "port": d.get("port", 587),
        "username": d.get("username", ""),
        "from_address": d.get("from_address", ""),
        "encryption": d.get("encryption", "starttls"),
        "enabled": bool(d.get("enabled", 0)),
        "has_password": bool(d.get("password_encrypted", "")),
    })


def _smtp_save():
    err = _require_admin()
    if err:
        return err
    db = get_db()
    _ensure_smtp_row(db)
    data = request.get_json() or {}
    now = datetime.now(UTC).isoformat()

    host = data.get("host", "").strip()
    port = int(data.get("port") or 587)
    username = data.get("username", "").strip()
    from_address = data.get("from_address", "").strip()
    encryption = data.get("encryption", "starttls")
    enabled = 1 if data.get("enabled") else 0

    if encryption not in ("starttls", "ssl", "none"):
        return jsonify({"error": "Invalid encryption value"}), 400

    if data.get("password"):
        pw_enc = db._encrypt(data["password"])
        db.execute(
            "UPDATE netapp_smtp_config "
            "SET host=?,port=?,username=?,password_encrypted=?,"
            "from_address=?,encryption=?,enabled=?,updated_at=? WHERE id='default'",
            (host, port, username, pw_enc, from_address, encryption, enabled, now),
        )
    else:
        db.execute(
            "UPDATE netapp_smtp_config "
            "SET host=?,port=?,username=?,from_address=?,encryption=?,enabled=?,updated_at=? "
            "WHERE id='default'",
            (host, port, username, from_address, encryption, enabled, now),
        )
    log.info("[netapp_storage] SMTP config saved")
    return jsonify({"success": True})


def _smtp_test():
    err = _require_admin()
    if err:
        return err
    db = get_db()
    _ensure_smtp_row(db)
    row = db.query_one("SELECT * FROM netapp_smtp_config WHERE id='default'")
    d = dict(row)
    host = d.get("host", "").strip()
    port = int(d.get("port") or 587)
    username = d.get("username", "").strip()
    password = db._decrypt(d.get("password_encrypted", ""))
    encryption = d.get("encryption", "starttls")

    if not host:
        return jsonify({"success": False, "error": "SMTP host not configured"})

    try:
        _test_smtp_connection(host, port, username, password, encryption)
        return jsonify({"success": True})
    except Exception as exc:
        log.warning(f"[netapp_storage] SMTP test failed: {exc}")
        return jsonify({"success": False, "error": str(exc)})


def _test_smtp_connection(host, port, username, password, encryption):
    ctx = ssl.create_default_context()
    if encryption == "ssl":
        with smtplib.SMTP_SSL(host, port, context=ctx, timeout=10) as s:
            if username and password:
                s.login(username, password)
    elif encryption == "starttls":
        with smtplib.SMTP(host, port, timeout=10) as s:
            s.ehlo()
            s.starttls(context=ctx)
            s.ehlo()
            if username and password:
                s.login(username, password)
    else:
        with smtplib.SMTP(host, port, timeout=10) as s:
            s.ehlo()
            if username and password:
                s.login(username, password)


def _log_severity(msg):
    """Classify a job log message as 'err', 'warn', or 'info'."""
    ml = msg.lower()
    if ml.startswith("error:") or ml.startswith("err:") or "error" in ml[:12]:
        return "err"
    if ml.startswith("warning:") or ml.startswith("warn:") or "warn" in ml[:12]:
        return "warn"
    return "info"


def _format_lag(s):
    """Convert ISO 8601 duration (P0DT4H23M5S) to a human-readable string."""
    import re

    if not s:
        return "–"
    m = re.match(r"P(?:(\d+)D)?T?(?:(\d+)H)?(?:(\d+)M)?(?:(\d+(?:\.\d+)?)S)?", s)
    if not m:
        return s
    parts = []
    if m.group(1):
        parts.append(f"{m.group(1)}d")
    if m.group(2):
        parts.append(f"{m.group(2)}h")
    if m.group(3):
        parts.append(f"{m.group(3)}m")
    if m.group(4):
        parts.append(f"{int(float(m.group(4)))}s")
    return " ".join(parts) if parts else "0s"


def _build_notification_email(
    subject, schedule_name, snap_name, job_status, log_lines=None, extra_rows=None, vm_list=None, datastore=None
):
    """
    Returns (html_body, plain_body).

    Builds an HTML email with:
    - Colour-coded status banner (green / amber / red)
    - Summary table
    - Dark terminal block with [INFO]/[WARN]/[ERR]-tagged log lines
    """
    # ── Determine overall severity ────────────────────────────────────────────
    entries = []
    if log_lines:
        for entry in log_lines[-50:]:
            ts = entry.get("ts", "")[:19].replace("T", " ")
            msg = entry.get("msg", str(entry))
            sev = _log_severity(msg)
            entries.append((ts, sev, msg))

    has_err = any(s == "err" for _, s, _ in entries)
    has_warn = any(s == "warn" for _, s, _ in entries)
    is_done = job_status == "done"

    if not is_done or has_err:
        overall = "err"
    elif has_warn:
        overall = "warn"
    else:
        overall = "ok"

    # ── Visual config per overall status ─────────────────────────────────────
    _cfg = {
        "ok": {
            "banner": "#16a34a",
            "icon": "✓",
            "label": "Snapshot Successful",
            "dot_color": "#16a34a",
            "dot_label": "Success",
        },
        "warn": {
            "banner": "#d97706",
            "icon": "⚠",
            "label": "Snapshot Completed with Warnings",
            "dot_color": "#d97706",
            "dot_label": "Success (with warnings)",
        },
        "err": {
            "banner": "#dc2626",
            "icon": "✗",
            "label": "Snapshot Failed",
            "dot_color": "#dc2626",
            "dot_label": "Failed",
        },
    }
    cfg = _cfg[overall]

    status_label = "Success" if is_done else "Failed"

    # ── Summary rows ─────────────────────────────────────────────────────────
    summary_rows = [
        ("Schedule", schedule_name),
        ("Snapshot", snap_name),
        ("Datastore", datastore) if datastore else None,
        ("Status", f'<span style="color:{cfg["dot_color"]};font-weight:700">● {cfg["dot_label"]}</span>'),
    ]
    summary_rows = [r for r in summary_rows if r is not None]
    if vm_list:

        def _vm_badge(vm):
            vmid = vm.get("vmid", "?")
            name = vm.get("name", "")
            vtype = (vm.get("vm_type") or "qemu").upper()
            label = f"{vtype} {vmid}" + (f" — {name}" if name else "")
            bg = "#1d4ed8" if vtype == "QEMU" else "#6d28d9"
            return (
                f'<span style="display:inline-block;background:{bg};color:#fff;'
                f'border-radius:4px;padding:1px 6px;font-size:11px;margin:1px 2px 1px 0">'
                f"{label}</span>"
            )

        vm_html = "".join(_vm_badge(v) for v in vm_list)
        summary_rows.append(("VMs", vm_html))
    if extra_rows:
        summary_rows.extend(extra_rows)

    summary_html = "".join(
        f"<tr>"
        f'<td style="padding:7px 12px 7px 0;color:#6b7280;white-space:nowrap;vertical-align:top">{k}</td>'
        f'<td style="padding:7px 0;font-weight:500;word-break:break-all">{v}</td>'
        f"</tr>"
        for k, v in summary_rows
    )

    # ── Log lines HTML ────────────────────────────────────────────────────────
    _sev_color = {"err": "#f87171", "warn": "#fbbf24", "info": "#a3e4b0"}
    _sev_tag = {"err": "[ERR] ", "warn": "[WARN]", "info": "[INFO]"}

    def _esc(s):
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")

    log_rows_html = ""
    if entries:
        for ts, sev, msg in entries:
            color = _sev_color[sev]
            tag = _sev_tag[sev]
            log_rows_html += (
                f'<div style="margin:1px 0">'
                f'<span style="color:#6b7280;user-select:none">{_esc(ts)} </span>'
                f'<span style="color:{color};font-weight:700;user-select:none">{tag} </span>'
                f'<span style="color:{color if sev != "info" else "#d1fae5"}">{_esc(msg)}</span>'
                f"</div>"
            )
    else:
        log_rows_html = '<div style="color:#6b7280;font-style:italic">No log entries.</div>'

    # ── Full HTML ─────────────────────────────────────────────────────────────
    html = f"""<!DOCTYPE html>
<html lang="en">
<head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"></head>
<body style="margin:0;padding:20px;background:#f3f4f6;font-family:Arial,Helvetica,sans-serif">
<div style="max-width:680px;margin:0 auto">

  <!-- Status banner -->
  <div style="background:{cfg["banner"]};border-radius:8px 8px 0 0;padding:22px 28px;color:#fff">
    <div style="font-size:22px;font-weight:700">{cfg["icon"]}&nbsp; {cfg["label"]}</div>
    <div style="font-size:13px;opacity:.85;margin-top:4px">NetApp ONTAP Storage Plugin · ProxmoxVEx</div>
  </div>

  <!-- Summary card -->
  <div style="background:#fff;padding:24px 28px;border-left:1px solid #e5e7eb;border-right:1px solid #e5e7eb">
    <table style="width:100%;border-collapse:collapse">
      {summary_html}
    </table>
  </div>

  <!-- Log terminal -->
  <div style="background:#0f172a;border-radius:0 0 8px 8px;padding:20px 24px">
    <div style="font-size:11px;font-weight:700;color:#64748b;letter-spacing:.08em;text-transform:uppercase;margin-bottom:12px">
      Job Log
    </div>
    <div style="font-family:'Courier New',Courier,monospace;font-size:11.5px;line-height:1.65">
      {log_rows_html}
    </div>
  </div>

  <!-- Footer -->
  <div style="text-align:center;font-size:11px;color:#9ca3af;margin-top:14px">
    ProxmoxVEx NetApp ONTAP Plugin
  </div>

</div>
</body>
</html>"""

    # ── Plain-text fallback ───────────────────────────────────────────────────
    plain_lines = [
        subject,
        "=" * len(subject),
        "",
        f"Schedule  : {schedule_name}",
        f"Snapshot  : {snap_name}",
    ]
    if datastore:
        plain_lines.append(f"Datastore : {datastore}")
    plain_lines.append(f"Status    : {status_label}")
    if vm_list:
        vm_labels = [
            f"{(v.get('vm_type') or 'qemu').upper()} {v.get('vmid', '?')}"
            + (f" ({v['name']})" if v.get("name") else "")
            for v in vm_list
        ]
        plain_lines.append(f"VMs      : {', '.join(vm_labels)}")
    plain_lines.append("")
    if entries:
        plain_lines.append("--- Log ---")
        for ts, sev, msg in entries:
            plain_lines.append(f"{ts}  {_sev_tag[sev]}  {msg}")

    return html, "\n".join(plain_lines)


def send_job_notification(
    schedule_name,
    job_status,
    snap_name,
    recipients_csv,
    notify_on,
    log_lines=None,
    vm_list=None,
    datastore=None,
    snapmirror_info=None,
):
    """Send a snapshot job result notification email.

    Called from the snapshot engine after a scheduled job finishes.
    Recipients is a comma-separated string.  notify_on is 'all', 'failed', or 'success'.

    snapmirror_info: optional dict with keys exists, dest_cluster, dest_svm, dest_volume,
                     state, healthy, lag_time, last_transfer_time  (from the DB relationship
                     row for this volume).  Shown as an extra summary row in the email.
    """
    if not recipients_csv or not recipients_csv.strip():
        return
    if notify_on == "failed" and job_status != "failed":
        return
    if notify_on == "success" and job_status != "done":
        return

    try:
        db = get_db()
        _ensure_smtp_row(db)
        row = db.query_one("SELECT * FROM netapp_smtp_config WHERE id='default'")
        d = dict(row)
        if not d.get("enabled"):
            return
        host = d.get("host", "").strip()
        port = int(d.get("port") or 587)
        username = d.get("username", "").strip()
        password = db._decrypt(d.get("password_encrypted", ""))
        encryption = d.get("encryption", "starttls")
        from_addr = d.get("from_address", "") or username
        if not host:
            return

        status_str = "Success" if job_status == "done" else job_status.capitalize()
        subject = f"[ProxmoxVEx] Snapshot {status_str}: {schedule_name} — {snap_name}"

        # Build SnapMirror extra row for the summary card
        extra_rows = []
        if snapmirror_info and snapmirror_info.get("exists"):
            sm = snapmirror_info
            dest = sm.get("dest_cluster") or sm.get("dest_svm") or "?"
            state = sm.get("state") or "?"
            lag_str = _format_lag(sm.get("lag_time") or "")
            last_t = (sm.get("last_transfer_time") or "")[:16].replace("T", " ")
            if not sm.get("healthy") or state in ("broken_off", "broken-off"):
                color, icon = "#dc2626", "✗"
            elif state == "snapmirrored":
                color, icon = "#16a34a", "⟳"
            else:
                color, icon = "#d97706", "⚠"
            sm_val = (
                f'<span style="color:{color};font-weight:700">{icon} {dest}</span>'
                f' <span style="color:#6b7280;font-size:12px">({state}, lag: {lag_str}'
                f"{', last: ' + last_t if last_t else ''})</span>"
            )
            extra_rows.append(("SnapMirror®", sm_val))
        elif snapmirror_info and not snapmirror_info.get("exists"):
            extra_rows.append(("SnapMirror®", '<span style="color:#6b7280">– not configured</span>'))

        html_body, plain_body = _build_notification_email(
            subject,
            schedule_name,
            snap_name,
            job_status,
            log_lines,
            extra_rows=extra_rows if extra_rows else None,
            vm_list=vm_list,
            datastore=datastore,
        )

        recipients = [r.strip() for r in recipients_csv.split(",") if r.strip()]
        msg = email.mime.multipart.MIMEMultipart("alternative")
        msg["From"] = from_addr
        msg["To"] = ", ".join(recipients)
        msg["Subject"] = subject
        msg.attach(email.mime.text.MIMEText(plain_body, "plain", "utf-8"))
        msg.attach(email.mime.text.MIMEText(html_body, "html", "utf-8"))

        _send_smtp(host, port, username, password, encryption, from_addr, recipients, msg.as_string())
        log.info(f"[netapp_storage] Notification sent for schedule '{schedule_name}' ({job_status})")
    except Exception as exc:
        log.warning(f"[netapp_storage] Notification send failed: {exc}")


def _send_smtp(host, port, username, password, encryption, from_addr, recipients, raw_message):
    ctx = ssl.create_default_context()
    if encryption == "ssl":
        with smtplib.SMTP_SSL(host, port, context=ctx, timeout=15) as s:
            if username and password:
                s.login(username, password)
            s.sendmail(from_addr, recipients, raw_message)
    elif encryption == "starttls":
        with smtplib.SMTP(host, port, timeout=15) as s:
            s.ehlo()
            s.starttls(context=ctx)
            s.ehlo()
            if username and password:
                s.login(username, password)
            s.sendmail(from_addr, recipients, raw_message)
    else:
        with smtplib.SMTP(host, port, timeout=15) as s:
            s.ehlo()
            if username and password:
                s.login(username, password)
            s.sendmail(from_addr, recipients, raw_message)


def _notify_test():
    """Send a test notification to the supplied recipients."""
    err = _require_admin()
    if err:
        return err
    data = request.get_json() or {}
    recipients_csv = data.get("recipients", "").strip()
    if not recipients_csv:
        return jsonify({"success": False, "error": "No recipients provided"})

    db = get_db()
    _ensure_smtp_row(db)
    row = db.query_one("SELECT * FROM netapp_smtp_config WHERE id='default'")
    d = dict(row)
    host = d.get("host", "").strip()
    port = int(d.get("port") or 587)
    username = d.get("username", "").strip()
    password = db._decrypt(d.get("password_encrypted", ""))
    encryption = d.get("encryption", "starttls")
    from_addr = d.get("from_address", "").strip() or username

    if not host:
        return jsonify({"success": False, "error": "SMTP host not configured"})

    recipients = [r.strip() for r in recipients_csv.split(",") if r.strip()]
    now_str = datetime.now(UTC).isoformat()

    subject = "[ProxmoxVEx] Test notification — NetApp ONTAP plugin"
    fake_log = [
        {"ts": now_str, "msg": "SMTP connection test initiated"},
        {"ts": now_str, "msg": "If you received this email, notifications are configured correctly."},
    ]
    fake_vms = [
        {"vmid": 100, "name": "web-prod-01", "vm_type": "qemu"},
        {"vmid": 101, "name": "db-prod-01", "vm_type": "qemu"},
        {"vmid": 200, "name": "alpine-proxy", "vm_type": "lxc"},
    ]
    html_body, plain_body = _build_notification_email(
        subject,
        "— test —",
        "— test —",
        "done",
        fake_log,
        extra_rows=[("Sent", now_str)],
        vm_list=fake_vms,
        datastore="nfs-prod-01",
    )
    msg = email.mime.multipart.MIMEMultipart("alternative")
    msg["From"] = from_addr
    msg["To"] = ", ".join(recipients)
    msg["Subject"] = subject
    msg.attach(email.mime.text.MIMEText(plain_body, "plain", "utf-8"))
    msg.attach(email.mime.text.MIMEText(html_body, "html", "utf-8"))

    try:
        _send_smtp(host, port, username, password, encryption, from_addr, recipients, msg.as_string())
        log.info(f"[netapp_storage] Test notification sent to {recipients_csv}")
        return jsonify({"success": True})
    except Exception as exc:
        log.warning(f"[netapp_storage] Test notification failed: {exc}")
        return jsonify({"success": False, "error": str(exc)})


# Tables exported in dependency order (parents before children so import doesn't
# hit FK constraints on a fresh DB).
_EXPORT_TABLES = [
    "netapp_endpoints",
    "netapp_pve_hosts",
    "netapp_smtp_config",
    "netapp_volume_mapping",
    "netapp_provisioned_datastores",
    "netapp_snapshot_schedules",
    "netapp_snapmirror_relationships",
    "netapp_dr_sites",
    "netapp_dr_plans",
    "netapp_dr_plan_entries",
    "netapp_dr_vm_groups",
    "netapp_dr_vm_assignments",
]


def build_export_payload():
    """Build and return the export payload dict (usable by sync and download)."""
    db = get_db()
    payload = {
        "version": "1",
        "plugin": "netapp_storage",
        "exported_at": datetime.now(UTC).isoformat(),
        "tables": {},
    }
    for table in _EXPORT_TABLES:
        query = f"SELECT * FROM {table}"  # nosec: B608 - table name is from a hardcoded allowlist
        rows = db.query(query)
        payload["tables"][table] = [dict(r) for r in rows]
    return payload


def _db_export():
    err = _require_admin()
    if err:
        return err
    payload = build_export_payload()
    ts = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    filename = f"netapp_storage_backup_{ts}.json"
    return Response(
        json.dumps(payload, indent=2, ensure_ascii=False),
        mimetype="application/json",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )


def apply_import_payload(payload):
    """Apply an export payload dict to the local DB. Returns stats dict."""
    if payload.get("plugin") != "netapp_storage":
        raise ValueError("Backup file is not from the netapp_storage plugin")
    if str(payload.get("version")) != "1":
        raise ValueError(f"Unsupported backup version: {payload.get('version')}")
    tables = payload.get("tables", {})
    db = get_db()
    stats = {}
    for table in _EXPORT_TABLES:
        rows = tables.get(table, [])
        if not rows:
            stats[table] = 0
            continue
        inserted = 0
        for row in rows:
            cols = ", ".join(row.keys())
            placeholders = ", ".join(["?" for _ in row])
            sql = f"INSERT OR REPLACE INTO {table} ({cols}) VALUES ({placeholders})"
            try:
                db.execute(sql, list(row.values()))
                inserted += 1
            except Exception as exc:
                log.warning(f"[netapp_storage] import: skipped row in {table}: {exc}")
        stats[table] = inserted
    total = sum(stats.values())
    log.info(f"[netapp_storage] DB import: {total} rows restored — {stats}")
    return {"success": True, "rows_imported": total, "per_table": stats}


def _db_import():
    err = _require_admin()
    if err:
        return err

    # Accept both JSON body and multipart file upload
    if request.content_type and "multipart" in request.content_type:
        f = request.files.get("file")
        if not f:
            return jsonify({"error": "No file uploaded"}), 400
        try:
            payload = json.load(f.stream)  # FileStorage wraps the real stream
        except Exception as exc:
            log.warning("Invalid import JSON: %s", exc)
            return jsonify({"error": "Invalid JSON"}), 400
    else:
        try:
            payload = request.get_json(force=True) or {}
        except Exception as exc:
            log.warning("Invalid import JSON: %s", exc)
            return jsonify({"error": "Invalid JSON"}), 400

    try:
        result = apply_import_payload(payload)
        return jsonify(result)
    except ValueError as exc:
        log.warning("Import apply failed: %s", exc)
        return jsonify({"error": "Import failed"}), 400




def register_routes():
    register_native_route(PLUGIN_ID, "settings/smtp", _smtp_get)
    register_native_route(PLUGIN_ID, "settings/smtp/save", _smtp_save)
    register_native_route(PLUGIN_ID, "settings/smtp/test", _smtp_test)
    register_native_route(PLUGIN_ID, "settings/notify-test", _notify_test)
    register_native_route(PLUGIN_ID, "settings/export", _db_export)
    register_native_route(PLUGIN_ID, "settings/import", _db_import)
