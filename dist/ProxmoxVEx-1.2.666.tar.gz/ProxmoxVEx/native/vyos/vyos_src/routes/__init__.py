# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/native/vyos/vyos_src/routes/__init__.py
# Project:     ProxmoxVEx
# Version:     1.2.662
# Build:       2026.10.21
# Description: Read-only route payload builders for VyOS.
# Usage:       import ProxmoxVEx.native.vyos.vyos_src.routes
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-10-21
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Read-only route payload builders for VyOS."""

from __future__ import annotations

from .overview import (  # noqa: F401
    build_interfaces_payload,
    build_overview_payload,
    build_routes_payload,
)
