# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/native/opnsense/opnsense_src/routes/dhcp.py
# Project:     ProxmoxVEx
# Version:     1.2.662
# Build:       2026.10.21
# Description: DHCPv4 reservation route — list / create / delete.
# Usage:       import
#              ProxmoxVEx.native.opnsense.opnsense_src.routes.dhcp
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-10-21
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""DHCPv4 reservation route — list / create / delete.

Mounted on `/api/opnsense/dhcp`. Refuses writes when plugin
config has read_only=true. Also exposes a subnet-list helper so the UI can
populate the subnet dropdown without re-implementing the search call.
"""

from __future__ import annotations

import logging
import os
from typing import Any

from opnsense_src.client import (
    OPNsenseAuthError,
    OPNsenseClient,
    OPNsenseError,
    OPNsenseHost,
    OPNsenseTimeoutError,
)
from opnsense_src.writers import AuditLog, DhcpReservationInput, DhcpReservationWriter, HAVerifier

log = logging.getLogger(__name__)


def _audit_log_path(plugin_dir: str) -> str:
    state = os.path.join(plugin_dir, "state")
    os.makedirs(state, exist_ok=True)
    return os.path.join(state, "audit.jsonl")


def build_dhcp_list_payload(host: OPNsenseHost) -> tuple[int, dict[str, Any]]:
    client = OPNsenseClient(host)
    try:
        reservations = client.get("/api/kea/dhcpv4/searchReservation")
        subnets = client.get("/api/kea/dhcpv4/searchSubnet")
        r_rows = reservations.get("rows", []) if isinstance(reservations, dict) else []
        s_rows = subnets.get("rows", []) if isinstance(subnets, dict) else []
        # `mappings`/`scopes` are the normalized keys the shared
        # firewall-manager UI renders; `reservations`/`subnets` stay for
        # legacy callers.
        from opnsense_src._fwkit import ensure_fwkit_importable

        ensure_fwkit_importable()
        from ProxmoxVEx.native.fwkit.normalize import (
            normalize_dhcp_mapping,
            normalize_dhcp_scope,
        )

        return 200, {
            "ok": True,
            "data": {
                "reservations": r_rows,
                "subnets": s_rows,
                "mappings": [
                    normalize_dhcp_mapping(r, "opnsense", index=i)
                    for i, r in enumerate(r_rows)
                ],
                "scopes": [
                    normalize_dhcp_scope(s, "opnsense", i)
                    for i, s in enumerate(s_rows)
                ],
                "total": len(r_rows),
            },
        }
    except OPNsenseAuthError as e:
        return 401, {"ok": False, "error": "auth", "detail": str(e)}
    except OPNsenseTimeoutError as e:
        return 504, {"ok": False, "error": "timeout", "detail": str(e)}
    except OPNsenseError as e:
        log.exception("dhcp list failed")
        return 502, {"ok": False, "error": "upstream", "detail": str(e)}


def build_dhcp_action_payload(
    host: OPNsenseHost,
    plugin_dir: str,
    body: dict[str, Any],
    actor: str = "plugin",
    read_only: bool = False,
    peer_host: OPNsenseHost | None = None,
) -> tuple[int, dict[str, Any]]:
    if read_only:
        return 403, {"ok": False, "error": "read_only", "detail": "plugin config has read_only=true"}
    action = str(body.get("action", "")).lower()
    # `mapping_set`/`mapping_delete` are the shared-manager verbs (pfSense
    # parity); they translate `mapping{mac,ip}` onto the Kea reservation
    # fields (`hw_address`, `ip_address`).
    if action in ("mapping_set", "mapping_delete"):
        mapping = body.get("mapping") or {}
        action = "create" if action == "mapping_set" else "delete"
        body = dict(body)
        body["action"] = action
        body["reservation"] = {
            "subnet": str(mapping.get("subnet", "")),
            "ip_address": str(mapping.get("ip") or mapping.get("ip_address") or ""),
            "hw_address": str(mapping.get("mac") or mapping.get("hw_address") or ""),
            "hostname": str(mapping.get("hostname", "")),
            "description": str(mapping.get("description", "")),
        }
        if mapping.get("mac") and not body.get("uuid"):
            body["uuid"] = str(mapping.get("mac"))
    if action not in ("create", "delete"):
        return 400, {"ok": False, "error": "bad_request", "detail": "action must be create|delete|mapping_set|mapping_delete"}

    client = OPNsenseClient(host)
    audit = AuditLog(_audit_log_path(plugin_dir))
    # HA verify: with a peer configured, writes sync to it and the result
    # carries a SyncResult; single-node short-circuits to verified.
    peer = OPNsenseClient(peer_host) if peer_host is not None else None
    writer = DhcpReservationWriter(client, audit, ha=HAVerifier(client, peer), actor=actor)

    try:
        if action == "create":
            r = body.get("reservation") or {}
            try:
                payload = DhcpReservationInput(
                    subnet=str(r.get("subnet", "")),
                    ip_address=str(r.get("ip_address", "")),
                    hw_address=str(r.get("hw_address", "")),
                    hostname=str(r.get("hostname", "")),
                    description=str(r.get("description", "")),
                )
            except (TypeError, ValueError) as e:
                return 400, {"ok": False, "error": "bad_request", "detail": str(e)}
            try:
                result = writer.create(payload)
            except ValueError as e:
                return 400, {"ok": False, "error": "validation", "detail": str(e)}
        else:
            uuid = str(body.get("uuid", ""))
            if not uuid:
                return 400, {"ok": False, "error": "bad_request", "detail": "uuid is required"}
            result = writer.delete(uuid)
    except OPNsenseAuthError as e:
        return 401, {"ok": False, "error": "auth", "detail": str(e)}
    except OPNsenseTimeoutError as e:
        return 504, {"ok": False, "error": "timeout", "detail": str(e)}
    except OPNsenseError as e:
        log.exception("dhcp action %s failed", action)
        return 502, {"ok": False, "error": "upstream", "detail": str(e)}

    if not result.ok:
        return 502, {"ok": False, "error": "upstream", "detail": result.detail or "write failed"}
    return 200, {"ok": True, "data": {"uuid": result.uuid, "action": action}}
