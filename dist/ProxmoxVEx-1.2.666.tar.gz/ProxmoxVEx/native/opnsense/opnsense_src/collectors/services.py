# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/native/opnsense/opnsense_src/collectors/services.py
# Project:     ProxmoxVEx
# Version:     1.2.662
# Build:       2026.10.21
# Description: Services collector — running/locked state per OPNsense
#              service.
# Usage:       import ProxmoxVEx.native.opnsense.opnsense_src.collecto
#              rs.services
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-10-21
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Services collector — running/locked state per OPNsense service."""

from __future__ import annotations

from typing import TypedDict

from opnsense_src.client import OPNsenseClient


class ServiceState(TypedDict):
    id: str
    name: str
    description: str
    running: bool
    locked: bool


class ServiceSummary(TypedDict):
    total: int
    running: int
    stopped: int
    items: list[ServiceState]


def _bool_from_int(value: object) -> bool:
    try:
        return int(str(value).strip()) == 1
    except (ValueError, AttributeError):
        return False


def collect_services(client: OPNsenseClient) -> ServiceSummary:
    payload = client.get("/api/core/service/search")
    rows = payload.get("rows", []) if isinstance(payload, dict) else []

    items: list[ServiceState] = []
    running = 0
    for r in rows:
        is_running = _bool_from_int(r.get("running"))
        if is_running:
            running += 1
        items.append(
            ServiceState(
                id=str(r.get("id", "")),
                name=str(r.get("name", "")),
                description=str(r.get("description", "")),
                running=is_running,
                locked=_bool_from_int(r.get("locked")),
            )
        )
    return ServiceSummary(
        total=len(items),
        running=running,
        stopped=len(items) - running,
        items=items,
    )
