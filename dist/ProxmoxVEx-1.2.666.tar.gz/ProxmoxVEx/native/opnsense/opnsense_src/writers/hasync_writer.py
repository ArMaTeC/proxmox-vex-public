# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/native/opnsense/opnsense_src/writers/hasync_writer.py
# Project:     ProxmoxVEx
# Version:     1.2.662
# Build:       2026.10.21
# Description: Compat shim — `HAVerifier`/`SyncResult` moved to
#              `ProxmoxVEx.native.fwkit.hasync` so the pfSense plugin
#              shares them.
# Usage:       import ProxmoxVEx.native.opnsense.opnsense_src.writers.
#              hasync_writer
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-10-21
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Compat shim — `HAVerifier`/`SyncResult` moved to
`ProxmoxVEx.native.fwkit.hasync` so the pfSense plugin shares them.

The fwkit `HAVerifier` defaults to the OPNsense sync trigger and revision
getter, so `HAVerifier(local, peer)` behaves identically to the old class.
"""

from opnsense_src._fwkit import ensure_fwkit_importable

ensure_fwkit_importable()

from ProxmoxVEx.native.fwkit.hasync import (  # noqa: E402,F401
    HAVerifier,
    SyncResult,
    opnsense_revision_getter,
    opnsense_sync_trigger,
)
