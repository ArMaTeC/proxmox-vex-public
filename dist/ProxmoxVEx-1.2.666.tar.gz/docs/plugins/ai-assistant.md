<!-- GENERATED:START -->
# AI Assistant

`ai-assistant` v1.0.5

In-app read-only assistant backed by your own provider (Ollama default, OpenAI-compatible endpoints supported). Answers infra questions using RBAC-scoped live context (inventory, firing alerts, recent tasks), replies in your UI language, streams responses with abort, and never executes actions or persists prompts by default. Provider keys are encrypted at rest; per-user rate limits and a global concurrency cap bound provider load.

**Author:** ProxmoxVEx Team | **Category:** Tools | **License tier:** `corporate` | **Requires ProxmoxVEx:** ≥ 1.2.23 | **Trusted:** True

## Permissions
- `clusters:read`
- `nodes:read`
- `vms:read`

## Configuration
_No config schema declared._

## Events subscribed
_None._
<!-- GENERATED:END -->
