# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/utils/mfa_gate.py
# Project:     ProxmoxVEx
# Version:     1.2.662
# Build:       2026.10.21
# Description: Force-MFA enrollment confinement gate
# Usage:       from ProxmoxVEx.utils.mfa_gate import mfa_enrollment_block
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-10-21
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Force-MFA confinement gate (spec 038/088).

Moved out of api/__init__.py (ID-0006) so the gate lives with the other
auth utilities and its dependencies resolve at module top — the only
lazy import left is `api.helpers.load_server_settings`, which sits
inside the api package and would create a true import cycle if hoisted
(api/__init__ imports this module before helpers is reachable).
"""

import logging

from flask import jsonify, request

# Module references (not name bindings) so tests that patch
# authmod.get_user_record / authmod.TOTP_AVAILABLE / dbmod.get_db still
# reach this gate — the same patch points the old api/__init__ version used.
from ProxmoxVEx.core import db as dbmod
from ProxmoxVEx.models.permissions import ROLE_ADMIN
from ProxmoxVEx.utils import auth as authmod

# Spec 038 (US1): endpoints an unenrolled user may still reach while the
# force-MFA hard block is active — enrollment itself plus session teardown.
MFA_ENROLL_ALLOWLIST = (
    "/api/auth/2fa/",
    "/api/webauthn/register/",
    "/api/auth/stepup/",
)


def mfa_enrollment_block(session):
    """Return a 403 confinement response when the session's user must enroll MFA.

    Applies to session AND API-token auth alike: an unenrolled account should not
    operate at all while force_2fa is on (a pre-existing token is a bypass
    otherwise). Evaluation failure fails open to the normal decorators — a broken
    settings store already degrades requests downstream via require_auth.
    """
    try:
        # lazy: api.helpers pulls in the api package; hoisting this would
        # cycle api/__init__ -> utils.mfa_gate -> api.helpers.
        from ProxmoxVEx.api.helpers import load_server_settings

        settings = load_server_settings() or {}
        # Spec 088: enforcement is either global (force_2fa) or role-scoped
        # (force_2fa_roles lists role names confined to enrollment).
        force_all = bool(settings.get("force_2fa"))
        force_roles = settings.get("force_2fa_roles") or []
        if not authmod.TOTP_AVAILABLE or (not force_all and not force_roles):
            return None
        if request.path.startswith(MFA_ENROLL_ALLOWLIST):
            return None

        username = session.get("user", "")
        # indexed fetch with the same legacy fallback the hand-rolled
        # get_db()/load_users() chain used to do inline
        user = authmod.get_user_record(username)
        if not user:
            return None

        # OIDC/Entra users satisfy MFA at their IdP — no local factor exists.
        if user.get("auth_source", "local") in ("oidc", "entra"):
            return None

        # Spec 088 edge: API tokens used by automation are exempt from
        # ROLE-SCOPED enforcement (they're scoped per #085). Global force_2fa
        # keeps confining them — an unenrolled account's token is a bypass.
        if session.get("api_token") and not force_all:
            return None
        is_admin = user.get("role") == ROLE_ADMIN
        # The exclude flag only relaxes the GLOBAL switch; an explicit
        # force_2fa_roles listing is deliberate and always wins.
        enforced = (force_all and not (is_admin and settings.get("force_2fa_exclude_admins"))) or (
            user.get("role") in force_roles
        )
        if not enforced:
            return None
        if user.get("totp_enabled") and user.get("totp_secret"):
            return None
        try:
            row = dbmod.get_db().query_one(
                "SELECT COUNT(*) AS n FROM webauthn_credentials WHERE username = ?",
                (username,),
            )
            if row and row["n"] > 0:
                return None
        except Exception as e:
            logging.debug(f"mfa-block: webauthn credential count failed for {username}: {e}")

        logging.info(f"mfa-block: confining unenrolled user {username} to enrollment (path={request.path})")
        return jsonify({
            "error": "MFA enrollment required",
            "code": "REQUIRES_2FA_SETUP",
            "requires_2fa_setup": True,
        }), 403
    except Exception as e:
        logging.error(f"mfa-block: evaluation failed ({e}); deferring to route auth")
        return None
