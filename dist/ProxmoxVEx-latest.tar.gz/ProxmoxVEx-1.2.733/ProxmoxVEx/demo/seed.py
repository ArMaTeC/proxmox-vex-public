# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/demo/seed.py
# Project:     ProxmoxVEx
# Version:     1.2.727
# Build:       2026.11.23
# Description: Seed synthetic demo fixtures when demo mode is enabled.
# Usage:       import ProxmoxVEx.demo.seed
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-11-23
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Seed synthetic demo fixtures when demo mode is enabled.

This module creates the demo user and a synthetic cluster record.  It is
idempotent so it can safely be run on every startup.
"""

import contextlib
import json
import logging
import os
from datetime import UTC, datetime, timedelta

from ProxmoxVEx.core.db import get_db
from ProxmoxVEx.demo import (
    DEMO_CLUSTER_HOST,
    DEMO_CLUSTER_ID,
    DEMO_PASSWORD,
    DEMO_ROLE,
    DEMO_USERNAME,
    is_demo_mode,
)
from ProxmoxVEx.utils.auth import hash_password


def _ensure_demo_user():
    """Create or reset the low-privilege demo user."""
    db = get_db()
    users = db.get_all_users()
    if DEMO_USERNAME in users:
        # Keep the seeded user's role in sync with DEMO_ROLE (upgrades from
        # viewer → admin for full read-only coverage of the demo UI).
        existing = users.get(DEMO_USERNAME) or {}
        if existing.get("role") != DEMO_ROLE:
            db.save_user(DEMO_USERNAME, dict(existing, role=DEMO_ROLE))
        return

    salt, password_hash = hash_password(DEMO_PASSWORD)
    demo_user = {
        "password_salt": salt,
        "password_hash": password_hash,
        "role": DEMO_ROLE,
        "permissions": [],
        "tenant": "",
        "auth_source": "demo",
        "is_demo": True,
        "display_name": "Demo User",
        "email": "",
        "enabled": True,
        "theme": "",
        "language": "",
        "ui_layout": "modern",
        "created_at": datetime.now(UTC).isoformat(),
    }
    db.save_user(DEMO_USERNAME, demo_user)
    logging.info(f"[DEMO_SEED] Created demo user '{DEMO_USERNAME}'")


# Synthetic demo clusters — one record per host the cluster mock serves.
# ``host`` selects the dataset in demo/cluster_mock.py; ``group_id`` and the
# latitude/longitude/location_label triple drive the sidebar grouping and the
# world map so the demo shows off multi-region organisation.
DEMO_GROUPS = [
    ("grp-production", "Production", "Primary production clusters", "#E86F2D", 0),
    ("grp-edge", "Edge", "Edge and lab sites", "#3B82F6", 1),
    ("grp-dr", "DR Sites", "Disaster recovery and failover sites", "#8B5CF6", 2),
]

DEMO_CLUSTERS = [
    {
        "id": DEMO_CLUSTER_ID,
        "name": "Production EU",
        "host": DEMO_CLUSTER_HOST,
        "group_id": "grp-production",
        "sort_order": 0,
        "latitude": 50.1109,
        "longitude": 8.6821,
        "location_label": "Frankfurt, DE",
    },
    {
        "id": "demo-us",
        "name": "Production US",
        "host": "demo-us",
        "group_id": "grp-production",
        "sort_order": 1,
        "latitude": 39.0438,
        "longitude": -77.4874,
        "location_label": "Ashburn, US",
    },
    {
        "id": "demo-dc",
        "name": "DC West",
        "host": "demo-dc",
        "group_id": "grp-production",
        "sort_order": 2,
        "latitude": 52.3702,
        "longitude": 4.8952,
        "location_label": "Amsterdam, NL",
    },
    {
        "id": "demo-uk",
        "name": "Production UK",
        "host": "demo-uk",
        "group_id": "grp-production",
        "sort_order": 3,
        "latitude": 51.5074,
        "longitude": -0.1278,
        "location_label": "London, UK",
    },
    {
        "id": "demo-jp",
        "name": "Production Tokyo",
        "host": "demo-jp",
        "group_id": "grp-production",
        "sort_order": 4,
        "latitude": 35.6762,
        "longitude": 139.6503,
        "location_label": "Tokyo, JP",
    },
    {
        "id": "demo-sg",
        "name": "Edge Lab Singapore",
        "host": "demo-sg",
        "group_id": "grp-edge",
        "sort_order": 0,
        "latitude": 1.3521,
        "longitude": 103.8198,
        "location_label": "Singapore, SG",
    },
    {
        "id": "demo-syd",
        "name": "Edge Lab Sydney",
        "host": "demo-syd",
        "group_id": "grp-edge",
        "sort_order": 1,
        "latitude": -33.8688,
        "longitude": 151.2093,
        "location_label": "Sydney, AU",
    },
    {
        "id": "demo-ca",
        "name": "DR Site Toronto",
        "host": "demo-ca",
        "group_id": "grp-dr",
        "sort_order": 0,
        "latitude": 43.6532,
        "longitude": -79.3832,
        "location_label": "Toronto, CA",
    },
]

_DEMO_CLUSTER_IDS = [c["id"] for c in DEMO_CLUSTERS]


def _ensure_demo_cluster_groups():
    """Create the cluster groups the demo clusters are filed under."""
    db = get_db()
    now = datetime.now(UTC).isoformat()
    for gid, name, desc, color, order in DEMO_GROUPS:
        db.execute(
            """
            INSERT OR IGNORE INTO cluster_groups
            (id, name, description, color, tenant_id, sort_order, created_at, updated_at)
            VALUES (?, ?, ?, ?, NULL, ?, ?, ?)
            """,
            (gid, name, desc, color, order, now, now),
        )
    logging.info("[DEMO_SEED] Ensured demo cluster groups")


def _ensure_demo_cluster():
    """Create the synthetic demo cluster records.

    Each cluster uses a ``demo*`` host which the manager mock intercepts and
    serves from a per-host fixture dataset — no real hypervisor connection is
    attempted.  Metadata (group, sort order, map location) is refreshed on
    every seed so reset/upgrade cycles converge to the same layout.
    """
    db = get_db()

    now = datetime.now(UTC).isoformat()
    for spec in DEMO_CLUSTERS:
        demo_cluster = {
            "name": spec["name"],
            "display_name": spec["name"],
            "host": spec["host"],
            "user": "demo",
            "pass": "",
            "ssl_verification": False,
            "migration_threshold": 30,
            "check_interval": 300,
            "auto_migrate": False,
            "balance_containers": False,
            "balance_local_disks": False,
            "dry_run": True,
            "enabled": True,
            "ha_enabled": False,
            "fallback_hosts": [],
            "ssh_user": "",
            "ssh_key": "",
            "ssh_port": 22,
            "api_port": 8006,
            "ha_settings": {},
            "group_id": spec["group_id"],
            "sort_order": spec["sort_order"],
            "latitude": spec["latitude"],
            "longitude": spec["longitude"],
            "location_label": spec["location_label"],
            "created_at": now,
            "updated_at": now,
        }
        db.save_cluster(spec["id"], demo_cluster)
        logging.info(f"[DEMO_SEED] Ensured demo cluster '{spec['id']}'")


def _ensure_demo_migration_history():
    """Seed a few migration rows per cluster so the Migrations view has data."""
    db = get_db()
    now = datetime.now(UTC)
    demo_migrations = [
        ("demo", 105, "k8s-w-01", "pve-demo-01", "pve-demo-02", "manual by demo@pve", "completed", 19.4, (now.timestamp() - 259200)),
        ("demo", 106, "k8s-w-02", "pve-demo-02", "pve-demo-03", "manual by demo@pve", "completed", 23.1, (now.timestamp() - 172800)),
        ("demo", 100, "web-01", "pve-demo-02", "pve-demo-01", "rebalance by ProxmoxVEx", "completed", 14.8, (now.timestamp() - 345600)),
        ("demo-us", 1105, "k8s-us-w-01", "pve-us-01", "pve-us-02", "manual by demo@pve", "completed", 21.7, (now.timestamp() - 200000)),
        ("demo-us", 1101, "orders-db-01", "pve-us-02", "pve-us-01", "rebalance by ProxmoxVEx", "completed", 38.2, (now.timestamp() - 300000)),
        ("demo-sg", 2105, "k3s-w-01", "pve-sg-02", "pve-sg-01", "manual by demo@pve", "completed", 12.6, (now.timestamp() - 150000)),
        ("demo-dc", 3001, "dc-web-01", "pve-dc-02", "pve-dc-01", "manual by demo@pve", "completed", 17.9, (now.timestamp() - 220000)),
        ("demo-dc", 3006, "archive-db-01", "pve-dc-07", "pve-dc-06", "rebalance by ProxmoxVEx", "completed", 41.3, (now.timestamp() - 310000)),
        ("demo-dc", 3008, "k8s-dc-w-01", "pve-dc-04", "pve-dc-05", "manual by demo@pve", "completed", 15.2, (now.timestamp() - 180000)),
        ("demo-uk", 4105, "k8s-uk-w-01", "pve-uk-02", "pve-uk-01", "manual by demo@pve", "completed", 18.9, (now.timestamp() - 190000)),
        ("demo-uk", 4101, "ledger-db-01", "pve-uk-03", "pve-uk-02", "rebalance by ProxmoxVEx", "completed", 33.4, (now.timestamp() - 280000)),
        ("demo-jp", 5105, "k8s-jp-w-01", "pve-jp-01", "pve-jp-02", "manual by demo@pve", "completed", 16.7, (now.timestamp() - 160000)),
        ("demo-jp", 5100, "storefront-jp-01", "pve-jp-02", "pve-jp-03", "rebalance by ProxmoxVEx", "completed", 24.8, (now.timestamp() - 240000)),
        ("demo-syd", 6105, "k3s-syd-w-01", "pve-syd-02", "pve-syd-01", "manual by demo@pve", "completed", 11.3, (now.timestamp() - 140000)),
        ("demo-syd", 6101, "telemetry-db-01", "pve-syd-01", "pve-syd-03", "manual by demo@pve", "completed", 19.8, (now.timestamp() - 260000)),
        ("demo-ca", 7105, "k3s-dr-w-01", "pve-ca-01", "pve-ca-02", "manual by demo@pve", "completed", 14.2, (now.timestamp() - 130000)),
        ("demo-ca", 7101, "vault-db-01", "pve-ca-03", "pve-ca-01", "rebalance by ProxmoxVEx", "completed", 29.6, (now.timestamp() - 320000)),
    ]
    cursor = db.conn.cursor()
    for cluster_id, vmid, vm_name, src, dst, reason, status, duration, ts in demo_migrations:
        cursor.execute(
            "SELECT COUNT(*) AS c FROM migration_history WHERE cluster_id = ? AND vmid = ?",
            (cluster_id, vmid),
        )
        row = cursor.fetchone()
        if row and (row["c"] if isinstance(row, dict) else row[0]):
            continue
        cursor.execute(
            """
            INSERT INTO migration_history
            (cluster_id, vmid, vm_name, source_node, target_node,
             reason, status, duration_seconds, timestamp)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (cluster_id, vmid, vm_name, src, dst, reason, status, duration, datetime.fromtimestamp(ts, UTC).isoformat()),
        )
    db.conn.commit()
    logging.info("[DEMO_SEED] Seeded demo migration history")


def _ensure_demo_alerts():
    """Seed alert rules per cluster so the Alerts view shows configured rules."""
    db = get_db()
    existing = db.get_all_alerts()
    alert_types = [
        ("node-cpu", "node_cpu", 85, 900),
        ("node-mem", "node_memory", 90, 900),
        ("storage", "storage", 80, 3600),
        ("vm-down", "vm_down", 0, 300),
    ]
    for cluster_id in _DEMO_CLUSTER_IDS:
        if any(a.get("cluster_id") == cluster_id for a in existing.values()):
            continue
        for suffix, atype, threshold, cooldown in alert_types:
            db.save_alert(
                f"{cluster_id}-{suffix}",
                {
                    "cluster_id": cluster_id,
                    "node": None,
                    "vmid": None,
                    "type": atype,
                    "threshold": threshold,
                    "enabled": True,
                    "notify_methods": ["email"],
                    "cooldown": cooldown,
                },
            )
    logging.info("[DEMO_SEED] Seeded demo alert rules")


def _ensure_demo_pbs_server():
    """Seed a synthetic PBS server so the backup-server surfaces show data.

    host='demo' port 8007 is intercepted by the cluster mock, which serves
    the PBS API from the ``pbs`` inventory fixture section — no real PBS
    is ever contacted.  It is linked to every demo cluster so the backup
    surfaces show coverage across regions.
    """
    db = get_db()
    cursor = db.conn.cursor()
    cursor.execute("SELECT COUNT(*) AS c FROM pbs_servers")
    row = cursor.fetchone()
    if row and (row["c"] if isinstance(row, dict) else row[0]):
        return

    now = datetime.now(UTC).isoformat()
    cursor.execute(
        """
        INSERT INTO pbs_servers
        (id, name, host, port, user, pass_encrypted, api_token_id,
         api_token_secret_encrypted, fingerprint, ssl_verify, enabled,
         linked_clusters, notes, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (
            "pbs-demo", "pbs-demo-01", DEMO_CLUSTER_HOST, 8007, "demo@pam",
            "", "demo@pam!demo", "", "", 0, 1,
            json.dumps(_DEMO_CLUSTER_IDS), "Synthetic demo backup server", now, now,
        ),
    )
    db.conn.commit()
    logging.info("[DEMO_SEED] Seeded demo PBS server")


def _ensure_demo_vmware_server():
    """Seed a synthetic vCenter so the VMware surface shows data.

    host='vcenter.demo.lab' is intercepted by the demo request mock and
    answered from the ``vcenter`` section of integrations.json.
    """
    db = get_db()
    cursor = db.conn.cursor()
    cursor.execute("SELECT COUNT(*) AS c FROM vmware_servers")
    row = cursor.fetchone()
    if row and (row["c"] if isinstance(row, dict) else row[0]):
        return

    now = datetime.now(UTC).isoformat()
    cursor.execute(
        """
        INSERT INTO vmware_servers
        (id, name, host, port, username, pass_encrypted, server_type,
         ssl_verify, enabled, linked_clusters, notes, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (
            "vmware-demo", "vcenter-01", "vcenter.demo.lab", 443,
            "demo@vsphere.local", db._encrypt("demo"), "vcenter",
            0, 1, '[]', "Synthetic demo vCenter", now, now,
        ),
    )
    db.conn.commit()
    logging.info("[DEMO_SEED] Seeded demo vCenter server")


def _ensure_demo_netapp_endpoint():
    """Seed a synthetic ONTAP endpoint for the NetApp plugin."""
    db = get_db()
    cursor = db.conn.cursor()
    try:
        cursor.execute("SELECT COUNT(*) AS c FROM netapp_endpoints")
    except Exception:
        return  # plugin tables not created yet
    row = cursor.fetchone()
    if row and (row["c"] if isinstance(row, dict) else row[0]):
        return

    now = datetime.now(UTC).isoformat()
    cursor.execute(
        """
        INSERT INTO netapp_endpoints
        (id, name, host, username, password_encrypted, ssl_verify, skip_nfs, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        ("ntap-demo", "ntap-01", "netapp.demo.lab", "demo", db._encrypt("demo"), 0, 0, now, now),
    )
    db.conn.commit()
    logging.info("[DEMO_SEED] Seeded demo NetApp endpoint")


def _ensure_demo_portainer_rancher_rows():
    """Seed Portainer + Rancher connections for the portainer_rancher module.

    Uses the module's own models so the schema stays module-owned; rows
    point only at mock hostnames routed through _INTEGRATION_HOSTS.
    """
    from ProxmoxVEx.native.portainer_rancher import models

    db = get_db()
    models.ensure_tables(db.conn)
    if not models.list_portainer_connections():
        models.create_portainer_connection({
            "display_name": "portainer-01",
            "base_url": "https://portainer.demo.lab",
            "tls_verify": False,
            "auth_type": "api_token",
            "credential": {"api_token": "demo-token"},
            "proxmox_cluster_id": "demo",
            "connectivity_status": "connected",
            "edition": "CE",
            "version": "2.19.4",
        })
    if not models.list_rancher_connections():
        models.create_rancher_connection({
            "display_name": "rancher-01",
            "server_url": "https://rancher.demo.lab",
            "tls_verify": False,
            "auth_type": "api_token",
            "credential": {"api_token": "demo-token"},
            "proxmox_cluster_id": "demo",
            "connectivity_status": "connected",
            "version": "2.8.x",
        })
    logging.info("[DEMO_SEED] Seeded demo Portainer/Rancher connections")


# Whitelist for fixtures/demo/db_seed.json (spec 143): table → natural key
# column used for check-before-insert (None → INSERT OR IGNORE). Only
# whitelisted tables are seeded — the fixture file is data, never DDL.
_DEMO_SEED_TABLES: dict = {
    "status_incidents": "id",
    "snapshot_policies": "id",
    "scheduled_tasks": "id",
    "backup_verifications": "id",
    "migration_history": None,
}


def _fixture_json(name: str) -> dict:
    """Load a fixtures/demo JSON file (demo-only helper)."""
    import json as _json
    from pathlib import Path

    try:
        from ProxmoxVEx.constants import CONFIG_DIR
        base = Path(CONFIG_DIR).parent / "fixtures" / "demo"
    except Exception:
        base = Path(__file__).resolve().parents[2] / "fixtures" / "demo"
    p = base / name
    if not p.is_file():
        p = Path(__file__).resolve().parents[2] / "fixtures" / "demo" / name
    try:
        return _json.loads(p.read_text())
    except Exception as e:
        logging.warning("[DEMO_SEED] could not load %s: %s", name, e)
        return {}


def _ensure_demo_table_rows() -> None:
    """Apply fixtures/demo/db_seed.json into whitelisted plugin tables.

    Per-table error isolation: a missing/lazy-created table never blocks
    the rest. `age_seconds`/`ends_in_seconds` values are anchored to
    wall-clock like the inventory fixture, so rows always look fresh.
    """
    rows_by_table = _fixture_json("db_seed.json")
    if not rows_by_table:
        return
    db = get_db()
    now = datetime.now(UTC).isoformat()
    now_ts = datetime.now(UTC).timestamp()
    for table, natural_key in _DEMO_SEED_TABLES.items():
        rows = rows_by_table.get(table)
        if not isinstance(rows, list) or not rows:
            continue
        try:
            cursor = db.conn.cursor()
            # Schemas are module-owned and differ per table — introspect
            # actual columns so fixture keys that don't exist are skipped
            # (e.g. updated_at is absent on several tables).
            cursor.execute(f"SELECT * FROM {table} LIMIT 0")
            cols_known = {d[0] for d in (cursor.description or [])}
            if not cols_known:
                continue
            # age_seconds maps to the table's own start timestamp column —
            # schemas differ (created_at vs started_at vs timestamp).
            age_col = next(
                (c for c in ("created_at", "started_at", "timestamp")
                 if c in cols_known), None)
            for row in rows:
                row = dict(row)
                for k in ("age_seconds", "ends_in_seconds",
                          "resolved_age_seconds"):
                    if k in row:
                        base = row.pop(k)
                        if k == "age_seconds":
                            if age_col:
                                row[age_col] = datetime.fromtimestamp(
                                    now_ts - base, UTC).isoformat()
                        elif k == "resolved_age_seconds":
                            row["resolved_at"] = datetime.fromtimestamp(
                                now_ts - base, UTC).isoformat()
                        else:
                            row["ends_at"] = datetime.fromtimestamp(
                                now_ts + base, UTC).isoformat()
                if "created_at" in cols_known:
                    row.setdefault("created_at", now)
                if "updated_at" in cols_known:
                    row.setdefault("updated_at", now)
                row = {k: v for k, v in row.items() if k in cols_known}
                if natural_key and natural_key in row:
                    cursor.execute(
                        f"SELECT 1 FROM {table} WHERE {natural_key} = ? LIMIT 1",
                        (row[natural_key],))
                    if cursor.fetchone():
                        continue
                cols = ", ".join(row)
                marks = ", ".join("?" for _ in row)
                try:
                    # plain INSERT — OR IGNORE isn't portable to Postgres;
                    # the natural-key check above gives idempotency, and a
                    # straggler constraint violation just skips the row.
                    cursor.execute(
                        f"INSERT INTO {table} ({cols}) VALUES ({marks})",
                        tuple(row.values()))
                except Exception:
                    with contextlib.suppress(Exception):
                        db.conn.rollback()
            db.conn.commit()
            logging.info("[DEMO_SEED] Seeded demo rows into %s", table)
        except Exception as e:
            logging.warning("[DEMO_SEED] db_seed %s failed: %s", table, e)
    for table in rows_by_table:
        if table not in _DEMO_SEED_TABLES:
            logging.warning("[DEMO_SEED] db_seed.json: %s not whitelisted", table)


def apply_demo_plugin_configs() -> None:
    """Overlay fixtures/demo/plugin_configs/<id>.json onto plugin configs.

    Demo wins over shipped/volume files so every plugin looks configured;
    overlays are rewritten each boot/reset, keeping the demo consistent.
    """
    import json as _json
    import shutil
    from pathlib import Path

    from ProxmoxVEx.constants import PLUGINS_DIR

    overlay_dir = (
        Path(__file__).resolve().parents[2] / "fixtures" / "demo" / "plugin_configs")
    if not overlay_dir.is_dir():
        return
    for overlay in sorted(overlay_dir.glob("*.json")):
        try:
            cfg = _json.loads(overlay.read_text())
        except Exception as e:
            logging.warning("[DEMO_SEED] bad overlay %s: %s", overlay.name, e)
            continue
        pid = overlay.stem
        target = Path(PLUGINS_DIR) / pid / "config.json"
        try:
            if target.is_symlink():
                target = target.resolve()
            target.parent.mkdir(parents=True, exist_ok=True)
            # preserve a pristine copy once per boot for hygiene checks
            bak = target.with_suffix(".json.predemo")
            if target.is_file() and not bak.exists():
                with contextlib.suppress(OSError):
                    shutil.copy2(target, bak)
            target.write_text(_json.dumps(cfg, indent=2) + "\n")
            logging.info("[DEMO_SEED] Applied demo config overlay for %s", pid)
        except Exception as e:
            logging.warning("[DEMO_SEED] overlay %s failed: %s", pid, e)


def _ensure_demo_rockstor_rows():
    """Seed a Rockstor appliance connection + representative inventory.

    The module reads its appliance list from rockstor_* tables, not a
    config.json hosts list, so a DB row is the demo-config seam.
    """
    from ProxmoxVEx.native.rockstor import models

    db = get_db()
    models.ensure_tables(db.conn)
    if not models.list_connections():
        models.create_connection({
            "display_name": "rockstor-01",
            "endpoint_url": "https://rockstor.demo.lab",
            "tls_verify": False,
            "credential": {"username": "demo", "password": "demo"},
            "auth_type": "password",
            "connectivity_status": "connected",
            "version": "5.0",
            "hostname": "rockstor.demo.lab",
        })
    logging.info("[DEMO_SEED] Seeded demo Rockstor connection")


def _ensure_demo_license_context():
    """Seed a synthetic Corporate license_context for the licence page.

    Spec 145: get_active_tier() already short-circuits to "corporate" in
    demo, but /api/v1/licence/status read active:false with no context
    row — the page looked unlicensed. The seeded key is a fresh `PVXD-*`
    marker per seed (rotates each reset, never a real issued key), or the
    operator-provided PROXMOXVEX_DEMO_LICENSE_KEY when the demo runs beside
    a local licensing service — stored
    encrypted like real keys via save_context, and never serialized —
    licence_status emits tier/expiry fields only. next_check_at is pushed
    far-future as a second layer under the is_demo_mode() freeze in
    LicensingService._revalidate_if_due so a fake key can never reach the
    real licensing service and bounce the context back to community.
    """
    import secrets

    from ProxmoxVEx.models.license_log import (
        add_license_log_entry,
        ensure_license_log_table,
    )
    from ProxmoxVEx.services.licensing import LicensingService

    # Spec 146 T010: when the demo runs beside a local licensing service,
    # PROXMOXVEX_DEMO_LICENSE_KEY carries the `PVXD-*` key that service
    # signed so paid-plugin artifact delivery can run its real flow. With
    # the env unset we keep a fresh random marker per seed (rotates each
    # reset, never a real issued key).
    license_key = (
        os.environ.get("PROXMOXVEX_DEMO_LICENSE_KEY", "").strip()
        or "PVXD-" + secrets.token_hex(16).upper()
    )
    db = get_db()
    ensure_license_log_table(db.conn)
    now = datetime.now(UTC)
    LicensingService().save_context(
        db,
        license_key=license_key,
        tier_slug="corporate",
        tier_name="Corporate",
        valid_until=now + timedelta(days=365),
        purchased_at=now - timedelta(days=30),
        billing_period="annual",
        customer_email="demo@proxmoxvex.com",
        max_nodes=64,
        nodes_used=11,
        over_limit=False,
    )
    db.conn.execute(
        "UPDATE license_context SET next_check_at = ? WHERE node_id = ?",
        ((now + timedelta(days=365)).isoformat(), "default"),
    )
    db.conn.commit()
    # Tier-only lifecycle event — FR-006: no key material in logs.
    add_license_log_entry(
        db.conn, "seeded", tier_to="corporate",
        reason="demo sandbox licence fixture")
    logging.info("[DEMO_SEED] Seeded synthetic Corporate licence context")


def _ensure_demo_plugin_state() -> None:
    """Mark every paid catalog plugin enabled so delivery restores it.

    The release image ships free plugins only — paid source is stripped by
    filter_free_plugins_for_image.py. background/plugin_updates treats an
    enabled-but-missing paid plugin as "update = initial download" and
    restores it through PluginDeliveryService on the first auto-update
    cycle (~2min after boot). Enabling the full paid catalog here lets the
    demo present every plugin once PROXMOXVEX_DEMO_LICENSE_KEY +
    LICENCE_SERVICE_URL point at a licensing service that honours the key;
    without them the rows simply stay enabled-but-missing, which is the
    same state a licensed install shows before its first artifact pull.
    """
    from ProxmoxVEx.api.helpers import load_server_settings, save_server_settings
    from ProxmoxVEx.constants import PLUGINS_DIR

    catalog_file = os.path.join(PLUGINS_DIR, "directory.json")
    if not os.path.exists(catalog_file):
        return
    with open(catalog_file, encoding="utf-8") as fh:
        catalog = json.load(fh)
    now = datetime.now(UTC).isoformat()
    db = get_db()
    existing = {
        row["plugin_id"] if isinstance(row, dict) else row[0]
        for row in (db.query("SELECT plugin_id FROM plugin_state") or [])
    }
    enabled = 0
    for entry in catalog.get("plugins", []):
        slug = entry.get("slug")
        if not slug or not (entry.get("is_paid") or entry.get("download_required")):
            continue
        if slug in existing:
            continue
        db.conn.execute(
            "INSERT INTO plugin_state (plugin_id, enabled, loaded_at, error)"
            " VALUES (?, 1, ?, '')",
            (slug, now),
        )
        enabled += 1
    db.conn.commit()
    if enabled:
        logging.info("[DEMO_SEED] Enabled %d paid catalog plugins for restore", enabled)

    # The auto-update cycle is what restores the enabled-but-missing paid
    # plugins — force it on in demo regardless of saved-settings state.
    try:
        settings = load_server_settings() or {}
        settings["plugin_auto_update"] = True
        settings.setdefault("plugin_auto_update_interval_hours", 1)
        # Theme-aware integration iframes follow the default theme, but the
        # app chrome is the fixed navy corporate palette — keep the demo on
        # corporateDark (the app's own default) so everything renders the
        # same navy instead of the Ember/brown proxmoxDark fallback.
        settings["default_theme"] = "corporateDark"
        save_server_settings(settings)
    except Exception as exc:
        logging.warning("[DEMO_SEED] Could not enable plugin auto-update: %s", exc)


def seed_demo():
    """Seed demo fixtures if demo mode is active."""
    if not is_demo_mode():
        return
    from ProxmoxVEx.demo import DEMO_SEED_VERSION

    logging.info(f"[DEMO_SEED] Seeding demo fixtures version {DEMO_SEED_VERSION}")
    try:
        _ensure_demo_user()
    except Exception as e:
        logging.error(f"[DEMO_SEED] Failed to seed demo user: {e}")
    try:
        _ensure_demo_cluster_groups()
    except Exception as e:
        logging.error(f"[DEMO_SEED] Failed to seed demo cluster groups: {e}")
    try:
        _ensure_demo_cluster()
    except Exception as e:
        logging.error(f"[DEMO_SEED] Failed to seed demo cluster: {e}")
    try:
        _ensure_demo_migration_history()
    except Exception as e:
        logging.error(f"[DEMO_SEED] Failed to seed migration history: {e}")
    try:
        _ensure_demo_alerts()
    except Exception as e:
        logging.error(f"[DEMO_SEED] Failed to seed alert rules: {e}")
    try:
        _ensure_demo_pbs_server()
    except Exception as e:
        logging.error(f"[DEMO_SEED] Failed to seed demo PBS server: {e}")
    try:
        _ensure_demo_vmware_server()
    except Exception as e:
        logging.error(f"[DEMO_SEED] Failed to seed demo vCenter server: {e}")
    try:
        _ensure_demo_netapp_endpoint()
    except Exception as e:
        logging.error(f"[DEMO_SEED] Failed to seed demo NetApp endpoint: {e}")
    try:
        _ensure_demo_portainer_rancher_rows()
    except Exception as e:
        logging.error(f"[DEMO_SEED] Failed to seed Portainer/Rancher rows: {e}")
    try:
        _ensure_demo_rockstor_rows()
    except Exception as e:
        logging.error(f"[DEMO_SEED] Failed to seed Rockstor rows: {e}")
    try:
        _ensure_demo_table_rows()
    except Exception as e:
        logging.error(f"[DEMO_SEED] Failed to seed demo table rows: {e}")
    try:
        apply_demo_plugin_configs()
    except Exception as e:
        logging.error(f"[DEMO_SEED] Failed to apply plugin config overlays: {e}")
    try:
        _ensure_demo_license_context()
    except Exception as e:
        logging.error(f"[DEMO_SEED] Failed to seed licence context: {e}")
    try:
        _ensure_demo_plugin_state()
    except Exception as e:
        logging.error(f"[DEMO_SEED] Failed to seed plugin state: {e}")
