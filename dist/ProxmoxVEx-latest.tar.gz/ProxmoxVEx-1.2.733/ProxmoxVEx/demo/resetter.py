# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/demo/resetter.py
# Project:     ProxmoxVEx
# Version:     1.2.728
# Build:       2026.11.23
# Description: In-app demo sandbox resetter — drops the demo schema on a
#              timer and SIGTERMs the process so docker restarts into a
#              fresh baseline. Replaces the pid-ns-sharing reset sidecar.
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-11-23
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Demo sandbox reset loop (demo mode only).

Historically a separate container ran ``scripts/demo-reset.py`` sharing the
app's PID namespace so it could SIGTERM the app after dropping the schema.
Two problems made that fragile: ``command:`` appended to the image
ENTRYPOINT (the sidecar actually ran a second full app instance), and
docker kills pid-namespace dependents when the provider container stops
but does not reliably restart them — so resets silently died.

Running the cycle in-app removes the coupling entirely: a daemon
greenlet sleeps ``PROXMOXVEX_DEMO_RESET_INTERVAL`` seconds, drops the
``public`` schema via a dedicated psycopg2 connection, then SIGTERMs the
process. Docker's restart policy brings the app back up and the normal
``seed_demo`` flow repopulates the baseline.
"""

import logging
import os
import signal
import threading
import time

logger = logging.getLogger(__name__)

_DEFAULT_INTERVAL = 900
_reset_thread: threading.Thread | None = None


def _database_url() -> str:
    return os.environ.get(
        "PROXMOXVEX_DATABASE_URL",
        "postgresql://proxmoxvex:proxmoxvex@postgres-demo:5432/proxmoxvex_demo",
    )


def _reset_schema() -> bool:
    """Drop and recreate the ``public`` schema. Returns True on success.

    The app holds a pool of ``idle in transaction`` connections whose
    locks block DROP SCHEMA indefinitely, so every other backend on the
    demo database is terminated first (their pools reconnect into the
    fresh schema moments later — the process is about to exit anyway).
    """
    import psycopg2

    url = _database_url()
    dbname = url.rsplit("/", 1)[-1].split("?", 1)[0]
    conn = psycopg2.connect(url)
    try:
        conn.set_session(autocommit=True)
        with conn.cursor() as cur:
            cur.execute("SET lock_timeout = '5s'")
            for attempt in range(3):
                cur.execute(
                    "SELECT pg_terminate_backend(pid) FROM pg_stat_activity "
                    "WHERE datname = %s AND pid <> pg_backend_pid()",
                    (dbname,),
                )
                try:
                    cur.execute("DROP SCHEMA IF EXISTS public CASCADE")
                    cur.execute("CREATE SCHEMA public")
                    logger.warning("[DEMO_RESET] Dropped and recreated public schema")
                    return True
                except psycopg2.Error as e:
                    logger.warning(
                        "[DEMO_RESET] Schema drop attempt %d failed: %s",
                        attempt + 1,
                        e,
                    )
        return False
    finally:
        conn.close()


def _reset_loop() -> None:
    try:
        interval = max(60, int(os.environ.get("PROXMOXVEX_DEMO_RESET_INTERVAL", str(_DEFAULT_INTERVAL))))
    except ValueError:
        interval = _DEFAULT_INTERVAL
    logger.warning("[DEMO_RESET] In-app resetter started; interval=%ss", interval)
    while True:
        time.sleep(interval)
        try:
            if _reset_schema():
                logger.warning(
                    "[DEMO_RESET] Schema dropped; signalling process to restart"
                )
                os.kill(os.getpid(), signal.SIGTERM)
                return
        except Exception as exc:
            logger.error("[DEMO_RESET] Reset cycle failed: %s", exc)


def start_demo_resetter() -> None:
    """Start the in-app reset loop. No-op outside demo mode."""
    global _reset_thread
    from ProxmoxVEx.demo import is_demo_mode

    if not is_demo_mode():
        return
    if _reset_thread is None or not _reset_thread.is_alive():
        _reset_thread = threading.Thread(
            target=_reset_loop,
            daemon=True,
            name="demo-reset",
        )
        _reset_thread.start()
