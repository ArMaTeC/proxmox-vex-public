# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/demo/cluster_mock.py
# Project:     ProxmoxVEx
# Version:     1.2.727
# Build:       2026.11.23
# Description: Intercept cluster manager HTTPS calls for the synthetic
#              demo cluster.
# Usage:       import ProxmoxVEx.demo.cluster_mock
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-11-23
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Intercept cluster manager HTTPS calls for the synthetic demo cluster.

Clusters seeded with ``host='demo'`` use this mock instead of talking to a
real Proxmox API.  Response shapes follow the PVE ``/api2/json`` convention
(``{"data": ...}``) so existing manager and frontend code parse them
unchanged.

The dataset is *recorded*, not generated on the fly: ``fixtures/demo/
inventory.json`` holds the static inventory and ``fixtures/demo/
rrddata.json`` holds a 24h metrics sequence that is replayed anchored to
wall-clock time (with interpolation between samples), so dashboards,
charts and counters look live instead of frozen.
"""

import copy
import json
import logging
import os
import re
import time
from pathlib import Path
from typing import Any
from urllib.parse import parse_qs, unquote, urlparse

import requests

from ProxmoxVEx.demo import DEMO_CLUSTER_HOST

# ---------------------------------------------------------------------------
# Fixture loading
# ---------------------------------------------------------------------------

# fixtures/demo lives at the repo/image root next to the ProxmoxVEx package.
# PROXMOXVEX_DEMO_FIXTURE_DIR is a deliberate override for packaged/dev
# deployments — the process environment is a trusted channel (same accepted
# risk as PROXMOXVEX_CONFIG_DIR in constants.py).  The env value is used only
# as an allowlist lookup key — never concatenated into a path — so an
# arbitrary value can select one of the fixed dirs below but nothing else.
_DEFAULT_FIXTURE_DIR = Path(__file__).resolve().parents[2] / "fixtures" / "demo"
_ALLOWED_FIXTURE_DIRS = {
    str(p): p
    for p in (
        _DEFAULT_FIXTURE_DIR,
        Path("/opt/proxmoxvex/fixtures/demo"),
        Path("/var/lib/proxmoxvex/fixtures/demo"),
        Path("/usr/share/proxmoxvex/fixtures/demo"),
    )
}
_FIXTURE_DIR = _ALLOWED_FIXTURE_DIRS.get(
    os.environ.get("PROXMOXVEX_DEMO_FIXTURE_DIR", ""), _DEFAULT_FIXTURE_DIR
)
_fixture_cache: dict = {}


def _fixture_file(name: str) -> dict:
    """Load a JSON fixture from fixtures/demo, cached for the process."""
    if name not in _fixture_cache:
        try:
            safe_name = os.path.basename(name)
            _fixture_cache[name] = json.loads((_FIXTURE_DIR / safe_name).read_text())
        except Exception as e:  # pragma: no cover - defensive fallback
            logging.warning(f"[DEMO_MOCK] Could not load fixture {name}: {e}")
            _fixture_cache[name] = {}
    return _fixture_cache[name]


def _inv(key: str, default=None):
    """Return a section of inventory.json (embedded defaults as fallback)."""
    return _fixture_file("inventory.json").get(key, default)


# Embedded fallback inventory (used only if fixtures/demo is missing).
_EMBEDDED_NODES = [
    {"node": "pve-demo-01", "status": "online", "cpu": 0.12, "maxcpu": 8, "mem": 8589934592, "maxmem": 34359738368, "disk": 4294967296, "maxdisk": 107374182400, "uptime": 86400, "id": "node/pve-demo-01", "type": "node"},
    {"node": "pve-demo-02", "status": "online", "cpu": 0.08, "maxcpu": 8, "mem": 6442450944, "maxmem": 34359738368, "disk": 2147483648, "maxdisk": 107374182400, "uptime": 43200, "id": "node/pve-demo-02", "type": "node"},
]
_EMBEDDED_QEMU = [
    {"vmid": 100, "name": "web-01", "status": "running", "node": "pve-demo-01", "cpus": 2, "maxcpu": 2, "cpu": 0.25, "memory": 4294967296, "maxmem": 4294967296, "mem": 2147483648, "disk": 10737418240, "maxdisk": 34359738368, "netin": 12345, "netout": 4321, "uptime": 36000, "pid": 1234, "type": "qemu", "id": "qemu/100"},
]
_EMBEDDED_LXC = [
    {"vmid": 200, "name": "monitor", "status": "running", "node": "pve-demo-02", "cpus": 2, "maxcpu": 2, "cpu": 0.15, "memory": 2147483648, "maxmem": 2147483648, "mem": 1073741824, "disk": 2147483648, "maxdisk": 10737418240, "netin": 1234, "netout": 567, "uptime": 18000, "type": "lxc", "id": "lxc/200"},
]
_EMBEDDED_STORAGE = [
    {"storage": "local-lvm", "plugintype": "lvmthin", "content": "rootdir,images", "total": 107374182400, "used": 10737418240, "available": 96636764160, "active": 1, "node": "pve-demo-01", "shared": 0, "id": "storage/pve-demo-01/local-lvm", "type": "storage"},
]

# ---------------------------------------------------------------------------
# Per-cluster datasets (multi-region demo)
# ---------------------------------------------------------------------------
#
# Each seeded demo cluster uses a distinct synthetic host ("demo", "demo-us",
# "demo-uk", ...); requests are routed to a per-host dataset keyed off the URL
# hostname, so every cluster shows its own inventory instead of sharing one.
# Non-base datasets are deterministic *variants* of the same recorded
# fixtures: node names, guest names, VMIDs and IPs are remapped, and metrics
# playback is phase-shifted, so regions look related but not copy-pasted.

_VARIANT_SPECS: dict = {
    DEMO_CLUSTER_HOST: None,  # base fixtures, untransformed
    "demo-us": {
        "cluster_name": "prod-us",
        "ip_prefix": "10.20.",
        "phase_seconds": 8 * 3600,  # offset the daily wave vs. the EU cluster
        "vmid_offset": 1000,
        "node_prefix": "pve-us-",
        "name_map": {
            "web-01": "storefront-01",
            "db-01": "orders-db-01",
            "cache-01": "session-cache-01",
            "gitlab-01": "ci-runner-01",
            "k8s-cp-01": "k8s-us-cp-01",
            "k8s-w-01": "k8s-us-w-01",
            "k8s-w-02": "k8s-us-w-02",
            "win11-ws": "win11-us-ws",
            "monitor": "librenms-01",
            "dns-01": "dns-us-01",
            "proxy-01": "proxy-us-01",
        },
    },
    "demo-sg": {
        "cluster_name": "edge-sg",
        "ip_prefix": "10.30.",
        "phase_seconds": 16 * 3600,
        "vmid_offset": 2000,
        "node_prefix": "pve-sg-",
        "name_map": {
            "web-01": "kiosk-ui-01",
            "db-01": "sensor-db-01",
            "cache-01": "edge-cache-01",
            "gitlab-01": "demo-sandbox-01",
            "k8s-cp-01": "k3s-cp-01",
            "k8s-w-01": "k3s-w-01",
            "k8s-w-02": "k3s-w-02",
            "win11-ws": "win10-kiosk",
            "monitor": "mqtt-broker",
            "dns-01": "dns-edge-01",
            "proxy-01": "tunnel-01",
        },
        # A leaner edge site — drop a few guests so cluster sizes differ.
        "drop_guests": (102, 103, 107),
    },
    "demo-dc": {
        # DC West — a bigger backup/HCI site served from standalone
        # fixtures (8 nodes can't come from remapping 3).
        "cluster_name": "dc-west",
        "ip_prefix": "10.40.",
        "phase_seconds": 4 * 3600,
        "fixture": "inventory_dc.json",
        "rrd_fixture": "rrddata_dc.json",
    },
    "demo-uk": {
        "cluster_name": "prod-uk",
        "ip_prefix": "10.50.",
        "phase_seconds": 2 * 3600,
        "vmid_offset": 4000,
        "node_prefix": "pve-uk-",
        "name_map": {
            "web-01": "trading-ui-01",
            "db-01": "ledger-db-01",
            "cache-01": "market-cache-01",
            "gitlab-01": "ci-uk-01",
            "k8s-cp-01": "k8s-uk-cp-01",
            "k8s-w-01": "k8s-uk-w-01",
            "k8s-w-02": "k8s-uk-w-02",
            "win11-ws": "win11-uk-ws",
            "monitor": "grafana-uk-01",
            "dns-01": "dns-uk-01",
            "proxy-01": "proxy-uk-01",
        },
    },
    "demo-jp": {
        "cluster_name": "prod-jp",
        "ip_prefix": "10.60.",
        "phase_seconds": 12 * 3600,
        "vmid_offset": 5000,
        "node_prefix": "pve-jp-",
        "name_map": {
            "web-01": "storefront-jp-01",
            "db-01": "orders-jp-db-01",
            "cache-01": "cache-jp-01",
            "gitlab-01": "ci-jp-01",
            "k8s-cp-01": "k8s-jp-cp-01",
            "k8s-w-01": "k8s-jp-w-01",
            "k8s-w-02": "k8s-jp-w-02",
            "win11-ws": "win11-jp-ws",
            "monitor": "zabbix-jp-01",
            "dns-01": "dns-jp-01",
            "proxy-01": "proxy-jp-01",
        },
    },
    "demo-syd": {
        "cluster_name": "edge-syd",
        "ip_prefix": "10.70.",
        "phase_seconds": 20 * 3600,
        "vmid_offset": 6000,
        "node_prefix": "pve-syd-",
        "name_map": {
            "web-01": "kiosk-syd-01",
            "db-01": "telemetry-db-01",
            "cache-01": "edge-cache-syd",
            "gitlab-01": "builder-syd-01",
            "k8s-cp-01": "k3s-syd-cp-01",
            "k8s-w-01": "k3s-syd-w-01",
            "k8s-w-02": "k3s-syd-w-02",
            "win11-ws": "win10-syd-kiosk",
            "monitor": "tempmon-syd",
            "dns-01": "dns-syd-01",
            "proxy-01": "tunnel-syd-01",
        },
        # Smaller edge footprint than the production variants.
        "drop_guests": (103, 107),
    },
    "demo-ca": {
        # DR persona — the only cluster in the "DR Sites" group.
        "cluster_name": "dr-ca",
        "ip_prefix": "10.80.",
        "phase_seconds": 6 * 3600,
        "vmid_offset": 7000,
        "node_prefix": "pve-ca-",
        "name_map": {
            "web-01": "dr-portal-01",
            "db-01": "vault-db-01",
            "cache-01": "dr-cache-01",
            "gitlab-01": "runbook-runner-01",
            "k8s-cp-01": "k3s-dr-cp-01",
            "k8s-w-01": "k3s-dr-w-01",
            "k8s-w-02": "k3s-dr-w-02",
            "win11-ws": "win10-dr-jump",
            "monitor": "watchman-dr-01",
            "dns-01": "dns-dr-01",
            "proxy-01": "dr-relay-01",
        },
    },
}


def _drop_guests(inv: dict, drops: set) -> None:
    """Remove guests and their fixture references from a variant inventory.

    Runs on the deep copy *before* the name/VMID remap, so ``drops`` contains
    base VMIDs.  Without this the dropped guests would still leak through
    tasks, HA status, backups and storage volumes.
    """
    if not drops:
        return
    drop_ids = {str(v) for v in drops}
    inv["qemu"] = [g for g in inv.get("qemu", []) if g.get("vmid") not in drops]
    inv["lxc"] = [g for g in inv.get("lxc", []) if g.get("vmid") not in drops]
    for sect in ("vm_configs", "vm_status_extra", "vm_snapshots", "agent", "lxc_interfaces"):
        table = inv.get(sect)
        if isinstance(table, dict):
            for key in [k for k in table if str(k).rsplit("/", 1)[-1] in drop_ids]:
                del table[key]
    inv["tasks"] = [t for t in inv.get("tasks", []) if str(t.get("id")) not in drop_ids]
    inv["migration_log"] = [m for m in inv.get("migration_log", []) if m.get("vmid") not in drops]
    inv["replication"] = [r for r in inv.get("replication", []) if r.get("guest") not in drops]
    inv["ha_resources"] = [
        h for h in inv.get("ha_resources", []) if str(h.get("id", "")).rsplit(":", 1)[-1] not in drop_ids
    ]
    inv["ha_status"] = [
        h for h in inv.get("ha_status", []) if str(h.get("sid", "")).rsplit(":", 1)[-1] not in drop_ids
    ]
    for job in inv.get("backup_jobs", []):
        if isinstance(job.get("vmid"), str):
            job["vmid"] = ",".join(v for v in job["vmid"].split(",") if v.strip() not in drop_ids)
    for items in inv.get("storage_content", {}).values():
        if isinstance(items, list):
            items[:] = [i for i in items if i.get("vmid") not in drops]
    inv["not_backed_up"] = [e for e in inv.get("not_backed_up", []) if e.get("vmid") not in drops]
    # Log lines and PBS snapshots that name a dropped VMID.
    drop_re = re.compile(r"\b(" + "|".join(sorted(drop_ids)) + r")\b")
    inv["cluster_log"] = [
        e for e in inv.get("cluster_log", []) if not drop_re.search(str(e.get("msg", "")))
    ]
    pbs = inv.get("pbs", {})
    for store, snaps in pbs.get("snapshots", {}).items():
        pbs["snapshots"][store] = [s for s in snaps if str(s.get("backup-id")) not in drop_ids]


def _transform_inventory(spec: dict) -> dict:
    """Build a per-cluster inventory variant from the base fixture.

    Remaps node names, guest names and VMIDs throughout — including composite
    keys (``qemu/100``), references embedded in strings (``vm-100-disk-0``,
    ``vm:101``, UPID-style task IDs, comma-separated backup VMID lists) and
    the guest subnet — so every cross-reference stays consistent.
    """
    inv = copy.deepcopy(_fixture_file("inventory.json"))
    _drop_guests(inv, set(spec.get("drop_guests", ())))

    node_map = {n["node"]: spec["node_prefix"] + n["node"].rsplit("-", 1)[-1] for n in inv.get("nodes", [])}
    name_map = dict(node_map)
    name_map.update(spec.get("name_map", {}))
    vmid_offset = int(spec.get("vmid_offset", 0))
    vmids = sorted({g["vmid"] for g in inv.get("qemu", []) + inv.get("lxc", [])}, reverse=True)
    name_re = re.compile("|".join(r"\b" + re.escape(k) + r"\b" for k in sorted(name_map, key=len, reverse=True)))
    vmid_re = re.compile(r"\b(" + "|".join(map(str, vmids)) + r")\b") if vmids and vmid_offset else None
    ip_prefix = spec.get("ip_prefix", "10.10.")

    def rstr(s: str) -> str:
        s = name_re.sub(lambda m: name_map[m.group(0)], s)
        if vmid_re:
            s = vmid_re.sub(lambda m: str(int(m.group(1)) + vmid_offset), s)
        if ip_prefix != "10.10.":
            s = s.replace("10.10.", ip_prefix)
        return s

    def remap(obj: Any, key: str | None = None) -> Any:
        if isinstance(obj, dict):
            return {rstr(k) if isinstance(k, str) else k: remap(v, k) for k, v in obj.items()}
        if isinstance(obj, list):
            return [remap(v) for v in obj]
        if isinstance(obj, str):
            return rstr(obj)
        if isinstance(obj, int) and not isinstance(obj, bool):
            return obj + vmid_offset if key in ("vmid", "guest") else obj
        return obj

    out: dict = remap(inv)
    # nextid sits just above the highest VMID; shift it with the rest.
    if vmid_offset and out.get("nextid"):
        out["nextid"] = str(int(out["nextid"]) + vmid_offset)
    return out


class _Dataset:
    """Fixture view for one demo host — base data or a transformed variant."""

    def __init__(self, host: str):
        self.host = host
        spec = _VARIANT_SPECS.get(host) or {}
        self.cluster_name = spec.get("cluster_name", "demo")
        self.ip_prefix = spec.get("ip_prefix", "10.10.")
        self.ip_subnet = f"{self.ip_prefix}1"  # node addresses live in .1.x
        self.phase = int(spec.get("phase_seconds", 0))
        # "fixture"/"rrd_fixture" spec keys select standalone files loaded
        # untransformed — an 8-node cluster can't be produced by remapping
        # the 3-node base fixture (spec 141). Both keys must be set together.
        fixture = spec.get("fixture")
        if fixture:
            self.inv = _fixture_file(fixture)
            logging.info("[DEMO_MOCK] %s: standalone inventory %s", host, fixture)
        else:
            self.inv = _transform_inventory(spec) if spec else _fixture_file("inventory.json")

        # Annotated as plain `list` — fixture/.get() unions (Any | object)
        # otherwise leak into arithmetic/subscript sites downstream.
        self.nodes: list = self.inv.get("nodes") or _EMBEDDED_NODES
        self.qemu: list = self.inv.get("qemu") or _EMBEDDED_QEMU
        self.lxc: list = self.inv.get("lxc") or _EMBEDDED_LXC
        self.storage: list = self.inv.get("storage") or _EMBEDDED_STORAGE
        self.guests = self.qemu + self.lxc
        self.guest_by_key = {f"{g['type']}/{g['vmid']}": g for g in self.guests}
        self.guest_by_vmid = {str(g["vmid"]): g for g in self.guests}
        self.node_by_name = {n["node"]: n for n in self.nodes}
        self.rrd = self._remap_rrd(spec)

    def _remap_rrd(self, spec: dict) -> dict:
        """Re-key the shared metrics sequence to this dataset's entities."""
        if spec.get("fixture"):
            # Standalone dataset: series keys already match entity names.
            rrd_fixture = spec.get("rrd_fixture")
            if not rrd_fixture:
                logging.warning(
                    "[DEMO_MOCK] %s: 'fixture' set without 'rrd_fixture' — "
                    "metrics will be empty", self.host)
                return {}
            return _fixture_file(rrd_fixture)
        base = _fixture_file("rrddata.json")
        rrd = {"step_seconds": base.get("step_seconds", 300), "nodes": {}, "qemu": {}, "lxc": {}}
        if not spec:
            return base
        offset = int(spec.get("vmid_offset", 0))
        for n in self.nodes:
            base_name = "pve-demo-" + n["node"].rsplit("-", 1)[-1]
            rrd["nodes"][n["node"]] = base.get("nodes", {}).get(base_name, [])
        for kind, guests in (("qemu", self.qemu), ("lxc", self.lxc)):
            for g in guests:
                rrd[kind][str(g["vmid"])] = base.get(kind, {}).get(str(g["vmid"] - offset), [])
        return rrd

    def seq(self, kind: str, key) -> list:
        return self.rrd.get(kind, {}).get(str(key), [])

    def sample(self, kind: str, key, at: float | None = None) -> dict:
        """Interpolated sample at wall-clock ``at`` + this cluster's phase."""
        seq = self.seq(kind, key)
        if not seq:
            return {}
        at = (time.time() if at is None else at) + self.phase
        pos = at / int(self.rrd.get("step_seconds", 300))
        i0 = int(pos) % len(seq)
        i1 = (i0 + 1) % len(seq)
        t = pos - int(pos)
        return {k: _lerp(v, seq[i1].get(k, v), t) for k, v in seq[i0].items()}


_DATASETS: dict = {host: _Dataset(host) for host in _VARIANT_SPECS}


def _dataset_for_host(host: str | None) -> _Dataset:
    """Return the dataset for a synthetic demo host (base as fallback)."""
    return _DATASETS.get(host or "") or _DATASETS[DEMO_CLUSTER_HOST]


# Module-level aliases for the base dataset — kept public so other demo code
# (and the fixture tests) can introspect the canonical inventory.
_BASE = _DATASETS[DEMO_CLUSTER_HOST]
NODES = _BASE.nodes
QEMU = _BASE.qemu
LXC = _BASE.lxc
STORAGE = _BASE.storage
RESOURCES = NODES + QEMU + LXC + STORAGE

_GUESTS = _BASE.guests
_GUEST_BY_KEY = _BASE.guest_by_key
_GUEST_BY_VMID = _BASE.guest_by_vmid
_NODE_BY_NAME = _BASE.node_by_name


# ---------------------------------------------------------------------------
# Recorded-sequence playback (rrddata.json)
# ---------------------------------------------------------------------------

def _lerp(a, b, t):
    if isinstance(a, (int, float)) and isinstance(b, (int, float)):
        return a + (b - a) * t
    return a


def _sample(kind: str, key, at: float | None = None) -> dict:
    """Interpolated sample for wall-clock ``at`` — values drift live."""
    return _BASE.sample(kind, key, at)


# PVE rrddata granularity: (point count, step seconds) per timeframe.
_TIMEFRAMES = {
    "hour": (70, 60),
    "day": (70, 1230),
    "week": (70, 8640),
    "month": (70, 37800),
    "year": (70, 302400),
}


def _rrd_points(ds: _Dataset, kind: str, key, maxmem: int, maxdisk: int, timeframe: str):
    """Build a PVE-shaped rrddata series ending at ``now``."""
    seq = ds.seq(kind, key)
    if not seq:
        return []
    count, step = _TIMEFRAMES.get(timeframe, _TIMEFRAMES["hour"])
    now = time.time()
    points = []
    for i in range(count):
        ts = int(now - (count - 1 - i) * step)
        s = ds.sample(kind, key, ts)
        if kind == "nodes":
            node = ds.node_by_name.get(key, {})
            points.append(
                {
                    "time": ts,
                    "cpu": round(s.get("cpu", 0.1), 4),
                    "maxcpu": node.get("maxcpu", 8),
                    "memtotal": node.get("maxmem", maxmem),
                    "memused": int(s.get("memused_frac", 0.5) * node.get("maxmem", maxmem)),
                    "roottotal": node.get("maxdisk", maxdisk),
                    "rootused": int(s.get("rootfs_frac", 0.4) * node.get("maxdisk", maxdisk)),
                    "swaptotal": 8589934592,
                    "swapused": int(s.get("swapused_frac", 0.05) * 8589934592),
                    "netin": round(s.get("netin", 0)),
                    "netout": round(s.get("netout", 0)),
                    "iowait": round(s.get("iowait", 0), 4),
                    "loadavg": s.get("loadavg", 0.5),
                    "pressurecpusome": s.get("pressurecpusome", 0),
                    "pressurecpufull": 0.0,
                    "pressureiosome": s.get("pressureiosome", 0),
                    "pressureiofull": 0.0,
                    "pressurememorysome": s.get("pressurememorysome", 0),
                    "pressurememoryfull": 0.0,
                }
            )
        else:
            points.append(
                {
                    "time": ts,
                    "cpu": round(s.get("cpu", 0.1), 4),
                    "maxcpu": None,
                    "mem": int(s.get("memused_frac", 0.5) * maxmem),
                    "maxmem": maxmem,
                    "disk": maxdisk and int(maxdisk * 0.45) or 0,
                    "maxdisk": maxdisk,
                    "diskread": round(s.get("diskread", 0)),
                    "diskwrite": round(s.get("diskwrite", 0)),
                    "netin": round(s.get("netin", 0)),
                    "netout": round(s.get("netout", 0)),
                }
            )
    return points


def _live_guest(ds: _Dataset, g: dict) -> dict:
    """Guest dict with cpu/mem/net counters refreshed from the sequence."""
    s = ds.sample(g["type"], g["vmid"])
    g = dict(g)
    if g.get("status") == "running":
        g["cpu"] = round(s.get("cpu", g.get("cpu", 0.1)), 4)
        g["mem"] = int(s.get("memused_frac", 0.5) * g.get("maxmem", 1))
        # Counters must grow monotonically to look like a live host.
        g["netin"] = g.get("netin", 0) + int(s.get("netin", 0) * (time.time() % 3600) / 10)
        g["netout"] = g.get("netout", 0) + int(s.get("netout", 0) * (time.time() % 3600) / 10)
    return g


def _live_node(ds: _Dataset, n: dict) -> dict:
    s = ds.sample("nodes", n["node"])
    n = dict(n)
    n["cpu"] = round(s.get("cpu", n.get("cpu", 0.1)), 4)
    n["mem"] = int(s.get("memused_frac", 0.5) * n.get("maxmem", 1))
    return n


# ---------------------------------------------------------------------------
# Mock response helpers
# ---------------------------------------------------------------------------

class _FakeResponse:
    """Response object compatible with the requests API used by the manager."""

    def __init__(self, json_data, status_code=200):
        self._json = json_data
        self.status_code = status_code
        self.headers = {"content-type": "application/json"}
        self.content = json.dumps(json_data).encode("utf-8") if json_data is not None else b""
        self.text = self.content.decode("utf-8") if self.content else ""

    @property
    def ok(self) -> bool:
        return 200 <= self.status_code < 400

    def json(self, **kwargs):
        return self._json

    def raise_for_status(self):
        if not self.ok:
            raise requests.HTTPError(f"Demo mock returned {self.status_code}")


def _ok(data):
    return _FakeResponse({"data": data})


def _age(value_key: str, entry: dict, default=0):
    """Fixture stores relative ages; convert to an absolute epoch."""
    return int(time.time() - entry.get(value_key, default))


def _task_objects(ds: _Dataset, node=None):
    """Build PVE task objects with timestamps anchored to now."""
    out = []
    for t in ds.inv.get("tasks", []):
        if node and t["node"] != node:
            continue
        starttime = int(time.time() - t.get("age_seconds", 0))
        dur = t.get("duration")
        task = {
            "upid": f"UPID:{t['node']}:{t['upid_suffix']}:0:{starttime:08X}:{t['type']}:{t.get('id','')}:{t['user']}:",
            "node": t["node"],
            "type": t["type"],
            "id": t.get("id", ""),
            "user": t["user"],
            "starttime": starttime,
            "status": t.get("status", "OK"),
        }
        if t.get("running"):
            task["status"] = "running"
        elif dur is not None:
            task["endtime"] = starttime + int(dur)
            task["exitstatus"] = t.get("exitstatus", "OK")
        out.append(task)
    out.sort(key=lambda x: x["starttime"], reverse=True)
    return out


def _task_status(ds: _Dataset, upid: str):
    task = next((t for t in _task_objects(ds) if t["upid"] == upid), None)
    if not task:
        return _FakeResponse({"data": None}, 404)
    if task.get("status") == "running":
        return _ok({"status": "running", "upid": upid, "node": task["node"], "type": task["type"], "user": task["user"], "starttime": task["starttime"], "id": task["id"], "pid": 24512, "pstart": 1})
    return _ok({"status": "stopped", "exitstatus": task.get("exitstatus", "OK"), "upid": upid, "node": task["node"], "type": task["type"], "user": task["user"], "starttime": task["starttime"], "endtime": task.get("endtime"), "id": task["id"]})


def _task_log(ds: _Dataset, upid: str):
    task = next((t for t in _task_objects(ds) if t["upid"] == upid), None)
    lines = ds.inv.get("task_log", [])
    node = task["node"] if task else ds.nodes[0]["node"]
    start = task["starttime"] if task else int(time.time()) - 300
    out = []
    for i, line in enumerate(lines, start=1):
        txt = line.replace("demo-anchor", time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(start)))
        out.append({"n": i, "t": txt, "node": node})
    return _ok(out)


def _node_status(ds: _Dataset, node_name):
    # `or {}` keeps the empty-check below working while giving the checker a
    # concrete dict type instead of the .get() union (Any | None | object).
    node: dict = ds.node_by_name.get(node_name) or {}
    if not node:
        return _FakeResponse({"data": None}, 404)
    s = ds.sample("nodes", node_name)
    extra = ds.inv.get("node_status_extra", {})
    maxmem = node["maxmem"]
    maxdisk = node["maxdisk"]
    mem_used = int(s.get("memused_frac", 0.5) * maxmem)
    rootfs_used = int(s.get("rootfs_frac", 0.4) * maxdisk)
    loadavg = s.get("loadavg", 0.5)
    return _ok(
        {
            "cpu": round(s.get("cpu", node.get("cpu", 0.1)), 4),
            "wait": round(s.get("iowait", 0), 4),
            "idle": 0,
            "loadavg": [str(round(loadavg, 2)), str(round(loadavg * 0.9, 2)), str(round(loadavg * 0.85, 2))],
            "memory": {"total": maxmem, "used": mem_used, "free": maxmem - mem_used, "available": int(maxmem * (1 - s.get("memused_frac", 0.5) * 0.8))},
            "swap": {"total": 8589934592, "used": int(s.get("swapused_frac", 0.05) * 8589934592), "free": 8589934592 - int(s.get("swapused_frac", 0.05) * 8589934592)},
            "rootfs": {"total": maxdisk, "used": rootfs_used, "free": maxdisk - rootfs_used, "avail": maxdisk - rootfs_used},
            "ksm": {"shared": 0},
            "uptime": node["uptime"] + int(time.time() % 86400),
            "pveversion": extra.get("pveversion", "pve-manager/9.0.11/demo"),
            "kversion": extra.get("kversion", "Linux 6.17.0-0.demo"),
            "boot-info": {"mode": extra.get("boot_mode", "efi"), "secureboot": extra.get("secureboot", 0)},
            "cpuinfo": {"model": extra.get("cpuinfo_model", "Demo CPU"), "vendor": extra.get("cpuinfo_vendor", "GenuineIntel"), "family": extra.get("cpuinfo_family", "6"), "cpus": node["maxcpu"], "cores": node["maxcpu"], "sockets": 1, "mhz": "3400.000", "user_hz": 100, "hvm": "1", "flags": "fpu vme de pse tsc msr pae mce cx8 apic sep mtrr pge mca cmov pat pse36 clflush mmx fxsr sse sse2 ss ht syscall nx lm constant_tsc rep_good nopl xtopology cpuid tsc_known_freq pni pclmulqdq ssse3 fma cx16 sse4_1 sse4_2 x2apic movbe popcnt aes xsave avx f16c rdrand lahf_lm abm 3dnowprefetch cpuid_fault"},
            "current-kernel": {"release": "6.17.2-2-pve", "machine": "x86_64", "version": "#1 SMP PREEMPT_DYNAMIC PMX 6.17.2-2 (2026-08-20T10:00Z)", "sysname": "Linux"},
        }
    )


def _vm_config(ds: _Dataset, vmid, node_name, vm_type):
    key = f"{vm_type}/{vmid}"
    cfg = ds.inv.get("vm_configs", {}).get(key)
    vm = ds.guest_by_key.get(key)
    if not vm or vm["node"] != node_name:
        return _FakeResponse({"data": None}, 404)
    if not cfg:
        cfg = {"name": vm["name"], "cores": vm["cpus"], "memory": vm["maxmem"] // (1024 * 1024), "net0": "virtio,bridge=vmbr0,firewall=1", "smbios1": "uuid=00000000-0000-0000-0000-000000000000"}
        cfg["rootfs" if vm_type == "lxc" else "scsi0"] = "local-lvm:8" if vm_type == "lxc" else f"local-lvm:{vm['maxdisk'] // (1024**3)},iothread=1"
    return _ok(cfg)


def _vm_status(ds: _Dataset, vmid, node_name, vm_type):
    key = f"{vm_type}/{vmid}"
    vm = ds.guest_by_key.get(key)
    if not vm or vm["node"] != node_name:
        return _FakeResponse({"data": None}, 404)
    s = ds.sample(vm_type, vmid)
    extra = ds.inv.get("vm_status_extra", {}).get(key, {})
    running = vm["status"] == "running"
    out = {
        "name": vm.get("name") or vm.get("hostname", ""),
        "vmid": vm["vmid"],
        "pid": vm.get("pid", 0),
        "status": vm["status"],
        "cpu": round(s.get("cpu", vm.get("cpu", 0)), 4) if running else 0,
        "cpus": vm["cpus"],
        "mem": int(s.get("memused_frac", 0.5) * vm["maxmem"]) if running else 0,
        "maxmem": vm["maxmem"],
        "disk": vm["disk"],
        "maxdisk": vm["maxdisk"],
        "diskread": extra.get("diskread", int(s.get("diskread", 0) * vm["uptime"])) if running else 0,
        "diskwrite": extra.get("diskwrite", int(s.get("diskwrite", 0) * vm["uptime"])) if running else 0,
        "netin": vm.get("netin", 0) + (int(s.get("netin", 0) * (time.time() % 3600) / 10) if running else 0),
        "netout": vm.get("netout", 0) + (int(s.get("netout", 0) * (time.time() % 3600) / 10) if running else 0),
        "uptime": vm["uptime"] + int(time.time() % 86400) if running else 0,
        "nics": extra.get("nics", {}),
        "ha": extra.get("ha", {"managed": 0}),
        "serial": 0,
    }
    if running:
        out.update({"qmpstatus": "running", "agent": extra.get("agent", 1), "ballooninfo": extra.get("ballooninfo", {}), "running-qemu": extra.get("running-qemu", "9.0.2"), "spice": 0, "clipboard": 1})
    if vm_type == "lxc":
        out["lock"] = ""
        out["swap"] = 0
        out["maxswap"] = 536870912
    return _ok(out)


def _storage_content(ds: _Dataset, storage_id, node_name):
    items = []
    for item in ds.inv.get("storage_content", {}).get(storage_id, []):
        i = dict(item)
        if "ctime_age" in i:
            i["ctime"] = _age("ctime_age", i)
            del i["ctime_age"]
        items.append(i)
    return _ok(items)


def _storage_status(ds: _Dataset, storage_id, node_name):
    st = next((s for s in ds.storage if s["storage"] == storage_id and (s.get("node") == node_name or s.get("shared"))), None)
    if not st:
        return _FakeResponse({"data": None}, 404)
    return _ok({"active": st.get("active", 1), "avail": st.get("avail", st.get("available", 0)), "total": st.get("total", st.get("maxdisk", 0)), "used": st.get("used", st.get("disk", 0)), "shared": st.get("shared", 0), "type": st.get("plugintype", "dir"), "content": st.get("content", "")})


def _replication_objects(ds: _Dataset, node=None):
    out = []
    for r in ds.inv.get("replication", []):
        if node and r.get("source") != node:
            continue
        rr = dict(r)
        rr["last_sync"] = int(time.time() - r.get("last_sync_age", 0))
        rr["next_sync"] = int(time.time() + r.get("next_sync_age", 0))
        rr["last_try"] = rr["last_sync"]
        rr.pop("last_sync_age", None)
        rr.pop("next_sync_age", None)
        out.append(rr)
    return out


def _backup_jobs(ds: _Dataset):
    out = []
    for j in ds.inv.get("backup_jobs", []):
        jj = dict(j)
        jj["next-run"] = int(time.time() + j.get("next-run_age", 86400))
        jj.pop("next-run_age", None)
        out.append(jj)
    return out


def _cluster_log(ds: _Dataset):
    out = []
    for e in ds.inv.get("cluster_log", []):
        ee = dict(e)
        ee["time"] = _age("age_seconds", ee)
        ee.pop("age_seconds", None)
        out.append(ee)
    out.sort(key=lambda x: x["time"], reverse=True)
    return out


def _syslog(ds: _Dataset):
    now = time.strftime("%b %d %H:%M:%S")
    return _ok([f"{now} {line}" for line in ds.inv.get("syslog", [])])


# ---------------------------------------------------------------------------
# Request dispatch
# ---------------------------------------------------------------------------

def _dispatch(method, url, params=None, data=None, **kwargs):
    """Return a synthetic PVE response for the requested endpoint."""
    parsed = urlparse(url)
    # The hostname selects which demo cluster's fixtures answer the request.
    ds = _dataset_for_host(parsed.hostname)
    path = parsed.path
    # Strip the standard PVE API prefix so route matchers stay clean.
    for prefix in ("/api2/json", "/api2/extjs"):
        if path.startswith(prefix):
            path = path[len(prefix):]
            break
    query = parse_qs(parsed.query)
    if params:
        query.update({k: [str(v)] for k, v in params.items()})
    timeframe = query.get("timeframe", ["hour"])[0]

    # PBS API surface: the demo seeds a pbs_servers row and a native
    # integration pointing at the "demo" host on port 8007. The port
    # separates PBS requests from PVE on the shared "demo" hostname.
    if parsed.port == 8007:
        return _route_pbs(method, path, query, ds)

    # Auth handshake (POST) — must come before the write catch-all.
    if path.endswith("/access/ticket"):
        return _ok({"ticket": "demo-ticket", "CSRFPreventionToken": "demo-csrf", "username": "demo@pve"})

    # API-token creation returns the token dict — the generic UPID string below
    # made _try_create_api_token crash on data.get() ("'str' has no attribute
    # 'get'"). Must run before the write catch-all.
    m = re.match(r"/access/users/([^/]+)/token/([^/]+)$", path)
    if m and str(method).upper() == "POST":
        return _ok({
            "tokenid": m.group(2),
            "full-tokenid": f"{m.group(1)}!{m.group(2)}",
            "value": "demo-token-secret",
            "comment": "demo api token",
            "expire": 0,
            "privsep": 1,
        })

    # Console proxies must return dict payloads BEFORE the generic write
    # stub — real PVE answers vncproxy/termproxy with {ticket, port, upid}
    # (termproxy also `user`), and get_vnc_ticket()/get_term_ticket() call
    # data.get() on it. Falling through to the UPID string below crashed
    # /console with "'str' object has no attribute 'get'" on the demo.
    m = re.match(r"/nodes/([^/]+)/(qemu|lxc)/(\d+)/(vncproxy|termproxy)$", path)
    if m and str(method).upper() == "POST":
        return _ok({
            "ticket": f"PVE:demo@pve:{m.group(4)}-demo-ticket",
            "port": 5900,
            "user": "demo@pve",
            "upid": f"UPID:{m.group(1)}:00000001:0000000000:0000000000:{m.group(4)}:{m.group(3)}:demo@pve:",
        })

    # All writes return a fake task UPID so callers that fire-and-forget keep
    # working; the Flask demo guard blocks user-facing writes before this.
    if str(method).upper() in ("POST", "PUT", "DELETE"):
        return _ok(f"UPID:{ds.nodes[0]['node']}:00000001:0000000000:0000000000:qmstart:100:demo@pve:")

    return _route_get(path, query, timeframe, ds)


def _pbs_time(v):
    """PBS fixture stores negative offsets from now; convert to epoch."""
    return int(time.time() + v) if isinstance(v, (int, float)) and v < 0 else int(v)


def _route_pbs(method, path, query, ds=None):
    """Serve the PBS API (port 8007) from the `pbs` fixture section."""
    ds = ds or _BASE
    pbs = ds.inv.get("pbs", {})
    if str(method).upper() in ("POST", "PUT", "DELETE"):
        if path.endswith("/access/ticket"):
            return _ok({"ticket": "demo-pbs-ticket", "CSRFPreventionToken": "demo-csrf", "username": "demo@pam"})
        return _ok("UPID:pbs-demo-01:00000001:00000000:00000000:verify:pbs-main:demo@pam:")

    if path.endswith("/version"):
        return _ok(pbs.get("version", {"version": "3.4.2", "release": "3.4", "repoid": "demo"}))
    if path.endswith("/nodes/localhost/status"):
        st = dict(pbs.get("status", {}))
        return _ok(st)
    if path.endswith("/nodes/localhost/rrd"):
        # Reuse a recorded node series — shape is the same on PBS.
        return _ok(_rrd_points(ds, "nodes", ds.nodes[0]["node"], 34359738368, 118111600640, query.get("timeframe", ["hour"])[0]))
    if path.endswith("/nodes/localhost/tasks"):
        out = []
        for t in pbs.get("tasks", []):
            tt = dict(t)
            tt["starttime"] = _pbs_time(t.get("starttime", 0))
            tt["endtime"] = _pbs_time(t["endtime"]) if t.get("endtime") is not None else None
            out.append(tt)
        out.sort(key=lambda x: x["starttime"], reverse=True)
        return _ok(out)
    if path.endswith("/nodes/localhost/syslog"):
        return _ok(pbs.get("syslog_seed", []))
    if path.endswith("/nodes/localhost/network"):
        return _ok(pbs.get("network", []))
    if path.endswith("/nodes/localhost/dns"):
        return _ok(pbs.get("dns", {}))
    if path.endswith("/nodes/localhost/subscription"):
        return _ok(pbs.get("subscription", {}))
    if path.endswith("/nodes/localhost/time"):
        return _ok({"timezone": "UTC", "time": int(time.time()), "localtime": int(time.time())})
    if path.endswith("/nodes/localhost/apt/update"):
        return _ok(pbs.get("apt_update", []))
    if path.endswith("/nodes/localhost/disks/list"):
        return _ok(pbs.get("disks", []))
    if "/disks/smart" in path:
        return _ok({"health": "PASSED", "type": "ssd", "wearout": 6})
    if path.endswith("/status/datastore-usage"):
        return _ok(pbs.get("datastore_usage", []))
    if path.endswith("/admin/datastore"):
        return _ok(pbs.get("datastores", []))
    m = re.match(r"/admin/datastore/([^/]+)/status$", path)
    if m:
        return _ok(pbs.get("datastore_status", {}).get(m.group(1), {}))
    m = re.match(r"/admin/datastore/([^/]+)/snapshots$", path)
    if m:
        snaps = []
        for s in pbs.get("snapshots", {}).get(m.group(1), []):
            ss = dict(s)
            ss["backup-time"] = _pbs_time(s.get("backup-time", 0))
            snaps.append(ss)
        return _ok(snaps)
    m = re.match(r"/admin/datastore/([^/]+)/content$", path)
    if m:
        return _ok(pbs.get("snapshots", {}).get(m.group(1), []))
    for key, sub in (("datastore", "/config/datastore"), ("prune", "/config/prune"), ("verify", "/config/verify"), ("sync", "/config/sync"), ("remote", "/config/remote"), ("traffic-control", "/config/traffic-control")):
        if path.endswith(sub):
            return _ok(pbs.get("config", {}).get(key, []))
    if path.endswith("/config/notifications/endpoints"):
        return _ok(pbs.get("config", {}).get("notifications", {}).get("endpoints", []))
    if path.endswith("/config/notifications/matchers"):
        return _ok(pbs.get("config", {}).get("notifications", {}).get("matchers", []))
    return _ok([])


def _route_get(path, query, timeframe, ds):
    inv = ds.inv

    # Version probes
    if path.endswith("/version"):
        return _ok(inv.get("node_version", {"release": "9.0", "repoid": "demo", "version": "9.0.11"}))

    # ---- cluster-level -------------------------------------------------
    if path.endswith("/cluster/config/nodes"):
        return _ok([{"name": n["node"], "node": n["node"], "nodeid": i + 1, "ip": f"{ds.ip_subnet}.{11 + i}", "pveversion": inv.get("node_status_extra", {}).get("pveversion", "9.0.11"), "vote": 1} for i, n in enumerate(ds.nodes)])

    if path.endswith("/cluster/config/join"):
        return _ok({"config": {"nodelist": {n["node"]: {"nodeid": i + 1, "ring0_addr": f"{ds.ip_subnet}.{11 + i}", "pve_addr": f"{ds.ip_subnet}.{11 + i}"} for i, n in enumerate(ds.nodes)}}, "nodelist": {n["node"]: {"nodeid": i + 1, "ring0_addr": f"{ds.ip_subnet}.{11 + i}", "pve_addr": f"{ds.ip_subnet}.{11 + i}"} for i, n in enumerate(ds.nodes)}, "preferred_node": ds.nodes[0]["node"], "totem": {"cluster_name": ds.cluster_name, "config_version": 3}})

    if path.endswith("/cluster/status"):
        out = [{"id": "cluster", "type": "cluster", "name": ds.cluster_name, "nodes": len(ds.nodes), "quorate": 1, "version": 12}, {"id": "quorum", "type": "quorum", "quorate": 1, "nodes": len(ds.nodes)}]
        out += [{"id": f"node/{n['node']}", "type": "node", "name": n["node"], "nodeid": i + 1, "ip": f"{ds.ip_subnet}.{11 + i}", "online": 1, "level": "", "local": 1 if i == 0 else 0} for i, n in enumerate(ds.nodes)]
        return _ok(out)

    if path.endswith("/cluster/tasks"):
        return _ok(_task_objects(ds))

    if path.endswith("/cluster/log"):
        return _ok(_cluster_log(ds, ))

    if path.endswith("/cluster/backup-info/not-backed-up"):
        return _ok(inv.get("not_backed_up", []))

    if path.endswith("/cluster/backup"):
        return _ok(_backup_jobs(ds, ))
    m = re.match(r"/cluster/backup/([^/]+)$", path)
    if m:
        job = next((j for j in _backup_jobs(ds, ) if j["id"] == m.group(1)), None)
        return _ok(job) if job else _FakeResponse({"data": None}, 404)

    if path.endswith("/cluster/replication"):
        return _ok(_replication_objects(ds))
    m = re.match(r"/cluster/replication/([^/]+)$", path)
    if m:
        job = next((j for j in _replication_objects(ds) if j["id"] == m.group(1)), None)
        return _ok(job) if job else _FakeResponse({"data": None}, 404)

    if path.endswith("/cluster/ha/status/manager_status"):
        return _ok(inv.get("ha_manager_status", {}))
    if path.endswith("/cluster/ha/status/current"):
        return _ok(inv.get("ha_status", []))
    if path.endswith("/cluster/ha/groups"):
        return _ok(inv.get("ha_groups", []))
    if path.endswith("/cluster/ha/resources"):
        return _ok(inv.get("ha_resources", []))
    if path.endswith("/cluster/ha/rules"):
        return _ok(inv.get("ha_rules", []))

    if path.endswith("/cluster/options"):
        return _ok(inv.get("cluster_options", {}))

    if path.endswith("/cluster/metrics/server"):
        return _ok(inv.get("metrics_server", []))

    if path.endswith("/cluster/nextid"):
        return _ok(inv.get("nextid", "108"))

    # Cluster firewall
    if path.endswith("/cluster/firewall/options"):
        return _ok(inv.get("firewall_options", {}))
    if path.endswith("/cluster/firewall/rules"):
        return _ok(inv.get("firewall_rules", []))
    if path.endswith("/cluster/firewall/aliases"):
        return _ok(inv.get("firewall_aliases", []))
    if path.endswith("/cluster/firewall/groups"):
        return _ok(inv.get("firewall_groups", []))
    m = re.match(r"/cluster/firewall/ipset/([^/]+)$", path)
    if m:
        return _ok(inv.get("firewall_ipset_content", {}).get(m.group(1), []))
    if path.endswith("/cluster/firewall/ipset"):
        return _ok(inv.get("firewall_ipset", []))

    # SDN
    if path.endswith("/cluster/sdn/zones"):
        return _ok(inv.get("sdn_zones", []))
    m = re.match(r"/cluster/sdn/zones/([^/]+)$", path)
    if m:
        z = next((x for x in inv.get("sdn_zones", []) if x["zone"] == m.group(1)), None)
        return _ok(z) if z else _FakeResponse({"data": None}, 404)
    if path.endswith("/cluster/sdn/vnets"):
        return _ok(inv.get("sdn_vnets", []))
    m = re.match(r"/cluster/sdn/vnets/([^/]+)/subnets/?$", path)
    if m:
        return _ok(inv.get("sdn_subnets", {}).get(m.group(1), []))
    m = re.match(r"/cluster/sdn/vnets/([^/]+)$", path)
    if m:
        v = next((x for x in inv.get("sdn_vnets", []) if x["vnet"] == m.group(1)), None)
        return _ok(v) if v else _FakeResponse({"data": None}, 404)
    if path.endswith("/cluster/sdn/controllers"):
        return _ok(inv.get("sdn_controllers", []))
    if path.endswith("/cluster/sdn/ipams"):
        return _ok(inv.get("sdn_ipams", []))
    if path.endswith("/cluster/sdn/dns"):
        return _ok(inv.get("sdn_dns", []))
    if path.endswith("/cluster/sdn/fabrics/fabric"):
        return _ok([])
    if path.endswith("/cluster/sdn"):
        return _ok(inv.get("sdn_status", {}))

    # Cluster mappings / ceph
    if path.endswith("/cluster/mapping/pci"):
        return _ok(inv.get("mapping_pci", []))
    if path.endswith("/cluster/mapping/usb"):
        return _ok(inv.get("mapping_usb", []))
    if path.endswith("/cluster/ceph") or "/cluster/ceph/" in path:
        return _ok({"health": inv.get("ceph_status", {}).get("health", {"status": "HEALTH_OK"}), "fsid": "deaf-beef-demo-0000-000000000000"})

    # Access control
    if path.endswith("/access/users"):
        return _ok(inv.get("access_users", []))
    if path.endswith("/access/groups"):
        return _ok(inv.get("access_groups", []))
    if path.endswith("/access/domains"):
        return _ok(inv.get("access_domains", []))
    if path.endswith("/access/acl"):
        return _ok(inv.get("access_acl", []))
    if path.endswith("/access/permissions"):
        return _ok({"/": {"Datastore.Audit": 1, "Sys.Audit": 1, "VM.Audit": 1}, "/vms": {"VM.Audit": 1}})
    if path.endswith("/access/tfa"):
        return _ok(inv.get("access_tfa", {}))
    m = re.match(r"/access/users/([^/]+)/token/([^/]+)$", path)
    if m:
        return _ok({"tokenid": m.group(2), "comment": "demo api token", "expire": 0, "privsep": 1})

    # Pools
    if path.endswith("/pools") or path.endswith("/cluster/pools"):
        return _ok(inv.get("pools", []))
    m = re.match(r"/pools/([^/]+)$", path)
    if m:
        pool = next((p for p in inv.get("pools", []) if p["poolid"] == m.group(1)), None)
        if not pool:
            return _FakeResponse({"data": None}, 404)
        members = [dict(g, id=f"{g['type']}/{g['vmid']}") for g in ds.guests if g.get("pool") == pool["poolid"]]
        return _ok({"comment": pool.get("comment", ""), "poolid": pool["poolid"], "members": members})

    # Per-node storage must be matched before the generic "/storage" suffix
    # below, otherwise /nodes/<n>/storage would return cluster storage config.
    m = re.match(r"/nodes/([^/]+)/storage$", path)
    if m:
        node = m.group(1)
        return _ok([s for s in ds.storage if s.get("node") == node or s.get("shared")])

    # Storage config (cluster-level /storage)
    if path.endswith("/storage"):
        return _ok(inv.get("storage_cfg", []))
    m = re.match(r"/storage/([^/]+)$", path)
    if m:
        cfg = next((s for s in inv.get("storage_cfg", []) if s["storage"] == m.group(1)), None)
        return _ok(cfg) if cfg else _FakeResponse({"data": None}, 404)

    # Cluster resources with optional ?type= filter
    if path.endswith("/cluster/resources"):
        requested_type = query.get("type", [None])[0]
        res = [_live_node(ds, n) for n in ds.nodes] + [_live_guest(ds, g) for g in ds.guests] + ds.storage
        if requested_type == "vm":
            res = [r for r in res if r["type"] in ("qemu", "lxc")]
        elif requested_type == "storage":
            res = [r for r in res if r["type"] == "storage"]
        elif requested_type == "node":
            res = [r for r in res if r["type"] == "node"]
        return _ok(res)

    if path.endswith("/cluster/config"):
        return _ok({"totem": {"cluster_name": ds.cluster_name, "config_version": 3}, "nodelist": {n["node"]: {"nodeid": i + 1, "ring0_addr": f"{ds.ip_subnet}.{11 + i}"} for i, n in enumerate(ds.nodes)}})

    # ---- node-level ----------------------------------------------------
    if path.endswith("/nodes"):
        return _ok([_live_node(ds, n) for n in ds.nodes])

    m = re.match(r"/nodes/([^/]+)/status$", path)
    if m:
        return _node_status(ds, m.group(1))

    m = re.match(r"/nodes/([^/]+)/rrddata$", path)
    if m:
        node = ds.node_by_name.get(m.group(1))
        if not node:
            return _FakeResponse({"data": None}, 404)
        return _ok(_rrd_points(ds, "nodes", node["node"], node["maxmem"], node["maxdisk"], timeframe))

    m = re.match(r"/nodes/([^/]+)/qemu$", path)
    if m:
        return _ok([_live_guest(ds, g) for g in ds.qemu if g["node"] == m.group(1)])

    m = re.match(r"/nodes/([^/]+)/lxc$", path)
    if m:
        return _ok([_live_guest(ds, g) for g in ds.lxc if g["node"] == m.group(1)])

    m = re.match(r"/nodes/([^/]+)/network$", path)
    if m:
        return _ok(inv.get("network", {}).get(m.group(1), []))

    m = re.match(r"/nodes/([^/]+)/disks/list$", path)
    if m:
        return _ok(inv.get("disks", {}).get(m.group(1), []))

    m = re.match(r"/nodes/([^/]+)/disks/smart$", path)
    if m:
        return _ok({"health": "PASSED", "text": "smart data", "type": "text", "attributes": [], "wearout": 3})

    if re.search(r"/nodes/[^/]+/disks/(lvm|lvmthin|zfs|directory)$", path):
        return _ok(inv.get("scan_" + path.rsplit("/", 1)[-1], []))

    m = re.match(r"/nodes/([^/]+)/services$", path)
    if m:
        return _ok(inv.get("services", []))

    m = re.match(r"/nodes/([^/]+)/dns$", path)
    if m:
        return _ok(inv.get("dns", {}))

    m = re.match(r"/nodes/([^/]+)/time$", path)
    if m:
        return _ok({"time": int(time.time()), "localtime": int(time.time()), "timezone": inv.get("time", {}).get("timezone", "UTC")})

    m = re.match(r"/nodes/([^/]+)/hosts$", path)
    if m:
        hosts = "127.0.0.1 localhost.localdomain localhost\n"
        for i, n in enumerate(ds.nodes):
            hosts += f"{ds.ip_subnet}.{11 + i} {n['node']}.demo.lab {n['node']}\n"
        return _ok({"data": hosts, "digest": "demo"})

    m = re.match(r"/nodes/([^/]+)/syslog$", path)
    if m:
        return _syslog(ds, )

    m = re.match(r"/nodes/([^/]+)/journal$", path)
    if m:
        return _syslog(ds, )

    m = re.match(r"/nodes/([^/]+)/apt/update$", path)
    if m:
        return _ok(inv.get("apt_update", []))

    m = re.match(r"/nodes/([^/]+)/apt/repositories$", path)
    if m:
        return _ok({"repositories": inv.get("apt_repositories", []), "files": [], "digest": "demo", "errors": [], "infos": [], "warnings": [], "standard-repos": []})

    m = re.match(r"/nodes/([^/]+)/aplinfo$", path)
    if m:
        return _ok([{"package": "debian-12-standard", "name": "debian-12-standard_12.7-1_amd64.tar.zst", "os": "debian", "release": "12.7", "section": "system", "sha512sum": "demo", "size": 122683392, "type": "package", "version": "12.7-1", "description": "Debian 12 (bookworm) standard"}])

    m = re.match(r"/nodes/([^/]+)/subscription$", path)
    if m:
        return _ok(inv.get("subscription", {}))

    m = re.match(r"/nodes/([^/]+)/config$", path)
    if m:
        return _ok(inv.get("node_config", {}))

    if re.search(r"/nodes/[^/]+/certificates/info$", path):
        return _ok({"certificates": inv.get("certificates", []), "deny-human-mismatch": 0})

    if re.search(r"/nodes/[^/]+/certificates/acme/certificate$", path):
        return _ok({"certificate": "", "private": ""})

    m = re.match(r"/nodes/([^/]+)/hardware/pci$", path)
    if m:
        return _ok(inv.get("hardware_pci", []))

    m = re.match(r"/nodes/([^/]+)/hardware/usb$", path)
    if m:
        return _ok(inv.get("hardware_usb", []))

    if re.search(r"/nodes/[^/]+/capabilities/qemu/cpu$", path):
        return _ok(inv.get("capabilities_cpu", []))

    if re.search(r"/nodes/[^/]+/netstat$", path):
        return _ok([{"dev": "vmbr0", "in": 1200000, "out": 900000, "state": "ok"}, {"dev": "vmbr1", "in": 800000, "out": 300000, "state": "ok"}])

    # Per-node tasks
    m = re.match(r"/nodes/([^/]+)/tasks$", path)
    if m:
        return _ok(_task_objects(ds, node=m.group(1)))

    m = re.match(r"/nodes/([^/]+)/tasks/([^/]+)/status$", path)
    if m:
        return _task_status(ds, unquote(m.group(2)))

    m = re.match(r"/nodes/([^/]+)/tasks/([^/]+)/log$", path)
    if m:
        return _task_log(ds, unquote(m.group(2)))

    m = re.match(r"/nodes/([^/]+)/tasks/([^/]+)$", path)
    if m:
        task = next((t for t in _task_objects(ds, node=m.group(1)) if t["upid"] == unquote(m.group(2))), None)
        return _ok(task) if task else _FakeResponse({"data": None}, 404)

    # Per-node storage
    m = re.match(r"/nodes/([^/]+)/storage/([^/]+)/content$", path)
    if m:
        return _storage_content(ds, m.group(2), m.group(1))

    m = re.match(r"/nodes/([^/]+)/storage/([^/]+)/status$", path)
    if m:
        return _storage_status(ds, m.group(2), m.group(1))

    # Node-level ceph
    if re.search(r"/nodes/[^/]+/ceph/status$", path):
        return _ok(inv.get("ceph_status", {}))
    if re.search(r"/nodes/[^/]+/ceph/osd$", path):
        # PVE returns a CRUSH tree (root → host → osd), not a flat list —
        # api/ceph.py::_flatten_osd_tree walks children looking for type=osd.
        hosts = {}
        for osd in inv.get("ceph_osd", []):
            entry = dict(osd)
            entry["type"] = "osd"
            hosts.setdefault(osd["host"], []).append(entry)
        tree = {"root": {"id": -1, "name": "default", "type": "root", "children": [{"id": -(i + 3), "name": host, "type": "host", "children": osds} for i, (host, osds) in enumerate(sorted(hosts.items()))]}}
        return _ok(tree)
    if re.search(r"/nodes/[^/]+/ceph/osd/\d+$", path):
        osd = next((o for o in inv.get("ceph_osd", []) if str(o["id"]) == path.rsplit("/", 1)[-1]), None)
        return _ok(osd) if osd else _FakeResponse({"data": None}, 404)
    if re.search(r"/nodes/[^/]+/ceph/mon$", path):
        return _ok(inv.get("ceph_mon", []))
    if re.search(r"/nodes/[^/]+/ceph/mgr$", path):
        return _ok(inv.get("ceph_mgr", []))
    if re.search(r"/nodes/[^/]+/ceph/mds$", path):
        return _ok(inv.get("ceph_mds", []))
    if re.search(r"/nodes/[^/]+/ceph/pool$", path):
        return _ok(inv.get("ceph_pool", []))
    m = re.search(r"/nodes/[^/]+/ceph/pool/([^/]+)$", path)
    if m:
        pool = next((p for p in inv.get("ceph_pool", []) if p["pool_name"] == m.group(1)), None)
        return _ok(pool) if pool else _FakeResponse({"data": None}, 404)
    if re.search(r"/nodes/[^/]+/ceph/fs$", path):
        return _ok(inv.get("ceph_fs", []))
    if re.search(r"/nodes/[^/]+/ceph/rules$", path):
        return _ok(inv.get("ceph_rules", []))
    if re.search(r"/nodes/[^/]+/ceph/(config|log|init)$", path):
        return _ok({"config": "[global]\n\tsingle line config for demo"})

    # Node-level replication listing
    m = re.match(r"/nodes/([^/]+)/replication$", path)
    if m:
        return _ok(_replication_objects(ds, node=m.group(1)))

    # Node firewall
    if re.search(r"/nodes/[^/]+/firewall/options$", path):
        return _ok({"enable": 1, "log_level_in": "nolog", "log_level_out": "nolog", "policy_in": "DROP", "policy_out": "ACCEPT"})
    if re.search(r"/nodes/[^/]+/firewall/rules$", path):
        return _ok(inv.get("firewall_rules", []))

    # ---- guest-level ---------------------------------------------------
    m = re.match(r"/nodes/([^/]+)/(qemu|lxc)/(\d+)/config$", path)
    if m:
        return _vm_config(ds, m.group(3), m.group(1), m.group(2))

    m = re.match(r"/nodes/([^/]+)/(qemu|lxc)/(\d+)/status/(current)?$", path)
    if m:
        return _vm_status(ds, m.group(3), m.group(1), m.group(2))

    m = re.match(r"/nodes/([^/]+)/(qemu|lxc)/(\d+)/rrddata$", path)
    if m:
        g = ds.guest_by_vmid.get(m.group(3))
        if not g:
            return _FakeResponse({"data": None}, 404)
        return _ok(_rrd_points(ds, g["type"], g["vmid"], g["maxmem"], g["maxdisk"], timeframe))

    m = re.match(r"/nodes/([^/]+)/(qemu|lxc)/(\d+)/snapshot$", path)
    if m:
        snaps = []
        for s in inv.get("vm_snapshots", {}).get(f"{m.group(2)}/{m.group(3)}", []):
            ss = dict(s)
            if "snaptime_age" in ss:
                ss["snaptime"] = _age("snaptime_age", ss)
                del ss["snaptime_age"]
            snaps.append(ss)
        return _ok(snaps)

    # ds.qemu guest agent calls
    m = re.match(r"/nodes/([^/]+)/qemu/(\d+)/agent/(network-get-interfaces|network)$", path)
    if m:
        agent = inv.get("agent", {}).get(f"qemu/{m.group(2)}", {})
        return _ok(agent.get("network", {"result": []}))

    m = re.match(r"/nodes/([^/]+)/qemu/(\d+)/agent/(get|info)$", path)
    if m:
        agent = inv.get("agent", {}).get(f"qemu/{m.group(2)}", {})
        return _ok(agent.get("info", {"result": {"version": "9.0.2"}}))

    m = re.match(r"/nodes/([^/]+)/qemu/(\d+)/agent/get-osinfo$", path)
    if m:
        agent = inv.get("agent", {}).get(f"qemu/{m.group(2)}", {})
        return _ok(agent.get("osinfo", {"result": {}}))

    m = re.match(r"/nodes/([^/]+)/qemu/(\d+)/agent/get-fsinfo$", path)
    if m:
        agent = inv.get("agent", {}).get(f"qemu/{m.group(2)}", {})
        return _ok(agent.get("fsinfo", {"result": []}))

    m = re.match(r"/nodes/([^/]+)/qemu/(\d+)/agent/file-read$", path)
    if m:
        return _ok({"content": "", "truncated": 0})

    m = re.match(r"/nodes/([^/]+)/lxc/(\d+)/interfaces$", path)
    if m:
        return _ok(inv.get("lxc_interfaces", {}).get(m.group(2), []))

    # Guest firewall
    if re.search(r"/nodes/[^/]+/(qemu|lxc)/\d+/firewall/options$", path):
        return _ok({"enable": 1, "dhcp": 1, "ipfilter": 1, "macfilter": 0, "policy_in": "DROP", "policy_out": "ACCEPT", "log_level_in": "nolog", "log_level_out": "nolog", "ndp": 1, "radv": 0})
    if re.search(r"/nodes/[^/]+/(qemu|lxc)/\d+/firewall/rules$", path):
        return _ok([{"pos": 0, "type": "in", "action": "ACCEPT", "proto": "tcp", "dport": "80,443", "enable": 1, "comment": "Allow web traffic", "digest": "demo-g1"}, {"pos": 1, "type": "in", "action": "DROP", "enable": 1, "comment": "Default deny", "digest": "demo-g2"}])
    if re.search(r"/nodes/[^/]+/(qemu|lxc)/\d+/firewall/(aliases|ipset|log|refs)", path):
        return _ok([])

    # Guest single-object fetch (/nodes/x/qemu/100) → config
    m = re.match(r"/nodes/([^/]+)/(qemu|lxc)/(\d+)$", path)
    if m:
        return _vm_config(ds, m.group(3), m.group(1), m.group(2))

    # Node scan endpoints (nfs/cifs/iscsi/pbs)
    if re.search(r"/nodes/[^/]+/scan/(nfs|cifs|iscsi|pbs|glusterfs)$", path):
        return _ok([{"server": "10.10.40.10", "export": "/mnt/backups/proxmox", "path": "/mnt/pve/nfs-backup", "options": ""}] if path.endswith("/nfs") else [])

    # Catch-all: empty list/object keeps unknown reads from raising.
    logging.debug(f"[DEMO_MOCK] Unhandled GET {path} — returning empty data")
    return _ok([])


class _FakeSession(requests.Session):
    """requests.Session-compatible session for the demo cluster."""

    # Match the real requests.Session.request signature: callers may pass
    # params/data positionally (session.request("GET", url, p, d)); accepting
    # them only via **kwargs breaks with a TypeError instead of dispatching.
    # Deliberately narrower than Session.request's 17-arg signature — this is a
    # dispatching fake, not a transport — hence the ignore.
    def request(self, method, url, params=None, data=None, **kwargs):  # type: ignore[override]  # pyright: ignore[reportIncompatibleMethodOverride]
        return _dispatch(method, url, params=params, data=data, **kwargs)


# Patch installer ------------------------------------------------------------

# ---------------------------------------------------------------------------
# Canned SSH layer
#
# The demo's synthetic nodes (pve-dc-01 etc.) have no real hosts behind them,
# so every SSH-backed read endpoint (hardening report, per-NIC netstats,
# ceph mirror status, package scans, config reads) used to fail with a raw
# 500/502/503 error. Instead of erroring, the SSH runners below serve
# plausible canned command output so those views render like a real node.
# Write commands are never reached — the demo guard blocks mutating HTTP
# methods before the handler runs.
# ---------------------------------------------------------------------------

# Marker-name → body used when a combined `echo '---X---' && <cmd>` batch
# command is executed (scan_node_packages, node inventory sweeps, …). Unknown
# markers get the hardening-style OK/FAIL status line so check matrices fill.
_SSH_MARKER_BODIES = {
    "OS": 'PRETTY_NAME="Debian GNU/Linux 12 (bookworm)"\nVERSION_ID="12"',
    "KERNEL": "6.8.12-1-pve",
    "PVE": "pve-manager/8.2.7/6e8b42ac1a29a5c1 (running kernel: 6.8.12-1-pve)",
    "REBOOT": "no",
    "DEBSECAN": "NOT_INSTALLED",
    "UPDATES": (
        "Inst pve-kernel-6.8 [6.8.12-1-pve] (6.8.12-2-pve ProxmoxVEx)\n"
        "Inst pve-manager [8.2.7] (8.2.9 ProxmoxVEx)\n"
        "Inst qemu-server [8.2.4] (8.2.6 ProxmoxVEx)"
    ),
}

_PROC_NET_DEV = """Inter-|   Receive                                                |  Transmit
 face |bytes    packets errs drop fifo frame compressed multicast|bytes    packets errs drop fifo colls carrier compressed
    lo:   9238471   81234    0    0    0     0          0         0   9238471   81234    0    0    0     0       0          0
  eth0: 8473629182 6293457    0    2    0     0          0         0 5120384751 4839201    0    0    0     0       0          0
  eth1: 1203948576  912384    0    0    0     0          0         0  847362918  701823    0    0    0     0       0          0
 vmbr0: 8234567890 5829301    0    2    0     0          0         0 5019283745 4728391    0    0    0     0       0          0
 vmbr1:  847362918  812034    0    0    0     0          0         0  102938475  183726    0    0    0     0       0          0
"""


def _proc_stat() -> str:
    """/proc/stat with counters that advance each call — the per-core
    utilisation reader samples twice and diffs, so identical output would
    show a flat 0% everywhere."""
    tick = int(time.time() * 100)
    lines = []
    total = [0] * 8
    for core in range(8):
        user = 1500000 + tick * 7 + core * 3121
        nice = 2800 + core * 13
        system = 480000 + tick * 2 + core * 977
        idle = 114700000 + tick * 90 + core * 401
        iowait = 21000 + core * 211
        irq = tick
        softirq = 5800 + core * 97 + tick
        steal = 0
        vals = [user, nice, system, idle, iowait, irq, softirq, steal]
        total = [a + b for a, b in zip(total, vals, strict=False)]
        lines.append(f"cpu{core} " + " ".join(str(v) for v in vals))
    head = "cpu  " + " ".join(str(v) for v in total) + " 0 0"
    return (
        head + "\n" + "\n".join(lines) + "\n"
        "intr 982736451\nctxt 3829174651\nbtime 1735689600\n"
        "processes 1827364\nprocs_running 2\nprocs_blocked 0\n"
        "softirq 928374651 0 293847561 182736 0 0 48291 0 129384756 0 38294756\n"
    )


def _hardening_status(cid: str) -> str:
    """Deterministic mostly-pass mix for hardening check markers — a wall of
    all-OK looks synthetic, ~1-in-6 FAIL shows the report's fail path too."""
    return "FAIL" if (sum(ord(c) for c in cid) % 6) == 0 else "OK"


def _demo_ssh_output(command: str) -> str:
    """Canned stdout for shell commands run against synthetic demo nodes.

    Combined `echo '---X---' && <check>` batches (hardening, package scans,
    inventory sweeps) get one marker + body line per marker, in order — the
    callers parse strictly on the markers they echoed.
    """
    cmd = command or ""

    markers = re.findall(r"echo ['\"]?---([A-Za-z0-9_.:-]+)---['\"]?", cmd)
    if markers:
        out = []
        for tag in markers:
            out.append(f"---{tag}---")
            if tag == "END":
                continue
            if tag.endswith(":EVIDENCE"):
                out.append("# canned evidence (demo sandbox)")
                continue
            if tag in _SSH_MARKER_BODIES:
                out.append(_SSH_MARKER_BODIES[tag])
            else:
                out.append(_hardening_status(tag))
        return "\n".join(out) + "\n"

    if "/proc/net/dev" in cmd:
        return _PROC_NET_DEV
    if "/proc/stat" in cmd:
        return _proc_stat()
    if "os-release" in cmd:
        return _SSH_MARKER_BODIES["OS"] + '\nNAME="Debian GNU/Linux"\nID=debian\n'
    if re.search(r"\brbd\b", cmd):
        return "[]"
    if re.search(r"\bceph\b", cmd):
        return "[]"
    if "pveversion" in cmd:
        return _SSH_MARKER_BODIES["PVE"]
    if re.search(r"\buname\b", cmd):
        return "Linux pve 6.8.12-1-pve #1 SMP PREEMPT_DYNAMIC" if "-a" in cmd else "6.8.12-1-pve"
    if re.search(r"\bapt-get\b.*-s\b|\bapt-get\b.*dist-upgrade", cmd):
        return _SSH_MARKER_BODIES["UPDATES"]
    if re.search(r"\bdate\b", cmd):
        return time.strftime("%a %b %d %H:%M:%S %Z %Y") + "\n"
    if re.search(r"\buptime\b", cmd):
        return " 12:34:56 up 23 days,  4:17,  1 user,  load average: 0.42, 0.38, 0.35\n"
    if re.search(r"\bhostname\b", cmd):
        return "pve\n"
    if re.search(r"\bdf\b", cmd):
        return (
            "Filesystem                 Size  Used Avail Use% Mounted on\n"
            "/dev/mapper/pve-root        96G   41G   51G  45% /\n"
            "rpool/ROOT/pve-1           96G   41G   51G  45% /\n"
        )
    if re.search(r"\bfree\b", cmd):
        return (
            "               total        used        free      shared  buff/cache   available\n"
            "Mem:       131768432    84920123    18273645     1234567    28574664    45291837\n"
            "Swap:        8388604           0     8388604\n"
        )
    if re.search(r"\b(systemctl|service)\b.*\b(is-active|is-enabled|status)\b", cmd):
        return "active" if "is-active" in cmd else ("enabled" if "is-enabled" in cmd else "active")
    # Bare `echo X` probes (reachability checks like `echo OK`) — echo back.
    m = re.fullmatch(r"\s*echo\s+(['\"]?)(.*?)\1\s*", cmd)
    if m:
        return m.group(2) + "\n"
    # Unknown reads produce empty stdout at exit 0 — callers' "no output"
    # paths render an empty state rather than an SSH error.
    return ""


class _FakeChannel:
    """paramiko Channel stand-in — exit status is captured per command."""

    def __init__(self, exit_status: int = 0):
        self._exit_status = exit_status

    def recv_exit_status(self):
        return self._exit_status

    def exit_status_ready(self):
        return True

    def recv_ready(self):
        return True

    def send(self, data):  # noqa: ARG002 — interactive shells swallow input
        return len(data) if isinstance(data, (bytes, str)) else 0

    def sendall(self, data):  # noqa: ARG002
        pass

    def recv(self, _n):
        return b""

    def recv_stderr(self, _n):
        return b""

    def exec_command(self, command):  # noqa: ARG002
        # Transport-level exec (e.g. `shutdown -r now` in _reboot_node) —
        # accept and forget; output drains as empty reads.
        pass

    def invoke_shell(self):  # noqa: ARG002 — interactive console opens empty
        pass

    def settimeout(self, _t):
        pass

    def makefile(self, *a, **kw):  # noqa: ARG002
        return _FakeStream(b"", self)

    def makefile_stderr(self, *a, **kw):  # noqa: ARG002
        return _FakeStream(b"", self)

    def makefile_stdin(self, *a, **kw):  # noqa: ARG002
        return _FakeStream(b"", self)

    def shutdown(self, _how):
        pass

    def close(self):
        pass


class _FakeStream:
    """paramiko ChannelFile stand-in. Mirrors real semantics: read() always
    returns BYTES (paramiko ignores the 'b' flag — "SSH treats all files as
    binary"), while readline()/iteration in text mode return STR and ""
    at EOF. Returning b"" there loops forever under
    `iter(stdout.readline, "")` (e.g. manager._ssh_execute)."""

    def __init__(self, data: bytes = b"", channel: _FakeChannel | None = None):
        import io

        self._buf = io.BytesIO(data)
        self.channel = channel or _FakeChannel()

    def read(self, *a):
        return self._buf.read(*a)

    def readline(self, *a):
        line = self._buf.readline(*a)
        return line.decode("utf-8", errors="replace") if line else ""

    def readlines(self, *a):
        return [
            ln.decode("utf-8", errors="replace")
            for ln in self._buf.readlines(*a)
        ]

    def __iter__(self):
        for ln in self._buf.getvalue().splitlines(keepends=True):
            yield ln.decode("utf-8", errors="replace")

    def write(self, data):
        return len(data)

    def flush(self):
        pass

    def close(self):
        pass


class _FakeSFTPFile:
    def __init__(self, data: bytes = b""):
        import io

        self._buf = io.BytesIO(data)

    def read(self, *a):
        return self._buf.read(*a)

    def write(self, b):
        return len(b)

    def close(self):
        pass

    def __enter__(self):
        return self

    def __exit__(self, *a):
        return False


class _FakeSFTP:
    """Empty filesystem — file reads return empty content, writes no-op."""

    def open(self, path, mode="r"):  # noqa: ARG002
        return _FakeSFTPFile()

    def file(self, path, mode="r"):  # noqa: ARG002
        return _FakeSFTPFile()

    def remove(self, path):  # noqa: ARG002
        return None

    def mkdir(self, path, mode=0o755):  # noqa: ARG002
        return None

    def listdir(self, path="."):  # noqa: ARG002
        return []

    def stat(self, path):
        raise FileNotFoundError(path)

    def close(self):
        pass


class _FakeTransport:
    def is_active(self):
        return True

    def open_session(self):
        return _FakeChannel()


class _FakeSSHClient:
    """paramiko.SSHClient stand-in for synthetic demo nodes. exec_command
    runs the canned-output matcher; SFTP/file APIs are inert."""

    def exec_command(self, command, timeout=None, **kwargs):  # noqa: ARG002
        out = _demo_ssh_output(command)
        # rbd EINVAL(22) = "mirroring not enabled" — the callers' designed
        # empty-state path (see _rbd_cmd), better than parsing fake data.
        exit_status = 22 if re.search(r"\brbd\b", command or "") else 0
        return (
            _FakeStream(),
            _FakeStream(out.encode(), _FakeChannel(exit_status)),
            _FakeStream(),
        )

    def open_sftp(self):
        return _FakeSFTP()

    def get_transport(self):
        return _FakeTransport()

    def invoke_shell(self, *a, **kw):
        return _FakeChannel()

    def set_missing_host_key_policy(self, *a, **kw):
        pass

    def connect(self, *a, **kw):
        pass

    def close(self):
        pass


# Handles to the pre-patch originals — populated by install_demo_cluster_mock()
# and only called through the patched code paths, so they are typed Any to
# keep static checkers from flagging the None-initialised call sites.
_ORIG_CREATE_SESSION: Any = None
_ORIG_RESOLVE_HOST: Any = None
_ORIG_SESSION_REQUEST: Any = None
_ORIG_GET_NODE_IP: Any = None
_ORIG_SSH_CONNECT: Any = None
_ORIG_NODE_SSH_EXEC: Any = None
_ORIG_INIT: Any = None
_ORIG_GET_FINGERPRINT: Any = None
_ORIG_SSH_RUNNERS: dict[str, Any] = {}
# paramiko-level originals — several api modules (node_mgmt, console,
# storage deep-scan) build paramiko.SSHClient() directly instead of going
# through manager._ssh_connect, so the demo patch has to live on the class.
_ORIG_PSSH: dict[str, Any] = {}


def _is_demo_ssh_target(host) -> bool:
    """True when *host* is a synthetic demo node/cluster (dataset hostname,
    node name, or an IP inside a demo cluster subnet)."""
    if not host:
        return False
    h = str(host)
    if h in _DATASETS:
        return True
    for ds in _DATASETS.values():
        if h.startswith(ds.ip_subnet + "."):
            return True
        for n in ds.nodes:
            if n.get("node") == h:
                return True
    return False


def _demo_migration_log(ds: _Dataset):
    """Recorded migration log entries (anchored to now) for the manager's
    in-memory ``last_migration_log``, which backs /api/clusters/<id>/migrations.
    """
    from datetime import datetime

    out = []
    for m in ds.inv.get("migration_log", []):
        out.append(
            {
                "timestamp": datetime.fromtimestamp(time.time() - m.get("age_seconds", 0)).isoformat(),
                "vm": m["vm"],
                "vmid": m["vmid"],
                "from_node": m["from_node"],
                "to_node": m["to_node"],
                "success": m.get("success", True),
                "dry_run": m.get("dry_run", False),
                "reason": m.get("reason", ""),
            }
        )
    return out


# Synthetic *.demo.lab hostnames used by the demo integration configs —
# each maps to a handler that serves fixture data from integrations.json.
_INTEGRATION_HOSTS = {
    "pbs.demo.lab": "pbs",
    "vcenter.demo.lab": "vcenter",
    "zabbix.demo.lab": "zabbix",
    "opnsense.demo.lab": "opnsense",
    "pfsense.demo.lab": "pfsense",
    "vyos.demo.lab": "vyos",
    "netapp.demo.lab": "netapp",
    "portainer.demo.lab": "portainer",
    "rancher.demo.lab": "rancher",
    "rockstor.demo.lab": "rockstor",
}


def _integ(name: str) -> dict:
    """Return a section of integrations.json."""
    return _fixture_file("integrations.json").get(name, {})


def _route_integration(key, method, url, **kwargs):
    """Serve a non-PVE integration API from fixtures/demo/integrations.json.

    These vendors return raw JSON (no PVE ``{"data": ...}`` wrapper), so
    handlers emit _FakeResponse payloads directly.
    """
    try:
        parsed = urlparse(url)
        path = parsed.path or "/"
        query = parse_qs(parsed.query)
    except Exception:
        return _FakeResponse({})
    body = kwargs.get("json") or kwargs.get("data") or {}
    if isinstance(body, str):
        try:
            body = json.loads(body)
        except Exception:
            body = {}
    method = str(method).upper()

    if key == "pbs":
        for prefix in ("/api2/json", "/api2/extjs"):
            if path.startswith(prefix):
                path = path[len(prefix):]
                break
        return _route_pbs(method, path, query)

    if key == "zabbix":
        result = _integ("zabbix").get((body or {}).get("method", ""))
        return _FakeResponse({"jsonrpc": "2.0", "result": result, "id": (body or {}).get("id", 1)})

    if key == "opnsense":
        if method in ("POST", "PUT", "DELETE"):
            return _FakeResponse({"status": "ok"})
        fx = _integ("opnsense")
        return _FakeResponse(fx.get(path.split("?")[0], {"rows": [], "rowCount": 0, "total": 0, "current": 1}))

    if key == "pfsense":
        action = query.get("action", [""])[0]
        return _FakeResponse(_integ("pfsense").get(action, {"callid": "demo", "action": action, "message": "ok", "data": {}}))

    if key == "vyos":
        op = (body or {}).get("op", "")
        vpath = ",".join((body or {}).get("path", []) or [])
        data = _integ("vyos").get(f"{op}:{vpath}")
        return _FakeResponse({"success": data is not None, "data": data})

    if key == "vcenter":
        return _route_vcenter(method, path, query, body)

    if key == "netapp":
        if method in ("POST", "PATCH", "DELETE"):
            return _FakeResponse({})
        return _FakeResponse(_integ("netapp").get(path, {"records": [], "num_records": 0}))

    if key == "portainer":
        if method in ("POST", "PUT", "PATCH", "DELETE"):
            return _FakeResponse({"status": "ok"})
        # Portainer CE answers bare arrays on list endpoints.
        return _FakeResponse(_integ("portainer").get(path, []))

    if key == "rancher":
        if method in ("POST", "PUT", "PATCH", "DELETE"):
            return _FakeResponse({"status": "ok"})
        # Rancher v3 answers {"data": [...]} collections.
        return _FakeResponse(_integ("rancher").get(path, {"data": []}))

    if key == "rockstor":
        if method in ("POST", "PUT", "PATCH", "DELETE"):
            return _FakeResponse({"status": "ok"})
        # Rockstor REST answers record lists.
        return _FakeResponse(_integ("rockstor").get(path, []))

    return _FakeResponse({})


def _route_vcenter(method, path, query, body):
    """vSphere REST API fixture surface (app-level + validation parity)."""
    fx = _integ("vcenter")
    if method == "POST":
        if path.endswith("/session") or path.endswith("/cis/session"):
            return _FakeResponse("demo-session", status_code=201)
        return _FakeResponse({}, status_code=201)
    if path.rstrip("/") in ("", "/"):
        return _FakeResponse({})
    if path.endswith("/appliance/system/version") or path.endswith("/system/config/version"):
        return _FakeResponse(fx.get("version", {}))
    if path.endswith("/appliance/health/system"):
        return _FakeResponse("green")
    if path.startswith("/api/appliance/health/"):
        return _FakeResponse("green")
    m = re.match(r"/api/vcenter/vm/([^/?]+)", path)
    if m:
        vm_id = m.group(1)
        if path.endswith("/guest/identity"):
            return _FakeResponse(fx.get("guest_identity", {}))
        vm = next((v for v in fx.get("vms", []) if v["vm"] == vm_id), None)
        if vm is None:
            return _FakeResponse({"error_type": "NOT_FOUND", "messages": []}, status_code=404)
        return _FakeResponse(dict(vm, guest_OS="Microsoft Windows Server 2022 (64-bit)" if vm["name"].startswith("win") else "Debian GNU/Linux 12 (64-bit)"))
    if path.rstrip("/").endswith("/vcenter/vm"):
        return _FakeResponse(fx.get("vms", []))
    for suffix, key in (
        ("/vcenter/host", "hosts"), ("/vcenter/datastore", "datastores"),
        ("/vcenter/network", "networks"), ("/vcenter/cluster", "clusters"),
        ("/vcenter/datacenter", "datacenters"), ("/vcenter/resource-pool", "resource_pools"),
        ("/vcenter/folder", "folders"), ("/vcenter/storage/policies", "storage_policies"),
        ("/content/library", "content_libraries"),
        ("/cis/tagging/category", "tag_categories"), ("/cis/tagging/tag", "tags"),
    ):
        if path.rstrip("/").endswith(suffix):
            return _FakeResponse(fx.get(key, []))
    return _FakeResponse([])


def _demo_request(self, method, url, params=None, data=None, **kwargs):
    """Global requests.Session.request hook that intercepts demo-cluster URLs.

    ``connect_to_proxmox`` creates raw ``requests.Session`` objects, so
    patching ``ProxmoxVExManager._create_session`` alone is not enough.
    This class-level hook catches *any* outgoing request to the demo host and
    returns a synthetic response before any network call is attempted.
    """
    # params/data are declared explicitly so positional callers
    # (session.request("GET", url, p, d)) bind the same way real requests does
    # instead of leaking a stray positional into _dispatch.
    try:
        parsed = urlparse(url)
        host = parsed.hostname or ""
    except Exception:
        host = ""
    if host in _DATASETS:
        return _dispatch(method, url, params=params, data=data, **kwargs)
    integ = _INTEGRATION_HOSTS.get(host)
    if integ:
        return _route_integration(integ, method, url, params=params, data=data, **kwargs)
    return _ORIG_SESSION_REQUEST(self, method, url, params=params, data=data, **kwargs)


def install_demo_cluster_mock():
    """Monkey-patch the manager and requests to use fake data for demo clusters."""
    global _ORIG_CREATE_SESSION, _ORIG_RESOLVE_HOST, _ORIG_SESSION_REQUEST
    global _ORIG_GET_NODE_IP, _ORIG_SSH_CONNECT, _ORIG_NODE_SSH_EXEC, _ORIG_INIT
    global _ORIG_SSH_RUNNERS, _ORIG_GET_FINGERPRINT
    if _ORIG_SESSION_REQUEST is not None:
        return

    from ProxmoxVEx.core.manager import ProxmoxVExManager

    _ORIG_CREATE_SESSION = ProxmoxVExManager._create_session
    _ORIG_RESOLVE_HOST = ProxmoxVExManager._resolve_host
    _ORIG_SESSION_REQUEST = requests.Session.request
    _ORIG_GET_NODE_IP = ProxmoxVExManager._get_node_ip
    _ORIG_SSH_CONNECT = ProxmoxVExManager._ssh_connect
    _ORIG_NODE_SSH_EXEC = ProxmoxVExManager._node_ssh_exec
    _ORIG_INIT = ProxmoxVExManager.__init__
    _ORIG_GET_FINGERPRINT = ProxmoxVExManager.get_cluster_fingerprint

    def _is_demo(self):
        return getattr(getattr(self, "config", None), "host", None) in _DATASETS

    def _init(self, *args, **kwargs):
        _ORIG_INIT(self, *args, **kwargs)
        if _is_demo(self):
            # Populate the in-memory migration log that backs
            # /api/clusters/<id>/migrations so the Migrations view has data.
            self.last_migration_log = _demo_migration_log(_dataset_for_host(self.config.host))

    def _create_session(self):
        if _is_demo(self):
            if not getattr(self, "_demo_session", None):
                self._demo_session = _FakeSession()
                self._demo_session.verify = False
                self._demo_session.trust_env = False
            return self._demo_session
        return _ORIG_CREATE_SESSION(self)

    @staticmethod
    def _resolve_host(hostname):
        if hostname in _DATASETS:
            return hostname
        return _ORIG_RESOLVE_HOST(hostname)

    def _get_node_ip(self, node_name):
        # Return the recorded IP directly — never TCP-probe synthetic
        # 10.x.1.x addresses (each probe burns the full timeout).
        if _is_demo(self):
            ds = _dataset_for_host(self.config.host)
            for i, n in enumerate(ds.nodes):
                if n["node"] == node_name:
                    return f"{ds.ip_subnet}.{11 + i}"
            return None
        return _ORIG_GET_NODE_IP(self, node_name)

    def _ssh_connect(self, host, *args, **kwargs):
        # No real SSH to synthetic demo hosts — return an inert client so
        # exec_command callers (ceph rbd, node file reads) get canned
        # output instead of a connect failure.
        if _is_demo(self):
            return _FakeSSHClient()
        return _ORIG_SSH_CONNECT(self, host, *args, **kwargs)

    def _node_ssh_exec(self, node, command, *args, **kwargs):
        if _is_demo(self):
            return 0, _demo_ssh_output(command), ""
        return _ORIG_NODE_SSH_EXEC(self, node, command, *args, **kwargs)

    # HA code paths run raw `ssh` subprocesses via these helpers — the fixture
    # IPs (10.10.1.x) don't exist, so each call would burn ConnectTimeout.
    _SSH_RUNNER_NAMES = (
        "_ssh_run_command_output",
        "_ssh_run_command_with_key_output",
        "_ssh_run_command_with_password_output",
        "_ssh_run_command",
        "_ssh_run_command_with_key",
        "_ssh_run_command_with_password",
    )

    def _make_runner_stub(name):
        def _stub(self, *args, **kwargs):
            if _is_demo(self):
                if name.endswith("_output"):
                    # *_output runners take (host/ip, user, cmd, …) — cmd is
                    # always args[2]; serve canned output for reads.
                    cmd = args[2] if len(args) > 2 else ""
                    return _demo_ssh_output(cmd)
                # boolean runners = "command ran OK" — read-path probes see a
                # healthy node instead of a connection failure.
                return True
            return _ORIG_SSH_RUNNERS[name](self, *args, **kwargs)

        return _stub

    def _demo_get_cluster_fingerprint(self):
        # TLS to the synthetic host can't resolve — serve the fixture
        # fingerprint the node inventory already advertises.
        if _is_demo(self):
            ds = _dataset_for_host(self.config.host)
            fp = (ds.nodes[0].get("ssl_fingerprint") if ds.nodes else None) or "AA:BB:CC:DD:EE:FF:00:11:22:33:44:55:66:77:88:99:AA:BB:CC:DD:EE:FF:00:11:22:33:44:55:66:77:88"
            return {"success": True, "fingerprint": fp, "host": self.config.host, "port": 8006}
        return _ORIG_GET_FINGERPRINT(self)

    ProxmoxVExManager.__init__ = _init
    ProxmoxVExManager._create_session = _create_session
    ProxmoxVExManager._resolve_host = _resolve_host
    ProxmoxVExManager._get_node_ip = _get_node_ip
    ProxmoxVExManager._ssh_connect = _ssh_connect
    ProxmoxVExManager._node_ssh_exec = _node_ssh_exec
    ProxmoxVExManager.get_cluster_fingerprint = _demo_get_cluster_fingerprint
    for _name in _SSH_RUNNER_NAMES:
        _orig = getattr(ProxmoxVExManager, _name, None)
        if _orig is not None:
            _ORIG_SSH_RUNNERS[_name] = _orig
            setattr(ProxmoxVExManager, _name, _make_runner_stub(_name))

    # Direct paramiko.SSHClient() call sites (node_mgmt, console proxy,
    # storage deep-scan, utils.ssh pooled exec) bypass the manager helpers —
    # mark instances that connect to synthetic demo hosts and serve them the
    # canned client. Real clusters keep the untouched originals.
    try:
        import paramiko as _paramiko

        for _m in ("connect", "exec_command", "open_sftp", "get_transport", "invoke_shell"):
            _ORIG_PSSH[_m] = getattr(_paramiko.SSHClient, _m, None)

        def _pssh_connect(self, hostname, *a, **kw):
            if _is_demo_ssh_target(hostname):
                self._proxmoxvex_demo = True
                return None
            return _ORIG_PSSH["connect"](self, hostname, *a, **kw)

        def _pssh_exec(self, command, *a, **kw):
            if getattr(self, "_proxmoxvex_demo", False):
                out = _demo_ssh_output(command)
                return (
                    _FakeStream(),
                    _FakeStream(out.encode(), _FakeChannel(0)),
                    _FakeStream(),
                )
            return _ORIG_PSSH["exec_command"](self, command, *a, **kw)

        def _pssh_sftp(self):
            if getattr(self, "_proxmoxvex_demo", False):
                return _FakeSFTP()
            return _ORIG_PSSH["open_sftp"](self)

        def _pssh_transport(self):
            if getattr(self, "_proxmoxvex_demo", False):
                return _FakeTransport()
            return _ORIG_PSSH["get_transport"](self)

        def _pssh_shell(self, *a, **kw):
            if getattr(self, "_proxmoxvex_demo", False):
                return _FakeChannel()
            return _ORIG_PSSH["invoke_shell"](self, *a, **kw)

        _paramiko.SSHClient.connect = _pssh_connect
        _paramiko.SSHClient.exec_command = _pssh_exec
        _paramiko.SSHClient.open_sftp = _pssh_sftp
        _paramiko.SSHClient.get_transport = _pssh_transport
        _paramiko.SSHClient.invoke_shell = _pssh_shell
    except Exception as exc:  # paramiko absent → manager-level stubs still apply
        logging.warning(f"[DEMO_MOCK] paramiko patch skipped: {exc}")

    # Intentional monkeypatch of the transport entry point for demo clusters;
    # the ignore silences the method-assignment complaint from the checkers.
    requests.Session.request = _demo_request  # type: ignore[method-assign]
    logging.info("[DEMO_MOCK] Installed ProxmoxVExManager + requests mock for demo clusters")
