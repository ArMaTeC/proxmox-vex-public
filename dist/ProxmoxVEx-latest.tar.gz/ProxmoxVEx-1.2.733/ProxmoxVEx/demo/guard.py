# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/demo/guard.py
# Project:     ProxmoxVEx
# Version:     1.2.662
# Build:       2026.10.21
# Description: Demo sandbox guard.
# Usage:       import ProxmoxVEx.demo.guard
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-10-21
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Demo sandbox guard.

When demo mode is active this guard blocks all mutating API calls except
a small allow-list (login, health, demo token exchange).  It runs at the
Flask ``before_request`` stage so it catches every route uniformly.
"""

import fnmatch
import logging

from ProxmoxVEx.demo import is_demo_mode

MUTATING_METHODS = {"POST", "PUT", "PATCH", "DELETE"}

# Explicitly allowed routes when demo mode is enabled.  Everything else
# under /api/* with a mutating verb is rejected with a clear message.
# /api/sse/token only mints a read-only realtime token and /api/user/preferences
# stores harmless UI state — blocking them made the demo UI retry in a loop.
# /api/sse/subscribe only adjusts the in-memory cluster filter of an existing
# SSE client; blocking it 403-toasted demo visitors on every sidebar toggle.
# /api/ws/token is the same class of session-scoped mint as /api/sse/token —
# blocking it meant demo consoles could never authenticate their WebSocket
# (the VNC path has no session= fallback), so every console died on connect.
_ALLOWED_DEMO_ROUTES = {
    "/api/auth/login",
    "/api/auth/logout",
    "/api/auth/check",
    "/api/demo/token",
    "/api/demo/login",
    "/api/health",
    "/api/sse/token",
    "/api/sse/subscribe",
    "/api/user/preferences",
    "/api/ws/token",
}

# Read-only (GET) routes that still exfiltrate host file contents or produce
# downloadable artifacts. The mutating-method check cannot see these, so they
# are denied explicitly: demo visitors may browse directory listings but must
# not be able to open, download, or export files off the host.
_BLOCKED_DEMO_READ_ROUTES = {
    "/api/plugins/disk-usage-explorer/api/content",
    "/api/plugins/disk-usage-explorer/api/download",
    "/api/plugins/disk-usage-explorer/api/export",
    # Spec 144 guard parity — GET routes flagged in the coverage matrix as
    # file-egress/exec surfaces (export/download/content/exec*/file/debug/
    # raw/dump/tail path segments). Read in name only: each downloads a
    # file, dumps host data, or triggers work, so they get the same 403
    # demo_forbidden shape as mutating methods. `*/detail` and
    # `*/profiles` matches were reviewed and excluded (regex false
    # positives — legit read views served by demo fixtures).
    "/api/plugins/ansible-runner/api/playbook-content",
    "/api/plugins/audit-search-enhanced/api/export",
    "/api/plugins/capacity-forecast/api/scenario/export",
    "/api/plugins/cost-chargeback/api/invoice-export",
    "/api/plugins/dns-sync/api/export",
    "/api/plugins/docker-swarm/api/export",
    "/api/plugins/ids/api/export",
    "/api/plugins/incident-timeline/api/export",
    "/api/plugins/lxc-template-marketplace/api/export",
    "/api/plugins/netapp-storage/api/export",
    "/api/plugins/opnsense/api/export",
    "/api/plugins/sdn-controller/api/export",
    "/api/plugins/storage-rebalancer/api/bulk-execute",
    "/api/plugins/storage-rebalancer/api/execute",
    "/api/plugins/syslog-forwarder/api/config/export",
    "/api/plugins/tape-library-manager/api/tapes/export",
    "/api/plugins/tenant-isolation/api/export",
    "/api/plugins/terraform-sync/api/export",
    "/api/plugins/terraform-sync/api/export/preview",
    "/api/plugins/terraform-sync/api/exports",
    "/api/plugins/terraform-sync/api/exports/compare",
    "/api/plugins/terraform-sync/api/exports/delete",
    "/api/plugins/terraform-sync/api/exports/download",
    "/api/plugins/terraform-sync/api/exports/re-export",
    "/api/plugins/truenas/api/export",
    "/api/plugins/vlan-provisioner/api/vlans/export",
    "/api/plugins/vm-bulk-deployer/api/jobs/export",
    "/api/plugins/vm-hibernate-scheduler/api/execute",
    "/api/plugins/vm-hibernate-scheduler/api/export",
    "/api/plugins/vm-migration-planner/api/execute",
    "/api/plugins/vm-migration-planner/api/export",
    "/api/plugins/vm-resource-quotas/api/export",
    "/api/plugins/vm-rightsizing/api/export",
    "/api/plugins/vm-tag-enforcer/api/export",
    "/api/plugins/vm-template-marketplace/api/export",
    "/api/plugins/vpn-access-portal/api/download",
    "/api/truenas/writes/execute",
    "/api/netapp_storage/settings/export",
    "/api/netapp_storage/snapmirror/ensure-export",
}

# Spec 145: unambiguous GET families blocked by prefix. The support
# ticket proxy forwards the stored licence key (X-License-Key) to the
# real support service — including attachment streaming — so every route
# under it is both external egress and key exposure in demo.
_BLOCKED_DEMO_READ_PREFIXES = (
    "/api/v1/support/tickets",
)


def is_demo_guarded(method: str, path: str) -> bool:
    """Return True if the request should be blocked in demo mode."""
    if not is_demo_mode():
        return False
    if method == "OPTIONS":
        return False
    if not path.startswith("/api/"):
        return False
    if path in _BLOCKED_DEMO_READ_ROUTES:
        return True
    if any(path == p or path.startswith(p + "/")
           for p in _BLOCKED_DEMO_READ_PREFIXES):
        return True
    if method not in MUTATING_METHODS:
        return False
    return all(
        not (path == allowed or fnmatch.fnmatch(path, allowed + "*"))
        for allowed in _ALLOWED_DEMO_ROUTES
    )


def demo_guard_response(path: str):
    """Return a 403 response explaining that the action is disabled."""
    logging.warning(f"[DEMO_GUARD] Blocked {path} in demo mode")
    from flask import jsonify, make_response

    return make_response(
        jsonify(
            {
                "error": "demo_forbidden",
                "message": "This action is disabled in the demo sandbox.",
            }
        ),
        403,
    )
