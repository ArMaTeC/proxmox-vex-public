# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/integrations/__init__.py
# Project:     ProxmoxVEx
# Version:     1.2.662
# Build:       2026.10.21
# Description: ProxmoxVEx Integrations package.
# Usage:       import ProxmoxVEx.integrations
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-10-21
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""ProxmoxVEx Integrations package."""

# Spec 092/US057: re-export the shared retry helper so non-native integration
# code uses the same backoff policy as ProxmoxVEx.native clients.
from ProxmoxVEx.native import TransientError, with_retry

__all__ = ["TransientError", "with_retry", "integration_blueprints"]


def integration_blueprints():
    """(name, blueprint) list for every vendor integration (ID-0007).

    Moved out of api/__init__ so the api package no longer hard-imports
    ~30 vendor modules; registration order among these is irrelevant —
    every integration serves a distinct path prefix. Imports stay inside
    the function to preserve the old lazy-import cold-start behavior.
    """
    from ProxmoxVEx.integrations.active_directory import bp as active_directory_bp
    from ProxmoxVEx.integrations.api_tokens import bp as api_tokens_bp
    from ProxmoxVEx.integrations.authentik import bp as authentik_bp

    # Specs 018-034: vendor integration blueprints (connector + read surfaces).
    from ProxmoxVEx.integrations.ceph_external import bp as ceph_external_bp
    from ProxmoxVEx.integrations.cisco import bp as cisco_bp
    from ProxmoxVEx.integrations.docker import bp as docker_bp
    from ProxmoxVEx.integrations.eos import bp as eos_bp
    from ProxmoxVEx.integrations.freeipa import bp as freeipa_bp
    from ProxmoxVEx.integrations.git import bp as git_bp
    from ProxmoxVEx.integrations.grafana import bp as grafana_bp
    from ProxmoxVEx.integrations.junos import bp as junos_bp
    from ProxmoxVEx.integrations.keycloak import bp as keycloak_bp
    from ProxmoxVEx.integrations.kubernetes import bp as kubernetes_bp
    from ProxmoxVEx.integrations.ldap import bp as ldap_integration_bp

    # Spec 016: the NetBox blueprint existed but was never registered, so its
    # /api/clusters/<id>/netbox/* endpoints 404'd despite tests covering the module.
    from ProxmoxVEx.integrations.netbox import bp as netbox_bp

    # Spec 032: OpenLDAP profile surface (posixAccount/inetOrgPerson presets,
    # ppolicy, replication, directory browser) alongside generic ldap auth.
    from ProxmoxVEx.integrations.openldap import bp as openldap_bp
    from ProxmoxVEx.integrations.packer import bp as packer_bp
    from ProxmoxVEx.integrations.pbs import bp as pbs_integration_bp
    from ProxmoxVEx.integrations.phpipam import bp as phpipam_bp
    from ProxmoxVEx.integrations.prometheus import bp as prometheus_bp
    from ProxmoxVEx.integrations.routeros import bp as routeros_bp
    from ProxmoxVEx.integrations.s3 import bp as s3_bp
    from ProxmoxVEx.integrations.synology import bp as synology_bp
    from ProxmoxVEx.integrations.tailscale import bp as tailscale_bp
    from ProxmoxVEx.integrations.terraform import bp as terraform_bp
    from ProxmoxVEx.integrations.uptimekuma import bp as uptimekuma_bp
    from ProxmoxVEx.integrations.vault import bp as vault_bp
    from ProxmoxVEx.integrations.victoriametrics import bp as victoriametrics_bp
    from ProxmoxVEx.integrations.vmware import bp as vmware_integration_bp
    from ProxmoxVEx.integrations.webhooks import bp as webhooks_bp
    from ProxmoxVEx.integrations.wireguard import bp as wireguard_integration_bp

    return [
        ("terraform", terraform_bp),
        ("vmware_integration", vmware_integration_bp),
        ("active_directory", active_directory_bp),
        ("kubernetes", kubernetes_bp),
        ("packer", packer_bp),
        ("prometheus", prometheus_bp),
        ("phpipam", phpipam_bp),
        ("netbox", netbox_bp),
        ("openldap", openldap_bp),
        ("ceph_external", ceph_external_bp),
        ("synology", synology_bp),
        ("routeros", routeros_bp),
        ("cisco", cisco_bp),
        ("eos", eos_bp),
        ("junos", junos_bp),
        ("tailscale", tailscale_bp),
        ("wireguard_integration", wireguard_integration_bp),
        ("victoriametrics", victoriametrics_bp),
        ("uptimekuma", uptimekuma_bp),
        ("freeipa", freeipa_bp),
        ("authentik", authentik_bp),
        ("keycloak", keycloak_bp),
        ("pbs_integration", pbs_integration_bp),
        ("grafana", grafana_bp),
        ("ldap", ldap_integration_bp),
        ("s3", s3_bp),
        ("docker", docker_bp),
        ("git", git_bp),
        ("vault", vault_bp),
        ("api_tokens", api_tokens_bp),
        ("webhooks", webhooks_bp),
    ]
