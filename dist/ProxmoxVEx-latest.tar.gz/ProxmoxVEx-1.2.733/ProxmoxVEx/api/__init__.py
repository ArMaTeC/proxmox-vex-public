# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/api/__init__.py
# Project:     ProxmoxVEx
# Version:     1.2.662
# Build:       2026.10.21
# Description: ProxmoxVEx API Blueprint Registration
# Usage:       import ProxmoxVEx.api
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-10-21
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""
ProxmoxVEx API Blueprint Registration
"""

import contextlib
import logging

from flask import jsonify, request

from ProxmoxVEx.utils.auth import validate_api_token, validate_session

# The force-MFA gate lives in utils/mfa_gate.py (ID-0006) — re-exported
# under its historical name so callers and tests keep working.
from ProxmoxVEx.utils.mfa_gate import mfa_enrollment_block as _mfa_enrollment_block

# (spec 092/US042) - endpoint-specific deprecations: route-rule ->
# (sunset HTTP-date, successor path). Consulted by the _deprecate_v1
# after_request hook in app.py BEFORE the blanket v1->v2 rule, so a route
# can name its real successor instead of the mechanical v2 mirror.
DEPRECATED_ROUTES = {
    # the legacy flat audit list is superseded by /api/audit/search (filters,
    # facets, integrity flags); kept for compat until the sunset date.
    "/api/audit": ("Sat, 01 Jan 2028 00:00:00 GMT", "/api/audit/search"),
}


def register_blueprints(app):
    """Register all API blueprints with the Flask app."""
    from ProxmoxVEx.api.alerts import bp as alerts_bp

    # spec 128 (ux-parity-pack): per-user layouts, tracked upload/asset
    # library, in-app API reference feed.
    from ProxmoxVEx.api.api_reference import bp as api_reference_bp
    from ProxmoxVEx.api.assets import bp as assets_bp
    from ProxmoxVEx.api.audit_search import bp as audit_search_bp
    from ProxmoxVEx.api.auth import bp as auth_bp
    from ProxmoxVEx.api.azure import bp as azure_bp
    from ProxmoxVEx.api.ceph import bp as ceph_bp
    from ProxmoxVEx.api.clusters import bp as clusters_bp
    from ProxmoxVEx.api.converter import bp as converter_bp
    from ProxmoxVEx.api.costs import bp as costs_bp
    from ProxmoxVEx.api.dashboards import bp as dashboards_bp
    from ProxmoxVEx.api.datacenter import bp as datacenter_bp
    from ProxmoxVEx.api.demo import bp as demo_bp
    from ProxmoxVEx.api.disaster_recovery import bp as disaster_recovery_bp
    from ProxmoxVEx.api.drift import bp as drift_bp
    from ProxmoxVEx.api.drift import start_scanner as start_drift_scanner
    from ProxmoxVEx.api.groups import bp as groups_bp
    from ProxmoxVEx.api.healthz import bp as healthz_bp
    from ProxmoxVEx.api.history import bp as history_bp
    from ProxmoxVEx.api.ids import bp as ids_bp
    from ProxmoxVEx.api.insights import bp as insights_bp
    from ProxmoxVEx.api.licence import bp as licence_bp
    from ProxmoxVEx.api.metrics_exporter import bp as metrics_exporter_bp
    from ProxmoxVEx.api.mirror import bp as mirror_bp
    from ProxmoxVEx.api.nodes import bp as nodes_bp
    from ProxmoxVEx.api.openapi_doc import bp as openapi_doc_bp
    from ProxmoxVEx.api.pbs import bp as pbs_bp
    from ProxmoxVEx.api.plugins import bp as plugins_bp
    from ProxmoxVEx.api.power import bp as power_bp
    from ProxmoxVEx.api.push import bp as push_bp
    from ProxmoxVEx.api.push import register_alert_handler
    from ProxmoxVEx.api.realtime import bp as realtime_bp
    from ProxmoxVEx.api.reports import bp as reports_bp
    from ProxmoxVEx.api.schedules import bp as schedules_bp
    from ProxmoxVEx.api.search import bp as search_bp
    from ProxmoxVEx.api.server_access import bp as server_access_bp
    from ProxmoxVEx.api.settings import bp as settings_bp
    from ProxmoxVEx.api.siem import bp as siem_bp
    from ProxmoxVEx.api.siem import start_worker as start_siem_worker
    from ProxmoxVEx.api.site_recovery import bp as site_recovery_bp
    from ProxmoxVEx.api.snapshots import bp as snapshots_bp
    from ProxmoxVEx.api.snapshots import start_scheduler as start_snap_scheduler
    from ProxmoxVEx.api.static_files import bp as static_files_bp
    from ProxmoxVEx.api.stepup import bp as stepup_bp
    from ProxmoxVEx.api.storage import bp as storage_bp
    from ProxmoxVEx.api.support import bp as support_bp
    from ProxmoxVEx.api.templates_lib import bp as templates_lib_bp
    from ProxmoxVEx.api.topology import bp as topology_bp
    from ProxmoxVEx.api.trash import bp as trash_bp
    from ProxmoxVEx.api.users import bp as users_bp
    from ProxmoxVEx.api.vms import bp as vms_bp
    from ProxmoxVEx.api.vmware import bp as vmware_bp
    from ProxmoxVEx.api.webauthn import bp as webauthn_bp
    from ProxmoxVEx.native.registry import bp as native_bp

    _blueprints = [
        ("auth", auth_bp),
        ("demo", demo_bp),
        ("users", users_bp),
        ("converter", converter_bp),
        ("clusters", clusters_bp),
        ("vms", vms_bp),
        ("nodes", nodes_bp),
        ("pbs", pbs_bp),
        ("storage", storage_bp),
        ("datacenter", datacenter_bp),
        ("vmware", vmware_bp),
        ("azure", azure_bp),
        ("schedules", schedules_bp),
        ("reports", reports_bp),
        ("settings", settings_bp),
        ("alerts", alerts_bp),
        ("realtime", realtime_bp),
        ("search", search_bp),
        ("server_access", server_access_bp),
        ("static_files", static_files_bp),
        ("stepup", stepup_bp),
        ("history", history_bp),
        ("ids", ids_bp),
        ("groups", groups_bp),
        ("ceph", ceph_bp),
        ("site_recovery", site_recovery_bp),
        # disaster-recovery routes live under /api/site-recovery/plans/<plan_id>/...
        # and must be registered before the native catch-all /api/<module_id>/<path:subpath>
        # to avoid being shadowed by the native proxy.
        ("disaster_recovery", disaster_recovery_bp),
        ("plugins", plugins_bp),
        ("native", native_bp),
        ("webauthn", webauthn_bp),
        ("metrics_exporter", metrics_exporter_bp),
        ("healthz", healthz_bp),
        ("openapi_doc", openapi_doc_bp),
        ("mirror", mirror_bp),
        ("insights", insights_bp),
        ("licence", licence_bp),
        ("support", support_bp),
        ("templates_lib", templates_lib_bp),
        ("push", push_bp),
        ("costs", costs_bp),
        ("drift", drift_bp),
        ("audit_search", audit_search_bp),
        ("siem", siem_bp),
        ("snapshots", snapshots_bp),
        ("topology", topology_bp),
        ("trash", trash_bp),
        ("power", power_bp),
        ("dashboards", dashboards_bp),
        ("assets", assets_bp),
        ("api_reference", api_reference_bp),
    ]

    # Vendor integration blueprints (ID-0007): registered via
    # integrations.integration_blueprints() so this package no longer
    # imports ~30 vendor modules. All share distinct path prefixes and
    # register after the native catch-all — append order is safe.
    from ProxmoxVEx.integrations import integration_blueprints
    _blueprints += integration_blueprints()

    # ISS-080: the previous blueprint-level whitelist meant ANY new route added
    # to a "public" blueprint was silently reachable without auth. The guard now
    # attaches to every blueprint, and only the explicitly listed paths
    # below bypass it — everything else under /api/ defaults to authenticated.
    #
    # SEC-007: the list is split into exact-match paths and real subtree
    # prefixes. Exact paths can never silently publish future children
    # (e.g. "/api/config" used to also exempt /api/config/backup|restore —
    # they were only safe because they self-guard with ROLE_ADMIN).
    _public_api_paths = frozenset({
        # health + login flow
        "/api/health",
        # deep health probe used by uptime monitors — was previously public
        # only by accident of the "/api/health" prefix swallowing the "z".
        "/api/healthz",
        # spec 092/US031: sanitized public status feed for external status
        # pages — up/down components + recent incident windows, no internals.
        "/api/status/public",
        "/api/auth/login",
        "/api/auth/setup",
        "/api/auth/check",
        "/api/auth/validate",
        "/api/auth/logout",
        # demo entry
        "/api/demo/token",
        "/api/demo/login",
        "/api/demo/auto-login",
        "/api/config",
        # WebAuthn login ceremony (registration/credentials self-guard)
        "/api/webauthn/available",
        # realtime: SSE/WS endpoints do their own token auth
        "/api/sse/updates",
        "/api/ws/updates",
        "/api/ws/token/validate",
        # metrics endpoint self-authenticates via Bearer token / metrics_public
        "/api/metrics",
        # mirror blueprint public docs/version endpoints
        "/api/version.json",
    })
    # True subtree prefixes only — each entry must end in "/" so the next
    # route added under it is a deliberate, reviewed public surface.
    _public_api_prefixes = (
        "/api/auth/oidc/",
        "/api/webauthn/auth/",
        "/api/trees/",
    )

    _guarded_bp_names = {name for name, _ in _blueprints}

    def _require_auth_for_request():
        """App-level before_request guard: require a valid session or API token."""
        # Only applies to routes owned by the API blueprints below — attaching at
        # app level (instead of bp.before_request) keeps the guard from leaking
        # into test apps that register a shared blueprint object directly.
        if request.blueprint not in _guarded_bp_names:
            return None
        # Non-API routes (/, /static, /favicon.ico, /app.bundle.js, etc.) are public SPA assets.
        if not request.path.startswith("/api/"):
            return None
        if request.path in _public_api_paths or request.path.startswith(
            _public_api_prefixes
        ):
            return None
        auth_header = request.headers.get("Authorization", "")
        session = None
        if auth_header.startswith("Bearer pgx_"):
            session = validate_api_token(auth_header[7:])
        if not session:
            session_id = request.headers.get("X-Session-ID") or request.cookies.get("session_id")
            session = validate_session(session_id)
        if not session:
            # (spec 092/US040) - standard error envelope; the legacy top-level
            # "code" is kept alongside for existing consumers.
            from ProxmoxVEx.api.helpers import api_error

            return api_error(401, "auth_required", "Unauthorized",
                             extra={"code": "AUTH_REQUIRED"})
        # setattr is deliberate (same as utils/auth.py): `session` isn't a
        # declared Request attribute, so plain assignment trips type checkers.
        setattr(request, "session", session)  # noqa: B010

        # Spec 038 (US1): force-MFA hard block — when `force_2fa` is on, a user
        # with no enrolled factor is confined to the enrollment endpoints.
        # Server-side enforcement; the frontend flag alone is bypassable.
        denied = _mfa_enrollment_block(session)
        if denied is not None:
            return denied

        # Spec 089: step-up registry — destroy-class routes challenge before
        # the view runs, so routes without an inline require_stepup() are
        # covered too. API tokens are exempt: automation can't answer a factor
        # prompt (tokens are scoped per #085 instead).
        if not session.get("api_token"):
            try:
                from ProxmoxVEx.utils.stepup import require_stepup, stepup_route_category

                category = stepup_route_category()
                if category:
                    denied = require_stepup(category)
                    if denied is not None:
                        return denied
            except Exception as e:
                # fail closed: a broken registry check must not silently let a
                # destructive call through
                logging.error(f"stepup registry check failed for {request.path}: {e}")
                return jsonify({"error": "Step-up check unavailable"}), 503

    for name, bp in _blueprints:
        # Pass an explicit registration name so blueprints whose internal name
        # clashes with a core API blueprint (e.g. vmware vs vmware_integration)
        # can still be mounted without a Flask "name already registered" error.
        app.register_blueprint(bp, name=name)

    if not getattr(app, "_ProxmoxVEx_auth_guard", False):
        app._ProxmoxVEx_auth_guard = True
        app.before_request(_require_auth_for_request)

    if not getattr(app, "_ProxmoxVEx_cache_invalidation", False):
        app._ProxmoxVEx_cache_invalidation = True

        @app.after_request
        def _invalidate_get_caches_on_mutation(response):
            # (spec 092/US003, FR-008) - a successful mutating call under
            # /api/clusters/<id>/… drops that cluster's cached GET responses
            # AND its bespoke data caches (vm_list_cache had an invalidate()
            # nothing ever called), so the next read sees post-mutation state.
            if (
                request.method not in ("GET", "HEAD", "OPTIONS")
                and request.path.startswith("/api/")
                and response.status_code < 400
            ):
                cid = (request.view_args or {}).get("cluster_id")
                if cid:
                    from ProxmoxVEx.core.cache import (
                        invalidate_response_cache,
                        vm_list_cache,
                    )

                    invalidate_response_cache(cid)
                    vm_list_cache.invalidate(cid)
            return response

    # Initialize WebSocket support for realtime blueprint
    from ProxmoxVEx.api.realtime import sock

    sock.init_app(app)

    # Wire push handler into the alerts pipeline
    with contextlib.suppress(Exception):
        register_alert_handler()

    # Drift scanner thread (6h cadence; harmless if mgrs not yet up)
    try:
        start_drift_scanner()
    except Exception as e:
        logging.warning(f"drift scanner start failed: {e}")

    # SIEM forwarder worker
    try:
        start_siem_worker()
    except Exception as e:
        logging.warning(f"siem worker start failed: {e}")

    # Snapshot scheduler (60s tick, idempotent)
    try:
        start_snap_scheduler()
    except Exception as e:
        logging.warning(f"snapshot scheduler start failed: {e}")

    # spec 128/US4: health-score history snapshot cron + retention sweep
    try:
        from ProxmoxVEx.ux.health import start_health_history_worker

        start_health_history_worker()
    except Exception as e:
        logging.warning(f"health history worker start failed: {e}")

    # Native built-in integrations (Docker, NetApp, OPNsense, TrueNAS)
    try:
        from ProxmoxVEx.native import register_native

        register_native(app)
    except Exception as e:
        logging.warning(f"native integrations registration failed: {e}")
