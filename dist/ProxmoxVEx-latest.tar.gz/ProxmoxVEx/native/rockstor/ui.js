/* --- ProxmoxVEx auto-header start ---
 * -------------------------------------------------------------------
 * File:        ProxmoxVEx/native/rockstor/ui.js
 * Project:     ProxmoxVEx
 * Version:     1.2.662
 * Build:       2026.10.21
 * Description: Ui JS source
 * Docs:        https://proxmoxvex.com/docs
 * Generated:   2026-10-21
 * -------------------------------------------------------------------
 * --- ProxmoxVEx auto-header end --- */
(function () {
    'use strict';
    var qs = new URLSearchParams(window.location.search);
    var theme = qs.get('theme') || 'modern-dark';
    if (theme === 'corp-light') document.documentElement.setAttribute('data-theme', 'corp-light');
    else document.documentElement.removeAttribute('data-theme');
    var $ = function (id) { return document.getElementById(id); };
    var API = '/api/rockstor';
    var NS = 'rockstor';
    var i18n = window.parent && window.parent.ProxmoxVExI18n;
    var fallbackDict = {};

    // Standalone English fallback so the iframe renders readable strings when
    // loaded outside the host shell (tests, direct URL) without the i18n bridge.
    var EN_FALLBACK = {
        loading: 'Loading…', retry: 'Retry', loadError: 'Failed to load data.',
        emptyConnections: 'No Rockstor connections yet.',
        emptyConnectionsHint: 'Add your first appliance to get started.',
        emptyPools: 'No pools.', emptyShares: 'No shares.', emptySnapshots: 'No snapshots.',
        noJobs: 'No operations yet.',
        confirmDeleteConn: 'Delete this connection and its cached inventory?',
        confirmDeletePool: 'Delete this pool on the appliance? This removes every share in it.',
        confirmDeleteShare: 'Delete this share on the appliance?',
        confirmDeleteSnap: 'Delete this snapshot?',
        confirmScrub: 'Start a scrub on this pool?',
        confirmBalance: 'Start a balance on this pool?',
        connOk: 'Reachable', connFail: 'Unreachable',
        cancel: 'Cancel', close: 'Close', save: 'Save', delete: 'Delete', create: 'Create',
        view: 'View', test: 'Test', retry2: 'Retry', resize: 'Resize', clone: 'Clone',
        scrub: 'Scrub', balance: 'Balance', refresh2: 'Refresh', yes: 'Yes', no: 'No',
        all: 'All', mounted: 'Mounted', unmounted: 'Not mounted',
        jobPending: 'Pending', jobRunning: 'Running', jobCompleted: 'Completed',
        jobFailed: 'Failed', jobCancelled: 'Cancelled', jobUnreachable: 'Unreachable',
        selectedN: '{n} selected', connectionsN: '{n} connection(s)', poolsN: '{n} pool(s)',
        sharesN: '{n} share(s)', snapshotsN: '{n} snapshot(s)', jobsN: '{n} operation(s)',
        connSaved: 'Connection saved', poolCreated: 'Pool created', shareCreated: 'Share created',
        shareResized: 'Share resized', snapCreated: 'Snapshot created', snapCloned: 'Snapshot cloned',
        actionDone: 'Operation completed', actionQueued: 'Operation queued — tracking on Jobs tab',
        prev: 'Previous', next: 'Next', pageN: 'Page {n}',
        reachable: 'Reachable', unreachable: 'Unreachable', unknown: 'Unknown',
        colActions: 'Actions', testConnection: 'Test', colSizeGib: 'Quota (GiB)',
    };
    var t = function (k) {
        var s = '';
        try { if (i18n && i18n.getT) s = i18n.getT(NS)(k); } catch (e) { s = ''; }
        if (!s || s === k) s = fallbackDict[k] || EN_FALLBACK[k] || k;
        return s;
    };
    function tf(k, n) { return t(k).replace('{n}', n); }
    function loadPluginDict() {
        var lang = 'en';
        try { lang = (i18n && i18n.getLanguage && i18n.getLanguage()) || 'en'; } catch (e) { lang = 'en'; }
        var langs = lang !== 'en' ? [lang, 'en'] : ['en'];
        return Promise.all(langs.map(function (l) {
            return fetch('/api/native/' + NS + '/i18n/' + l + '.json', { credentials: 'same-origin', cache: 'no-cache' })
                .then(function (r) { return r.ok ? r.json() : null; }).catch(function () { return null; });
        })).then(function (dicts) {
            var all = {};
            langs.forEach(function (l, i) { if (dicts[i]) all[l] = dicts[i]; });
            if (Object.keys(all).length && i18n && i18n.registerNamespaceBulk) i18n.registerNamespaceBulk(NS, all);
            fallbackDict = all.en || dicts[0] || {};
        });
    }

    function esc(s) { var d = document.createElement('div'); d.textContent = s == null ? '' : String(s); return d.innerHTML; }
    function api(path, method, body) {
        var opts = { method: method || 'GET', credentials: 'same-origin', headers: { 'X-Requested-With': 'XMLHttpRequest' } };
        if (body !== null && body !== undefined) { opts.headers['Content-Type'] = 'application/json'; opts.body = JSON.stringify(body); }
        return fetch(API + path, opts).then(function (res) {
            return res.json().catch(function () { return {}; }).then(function (data) {
                if (!res.ok) { var e = new Error(data.reason || data.error || ('HTTP ' + res.status)); e.data = data; throw e; }
                return data;
            });
        });
    }
    function setStatus(msg, type) {
        var el = $('statusMsg');
        if (!el) return;
        el.textContent = msg || '';
        el.className = 'status' + (type ? ' ' + type : '');
    }
    function toast(msg, type) {
        var host = $('toasts');
        if (!host) { setStatus(msg, type === 'error' ? 'error' : 'ok'); return; }
        var d = document.createElement('div');
        d.className = 'toast ' + (type || 'ok');
        d.textContent = msg;
        host.appendChild(d);
        setTimeout(function () { d.remove(); }, 5000);
    }
    function fmtTime(iso) {
        if (!iso) return '—';
        var d = new Date(iso);
        return isNaN(d.getTime()) ? '—' : d.toLocaleString();
    }
    // Rockstor reports every size field in KiB.
    function fmtKiB(n) {
        if (n == null || isNaN(n)) return '—';
        var units = ['KiB', 'MiB', 'GiB', 'TiB', 'PiB'];
        var i = 0, v = Number(n);
        while (v >= 1024 && i < units.length - 1) { v /= 1024; i++; }
        return v.toFixed(v >= 100 || i === 0 ? 0 : 1) + ' ' + units[i];
    }
    var STATUS_BADGE = {
        pending: 'badge-muted', running: 'badge-info', idle: 'badge-info',
        completed: 'badge-ok', reachable: 'badge-ok', online: 'badge-ok',
        failed: 'badge-err', error: 'badge-err', degraded: 'badge-warn',
        cancelled: 'badge-muted', unreachable: 'badge-warn', unknown: 'badge-muted',
        warning: 'badge-warn', mounted: 'badge-ok', unmounted: 'badge-muted',
    };
    var STATUS_KEY = {
        pending: 'jobPending', running: 'jobRunning', completed: 'jobCompleted',
        failed: 'jobFailed', cancelled: 'jobCancelled', unreachable: 'jobUnreachable',
    };
    function badge(status, label) {
        var cls = STATUS_BADGE[String(status).toLowerCase()] || 'badge-muted';
        var key = STATUS_KEY[status];
        var text = label || (key ? t(key) : status);
        return '<span class="badge ' + cls + '">' + esc(text) + '</span>';
    }
    function skeletonRows(tbody, cols, rows) {
        tbody.innerHTML = '';
        for (var i = 0; i < (rows || 4); i++) {
            var tr = tbody.insertRow();
            var td = tr.insertCell();
            td.colSpan = cols;
            td.innerHTML = '<div class="skeleton-row"></div>';
        }
    }
    function emptyRow(tbody, cols, msg, hint) {
        tbody.innerHTML = '<tr><td colspan="' + cols + '"><div class="empty"><span>' + esc(msg) + '</span>' +
            (hint ? '<span class="muted">' + esc(hint) + '</span>' : '') + '</div></td></tr>';
    }
    function errorRow(tbody, cols, err, retryFn) {
        tbody.innerHTML = '<tr><td colspan="' + cols + '"><div class="empty"><span class="error-text">' +
            esc((err && err.message) || t('loadError')) + '</span></div></td></tr>';
        var btn = document.createElement('button');
        btn.className = 'btn small secondary';
        btn.textContent = t('retry');
        btn.addEventListener('click', retryFn);
        tbody.lastChild.firstChild.firstChild.appendChild(btn);
    }
    function wireMenus(root) {
        root.querySelectorAll('details.action-menu').forEach(function (menu) {
            menu.addEventListener('toggle', function () {
                var content = menu.querySelector('.action-menu-content');
                if (!content) return;
                if (!menu.open) { content.style.position = ''; content.style.top = ''; content.style.left = ''; content.style.right = ''; return; }
                var rect = menu.querySelector('summary').getBoundingClientRect();
                var w = Math.max(content.offsetWidth, 170);
                content.style.position = 'fixed';
                var h = content.offsetHeight || 0;
                var top = rect.bottom + 2;
                if (top + h > window.innerHeight - 8) top = Math.max(8, rect.top - h - 2);
                content.style.top = top + 'px';
                content.style.left = Math.max(4, rect.right - w) + 'px';
                content.style.right = 'auto';
            });
        });
    }
    function debounce(fn, ms) {
        var h = null;
        return function () { clearTimeout(h); h = setTimeout(fn, ms || 250); };
    }
    function confirmAction(msg) { return window.confirm(msg); }

    /* ---- Tabs ------------------------------------------------------------- */
    function switchTab(name) {
        document.querySelectorAll('.tab').forEach(function (b) {
            var on = b.getAttribute('data-tab') === name;
            b.classList.toggle('active', on);
            b.setAttribute('aria-selected', on ? 'true' : 'false');
        });
        document.querySelectorAll('.tab-panel').forEach(function (p) {
            p.classList.toggle('hidden', p.id !== 'tab-' + name);
        });
    }
    document.querySelectorAll('.tab').forEach(function (b) {
        b.addEventListener('click', function () { switchTab(b.getAttribute('data-tab')); });
    });

    /* ---- Side pane -------------------------------------------------------- */
    function openDetail(title, html, actions) {
        $('spTitle').textContent = title;
        $('spBody').innerHTML = html;
        var acts = $('spActions');
        acts.innerHTML = '';
        (actions || []).forEach(function (a) {
            var b = document.createElement('button');
            b.className = 'btn small ' + (a.danger ? 'danger' : 'secondary');
            b.textContent = a.label;
            b.addEventListener('click', a.onClick);
            acts.appendChild(b);
        });
        $('sidePane').classList.add('open');
    }
    function closeDetail() { $('sidePane').classList.remove('open'); }
    $('spClose').addEventListener('click', closeDetail);
    function kv(obj) {
        return '<dl class="sp-kv">' + Object.keys(obj).map(function (k) {
            return '<dt>' + esc(k) + '</dt><dd>' + obj[k] + '</dd>';
        }).join('') + '</dl>';
    }

    /* ---- Caches ------------------------------------------------------------ */
    var connsCache = [], poolsCache = [], sharesCache = [], snapsCache = [], jobsCache = [];
    var jobsPage = 1;
    function connName(cid) {
        var c = connsCache.filter(function (x) { return x.id === cid; })[0];
        return c ? (c.display_name || c.name) : (cid || '—');
    }
    function fillConnSelect(sel) {
        sel.innerHTML = '';
        connsCache.forEach(function (c) {
            var o = document.createElement('option');
            o.value = c.id; o.textContent = c.display_name || c.endpoint_url;
            sel.appendChild(o);
        });
    }
    function fillConnFilter(sel) {
        var cur = sel.value;
        sel.innerHTML = '<option value="">' + esc(t('all')) + '</option>';
        connsCache.forEach(function (c) {
            var o = document.createElement('option');
            o.value = c.id; o.textContent = c.display_name || c.endpoint_url;
            sel.appendChild(o);
        });
        sel.value = cur;
    }
    function refreshConnFilters() {
        ['poolConnFilter', 'shareConnFilter', 'snapConnFilter'].forEach(function (id) { fillConnFilter($(id)); });
    }
    function fillPoolSelect(sel, connId) {
        sel.innerHTML = '';
        poolsCache.filter(function (p) { return !connId || p.connection_id === connId; })
            .forEach(function (p) {
                var o = document.createElement('option');
                o.value = p.name; o.textContent = p.name;
                sel.appendChild(o);
            });
    }
    function fillShareSelect(sel, connId) {
        sel.innerHTML = '';
        sharesCache.filter(function (s) { return !connId || s.connection_id === connId; })
            .forEach(function (s) {
                var o = document.createElement('option');
                o.value = s.remote_id; o.textContent = s.name;
                sel.appendChild(o);
            });
    }

    /* ---- Add connection modal ------------------------------------------------ */
    function openConnModal() {
        $('fConnName').value = ''; $('fConnUrl').value = '';
        $('fConnUser').value = ''; $('fConnPass').value = '';
        $('fConnTls').checked = true;
        $('connModalError').textContent = ''; $('connTestResult').textContent = '';
        $('connModal').classList.remove('hidden');
        $('fConnName').focus();
    }
    function closeConnModal() { $('connModal').classList.add('hidden'); }
    $('cmdAddConn').addEventListener('click', openConnModal);
    $('connCancel').addEventListener('click', closeConnModal);
    $('connModal').addEventListener('click', function (e) { if (e.target === $('connModal')) closeConnModal(); });
    $('connSave').addEventListener('click', function () {
        var tlsVerify = $('fConnTls').checked;
        $('connSave').disabled = true;
        api('/connections', 'POST', {
            display_name: $('fConnName').value.trim(),
            endpoint_url: $('fConnUrl').value.trim(),
            tls_verify: tlsVerify,
            tls_insecure_ack: !tlsVerify,
            credential: { username: $('fConnUser').value.trim(), password: $('fConnPass').value },
        }).then(function () {
            closeConnModal(); toast(t('connSaved'), 'ok'); loadConnections(); loadOverview();
        }).catch(function (e) {
            $('connModalError').textContent = e.message;
        }).finally(function () { $('connSave').disabled = false; });
    });

    /* ---- New pool modal --------------------------------------------------------- */
    function openPoolModal() {
        fillConnSelect($('fPoolConn'));
        if (!connsCache.length) { toast(t('emptyConnections'), 'warn'); return; }
        $('fPoolName').value = ''; $('fPoolDisks').value = '';
        $('poolModalError').textContent = '';
        $('poolModal').classList.remove('hidden');
    }
    function closePoolModal() { $('poolModal').classList.add('hidden'); }
    $('cmdNewPool').addEventListener('click', openPoolModal);
    $('poolCancel').addEventListener('click', closePoolModal);
    $('poolModal').addEventListener('click', function (e) { if (e.target === $('poolModal')) closePoolModal(); });
    $('poolSave').addEventListener('click', function () {
        var disks = $('fPoolDisks').value.split(',').map(function (s) { return s.trim(); }).filter(Boolean);
        api('/operations/pool', 'POST', {
            connection_id: parseInt($('fPoolConn').value, 10),
            name: $('fPoolName').value.trim(), disks: disks, raid_level: $('fPoolRaid').value,
        }).then(function () {
            closePoolModal(); toast(t('poolCreated'), 'ok'); loadPools(); loadOverview();
        }).catch(function (e) { $('poolModalError').textContent = e.message; });
    });

    /* ---- New share modal --------------------------------------------------------- */
    function openShareModal() {
        fillConnSelect($('fShareConn'));
        if (!connsCache.length) { toast(t('emptyConnections'), 'warn'); return; }
        fillPoolSelect($('fSharePool'), parseInt($('fShareConn').value, 10));
        $('fShareName').value = ''; $('fShareSize').value = '';
        $('shareModalError').textContent = '';
        $('shareModal').classList.remove('hidden');
    }
    function closeShareModal() { $('shareModal').classList.add('hidden'); }
    $('cmdNewShare').addEventListener('click', openShareModal);
    $('shareCancel').addEventListener('click', closeShareModal);
    $('shareModal').addEventListener('click', function (e) { if (e.target === $('shareModal')) closeShareModal(); });
    $('fShareConn').addEventListener('change', function () {
        fillPoolSelect($('fSharePool'), parseInt($('fShareConn').value, 10));
    });
    $('shareSave').addEventListener('click', function () {
        var gib = parseFloat($('fShareSize').value);
        if (!isFinite(gib) || gib <= 0) { $('shareModalError').textContent = t('colSizeGib'); return; }
        api('/operations/share', 'POST', {
            connection_id: parseInt($('fShareConn').value, 10),
            pool: $('fSharePool').value,
            name: $('fShareName').value.trim(),
            size_kib: Math.round(gib * 1024 * 1024),
            compression: $('fShareCompression').value,
        }).then(function () {
            closeShareModal(); toast(t('shareCreated'), 'ok'); loadShares(); loadOverview();
        }).catch(function (e) { $('shareModalError').textContent = e.message; });
    });

    /* ---- New snapshot modal --------------------------------------------------------- */
    function openSnapModal() {
        fillConnSelect($('fSnapConn'));
        if (!connsCache.length) { toast(t('emptyConnections'), 'warn'); return; }
        fillShareSelect($('fSnapShare'), parseInt($('fSnapConn').value, 10));
        $('fSnapName').value = ''; $('fSnapWritable').checked = false; $('fSnapUvisible').checked = false;
        $('snapModalError').textContent = '';
        $('snapModal').classList.remove('hidden');
    }
    function closeSnapModal() { $('snapModal').classList.add('hidden'); }
    $('cmdNewSnapshot').addEventListener('click', openSnapModal);
    $('snapCancel').addEventListener('click', closeSnapModal);
    $('snapModal').addEventListener('click', function (e) { if (e.target === $('snapModal')) closeSnapModal(); });
    $('fSnapConn').addEventListener('change', function () {
        fillShareSelect($('fSnapShare'), parseInt($('fSnapConn').value, 10));
    });
    $('snapSave').addEventListener('click', function () {
        api('/operations/snapshot', 'POST', {
            connection_id: parseInt($('fSnapConn').value, 10),
            share_remote_id: parseInt($('fSnapShare').value, 10),
            name: $('fSnapName').value.trim(),
            writable: $('fSnapWritable').checked,
            uvisible: $('fSnapUvisible').checked,
        }).then(function () {
            closeSnapModal(); toast(t('snapCreated'), 'ok'); loadSnapshots(); loadOverview();
        }).catch(function (e) { $('snapModalError').textContent = e.message; });
    });

    /* ---- Resize share modal ----------------------------------------------------- */
    var resizeTarget = null;
    function openResizeModal(share) {
        resizeTarget = share;
        $('resizeTarget').textContent = share.name + ' (' + connName(share.connection_id) + ')';
        $('fResizeSize').value = Math.max(1, Math.round((share.size_kib || 0) / 1024 / 1024));
        $('resizeModalError').textContent = '';
        $('resizeModal').classList.remove('hidden');
    }
    function closeResizeModal() { $('resizeModal').classList.add('hidden'); resizeTarget = null; }
    $('resizeCancel').addEventListener('click', closeResizeModal);
    $('resizeModal').addEventListener('click', function (e) { if (e.target === $('resizeModal')) closeResizeModal(); });
    $('resizeSave').addEventListener('click', function () {
        if (!resizeTarget) return;
        var gib = parseFloat($('fResizeSize').value);
        if (!isFinite(gib) || gib <= 0) { $('resizeModalError').textContent = t('colSizeGib'); return; }
        api('/operations/share/resize', 'POST', {
            connection_id: resizeTarget.connection_id,
            remote_id: resizeTarget.remote_id,
            size_kib: Math.round(gib * 1024 * 1024),
        }).then(function () {
            closeResizeModal(); toast(t('shareResized'), 'ok'); loadShares();
        }).catch(function (e) { $('resizeModalError').textContent = e.message; });
    });

    /* ---- Clone snapshot modal ------------------------------------------------------ */
    var cloneTarget = null;
    function openCloneModal(snap) {
        cloneTarget = snap;
        $('cloneTarget').textContent = snap.name + ' → share ' + (snap.share_name || '');
        $('fCloneName').value = (snap.name || '') + '-clone';
        $('cloneModalError').textContent = '';
        $('cloneModal').classList.remove('hidden');
    }
    function closeCloneModal() { $('cloneModal').classList.add('hidden'); cloneTarget = null; }
    $('cloneCancel').addEventListener('click', closeCloneModal);
    $('cloneModal').addEventListener('click', function (e) { if (e.target === $('cloneModal')) closeCloneModal(); });
    $('cloneSave').addEventListener('click', function () {
        if (!cloneTarget) return;
        api('/operations/snapshot/clone', 'POST', {
            connection_id: cloneTarget.connection_id,
            share_remote_id: cloneTarget.share_remote_id,
            name: cloneTarget.name,
            new_name: $('fCloneName').value.trim(),
        }).then(function () {
            closeCloneModal(); toast(t('snapCloned'), 'ok'); loadSnapshots(); loadShares();
        }).catch(function (e) { $('cloneModalError').textContent = e.message; });
    });

    /* ---- Overview ----------------------------------------------------------------- */
    function loadOverview() {
        api('/overview').then(function (s) {
            $('statConnections').textContent = (s.connections && s.connections.total != null) ? s.connections.total : '–';
            $('statPools').textContent = (s.pools && s.pools.total != null) ? s.pools.total : '–';
            $('statShares').textContent = (s.shares && s.shares.total != null) ? s.shares.total : '–';
            $('statSnapshots').textContent = (s.snapshots && s.snapshots.total != null) ? s.snapshots.total : '–';
            var cap = s.capacity || {};
            $('statCapacity').textContent = cap.size_kib ? (fmtKiB(cap.used_kib) + ' / ' + fmtKiB(cap.size_kib)) : '–';
            var ops = s.operations || {};
            var byStatus = {};
            (ops.latest || []).forEach(function (o) { byStatus[o.status || 'unknown'] = (byStatus[o.status || 'unknown'] || 0) + 1; });
            var host = $('statusBreakdown');
            var counts = { running: ops.running || 0, failed: ops.failed || 0, recent: ops.recent || 0 };
            var keys = Object.keys(counts).filter(function (k) { return counts[k]; });
            if (!keys.length) { host.innerHTML = '<p class="empty">' + esc(t('noJobs')) + '</p>'; }
            else host.innerHTML = '<table class="data-table"><tbody>' + keys.map(function (k) {
                return '<tr><td>' + badge(k === 'recent' ? 'idle' : k) + '</td><td class="muted">' + counts[k] + '</td></tr>';
            }).join('') + '</tbody></table>';
        }).catch(function (e) {
            $('statusBreakdown').innerHTML = '<p class="empty error-text">' + esc(e.message || t('loadError')) + '</p>';
        });
        api('/operations?page_size=5').then(function (d) {
            var rows = d.items || [];
            var rh = $('recentJobs');
            if (!rows.length) { rh.innerHTML = '<p class="empty">' + esc(t('noJobs')) + '</p>'; return; }
            rh.innerHTML = '<table class="data-table"><tbody>' + rows.map(function (r) {
                return '<tr><td class="nowrap muted">' + esc((r.id || '').slice(0, 8)) + '</td><td>' + esc(r.action || '—') + '</td><td>' +
                    esc(r.target || '—') + '</td><td>' + badge(r.status) + '</td><td class="muted nowrap">' + esc(fmtTime(r.created_at)) + '</td></tr>';
            }).join('') + '</tbody></table>';
        }).catch(function () { $('recentJobs').innerHTML = '<p class="empty">' + esc(t('noJobs')) + '</p>'; });
    }
    $('viewAllJobs').addEventListener('click', function () { switchTab('jobs'); });

    /* ---- Connections ----------------------------------------------------------------- */
    function loadConnections() {
        var tbody = $('connectionsBody');
        skeletonRows(tbody, 7);
        api('/connections').then(function (d) {
            connsCache = d.connections || [];
            refreshConnFilters();
            var status = $('connStatusFilter').value;
            var q = $('searchConnections').value.trim().toLowerCase();
            var rows = connsCache.filter(function (c) {
                if (status && (c.connectivity_status || 'unknown') !== status) return false;
                if (q && String(c.display_name || '').toLowerCase().indexOf(q) < 0 &&
                    String(c.endpoint_url || '').toLowerCase().indexOf(q) < 0) return false;
                return true;
            });
            $('connCount').textContent = tf('connectionsN', rows.length);
            if (!rows.length) { emptyRow(tbody, 7, t('emptyConnections'), t('emptyConnectionsHint')); return; }
            tbody.innerHTML = '';
            rows.forEach(function (c) {
                var tr = tbody.insertRow();
                tr.innerHTML =
                    '<td><button class="link-btn conn-link" data-id="' + esc(c.id) + '">' + esc(c.display_name || '—') + '</button></td>' +
                    '<td class="muted wrap">' + esc(c.endpoint_url || '—') + '</td>' +
                    '<td class="nowrap">' + esc(c.hostname || '—') + '</td>' +
                    '<td class="nowrap">' + esc(c.version || '—') + '</td>' +
                    '<td>' + badge(c.connectivity_status || 'unknown') + '</td>' +
                    '<td class="muted nowrap">' + esc(fmtTime(c.last_successful_contact)) + '</td>' +
                    '<td class="nowrap"><details class="action-menu"><summary class="btn small secondary">' + esc(t('colActions')) + ' <span class="caret">▾</span></summary>' +
                    '<div class="action-menu-content">' +
                    '<button class="btn small secondary act-test" data-id="' + esc(c.id) + '">' + esc(t('testConnection')) + '</button>' +
                    '<button class="btn small secondary act-refresh" data-id="' + esc(c.id) + '">' + esc(t('refresh2')) + '</button>' +
                    '<button class="btn small danger act-del" data-id="' + esc(c.id) + '">' + esc(t('delete')) + '</button>' +
                    '</div></details></td>';
            });
            wireMenus(tbody);
        }).catch(function (e) { errorRow(tbody, 7, e, loadConnections); });
    }
    $('connectionsBody').addEventListener('click', function (e) {
        var btn = e.target.closest('button');
        if (!btn) return;
        var id = parseInt(btn.getAttribute('data-id'), 10);
        if (btn.classList.contains('act-test')) {
            setStatus(t('loading'));
            api('/connections/test', 'POST', { connection_id: id }).then(function (r) {
                setStatus(r.reachable ? t('connOk') : t('connFail'), r.reachable ? 'ok' : 'error');
                loadConnections();
            }).catch(function (err) { setStatus(err.message, 'error'); loadConnections(); });
        } else if (btn.classList.contains('act-refresh')) {
            setStatus(t('loading'));
            api('/inventory/refresh', 'POST', { connection_id: id }).then(function () {
                setStatus('', ''); toast(t('actionDone'), 'ok'); refreshAll();
            }).catch(function (err) { setStatus(err.message, 'error'); });
        } else if (btn.classList.contains('act-del')) {
            if (!confirmAction(t('confirmDeleteConn'))) return;
            api('/connections/delete', 'DELETE', { connection_id: id }).then(function () {
                toast(t('actionDone'), 'ok'); loadConnections(); loadOverview();
            }).catch(function (err) { toast(err.message, 'error'); });
        } else if (btn.classList.contains('conn-link')) {
            var c = connsCache.filter(function (x) { return x.id === id; })[0];
            if (!c) return;
            openDetail(c.display_name || '—', kv({
                'ID': esc(c.id), 'URL': esc(c.endpoint_url || '—'),
                'Hostname': esc(c.hostname || '—'), 'Version': esc(c.version || '—'),
                'TLS verify': c.tls_verify ? t('yes') : t('no'),
                'Status': badge(c.connectivity_status || 'unknown'),
                'Last contact': esc(fmtTime(c.last_successful_contact)),
                'Created': esc(fmtTime(c.created_at)),
            }));
        }
    });
    $('connStatusFilter').addEventListener('change', loadConnections);
    $('searchConnections').addEventListener('input', debounce(loadConnections));

    /* ---- Pools ----------------------------------------------------------------- */
    function loadPools() {
        var tbody = $('poolsBody');
        skeletonRows(tbody, 8);
        var cid = $('poolConnFilter').value;
        api('/inventory/pools' + (cid ? '?connection_id=' + cid : '')).then(function (d) {
            poolsCache = d.items || [];
            var raid = $('poolRaidFilter').value;
            var q = $('searchPools').value.trim().toLowerCase();
            var rows = poolsCache.filter(function (p) {
                if (raid && (p.raid || '') !== raid) return false;
                if (q && String(p.name || '').toLowerCase().indexOf(q) < 0) return false;
                return true;
            });
            $('poolCount').textContent = tf('poolsN', rows.length);
            if (!rows.length) { emptyRow(tbody, 8, t('emptyPools')); return; }
            tbody.innerHTML = '';
            rows.forEach(function (p) {
                var tr = tbody.insertRow();
                tr.innerHTML =
                    '<td><button class="link-btn pool-link" data-id="' + esc(p.remote_id) + '" data-conn="' + esc(p.connection_id) + '">' + esc(p.name || '—') + '</button></td>' +
                    '<td class="nowrap">' + esc(connName(p.connection_id)) + '</td>' +
                    '<td class="nowrap">' + esc(p.raid || '—') + '</td>' +
                    '<td class="nowrap">' + esc(fmtKiB(p.size_kib)) + '</td>' +
                    '<td class="nowrap">' + esc(fmtKiB(p.used_kib)) + '</td>' +
                    '<td class="nowrap">' + esc(fmtKiB(p.free_kib)) + '</td>' +
                    '<td>' + badge(p.is_mounted ? 'mounted' : 'unmounted', p.is_mounted ? t('mounted') : t('unmounted')) + '</td>' +
                    '<td class="nowrap"><details class="action-menu"><summary class="btn small secondary">' + esc(t('colActions')) + ' <span class="caret">▾</span></summary>' +
                    '<div class="action-menu-content">' +
                    '<button class="btn small secondary act-scrub" data-id="' + esc(p.remote_id) + '" data-conn="' + esc(p.connection_id) + '">' + esc(t('scrub')) + '</button>' +
                    '<button class="btn small secondary act-balance" data-id="' + esc(p.remote_id) + '" data-conn="' + esc(p.connection_id) + '">' + esc(t('balance')) + '</button>' +
                    '<button class="btn small danger act-del" data-id="' + esc(p.remote_id) + '" data-conn="' + esc(p.connection_id) + '">' + esc(t('delete')) + '</button>' +
                    '</div></details></td>';
            });
            wireMenus(tbody);
        }).catch(function (e) { errorRow(tbody, 8, e, loadPools); });
    }
    function poolAction(btn, action, confirmMsg) {
        var rid = parseInt(btn.getAttribute('data-id'), 10);
        var cid = parseInt(btn.getAttribute('data-conn'), 10);
        if (confirmMsg && !confirmAction(confirmMsg)) return;
        setStatus(t('loading'));
        api('/operations/pool/action', 'POST', { connection_id: cid, remote_id: rid, action: action }).then(function () {
            setStatus('', ''); toast(t('actionDone'), 'ok'); loadPools(); loadJobs();
        }).catch(function (e) { setStatus('', ''); toast(e.message, 'error'); });
    }
    $('poolsBody').addEventListener('click', function (e) {
        var btn = e.target.closest('button');
        if (!btn) return;
        if (btn.classList.contains('act-scrub')) poolAction(btn, 'scrub', t('confirmScrub'));
        else if (btn.classList.contains('act-balance')) poolAction(btn, 'balance', t('confirmBalance'));
        else if (btn.classList.contains('act-del')) poolAction(btn, 'delete', t('confirmDeletePool'));
        else if (btn.classList.contains('pool-link')) {
            var rid = parseInt(btn.getAttribute('data-id'), 10);
            var p = poolsCache.filter(function (x) { return x.remote_id === rid; })[0];
            if (!p) return;
            openDetail(p.name || '—', kv({
                'Remote ID': esc(p.remote_id), 'UUID': esc(p.uuid || '—'),
                'RAID': esc(p.raid || '—'), 'Size': esc(fmtKiB(p.size_kib)),
                'Used': esc(fmtKiB(p.used_kib)), 'Free': esc(fmtKiB(p.free_kib)),
                'Compression': esc(p.compression || '—'), 'Role': esc(p.role || '—'),
                'Mounted': p.is_mounted ? t('yes') : t('no'),
                'Last seen': esc(fmtTime(p.last_seen)),
            }));
        }
    });
    $('poolConnFilter').addEventListener('change', loadPools);
    $('poolRaidFilter').addEventListener('change', loadPools);
    $('searchPools').addEventListener('input', debounce(loadPools));

    /* ---- Shares ----------------------------------------------------------------- */
    function loadShares() {
        var tbody = $('sharesBody');
        skeletonRows(tbody, 8);
        var cid = $('shareConnFilter').value;
        api('/inventory/shares' + (cid ? '?connection_id=' + cid : '')).then(function (d) {
            sharesCache = d.items || [];
            var poolSel = $('sharePoolFilter');
            var curPool = poolSel.value;
            var poolNames = [];
            sharesCache.forEach(function (s) { if (s.pool_name && poolNames.indexOf(s.pool_name) < 0) poolNames.push(s.pool_name); });
            poolSel.innerHTML = '<option value="">' + esc(t('all')) + '</option>';
            poolNames.forEach(function (n) {
                var o = document.createElement('option'); o.value = n; o.textContent = n; poolSel.appendChild(o);
            });
            poolSel.value = curPool;
            var pool = poolSel.value;
            var q = $('searchShares').value.trim().toLowerCase();
            var rows = sharesCache.filter(function (s) {
                if (pool && (s.pool_name || '') !== pool) return false;
                if (q && String(s.name || '').toLowerCase().indexOf(q) < 0) return false;
                return true;
            });
            $('shareCount').textContent = tf('sharesN', rows.length);
            if (!rows.length) { emptyRow(tbody, 8, t('emptyShares')); return; }
            tbody.innerHTML = '';
            rows.forEach(function (s) {
                var tr = tbody.insertRow();
                tr.innerHTML =
                    '<td><button class="link-btn share-link" data-id="' + esc(s.remote_id) + '" data-conn="' + esc(s.connection_id) + '">' + esc(s.name || '—') + '</button></td>' +
                    '<td class="nowrap">' + esc(connName(s.connection_id)) + '</td>' +
                    '<td class="nowrap">' + esc(s.pool_name || '—') + '</td>' +
                    '<td class="nowrap">' + esc(fmtKiB(s.size_kib)) + '</td>' +
                    '<td class="nowrap">' + esc(fmtKiB(s.rusage_kib)) + '</td>' +
                    '<td class="nowrap">' + esc(s.compression_algo || 'no') + '</td>' +
                    '<td>' + badge(s.is_mounted ? 'mounted' : 'unmounted', s.is_mounted ? t('mounted') : t('unmounted')) + '</td>' +
                    '<td class="nowrap"><details class="action-menu"><summary class="btn small secondary">' + esc(t('colActions')) + ' <span class="caret">▾</span></summary>' +
                    '<div class="action-menu-content">' +
                    '<button class="btn small secondary act-resize" data-id="' + esc(s.remote_id) + '" data-conn="' + esc(s.connection_id) + '">' + esc(t('resize')) + '</button>' +
                    '<button class="btn small danger act-del" data-id="' + esc(s.remote_id) + '" data-conn="' + esc(s.connection_id) + '">' + esc(t('delete')) + '</button>' +
                    '</div></details></td>';
            });
            wireMenus(tbody);
        }).catch(function (e) { errorRow(tbody, 8, e, loadShares); });
    }
    $('sharesBody').addEventListener('click', function (e) {
        var btn = e.target.closest('button');
        if (!btn) return;
        var rid = parseInt(btn.getAttribute('data-id'), 10);
        var cid = parseInt(btn.getAttribute('data-conn'), 10);
        var share = sharesCache.filter(function (s) { return s.remote_id === rid && s.connection_id === cid; })[0];
        if (btn.classList.contains('act-resize')) {
            if (share) openResizeModal(share);
        } else if (btn.classList.contains('act-del')) {
            if (!confirmAction(t('confirmDeleteShare'))) return;
            api('/operations/share/delete', 'DELETE', { connection_id: cid, remote_id: rid }).then(function () {
                toast(t('actionDone'), 'ok'); loadShares(); loadOverview();
            }).catch(function (err) { toast(err.message, 'error'); });
        } else if (btn.classList.contains('share-link')) {
            if (!share) return;
            openDetail(share.name || '—', kv({
                'Remote ID': esc(share.remote_id), 'Pool': esc(share.pool_name || '—'),
                'Size': esc(fmtKiB(share.size_kib)), 'Used (rusage)': esc(fmtKiB(share.rusage_kib)),
                'Used (eusage)': esc(fmtKiB(share.eusage_kib)), 'Compression': esc(share.compression_algo || '—'),
                'Owner': esc(share.owner || '—'), 'Group': esc(share.grp || '—'),
                'Perms': esc(share.perms || '—'), 'Replica': share.replica ? t('yes') : t('no'),
                'Mounted': share.is_mounted ? t('yes') : t('no'),
                'Last seen': esc(fmtTime(share.last_seen)),
            }), [
                { label: t('resize'), onClick: function () { closeDetail(); openResizeModal(share); } },
            ]);
        }
    });
    $('shareConnFilter').addEventListener('change', loadShares);
    $('sharePoolFilter').addEventListener('change', loadShares);
    $('searchShares').addEventListener('input', debounce(loadShares));

    /* ---- Snapshots ----------------------------------------------------------------- */
    function loadSnapshots() {
        var tbody = $('snapshotsBody');
        skeletonRows(tbody, 6);
        var cid = $('snapConnFilter').value;
        api('/inventory/snapshots' + (cid ? '?connection_id=' + cid : '')).then(function (d) {
            snapsCache = d.items || [];
            var shareSel = $('snapShareFilter');
            var curShare = shareSel.value;
            var shareNames = [];
            snapsCache.forEach(function (s) { if (s.share_name && shareNames.indexOf(s.share_name) < 0) shareNames.push(s.share_name); });
            shareSel.innerHTML = '<option value="">' + esc(t('all')) + '</option>';
            shareNames.forEach(function (n) {
                var o = document.createElement('option'); o.value = n; o.textContent = n; shareSel.appendChild(o);
            });
            shareSel.value = curShare;
            var share = shareSel.value;
            var q = $('searchSnapshots').value.trim().toLowerCase();
            var rows = snapsCache.filter(function (s) {
                if (share && (s.share_name || '') !== share) return false;
                if (q && String(s.name || '').toLowerCase().indexOf(q) < 0) return false;
                return true;
            });
            $('snapCount').textContent = tf('snapshotsN', rows.length);
            if (!rows.length) { emptyRow(tbody, 6, t('emptySnapshots')); return; }
            tbody.innerHTML = '';
            rows.forEach(function (s) {
                var tr = tbody.insertRow();
                tr.innerHTML =
                    '<td>' + esc(s.name || '—') + '</td>' +
                    '<td class="nowrap">' + esc(s.share_name || '—') + '</td>' +
                    '<td class="nowrap">' + esc(connName(s.connection_id)) + '</td>' +
                    '<td>' + (s.writable ? t('yes') : t('no')) + '</td>' +
                    '<td class="muted nowrap">' + esc(fmtTime(s.toc)) + '</td>' +
                    '<td class="nowrap"><details class="action-menu"><summary class="btn small secondary">' + esc(t('colActions')) + ' <span class="caret">▾</span></summary>' +
                    '<div class="action-menu-content">' +
                    '<button class="btn small secondary act-clone" data-name="' + esc(s.name) + '" data-share="' + esc(s.share_remote_id) + '" data-conn="' + esc(s.connection_id) + '">' + esc(t('clone')) + '</button>' +
                    '<button class="btn small danger act-del" data-name="' + esc(s.name) + '" data-share="' + esc(s.share_remote_id) + '" data-conn="' + esc(s.connection_id) + '">' + esc(t('delete')) + '</button>' +
                    '</div></details></td>';
            });
            wireMenus(tbody);
        }).catch(function (e) { errorRow(tbody, 6, e, loadSnapshots); });
    }
    $('snapshotsBody').addEventListener('click', function (e) {
        var btn = e.target.closest('button');
        if (!btn) return;
        var name = btn.getAttribute('data-name');
        var sid = parseInt(btn.getAttribute('data-share'), 10);
        var cid = parseInt(btn.getAttribute('data-conn'), 10);
        var snap = snapsCache.filter(function (s) {
            return s.name === name && s.share_remote_id === sid && s.connection_id === cid;
        })[0];
        if (btn.classList.contains('act-clone')) {
            if (snap) openCloneModal(snap);
        } else if (btn.classList.contains('act-del')) {
            if (!confirmAction(t('confirmDeleteSnap'))) return;
            api('/operations/snapshot/delete', 'DELETE', { connection_id: cid, share_remote_id: sid, name: name }).then(function () {
                toast(t('actionDone'), 'ok'); loadSnapshots();
            }).catch(function (err) { toast(err.message, 'error'); });
        }
    });
    $('snapConnFilter').addEventListener('change', loadSnapshots);
    $('snapShareFilter').addEventListener('change', loadSnapshots);
    $('searchSnapshots').addEventListener('input', debounce(loadSnapshots));

    /* ---- Jobs ----------------------------------------------------------------- */
    function loadJobs() {
        var tbody = $('jobsBody');
        skeletonRows(tbody, 7);
        api('/operations?page=' + jobsPage + '&page_size=25').then(function (d) {
            var rows = d.items || [];
            jobsCache = rows;
            var status = $('jobStatusFilter').value;
            var q = $('searchJobs').value.trim().toLowerCase();
            var filtered = rows.filter(function (j) {
                if (status && (j.status || '') !== status) return false;
                if (q && String(j.action || '').toLowerCase().indexOf(q) < 0 &&
                    String(j.target || '').toLowerCase().indexOf(q) < 0 &&
                    String(j.id || '').indexOf(q) < 0) return false;
                return true;
            });
            $('jobCount').textContent = tf('jobsN', filtered.length);
            $('jobPageInfo').textContent = tf('pageN', d.page || 1) + ' / ' + (d.total || 0);
            $('jobPrev').disabled = (d.page || 1) <= 1;
            $('jobNext').disabled = (d.page * d.page_size) >= (d.total || 0);
            var running = filtered.filter(function (j) { return j.status === 'running' || j.status === 'pending'; }).length;
            var bj = $('badgeJobs');
            if (running) { bj.textContent = running; bj.classList.remove('hidden'); bj.classList.add('warn'); }
            else { bj.classList.add('hidden'); }
            if (!filtered.length) { emptyRow(tbody, 7, t('noJobs')); return; }
            tbody.innerHTML = '';
            filtered.forEach(function (j) {
                var tr = tbody.insertRow();
                var canCancel = j.status === 'pending';
                var canRetry = ['completed', 'failed', 'cancelled', 'unreachable'].indexOf(j.status) >= 0;
                tr.innerHTML =
                    '<td class="nowrap muted">' + esc((j.id || '').slice(0, 8)) + '</td>' +
                    '<td>' + esc(j.action || '—') + '</td>' +
                    '<td class="wrap">' + esc(j.target || '—') + '</td>' +
                    '<td>' + badge(j.status) + (j.error ? ' <span class="error-text">' + esc(j.error) + '</span>' : '') + '</td>' +
                    '<td class="nowrap">' + esc(j.actor || '—') + '</td>' +
                    '<td class="muted nowrap">' + esc(fmtTime(j.created_at)) + '</td>' +
                    '<td class="nowrap"><details class="action-menu"><summary class="btn small secondary">' + esc(t('colActions')) + ' <span class="caret">▾</span></summary>' +
                    '<div class="action-menu-content">' +
                    '<button class="btn small secondary act-view" data-id="' + esc(j.id) + '">' + esc(t('view')) + '</button>' +
                    (canRetry ? '<button class="btn small secondary act-retry" data-id="' + esc(j.id) + '">' + esc(t('retry2')) + '</button>' : '') +
                    (canCancel ? '<button class="btn small danger act-cancel" data-id="' + esc(j.id) + '">' + esc(t('cancel')) + '</button>' : '') +
                    '</div></details></td>';
            });
            wireMenus(tbody);
        }).catch(function (e) { errorRow(tbody, 7, e, loadJobs); });
    }
    $('jobsBody').addEventListener('click', function (e) {
        var btn = e.target.closest('button');
        if (!btn) return;
        var id = btn.getAttribute('data-id');
        if (btn.classList.contains('act-view')) {
            api('/operations/detail?op_id=' + encodeURIComponent(id)).then(function (j) {
                openDetail(j.action || '—', kv({
                    'ID': esc(j.id), 'Action': esc(j.action || '—'),
                    'Target': esc(j.target || '—'), 'Status': badge(j.status),
                    'Actor': esc(j.actor || '—'), 'Error': esc(j.error || '—'),
                    'Created': esc(fmtTime(j.created_at)), 'Finished': esc(fmtTime(j.finished_at)),
                }));
            }).catch(function (err) { toast(err.message, 'error'); });
        } else if (btn.classList.contains('act-retry')) {
            api('/operations/retry', 'POST', { op_id: id }).then(function () {
                toast(t('actionQueued'), 'ok'); loadJobs(); loadOverview();
            }).catch(function (err) { toast(err.message, 'error'); });
        } else if (btn.classList.contains('act-cancel')) {
            api('/operations/cancel', 'POST', { op_id: id }).then(function () {
                loadJobs();
            }).catch(function (err) { toast(err.message, 'error'); });
        }
    });
    $('jobStatusFilter').addEventListener('change', loadJobs);
    $('searchJobs').addEventListener('input', debounce(loadJobs));
    $('jobPrev').addEventListener('click', function () { if (jobsPage > 1) { jobsPage--; loadJobs(); } });
    $('jobNext').addEventListener('click', function () { jobsPage++; loadJobs(); });

    /* ---- Boot ----------------------------------------------------------------- */
    function refreshAll() {
        loadOverview(); loadConnections(); loadPools(); loadShares(); loadSnapshots(); loadJobs();
    }
    $('cmdRefresh').addEventListener('click', refreshAll);
    loadPluginDict().finally(refreshAll);
})();
