# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/native/rockstor/connector.py
# Project:     ProxmoxVEx
# Version:     1.2.662
# Build:       2026.10.21
# Description: Rockstor appliance REST API connector.
# Usage:       import ProxmoxVEx.native.rockstor.connector
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-10-21
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Rockstor appliance REST API connector.

Talks to the Rockstor web API (``/api/...``) with HTTP basic auth — the same
auth scheme the Rockstor CLI and Web-UI backend accept for admin users.
TLS verification is on by default; disabling it is an explicit per-connection
opt-in (Rockstor ships a self-signed cert, so ``tls_verify=False`` +
``tls_insecure_ack`` in the connection payload is expected for most
appliances).

A ``mock://`` base URL activates the built-in :class:`MockRockstorSession`
so unit and contract tests exercise the full route/connector stack without a
live appliance.
"""

import logging
import re
import time
from typing import Any, Dict, List, Optional
from urllib.parse import urlparse

import requests

log = logging.getLogger("plugin.rockstor.connector")

ERROR_CODES = {
    "connection.unreachable": "Rockstor appliance unreachable",
    "auth.forbidden": "Invalid credentials or insufficient rights",
    "api.unavailable": "Rockstor REST API unavailable",
    "tls.verify": "TLS verification failed",
    "not_found": "Object not found on Rockstor appliance",
    "operation.failed": "Remote operation failed",
}

MOCK_SCHEME = "mock://"
# Rockstor paginates list endpoints (DRF PageNumberPagination,
# page_size_query_param="page_size", MAX_LIMIT=10000).
PAGE_SIZE = 10000


def tcp_probe_error(address_or_url: str, port: int = 443, timeout: float = 3.0) -> Optional[str]:
    """Return an error string when the TCP endpoint cannot be reached."""
    import socket

    if not address_or_url or address_or_url.startswith(MOCK_SCHEME):
        return None
    address = address_or_url
    if "://" in address:
        parsed = urlparse(address)
        address = parsed.hostname or address
        port = parsed.port or port
    if not address:
        return "Invalid URL"
    try:
        with socket.create_connection((address, port), timeout=timeout) as sock:
            sock.settimeout(timeout)
        return None
    except (socket.timeout, OSError) as e:
        return f"TCP probe failed for {address}:{port}: {e}"


class ConnectorError(Exception):
    def __init__(self, code: str, message: str = ""):
        self.code = code
        self.message = message or ERROR_CODES.get(code, code)
        super().__init__(self.message)


def _map_request_error(e: Exception) -> ConnectorError:
    """Map requests exceptions to a ConnectorError with a stable code."""
    if isinstance(e, requests.exceptions.SSLError):
        return ConnectorError("tls.verify", f"TLS error: {e}")
    if isinstance(e, (requests.exceptions.Timeout, requests.exceptions.ConnectTimeout)):
        return ConnectorError("connection.unreachable", f"Timeout: {e}")
    if isinstance(e, requests.exceptions.ConnectionError):
        return ConnectorError("connection.unreachable", str(e))
    return ConnectorError("operation.failed", str(e))


class RockstorConnector:
    """Rockstor appliance REST client (``/api`` namespace, basic auth)."""

    def __init__(
        self,
        base_url: str,
        credential: Optional[Dict[str, Any]] = None,
        tls_verify: bool = True,
        timeout: int = 20,
        session: Optional[Any] = None,
    ):
        self.base_url = base_url.rstrip("/")
        cred = credential or {}
        self.username = cred.get("username", "")
        self.password = cred.get("password", "")
        self.tls_verify = tls_verify
        self.timeout = timeout
        self._session = session
        self._version = ""

    # ---- transport ----

    def _use_mock(self) -> bool:
        return self.base_url.startswith(MOCK_SCHEME)

    def _http(self) -> Any:
        if self._session is None:
            s = requests.Session()
            s.auth = (self.username, self.password)
            self._session = s
        return self._session

    def _request(self, method: str, path: str, **kwargs) -> Any:
        if self._use_mock():
            return MockRockstorSession.request(self, method, path, **kwargs)
        err = tcp_probe_error(self.base_url, timeout=min(5.0, self.timeout))
        if err:
            raise ConnectorError("connection.unreachable", err)
        url = f"{self.base_url}/api{path}"
        kwargs.setdefault("timeout", self.timeout)
        kwargs.setdefault("verify", self.tls_verify)
        try:
            resp = self._http().request(method, url, **kwargs)
        except Exception as e:
            raise _map_request_error(e) from e
        if resp.status_code in (401, 403):
            raise ConnectorError("auth.forbidden", f"HTTP {resp.status_code}")
        if resp.status_code == 404:
            raise ConnectorError("not_found", f"{method} {path} -> 404")
        if resp.status_code >= 400:
            raise ConnectorError("operation.failed", f"HTTP {resp.status_code}: {resp.text[:300]}")
        if resp.status_code == 204 or not resp.content:
            return {}
        try:
            return resp.json()
        except ValueError:
            return {"raw": resp.text}

    @staticmethod
    def _unwrap(data: Any) -> List[Dict[str, Any]]:
        """Rockstor DRF pagination wraps lists as {count, next, results};
        a few endpoints still return bare lists — accept both."""
        if isinstance(data, list):
            return data
        if isinstance(data, dict):
            if isinstance(data.get("results"), list):
                return data["results"]
            for key in ("items", "data"):
                if isinstance(data.get(key), list):
                    return data[key]
        return []

    def _list(self, path: str) -> List[Dict[str, Any]]:
        """Fetch a paginated collection, following ``next`` links if the
        appliance reports more pages than a single request covers."""
        sep = "&" if "?" in path else "?"
        data = self._request("GET", f"{path}{sep}page_size={PAGE_SIZE}")
        items = self._unwrap(data)
        seen = 0
        # Defensive: follow up to 10 `next` pages so a busy appliance cannot
        # silently truncate the inventory when page_size is capped lower.
        while isinstance(data, dict) and data.get("next") and seen < 10:
            nxt = urlparse(str(data["next"]))
            data = self._request("GET", nxt.path.replace("/api", "", 1) + "?" + nxt.query)
            items.extend(self._unwrap(data))
            seen += 1
        return items

    # ---- validation / discovery ----

    def test_connection(self) -> Dict[str, Any]:
        """Validate credentials and report appliance identity.

        ``/api/appliances`` is the cheapest authenticated read that also
        proves the account has admin rights — it 403s for plain users.
        """
        appliances = self._list("/appliances")
        me = next((a for a in appliances if a.get("current_appliance")), appliances[0] if appliances else {})
        version = ""
        try:
            # POST /api/commands/current-version returns a bare version string.
            info = self._request("POST", "/commands/current-version")
            if isinstance(info, str):
                version = info
            elif isinstance(info, dict):
                version = str(info.get("version") or info.get("raw") or "")
        except ConnectorError:
            version = ""
        self._version = version
        return {
            "reachable": True,
            "status": "reachable",
            "version": version,
            "hostname": me.get("hostname") or "",
            "uuid": me.get("uuid") or "",
            "ip": me.get("ip") or "",
        }

    # ---- collection endpoints ----

    def list_pools(self) -> List[Dict[str, Any]]:
        return self._list("/pools")

    def list_disks(self) -> List[Dict[str, Any]]:
        return self._list("/disks")

    def list_shares(self) -> List[Dict[str, Any]]:
        return self._list("/shares")

    def list_share_snapshots(self, share_id: int) -> List[Dict[str, Any]]:
        return self._list(f"/shares/{share_id}/snapshots")

    # ---- pool operations ----

    def create_pool(self, name: str, disks: List[str], raid_level: str) -> Dict[str, Any]:
        return self._request(
            "POST", "/pools",
            json={"pname": name, "disks": list(disks), "raid_level": raid_level},
        )

    def _delete(self, path: str, gone) -> Any:
        """DELETE with an idempotent post-check.

        Rockstor removes the subvolume first and cleans up its qgroup
        after — a busy quota group turns an otherwise-successful delete
        into HTTP 500 (``qgroup destroy ... Device or resource busy``).
        When the delete errors, re-list: if the object is gone the
        operation genuinely succeeded and callers should not see a
        spurious failure. The original error is re-raised whenever the
        object still exists.
        """
        try:
            return self._request("DELETE", path)
        except ConnectorError as e:
            if e.code != "operation.failed":
                raise
            # The object can take a while to disappear from list
            # responses after the 500 (observed >10s on appliances under
            # filesystem churn) — poll up to ~45s before deciding the
            # delete genuinely failed.
            deadline = time.monotonic() + 45
            while time.monotonic() < deadline:
                if gone():
                    return {}
                time.sleep(2)
            raise

    def delete_pool(self, pool_id: int, force: bool = False) -> Any:
        suffix = "/force" if force else ""
        return self._delete(
            f"/pools/{pool_id}{suffix}",
            lambda: all(p.get("id") != pool_id for p in self.list_pools()),
        )

    def scrub_pool(self, pool_id: int, force: bool = False) -> Dict[str, Any]:
        return self._request("POST", f"/pools/{pool_id}/scrub", json={"force": bool(force)})

    def scrub_status(self, pool_id: int) -> Any:
        return self._request("POST", f"/pools/{pool_id}/scrub/status")

    def balance_pool(self, pool_id: int, force: bool = False) -> Dict[str, Any]:
        return self._request("POST", f"/pools/{pool_id}/balance", json={"force": bool(force)})

    def balance_status(self, pool_id: int) -> Any:
        return self._request("POST", f"/pools/{pool_id}/balance/status")

    # ---- share operations ----

    def create_share(
        self,
        pool: str,
        name: str,
        size_kb: int,
        compression: str = "no",
    ) -> Dict[str, Any]:
        return self._request(
            "POST", "/shares",
            json={
                "pool": pool,
                "sname": name,
                "size": int(size_kb),
                "compression": compression,
            },
        )

    def resize_share(self, share_id: int, size_kb: int) -> Dict[str, Any]:
        return self._request("PUT", f"/shares/{share_id}", json={"size": int(size_kb)})

    def delete_share(self, share_id: int, force: bool = False) -> Any:
        suffix = "/force" if force else ""
        return self._delete(
            f"/shares/{share_id}{suffix}",
            lambda: all(s.get("id") != share_id for s in self.list_shares()),
        )

    # ---- snapshot operations ----

    def create_snapshot(
        self,
        share_id: int,
        name: str,
        writable: bool = False,
        uvisible: bool = False,
    ) -> Dict[str, Any]:
        return self._request(
            "POST", f"/shares/{share_id}/snapshots/{name}",
            json={"writable": bool(writable), "uvisible": bool(uvisible), "snap_type": "admin"},
        )

    def delete_snapshot(self, share_id: int, name: str) -> Any:
        def _gone() -> bool:
            try:
                return all(
                    s.get("name") != name for s in self.list_share_snapshots(share_id)
                )
            except ConnectorError as e:
                # A missing parent share means the snapshot is gone too.
                return e.code == "not_found"

        return self._delete(f"/shares/{share_id}/snapshots/{name}", _gone)

    def clone_snapshot(self, share_id: int, name: str, new_name: str) -> Dict[str, Any]:
        return self._request(
            "POST", f"/shares/{share_id}/snapshots/{name}/clone", json={"name": new_name}
        )


_NAME_SAFE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.\-]{0,127}$")


class MockRockstorSession:
    """Deterministic in-process stand-in for a Rockstor appliance.

    Activated by ``mock://`` base URLs; keeps pools/shares/snapshots in
    module state so create/delete flows round-trip through the connector
    exactly like the live API does.
    """

    _pools: List[Dict[str, Any]] = [
        {
            "id": 1, "name": "mock-pool", "uuid": "mock-uuid-1", "raid": "single",
            "size": 107374182400, "free": 53687091200, "usage": 53687091200,
            "compression": "no", "mnt_options": "", "role": "", "toc": "2026-01-01T00:00:00Z",
            "is_mounted": True,
        }
    ]
    _shares: List[Dict[str, Any]] = [
        {
            "id": 1, "name": "mock-share", "pool": {"id": 1, "name": "mock-pool"},
            "size": 10737418240, "rusage": 1073741824, "eusage": 1073741824,
            "qgroup": "0/257", "pqgroup": "2015/1", "owner": "root", "group": "root",
            "perms": "755", "compression_algo": "no", "replica": False,
            "is_mounted": True, "toc": "2026-01-01T00:00:00Z", "subvol_name": "mock-share",
        }
    ]
    _snapshots: Dict[int, List[Dict[str, Any]]] = {
        1: [
            {
                "id": 1, "share": 1, "name": "mock-snap-1", "real_name": "mock-snap-1",
                "writable": False, "uvisible": False, "snap_type": "admin",
                "size": 1073741824, "qgroup": "0/258", "toc": "2026-01-01T00:00:00Z",
            }
        ]
    }
    _disks: List[Dict[str, Any]] = [
        {
            "id": 1, "name": "sda", "model": "MOCKDISK", "serial": "MD-001",
            "size": 107374182400, "pool": {"id": 1, "name": "mock-pool"},
            "smart_available": True, "smart_enabled": True,
        }
    ]
    _next_id = 100

    @classmethod
    def _alloc_id(cls) -> int:
        cls._next_id += 1
        return cls._next_id

    @staticmethod
    def request(connector: RockstorConnector, method: str, path: str, **kwargs) -> Any:
        cls = MockRockstorSession
        body = kwargs.get("json") or {}
        # _list() appends ?page_size=... — the mock matches on the bare path.
        path = path.split("?", 1)[0]
        base = connector.base_url
        if not base.startswith(MOCK_SCHEME):
            raise ConnectorError("connection.unreachable", "not a mock endpoint")

        def page(items: List[Dict[str, Any]]) -> Dict[str, Any]:
            return {"count": len(items), "next": None, "previous": None, "results": list(items)}

        if path.startswith("/appliances"):
            return page([{
                "id": 1, "ip": "192.0.2.10", "mgmt_iface_name": "eth0",
                "hostname": "rockstor-mock", "uuid": "mock-appliance-uuid",
                "current_appliance": True,
            }])
        if path.startswith("/commands/"):
            if path.endswith("current-version"):
                return "5.0.15"
            return {}
        if path.startswith("/disks"):
            return page(cls._disks)
        if path == "/pools" and method == "GET":
            return page(cls._pools)
        if path == "/pools" and method == "POST":
            pname = body.get("pname") or ""
            if not _NAME_SAFE.match(pname):
                raise ConnectorError("operation.failed", f"Invalid pool name {pname}")
            if any(p["name"] == pname for p in cls._pools):
                raise ConnectorError("operation.failed", f"Pool ({pname}) already exists")
            pool: Dict[str, Any] = {
                "id": cls._alloc_id(), "name": pname, "uuid": f"mock-uuid-{pname}",
                "raid": body.get("raid_level") or "single", "size": 107374182400,
                "free": 107374182400, "usage": 0, "compression": "no",
                "mnt_options": "", "role": "", "toc": "2026-01-01T00:00:00Z",
                "is_mounted": True,
            }
            cls._pools.append(pool)
            return dict(pool)
        m = re.match(r"^/pools/(\d+)(.*)$", path)
        if m:
            pid = int(m.group(1))
            rest = m.group(2) or ""
            found_pool = next((p for p in cls._pools if p["id"] == pid), None)
            if found_pool is None:
                raise ConnectorError("not_found", f"pool {pid} not found")
            pool = found_pool
            if method == "DELETE":
                if any(s.get("pool", {}).get("id") == pid for s in cls._shares) and rest != "/force":
                    raise ConnectorError("operation.failed", f"Pool ({pool['name']}) is not empty")
                cls._pools = [p for p in cls._pools if p["id"] != pid]
                cls._shares = [s for s in cls._shares if s.get("pool", {}).get("id") != pid]
                return {}
            if rest.startswith("/scrub"):
                if rest.endswith("/status"):
                    return {"status": "finished", "kb_scrubbed": 107374182400, "duration": 60}
                return {"status": "running"}
            if rest.startswith("/balance"):
                if rest.endswith("/status"):
                    return {"status": "finished", "percent_complete": 100}
                return {"status": "running"}
            if rest == "/shares":
                return page([s for s in cls._shares if s.get("pool", {}).get("id") == pid])
        if path == "/shares" and method == "GET":
            return page(cls._shares)
        if path == "/shares" and method == "POST":
            sname = body.get("sname") or ""
            if not _NAME_SAFE.match(sname):
                raise ConnectorError("operation.failed", f"Invalid share name {sname}")
            pool_name = body.get("pool") or ""
            found_pool = next((p for p in cls._pools if p["name"] == pool_name), None)
            if found_pool is None:
                raise ConnectorError("operation.failed", f"Pool ({pool_name}) does not exist")
            pool = found_pool
            if any(s["name"] == sname for s in cls._shares):
                raise ConnectorError("operation.failed", f"Share ({sname}) already exists")
            share: Dict[str, Any] = {
                "id": cls._alloc_id(), "name": sname, "pool": {"id": pool["id"], "name": pool["name"]},
                "size": int(body.get("size") or pool["size"]), "rusage": 0, "eusage": 0,
                "qgroup": "0/0", "pqgroup": "2015/0", "owner": "root", "group": "root",
                "perms": "755", "compression_algo": body.get("compression") or "no",
                "replica": False, "is_mounted": True, "toc": "2026-01-01T00:00:00Z",
                "subvol_name": sname,
            }
            cls._shares.append(share)
            cls._snapshots[share["id"]] = []
            return dict(share)
        m = re.match(r"^/shares/(\d+)(.*)$", path)
        if m:
            sid = int(m.group(1))
            rest = m.group(2) or ""
            found_share = next((s for s in cls._shares if s["id"] == sid), None)
            if found_share is None:
                raise ConnectorError("not_found", f"share {sid} not found")
            share = found_share
            # DELETE /shares/<id>[/force] removes the share itself; a DELETE
            # under /snapshots/<name> must fall through to the snapshot branch.
            if method == "DELETE" and rest in ("", "/force"):
                cls._shares = [s for s in cls._shares if s["id"] != sid]
                cls._snapshots.pop(sid, None)
                return {}
            if method == "PUT" and rest == "":
                share["size"] = int(body.get("size") or share["size"])
                return dict(share)
            sm = re.match(r"^/snapshots(?:/([^/]+)(?:/(\w+))?)?$", rest)
            if sm:
                snap_name = sm.group(1)
                command = sm.group(2)
                snaps = cls._snapshots.setdefault(sid, [])
                if method == "GET" and snap_name is None:
                    return page(snaps)
                if method == "POST" and snap_name and command == "clone":
                    new_name = body.get("name") or ""
                    if not _NAME_SAFE.match(new_name):
                        raise ConnectorError("operation.failed", f"Invalid share name {new_name}")
                    src = next((s for s in snaps if s["name"] == snap_name), None)
                    if src is None:
                        raise ConnectorError("not_found", f"snapshot {snap_name} not found")
                    clone = {
                        "id": cls._alloc_id(), "name": new_name,
                        "pool": {"id": share["pool"]["id"], "name": share["pool"]["name"]},
                        "size": src.get("size") or share["size"], "rusage": 0, "eusage": 0,
                        "qgroup": "0/0", "pqgroup": "2015/0", "owner": "root", "group": "root",
                        "perms": "755", "compression_algo": share.get("compression_algo") or "no",
                        "replica": False, "is_mounted": True, "toc": "2026-01-01T00:00:00Z",
                        "subvol_name": new_name,
                    }
                    cls._shares.append(clone)
                    return dict(clone)
                if method == "POST" and snap_name:
                    if not _NAME_SAFE.match(snap_name):
                        raise ConnectorError("operation.failed", f"Invalid snapshot name {snap_name}")
                    if any(s["name"] == snap_name for s in snaps):
                        raise ConnectorError("operation.failed", f"Snapshot ({snap_name}) already exists")
                    snap = {
                        "id": cls._alloc_id(), "share": sid, "name": snap_name,
                        "real_name": snap_name, "writable": bool(body.get("writable")),
                        "uvisible": bool(body.get("uvisible")),
                        "snap_type": body.get("snap_type") or "admin",
                        "size": share["size"], "qgroup": "0/0", "toc": "2026-01-01T00:00:00Z",
                    }
                    snaps.append(snap)
                    return dict(snap)
                if method == "DELETE" and snap_name:
                    cls._snapshots[sid] = [s for s in snaps if s["name"] != snap_name]
                    return {}
        raise ConnectorError("not_found", f"mock: unhandled {method} {path}")


def build_connector(conn: Any, credential: Optional[Dict[str, Any]] = None) -> RockstorConnector:
    """Build a connector from a Connection dataclass."""
    if credential is None:
        from .models import get_connection_credential

        credential = get_connection_credential(conn.id)
    return RockstorConnector(
        base_url=conn.endpoint_url,
        credential=credential,
        tls_verify=conn.tls_verify,
    )
