# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/core/config.py
# Project:     ProxmoxVEx
# Version:     1.2.681
# Build:       2026.10.22
# Description: ProxmoxVEx Config Management - Layer 3 Encryption key
#              management and config load/save.
# Usage:       import ProxmoxVEx.core.config
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-10-22
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""
ProxmoxVEx Config Management - Layer 3
Encryption key management and config load/save.
"""

import json
import logging
import os
import re
from pathlib import Path

from ProxmoxVEx.constants import CONFIG_FILE_ENCRYPTED
from ProxmoxVEx.core.db import ENCRYPTION_AVAILABLE, get_db
from ProxmoxVEx.globals import cluster_managers

try:
    from cryptography.fernet import Fernet
except ImportError:  # optional dep — ENCRYPTION_AVAILABLE (core.db) gates all uses
    # explicit None binding (vs suppress()) keeps the name defined so type
    # checkers don't flag uses as possibly-unbound
    # Assigning None over an imported class trips both [misc] (assign to a
    # type) and [assignment] (None vs type[Fernet]) — suppress both.
    Fernet = None  # type: ignore[assignment,misc]


def get_or_create_encryption_key():
    """Get the master key — now resolved by `ProxmoxVEx.core.keystore`.

    Kept as a back-compat shim so older imports (audit.py, plugins) keep
    working.  The actual resolution logic moved to keystore.load_master_key()
    which supports systemd LoadCredentialEncrypted, env vars, /etc/ProxmoxVEx/,
    user-config and the legacy CONFIG_DIR location (in priority order).

    (Stufe 1+2 of the security-review response).
    """
    if not ENCRYPTION_AVAILABLE:
        return None
    try:
        from ProxmoxVEx.core.keystore import load_master_key

        return load_master_key().key_b64
    except Exception as e:
        logging.error(f"[CONFIG] keystore.load_master_key() failed: {e}")
        return None


def get_fernet():
    """Get Fernet encryption instance"""
    # `Fernet is None` restates the ENCRYPTION_AVAILABLE correlation so the
    # checker knows the name is bound before the call below.
    if not ENCRYPTION_AVAILABLE or Fernet is None:
        return None

    key = get_or_create_encryption_key()
    if key:
        return Fernet(key)
    return None


def load_config():
    """Load configuration from SQLite database

    refactored to use SQLite
    Automatically migrates existing JSON/encrypted files on first run
    """
    logging.info("=== Loading config from SQLite ===")

    try:
        db = get_db()
        config = db.get_all_clusters()

        if config:
            logging.info(f"✓ Loaded {len(config)} clusters from SQLite: {list(config.keys())}")
            return config
        else:
            logging.info("No clusters in database yet")
            return {}
    except Exception as e:
        logging.error(f"Failed to load config from database: {e}")
        import traceback

        logging.error(traceback.format_exc())

        # Emergency fallback to legacy files
        logging.info("Attempting legacy fallback...")
        return _load_config_legacy()


def _load_config_legacy():
    """Legacy config loader - used as fallback if database fails

    Plain-JSON CONFIG_FILE (clusters.JSON) fallback dropped. The
    only legacy path still trusted here is the Fernet-encrypted .enc file (which
    was already encrypted-at-rest). A plain-text spill would defeat the whole
    SQLCipher migration done in v0.9.10. If both DB load and the .enc fallback
    fail, return empty and let the caller deal with it — operator has to fix the
    DB, not bring back a JSON file.
    """
    fernet = get_fernet()

    # Encrypted-only legacy fallback
    if fernet and os.path.exists(CONFIG_FILE_ENCRYPTED):
        try:
            with open(CONFIG_FILE_ENCRYPTED, "rb") as f:
                encrypted_data = f.read()
            decrypted_data = fernet.decrypt(encrypted_data)
            config = json.loads(decrypted_data.decode("utf-8"))
            if config:
                logging.info(f"✓ Loaded {len(config)} clusters from legacy encrypted file")
                return config
        except Exception as e:
            logging.error(f"Failed to load legacy encrypted config: {e}")

    return {}


def save_config():
    """Save configuration to SQLite database

    SQLite instead of JSON now
    """
    if not cluster_managers:
        logging.warning("save_config called with no clusters - skipping")
        return False

    try:
        db = get_db()

        for cluster_id, manager in cluster_managers.items():
            try:
                # Sanitize fallback_hosts
                fallback_hosts = getattr(manager.config, "fallback_hosts", []) or []
                if not isinstance(fallback_hosts, list):
                    fallback_hosts = []
                fallback_hosts = [str(h) for h in fallback_hosts if h]

                cluster_data = {
                    "name": manager.config.name,
                    "host": manager.config.host,
                    "user": manager.config.user,
                    "pass": manager.config.pass_,
                    "ssl_verification": getattr(manager.config, "ssl_verification", True),
                    "migration_threshold": getattr(manager.config, "migration_threshold", 30),
                    "migration_tolerance": getattr(manager.config, "migration_tolerance", 10),
                    "check_interval": getattr(manager.config, "check_interval", 300),
                    "auto_migrate": getattr(manager.config, "auto_migrate", False),
                    "balance_containers": getattr(manager.config, "balance_containers", False),
                    "balance_local_disks": getattr(manager.config, "balance_local_disks", False),
                    "proxlb_tags_enabled": bool(getattr(manager.config, "proxlb_tags_enabled", False)),
                    "dry_run": getattr(manager.config, "dry_run", False),
                    "enabled": getattr(manager.config, "enabled", True),
                    "ha_enabled": getattr(manager.config, "ha_enabled", False),
                    "fallback_hosts": fallback_hosts,
                    "ssh_user": getattr(manager.config, "ssh_user", ""),
                    "ssh_key": getattr(manager.config, "ssh_key", ""),
                    "ssh_port": getattr(manager.config, "ssh_port", 22),
                    "ha_settings": getattr(manager.config, "ha_settings", {}),
                    "excluded_nodes": getattr(manager.config, "excluded_nodes", []),
                    "api_token_user": getattr(manager.config, "api_token_user", ""),
                    "api_token_secret": getattr(manager.config, "api_token_secret", ""),
                    "cluster_type": getattr(manager, "cluster_type", "proxmox"),
                    "vnc_tunnel": bool(getattr(manager.config, "vnc_tunnel", False)),  # Apr 2026
                    # (#364) - load-balancer settings used to be set
                    # on the in-memory config object but never made it into the
                    # save dict, so they reverted on the next reload.
                    "predictive_balancing": bool(getattr(manager.config, "predictive_balancing", False)),
                    "predictive_threshold": float(getattr(manager.config, "predictive_threshold", 0.0) or 0.0),
                    "balance_cpu_weight": float(getattr(manager.config, "balance_cpu_weight", 1.0) or 1.0),
                    "balance_mem_weight": float(getattr(manager.config, "balance_mem_weight", 1.0) or 1.0),
                    "balance_io_weight": float(getattr(manager.config, "balance_io_weight", 1.0) or 1.0),
                    "cpu_baseline": getattr(manager.config, "cpu_baseline", "") or "",
                    "backup_sla_max_age_hours": int(getattr(manager.config, "backup_sla_max_age_hours", 0) or 0),
                    # Proxmox API port override (default 8006). Direct-TLS only.
                    "api_port": int(getattr(manager.config, "api_port", 8006) or 8006),
                }

                db.save_cluster(cluster_id, cluster_data)
            except Exception as e:
                logging.error(f"Error saving cluster {cluster_id}: {e}")
                continue

        logging.debug(f"Saved {len(cluster_managers)} clusters to SQLite")
        return True

    except Exception as e:
        logging.error(f"Failed to save config to database: {e}")
        return False


# ── spec 092/US085: boot-time env validation ──
# Misconfig must abort startup naming the variable and the fix — a typo'd
# DSN otherwise surfaces as a cryptic psycopg2 error at first query, and a
# bad port as a silent fallback to a port the operator didn't ask for.

_PORT_ENV_VARS = (
    "PROXMOXVEX_PORT",
    "PROXMOXVEX_HTTP_PORT",
    "PROXMOXVEX_VNC_WS_PORT",
    "PROXMOXVEX_SSH_WS_PORT",
)
# Kubernetes injects tcp://<cluster-ip>:<port> when a Service is named
# proxmoxvex — the same form app.py's runtime port parser accepts.
_K8S_PORT_RE = re.compile(r"^tcp://[^:]*:(\d+)$")


class ConfigError(Exception):
    """Fatal startup misconfiguration — carries the full actionable list."""


def validate_startup_config(env=None):
    """Validate env config before serving; return (errors, warnings).

    errors   — boot must abort; each names the variable + how to fix it.
    warnings — insecure defaults that still allow boot (logged loudly).
    """
    env = os.environ if env is None else env
    errors: list[str] = []
    warnings: list[str] = []

    # PostgreSQL is the only supported backend — anything else fails later
    # with a driver error that never mentions the env var.
    url = (env.get("PROXMOXVEX_DATABASE_URL") or "").strip()
    if url and not url.startswith(("postgres://", "postgresql://")):
        errors.append(
            "PROXMOXVEX_DATABASE_URL is not a PostgreSQL DSN — "
            "set e.g. postgresql://user:pass@host:5432/proxmoxvex (or unset for the localhost default)"
        )

    for var in _PORT_ENV_VARS:
        v = (env.get(var) or "").strip()
        if not v:
            continue
        m = _K8S_PORT_RE.match(v)
        raw = m.group(1) if m else v
        if not raw.isdigit() or not (1 <= int(raw) <= 65535):
            errors.append(f"{var}={v!r} is not a usable port — set an integer 1-65535 or unset it")

    # The shipped demo token secret forges demo sessions — fine for the
    # local sandbox it's meant for, dangerous anywhere reachable.
    from ProxmoxVEx.demo import DEMO_ENV_VAR

    if (env.get(DEMO_ENV_VAR) or "").lower() in ("1", "true", "yes"):
        secret = env.get("PROXMOXVEX_DEMO_TOKEN_SECRET", "demo-secret-change-in-production")
        if secret == "demo-secret-change-in-production":
            warnings.append(
                "PROXMOXVEX_DEMO_TOKEN_SECRET is the shipped default — demo sessions are forgeable; "
                "set a random value (openssl rand -hex 32) if this instance is reachable"
            )

    return errors, warnings


# ---------------------------------------------------------------------------
# spec 092/US092: read-only root filesystem support.
#
# When the container runs with `read_only: true`, every path the app writes
# to must be an explicit mount. The image carries a pristine plugin copy at
# /app/plugins-seed because a fresh /app/plugins volume starts empty and
# would shadow the shipped plugin set; ensure_plugins_seeded restores it on
# first boot only — an already-populated volume is never overwritten, so
# installed plugin upgrades stay authoritative.
# ---------------------------------------------------------------------------

PLUGINS_SEED_DIR = os.environ.get("PROXMOXVEX_PLUGINS_SEED", "/app/plugins-seed")


def writable_paths_report(paths):
    """Map each path -> True when it accepts writes. Used by the boot check
    to name the missing mount instead of failing deep inside a request."""
    report = {}
    for path, _label in paths:
        p = str(path)
        if os.access(p, os.W_OK):
            report[p] = True
            continue
        if os.path.exists(p):
            # An existing dir that isn't writable rejects writes outright —
            # don't soften that to a parent check.
            report[p] = False
            continue
        # A path may not exist yet on a writable parent — probe the parent.
        parent = os.path.dirname(p) or "."
        report[p] = os.path.exists(parent) and os.access(parent, os.W_OK)
    return report


def required_writable_paths():
    """The persistent/scratch paths ProxmoxVEx writes to at runtime — every
    entry must be a volume or tmpfs when the rootfs is read-only."""
    import tempfile

    from ProxmoxVEx.constants import CONFIG_DIR, LOG_DIR, PLUGINS_DIR

    root = os.path.abspath(".")
    return [
        (CONFIG_DIR, "config volume (settings, keys, backups)"),
        (os.path.join(root, LOG_DIR), "logs volume"),
        (os.path.join(root, PLUGINS_DIR), "plugins volume (install/update)"),
        (tempfile.gettempdir(), "tmpfs /tmp"),
    ]


def check_writable_paths(log=None):
    """Warn at boot when a required write path is unwritable — the operator
    sees the missing mount name, not a late crash mid-request. Returns the
    list of (path, label) that failed; non-fatal by design."""
    failed = []
    report = writable_paths_report(required_writable_paths())
    for path, label in required_writable_paths():
        if not report.get(str(path)):
            failed.append((str(path), label))
    if failed and log is not None:
        for path, label in failed:
            log.warning(
                "[STARTUP] %s is not writable (%s) — on a read-only rootfs "
                "deployment add a volume or tmpfs mount for this path",
                path,
                label,
            )
    return failed


def _plugin_manifest_meta(manifest_path):
    """Best-effort manifest read for the seed-sync — a missing/invalid
    manifest yields {} so the dir is treated as versionless."""
    try:
        return json.loads(manifest_path.read_text(encoding="utf-8"))
    except Exception:
        return {}


def _plugin_version_key(version):
    """Numeric-tuple version key for manifest compares ('1.2.10' -> (1, 2, 10)).
    Non-numeric fragments are ignored; equal prefixes compare equal."""
    return tuple(int(tok) for tok in re.findall(r"\d+", str(version)))


def _plugin_mutable_paths(manifest):
    """manifest.json `mutable_paths` — plugin-relative files/dirs the plugin
    may rewrite at runtime (state.json, data/ seeds). Normalised like
    plugin_delivery's verifier so 'data' also matches 'data/x/y'.

    config.json is always implicitly mutable: /api/plugins/<id>/config is
    the admin-facing settings editor, so the seed's default must never
    overwrite live settings on boot. Regression: SEC-019 stripped the
    shipped status_page auth_key and the next boot's seed-sync reset the
    admin-configured key to "" — every shipped plugin's config would
    regress the same way on each deploy."""
    declared = [
        str(p).strip().strip("/")
        for p in manifest.get("mutable_paths", [])
        if str(p).strip().strip("/")
    ]
    if "config.json" not in declared:
        declared.append("config.json")
    return declared


def _plugin_rel_mutable(rel, mutable):
    return any(rel == entry or rel.startswith(entry + "/") for entry in mutable)


def _plugin_files(root):
    """{rel_posix_path: Path} for real plugin files — interpreter bytecode
    (__pycache__/*.pyc) and the delivery integrity manifest are runtime
    artifacts, never synced or pruned."""
    out = {}
    for f in root.rglob("*"):
        rel = f.relative_to(root)
        if "__pycache__" in rel.parts or f.suffix in (".pyc", ".pyo") or f.name == "integrity.json":
            continue
        if f.is_file():
            out[rel.as_posix()] = f
    return out


def _seed_copy2(src, dst):
    """copy2 that survives foreign-owned targets: root-owned leftovers (from
    docker cp or an old root-running container) can't be opened for write,
    but unlink only needs the PARENT directory's write bit — swap the file.
    Without this the stale file survived every boot's sync silently
    (observed: demo's Sep-2026 rbac-explorer/ui.js and both instances'
    directory.json were root-owned, so the catalog could never refresh and
    the stale plugin code crashed on the newer ui.html)."""
    import shutil

    try:
        shutil.copy2(src, dst)
    except PermissionError:
        dst.unlink()
        shutil.copy2(src, dst)


def _sync_plugin_dir(seed_dir, target_dir):
    """Reconcile a shipped plugin dir with the image copy: copy new/changed
    files, delete files the image no longer ships, prune empty dirs. Paths
    declared `mutable_paths` in the INSTALLED manifest are preserved — the
    plugin may hold live runtime state there. Returns True on any change."""
    mutable = _plugin_mutable_paths(_plugin_manifest_meta(target_dir / "manifest.json"))
    seed_files = _plugin_files(seed_dir)
    changed = False
    # Delete volume files the image no longer ships (preserving mutables).
    for rel in _plugin_files(target_dir):
        if rel not in seed_files and not _plugin_rel_mutable(rel, mutable):
            try:
                (target_dir / rel).unlink()
                changed = True
            except OSError:
                pass
    # Copy new/changed files (byte-compare so mtimes never fake a sync).
    for rel, sf in seed_files.items():
        if _plugin_rel_mutable(rel, mutable):
            continue
        tf = target_dir / rel
        try:
            if not tf.is_file() or tf.read_bytes() != sf.read_bytes():
                tf.parent.mkdir(parents=True, exist_ok=True)
                _seed_copy2(sf, tf)
                changed = True
        except OSError:
            pass
    # Prune dirs emptied by the deletes (and stray empty dirs), keeping any
    # the seed still ships.
    seed_dirs = {str(p.relative_to(seed_dir).as_posix()) for p in seed_dir.rglob("*") if p.is_dir()}
    for d in sorted((p for p in target_dir.rglob("*") if p.is_dir()),
                    key=lambda p: len(p.parts), reverse=True):
        rel = d.relative_to(target_dir).as_posix()
        if rel not in seed_dirs and not _plugin_rel_mutable(rel, mutable):
            try:
                if not any(d.iterdir()):
                    d.rmdir()
                    changed = True
            except OSError:
                pass
    return changed


def ensure_plugins_seeded(plugins_dir=None, seed_dir=None):
    """Keep the plugins volume in sync with the image's shipped plugin set.

    Every dir in the seed is a free/shipped plugin (paid plugins are
    filtered out of the image and only ever arrive via license-server
    artifacts), so the image copy is authoritative: missing dirs are
    copied, stale files synced byte-for-byte, and files the image dropped
    are removed — EXCEPT paths declared `mutable_paths` in the installed
    manifest (live plugin state) and except when the installed dir's
    manifest reports a NEWER version (an artifact-installed upgrade of a
    same-named plugin would otherwise be downgraded).

    directory.json is the exception: it is app-owned catalog metadata
    (regenerated at build time by generate_plugin_directory.py) and is
    refreshed from the seed on EVERY boot when it differs. Without this, an
    image upgrade leaves the stale volume catalog in place and retired paid
    plugins (e.g. apc-ups) keep resurfacing in /api/plugins as undeletable
    "download" entries."""
    import shutil

    from ProxmoxVEx.constants import PLUGINS_DIR

    target = Path(plugins_dir) if plugins_dir else Path(PLUGINS_DIR)
    seed = Path(seed_dir) if seed_dir else Path(PLUGINS_SEED_DIR)
    if not seed.is_dir():
        return False
    if not target.is_dir():
        # A missing plugins dir only appears on layouts without the baked
        # tree — create it when the parent is writable (fresh volume root).
        try:
            target.mkdir(parents=True)
        except OSError:
            return False
    changed = False
    for entry in seed.iterdir():
        dest = target / entry.name
        if entry.is_dir():
            if not dest.is_dir():
                # Missing dir (new shipped plugin, e.g. rockstor) or a stray
                # same-named file — the seed copy wins either way.
                if dest.exists():
                    try:
                        dest.unlink()
                    except OSError:
                        continue
                try:
                    shutil.copytree(entry, dest)
                    changed = True
                except OSError:
                    pass
                continue
            # Existing dir: skip only when the installed copy reports a
            # NEWER version — artifact-installed upgrades stay authoritative.
            seed_v = _plugin_version_key(
                _plugin_manifest_meta(entry / "manifest.json").get("version"))
            dest_v = _plugin_version_key(
                _plugin_manifest_meta(dest / "manifest.json").get("version"))
            if seed_v >= dest_v and _sync_plugin_dir(entry, dest):
                changed = True
        elif not dest.exists():
            try:
                shutil.copy2(entry, dest)
                changed = True
            except OSError:
                pass
    seed_catalog = seed / "directory.json"
    target_catalog = target / "directory.json"
    if seed_catalog.is_file():
        try:
            if (
                not target_catalog.exists()
                or target_catalog.read_bytes() != seed_catalog.read_bytes()
            ):
                _seed_copy2(seed_catalog, target_catalog)
                changed = True
        except OSError:
            # Unwritable plugins volume — catalog stays stale but boot must
            # not fail over a best-effort metadata refresh.
            pass
    return changed
