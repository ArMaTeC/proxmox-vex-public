# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/core/scan_import.py
# Project:     ProxmoxVEx
# Version:     1.2.698
# Build:       2026.11.17
# Description: Scanner report import (report ingestion).
# Usage:       import ProxmoxVEx.core.scan_import
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-11-17
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Scanner report import (report ingestion).

Nov 2026 — operators often already run Trivy/Grype/Nuclei/Nessus/OpenVAS
against their guests and services; this module normalizes those reports into
the shared scan_findings model (host, port/service, name, severity, cvss,
cve_ids, description, refs, tool) so imported vulns dedup and carry the same
lifecycle statuses as debsecan findings.

Formats are detected by content sniffing (not the filename), then parsed
by small per-format parsers. Only the
fields we actually use are extracted; anything unknown becomes severity
'info' with the raw name kept.
"""

import json
import logging
import xml.etree.ElementTree as ET
from urllib.parse import urlparse

log = logging.getLogger(__name__)

MAX_REPORT_BYTES = 20 * 1024 * 1024  # 20 MB — Nessus reports get big fast
MAX_FINDINGS = 5000

def _sev_norm(value):
    """Normalize a severity string to critical/high/medium/low/info.

    Word severities pass through the shared scale; bare numbers are treated
    as CVSS-like 0-10 scores (OpenVAS/GVM report format)."""
    if value is None:
        return "info"
    s = str(value).strip().lower()
    if not s:
        return "info"
    if s == "moderate":
        return "medium"
    if s in ("informational", "log", "note", "none"):
        return "info"
    if s in ("critical", "high", "medium", "low", "info"):
        return s
    try:
        n = float(s)
    except ValueError:
        return "info"
    if n >= 9.0:
        return "critical"
    if n >= 7.0:
        return "high"
    if n >= 4.0:
        return "medium"
    if n > 0:
        return "low"
    return "info"


# nessus uses its own 0-4 integer scale — it is NOT a CVSS score
_NESSUS_SEV = {"0": "info", "1": "low", "2": "medium", "3": "high", "4": "critical"}


def _sev_nessus(value):
    return _NESSUS_SEV.get(str(value).strip(), _sev_norm(value))


def _num(x):
    try:
        f = float(x)
    except (TypeError, ValueError):
        return None
    return round(f, 1)


def _host_from_url(url):
    try:
        return urlparse(url if "://" in url else f"//{url}", scheme="").hostname or url
    except Exception:
        return url


def _port_from_host(host, explicit=None):
    if explicit:
        try:
            return int(str(explicit).split("/")[0])
        except ValueError:
            return 0
    if not isinstance(host, str) or ":" not in host:
        return 0
    if "://" in host:
        try:
            return urlparse(host).port or 0
        except ValueError:
            return 0
    tail = host.rsplit(":", 1)[-1]
    return int(tail) if tail.isdigit() else 0


# --- JSON formats ----------------------------------------------------------


def _parse_trivy(doc):
    findings = []
    for res in doc.get("Results") or []:
        target = str(res.get("Target") or res.get("Class") or "trivy")
        for v in res.get("Vulnerabilities") or []:
            cvss = v.get("CVSS") or {}
            score = (
                _num((cvss.get("nvd") or {}).get("V3Score"))
                or _num((cvss.get("redhat") or {}).get("V3Score"))
                or _num((cvss.get("ghsa") or {}).get("V3Score"))
                or _num((cvss.get("nvd") or {}).get("V2Score"))
            )
            vid = str(v.get("VulnerabilityID") or "")
            findings.append({
                "host": target,
                "port": 0,
                "service": v.get("PkgName") or "",
                "name": f"{vid} {v.get('PkgName') or ''}".strip() or vid or "trivy finding",
                "severity": _sev_norm(v.get("Severity")),
                "cvss_score": score,
                "cve_ids": [vid] if vid.startswith("CVE-") else [],
                "description": (v.get("Description") or v.get("Title") or "")[:1000],
                "refs": [r for r in (v.get("References") or []) if isinstance(r, str)][:6],
                "tool": "trivy",
            })
    return findings


def _parse_grype(doc):
    findings = []
    source = doc.get("source") or {}
    target = (source.get("target") or {}).get("userInput") or source.get("type") or "grype"
    for m in doc.get("matches") or []:
        vul = m.get("vulnerability") or {}
        art = m.get("artifact") or {}
        score = None
        for c in vul.get("cvss") or []:
            if str(c.get("version", "")).startswith("3"):
                score = _num((c.get("metrics") or {}).get("baseScore"))
                if score is not None:
                    break
        if score is None:
            for c in vul.get("cvss") or []:
                score = _num((c.get("metrics") or {}).get("baseScore"))
                if score is not None:
                    break
        vid = str(vul.get("id") or "")
        pkg = art.get("name") or ""
        # GHSA-keyed matches carry their CVE aliases in relatedVulnerabilities
        cve_ids = [vid] if vid.startswith("CVE-") else [
            str(rv["id"]).upper() for rv in (vul.get("relatedVulnerabilities") or [])
            if str((rv or {}).get("id", "")).upper().startswith("CVE-")
        ][:3]
        findings.append({
            "host": str(target),
            "port": 0,
            "service": pkg,
            "name": f"{vid} {pkg}".strip() or vid or "grype finding",
            "severity": _sev_norm(vul.get("severity")),
            "cvss_score": score,
            "cve_ids": cve_ids,
            "description": (vul.get("description") or "")[:1000],
            "refs": [u for u in (vul.get("urls") or []) if isinstance(u, str)][:6] or ([vul.get("dataSource")] if vul.get("dataSource") else []),
            "tool": "grype",
        })
    return findings


def _parse_nuclei_obj(obj):
    info = obj.get("info") or {}
    cls = info.get("classification") or {}
    cves = cls.get("cve-id") or cls.get("cve_id") or []
    if isinstance(cves, str):
        cves = [cves]
    cves = [str(c).upper() for c in cves if str(c).upper().startswith("CVE-")]
    host = str(obj.get("matched-at") or obj.get("host") or "")
    name = str(info.get("name") or obj.get("template-id") or obj.get("templateID") or "nuclei finding")
    return {
        "host": _host_from_url(host) or host or "nuclei",
        "port": _port_from_host(host, obj.get("port")),
        "service": str(obj.get("type") or obj.get("scheme") or ""),
        "name": name,
        "severity": _sev_norm(info.get("severity")),
        "cvss_score": _num(cls.get("cvss-score") or cls.get("cvss_score")),
        "cve_ids": cves,
        "description": (info.get("description") or "")[:1000],
        "refs": [r for r in (info.get("reference") or []) if isinstance(r, str)][:6],
        "tool": "nuclei",
    }


def _parse_nuclei(content):
    text = content.decode("utf-8", "replace").strip()
    findings = []
    try:
        doc = json.loads(text)
        if isinstance(doc, list):
            return [_parse_nuclei_obj(o) for o in doc if isinstance(o, dict)]
        if isinstance(doc, dict):
            return [_parse_nuclei_obj(doc)]
    except json.JSONDecodeError:
        pass
    for line in text.splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            obj = json.loads(line)
        except json.JSONDecodeError:
            continue
        if isinstance(obj, dict):
            findings.append(_parse_nuclei_obj(obj))
    return findings


# --- XML formats -----------------------------------------------------------
# stdlib ElementTree: expat does not resolve external entities (no XXE file
# exfil) and Python >=3.11's expat caps entity amplification (billion-laughs
# safe). File is additionally size-capped at the endpoint.


def _parse_nessus(root):
    findings = []
    for host_el in root.iter("ReportHost"):
        host = host_el.get("name") or "nessus"
        for item in host_el.iter("ReportItem"):
            cves = [c.text.strip().upper() for c in item.iter("cve")
                    if c.text and c.text.strip().upper().startswith("CVE-")]
            cvss = _num(item.findtext("cvss3_base_score")) or _num(item.findtext("cvss_base_score"))
            desc = " ".join((item.findtext("description") or "").split())[:1000]
            refs = [r.text.strip() for r in item.iter("reference")
                    if r.text and r.text.strip().startswith("http")][:6]
            see_also = (item.findtext("see_also") or "").split()
            refs += [u for u in see_also if u.startswith("http")][: max(0, 6 - len(refs))]
            findings.append({
                "host": host,
                "port": _port_from_host(None, item.get("port")),
                "service": item.get("svc_name") or item.get("protocol") or "",
                "name": (item.get("pluginName") or "nessus finding")[:300],
                "severity": _sev_nessus(item.get("severity")),
                "cvss_score": cvss,
                "cve_ids": cves[:10],
                "description": desc,
                "refs": refs,
                "tool": "nessus",
            })
    return findings


def _parse_openvas(root):
    findings = []
    for res in root.iter("result"):
        host_el = res.find("host")
        host = ""
        if host_el is not None:
            host = (host_el.text or "").strip()
            if not host:
                host_el = host_el.find("hostname")
                host = (host_el.text or "").strip() if host_el is not None else ""
        nvt = res.find("nvt")
        cve_ids = []
        if nvt is not None:
            cve_txt = (nvt.findtext("cve") or "").strip()
            if cve_txt and cve_txt.upper() != "NOVECTOR":
                cve_ids = [c.strip().upper() for c in cve_txt.replace(";", ",").split(",")
                           if c.strip().upper().startswith("CVE-")]
        qod = res.find("qod")
        if qod is not None and (qod.findtext("type") or "") == "false_positive":
            continue  # openvas already judged it an FP — don't import noise
        findings.append({
            "host": host or "openvas",
            "port": _port_from_host(None, res.findtext("port")),
            "service": (res.findtext("port") or "").split("/")[-1] if res.findtext("port") else "",
            "name": (res.findtext("name") or "openvas finding")[:300],
            "severity": _sev_norm(res.findtext("severity")),
            "cvss_score": _num(res.findtext("severity")),
            "cve_ids": cve_ids[:10],
            "description": " ".join((res.findtext("description") or "").split())[:1000],
            "refs": [],
            "tool": "openvas",
        })
    return findings


# --- detection + dispatch ---------------------------------------------------


def _looks_like_nuclei(obj):
    return isinstance(obj, dict) and (
        "template-id" in obj or "templateID" in obj or ("info" in obj and "matched-at" in obj)
    )


def detect_report_format(content, filename=""):
    """Sniff the report format: returns
    'trivy'|'grype'|'nuclei'|'nessus'|'openvas'|None."""
    head = content[:8192].lstrip()
    if not head:
        return None

    if head[:1] in (b"{", b"["):
        try:
            doc = json.loads(content)
        except (json.JSONDecodeError, UnicodeDecodeError):
            doc = None
        if isinstance(doc, dict):
            if isinstance(doc.get("Results"), list) and ("SchemaVersion" in doc or "Artifacts" in doc):
                return "trivy"
            if isinstance(doc.get("matches"), list) and ("source" in doc or "descriptor" in doc or "distro" in doc):
                return "grype"
            if _looks_like_nuclei(doc):
                return "nuclei"
        elif isinstance(doc, list) and doc and _looks_like_nuclei(doc[0]):
            return "nuclei"
        if doc is None:
            # nuclei streams JSONL — try the first non-empty line
            for line in content.splitlines():
                line = line.strip()
                if not line:
                    continue
                try:
                    if _looks_like_nuclei(json.loads(line)):
                        return "nuclei"
                except json.JSONDecodeError:
                    pass
                break

    if head[:1] == b"<" or filename.lower().endswith((".xml", ".nessus")):
        if b"NessusClientData" in head or filename.lower().endswith(".nessus"):
            return "nessus"
        if b"<report" in head or b"get_reports_response" in head or b"<omp" in head:
            return "openvas"
    return None


def parse_scan_report(content, filename=""):
    """Returns (format, [finding dicts]). Raises ValueError on unknown/corrupt
    input. Findings are capped at MAX_FINDINGS."""
    fmt = detect_report_format(content, filename)
    if fmt is None:
        raise ValueError("unsupported report format (expected Trivy, Grype, Nuclei JSON or Nessus/OpenVAS XML)")

    if fmt in ("trivy", "grype"):
        try:
            doc = json.loads(content)
        except (json.JSONDecodeError, UnicodeDecodeError) as e:
            raise ValueError(f"invalid {fmt} JSON report: {e}") from e
        findings = _parse_trivy(doc) if fmt == "trivy" else _parse_grype(doc)
    elif fmt == "nuclei":
        findings = _parse_nuclei(content)
    else:
        try:
            root = ET.fromstring(content)
        except ET.ParseError as e:
            raise ValueError(f"invalid {fmt} XML report: {e}") from e
        findings = _parse_nessus(root) if fmt == "nessus" else _parse_openvas(root)

    if not findings:
        raise ValueError(f"no findings parsed from {fmt} report")

    return fmt, findings[:MAX_FINDINGS]
