# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/core/cve_enrich.py
# Project:     ProxmoxVEx
# Version:     1.2.701
# Build:       2026.11.17
# Description: CVE enrichment via the OSV.dev batch API.
# Usage:       import ProxmoxVEx.core.cve_enrich
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-11-17
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""CVE enrichment via the OSV.dev batch API.

Nov 2026 — debsecan only yields Debian's 3-level urgency (low/medium/high),
which routinely undersells real-world risk (a Debian-"low" can be CVSS 9.x).
Normalize every finding to a real CVSS score, backed by the free
OSV.dev `querybatch` endpoint
(no API key, one POST per 100 CVEs).

Design notes:

- Results are cached in the `cve_enrichment` DB table (7d positive / 1d
  negative TTL) so rescans stay fast and repeated scans don't hammer the API.
- The caller passes `air_gap=True` when the server setting is on — air-gapped
  installs must not emit outbound traffic.
- Everything here is best-effort: a network/API failure must never break a
  CVE scan response.
"""

import json
import logging
import math
from datetime import datetime, timedelta

import requests

log = logging.getLogger(__name__)

OSV_BATCH_URL = "https://api.osv.dev/v1/querybatch"
OSV_BATCH_SIZE = 100
HTTP_TIMEOUT = 10
CACHE_TTL_DAYS = 7
FAILED_TTL_DAYS = 1

_SEVERITY_FROM_SCORE = ((9.0, "critical"), (7.0, "high"), (4.0, "medium"), (0.1, "low"))


def score_to_severity(score):
    """Normalize a CVSS base score to a severity band (CVSS v3 bands)."""
    if score is None:
        return "unknown"
    for threshold, label in _SEVERITY_FROM_SCORE:
        if score >= threshold:
            return label
    return "none"


# --- CVSS v3.1 base score -------------------------------------------------
# Self-contained implementation of the CVSS v3.1 base-score formula so we
# don't drag in another dependency for one equation.

_CVSS31 = {
    "AV": {"N": 0.85, "A": 0.62, "L": 0.55, "P": 0.20},
    "AC": {"L": 0.77, "H": 0.44},
    "PR_U": {"N": 0.85, "L": 0.62, "H": 0.27},  # PR when Scope = Unchanged
    "PR_C": {"N": 0.85, "L": 0.68, "H": 0.50},  # PR when Scope = Changed
    "UI": {"N": 0.85, "R": 0.62},
    "CIA": {"H": 0.56, "L": 0.22, "N": 0.0},
}


def _roundup(x):
    return math.ceil(round(x, 5) * 10) / 10.0


def cvss31_base_score(vector):
    """Compute the CVSS v3.x base score from a vector string like
    'CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:H'. Returns None on parse
    failure."""
    try:
        parts = dict(p.split(":", 1) for p in vector.split("/") if ":" in p)
        scope_changed = parts["S"] == "C"
        c = _CVSS31["CIA"][parts["C"]]
        i = _CVSS31["CIA"][parts["I"]]
        a = _CVSS31["CIA"][parts["A"]]
        isc_base = 1 - (1 - c) * (1 - i) * (1 - a)
        impact = (
            7.52 * (isc_base - 0.029) - 3.25 * (isc_base - 0.02) ** 15
            if scope_changed
            else 6.42 * isc_base
        )
        pr = _CVSS31["PR_C" if scope_changed else "PR_U"][parts["PR"]]
        exploitability = (
            8.22
            * _CVSS31["AV"][parts["AV"]]
            * _CVSS31["AC"][parts["AC"]]
            * pr
            * _CVSS31["UI"][parts["UI"]]
        )
        if impact <= 0:
            return 0.0
        if scope_changed:
            return _roundup(min(1.08 * (impact + exploitability), 10))
        return _roundup(min(impact + exploitability, 10))
    except (KeyError, ValueError, ZeroDivisionError):
        return None


# --- CVSS v2 base score ---------------------------------------------------

_CVSS2 = {
    "AV": {"L": 0.395, "A": 0.646, "N": 1.0},
    "AC": {"H": 0.35, "M": 0.61, "L": 0.71},
    "Au": {"M": 0.45, "S": 0.56, "N": 0.704},
    "CIA": {"N": 0.0, "P": 0.275, "C": 0.66},
}


def cvss2_base_score(vector):
    """Compute the CVSS v2 base score from 'AV:N/AC:L/Au:N/C:P/I:P/A:P'."""
    try:
        parts = dict(p.split(":", 1) for p in vector.split("/") if ":" in p)
        c, i, a = (_CVSS2["CIA"][parts[k]] for k in ("C", "I", "A"))
        impact = 10.41 * (1 - (1 - c) * (1 - i) * (1 - a))
        exploitability = (
            20
            * _CVSS2["AV"][parts["AV"]]
            * _CVSS2["AC"][parts["AC"]]
            * _CVSS2["Au"][parts["Au"]]
        )
        f = 0.0 if impact == 0 else 1.176
        return round((0.6 * impact + 0.4 * exploitability - 1.5) * f, 1)
    except (KeyError, ValueError):
        return None


def _parse_osv_vuln(vuln):
    """Extract the fields we persist from an OSV `vuln` record."""
    refs = [r.get("url") for r in vuln.get("references", []) if r.get("url")][:6]
    summary = (vuln.get("summary") or "").strip()
    if not summary:
        summary = ((vuln.get("details") or "").strip().split("\n") or [""])[0][:300]

    # Best CVSS vector wins: prefer v3, fall back to v2. v4-only records keep
    # the vector but no score (v4's lookup-table scoring isn't implemented).
    score, vector = None, None
    for want, calc in (("CVSS_V3", cvss31_base_score), ("CVSS_V2", cvss2_base_score)):
        for sev in vuln.get("severity", []):
            if sev.get("type") == want and sev.get("score"):
                vector = sev["score"]
                score = calc(vector)
                if score is not None:
                    break
        if score is not None:
            break
    if vector is None:
        for sev in vuln.get("severity", []):
            if sev.get("score"):
                vector = sev["score"]
                break

    severity = score_to_severity(score)
    if severity == "unknown":
        # Some ecosystems (e.g. GHSA) expose a qualitative rating instead of
        # a computable vector — map it into the same severity scale.
        ds = (vuln.get("database_specific") or {}).get("severity") or ""
        ds = ds.lower()
        severity = {
            "critical": "critical",
            "high": "high",
            "moderate": "medium",
            "medium": "medium",
            "low": "low",
        }.get(ds, "unknown")

    return {
        "cvss_score": score,
        "cvss_vector": vector,
        "severity": severity,
        "summary": summary,
        "refs": refs,
    }


def _osv_batch_lookup(cve_ids):
    """Query OSV for a list of CVE ids. Returns {cve_id: enrichment-or-None}."""
    out = {}
    for i in range(0, len(cve_ids), OSV_BATCH_SIZE):
        chunk = cve_ids[i : i + OSV_BATCH_SIZE]
        resp = requests.post(
            OSV_BATCH_URL,
            json={"queries": [{"id": c} for c in chunk]},
            timeout=HTTP_TIMEOUT,
        )
        resp.raise_for_status()
        results = (resp.json() or {}).get("results", [])
        for cve_id, entry in zip(chunk, results, strict=False):
            vuln = entry.get("vuln") if isinstance(entry, dict) else None
            out[cve_id] = _parse_osv_vuln(vuln) if vuln else None
    return out


def enrich_cve_ids(cve_ids, db=None, air_gap=False):
    """Return {cve_id: {'cvss_score','severity','summary','refs','source'}}.

    Serves from the cve_enrichment cache first; missing/stale IDs are fetched
    in batches and written back. `air_gap` short-circuits all network access.
    Never raises — returns whatever is available.
    """
    cve_ids = sorted({c for c in cve_ids if isinstance(c, str) and c.startswith("CVE-")})
    if not cve_ids or air_gap:
        return {}

    if db is None:
        try:
            from ProxmoxVEx.core.db import get_db

            db = get_db()
        except Exception as e:
            log.warning(f"[CVE] enrichment: no db for cache ({e})")
            db = None

    now = datetime.now()
    result, missing = {}, list(cve_ids)

    if db is not None:
        try:
            covered = set()
            for cve_id, row in db.get_cve_enrichment(cve_ids).items():
                try:
                    fetched = datetime.fromisoformat(str(row.get("fetched_at") or ""))
                except ValueError:
                    continue
                ttl = FAILED_TTL_DAYS if row.get("failed") else CACHE_TTL_DAYS
                if now - fetched < timedelta(days=ttl):
                    covered.add(cve_id)
                    # failed rows are a negative cache: they suppress refetch
                    # but contribute nothing to the result
                    if not row.get("failed"):
                        result[cve_id] = {
                            "cvss_score": row.get("cvss_score"),
                            "severity": row.get("severity"),
                            "summary": row.get("summary") or "",
                            "refs": json.loads(row.get("refs") or "[]"),
                            "source": row.get("source") or "cache",
                        }
            missing = [c for c in cve_ids if c not in covered]
        except Exception as e:
            log.warning(f"[CVE] enrichment cache read failed: {e}")
            result, missing = {}, list(cve_ids)

    if not missing:
        return result

    try:
        fresh = _osv_batch_lookup(missing)
    except Exception as e:
        log.warning(f"[CVE] OSV enrichment lookup failed ({len(missing)} ids): {e}")
        return result

    for cve_id, data in fresh.items():
        if data is not None:
            result[cve_id] = {**data, "source": "osv"}
        if db is not None:
            try:
                d = data or {}
                db.upsert_cve_enrichment(
                    cve_id,
                    cvss_score=d.get("cvss_score"),
                    cvss_vector=d.get("cvss_vector"),
                    severity=d.get("severity"),
                    summary=d.get("summary"),
                    refs=json.dumps(d.get("refs") or []),
                    source="osv",
                    failed=0 if data is not None else 1,
                )
            except Exception as e:
                log.warning(f"[CVE] enrichment cache write failed for {cve_id}: {e}")

    return result


def query_pkg_vulns(pairs, air_gap=False):
    """Query OSV for vulnerabilities affecting a set of installed packages.

    pairs: [(ecosystem, name, version)] — the guest-side alternative to
    debsecan: works for any OSV-supported ecosystem (Debian, Ubuntu,
    Alpine, AlmaLinux, Rocky Linux, SUSE, ...).
    Returns {name: [cve_ids]} for packages with at least one CVE.
    Never raises — returns {} on any failure (incl. air-gap mode).
    """
    if air_gap or not pairs:
        return {}
    keys = list({(e, n, v) for e, n, v in pairs if e and n and v})
    out = {}
    for i in range(0, len(keys), OSV_BATCH_SIZE):
        chunk = keys[i:i + OSV_BATCH_SIZE]
        try:
            resp = requests.post(
                OSV_BATCH_URL,
                json={"queries": [
                    {"package": {"name": n, "ecosystem": e}, "version": v}
                    for e, n, v in chunk
                ]},
                timeout=HTTP_TIMEOUT,
            )
            resp.raise_for_status()
            results = (resp.json() or {}).get("results", [])
        except Exception as e:
            log.warning(f"[CVE] osv package query failed: {e}")
            break  # offline/rate-limited — keep whatever we already have
        for (_e, name, _v), entry in zip(chunk, results, strict=False):
            vulns = entry.get("vulns") if isinstance(entry, dict) else None
            if not vulns:
                continue
            ids = {
                v["id"] for v in vulns
                if isinstance(v.get("id"), str) and v["id"].startswith("CVE-")
            }
            if ids:
                out[name] = sorted(set(out.get(name, [])) | ids)
    return out
