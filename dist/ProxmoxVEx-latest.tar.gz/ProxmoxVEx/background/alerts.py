# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/background/alerts.py
# Project:     ProxmoxVEx
# Version:     1.2.303
# Build:       2026.09.04
# Description: ProxmoxVEx Alert Monitoring - Layer 7
# Docs:        https://proxmoxvex.local/docs
# Generated:   2026-09-04
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""
ProxmoxVEx Alert Monitoring - Layer 7
Background alert checking and notification.
"""

import html as html_lib  # Aliased so we don't shadow local `html` vars
import json
import logging
import os
import threading
import time
import uuid
from datetime import datetime

from ProxmoxVEx.api.helpers import load_server_settings, save_server_settings
from ProxmoxVEx.constants import (
    ALERTS_CONFIG_FILE,
    GITHUB_TOKEN,
    GITHUB_VERSION_URL,
    ProxmoxVEx_VERSION,
)
from ProxmoxVEx.core.db import get_db
from ProxmoxVEx.globals import (
    _alert_last_sent,
    _notification_handlers,
    cluster_managers,
)
from ProxmoxVEx.updater.github import github_headers
from ProxmoxVEx.utils.concurrent import run_concurrent  # H5: parallel backup-store scan
from ProxmoxVEx.utils.email import send_email


def load_alerts_config():
    """Load alerts configuration from SQLite database.

    Cluster-level alerts (created via the per-cluster UI under
    Automation → Alerts) live in the `cluster_alerts` table. The legacy `alerts`
    table contains old global-style rows. The background check loop used to
    only read `alerts`, which is why nothing ever fired for users who created
    alerts in the new UI. Now we read both, prefer cluster_alerts, and inject
    `cluster_id` from the table column when missing in the JSON config.
    """
    defaults = {"alerts": [], "enabled": True}
    out = []
    seen_ids = set()

    # Primary source — cluster_alerts (populated by /api/clusters/<id>/alerts)
    try:
        db = get_db()
        cur = db.conn.cursor()
        cur.execute("SELECT cluster_id, alert_type, config, enabled FROM cluster_alerts")
        for row in cur.fetchall():
            try:
                cfg = json.loads(row["config"] or "{}")
            except Exception as _e:
                continue
            if not cfg:
                continue
            cfg.setdefault("id", row["alert_type"])
            cfg.setdefault("cluster_id", row["cluster_id"])
            # row['enabled'] wins over a stale config payload
            cfg["enabled"] = bool(row["enabled"]) and cfg.get("enabled", True)
            if not cfg.get("metric"):
                continue  # incomplete row — skip
            out.append(cfg)
            seen_ids.add(cfg.get("id"))
    except Exception as e:
        logging.debug(f"[alerts] cluster_alerts read failed: {e}")

    # Legacy source — `alerts` table. Only include rows that look fully
    # populated (skip the empty-`type` stubs from old migrations).
    try:
        db = get_db()
        legacy = db.get_all_alerts() or {}
        for aid, a in legacy.items():
            if aid in seen_ids:
                continue
            metric = a.get("metric") or a.get("type")
            if not metric:
                continue
            a.setdefault("id", aid)
            a.setdefault("metric", metric)
            out.append(a)
    except Exception as e:
        logging.error(f"Error loading alerts from database: {e}")
        if os.path.exists(ALERTS_CONFIG_FILE):
            try:
                with open(ALERTS_CONFIG_FILE) as f:
                    return {**defaults, **json.load(f)}
            except Exception as _e:
                pass

    return {"alerts": out, "enabled": True}


def save_alerts_config(config):
    """Save alerts configuration to SQLite database

    SQLite migration
    """
    try:
        db = get_db()

        # Convert alerts list to dict format for database
        alerts_dict = {}
        for alert in config.get("alerts", []):
            alert_id = alert.get("id", str(uuid.uuid4()))
            alerts_dict[alert_id] = alert

        db.save_all_alerts(alerts_dict)
        return True
    except Exception as e:
        logging.error(f"Error saving alerts config: {e}")
        return False


_last_eval = {}  # alert_id -> dict with ts/cluster/metric/value/triggered/reason
_last_tick_at = 0.0


def _record_eval(alert_id, **fields):
    """keep the last evaluation per alert so the diagnostics
    endpoint can show *why* something fired (or didn't). Customer-facing
    saves us a round-trip when triaging 'no alerts arrive' tickets."""
    snap = {"ts": time.time(), "alert_id": alert_id}
    snap.update(fields)
    _last_eval[alert_id] = snap


def check_and_send_alerts():
    """Check all alert conditions and send notifications.

    This runs periodically in a background thread
    Checks CPU, RAM, Disk usage against thresholds
    """
    global _last_tick_at
    _last_tick_at = time.time()
    config = load_alerts_config()
    if not config.get("enabled"):
        return

    settings = load_server_settings()
    recipients = settings.get("alert_email_recipients", [])
    cooldown = settings.get("alert_cooldown", 300)

    # (#213) - don't bail just because email isn't configured.
    # Webhook-only setups (ntfy, slack) were silently skipped because of this.
    current_time = time.time()
    alerts_list = config.get("alerts", [])
    logging.info(
        f"[AlertCheck] tick: {len(alerts_list)} alert(s), {len(cluster_managers)} cluster(s) loaded, recipients={len(recipients)}"
    )

    for alert in alerts_list:
        alert_id = alert.get("id", "")
        if not alert.get("enabled", True):
            _record_eval(alert_id, reason="disabled")
            continue

        cluster_id = alert.get("cluster_id", "")
        metric = alert.get("metric", "")  # cpu, memory, disk
        threshold = alert.get("threshold", 80)
        operator = alert.get("operator", ">")  # >, <, =
        target_type = alert.get("target_type", "cluster")  # cluster, node, vm
        target_id = alert.get("target_id", "")  # node name or vmid

        # Check cooldown
        # May 2026: include alert_id so a warning rule and a critical rule
        # on the same metric don't poison each other's cooldown.
        alert_key = f"{alert_id}:{cluster_id}:{target_type}:{target_id}:{metric}"
        if alert_key in _alert_last_sent and current_time - _alert_last_sent[alert_key] < cooldown:
            _record_eval(
                alert_id,
                reason=f"cooldown ({int(current_time - _alert_last_sent[alert_key])}s of {cooldown}s)",
                cluster_id=cluster_id,
                metric=metric,
            )
            continue

        # Get current value
        current_value = None
        target_name = target_id

        if cluster_id not in cluster_managers:
            _record_eval(
                alert_id,
                reason=f"cluster '{cluster_id}' not loaded (have: {sorted(cluster_managers.keys())})",
                cluster_id=cluster_id,
                metric=metric,
                target_type=target_type,
            )
            logging.info(f"[AlertCheck]   skip {alert_id}: cluster '{cluster_id}' not in cluster_managers")
            continue

        if cluster_id in cluster_managers:
            manager = cluster_managers[cluster_id]

            # Guard the metric lookup. The old code called
            # `manager.get_cluster_summary()` and `manager.get_resources()`
            # neither method exists on ProxmoxVExManager. Cluster + VM targets
            # have been raising AttributeError since this was written.
            try:
                if target_type == "cluster":
                    # Aggregate cluster CPU/mem/disk from per-node status
                    per_node = manager.get_node_status() or {}
                    online = [n for n in per_node.values() if (n.get("status") or "").lower() == "online"]
                    if metric == "cpu" and online:
                        current_value = sum(n.get("cpu_percent", 0) for n in online) / len(online)
                    elif metric == "memory":
                        used = sum(n.get("mem_used", 0) for n in online)
                        total = sum(n.get("mem_total", 0) for n in online)
                        if total > 0:
                            current_value = used / total * 100
                    elif metric == "disk":
                        used = sum(n.get("disk_used", 0) for n in online)
                        total = sum(n.get("disk_total", 0) for n in online)
                        if total > 0:
                            current_value = used / total * 100
                    elif metric == "temperature":
                        # #601 — hottest cached node temperature (°C) across the cluster.
                        # Populated by the 5-min metrics collector; we never SSH here.
                        temps = []
                        for nname in list(getattr(manager, "_node_temp_cache", {}) or {}):
                            tv = manager.get_cached_node_temp(nname)
                            if tv is not None:
                                temps.append(tv)
                        if temps:
                            current_value = max(temps)
                    elif metric in ("backup_sla_breached_pct", "backup_sla_compliance_pct"):
                        # Backup SLA-aware alerts. Run the same
                        # eval as the /backup-sla endpoint and feed the % into
                        # the alerting pipeline. Threshold direction depends on
                        # which metric: breached_pct >= X (warn when too many
                        # behind), compliance_pct <= Y (warn when below floor).
                        try:
                            # We can't call the Flask endpoint directly from a thread.
                            # Inline the same evaluation: threshold + storage scan.
                            import time as _t

                            max_age = int(getattr(manager.config, "backup_sla_max_age_hours", 0) or 0)
                            if max_age > 0:
                                _now = int(_t.time())
                                _max_s = max_age * 3600
                                vms = manager.get_vm_resources() or []
                                # H5 (scale audit): the backup-store walk (per node →
                                # per backup storage → /content) is serial and can take
                                # minutes on big PBS/NFS stores; backups change slowly, so
                                # re-running it on every 60s alert tick stalled the whole
                                # alert loop. Cache the last-backup map (10-min TTL,
                                # regardless of whether an alert fired) + fan the per-node
                                # walk out over the pool.
                                _bk_ent = getattr(manager, "_backup_sla_cache", None)
                                last_bk = None
                                if _bk_ent and (_t.time() - _bk_ent[0]) < 600:
                                    last_bk = _bk_ent[1]
                                else:
                                    _fresh = {}
                                    _scan_ok = False
                                    try:
                                        sess = manager._create_session()
                                        nr = sess.get(
                                            f"https://{manager.host}:{manager.api_port}/api2/json/nodes", timeout=10
                                        )
                                        nodes = (
                                            [
                                                n["node"]
                                                for n in (nr.json().get("data") or [])
                                                if n.get("status") == "online"
                                            ]
                                            if nr.status_code == 200
                                            else []
                                        )

                                        def _scan_node(nd, sess=sess, manager=manager):
                                            out = {}
                                            try:
                                                sr = sess.get(
                                                    f"https://{manager.host}:{manager.api_port}/api2/json/nodes/{nd}/storage",
                                                    timeout=10,
                                                )
                                                if sr.status_code != 200:
                                                    return out
                                                for st in sr.json().get("data") or []:
                                                    if "backup" not in (st.get("content") or ""):
                                                        continue
                                                    sname = st.get("storage")
                                                    if not sname:
                                                        continue
                                                    try:
                                                        cr = sess.get(
                                                            f"https://{manager.host}:{manager.api_port}/api2/json/nodes/{nd}/storage/{sname}/content",
                                                            params={"content": "backup"},
                                                            timeout=(5, 30),
                                                        )
                                                    except Exception as _e:
                                                        continue
                                                    if cr.status_code != 200:
                                                        continue
                                                    for it in cr.json().get("data") or []:
                                                        ts = int(it.get("ctime") or 0)
                                                        vmid = str(it.get("vmid") or "")
                                                        if not ts or not vmid:
                                                            continue
                                                        volid = it.get("volid") or ""
                                                        vt = (
                                                            "qemu"
                                                            if "qemu" in volid or "/vm/" in volid
                                                            else "lxc"
                                                            if "lxc" in volid or "/ct/" in volid
                                                            else ""
                                                        )
                                                        if not vt:
                                                            continue
                                                        k = (vt, vmid)
                                                        if k not in out or ts > out[k]:
                                                            out[k] = ts
                                            except Exception as _e:
                                                pass
                                            return out

                                        for _res in run_concurrent(
                                            [lambda n=nd: _scan_node(n) for nd in nodes], timeout=120
                                        ):
                                            if not _res:
                                                continue
                                            for k, ts in _res.items():
                                                if k not in _fresh or ts > _fresh[k]:
                                                    _fresh[k] = ts
                                        # R1 (regression fix): only authoritative if we actually reached
                                        # the cluster. Caching an empty map from a failed/zero-node walk
                                        # fired a false "100% breached" SLA alert for the full 10-min TTL.
                                        _scan_ok = nr.status_code == 200 and bool(nodes)
                                    except Exception as _e:
                                        _scan_ok = False
                                    if _scan_ok:
                                        last_bk = _fresh
                                        manager._backup_sla_cache = (_t.time(), _fresh)
                                    elif _bk_ent:
                                        last_bk = _bk_ent[1]  # fall back to last good result, never alert on bad data
                                    # else: scan failed + no prior result → last_bk stays None → skip eval this tick
                                if last_bk is not None:
                                    breached = 0
                                    ok_cnt = 0
                                    total = 0
                                    for r in vms:
                                        if r.get("type") not in ("qemu", "lxc"):
                                            continue
                                        total += 1
                                        ts = last_bk.get((r.get("type"), str(r.get("vmid", ""))), 0)
                                        if not ts or (_now - ts) >= _max_s:
                                            breached += 1
                                        else:
                                            ok_cnt += 1
                                    if total > 0:
                                        if metric == "backup_sla_breached_pct":
                                            current_value = round(100 * breached / total, 1)
                                        else:
                                            current_value = round(100 * ok_cnt / total, 1)
                        except Exception as _e:
                            logging.debug(f"[AlertCheck] backup_sla eval failed: {_e}")
                    try:
                        target_name = manager.config.name
                    except Exception as _e:
                        target_name = cluster_id

                elif target_type == "node":
                    node_summary = manager.get_node_summary(target_id) or {}
                    if metric == "cpu":
                        current_value = node_summary.get("cpu", 0) * 100
                    elif metric == "memory":
                        mem = node_summary.get("memory", {}) or {}
                        if mem.get("total", 0) > 0:
                            current_value = (mem.get("used", 0) / mem.get("total", 1)) * 100
                    elif metric == "disk":
                        rootfs = node_summary.get("rootfs", {}) or {}
                        if rootfs.get("total", 0) > 0:
                            current_value = (rootfs.get("used", 0) / rootfs.get("total", 1)) * 100
                    elif metric == "temperature":
                        # #601 — cached hottest-sensor temp (°C) for this node.
                        current_value = manager.get_cached_node_temp(target_id)

                elif target_type == "vm":
                    # Was `manager.get_resources()` which doesn't exist; the
                    # actual VM enumerator on ProxmoxVExManager is get_vm_resources()
                    fetch = getattr(manager, "get_vm_resources", None)
                    vms = fetch() if callable(fetch) else []
                    for res in vms or []:
                        if str(res.get("vmid")) == str(target_id):
                            if metric == "cpu":
                                current_value = res.get("cpu", 0) * 100
                            elif metric == "memory":
                                if res.get("maxmem", 0) > 0:
                                    current_value = (res.get("mem", 0) / res.get("maxmem", 1)) * 100
                            elif metric == "disk" and res.get("maxdisk", 0) > 0:
                                current_value = (res.get("disk", 0) / res.get("maxdisk", 1)) * 100
                            target_name = res.get("name", target_id)
                            break
            except Exception as e:
                logging.warning(f"[AlertCheck]   alert {alert_id} metric lookup raised: {e}")
                _record_eval(
                    alert_id,
                    reason=f"metric lookup error: {e}",
                    cluster_id=cluster_id,
                    metric=metric,
                    target_type=target_type,
                )
                continue

        if current_value is None:
            _record_eval(
                alert_id,
                reason=f"metric '{metric}' returned no value for {target_type} '{target_id}'",
                cluster_id=cluster_id,
                metric=metric,
                target_type=target_type,
                target_id=target_id,
            )
            logging.info(f"[AlertCheck]   skip {alert_id}: {target_type} '{target_id}' / {metric} → no value")
            continue

        # Check condition
        triggered = False
        if (
            operator == ">"
            and current_value > threshold
            or operator == "<"
            and current_value < threshold
            or operator == ">="
            and current_value >= threshold
            or operator == "<="
            and current_value <= threshold
        ):
            triggered = True

        # #601 — temperature is an absolute °C reading, every other metric is a %.
        unit = "°C" if metric == "temperature" else "%"

        if not triggered:
            _record_eval(
                alert_id,
                reason=f"below threshold ({metric}={current_value:.1f}{unit} {operator} {threshold}{unit} → false)",
                cluster_id=cluster_id,
                metric=metric,
                current_value=round(current_value, 1),
                threshold=threshold,
                operator=operator,
                triggered=False,
            )

        if triggered:
            # Send alert
            alert_name = alert.get("name", f"{metric} Alert")
            subject = f"[ProxmoxVEx Alert] {alert_name}"
            body = f"""
Alert: {alert_name}
Target: {target_type.capitalize()} - {target_name}
Metric: {metric.upper()}
Condition: {metric} {operator} {threshold}{unit}
Current Value: {current_value:.1f}{unit}
Time: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}
Cluster: {cluster_id}

This is an automated alert from ProxmoxVEx.
"""
            # Escape user-controlled strings in the HTML email
            # (alert_name + target_name come from user-defined alert rules, target_type
            # from manager state, metric/operator from rule config). current_value +
            # threshold are floats so format-spec coercion already kills any payload.
            _esc = html_lib.escape
            html_body = f"""
<h2 style="color: #e74c3c;">⚠️ ProxmoxVEx Alert: {_esc(str(alert_name))}</h2>
<table style="border-collapse: collapse; width: 100%; max-width: 500px;">
<tr><td style="padding: 8px; border: 1px solid #ddd;"><strong>Target</strong></td><td style="padding: 8px; border: 1px solid #ddd;">{_esc(str(target_type).capitalize())} - {_esc(str(target_name))}</td></tr>
<tr><td style="padding: 8px; border: 1px solid #ddd;"><strong>Metric</strong></td><td style="padding: 8px; border: 1px solid #ddd;">{_esc(str(metric).upper())}</td></tr>
<tr><td style="padding: 8px; border: 1px solid #ddd;"><strong>Condition</strong></td><td style="padding: 8px; border: 1px solid #ddd;">{_esc(str(metric))} {_esc(str(operator))} {threshold}{unit}</td></tr>
<tr style="background-color: #fee2e2;"><td style="padding: 8px; border: 1px solid #ddd;"><strong>Current Value</strong></td><td style="padding: 8px; border: 1px solid #ddd;"><strong>{current_value:.1f}{unit}</strong></td></tr>
<tr><td style="padding: 8px; border: 1px solid #ddd;"><strong>Time</strong></td><td style="padding: 8px; border: 1px solid #ddd;">{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}</td></tr>
</table>
<p style="color: #666; font-size: 12px; margin-top: 20px;">This is an automated alert from ProxmoxVEx.</p>
"""

            # (#213) - honour the per-rule channel selection.
            # `channels` (new, list) takes precedence; fall back to legacy `action`.
            sel = alert.get("channels")
            if isinstance(sel, list):
                selected = [str(s) for s in sel]
            else:
                legacy = (alert.get("action") or "log").lower()
                if legacy == "email":
                    selected = ["email"]
                elif legacy == "all":
                    # old "fire everything" — keep broadcast (None = all webhooks)
                    selected = ["email", "__all_webhooks__"]
                else:  # 'log' or anything unknown
                    selected = []

            want_email = "email" in selected
            webhook_ids = [s for s in selected if s not in ("email", "log", "__all_webhooks__")]
            fire_all_webhooks = "__all_webhooks__" in selected

            sent_anywhere = False
            email_status = "not selected"
            if want_email and not recipients:
                email_status = "no recipients configured"
                logging.warning(f"[AlertCheck]   alert {alert_id} wants email but no alert_email_recipients set")
            elif want_email and recipients:
                success, error = send_email(recipients, subject, body, html_body)
                if success:
                    sent_anywhere = True
                    email_status = f"ok → {len(recipients)} recipient(s)"
                    logging.info(f"[AlertCheck]   alert {alert_id} email → ok ({len(recipients)})")
                elif error:
                    email_status = f"failed: {error}"
                    logging.warning(f"[AlertCheck]   alert {alert_id} email → FAILED: {error}")

            # #501: a rule may pin an explicit severity; otherwise derive it.
            _rule_sev = alert.get("severity")
            if _rule_sev and _rule_sev != "auto":
                severity = _rule_sev
            elif metric == "temperature":
                # #601 — absolute °C thresholds for auto-severity (not the %-based ladder)
                severity = "critical" if current_value >= 85 else "warning" if current_value >= 75 else "info"
            else:
                severity = "critical" if current_value > 90 else "warning" if current_value > 70 else "info"
            alert_data = {
                "alert_name": alert_name,
                "metric": metric,
                "operator": operator,
                "threshold": threshold,
                "current_value": round(current_value, 1),
                "target_type": target_type,
                "target_name": target_name,
                "cluster_id": cluster_id,
                "severity": severity,
                "timestamp": datetime.now().isoformat(),
                "message": f"{target_type.capitalize()} {target_name}: {metric} is {current_value:.1f}{unit} (threshold: {operator} {threshold}{unit})",
            }
            if _notification_handlers:
                for handler in _notification_handlers:
                    try:
                        handler(alert_data)
                    except Exception as he:
                        logging.debug(f"Notification handler error: {he}")

            webhook_status = "no webhook channels selected"
            if webhook_ids or fire_all_webhooks:
                try:
                    from ProxmoxVEx.utils.webhooks import send_to_channels

                    send_to_channels(alert_data, channel_ids=None if fire_all_webhooks else webhook_ids)
                    sent_anywhere = True
                    webhook_status = f"dispatched to {webhook_ids or 'all webhooks'}"
                    logging.info(f"[AlertCheck]   alert {alert_id} webhooks → {webhook_status}")
                except Exception as he:
                    webhook_status = f"dispatch error: {he}"
                    logging.warning(f"[AlertCheck]   alert {alert_id} webhooks → FAILED: {he}")

            # #501: persist this firing as an active incident (for ack + escalation)
            try:
                _upsert_active_alert(
                    alert_key, alert_id, alert_data, round(current_value, 1), threshold, operator, target_id
                )
            except Exception as _aae:
                logging.debug(f"[AlertCheck] active-alert persist failed: {_aae}")

            _record_eval(
                alert_id,
                triggered=True,
                current_value=round(current_value, 1),
                threshold=threshold,
                operator=operator,
                metric=metric,
                cluster_id=cluster_id,
                target_type=target_type,
                target_id=target_id,
                severity=severity,
                email=email_status,
                webhooks=webhook_status,
                sent=sent_anywhere,
            )

            # bump cooldown only if at least one destination ran (email OR webhook)
            # purely "log" rules should still respect cooldown, but we don't dedupe them
            if sent_anywhere or not selected:
                _alert_last_sent[alert_key] = current_time


# Alert check thread
_alert_thread = None
_alert_running = False

# (#331) - throttle the version poll. The main alert loop ticks every 60s
# but hitting GitHub that often would be silly. Keep a module-level timestamp and
# skip until `UPDATE_CHECK_INTERVAL` has passed.
# 2026-04-24: bumped to 24h after user feedback - once a day is plenty and keeps
# us well clear of any rate-limit suspicion from upstream mirrors.
UPDATE_CHECK_INTERVAL = 24 * 60 * 60  # 24 hours
_FIRST_CHECK_DELAY = 15 * 60  # wait 15min after process start before the first poll
_last_update_check_at = 0.0
_process_started_at = time.time()


def _parse_ver(v):
    try:
        parts = str(v).replace("Alpha ", "").replace("Beta ", "").split(".")
        return tuple(int(p) for p in parts if p.isdigit())
    except Exception as _e:
        return (0, 0)


def check_update_available_alert():
    """Poll version.json and send an email when a new release appears.

    Fires at most once per *new* version (dedup via server_settings.alert_last_notified_version).
    No-op when `alert_update_available` is False or there are no recipients.
    """
    global _last_update_check_at
    now = time.time()
    # don't hammer the mirror right on startup (server restarts shouldn't refire the poll)
    if _last_update_check_at == 0.0 and (now - _process_started_at) < _FIRST_CHECK_DELAY:
        return
    if now - _last_update_check_at < UPDATE_CHECK_INTERVAL:
        return
    _last_update_check_at = now

    try:
        settings = load_server_settings()
    except Exception as e:
        logging.debug(f"[update-alert] cannot load settings: {e}")
        return

    if not settings.get("alert_update_available"):
        return
    recipients = settings.get("alert_email_recipients") or []
    if not recipients:
        return

    remote = None
    try:
        import requests  # local import — background threads shouldn't block module load

        try:
            r = requests.get(GITHUB_VERSION_URL, headers=github_headers(GITHUB_TOKEN), timeout=10)
            if r.status_code == 200:
                remote = r.json()
        except Exception as _e:
            pass
    except Exception as e:
        logging.debug(f"[update-alert] fetch failed: {e}")
        return
    if not remote:
        return

    latest = remote.get("version", "")
    if not latest:
        return
    if _parse_ver(latest) <= _parse_ver(ProxmoxVEx_VERSION):
        return  # already on latest

    last_notified = settings.get("alert_last_notified_version") or ""
    if last_notified == latest:
        return  # already told the user about this one

    # compose + send
    release_date = remote.get("release_date") or ""
    changelog = remote.get("changelog", []) or []
    subject = f"[ProxmoxVEx] Update available — {latest}"
    body_lines = [
        f"A new ProxmoxVEx release is available: {latest}",
        f"Current version: {ProxmoxVEx_VERSION}",
        f"Released: {release_date}" if release_date else "",
        "",
        "Changelog:",
    ]
    body_lines += [f"  - {line}" for line in changelog[:10]]
    body_lines += ["", f"Download: {remote.get('download_url', '')}"]
    body = "\n".join([ln for ln in body_lines if ln is not None])
    # Changelog + version come from remote update server (version.JSON).
    # If GitHub-mirror is ever compromised an attacker could ship `<script>` inside
    # the release notes; escape them all before they hit the email's HTML body.
    download_url = remote.get("download_url", "")
    html_items = "".join(f"<li>{html_lib.escape(str(c))}</li>" for c in changelog[:10])
    html_body = (
        f"<h2>ProxmoxVEx update available</h2>"
        f"<p>A new release <b>{html_lib.escape(str(latest))}</b> is available.</p>"
        f"<p>Current: <code>{html_lib.escape(ProxmoxVEx_VERSION)}</code>"
        + (f" · Released: {html_lib.escape(str(release_date))}" if release_date else "")
        + "</p>"
        f"<ul>{html_items}</ul>"
        f'<p><a href="{html_lib.escape(str(download_url), quote=True)}">Release page</a></p>'
    )

    ok, err = send_email(recipients, subject, body, html_body)
    if ok:
        settings["alert_last_notified_version"] = latest
        try:
            save_server_settings(settings)
        except Exception as e:
            # non-fatal — we'll just re-notify next cycle
            logging.debug(f"[update-alert] could not persist last_notified_version: {e}")
        logging.info(f"[update-alert] sent notification for {latest}")
    elif err:
        logging.warning(f"[update-alert] email failed: {err}")


# 2026-04-24 (#213) - node up/down watcher. Background thread compares
# the current node status per cluster to the previous tick and fires an alert
# on transition. A small streak counter keeps short flaps (single missed poll)
# from spamming the on-call channel — default 3 consecutive misses = ~3 min.
_node_last_status = {}  # (cluster_id, node_name) -> 'online' | 'offline'
_node_offline_streak = {}  # (cluster_id, node_name) -> int
_NODE_OFFLINE_FLAP_THRESHOLD = 3


def check_node_status_transitions():
    try:
        settings = load_server_settings() or {}
    except Exception as _e:
        settings = {}
    if not settings.get("alert_node_status", True):
        return  # disabled by admin

    threshold = int(settings.get("alert_node_status_flap_threshold") or _NODE_OFFLINE_FLAP_THRESHOLD)
    recipients = settings.get("alert_email_recipients") or []

    for cluster_id, mgr in list(cluster_managers.items()):
        try:
            if not getattr(mgr, "is_connected", False):
                continue
            statuses = mgr.get_node_status() or {}
        except Exception as e:
            logging.debug(f"[NodeWatch] {cluster_id}: status fetch failed: {e}")
            continue

        for node, info in statuses.items():
            status = (info.get("status") or "").lower()
            if status not in ("online", "offline"):
                continue
            key = (cluster_id, node)
            prev = _node_last_status.get(key)

            # track streak
            if status == "offline":
                _node_offline_streak[key] = _node_offline_streak.get(key, 0) + 1
            else:
                _node_offline_streak[key] = 0

            # online -> offline: only fire once the streak crosses the flap threshold
            if prev == "online" and status == "offline" and _node_offline_streak[key] >= threshold:
                _emit_node_status_event(
                    cluster_id,
                    node,
                    "offline",
                    f"Node {node} is offline on cluster {cluster_id}",
                    "critical",
                    recipients,
                )
                _node_last_status[key] = "offline"
                continue

            # offline -> online recovery
            if prev == "offline" and status == "online":
                _emit_node_status_event(
                    cluster_id, node, "online", f"Node {node} recovered on cluster {cluster_id}", "info", recipients
                )
                _node_last_status[key] = "online"
                continue

            # first time we see this node — seed without firing
            if prev is None:
                # treat initial offline as "unseen yet" — don't spam on startup
                _node_last_status[key] = status


def _emit_node_status_event(cluster_id, node, new_status, message, severity, recipients):
    alert_data = {
        "alert_name": f"Node {node} {'DOWN' if new_status == 'offline' else 'recovered'}",
        "metric": "node_status",
        "target_type": "node",
        "target_name": node,
        "cluster_id": cluster_id,
        "severity": severity,
        "current_value": new_status,
        "timestamp": datetime.now().isoformat(),
        "message": message,
    }
    logging.warning(f"[NodeWatch] {message} (severity={severity})")

    if recipients:
        try:
            subject = f"[ProxmoxVEx] {alert_data['alert_name']}"
            body = f"{message}\n\nCluster: {cluster_id}\nNode: {node}\nTime: {alert_data['timestamp']}\n"
            # Alert_data['alert_name'] is user-defined; message comes
            # from the watcher (mostly safe) but cluster_id can be free-form. Escape
            # everything before it hits HTML.
            html_email = (
                f"<h2>{html_lib.escape(str(alert_data['alert_name']))}</h2>"
                f"<p>{html_lib.escape(str(message))}</p>"
                f"<p><b>Cluster:</b> {html_lib.escape(str(cluster_id))}<br>"
                f"<b>Time:</b> {html_lib.escape(str(alert_data['timestamp']))}</p>"
            )
            send_email(recipients, subject, body, html_email)
        except Exception as e:
            logging.debug(f"[NodeWatch] email failed: {e}")

    try:
        from ProxmoxVEx.utils.webhooks import send_to_channels

        send_to_channels(alert_data)
    except Exception as e:
        logging.debug(f"[NodeWatch] webhook dispatch failed: {e}")


_SESSION_CLEANUP_INTERVAL = 6 * 60 * 60  # every 6 hours
_last_session_cleanup_at = 0.0


def _periodic_session_cleanup():
    """expire stale sessions in the background. Was called on boot only,
    which left tokens alive for the full timeout (default 8h) after a logout/crash.
    Piggy-backs on the alert loop so we don't spawn yet another thread."""
    global _last_session_cleanup_at
    now = time.time()
    if now - _last_session_cleanup_at < _SESSION_CLEANUP_INTERVAL:
        return
    _last_session_cleanup_at = now
    try:
        from ProxmoxVEx.utils.auth import cleanup_expired_sessions

        cleanup_expired_sessions()
    except Exception as e:
        logging.debug(f"[SessionCleanup] background pass failed: {e}")


_AUDIT_CLEANUP_INTERVAL = 24 * 60 * 60  # daily
_last_audit_cleanup_at = 0.0


def _periodic_audit_cleanup():
    """M5 (scale audit): enforce audit_retention_days. cleanup_audit_log() was
    never called anywhere, so audit_log grew unbounded — bloating the DB and
    making the get_tasks LIKE fallback + audit search/integrity scans slower over
    the install lifetime. Daily, piggy-backing the alert loop; the prune runs
    off-hub via run_heavy_write (see audit.cleanup_audit_log)."""
    global _last_audit_cleanup_at
    now = time.time()
    if now - _last_audit_cleanup_at < _AUDIT_CLEANUP_INTERVAL:
        return
    _last_audit_cleanup_at = now
    try:
        from ProxmoxVEx.utils.audit import cleanup_audit_log

        cleanup_audit_log()
    except Exception as e:
        logging.debug(f"[AuditCleanup] background pass failed: {e}")


def _upsert_active_alert(alert_key, alert_id, alert_data, current_value, threshold, operator, target_id):
    """#501 — create/refresh the persisted active-alert row for an ongoing incident.
    First fire inserts; later fires only bump last_fired_at (used for auto-resolve)."""
    import uuid as _uuid

    from ProxmoxVEx.core.db import get_db

    now = datetime.now().isoformat()
    db = get_db()
    cur = db.conn.cursor()
    existing = cur.execute(
        "SELECT id FROM active_alerts WHERE alert_key = ? AND resolved_at IS NULL", (alert_key,)
    ).fetchone()
    sev = alert_data.get("severity", "warning")
    msg = alert_data.get("message", "")
    if existing:
        cur.execute(
            "UPDATE active_alerts SET last_fired_at=?, severity=?, message=?, current_value=?, threshold=?, operator=? WHERE id=?",
            (now, sev, msg, current_value, threshold, operator, existing[0]),
        )
    else:
        cur.execute(
            """INSERT INTO active_alerts
               (id, alert_key, alert_id, cluster_id, metric, target_type, target_id, target_name,
                severity, message, current_value, threshold, operator, triggered_at, last_fired_at, escalation_step)
               VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,0)""",
            (
                str(_uuid.uuid4())[:12],
                alert_key,
                alert_id,
                alert_data.get("cluster_id"),
                alert_data.get("metric"),
                alert_data.get("target_type"),
                ("" if target_id is None else str(target_id)),
                alert_data.get("target_name"),
                sev,
                msg,
                current_value,
                threshold,
                operator,
                now,
                now,
            ),
        )
    db.conn.commit()


def process_alert_lifecycle():
    """#501 — auto-resolve stale active alerts + escalate unacked ones. Runs each
    tick after check_and_send_alerts. Resolution is driven by last_fired_at going
    stale (independent of the per-rule cooldown); escalation by the rule's
    escalation steps measured from triggered_at. Acked incidents stop escalating."""
    from ProxmoxVEx.core.db import get_db

    cooldown = load_server_settings().get("alert_cooldown", 300)
    resolve_grace = max(cooldown * 2, 600) + 60  # no re-fire within this → cleared
    now = datetime.now()
    db = get_db()
    cur = db.conn.cursor()
    rows = cur.execute(
        """SELECT id, alert_key, alert_id, cluster_id, severity, message, target_name,
                  triggered_at, last_fired_at, acked_at, escalation_step
           FROM active_alerts WHERE resolved_at IS NULL"""
    ).fetchall()
    if not rows:
        return
    rules_by_id = None
    for r in rows:
        (
            aid,
            alert_key,
            rule_id,
            cluster_id,
            severity,
            message,
            target_name,
            triggered_at,
            last_fired_at,
            acked_at,
            esc_step,
        ) = r
        # 1) auto-resolve incidents that stopped re-firing
        try:
            lf = datetime.fromisoformat(last_fired_at) if last_fired_at else None
        except Exception as _e:
            lf = None
        if lf and (now - lf).total_seconds() > resolve_grace:
            cur.execute("UPDATE active_alerts SET resolved_at=?, resolved_by='auto' WHERE id=?", (now.isoformat(), aid))
            continue
        # 2) escalate unacked incidents along their rule's chain
        if acked_at:
            continue
        if rules_by_id is None:
            try:
                rules_by_id = {a.get("id"): a for a in (load_alerts_config().get("alerts", []) or [])}
            except Exception as _e:
                rules_by_id = {}
        steps = (rules_by_id.get(rule_id) or {}).get("escalation") or []
        if not isinstance(steps, list) or not steps:
            continue
        steps = steps[:10]  # F1 defense-in-depth: bound runaway/legacy chains (matches write-time cap)
        try:
            trg = datetime.fromisoformat(triggered_at) if triggered_at else now
        except Exception as _e:
            trg = now
        elapsed_min = (now - trg).total_seconds() / 60.0
        for idx, step in enumerate(steps):
            if not isinstance(step, dict):
                continue
            if idx < (esc_step or 0):
                continue
            try:
                after = float(step.get("after_minutes", 0))
            except Exception as _e:
                after = 0
            if elapsed_min < after:
                break  # ordered steps — later ones aren't due yet
            channels = step.get("channels") or []
            esc_data = {
                "alert_name": f"{message or 'Alert'} [escalation {idx + 1}]",
                "severity": severity,
                "cluster_id": cluster_id,
                "target_name": target_name,
                "message": message or "",
                "timestamp": now.isoformat(),
            }
            try:
                wh = [c for c in channels if c not in ("email", "log")]
                if wh:
                    from ProxmoxVEx.utils.webhooks import send_to_channels

                    send_to_channels(esc_data, channel_ids=wh)
                if "email" in channels:
                    recips = load_server_settings().get("alert_email_recipients", [])
                    if recips:
                        send_email(recips, f"[ESCALATION] {esc_data['alert_name']}", message or "", None)
                logging.info(f"[AlertEscalation] {alert_key} → step {idx + 1} via {channels}")
            except Exception as ee:
                logging.warning(f"[AlertEscalation] step {idx + 1} dispatch failed: {ee}")
            cur.execute(
                "UPDATE active_alerts SET escalation_step=?, last_escalated_at=? WHERE id=?",
                (idx + 1, now.isoformat(), aid),
            )
    db.conn.commit()


def alert_check_loop():
    """Background thread that checks alerts periodically"""
    global _alert_running
    _alert_running = True

    while _alert_running:
        try:
            check_and_send_alerts()
        except Exception as e:
            logging.error(f"Alert check error: {e}")
        try:
            process_alert_lifecycle()  # #501: auto-resolve + escalation
        except Exception as e:
            logging.debug(f"Alert lifecycle error: {e}")
        try:
            check_node_status_transitions()
        except Exception as e:
            logging.debug(f"Node status watcher error: {e}")
        try:
            check_update_available_alert()
        except Exception as e:
            logging.debug(f"Update alert check error: {e}")
        try:
            _periodic_session_cleanup()
        except Exception as e:
            logging.debug(f"session cleanup tick error: {e}")
        try:
            _periodic_audit_cleanup()
        except Exception as e:
            logging.debug(f"audit cleanup tick error: {e}")

        # Check every 60 seconds
        time.sleep(60)


def start_alert_thread():
    global _alert_thread
    if _alert_thread is None or not _alert_thread.is_alive():
        _alert_thread = threading.Thread(target=alert_check_loop, daemon=True)
        _alert_thread.start()
        logging.info("Alert monitoring thread started")
