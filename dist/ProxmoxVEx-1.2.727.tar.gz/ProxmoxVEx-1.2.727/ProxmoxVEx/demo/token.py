# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/demo/token.py
# Project:     ProxmoxVEx
# Version:     1.2.706
# Build:       2026.11.18
# Description: Short-lived HMAC tokens for anonymous demo entry.
# Usage:       import ProxmoxVEx.demo.token
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-11-18
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Short-lived HMAC tokens for anonymous demo entry.

These tokens are *not* sessions; they only prove that a visitor arrived
via the public demo CTA.  The real Flask session is created after the
token is exchanged at /api/demo/login.
"""

import base64
import hashlib
import hmac
import json
import time
from typing import Any

from ProxmoxVEx.demo import DEMO_TOKEN_SECRET, DEMO_USERNAME

# ID-0117: purpose/scope claim bound into every issued token and enforced on
# verify + at the demo/login consume point. Without it the payload carried no
# statement of what the token is *for*, so any future consumer sharing this
# token format/signing key could be replayed a demo token it should reject.
DEMO_TOKEN_PURPOSE = "demo-login"


def _secret() -> bytes:
    """Load or derive the demo token signing secret."""
    raw = DEMO_TOKEN_SECRET
    if raw:
        return raw.encode("utf-8")
    # Fallback only for local development; production must set the env var.
    return b"demo-local-dev-secret"


def issue_demo_token(ttl: int = 300) -> str:
    """Issue a URL-safe HMAC token for anonymous demo access."""
    payload = {
        "u": DEMO_USERNAME,
        "purpose": DEMO_TOKEN_PURPOSE,
        "iat": int(time.time()),
        "exp": int(time.time()) + ttl,
    }
    body = base64.urlsafe_b64encode(json.dumps(payload, separators=(",", ":")).encode("utf-8")).rstrip(b"=")
    sig = hmac.new(_secret(), body, hashlib.sha256).digest()
    token = body + b":" + base64.urlsafe_b64encode(sig).rstrip(b"=")
    return token.decode("ascii")


def verify_demo_token(token: str) -> dict[str, Any] | None:
    """Verify a demo token and return its payload, or None if invalid."""
    if not token or not isinstance(token, str):
        return None
    try:
        # UnicodeEncodeError (non-ASCII input) must not bubble up as a 500.
        body_b64, sig_b64 = token.encode("ascii").split(b":")
    except (ValueError, UnicodeEncodeError):
        return None
    expected_sig = hmac.new(_secret(), body_b64, hashlib.sha256).digest()
    try:
        provided_sig = base64.urlsafe_b64encode(base64.urlsafe_b64decode(sig_b64 + b"=="))
    except Exception:
        return None
    if not hmac.compare_digest(
        base64.urlsafe_b64encode(expected_sig).rstrip(b"="),
        provided_sig.rstrip(b"="),
    ):
        return None
    try:
        body = base64.urlsafe_b64decode(body_b64 + b"==")
        payload = json.loads(body.decode("utf-8"))
    except Exception:
        return None
    if not isinstance(payload, dict):
        return None
    # ID-0117: single-purpose binding — a correctly-signed token minted for
    # anything other than the demo login exchange (or carrying a non-demo
    # identity claim) is rejected even though the signature is valid.
    if payload.get("purpose") != DEMO_TOKEN_PURPOSE:
        return None
    if payload.get("u") != DEMO_USERNAME:
        return None
    exp = payload.get("exp")
    # A non-numeric exp (e.g. a string) would TypeError on the comparison —
    # treat any missing/non-numeric expiry as invalid instead of crashing.
    if not isinstance(exp, (int, float)) or exp < time.time():
        return None
    return payload
