# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/utils/json_logging.py
# Project:     ProxmoxVEx
# Version:     1.2.662
# Build:       2026.10.21
# Description: (spec 092/US023) Structured JSON logging across the
#              backend.
# Usage:       import ProxmoxVEx.utils.json_logging
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-10-21
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""(spec 092/US023) Structured JSON logging across the backend.

One JSON object per log line with consistent fields — ts, level, logger,
msg, request_id — so stdout/file output is machine-queryable in a SIEM
instead of needing regex parsing of free-text lines.

- ``JsonFormatter`` renders the record; secret-ish extras (password, token,
  secret, ticket) are redacted so a stray ``extra=`` can't leak creds.
- ``SecretRedactionFilter`` (ID-0714) is attached to every handler by
  ``install_json_logging`` and scrubs the *rendered* message + exception
  text for named secret fields, bearer/basic creds, DSN passwords, PEM
  blocks, and Fernet tokens — covering the text formatter and
  child-logger propagation, not just JSON output.
- ``RequestContextFilter`` hoists the ``request_id_var`` contextvar onto
  every record, so plain ``logging.*`` calls carry request_id once request
  middleware (spec 092/US024) sets it per request.
- ``make_formatter()`` returns JsonFormatter by default;
  ``PROXMOXVEX_LOG_FORMAT=text`` opts back into the human-readable line for
  local dev. ``install_json_logging()`` applies the formatter + filter to
  the root logger's handlers (adding a StreamHandler when none exist) so it
  works under any entrypoint — service main(), WSGI workers, or tests.
"""

import contextlib
import contextvars
import json
import logging
import os
import re

# Per-request correlation id; populated by request middleware (US024) and
# read by RequestContextFilter for every emitted record.
# annotated explicitly: default=None alone infers ContextVar[None], which
# makes every .set(str) call a type error
request_id_var: contextvars.ContextVar[str | None] = contextvars.ContextVar("proxmoxvex_request_id", default=None)


def set_request_id(value):
    """Store the current request id; returns a token for reset."""
    return request_id_var.set(value)


def get_request_id():
    return request_id_var.get()


class RequestContextFilter(logging.Filter):
    """Inject request_id (and future request-scoped fields) into records."""

    def filter(self, record):
        if getattr(record, "request_id", None) is None:
            record.request_id = request_id_var.get()
        return True


# --- ID-0714: secret redaction ------------------------------------------------
#
# The formatter already dropped secret-named `extra` keys, but creds most
# often leak through the *message text* — f-strings interpolating request
# data, connection strings in exception bodies, Authorization headers in
# debug output. SecretRedactionFilter scrubs the record itself (msg, args,
# rendered exception text) on the root logger, so every formatter —
# JSON and text — emits clean lines. Patterns are deliberately tight:
# named-field assignments, bearer/DSN credentials, PEM blocks, and Fernet
# tokens; matching wider would over-redact ordinary ops output.
_SECRET_FIELD = re.compile(
    r"(?i)\b(password|passwd|pwd|secret|api[_-]?key|private[_-]?key|"
    r"access[_-]?token|auth[_-]?token|refresh[_-]?token|authorization|"
    r"ticket|csrf[_-]?token|token)"
    r"(['\"]?\s*[=:]\s*['\"]?)([^\s,'\"}{]{4,})")
_SECRET_BEARER = re.compile(r"(?i)\b(bearer|basic)\s+[A-Za-z0-9._~+/=-]{8,}")
_SECRET_DSN = re.compile(r"(://[^:/\s]{1,64}:)([^@/\s]{3,})(@)")
_SECRET_PEM = re.compile(
    r"-----BEGIN [A-Z0-9 ]*PRIVATE KEY-----.*?-----END [A-Z0-9 ]*PRIVATE KEY-----",
    re.DOTALL)
_SECRET_FERNET = re.compile(r"(?<![\w])gAAAAA[\w=-]{40,}")


def _redact_text(text):
    if not isinstance(text, str):
        return text
    # bearer/basic FIRST — "Authorization: Bearer x.y" would otherwise
    # have the field pattern eat "Bearer" as the value and leak the token
    text = _SECRET_BEARER.sub(lambda m: m.group(1) + " ***", text)
    text = _SECRET_FIELD.sub(lambda m: m.group(1) + m.group(2) + "***", text)
    text = _SECRET_DSN.sub(r"\1***\3", text)
    text = _SECRET_PEM.sub("-----BEGIN PRIVATE KEY-----***-----END PRIVATE KEY-----", text)
    text = _SECRET_FERNET.sub("***", text)
    return text


class SecretRedactionFilter(logging.Filter):
    """ID-0714: scrub credential material out of every log record.

    Runs on the root logger before formatting, so msg + args + a
    pre-rendered exception are sanitized for BOTH the JSON and text
    formatters. Exception text is rendered once, scrubbed, and stashed
    on record.exc_text — Formatter.format() then uses it verbatim while
    record.exc_info stays set for JsonFormatter's `exc` field.
    """

    def filter(self, record):
        # scrub the RENDERED message — scrubbing msg and args separately
        # misses secrets that only appear once args are %-interpolated
        # into the format string (e.g. "password=%s", secret)
        with contextlib.suppress(Exception):
            record.msg = _redact_text(record.getMessage())
        record.args = ()
        if record.exc_info and not record.exc_text:
            with contextlib.suppress(Exception):
                rendered = logging.Formatter().formatException(record.exc_info)
                record.exc_text = _redact_text(rendered)
        return True


class JsonFormatter(logging.Formatter):
    REDACT = ("password", "token", "secret", "ticket")

    # param named `record` (not `rec`) to match Formatter.format's signature —
    # an override that renames it breaks keyword callers
    def format(self, record):
        out = {
            "ts": round(record.created, 3),
            "level": record.levelname,
            "logger": record.name,
            "msg": record.getMessage(),
            "request_id": getattr(record, "request_id", None),
        }
        for k, v in (getattr(record, "extra", None) or {}).items():
            if not any(s in k.lower() for s in self.REDACT):
                out[k] = v
        # hoist non-secret custom attributes set directly on the record —
        # the stdlib reserves its own names, so only extras lands here; the
        # explicit `extra` dict above is the sanctioned channel.
        if record.exc_info or record.exc_text:
            # exc_text may already hold SecretRedactionFilter's scrubbed
            # render — honour it instead of re-rendering the raw traceback
            out["exc"] = record.exc_text or self.formatException(record.exc_info)
        try:
            return json.dumps(out, default=str)
        except Exception:
            # A formatter must never raise — emit() would funnel the error
            # through handleError and, under a broken json.dumps, recurse.
            # Fall back to a minimal plain line so the record still lands.
            return '{"level": "ERROR", "msg": "log record serialization failed"}'


def make_formatter():
    """JSON by default; PROXMOXVEX_LOG_FORMAT=text restores the text line."""
    fmt = (os.environ.get("PROXMOXVEX_LOG_FORMAT") or "json").strip().lower()
    if fmt == "text":
        return logging.Formatter("[%(asctime)s] [%(name)s] %(levelname)s: %(message)s")
    return JsonFormatter()


def install_json_logging():
    """Apply the structured formatter + request filter to the root logger.

    Idempotent: swaps formatter on existing handlers (so a later
    logging.basicConfig's handlers get upgraded too) and adds a stream
    handler only when nothing is attached yet.
    """
    root = logging.getLogger()
    fmt = make_formatter()
    if not root.handlers:
        root.addHandler(logging.StreamHandler())
    for h in root.handlers:
        h.setFormatter(fmt)
        # ID-0714: the redaction filter must live on each HANDLER — a
        # filter on the root logger never sees records that propagate
        # up from child loggers (callHandlers bypasses logger filters)
        if not any(isinstance(f, SecretRedactionFilter) for f in h.filters):
            h.addFilter(SecretRedactionFilter())
    if not any(isinstance(f, RequestContextFilter) for f in root.filters):
        root.addFilter(RequestContextFilter())
