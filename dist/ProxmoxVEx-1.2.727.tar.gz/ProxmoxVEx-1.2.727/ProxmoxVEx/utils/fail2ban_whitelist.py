# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/utils/fail2ban_whitelist.py
# Project:     ProxmoxVEx
# Version:     1.2.727
# Build:       2026.11.23
# Description: Mutual fail2ban whitelisting for newly added clusters
#              (2026-11-23).
# Usage:       import ProxmoxVEx.utils.fail2ban_whitelist
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-11-23
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Mutual fail2ban whitelisting for newly added clusters (2026-11-23).

Why: the app's SSH layer probes auth methods (keyboard-interactive first for
ESXi) before password auth succeeds. On nodes where the sshd fail2ban jail
runs in aggressive mode that counts each pre-auth disconnect as a failure —
the ProxmoxVEx host got itself banned within a single poll cycle
(see ssh-auth.log "Connection closed by authenticating user ... [preauth]").

On cluster add / reconfigure we now, best-effort and fully non-fatal:
  1. On the node (if it runs fail2ban): whitelist OUR source IP — taken from
     $SSH_CONNECTION inside the session so it's the IP the node really sees
     (NAT-safe) — in EVERY active jail via a jail.d/*.local drop-in. `.local`
     is the highest-precedence config source in fail2ban's read order
     (jail.conf < jail.d/*.conf < jail.local < jail.d/*.local), so it wins
     over per-jail ignoreip set in jail.local. Current ignoreip entries are
     read back and merged so nothing existing is clobbered. A pre-existing
     ban of our IP is also lifted.
  2. Fan-out to sibling cluster nodes (corosync ring0_addrs) over the
     cluster-wide root SSH trust PVE sets up — per-node SSH polling would hit
     the same ban on each member otherwise.
  3. On the ProxmoxVEx host (if IT runs fail2ban): whitelist the node's IP
     the same way, so anything the node does back at us can't trip our jail.
"""

import contextlib
import logging
import os
import shutil
import socket
import subprocess
import threading

log = logging.getLogger(__name__)

# Drop-in name — a *.local file inside jail.d is read LAST, so per-jail
# ignoreip here beats jail.local. Rewritten wholesale on each run.
_DROPIN = "/etc/fail2ban/jail.d/zz-proxmoxvex-peers.local"

# Core whitelist pass. Expects PROXMOXVEX_PEER_IP in env, else learns the
# peer from $SSH_CONNECTION/$SSH_CLIENT (the source addr the host sees).
_CORE = r'''
PEER_IP="${PROXMOXVEX_PEER_IP:-}"
if [ -z "$PEER_IP" ]; then PEER_IP=$(echo "$SSH_CONNECTION" | awk '{print $1}'); fi
if [ -z "$PEER_IP" ]; then PEER_IP=$(echo "$SSH_CLIENT" | awk '{print $1}'); fi
if [ -z "$PEER_IP" ]; then echo "SKIP no-peer-ip"; exit 0; fi
JAILS=$(fail2ban-client status 2>/dev/null | sed -n 's/.*Jail list:[[:space:]]*//p' | tr -d ' \t' | tr ',' ' ')
if [ -z "$JAILS" ]; then echo "SKIP no-jails"; exit 0; fi
{
  echo "# ProxmoxVEx managed - peer whitelist (rewritten automatically; do not hand-edit)"
  echo "[DEFAULT]"
  echo "ignoreip = 127.0.0.1/8 ::1 $PEER_IP"
  for J in $JAILS; do
    CUR=$(fail2ban-client get "$J" ignoreip 2>/dev/null | sed -n 's/^[|`]-[[:space:]]*//p' | tr '\n' ' ')
    case " $CUR " in
      *" $PEER_IP "*) MERGED="$CUR" ;;
      *) MERGED="$CUR $PEER_IP" ;;
    esac
    echo "[$J]"
    echo "ignoreip = $MERGED"
  done
} > __PVEX_DROPIN__ || { echo "FAIL cannot-write-dropin"; exit 1; }
for J in $JAILS; do
  fail2ban-client set "$J" unbanip "$PEER_IP" >/dev/null 2>&1 || true
done
fail2ban-client reload >/dev/null 2>&1 || systemctl reload fail2ban >/dev/null 2>&1 || true
echo "OK $PEER_IP"
'''.replace("__PVEX_DROPIN__", _DROPIN)

# Remote wrapper: skip when fail2ban is absent/inactive, run the core pass,
# then fan out to sibling corosync members over the intra-cluster root trust.
_REMOTE_SCRIPT = r'''
if ! command -v fail2ban-client >/dev/null 2>&1; then
  echo "SKIP no-fail2ban"; exit 0
fi
systemctl is-active --quiet fail2ban 2>/dev/null || systemctl start fail2ban >/dev/null 2>&1 || true
fail2ban-client ping >/dev/null 2>&1 || { echo "SKIP fail2ban-not-ready"; exit 0; }

TMPS=/tmp/.pvex-f2b-whitelist.$$.sh
cat > "$TMPS" <<'PVEX_F2B_EOF'
''' + _CORE + r'''
PVEX_F2B_EOF
sh "$TMPS"

# Fan out to sibling cluster members (corosync ring0 addrs). PVE links node
# root SSH keys cluster-wide, so BatchMode key auth reaches them. Idempotent.
LOCAL_IP=$(echo "$SSH_CONNECTION" | awk '{print $3}')
SEEN=" $LOCAL_IP "
for NIP in $(awk '/ring0_addr/ {print $2}' /etc/pve/corosync.conf 2>/dev/null); do
  case "$SEEN" in *" $NIP "*) continue ;; esac
  SEEN="$SEEN$NIP "
  ssh -o BatchMode=yes -o ConnectTimeout=5 -o StrictHostKeyChecking=accept-new \
      "root@$NIP" "PROXMOXVEX_PEER_IP=$(echo "$SSH_CONNECTION" | awk '{print $1}') sh -s" \
      < "$TMPS" 2>/dev/null | sed "s/^/[peer $NIP] /" || echo "[peer $NIP] unreachable"
done
rm -f "$TMPS"
'''


def _resolve_ips(hosts: list) -> list:
    """hostnames/IPs -> unique IP list (best effort; unresolved entries skipped)."""
    out, seen = [], set()
    for h in hosts:
        if not h:
            continue
        h = h.strip("[]")  # bracketed IPv6
        ip: str | None
        try:
            ip = socket.gethostbyname(h)
        except Exception:
            ip = h if ":" in h else None  # keep literal IPv6, drop bad names
        if ip and ip not in seen:
            seen.add(ip)
            out.append(ip)
    return out


def _node_whitelist(manager) -> str:
    """Run the remote script on the cluster's entry host via its SSH creds."""
    ssh = manager._ssh_connect(manager.config.host, retries=1)
    if not ssh:
        return "skipped (ssh connect failed)"
    try:
        rc, out, err = manager._ssh_execute(ssh, _REMOTE_SCRIPT)
        # first line = primary host's verdict; later lines are peer fan-out
        return (out or err or f"rc={rc}").strip().split("\n")[0][:300]
    finally:
        with contextlib.suppress(Exception):
            ssh.close()


def _local_whitelist(peer_ips: list) -> str:
    """Whitelist the node IPs in the ProxmoxVEx HOST's own fail2ban, if any."""
    if not peer_ips:
        return "skipped (no peer ip)"
    if not shutil.which("fail2ban-client"):
        return "skipped (no fail2ban on this host)"
    r = subprocess.run(["systemctl", "is-active", "--quiet", "fail2ban"], capture_output=True)
    if r.returncode != 0:
        return "skipped (fail2ban inactive on this host)"
    # one _CORE pass per peer IP — keeps the ignoreip dedup check correct
    last = ""
    for ip in peer_ips:
        env = dict(os.environ, PROXMOXVEX_PEER_IP=ip)
        try:
            pr = subprocess.run(["sh", "-c", _CORE], capture_output=True, text=True, timeout=30, env=env)
            last = (pr.stdout or pr.stderr).strip().split("\n")[-1][:300]
        except Exception as e:
            last = f"skipped ({e})"
    return last


def ensure_mutual_fail2ban_whitelist(manager, username: str = "system") -> dict:
    """Best-effort mutual whitelist; never raises, never blocks callers."""
    result = {"node": "skipped", "local": "skipped"}
    try:
        peer_ips = _resolve_ips(
            [manager.config.host] + list(getattr(manager.config, "fallback_hosts", []) or [])
        )
        result["local"] = _local_whitelist(peer_ips)
        result["node"] = _node_whitelist(manager)
    except Exception as e:
        log.warning(f"[fail2ban-whitelist] {manager.config.name}: {e}")
    try:
        from ProxmoxVEx.utils.audit import log_audit

        log_audit(
            username,
            "cluster.fail2ban_whitelist",
            f"fail2ban mutual whitelist for {manager.config.name}: node={result['node']} local={result['local']}",
        )
    except Exception:
        pass
    log.info(f"[fail2ban-whitelist] {manager.config.name}: {result}")
    return result


def schedule_mutual_fail2ban_whitelist(manager, username: str = "system") -> None:
    """Fire-and-forget — SSH fan-out shouldn't hold up the API response."""
    threading.Thread(
        target=ensure_mutual_fail2ban_whitelist,
        args=(manager, username),
        daemon=True,
        name=f"f2b-whitelist-{manager.id}",
    ).start()


def schedule_cluster_sweep(username: str = "system") -> int:
    """Whitelist pass over EVERY registered cluster manager.

    Runs at each app startup and via the admin maintenance endpoint so
    clusters added before this feature existed get covered too. Idempotent —
    the node-side drop-in is rewritten wholesale each run, so repeats just
    converge (covers nodes that were offline, renamed hosts, IP changes).
    """
    from ProxmoxVEx.globals import cluster_managers

    scheduled = 0
    for cid, mgr in list(cluster_managers.items()):
        # ESXi cluster wrappers and demo mocks lack _ssh_connect/_ssh_execute —
        # ensure_* would no-op anyway, skip them quietly.
        if not (hasattr(mgr, "_ssh_connect") and hasattr(mgr, "_ssh_execute")):
            continue
        try:
            schedule_mutual_fail2ban_whitelist(mgr, username)
            scheduled += 1
        except Exception as e:
            log.warning(f"[fail2ban-whitelist] sweep skip {cid}: {e}")
    log.info(f"[fail2ban-whitelist] sweep scheduled for {scheduled} cluster(s)")
    return scheduled
