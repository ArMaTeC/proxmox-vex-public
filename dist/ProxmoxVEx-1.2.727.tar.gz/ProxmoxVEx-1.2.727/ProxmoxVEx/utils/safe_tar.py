# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/utils/safe_tar.py
# Project:     ProxmoxVEx
# Version:     0.5.9
# Build:
# Description: shared hardened tar extractor (ID-0102) — realpath
#              containment + file/dir-only + masked modes
# Usage:       from ProxmoxVEx.utils.safe_tar import extract_archive
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-11-19T15:00:00Z
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Hardened tar extraction shared by the update path
(api/settings.py) and paid-plugin delivery
(services/plugin_delivery.py).

Both callers previously rolled their own member filtering on top of
``tarfile.extractall`` — and the update path passed
``filter="fully_trusted"``, which performs NO tarfile-side checks and
relied entirely on its pre-filter being correct. This module is the
single hardened path: every member must resolve inside the destination
and be a plain file or directory; writing is done member-by-member so
no extractall filter semantics are involved at all (PEP 706 filters
only partially mitigate symlink-ordering tricks; never letting a link
member exist eliminates the class).
"""

import contextlib
import os
import shutil
import tarfile


def safe_members(tar, dest, strict=False):
    """Return the members allowed to extract into *dest*.

    A member is allowed iff its resolved target stays inside the real
    destination AND it is a plain file or directory — links, devices,
    fifos and other special members are dropped. Names alone are
    insufficient: a symlink member earlier in the archive would let a
    later member write outside through the link, so type and resolved
    path are both checked before any byte is written.

    ``strict=True`` raises ``ValueError`` on the first offending member
    instead of skipping it — used when an unexpected member means a
    tampered artifact (plugin delivery) rather than benign junk
    (upstream tarballs ship absolute-path symlinks that must simply be
    skipped).
    """
    dest_real = os.path.realpath(dest) + os.sep
    for member in tar.getmembers():
        target = os.path.realpath(os.path.join(dest, member.name))
        if not target.startswith(dest_real):
            if strict:
                raise ValueError(
                    f"Archive member escapes destination: {member.name}")
            continue
        if member.isfile() or member.isdir():
            yield member
        elif strict:
            raise ValueError(
                f"Archive member has disallowed type: {member.name}")


def extract_archive(tar, dest, strict=False):
    """Extract the validated members of *tar* into *dest*.

    Members are written one at a time: directories are mkdir'ed, files
    are streamed through ``extractfile`` with parent dirs created on
    demand (archives may omit intermediate dir members), and the mode
    is masked to permission bits so an archive can't smuggle
    setuid/setgid/sticky bits. Symlink/hardlink/device members simply
    never reach this loop (or raise under ``strict``).
    """
    members = list(safe_members(tar, dest, strict=strict))
    for member in members:
        target = os.path.join(dest, member.name)
        if member.isdir():
            os.makedirs(target, exist_ok=True)
            continue
        src = tar.extractfile(member)
        if src is None:
            continue
        os.makedirs(os.path.dirname(target), exist_ok=True)
        with src, open(target, "wb") as dst:
            shutil.copyfileobj(src, dst)
        with contextlib.suppress(OSError):
            os.chmod(target, member.mode & 0o777)
    return members


def extract_archive_file(archive_path, dest, strict=False):
    """Open ``archive_path`` as r:gz and extract it via
    :func:`extract_archive`. Convenience for the common .tar.gz case."""
    with tarfile.open(archive_path, "r:gz") as tar:
        return extract_archive(tar, dest, strict=strict)
