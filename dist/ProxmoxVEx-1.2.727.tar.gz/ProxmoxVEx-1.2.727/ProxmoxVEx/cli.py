# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/cli.py
# Project:     ProxmoxVEx
# Version:     1.2.706
# Build:       2026.11.18
# Description: spec 092/US087: disaster-recovery as a documented
#              command.
# Usage:       python3 ProxmoxVEx/cli.py
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-11-18
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""spec 092/US087: disaster-recovery as a documented command.

``python -m ProxmoxVEx.cli backup <dest.tar.gz>`` writes a tar.gz holding
a consistent ``pg_dump -Fc`` snapshot (``db.dump``), the config directory
(``config/`` — settings, keys, keystore material), a ``keystore/`` member
with the resolved master key (its preferred tiers live outside config/),
and a ``MANIFEST`` identifying the app version and DB backend that
produced it.

PostgreSQL is the only supported backend (the SQLite/SQLCipher path was
removed from ``core/db.py``), so backup/restore shells out to
``pg_dump``/``pg_restore`` — both must be on PATH (``postgresql-client``)
or the command refuses with the install remediation instead of a stack
trace. The MANIFEST ``db_backend`` stamp lets restore reject
foreign-backend archives loudly rather than "restoring" nothing
(roadmap ID-0317).

``python -m ProxmoxVEx.cli restore <src.tar.gz>`` gates on the archive
backend and manifest version (cross-version restores need ``--force`` —
schema epochs differ), unpacks config/, restores the bundled master key
to ``config/secret.key`` when no key file exists yet, and
``pg_restore --clean --if-exists`` the dump into the configured
PostgreSQL DSN.

``python -m ProxmoxVEx.cli drill [archive.tar.gz]`` proves restorability
without touching the live database (roadmap ID-0384): it produces a dump
(a fresh ``pg_dump -Fc``, or the ``db.dump`` member of a given archive),
``pg_restore``s it into a ``<dbname>_restore_drill`` scratch database on
the same cluster, compares public-table counts, then drops the scratch
database. A ``finally`` block drops the scratch DB even on failure — a
half-run never leaves a restorable snapshot behind.
"""

import argparse
import io
import json
import logging
import os
import re
import shutil
import subprocess
import sys
import tarfile
import tempfile
from datetime import UTC, datetime
from pathlib import Path

from ProxmoxVEx.constants import CONFIG_DIR, ProxmoxVEx_BUILD, ProxmoxVEx_VERSION


class RestoreError(Exception):
    """Fatal restore problem — carries the actionable reason."""


# ID-0317: backend stamp written into every MANIFEST. PG is the only
# supported engine since the SQLite/SQLCipher removal, but archives must
# self-describe so a restore can refuse a foreign-engine tarball instead
# of pg_restore-ing the wrong payload (or silently restoring nothing).
_DB_BACKEND = "postgresql"


# ID-0130: columns that must never hold plaintext. ``_decrypt`` silently
# passes unencrypted values through, so a leftover works at runtime while
# leaking raw secrets into every DB dump — ``verify-secrets`` scans each
# column and fails loudly on anything not aes256:/Fernet-shaped.
# table -> (pk column, secret columns)
_SECRET_COLUMNS: dict[str, tuple[str, tuple[str, ...]]] = {
    "clusters": ("id", ("pass_encrypted", "ssh_key_encrypted",
                        "api_token_secret_encrypted")),
    "users": ("username", ("totp_secret_encrypted",
                           "totp_pending_secret_encrypted")),
    "esxi_storages": ("id", ("password_encrypted",)),
    "pbs_servers": ("id", ("pass_encrypted", "api_token_secret_encrypted")),
    "vmware_servers": ("id", ("pass_encrypted",)),
    "azure_connections": ("id", ("secret_encrypted",)),
}
# server_settings keys whose VALUE is ciphertext in place (the save paths
# encrypt; ldap_bind_password migrated by ID-0124). Keys belong here only
# when the write path encrypts them — otherwise every plaintext value
# would be a false positive.
_SECRET_SETTINGS_KEYS = (
    "ldap_bind_password", "smtp_password", "acme_dns_rfc2136_secret")

# Fernet tokens base64-start with gAAA (0x80 version byte); aes256: rows
# are AES-256-GCM (nonce+ciphertext, base64). Anything else is plaintext.
_FERNET_TOKEN_RE = re.compile(r"^gAAA[A-Za-z0-9_\-]{20,}={0,2}$")


def _is_ciphertext(value: str) -> bool:
    """Recognise stored ciphertext without needing the key."""
    return value.startswith("aes256:") or bool(_FERNET_TOKEN_RE.match(value))


def verify_secrets() -> list[str]:
    """ID-0130: list ``table.column pk=…`` findings for secret columns
    holding plaintext instead of ciphertext. Empty list = clean."""
    from ProxmoxVEx.core.db import get_db

    db = get_db()
    findings: list[str] = []
    for table, (pk, columns) in _SECRET_COLUMNS.items():
        try:
            present = {
                row[0]
                for row in db.conn.execute(
                    "SELECT column_name FROM information_schema.columns "
                    "WHERE table_name = ?", (table,)).fetchall()
            }
        except Exception as exc:
            # information_schema probe failed — scan anyway, missing
            # columns surface per-column below.
            logging.debug("verify-secrets: column probe for %s: %s", table, exc)
            present = set(columns)
        for col in columns:
            if col not in present:
                continue  # pre-migration schema — nothing stored there
            try:
                rows = db.conn.execute(
                    f"SELECT {pk}, {col} FROM {table}").fetchall()
            except Exception as exc:
                logging.warning(
                    "verify-secrets: cannot read %s.%s: %s", table, col, exc)
                continue
            for row in rows:
                if row[1] and not _is_ciphertext(str(row[1])):
                    findings.append(f"{table}.{col} {pk}={row[0]!r}")
    for key in _SECRET_SETTINGS_KEYS:
        try:
            rows = db.conn.execute(
                "SELECT key, value FROM server_settings WHERE key = ?",
                (key,)).fetchall()
        except Exception as exc:
            logging.warning("verify-secrets: server_settings scan: %s", exc)
            break
        for row in rows:
            if row[1] and not _is_ciphertext(str(row[1])):
                findings.append(f"server_settings[{key}]")
    return findings


def _dsn() -> str:
    from ProxmoxVEx.core.db import _load_dotenv
    from ProxmoxVEx.core.db_pg import _pg_dsn

    # ID-0317: standalone CLI processes must load the app's project .env too;
    # otherwise a correct backup can silently target the default database.
    _load_dotenv()
    return _pg_dsn()


def _require_pg_tool(name: str) -> str:
    """Resolve a PostgreSQL client tool on PATH or fail with remediation
    (ID-0317 fail-loud). A bare FileNotFoundError traceback tells the
    operator nothing — tell them which package to install instead."""
    tool = shutil.which(name)
    if tool is None:
        raise RestoreError(
            f"{name} not found on PATH — install the PostgreSQL client tools "
            "(Debian/Ubuntu: `apt install postgresql-client`, "
            "RHEL/Fedora: `dnf install postgresql`) and retry"
        )
    return tool


def _run_pg_tool(argv: list, timeout: int = 600) -> None:
    """Run a pg_* client tool, surfacing ITS error on failure (ID-0317
    fail-loud). CalledProcessError's str() is only 'returned non-zero exit
    status N' — useless without pg_dump's 'connection refused' /
    'database does not exist' detail, so the stderr tail is carried."""
    tool = Path(argv[0]).name
    try:
        subprocess.run(argv, check=True, timeout=timeout, capture_output=True, text=True)
    except subprocess.TimeoutExpired as e:
        raise RestoreError(
            f"{tool} timed out after {timeout}s — the database may be too "
            "large for the default window or the server is stalled"
        ) from e
    except subprocess.CalledProcessError as e:
        detail = (e.stderr or e.stdout or "").strip()
        raise RestoreError(
            f"{tool} failed (exit {e.returncode})"
            + (f": {detail[-2000:]}" if detail else " — no output captured")
        ) from e


def create_backup(dest, config_dir=CONFIG_DIR) -> Path:
    """Write a backup archive: consistent DB dump + config dir + manifest."""
    # ID-0317: verify pg_dump exists BEFORE producing anything — a backup
    # that can't snapshot the DB must fail loudly, not half-write a tarball.
    pg_dump = _require_pg_tool("pg_dump")
    dest = Path(dest)
    dest.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory() as tmp:
        dump = Path(tmp) / "db.dump"
        # consistent snapshot — same custom format the pre-migration
        # backups use, restorable by pg_restore.
        _run_pg_tool([pg_dump, "-Fc", "-f", str(dump), _dsn()])
        if not dump.exists() or dump.stat().st_size == 0:
            raise RestoreError(f"pg_dump produced an empty/missing dump: {dump}")

        manifest = {
            "version": ProxmoxVEx_VERSION,
            "build": ProxmoxVEx_BUILD,
            "created": datetime.now(UTC).isoformat(),
            "db_backend": _DB_BACKEND,
        }
        with tarfile.open(dest, "w:gz") as tar:
            tar.add(dump, arcname="db.dump")
            cfg = Path(config_dir)
            if cfg.is_dir():
                tar.add(cfg, arcname="config")
            _add_keystore_material(tar)
            manifest_bytes = json.dumps(manifest, indent=2).encode()
            ti = tarfile.TarInfo("MANIFEST")
            ti.size = len(manifest_bytes)  # required — bare TarInfo sizes 0
            tar.addfile(ti, io.BytesIO(manifest_bytes))
    logging.info("[backup] wrote %s", dest)
    return dest


def _add_keystore_material(tar: tarfile.TarFile) -> None:
    """Bundle the resolved master key so a restore can decrypt cluster
    credentials (roadmap ID-0312). The keystore's preferred tiers
    (/etc/ProxmoxVEx/secret.key, systemd credentials, env vars) live
    OUTSIDE config/ — a config/-only archive restores rows nobody can
    read. The canonical key_b64 form is archived (the same encoding key
    files store) with a SOURCE note recording which tier supplied it.
    The archive already carries the full ciphertext DB, so the key adds
    no new trust boundary — encrypt the archive itself at rest."""
    try:
        from ProxmoxVEx.core.keystore import load_master_key

        mk = load_master_key()
    except Exception as exc:  # noqa: BLE001 — a missing keystore must not
        # abort the DB backup; the restore just can't decrypt creds.
        logging.warning("[backup] keystore unresolved — archive lacks key material: %s", exc)
        return
    note = (
        f"master key tier: {mk.source}"
        + (f" ({mk.source_path})" if mk.source_path else "")
        + "\nOn restore this lands in config/secret.key (legacy tier) "
        "only when no key file is already present.\n"
    ).encode()
    for name, payload in (
        ("keystore/master.key", mk.key_b64),
        ("keystore/SOURCE.txt", note),
    ):
        ti = tarfile.TarInfo(name)
        ti.size = len(payload)
        ti.mode = 0o600
        tar.addfile(ti, io.BytesIO(payload))


def check_archive(src) -> dict:
    """Read + return the archive MANIFEST — missing/bad/foreign-backend
    archives fail here (ID-0317)."""
    try:
        with tarfile.open(src) as tar:
            f = tar.extractfile("MANIFEST")
            if f is None:
                raise RestoreError(f"{src}: no MANIFEST — not a ProxmoxVEx backup archive")
            manifest = json.loads(f.read())
            names = tar.getnames()
    except (tarfile.TarError, KeyError, json.JSONDecodeError) as e:
        raise RestoreError(f"{src}: unreadable backup archive ({e})") from e

    # ID-0317 backend gate: the archive must carry a payload this install
    # can actually restore. A stamped backend must match; unstamped
    # (pre-marker) archives are inferred from their payload member — a
    # SQLite-era tarball restored onto PG would otherwise "succeed" while
    # leaving the database untouched.
    stamped = manifest.get("db_backend")
    if stamped is not None and stamped != _DB_BACKEND:
        raise RestoreError(
            f"{src}: archive backend is {stamped!r} but this install runs "
            f"{_DB_BACKEND} — restore it on a matching-engine install instead"
        )
    if "db.dump" not in names:
        hint = (
            "it carries a SQLite-era payload"
            if any(n.endswith((".sqlite3", ".sqlite", ".db")) for n in names)
            else "no db.dump member found"
        )
        raise RestoreError(
            f"{src}: not restorable on this install — {hint}; "
            f"expected a pg_dump archive member (backend {_DB_BACKEND})"
        )
    return manifest


def _safe_extract_config(tar, config_dir: Path):
    """Extract config/ members only, stripped of the prefix — a crafted
    archive member like config/../../etc/passwd must never escape the
    target dir."""
    target = config_dir.resolve()
    for m in tar.getmembers():
        if not m.name.startswith("config/") or m.name == "config/":
            continue
        rel = m.name[len("config/") :]
        dest_path = (target / rel).resolve()
        if not str(dest_path).startswith(str(target) + os.sep):
            raise RestoreError(f"archive member escapes config dir: {m.name}")
        if m.isdir():
            dest_path.mkdir(parents=True, exist_ok=True)
        elif m.isfile():
            # write the payload directly — no tar.extract path semantics,
            # so the config/ prefix can't leak into the target layout
            dest_path.parent.mkdir(parents=True, exist_ok=True)
            dest_path.write_bytes(tar.extractfile(m).read())
            os.chmod(dest_path, m.mode & 0o777)


def _key_already_resolvable(dest: Path) -> bool:
    """True when any keystore tier would already yield a key — mirrors
    _resolve()'s file/env/credential checks WITHOUT calling it (tier 6
    auto-GENERATES a key, which would then shadow the archived one)."""
    if os.environ.get("PROXMOXVEX_DB_KEY") or os.environ.get("PROXMOXVEX_KEY_FILE"):
        return True
    cred_dir = os.environ.get("CREDENTIALS_DIRECTORY")
    if cred_dir and (Path(cred_dir) / "db-key").is_file():
        return True
    return any(
        p.is_file()
        for p in (
            dest,
            Path("/etc/ProxmoxVEx/secret.key"),
            Path("~/.config/ProxmoxVEx/secret.key").expanduser(),
        )
    )


def _restore_keystore_material(tar, config_dir: Path) -> None:
    """Place the bundled master key at ``config/secret.key`` — the
    keystore's legacy fallback tier — when no key source already exists
    (roadmap ID-0312). Without it, a restore onto a fresh box yields a
    working DB full of undecryptable cluster credentials.
    Reading via extractfile keeps the fixed-destination write immune to
    member-name path tricks."""
    try:
        member = tar.getmember("keystore/master.key")
    except KeyError:
        return  # archive predates key bundling — nothing to place
    dest = Path(config_dir) / "secret.key"
    if _key_already_resolvable(dest):
        logging.info("[restore] a master key already resolves — archive key skipped")
        return
    f = tar.extractfile(member)
    if f is None:
        return
    dest.write_bytes(f.read())
    os.chmod(dest, 0o600)
    logging.warning(
        "[restore] master key restored to legacy path %s — move it to "
        "/etc/ProxmoxVEx/secret.key (tier 4) or a systemd credential",
        dest,
    )


def _psql_scalar(psql: str, dsn: str, sql: str) -> str:
    """Run a psql scalar query, fail-loud like _run_pg_tool (ID-0317)."""
    try:
        r = subprocess.run(
            [psql, dsn, "-Atc", sql],
            check=True, timeout=120, capture_output=True, text=True,
        )
    except subprocess.CalledProcessError as e:
        detail = (e.stderr or e.stdout or "").strip()
        raise RestoreError(
            f"psql failed (exit {e.returncode})"
            + (f": {detail[-2000:]}" if detail else " — no output captured")
        ) from e
    return r.stdout.strip()


def restore_drill(archive=None) -> None:
    """ID-0384 restore drill: dump → restore-scratch → compare → drop.

    The source database is never written; the scratch database is dropped
    in a ``finally`` block so a failed drill cannot leave a restorable
    snapshot (or a stray scratch DB) behind — the same scratch-only rule
    docs/backups.md mandates for every service's ``--drill``.
    """
    pg_restore = _require_pg_tool("pg_restore")
    psql = _require_pg_tool("psql")
    dsn = _dsn()
    # Maintenance commands run connected to the source DB (createdb/
    # dropdb can't target the DB you're connected to, and never need to
    # here — the scratch name is derived, not the source name).
    src_db = dsn.rsplit("/", 1)[-1].split("?", 1)[0]
    scratch_db = f"{src_db}_restore_drill"
    scratch_dsn = dsn.rsplit("/", 1)[0] + "/" + scratch_db
    tables_sql = (
        "select count(*) from information_schema.tables "
        "where table_schema='public'"
    )

    with tempfile.TemporaryDirectory() as tmp:
        if archive is not None:
            # Drill the real artifact — proves the shipped archive, not
            # just a fresh dump, restores. check_archive gates foreign
            # backends before any scratch DB exists.
            check_archive(archive)
            with tarfile.open(archive) as tar:
                tar.extract("db.dump", path=tmp, filter="data")
            dump = Path(tmp) / "db.dump"
        else:
            pg_dump = _require_pg_tool("pg_dump")
            dump = Path(tmp) / "drill.dump"
            _run_pg_tool([pg_dump, "-Fc", "-f", str(dump), dsn])
            if not dump.exists() or dump.stat().st_size == 0:
                raise RestoreError(f"pg_dump produced an empty/missing dump: {dump}")

        try:
            _run_pg_tool([psql, dsn, "-c", f'DROP DATABASE IF EXISTS "{scratch_db}"'])
            _run_pg_tool([psql, dsn, "-c", f'CREATE DATABASE "{scratch_db}"'])
            _run_pg_tool(
                [pg_restore, "--no-owner", "--no-privileges",
                 "-d", scratch_dsn, str(dump)]
            )
            src_tables = _psql_scalar(psql, dsn, tables_sql)
            dst_tables = _psql_scalar(psql, scratch_dsn, tables_sql)
        finally:
            subprocess.run(
                [psql, dsn, "-c", f'DROP DATABASE IF EXISTS "{scratch_db}"'],
                capture_output=True, text=True, timeout=60,
            )

    if src_tables != dst_tables:
        raise RestoreError(
            f"drill FAILED — source has {src_tables} public tables, "
            f"scratch restored {dst_tables}"
        )
    logging.info("[drill] OK — %s/%s tables restored into scratch DB", dst_tables, src_tables)


def apply_backup(src, config_dir=CONFIG_DIR, force=False) -> None:
    """Restore an archive: backend/version gates → config unpack → pg_restore."""
    manifest = check_archive(src)
    # ID-0317: verify pg_restore exists BEFORE extracting config/ — refusing
    # afterwards would leave a half-restored install (new config, old DB).
    pg_restore = _require_pg_tool("pg_restore")
    version = manifest.get("version", "unknown")
    if version != ProxmoxVEx_VERSION and not force:
        raise RestoreError(
            f"backup was made by version {version}, this install is {ProxmoxVEx_VERSION} — "
            "restore only onto a matching version, or pass --force to attempt it anyway"
        )

    config_dir = Path(config_dir)
    config_dir.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory() as tmp:
        with tarfile.open(src) as tar:
            _safe_extract_config(tar, config_dir)
            _restore_keystore_material(tar, config_dir)
            tar.extract("db.dump", path=tmp, filter="data")
        _run_pg_tool(
            [pg_restore, "--clean", "--if-exists", "--no-owner", "--no-privileges",
             "-d", _dsn(), str(Path(tmp) / "db.dump")]
        )
    logging.info("[restore] restored backup created %s (version %s)", manifest.get("created"), version)


def main(argv=None):
    ap = argparse.ArgumentParser(prog="proxmoxvex", description="ProxmoxVEx backup/restore")
    sub = ap.add_subparsers(dest="cmd", required=True)
    for name in ("backup", "restore"):
        p = sub.add_parser(name)
        p.add_argument("archive")
        p.add_argument("--config-dir", default=CONFIG_DIR)
    sub.choices["restore"].add_argument("--force", action="store_true")
    # ID-0384: drill proves restorability against a scratch DB — optional
    # archive drills the shipped artifact, omitting it drills a live dump.
    p = sub.add_parser("drill")
    p.add_argument("archive", nargs="?", default=None)
    # ID-0130: plaintext-leftover scan over every secret column — a DB dump
    # must never be a credential dump.
    sub.add_parser("verify-secrets")
    args = ap.parse_args(argv)

    try:
        if args.cmd == "backup":
            create_backup(args.archive, config_dir=args.config_dir)
            print(f"backup written: {args.archive}")
        elif args.cmd == "drill":
            restore_drill(args.archive)
            print("drill OK — backup restored into scratch DB and verified")
        elif args.cmd == "verify-secrets":
            findings = verify_secrets()
            if findings:
                for f in findings:
                    print(f"PLAINTEXT LEFTOVER: {f}", file=sys.stderr)
                print(
                    f"verify-secrets: {len(findings)} plaintext value(s) in "
                    "secret columns — rewrite each row through the app so the "
                    "save path re-encrypts it, or run "
                    "/api/ProxmoxVEx/security/migrate-all.",
                    file=sys.stderr,
                )
                return 1
            print("verify-secrets OK — all secret columns hold ciphertext")
        else:
            apply_backup(args.archive, config_dir=args.config_dir, force=args.force)
            print(f"restored: {args.archive}")
    except (RestoreError, subprocess.CalledProcessError) as e:
        print(f"{args.cmd} failed: {e}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
