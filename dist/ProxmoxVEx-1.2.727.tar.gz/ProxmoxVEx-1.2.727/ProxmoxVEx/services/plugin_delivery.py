# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/services/plugin_delivery.py
# Project:     ProxmoxVEx
# Version:     1.2.681
# Build:       2026.10.22
# Description: License-gated plugin artifact delivery and integrity.
# Usage:       import ProxmoxVEx.services.plugin_delivery
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-10-22
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""License-gated plugin artifact delivery and integrity.

Downloads compressed paid plugin artifacts from the license server,
verifies artifact and per-file SHA-256 hashes, unpacks the plugin into the
runtime `plugins/` directory, and detects unauthorized changes.
"""

from __future__ import annotations

import contextlib
import hashlib
import ipaddress
import json
import logging
import os
import shutil
import tarfile
import tempfile
import uuid
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

import requests

from ProxmoxVEx.models.plugin_integrity import (
    add_plugin_delivery_log,
    get_plugin_integrity,
    set_plugin_integrity,
)
from ProxmoxVEx.utils import safe_tar

logger = logging.getLogger(__name__)


def _default_base_url() -> str:
    return os.environ.get(
        "LICENCE_SERVICE_URL", "https://licensing.proxmoxvex.com"
    ).rstrip("/")


def _api_key() -> str:
    return os.environ.get("LICENCE_SERVICE_API_KEY", "").strip()


def _auth_headers() -> dict[str, str]:
    headers = {}
    if _api_key():
        headers["Authorization"] = f"Bearer {_api_key()}"
    return headers


# Non-public DNS names/suffixes: the RFC 2606 reserved TLDs, the reserved
# documentation domains, and LAN-only namespaces. None of these can resolve
# to a public endpoint, so plaintext http to them stays inside the local
# trust domain — the test-suite fixtures live on licence.test / *.example.
_LOCAL_DNS_SUFFIXES = (
    ".test",
    ".example",
    ".invalid",
    ".localhost",
    ".local",
    ".internal",
    ".lan",
    ".home.arpa",
    ".example.com",
    ".example.net",
    ".example.org",
)
_LOCAL_DNS_NAMES = frozenset(
    {"localhost", "example.com", "example.net", "example.org"}
)


def _is_local_or_test_host(hostname: str) -> bool:
    """True when *hostname* cannot resolve to a public endpoint."""
    host = (hostname or "").strip().lower().rstrip(".")
    if not host:
        return False
    try:
        # Loopback, RFC1918, link-local, CGNAT and other ranges the IANA marks
        # not globally reachable — plaintext there cannot leave the local
        # trust domain (same-host docker traffic like http://172.17.0.1:8001
        # is a documented deployment case, as is the e2e pipeline's
        # LICENCE_SERVICE_URL=http://127.0.0.1:8002).
        return not ipaddress.ip_address(host).is_global
    except ValueError:
        pass
    if "." not in host:
        # Single-label names are internal DNS / docker-compose service names.
        return True
    return host in _LOCAL_DNS_NAMES or host.endswith(_LOCAL_DNS_SUFFIXES)


def _insecure_transport_reason(url: str) -> str | None:
    """Return a refusal reason when *url* uses an unauthenticated channel.

    ID-0106: the expected artifact hash and the artifact bytes are only as
    trustworthy as the channel that carried them. Over public plaintext http
    a MITM can serve a matching malicious manifest+artifact pair and the
    sha256 comparison then proves nothing. TLS server authentication is what
    authenticates the licensing catalog response (the manifest endpoint is
    public server-side — the bearer key authenticates the *client*, not the
    reply), so https is mandatory for any public endpoint. Plaintext http
    stays allowed for hosts that cannot be public (loopback/private IPs,
    docker service names, reserved test TLDs).
    """
    parsed = urlparse(url or "")
    scheme = parsed.scheme.lower()
    if scheme == "https":
        return None
    if scheme != "http":
        return f"unsupported URL scheme {scheme or '(none)'!r} — https required"
    if _is_local_or_test_host(parsed.hostname or ""):
        return None
    return f"plaintext http to public host {parsed.hostname!r} — https required"


class PluginDeliveryService:
    """Client for paid plugin artifact delivery and integrity checks."""

    def __init__(
        self,
        base_url: str | None = None,
        timeout: int = 30,
        plugins_dir: str | Path | None = None,
    ) -> None:
        self.base_url = (base_url or _default_base_url()).rstrip("/")
        self.timeout = timeout
        if plugins_dir is None:
            from ProxmoxVEx.constants import PLUGINS_DIR

            self.plugins_dir = Path(PLUGINS_DIR)
        else:
            self.plugins_dir = Path(plugins_dir)

    # Spec 092/US056: keep the previous plugin directory under
    # plugins/.rollback/<id> before an update so a failed install can be
    # reverted automatically and an admin can roll back on demand.
    def _rollback_dir(self, plugin_id: str) -> Path:
        return self.plugins_dir / ".rollback" / plugin_id

    def snapshot_for_rollback(self, plugin_id: str) -> bool:
        """Copy the installed plugin directory into the rollback area."""
        src = self.plugins_dir / plugin_id
        if not src.is_dir():
            return False
        dest = self._rollback_dir(plugin_id)
        shutil.rmtree(dest, ignore_errors=True)
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copytree(src, dest)
        return True

    def has_rollback(self, plugin_id: str) -> bool:
        return self._rollback_dir(plugin_id).is_dir()

    def discard_rollback(self, plugin_id: str) -> None:
        """Drop a plugin's rollback snapshot — used by delete_plugin so a
        deleted plugin cannot be resurrected via plugins/.rollback/<id>."""
        shutil.rmtree(self._rollback_dir(plugin_id), ignore_errors=True)

    def restore_rollback(self, plugin_id: str) -> bool:
        """Restore the last known-good snapshot over the plugin directory."""
        snap = self._rollback_dir(plugin_id)
        if not snap.is_dir():
            return False
        target = self.plugins_dir / plugin_id
        shutil.rmtree(target, ignore_errors=True)
        shutil.copytree(snap, target)
        return True

    @staticmethod
    def _response_detail(exc: requests.exceptions.RequestException) -> str:
        """Extract the server's error body so license-denial reasons are visible."""
        if exc.response is None:
            return ""
        try:
            return str(exc.response.json().get("detail") or exc.response.text)[:300]
        except ValueError:
            return exc.response.text[:300]

    def _request(
        self,
        method: str,
        path: str,
        payload: dict[str, Any] | None = None,
        params: dict[str, Any] | None = None,
        extra_headers: dict[str, str] | None = None,
    ) -> tuple[dict[str, Any] | None, str | None]:
        """Send one licensing-service request.

        Returns ``(json_body, error_detail)``. ``error_detail`` carries the
        server's own error body (e.g. "Plugin not in catalog") when available
        so callers can surface the real failure reason instead of a generic
        "request failed".
        """
        # ID-0106: never send the service API key / license key — or trust a
        # reply — over an unauthenticated channel (plaintext http to a public
        # host). Fail closed for every endpoint, not just the download path.
        channel_err = _insecure_transport_reason(self.base_url)
        if channel_err:
            logger.error(
                "Refusing plugin-delivery request to %s: %s", self.base_url, channel_err
            )
            return None, f"insecure license service URL: {channel_err}"
        try:
            headers = _auth_headers()
            if extra_headers:
                headers.update(extra_headers)
            response = requests.request(
                method,
                f"{self.base_url}{path}",
                json=payload,
                params=params,
                headers=headers,
                timeout=self.timeout,
            )
            response.raise_for_status()
            return response.json(), None
        except requests.exceptions.RequestException as exc:
            detail = self._response_detail(exc)
            logger.error("Plugin delivery request failed for %s: %s %s", path, exc, detail)
            return None, detail or str(exc) or "request failed"

    def _post(
        self,
        path: str,
        payload: dict[str, Any],
        extra_headers: dict[str, str] | None = None,
    ) -> dict[str, Any] | None:
        data, _ = self._request("POST", path, payload=payload, extra_headers=extra_headers)
        return data

    def _get(self, path: str, params: dict[str, Any] | None = None) -> dict[str, Any] | None:
        data, _ = self._request("GET", path, params=params)
        return data

    def _get_detail(
        self, path: str, params: dict[str, Any] | None = None
    ) -> tuple[dict[str, Any] | None, str | None]:
        return self._request("GET", path, params=params)

    def _log(
        self,
        conn,
        plugin_id: str,
        event_type: str,
        version: str,
        outcome: str,
        details: dict[str, Any] | None = None,
    ) -> None:
        add_plugin_delivery_log(
            conn,
            str(uuid.uuid4()),
            plugin_id,
            event_type,
            version,
            outcome,
            details,
        )

    @staticmethod
    def _sha256_file(path: Path) -> str:
        h = hashlib.sha256()
        with open(path, "rb") as f:
            for chunk in iter(lambda: f.read(8192), b""):
                h.update(chunk)
        return h.hexdigest()

    def _artifact_manifest_path(self, plugin_dir: Path) -> Path:
        return plugin_dir / "integrity.json"

    def is_paid_plugin(self, plugin_id: str) -> bool:
        """Return True if the plugin is marked paid in the generated directory."""
        # Resolve against self.plugins_dir (PLUGINS_DIR) rather than a fixed
        # parents[2] path — the two diverge when the process CWD is not the
        # project root, which silently disabled paid-plugin downloads.
        catalog = self.plugins_dir / "directory.json"
        if not catalog.exists():
            return False
        try:
            data = json.loads(catalog.read_text(encoding="utf-8"))
            for entry in data.get("plugins", []):
                if entry.get("slug") == plugin_id:
                    return bool(entry.get("is_paid") or entry.get("download_required"))
        except Exception:
            logger.warning("Could not read plugin directory catalog for %s", plugin_id)
        return False

    def get_installed_integrity(self, db, plugin_id: str) -> dict[str, Any] | None:
        return get_plugin_integrity(db.conn, plugin_id)

    def verify_installed_files(self, db, plugin_id: str) -> dict[str, Any]:
        """Recompute hashes of installed files and compare to the expected manifest.

        Returns a dict with `ok`, `status`, and `mismatched_files`.
        """
        plugin_dir = self.plugins_dir / plugin_id
        manifest_path = self._artifact_manifest_path(plugin_dir)
        if not manifest_path.exists():
            return {
                "ok": False,
                "status": "missing",
                "mismatched_files": ["integrity.json"],
            }

        try:
            manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        except Exception as exc:
            logger.error("Failed to read integrity manifest for %s: %s", plugin_id, exc)
            return {
                "ok": False,
                "status": "tampered",
                "mismatched_files": ["integrity.json"],
            }

        # Skip interpreter bytecode in BOTH directions: manifests generated
        # before scripts/package_paid_plugins.py excluded __pycache__ still
        # list .pyc entries whose hashes can never match — the cached bytecode
        # embeds the source mtime and is regenerated at import time. A real
        # tamper is still caught because the .py source is hash-checked.
        # Paths the plugin is allowed to rewrite at runtime (state.json,
        # data/ seeds, ...). Declared in manifest.json `mutable_paths`, carried
        # in the packaged integrity.json — absent on older manifests, which
        # keeps the strict check for plugins that never declared mutables.
        mutable_paths = [
            str(p).strip().strip("/")
            for p in manifest.get("mutable_paths", [])
            if str(p).strip().strip("/")
        ]
        # config.json is always implicitly mutable: /api/plugins/<id>/config
        # is the admin-facing settings editor, so a legitimate settings save
        # must not flag the whole plugin as tampered and disable it.
        if "config.json" not in mutable_paths:
            mutable_paths.append("config.json")

        def _mutable(rel: str) -> bool:
            return any(
                rel == entry or rel.startswith(entry + "/") for entry in mutable_paths
            )

        expected_files = {
            f["path"]: f["hash"]
            for f in manifest.get("files", [])
            if "__pycache__" not in Path(f["path"]).parts
            and Path(f["path"]).suffix not in (".pyc", ".pyo")
            and not _mutable(f["path"])
        }
        mismatched: list[str] = []
        found_files: set[str] = set()

        for path, expected_hash in expected_files.items():
            file_path = plugin_dir / path
            if not file_path.is_file():
                mismatched.append(path)
                continue
            found_files.add(path)
            actual = self._sha256_file(file_path)
            if actual != expected_hash:
                mismatched.append(path)

        # Detect extra files not in the manifest (excluding the integrity manifest).
        for item in plugin_dir.rglob("*"):
            if item.is_file() and item.name != "integrity.json":
                rel = item.relative_to(plugin_dir).as_posix()
                # Python bytecode caches (__pycache__/*.pyc) are written next to
                # plugin sources at import time — they are runtime artifacts,
                # not delivered content. Counting them flagged every paid
                # plugin as tampered as soon as the interpreter cached bytecode.
                if "__pycache__" in item.relative_to(plugin_dir).parts or item.suffix in (".pyc", ".pyo"):
                    continue
                if rel not in found_files and not _mutable(rel):
                    mismatched.append(rel)

        ok = not mismatched
        status = "valid" if ok else "tampered"
        return {
            "ok": ok,
            "status": status,
            "mismatched_files": mismatched,
        }

    def _verify_artifact(self, archive_path: Path, expected_hash: str) -> bool:
        """sha256-compare the downloaded archive against the expected hash.

        This is only a comparison — hash *provenance* is the caller's
        contract (ID-0106): ``expected_hash`` must come from the licensing
        manifest response fetched over the authenticated channel that
        ``download_and_install`` validates, never from the artifact itself
        or an unauthenticated source.
        """
        return self._sha256_file(archive_path) == expected_hash

    def _unpack_artifact(self, archive_path: Path, dest_dir: Path) -> None:
        """Extract a .tar.gz archive into place, blocking path traversal.

        The archive is extracted into a staging sibling and swapped in via
        os.rename rather than rmtree'ed first, for two reasons:

        * Rename only needs write permission on ``plugins/`` itself, so a
          previous install containing entries owned by another user (e.g.
          files docker cp'ed in as root, or a volume seeded by a root
          container) no longer fails the whole update with EACCES on
          ``shutil.rmtree`` — the old tree is moved aside and cleaned up
          best-effort.
        * A corrupt or hostile archive used to destroy the installed plugin
          before validation even ran (rmtree happened before the tar was
          opened). The previous version now survives until the new one is
          fully validated and extracted.
        """
        staging = dest_dir.parent / f".{dest_dir.name}.staging-{uuid.uuid4().hex}"
        trash = dest_dir.parent / f".{dest_dir.name}.old-{uuid.uuid4().hex}"
        staging.mkdir(parents=True)
        try:
            with tarfile.open(archive_path, "r:gz") as tar:
                # ID-0102: shared hardened extractor (utils/safe_tar.py) —
                # strict mode keeps this path's raise-on-tampered-member
                # semantics: delivered artifacts only ever contain plain
                # files/dirs (scripts/package_paid_plugins.py), so a link
                # or traversal member means the artifact is hostile.
                safe_tar.extract_archive(tar, staging, strict=True)
        except Exception:
            shutil.rmtree(staging, ignore_errors=True)
            raise

        # Preserve live runtime state across the swap: the artifact ships
        # config.json and mutable_paths entries only as first-install seeds.
        # Without this, every paid-plugin update reset the admin's config and
        # wiped plugin state (the class of bug that reset status_page's
        # auth_key to "" and broke the public status page).
        if dest_dir.exists():
            self._preserve_runtime_state(dest_dir, staging)

        # Swap: move the old tree aside, move the staged tree into place. The
        # window where dest_dir is missing is two renames — versus the whole
        # rmtree+extract duration with the previous inline approach.
        swapped_out = False
        try:
            if dest_dir.exists():
                os.rename(dest_dir, trash)
                swapped_out = True
            os.rename(staging, dest_dir)
        except Exception:
            if swapped_out:
                with contextlib.suppress(OSError):
                    os.rename(trash, dest_dir)
            shutil.rmtree(staging, ignore_errors=True)
            raise

        # Best-effort cleanup of the previous tree. Foreign-owned leftovers
        # (e.g. a root-owned __pycache__) can make this fail — that must not
        # fail the install: the new version is already active. The hidden
        # ".old-*" remnant is skipped by plugin discovery and retried on the
        # next update.
        shutil.rmtree(trash, ignore_errors=True)
        if trash.exists():
            logger.warning(
                "Leftover files under %s could not be removed (owned by another user); "
                "the new plugin version is active regardless",
                trash,
            )

    def _runtime_state_paths(self, *roots: Path) -> list[str]:
        """Plugin-relative paths carrying live state: config.json (edited via
        the admin config API on every install) plus every mutable_paths entry
        declared by each root's packaged manifest. The old install's and the
        new artifact's manifests are merged so state survives even when the
        new version stops shipping a seed file the plugin still writes."""
        rels: set[str] = {"config.json"}
        for root in roots:
            manifest_path = root / "integrity.json"
            try:
                manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
            except Exception:
                continue
            for entry in manifest.get("mutable_paths", []):
                entry = str(entry).strip().strip("/")
                if entry:
                    rels.add(entry)
        return sorted(rels)

    def _preserve_runtime_state(self, old_dir: Path, staging: Path) -> None:
        """Copy live config/state files from the previous install into the
        staged tree before it is swapped in. Live content always wins over
        the packaged seed; seed files with no prior state still land."""
        old_resolved = old_dir.resolve()
        staging_resolved = staging.resolve()
        for rel in self._runtime_state_paths(old_dir, staging):
            try:
                src = (old_dir / rel).resolve()
                dst = (staging / rel).resolve()
                if not src.is_relative_to(old_resolved):
                    continue
                if not dst.is_relative_to(staging_resolved):
                    continue
            except OSError:
                continue
            if not src.exists():
                continue
            try:
                if src.is_dir():
                    shutil.copytree(src, dst, dirs_exist_ok=True)
                else:
                    dst.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(src, dst)
            except OSError:
                logger.warning("Could not preserve runtime file %s during plugin update", rel)

    def _download_artifact(self, download_url: str, dest_path: Path, license_key: str = "") -> None:
        # SEC-006: the license key travels in a header, not the URL, so it
        # never lands in access logs / Referer headers on either side.
        headers = _auth_headers()
        if license_key:
            headers["X-License-Key"] = license_key
        with requests.get(download_url, stream=True, timeout=self.timeout, headers=headers) as resp:
            resp.raise_for_status()
            # ID-0106: requests follows redirects silently — a https artifact
            # URL could still land on plaintext http. Re-verify the FINAL url
            # before any downloaded bytes hit disk.
            final_err = _insecure_transport_reason(getattr(resp, "url", "") or download_url)
            if final_err:
                raise requests.exceptions.RequestException(
                    f"artifact download redirected to an insecure URL: {final_err}"
                )
            with open(dest_path, "wb") as f:
                for chunk in resp.iter_content(chunk_size=8192):
                    if chunk:
                        f.write(chunk)

    def download_and_install(
        self,
        db,
        plugin_id: str,
        license_key: str,
        version: str | None = None,
    ) -> tuple[bool, str]:
        """Download, verify, and unpack a paid plugin artifact.

        Returns (ok, error_message).
        """
        self._log(db.conn, plugin_id, "download", version or "latest", "pending")

        # ID-0106: provenance gate. The expected artifact hash below is only
        # as trustworthy as the channel that delivers it — when the license
        # service URL is plaintext http to a public host, a MITM can serve a
        # matching malicious manifest+artifact pair and the sha256 check
        # proves nothing, so the download is refused before any request.
        channel_err = _insecure_transport_reason(self.base_url)
        if channel_err:
            self._log(
                db.conn,
                plugin_id,
                "download",
                version or "latest",
                "failure",
                {"reason": "insecure_transport"},
            )
            return False, f"Refusing plugin download: {channel_err}"

        manifest = self._get(
            f"/v1/plugins/{plugin_id}/manifest",
            {"version": version} if version else None,
        )
        if not manifest:
            self._log(db.conn, plugin_id, "download", version or "latest", "failure", {"reason": "no_manifest"})
            return False, "Could not retrieve plugin manifest from license server"
        if not manifest.get("success"):
            err = manifest.get("error", "License server rejected manifest request")
            self._log(db.conn, plugin_id, "download", version or "latest", "failure", {"reason": err})
            return False, err

        data = manifest.get("data", {})
        version = version or data.get("version")
        # ID-0106: the expected hash is pinned to THIS manifest response —
        # fetched over the channel validated above (TLS server-authenticated
        # for public hosts). It is never taken from the artifact itself or an
        # unauthenticated source, so a tampered archive cannot ship its own
        # "expected" hash.
        artifact_hash = data.get("artifact_hash")
        if not version or not artifact_hash:
            return False, "Manifest missing version or artifact hash"

        download_resp = self._post(
            f"/v1/plugins/{plugin_id}/download",
            {"license_key": license_key, "version": version},
            extra_headers={"X-License-Key": license_key},
        )
        if not download_resp or not download_resp.get("success"):
            err = (download_resp or {}).get("error", "License server denied download")
            self._log(db.conn, plugin_id, "download", version, "failure", {"reason": err})
            return False, err

        download_url = download_resp.get("data", {}).get("download_url")
        if not download_url:
            return False, "License server did not provide a download URL"
        # ID-0106: the same transport rule applies to the artifact URL — a
        # manifest response must not downgrade the fetch to public plaintext
        # http, where a MITM could swap the bytes (and a colluding manifest
        # would have supplied the matching hash).
        url_err = _insecure_transport_reason(download_url)
        if url_err:
            self._log(
                db.conn,
                plugin_id,
                "download",
                version,
                "failure",
                {"reason": "insecure_download_url"},
            )
            return False, f"Refusing plugin artifact download URL: {url_err}"

        with tempfile.TemporaryDirectory() as tmp:
            archive_path = Path(tmp) / f"{plugin_id}-{version}.tar.gz"
            try:
                self._download_artifact(download_url, archive_path, license_key=license_key)
            except requests.exceptions.RequestException as exc:
                logger.error("Failed to download plugin artifact for %s: %s", plugin_id, exc)
                self._log(db.conn, plugin_id, "download", version, "failure", {"reason": "download_failed"})
                return False, f"Failed to download plugin artifact: {exc}"

            if not self._verify_artifact(archive_path, artifact_hash):
                self._log(db.conn, plugin_id, "download", version, "failure", {"reason": "artifact_hash_mismatch"})
                return False, "Downloaded plugin artifact hash does not match manifest"

            plugin_dir = self.plugins_dir / plugin_id
            try:
                self._unpack_artifact(archive_path, plugin_dir)
            except Exception as exc:
                logger.exception("Failed to unpack plugin %s: %s", plugin_id, exc)
                self._log(db.conn, plugin_id, "download", version, "failure", {"reason": "unpack_failed"})
                return False, f"Failed to unpack plugin artifact: {exc}"

            verify = self.verify_installed_files(db, plugin_id)
            if not verify["ok"]:
                set_plugin_integrity(db.conn, plugin_id, version, artifact_hash, verify["status"])
                # _log/add_plugin_delivery_log expect the raw connection — it
                # calls conn.commit() which the wrapper class does not expose.
                self._log(
                    db.conn,
                    plugin_id,
                    "download",
                    version,
                    "failure",
                    {"reason": "integrity_mismatch", "mismatched_files": verify["mismatched_files"]},
                )
                return False, f"Plugin integrity check failed: {', '.join(verify['mismatched_files'])}"

            set_plugin_integrity(db.conn, plugin_id, version, artifact_hash, "valid")
            self._log(db.conn, plugin_id, "download", version, "success")
            return True, ""

    def check_for_update(
        self, db, plugin_id: str, license_key: str | None = None
    ) -> dict[str, Any]:
        """Return whether a newer artifact is available on the license server.

        The server's ``/updates`` endpoint is public — the license key is
        accepted for call-site symmetry but never sent; only artifact
        downloads require a license.
        """
        current = get_plugin_integrity(db.conn, plugin_id)
        installed_version = current["version"] if current else None

        manifest, detail = self._get_detail(
            f"/v1/plugins/{plugin_id}/updates",
            {"installed_version": installed_version} if installed_version else None,
        )
        if manifest is None:
            err = "Could not check for updates"
            if detail:
                err = f"{err}: {detail}"
            return {"update_available": False, "error": err}
        if not manifest.get("success"):
            return {
                "update_available": False,
                "error": manifest.get("error") or "Could not check for updates",
            }

        data = manifest.get("data", {})
        return {
            "update_available": data.get("update_available", False),
            "latest_version": data.get("latest_version"),
            "artifact_hash": data.get("artifact_hash"),
        }

    def install_update(
        self,
        db,
        plugin_id: str,
        license_key: str,
    ) -> tuple[bool, str]:
        """Download and install the latest version of a paid plugin."""
        info = self.check_for_update(db, plugin_id, license_key)
        # A failed check must not masquerade as "No update available" — the
        # apply pass would otherwise report success while nothing happened.
        if info.get("error") and not info.get("update_available"):
            return False, str(info["error"])
        if not info.get("update_available"):
            return True, "No update available"
        return self.download_and_install(db, plugin_id, license_key, info.get("latest_version"))

    def verify_and_remediate(
        self,
        db,
        plugin_id: str,
        license_key: str | None,
    ) -> dict[str, Any]:
        """Verify a loaded paid plugin and, if tampered, disable it.

        Returns a status dict with `ok`, `status`, and `action`.
        """
        result = self.verify_installed_files(db, plugin_id)
        current = get_plugin_integrity(db.conn, plugin_id)
        version = current["version"] if current else "unknown"

        # "missing" means no integrity.json baseline on disk. When no baseline
        # was ever recorded either (no artifact hash in plugin_integrity), the
        # plugin was installed from source — a dev checkout or the E2E harness —
        # not delivered through the license server, so there is nothing to
        # verify against. Treat it as unverifiable rather than tampered;
        # disabling here broke every source-installed paid plugin.
        if result["status"] == "missing" and not (current and current.get("artifact_hash")):
            return {**result, "action": "none"}

        if not result["ok"]:
            set_plugin_integrity(db.conn, plugin_id, version, current["artifact_hash"] if current else "", "tampered")
            self._log(
                db.conn,
                plugin_id,
                "tamper",
                version,
                "failure",
                {"mismatched_files": result["mismatched_files"]},
            )
            self.report_tamper(plugin_id, version, result["mismatched_files"], license_key)
            return {**result, "action": "disable"}

        if current:
            # set_plugin_integrity calls conn.commit(); the wrapper class does
            # not expose commit(), so pass the raw connection.
            set_plugin_integrity(
                db.conn,
                plugin_id,
                current["version"],
                current["artifact_hash"],
                "valid",
            )
        return {**result, "action": "none"}

    def report_tamper(
        self,
        plugin_id: str,
        version: str,
        mismatched_files: list[str],
        license_key: str | None = None,
    ) -> dict[str, Any] | None:
        """Report a tamper event to the license server."""
        payload = {
            "plugin_id": plugin_id,
            "version": version,
            "mismatched_files": mismatched_files,
        }
        if license_key:
            payload["license_key"] = license_key
        return self._post(f"/v1/plugins/{plugin_id}/tamper", payload)
