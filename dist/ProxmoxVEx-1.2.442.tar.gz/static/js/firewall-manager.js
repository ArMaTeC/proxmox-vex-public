/* --- ProxmoxVEx auto-header start ---
 * -------------------------------------------------------------------
 * File:        static/js/firewall-manager.js
 * Project:     ProxmoxVEx
 * Version:     1.2.437
 * Build:       2026.09.12
 * Description: Shared firewall appliance manager UI (pfSense + OPNsense).
 * Docs:        https://proxmoxvex.com/docs
 * Generated:   2026-09-12
 * -------------------------------------------------------------------
 * --- ProxmoxVEx auto-header end --- */
/* Shared firewall-manager UI for the pfSense and OPNsense native plugins
   (spec 003 — parity by construction: both pages boot this same module).

   Each plugin page loads this file plus a thin per-plugin boot call:

     FirewallManager.boot({ pluginId: 'pfsense', apiBase: '/api/pfsense',
                            i18nBase: '/api/native/pfsense/i18n',
                            title: 'pfSense Manager' });

   The manager fetches `<apiBase>/health` first; the response carries the
   caller's effective `permissions` (["pfsense.rules", ...]) which gate every
   action control — server-side RBAC stays authoritative, this only hides
   buttons the server would reject anyway.

   Builds on window.NativeDataView helpers (el/table/badge/kv/kpis/card)
   so both plugins render with the same design tokens. */
(function () {
    'use strict';

    var V = window.NativeDataView;
    var el, badge, chips, dataTable, kpiGrid, kvList, card, stateCard, toneFor;

    function bindHelpers() {
        el = V.el; badge = V.badge; chips = V.chips; dataTable = V.table;
        kpiGrid = V.kpis; kvList = V.kv; card = V.card; stateCard = V.stateCard;
        toneFor = V.toneFor;
    }

    // ---------- i18n (mirrors native-dataview) ----------
    var _i18n = null;
    var _ns = 'core';
    var _localDict = null;
    try { _i18n = window.parent.ProxmoxVExI18n; } catch (e) { /* standalone */ }

    function t(key) {
        if (_i18n) {
            var v = _i18n.t(key, { ns: _ns });
            if (v !== key) return v;
            v = _i18n.t(key, { ns: 'core' });
            if (v !== key) return v;
        }
        if (_localDict && _localDict[key] != null) return _localDict[key];
        // graceful fallback: render the key humanized rather than raw
        return String(key).replace(/[_-]+/g, ' ').replace(/\b\w/g, function (m) { return m.toUpperCase(); });
    }

    // ---------- generic api ----------
    var _apiBase = '';

    function apiGet(endpoint) {
        return fetch(_apiBase + '/' + endpoint, { credentials: 'same-origin' })
            .then(function (r) { return r.json().then(function (d) { return { status: r.status, data: d }; }); });
    }

    function apiPost(endpoint, body) {
        return fetch(_apiBase + '/' + endpoint, {
            method: 'POST', credentials: 'same-origin',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(body || {})
        }).then(function (r) { return r.json().then(function (d) { return { status: r.status, data: d }; }); });
    }

    // ---------- permission gating ----------
    var _pluginId = '';
    var _perms = [];

    function can(domain) {
        return _perms.indexOf(_pluginId + '.' + domain) !== -1;
    }

    function lockedChip() {
        return el('span', { class: 'ndv-badge ndv-badge-muted', text: t('read_only') });
    }

    // ---------- toast / status ----------
    var _toastHost = null;

    function toast(msg, tone) {
        if (!_toastHost) return;
        var n = el('div', { class: 'ndv-toast ndv-toast-' + (tone || 'ok'), text: msg });
        _toastHost.appendChild(n);
        setTimeout(function () { n.remove(); }, 4200);
    }

    // ---------- modal form ----------
    function openForm(title, fields, initial, onSubmit) {
        var dlg = document.createElement('dialog');
        dlg.className = 'ndv-modal';
        var form = el('form', { method: 'dialog', class: 'ndv-form' });
        form.appendChild(el('h2', { class: 'ndv-card-title', text: title }));
        var inputs = {};
        (fields || []).forEach(function (f) {
            var val = initial && initial[f.key] != null ? initial[f.key] : (f.value != null ? f.value : '');
            var input;
            if (f.type === 'select') {
                input = el('select', { name: f.key, class: 'ndv-input' },
                    (f.options || []).map(function (o) {
                        var opt = el('option', { value: o.value != null ? o.value : o, text: o.label != null ? o.label : o });
                        if (String(o.value != null ? o.value : o) === String(val)) opt.selected = true;
                        return opt;
                    }));
            } else if (f.type === 'checkbox') {
                input = el('input', { type: 'checkbox', name: f.key });
                input.checked = !!val;
            } else if (f.type === 'textarea') {
                input = el('textarea', { name: f.key, class: 'ndv-input', rows: '3' });
                input.value = Array.isArray(val) ? val.join('\n') : String(val);
            } else {
                input = el('input', { type: f.type || 'text', name: f.key, class: 'ndv-input' });
                input.value = String(val);
            }
            inputs[f.key] = { field: f, node: input };
            form.appendChild(el('label', { class: 'ndv-field' },
                el('span', { class: 'ndv-field-label', text: t(f.label || f.key) + (f.required ? ' *' : '') }), input));
        });
        var errBox = el('div', { class: 'ndv-form-error', hidden: '' });
        var btns = el('div', { class: 'ndv-form-actions' },
            el('button', { type: 'button', class: 'btn secondary', text: t('cancel') }),
            el('button', { type: 'submit', class: 'btn', text: t('save') }));
        btns.firstChild.addEventListener('click', function () { dlg.close(); });
        form.appendChild(errBox);
        form.appendChild(btns);
        form.addEventListener('submit', function (ev) {
            ev.preventDefault();
            var out = {};
            Object.keys(inputs).forEach(function (k) {
                var it = inputs[k];
                if (it.field.type === 'checkbox') out[k] = it.node.checked;
                else out[k] = it.node.value;
            });
            var missing = (fields || []).filter(function (f) {
                return f.required && (out[f.key] == null || String(out[f.key]).trim() === '');
            });
            if (missing.length) {
                errBox.textContent = t('required_fields') + ': ' + missing.map(function (f) { return t(f.label || f.key); }).join(', ');
                errBox.removeAttribute('hidden');
                return;
            }
            onSubmit(out, function (errMsg) {
                if (errMsg) { errBox.textContent = errMsg; errBox.removeAttribute('hidden'); return; }
                dlg.close();
            });
        });
        dlg.appendChild(form);
        document.body.appendChild(dlg);
        dlg.addEventListener('close', function () { dlg.remove(); });
        dlg.showModal();
    }

    // ---------- generic CRUD domain ----------
    // spec: { endpoint, listKey, perm, columns, form, keyField, bodyFor(action,rowOrForm) }
    function renderDomain(h, data, payload, spec, refresh) {
        var rows = (data && data[spec.listKey || 'rows']) || [];
        // `readonly` domains (audit) never get mutation controls even when
        // the caller holds the domain permission.
        var writable = !spec.readonly && can(spec.perm);
        var head = el('div', { class: 'ndv-toolbar' });
        if (writable) {
            var addBtn = el('button', { class: 'btn', type: 'button', text: '+ ' + t('add') });
            addBtn.addEventListener('click', function () {
                openForm(t('add'), spec.form, {}, function (form, done) {
                    apiPost(spec.endpoint, spec.bodyFor('create', form)).then(function (r) {
                        if (!r.data || r.data.ok === false) { done((r.data && r.data.detail) || t('request_failed')); return; }
                        done(null); toast(t('saved')); refresh();
                    });
                });
            });
            head.appendChild(addBtn);
        } else {
            head.appendChild(lockedChip());
        }
        h.root.appendChild(head);

        var cols = (spec.columns || []).slice();
        if (writable) {
            cols.push({
                key: '_actions', label: t('actions'),
                render: function (_v, row) {
                    var wrap = el('span', { class: 'ndv-row-actions' });
                    (spec.actions || ['update', 'delete']).forEach(function (verb) {
                        var btn = el('button', {
                            class: 'btn secondary ndv-btn-sm', type: 'button',
                            text: t(verb === 'update' ? 'edit' : verb)
                        });
                        btn.addEventListener('click', function () { rowAction(spec, verb, row, refresh); });
                        wrap.appendChild(btn);
                    });
                    return wrap;
                }
            });
        }
        h.root.appendChild(dataTable(rows, cols, { emptyText: t('no_data') }));
    }

    function rowAction(spec, verb, row, refresh) {
        var uuid = row[spec.keyField || 'uuid'];
        if (verb === 'delete' || verb === 'toggle') {
            if (verb === 'delete' && !window.confirm(t('confirm_delete') + ' ' + (row.name || row.description || uuid))) return;
            apiPost(spec.endpoint, spec.bodyFor(verb, row)).then(function (r) {
                if (!r.data || r.data.ok === false) { toast((r.data && r.data.detail) || t('request_failed'), 'err'); return; }
                toast(t('saved')); refresh();
            });
            return;
        }
        // edit — prefill the form from the row
        openForm(t('edit'), spec.form, row, function (form, done) {
            apiPost(spec.endpoint, spec.bodyFor('update', form, row)).then(function (r) {
                if (!r.data || r.data.ok === false) { done((r.data && r.data.detail) || t('request_failed')); return; }
                done(null); toast(t('saved')); refresh();
            });
        });
    }

    // ---------- column/field vocab ----------
    var OPT_PROTO = ['any', 'tcp', 'udp', 'tcp/udp', 'icmp'];
    var OPT_ACTION = ['pass', 'block', 'reject'];
    var OPT_IPPROTO = [{ value: 'inet', label: 'IPv4' }, { value: 'inet6', label: 'IPv6' }];
    var OPT_NAT_KIND = [
        { value: 'port_forward', label: 'Port forward' },
        { value: 'outbound', label: 'Outbound' },
        { value: 'one_to_one', label: '1:1' },
    ];

    // ---------- tab specs ----------
    function tabSpecs(refreshFor) {
        return [
            {
                id: 'overview', endpoint: 'overview', perm: 'view',
                render: renderOverview
            },
            {
                id: 'network', endpoint: 'network', perm: 'view',
                render: renderNetwork
            },
            {
                id: 'rules', endpoint: 'rules', perm: 'rules',
                domain: {
                    endpoint: 'rules', listKey: 'rules', perm: 'rules',
                    actions: ['update', 'toggle', 'delete'],
                    columns: [
                        { key: 'sequence', label: '#' },
                        { key: 'interface', label: t('interface'), render: function (v) { return badge(v, 'info'); } },
                        { key: 'action', label: t('action'), render: function (v) { return badge(v); } },
                        { key: 'protocol', label: t('protocol') },
                        { key: 'source_net', label: t('source') },
                        { key: 'destination_net', label: t('destination') },
                        { key: 'destination_port', label: t('port') },
                        { key: 'enabled', label: t('enabled') },
                        { key: 'description', label: t('description') },
                    ],
                    form: [
                        { key: 'interface', label: 'interface', required: true },
                        { key: 'action', label: 'action', type: 'select', options: OPT_ACTION, value: 'pass' },
                        { key: 'direction', label: 'direction', type: 'select', options: ['in', 'out'], value: 'in' },
                        { key: 'ipprotocol', label: 'ipprotocol', type: 'select', options: OPT_IPPROTO, value: 'inet' },
                        { key: 'protocol', label: 'protocol', type: 'select', options: OPT_PROTO, value: 'any' },
                        { key: 'source_net', label: 'source', value: 'any' },
                        { key: 'source_port', label: 'source_port' },
                        { key: 'destination_net', label: 'destination', value: 'any' },
                        { key: 'destination_port', label: 'destination_port' },
                        { key: 'description', label: 'description' },
                        { key: 'enabled', label: 'enabled', type: 'checkbox', value: true },
                        { key: 'sequence', label: 'sequence', type: 'number', value: 1 },
                    ],
                    bodyFor: function (action, form, row) {
                        if (action === 'delete' || action === 'toggle') return { action: action, uuid: row.uuid };
                        return { action: action, uuid: row ? row.uuid : undefined, rule: form };
                    }
                }
            },
            {
                id: 'aliases', endpoint: 'aliases', perm: 'aliases',
                domain: {
                    endpoint: 'aliases', listKey: 'aliases', perm: 'aliases',
                    columns: [
                        { key: 'name', label: t('name') },
                        { key: 'type', label: t('type'), render: function (v) { return badge(v, 'info'); } },
                        { key: 'content', label: t('content'), render: function (v) { return chips(Array.isArray(v) ? v : String(v || '').split('\n')); } },
                        { key: 'ref_count', label: t('ref_count') },
                        { key: 'description', label: t('description') },
                    ],
                    form: [
                        { key: 'name', label: 'name', required: true },
                        { key: 'type', label: 'type', type: 'select', options: ['host', 'network', 'port', 'url'], value: 'host' },
                        { key: 'content', label: 'content', type: 'textarea', required: true },
                        { key: 'description', label: 'description' },
                    ],
                    bodyFor: function (action, form, row) {
                        if (action === 'delete') return { action: 'delete', uuid: row.uuid };
                        return { action: action, uuid: row ? row.uuid : undefined, alias: form };
                    }
                }
            },
            {
                id: 'nat', endpoint: 'nat', perm: 'nat',
                render: function (h, data, payload, refresh) { renderNat(h, data, payload, refresh); }
            },
            {
                id: 'dhcp', endpoint: 'dhcp', perm: 'dhcp',
                render: function (h, data, payload, refresh) { renderDhcp(h, data, payload, refresh); }
            },
            {
                id: 'dns', endpoint: 'dns', perm: 'dns',
                render: function (h, data, payload, refresh) { renderDns(h, data, payload, refresh); }
            },
            {
                id: 'vpn', endpoint: 'vpn', perm: 'vpn',
                render: function (h, data, payload, refresh) { renderVpn(h, data, payload, refresh); }
            },
            {
                id: 'services', endpoint: 'services', perm: 'services',
                render: function (h, data, payload, refresh) { renderServices(h, data, payload, refresh); }
            },
            {
                id: 'ops', endpoint: 'ops', perm: 'ops',
                render: function (h, data, payload, refresh) { renderOps(h, data, payload, refresh); }
            },
            {
                id: 'audit', endpoint: 'audit', perm: 'audit',
                domain: {
                    endpoint: 'audit', listKey: 'entries', perm: 'audit', readonly: true,
                    columns: [
                        { key: 'ts', label: t('time') },
                        { key: 'user', label: t('user') },
                        { key: 'action', label: t('action'), render: function (v) { return badge(v, 'info'); } },
                        { key: 'target', label: t('target') },
                        { key: 'host', label: t('host') },
                        { key: 'result', label: t('result'), render: function (v) { return badge(v); } },
                        { key: 'detail', label: t('detail') },
                    ],
                }
            },
            {
                id: 'logs', endpoint: 'logs', perm: 'view',
                render: renderLogs
            },
        ];
    }

    // ---------- overview ----------
    function renderOverview(h, data) {
        // cluster shape: {nodes:{a,b}, divergence, master} — single node: snapshot
        if (data && data.nodes) { renderClusterOverview(h, data); return; }
        data = data || {};
        var sys = data.system || {};
        var ifaces = data.interfaces || [];
        var gws = data.gateways || [];
        var svcs = (data.services && data.services.items) || data.services || [];
        h.root.appendChild(kpiGrid([
            { label: t('interfaces'), value: ifaces.length },
            { label: t('gateways'), value: gws.length },
            { label: t('services'), value: svcs.length },
            { label: t('certs_expiring'), value: (data.certs && data.certs.expiring_soon_count) || 0 },
        ]));
        h.section(t('system'), kvList([
            [t('hostname'), sys.hostname || sys.name],
            [t('version'), sys.version],
            [t('uptime'), sys.uptime],
            ['CPU', sys.cpumodel || sys.cpu],
            [t('kernel'), sys.kernel],
        ]));
        if (data.carp) h.section('CARP', kvList(data.carp));
        if (gws.length) h.section(t('gateways'), dataTable(gws));
        var vpn = data.vpn || {};
        var wgPeers = (vpn.wireguard && vpn.wireguard.peers) || [];
        if (wgPeers.length || (vpn.ipsec || []).length || (vpn.openvpn || []).length) {
            h.section(t('vpn'), kvList([
                ['WireGuard', wgPeers.length + ' ' + t('peers')],
                ['IPsec', (vpn.ipsec || []).length],
                ['OpenVPN', (vpn.openvpn || []).length],
            ]));
        }
    }

    function renderClusterOverview(h, data) {
        var div = data.divergence || [];
        h.root.appendChild(kpiGrid([
            { label: t('master'), value: data.master || '—' },
            { label: t('divergences'), value: div.length },
        ]));
        ['a', 'b'].forEach(function (side) {
            var node = data.nodes && data.nodes[side];
            if (!node) return;
            var sys = (node.snap && node.snap.system) || {};
            var c = card(node.name + (data.master === node.name ? ' — ' + t('master') : ''));
            if (!node.ok) c.appendChild(stateCard('err', node.error || 'unreachable', node.detail));
            else c.appendChild(kvList([[t('version'), sys.version], [t('uptime'), sys.uptime], [t('hostname'), sys.hostname || sys.name]]));
            h.root.appendChild(c);
        });
        if (div.length) {
            h.section(t('divergence'), dataTable(div, [
                { key: 'severity', label: t('severity'), render: function (v) { return badge(v); } },
                { key: 'category', label: t('category') },
                { key: 'key', label: t('item') },
                { key: 'detail', label: t('detail') },
            ]));
        }
    }

    // ---------- network ----------
    function renderNetwork(h, data) {
        data = data || {};
        var ifaces = data.interfaces || data.rows || data || [];
        if (ifaces && !Array.isArray(ifaces) && ifaces.interfaces) ifaces = ifaces.interfaces;
        if (Array.isArray(ifaces) && ifaces.length) {
            h.section(t('interfaces'), dataTable(ifaces));
        }
        var routes = data.routes || [];
        if (routes.length) h.section(t('routes'), dataTable(routes));
        var gws = data.gateways || [];
        if (gws.length) h.section(t('gateways'), dataTable(gws));
        if (!Array.isArray(ifaces) || !ifaces.length) {
            // last resort: auto-render whatever came back
            h.root.appendChild(card(t('network')));
            h.root.lastChild.appendChild(kvList(data));
        }
    }

    // ---------- nat ----------
    var _natKind = 'port_forward';

    function renderNat(h, data, payload, refresh) {
        var rules = (data && data.rules) || [];
        var writable = can('nat');
        var bar = el('div', { class: 'ndv-toolbar' });
        var sel = el('select', { class: 'ndv-input' }, OPT_NAT_KIND.map(function (o) {
            var opt = el('option', { value: o.value, text: o.label });
            if (o.value === _natKind) opt.selected = true;
            return opt;
        }));
        sel.addEventListener('change', function () { _natKind = sel.value; refresh(); });
        bar.appendChild(sel);
        if (writable) {
            var addBtn = el('button', { class: 'btn', type: 'button', text: '+ ' + t('add') });
            addBtn.addEventListener('click', function () { natForm(null, refresh); });
            bar.appendChild(addBtn);
        }
        h.root.appendChild(bar);

        var rows = rules.filter(function (r) { return r.kind === _natKind; });
        var cols = [
            { key: 'interface', label: t('interface'), render: function (v) { return badge(v, 'info'); } },
            { key: 'protocol', label: t('protocol') },
            { key: 'source_net', label: t('source') },
            { key: 'destination_net', label: t('destination') },
            { key: 'destination_port', label: t('dest_port') },
            { key: 'target', label: t('target') },
            { key: 'target_port', label: t('target_port') },
            { key: 'enabled', label: t('enabled') },
            { key: 'description', label: t('description') },
        ];
        if (writable) {
            cols.push({
                key: '_a', label: t('actions'),
                render: function (_v, row) {
                    var wrap = el('span', { class: 'ndv-row-actions' });
                    var edit = el('button', { class: 'btn secondary ndv-btn-sm', text: t('edit') });
                    edit.addEventListener('click', function () { natForm(row, refresh); });
                    var del = el('button', { class: 'btn secondary ndv-btn-sm', text: t('delete') });
                    del.addEventListener('click', function () {
                        if (!window.confirm(t('confirm_delete'))) return;
                        apiPost('nat', { action: 'delete', kind: row.kind, uuid: row.uuid }).then(function (r) {
                            if (!r.data || r.data.ok === false) { toast((r.data && r.data.detail) || t('request_failed'), 'err'); return; }
                            toast(t('saved')); refresh();
                        });
                    });
                    wrap.appendChild(edit); wrap.appendChild(del);
                    return wrap;
                }
            });
        }
        h.root.appendChild(dataTable(rows, cols, { emptyText: t('no_data') }));
    }

    function natForm(row, refresh) {
        var kind = (row && row.kind) || _natKind;
        var fields = [
            { key: 'interface', label: 'interface', required: true },
            { key: 'protocol', label: 'protocol', type: 'select', options: OPT_PROTO, value: kind === 'port_forward' ? 'tcp' : 'any' },
            { key: 'source_net', label: 'source', value: 'any' },
            { key: 'destination_net', label: 'destination', value: 'any' },
            { key: 'destination_port', label: 'destination_port' },
            { key: 'target', label: kind === 'one_to_one' ? 'external' : 'target', required: kind !== 'outbound' },
            { key: 'target_port', label: 'target_port' },
            { key: 'description', label: 'description' },
            { key: 'enabled', label: 'enabled', type: 'checkbox', value: true },
        ];
        openForm(t('nat') + ' — ' + kind, fields, row || {}, function (form, done) {
            apiPost('nat', {
                action: row ? 'update' : 'create',
                kind: kind, uuid: row ? row.uuid : undefined,
                rule: form
            }).then(function (r) {
                if (!r.data || r.data.ok === false) { done((r.data && r.data.detail) || t('request_failed')); return; }
                done(null); toast(t('saved')); refresh();
            });
        });
    }

    // ---------- dhcp ----------
    function renderDhcp(h, data, payload, refresh) {
        data = data || {};
        var writable = can('dhcp');
        var scopes = data.scopes || data.subnets || [];
        var maps = data.mappings || data.reservations || [];
        if (scopes.length) h.section(t('scopes'), dataTable(scopes));
        var head = el('div', { class: 'ndv-toolbar' });
        if (writable) {
            var addBtn = el('button', { class: 'btn', type: 'button', text: '+ ' + t('add') });
            addBtn.addEventListener('click', function () {
                openForm(t('add') + ' ' + t('static_mapping'), [
                    { key: 'interface', label: 'interface' },
                    { key: 'subnet', label: 'subnet' },
                    { key: 'mac', label: 'mac', required: true },
                    { key: 'ip', label: 'ip_address', required: true },
                    { key: 'hostname', label: 'hostname' },
                    { key: 'description', label: 'description' },
                ], {}, function (form, done) {
                    apiPost('dhcp', { action: 'mapping_set', mapping: form }).then(function (r) {
                        if (!r.data || r.data.ok === false) { done((r.data && r.data.detail) || t('request_failed')); return; }
                        done(null); toast(t('saved')); refresh();
                    });
                });
            });
            head.appendChild(addBtn);
        } else head.appendChild(lockedChip());
        var c = card(t('static_mappings'));
        c.appendChild(head);
        var cols = [
            { key: 'interface', label: t('interface') },
            { key: 'mac', label: 'MAC' },
            { key: 'ip', label: t('ip_address') },
            { key: 'hostname', label: t('hostname') },
            { key: 'description', label: t('description') },
        ];
        if (writable) {
            cols.push({
                key: '_a', label: t('actions'),
                render: function (_v, row) {
                    var del = el('button', { class: 'btn secondary ndv-btn-sm', text: t('delete') });
                    del.addEventListener('click', function () {
                        if (!window.confirm(t('confirm_delete'))) return;
                        apiPost('dhcp', { action: 'mapping_delete', uuid: row.uuid, interface: row.interface }).then(function (r) {
                            if (!r.data || r.data.ok === false) { toast((r.data && r.data.detail) || t('request_failed'), 'err'); return; }
                            toast(t('saved')); refresh();
                        });
                    });
                    return del;
                }
            });
        }
        c.appendChild(dataTable(maps, cols, { emptyText: t('no_data') }));
        h.root.appendChild(c);
    }

    // ---------- dns ----------
    function renderDns(h, data, payload, refresh) {
        data = data || {};
        var writable = can('dns');
        var hosts = data.hosts || data.hosts_overrides || [];
        var domains = data.domains || [];
        ['hosts', 'domains'].forEach(function (kind) {
            var rows = kind === 'hosts' ? hosts : domains;
            var c = card(t(kind === 'hosts' ? 'host_overrides' : 'domain_overrides'));
            if (writable) {
                var addBtn = el('button', { class: 'btn', type: 'button', text: '+ ' + t('add') });
                addBtn.addEventListener('click', function () {
                    var fields = kind === 'hosts'
                        ? [{ key: 'hostname', required: true }, { key: 'domain', required: true }, { key: 'ip', label: 'ip_address', required: true }, { key: 'description' }]
                        : [{ key: 'domain', required: true }, { key: 'ip', label: 'ip_address', required: true }, { key: 'description' }];
                    openForm(t('add'), fields, {}, function (form, done) {
                        var body = { action: kind === 'hosts' ? 'host_set' : 'domain_set' };
                        body[kind === 'hosts' ? 'host' : 'domain'] = form;
                        apiPost('dns', body).then(function (r) {
                            if (!r.data || r.data.ok === false) { done((r.data && r.data.detail) || t('request_failed')); return; }
                            done(null); toast(t('saved')); refresh();
                        });
                    });
                });
                c.appendChild(addBtn);
            }
            var cols = [
                { key: 'hostname', label: t('hostname') },
                { key: 'domain', label: t('domain') },
                { key: 'ip', label: t('ip_address') },
                { key: 'description', label: t('description') },
            ];
            if (writable) {
                cols.push({
                    key: '_a', label: t('actions'),
                    render: function (_v, row) {
                        var del = el('button', { class: 'btn secondary ndv-btn-sm', text: t('delete') });
                        del.addEventListener('click', function () {
                            if (!window.confirm(t('confirm_delete'))) return;
                            apiPost('dns', { action: kind === 'hosts' ? 'host_delete' : 'domain_delete', uuid: row.uuid }).then(function (r) {
                                if (!r.data || r.data.ok === false) { toast((r.data && r.data.detail) || t('request_failed'), 'err'); return; }
                                toast(t('saved')); refresh();
                            });
                        });
                        return del;
                    }
                });
            }
            c.appendChild(dataTable(rows, cols, { emptyText: t('no_data') }));
            h.root.appendChild(c);
        });
    }

    // ---------- vpn ----------
    function renderVpn(h, data, payload, refresh) {
        data = data || {};
        var writable = can('vpn');
        var status = data.status || {};

        // live sessions
        var wgLive = (status.wireguard && status.wireguard.peers) || [];
        var sessions = wgLive.concat(status.ipsec || []).concat(status.openvpn || []);
        if (sessions.length) {
            h.section(t('sessions'), dataTable(sessions, [
                { key: 'type', label: t('type'), render: function (v) { return badge(v, 'info'); } },
                { key: 'name', label: t('name') },
                { key: 'enabled', label: t('enabled') },
                { key: 'connected', label: t('connected') },
                { key: 'remote_address', label: t('remote') },
            ]));
        }

        vpnSection(h, refresh, 'wireguard', t('wireguard_peers'), data.wireguard || [], writable, [
            { key: 'name', label: 'name', required: true },
            { key: 'public_key', label: 'public_key', required: true },
            { key: 'allowed_ips', label: 'allowed_ips' },
            { key: 'endpoint_host', label: 'endpoint' },
            { key: 'endpoint_port', label: 'port' },
            { key: 'keepalive', label: 'keepalive', type: 'number', value: 25 },
            { key: 'enabled', label: 'enabled', type: 'checkbox', value: true },
        ], 'wg_set', 'wg_delete', 'peer', [
            { key: 'name', label: t('name') },
            { key: 'public_key', label: t('public_key') },
            { key: 'allowed_ips', label: t('allowed_ips'), render: function (v) { return chips(Array.isArray(v) ? v : [v]); } },
            { key: 'enabled', label: t('enabled') },
        ]);

        vpnSection(h, refresh, 'ipsec_p1', 'IPsec ' + t('phase1'), (data.ipsec && data.ipsec.phase1) || [], writable, [
            { key: 'remote_addrs', label: 'remote_gateway', required: true },
            { key: 'local_addrs', label: 'local_addrs' },
            { key: 'ike_version', label: 'ike_version', type: 'select', options: [{ value: '2', label: 'IKEv2' }, { value: '1', label: 'IKEv1' }], value: '2' },
            { key: 'auth_method', label: 'auth_method', type: 'select', options: ['psk', 'pubkey'], value: 'psk' },
            { key: 'proposals', label: 'proposals', value: 'aes256-sha256-modp2048' },
            { key: 'psk', label: 'psk', type: 'password' },
            { key: 'description', label: 'description' },
            { key: 'enabled', label: 'enabled', type: 'checkbox', value: true },
        ], 'ipsec_p1_set', 'ipsec_p1_delete', 'tunnel', [
            { key: 'remote_addrs', label: t('remote') },
            { key: 'ike_version', label: 'IKE' },
            { key: 'auth_method', label: t('auth') },
            { key: 'proposal', label: t('proposal') },
            { key: 'enabled', label: t('enabled') },
            { key: 'description', label: t('description') },
        ]);

        var p2 = (data.ipsec && data.ipsec.phase2) || [];
        if (p2.length) h.section('IPsec ' + t('phase2'), dataTable(p2));

        ['servers', 'clients'].forEach(function (role) {
            var rows = (data.openvpn && data.openvpn[role]) || [];
            vpnSection(h, refresh, 'openvpn_' + (role === 'servers' ? 'server' : 'client'),
                'OpenVPN ' + t(role === 'servers' ? 'servers' : 'clients'), rows, writable, [
                { key: 'protocol', label: 'protocol', type: 'select', options: ['udp4', 'udp6', 'tcp4', 'tcp6'], value: 'udp4' },
                { key: 'port', label: 'port', type: 'number', value: '1194' },
                { key: 'device_mode', label: 'device_mode', type: 'select', options: ['tun', 'tap'], value: 'tun' },
                { key: 'local_net', label: 'tunnel_network' },
                { key: 'remote_net', label: 'remote_networks' },
                { key: 'remote', label: 'remote' },
                { key: 'cert_ref', label: 'cert' },
                { key: 'description', label: 'description' },
                { key: 'enabled', label: 'enabled', type: 'checkbox', value: true },
            ], 'openvpn_' + (role === 'servers' ? 'server' : 'client') + '_set',
                'openvpn_' + (role === 'servers' ? 'server' : 'client') + '_delete', 'instance', [
                { key: 'description', label: t('description') },
                { key: 'protocol', label: t('protocol') },
                { key: 'port', label: t('port') },
                { key: 'local_net', label: t('tunnel_network') },
                { key: 'enabled', label: t('enabled') },
            ]);
        });
    }

    function vpnSection(h, refresh, _id, title, rows, writable, formFields, setVerb, delVerb, objKey, cols) {
        var c = card(title);
        if (writable) {
            var addBtn = el('button', { class: 'btn', type: 'button', text: '+ ' + t('add') });
            addBtn.addEventListener('click', function () {
                openForm(title, formFields, {}, function (form, done) {
                    var body = { action: setVerb };
                    body[objKey] = form;
                    apiPost('vpn', body).then(function (r) {
                        if (!r.data || r.data.ok === false) { done((r.data && r.data.detail) || t('request_failed')); return; }
                        done(null); toast(t('saved')); refresh();
                    });
                });
            });
            c.appendChild(addBtn);
        }
        var cols2 = cols.slice();
        if (writable) {
            cols2.push({
                key: '_a', label: t('actions'),
                render: function (_v, row) {
                    var wrap = el('span', { class: 'ndv-row-actions' });
                    var edit = el('button', { class: 'btn secondary ndv-btn-sm', text: t('edit') });
                    edit.addEventListener('click', function () {
                        openForm(title, formFields, row, function (form, done) {
                            var body = { action: setVerb, uuid: row.uuid };
                            body[objKey] = form;
                            apiPost('vpn', body).then(function (r) {
                                if (!r.data || r.data.ok === false) { done((r.data && r.data.detail) || t('request_failed')); return; }
                                done(null); toast(t('saved')); refresh();
                            });
                        });
                    });
                    var del = el('button', { class: 'btn secondary ndv-btn-sm', text: t('delete') });
                    del.addEventListener('click', function () {
                        if (!window.confirm(t('confirm_delete'))) return;
                        apiPost('vpn', { action: delVerb, uuid: row.uuid }).then(function (r) {
                            if (!r.data || r.data.ok === false) { toast((r.data && r.data.detail) || t('request_failed'), 'err'); return; }
                            toast(t('saved')); refresh();
                        });
                    });
                    wrap.appendChild(edit); wrap.appendChild(del);
                    return wrap;
                }
            });
        }
        c.appendChild(dataTable(rows, cols2, { emptyText: t('no_data') }));
        h.root.appendChild(c);
    }

    // ---------- services ----------
    function renderServices(h, data, payload, refresh) {
        var rows = (data && data.services) || [];
        var writable = can('services');
        var cols = [
            { key: 'name', label: t('name') },
            { key: 'label', label: t('label') },
            { key: 'status', label: t('status'), render: function (v) { return badge(v); } },
            { key: 'locked', label: t('locked') },
        ];
        if (writable) {
            cols.push({
                key: '_a', label: t('actions'),
                render: function (_v, row) {
                    var wrap = el('span', { class: 'ndv-row-actions' });
                    var verbs = row.status === 'running' ? ['restart', 'stop', 'reconfigure'] : ['start'];
                    verbs.forEach(function (verb) {
                        var btn = el('button', { class: 'btn secondary ndv-btn-sm', text: t(verb) });
                        btn.addEventListener('click', function () {
                            apiPost('services', { action: verb, service: row.name }).then(function (r) {
                                if (!r.data || r.data.ok === false) { toast((r.data && r.data.detail) || t('request_failed'), 'err'); return; }
                                toast(t('done')); refresh();
                            });
                        });
                        wrap.appendChild(btn);
                    });
                    return wrap;
                }
            });
        } else {
            h.root.appendChild(lockedChip());
        }
        h.root.appendChild(dataTable(rows, cols, { emptyText: t('no_data') }));
    }

    // ---------- ops ----------
    var OPS_ACTIONS = [
        { action: 'apply', label: 'apply_config' },
        { action: 'backup', label: 'backup' },
        { action: 'firmware_check', label: 'firmware_check' },
        { action: 'restore', label: 'restore', destructive: true, idField: 'backup_id' },
        { action: 'reboot', label: 'reboot', destructive: true },
        { action: 'halt', label: 'halt', destructive: true },
        { action: 'firmware_update', label: 'firmware_update', destructive: true },
        { action: 'firmware_upgrade', label: 'firmware_upgrade', destructive: true },
    ];

    function renderOps(h, data, payload, refresh) {
        data = data || {};
        var writable = can('ops');
        var hostname = data.hostname || '';
        var c = card(t('operations'));
        if (!writable) c.appendChild(lockedChip());
        var grid = el('div', { class: 'ndv-ops-grid' });
        OPS_ACTIONS.forEach(function (op) {
            var btn = el('button', {
                class: 'btn ' + (op.destructive ? 'danger' : 'secondary'), type: 'button',
                text: t(op.label)
            });
            if (!writable) btn.disabled = true;
            btn.addEventListener('click', function () {
                var body = { action: op.action };
                if (op.idField) {
                    var id = window.prompt(t('backup_id') + ':');
                    if (!id) return;
                    body[op.idField] = id;
                }
                if (op.destructive) {
                    var conf = window.prompt(t('confirm_hostname') + ' (' + hostname + '):');
                    if (conf !== hostname) { toast(t('confirm_mismatch'), 'err'); return; }
                    body.confirm = conf;
                }
                apiPost('ops', body).then(function (r) {
                    if (!r.data || r.data.ok === false) {
                        toast((r.data && r.data.detail) || t('request_failed'), 'err');
                        return;
                    }
                    toast(t('done')); refresh();
                });
            });
            grid.appendChild(btn);
        });
        c.appendChild(grid);
        h.root.appendChild(c);

        if (data.firmware) h.section(t('firmware'), kvList(data.firmware));
        var backups = data.backups || [];
        if (backups.length) h.section(t('backups'), dataTable(backups));
        if (data.system) h.section(t('system'), kvList(data.system));
    }

    // ---------- logs ----------
    function renderLogs(h, data) {
        var rows = (data && (data.entries || data.logs || data.rows)) || (Array.isArray(data) ? data : []);
        h.root.appendChild(dataTable(rows, null, { emptyText: t('no_data') }));
    }

    // ---------- boot ----------
    function boot(cfg) {
        bindHelpers();
        _pluginId = cfg.pluginId;
        _ns = cfg.ns || cfg.pluginId;
        _apiBase = cfg.apiBase;

        var root = document.getElementById(cfg.rootId || 'ndv-root') || document.body;
        var loaded = {};
        var tabs = tabSpecs();

        function refreshCurrent() {
            var active = root.querySelector('.ndv-tab[aria-selected="true"]');
            if (active) { loaded[active.dataset.tab] = false; loadTab(active.dataset.tab); }
        }

        function loadTab(id) {
            var spec = tabs.filter(function (s) { return s.id === id; })[0];
            if (!spec) return;
            var panel = document.getElementById('fwm-panel-' + id);
            var content = el('div', { class: 'ndv-content' });
            panel.textContent = '';
            panel.appendChild(el('div', { class: 'ndv-status muted', text: t('loading') }));
            panel.appendChild(content);
            apiGet(spec.endpoint).then(function (r) {
                panel.querySelector('.ndv-status').textContent = '';
                var payload = r.data || {};
                if (!r.status || r.status >= 400 || payload.ok === false) {
                    var errCode = (payload && payload.error) || ('http_' + r.status);
                    var title = errCode === 'forbidden' ? t('forbidden')
                        : errCode === 'unconfigured' ? t('not_configured')
                        : errCode === 'auth' ? t('auth_failed') : t('error');
                    content.textContent = '';
                    content.appendChild(stateCard(errCode === 'forbidden' ? 'warn' : 'err', title, payload && payload.detail));
                    return;
                }
                content.textContent = '';
                var h = {
                    el: el, t: t, badge: badge, chips: chips, kv: kvList, table: dataTable,
                    kpis: kpiGrid, card: card, root: content,
                    section: function (titleText, node) {
                        var c2 = card(titleText); c2.appendChild(node); content.appendChild(c2); return c2;
                    }
                };
                try {
                    if (spec.domain) renderDomain(h, payload.data, payload, spec.domain, refreshCurrent);
                    else spec.render(h, payload.data, payload, refreshCurrent);
                } catch (e) {
                    content.appendChild(stateCard('err', t('error'), String(e && e.message || e)));
                }
            }).catch(function (e) {
                panel.querySelector('.ndv-status').textContent = '';
                content.appendChild(stateCard('err', t('error'), String(e && e.message || e)));
            });
        }

        function activate(id) {
            root.querySelectorAll('.ndv-tab').forEach(function (b) {
                b.setAttribute('aria-selected', b.dataset.tab === id ? 'true' : 'false');
            });
            root.querySelectorAll('.fwm-panel').forEach(function (p) {
                if (p.id === 'fwm-panel-' + id) p.removeAttribute('hidden'); else p.setAttribute('hidden', '');
            });
            loadTab(id);
        }

        function buildShell() {
            root.textContent = '';
            _toastHost = el('div', { class: 'ndv-toast-host' });
            var refreshBtn = el('button', { class: 'secondary ndv-refresh', type: 'button' }, '⟳ ', t('refresh'));
            refreshBtn.addEventListener('click', refreshCurrent);
            var roBadge = null;
            // t() humanizes a missing key to 'Title' — fall back to the
            // boot-configured plugin name in that case.
            var hdrTitle = t('title');
            var head = el('header', { class: 'ndv-header' },
                el('h1', {}, hdrTitle === 'Title' && cfg.title ? cfg.title : hdrTitle),
                refreshBtn);
            var tabBar = el('div', { class: 'ndv-tabs', role: 'tablist' });
            var main = el('main', {});
            tabs.forEach(function (spec, i) {
                var btn = el('button', {
                    class: 'ndv-tab', role: 'tab', type: 'button',
                    'data-tab': spec.id, 'aria-selected': i === 0 ? 'true' : 'false'
                }, t(spec.id));
                btn.addEventListener('click', function () { activate(spec.id); });
                tabBar.appendChild(btn);
                var panel = el('section', { class: 'fwm-panel', id: 'fwm-panel-' + spec.id, role: 'tabpanel' });
                if (i !== 0) panel.setAttribute('hidden', '');
                main.appendChild(panel);
            });
            root.appendChild(el('div', { class: 'ndv-shell' }, head, tabBar, main, _toastHost));
            activate(tabs[0].id);
        }

        // i18n then health (permissions) then shell
        var ready = Promise.resolve();
        if (_i18n && _i18n.loadPluginNamespaceFull) {
            ready = _i18n.loadPluginNamespaceFull(_ns, cfg.i18nBase).catch(function () { });
        } else if (cfg.i18nBase) {
            ready = fetch(cfg.i18nBase + '/en.json')
                .then(function (r) { return r.ok ? r.json() : {}; })
                .then(function (d) { _localDict = d; })
                .catch(function () { });
        }
        ready.then(function () {
            return apiGet('health').then(function (r) {
                var d = (r && r.data) || {};
                _perms = d.permissions || [];
                buildShell();
                document.title = (cfg.title || 'Firewall Manager') + ' - ProxmoxVEx';
            });
        }).catch(function () { buildShell(); });
    }

    window.FirewallManager = { boot: boot };
})();
