/* --- ProxmoxVEx auto-header start ---
 * -------------------------------------------------------------------
 * File:        web/src/pwa.js
 * Project:     ProxmoxVEx
 * Version:     1.2.437
 * Build:       2026.09.12
 * Description: Register service worker as soon as possible. SW handles...
 * Docs:        https://proxmoxvex.com/docs
 * Generated:   2026-09-12
 * -------------------------------------------------------------------
 * --- ProxmoxVEx auto-header end --- */
// Register service worker as soon as possible. SW handles offline shell + push.
if ('serviceWorker' in navigator) {
    window.addEventListener('load', function () {
        navigator.serviceWorker.register('/sw.js', { scope: '/' })
            .then(function (reg) { console.log('[PWA] SW registered, scope:', reg.scope); })
            .catch(function (err) { console.warn('[PWA] SW registration failed:', err); });
    });
}
