/* --- ProxmoxVEx auto-header start ---
 * -------------------------------------------------------------------
 * File:        plugins/docker-swarm/ui.js
 * Project:     ProxmoxVEx
 * Version:     1.2.437
 * Build:       2026.09.12
 * Description: Ui JS source
 * Docs:        https://proxmoxvex.com/docs
 * Generated:   2026-09-12
 * -------------------------------------------------------------------
 * --- ProxmoxVEx auto-header end --- */
(function () {
    const qs = new URLSearchParams(window.location.search);
    const theme = qs.get('theme') || 'modern-dark';
    if (theme === 'corp-light') { document.documentElement.setAttribute('data-theme', 'corp-light'); } else { document.documentElement.removeAttribute('data-theme'); }
    const $ = (id) => document.getElementById(id);
    const i18n = window.parent && window.parent.ProxmoxVExI18n;

    // Standalone English fallback so the iframe still renders readable strings
    // when loaded outside the host shell (tests, direct URL) without i18n.
    const EN_FALLBACK = {
        title: 'Docker / Swarm Manager',
        refresh: 'Refresh', dashboard: 'Dashboard', nodes: 'Nodes', services: 'Services',
        stacks: 'Stacks', containers: 'Containers', networks: 'Networks', volumes: 'Volumes',
        images: 'Images', cleanup: 'Disk Cleanup', stackName: 'Name', composeYaml: 'Compose YAML',
        deploy: 'Deploy', save: 'Save', runNow: 'Run now', autoPrune: 'Auto prune',
        threshold: 'Threshold %', interval: 'Interval (s)', targets: 'Targets',
        loading: 'Loading...', error: 'Error', retry: 'Retry',
        loadError: 'Failed to load data.', empty: 'No items.',
        drained: 'Drained', scaled: 'Scaled', deleted: 'Deleted', deployed: 'Deployed',
        saved: 'Saved', refreshed: 'Refreshed', removed: 'Removed',
        confirmPrune: 'Run prune now? This deletes stopped containers, unused images and volumes.',
        pruneStarted: 'Prune started',
    };

    function t(k, p) {
        let s = '';
        if (i18n) s = i18n.getT('docker_swarm')(k, p ? { params: p } : undefined);
        if (!s || s === k) {
            s = EN_FALLBACK[k] || k;
        }
        return s;
    }
    if (i18n) i18n.loadPluginNamespaceFull('docker_swarm', '/api/plugins/docker-swarm/i18n');

    async function api(path, method = 'GET', body = null) {
        const opts = { method, credentials: 'same-origin', headers: { 'X-Requested-With': 'XMLHttpRequest' } };
        if (body) { opts.headers['Content-Type'] = 'application/json'; opts.body = JSON.stringify(body); }
        const res = await fetch(path, opts);
        const data = await res.json().catch(() => ({}));
        // Surface stable error codes with the message so failures stay actionable.
        if (!res.ok) { const e = new Error(data.error || `HTTP ${res.status}`); e.code = data.code; e.status = res.status; throw e; }
        return data;
    }
    function escapeHtml(s) { const d = document.createElement('div'); d.textContent = s; return d.innerHTML; }
    function showMessage(text, type) { const m = $('message'); m.innerHTML = DOMPurify.sanitize(`<div class="message ${type}">${escapeHtml(text)}</div>`); setTimeout(() => { m.innerHTML = ''; }, 4000); }
    function setLoading(id) { const el = $(id); if (el) el.innerHTML = DOMPurify.sanitize(`<p class="loading">${escapeHtml(t('loading'))}</p>`); }
    function setLoadError(id, loader) {
        const el = $(id); if (!el) return;
        el.innerHTML = DOMPurify.sanitize(`<p class="empty">${escapeHtml(t('loadError'))}</p>`);
        const btn = document.createElement('button');
        btn.className = 'secondary'; btn.textContent = t('retry');
        btn.addEventListener('click', () => { setLoading(id); loader(); });
        el.appendChild(btn);
    }
    function setEmpty(id, msg) { const el = $(id); if (el) el.innerHTML = DOMPurify.sanitize(`<p class="empty">${escapeHtml(msg || t('empty'))}</p>`); }

    function applyI18n() {
        document.querySelectorAll('[data-i18n]').forEach(el => {
            el.textContent = t(el.dataset.i18n);
        });
    }

    async function loadDashboard() {
        setLoading('dashboardStats');
        try {
            const d = await api('dashboard');
            $('dashboardStats').innerHTML = DOMPurify.sanitize(`<div class="stat"><div class="value">${escapeHtml(d.mode)}</div><div class="muted">Engine</div></div><div class="stat"><div class="value">${escapeHtml(d.nodes)}</div><div class="muted">Nodes</div></div><div class="stat"><div class="value">${escapeHtml(d.services)}</div><div class="muted">Services</div></div><div class="stat"><div class="value">${escapeHtml(d.stacks)}</div><div class="muted">Stacks</div></div><div class="stat"><div class="value">${escapeHtml(d.containers)}</div><div class="muted">Containers</div></div><div class="stat"><div class="value">${escapeHtml(d.images)}</div><div class="muted">Images</div></div>`);
            $('modeChip').textContent = d.mode;
        } catch (e) { setLoadError('dashboardStats', loadDashboard); showMessage(e.message, 'error'); }
    }

    async function loadNodes() {
        setLoading('nodesList');
        try {
            const d = await api('nodes');
            if (!d.nodes.length) { setEmpty('nodesList', 'No nodes.'); return; }
            let html = '<table><thead><tr><th>Name</th><th>Role</th><th>Status</th><th>CPU</th><th>Memory</th><th>Actions</th></tr></thead><tbody>';
            d.nodes.forEach(n => { html += `<tr><td>${escapeHtml(n.name)}</td><td class="muted">${escapeHtml(n.role)}</td><td>${escapeHtml(n.status)}</td><td class="muted">${escapeHtml(n.cpu)}%</td><td class="muted">${escapeHtml(n.memory)}%</td><td><button class="secondary drainNode" data-id="${escapeHtml(n.id)}">Drain</button></td></tr>`; });
            html += '</tbody></table>';
            $('nodesList').innerHTML = DOMPurify.sanitize(html);
            document.querySelectorAll('.drainNode').forEach(b => b.addEventListener('click', async (e) => { try { await api('nodes/drain', 'POST', { id: e.target.dataset.id }); showMessage(t('drained'), 'success'); loadNodes(); } catch (err) { showMessage(err.message, 'error'); } }));
        } catch (e) { setLoadError('nodesList', loadNodes); }
    }

    async function loadServices() {
        setLoading('servicesList');
        try {
            const d = await api('services');
            if (!d.services.length) { setEmpty('servicesList', 'No services.'); return; }
            let html = '<table><thead><tr><th>Name</th><th>Image</th><th>Replicas</th><th>Status</th><th>Actions</th></tr></thead><tbody>';
            d.services.forEach(s => { html += `<tr><td>${escapeHtml(s.name)}</td><td class="muted">${escapeHtml(s.image)}</td><td>${escapeHtml(s.replicas)}</td><td>${escapeHtml(s.status)}</td><td><input type="number" style="width:60px" value="${escapeHtml(s.replicas)}" min="0" max="100" class="scaleInput" data-id="${escapeHtml(s.id)}" aria-label="Replicas for ${escapeHtml(s.name)}" /><button class="secondary scaleBtn" data-id="${escapeHtml(s.id)}">Scale</button></td></tr>`; });
            html += '</tbody></table>';
            $('servicesList').innerHTML = DOMPurify.sanitize(html);
            document.querySelectorAll('.scaleBtn').forEach(b => b.addEventListener('click', async (e) => { const input = document.querySelector(`.scaleInput[data-id="${e.target.dataset.id}"]`); try { await api('services/scale', 'POST', { id: e.target.dataset.id, replicas: parseInt(input.value) }); showMessage(t('scaled'), 'success'); loadServices(); } catch (err) { showMessage(err.message, 'error'); } }));
        } catch (e) { setLoadError('servicesList', loadServices); }
    }

    async function loadStacks() {
        setLoading('stacksList');
        try {
            const d = await api('stacks');
            if (!d.stacks.length) { setEmpty('stacksList', 'No stacks.'); return; }
            let html = '<table><thead><tr><th>Name</th><th>Services</th><th>Status</th><th>Actions</th></tr></thead><tbody>';
            d.stacks.forEach(s => { html += `<tr><td>${escapeHtml(s.name)}</td><td class="muted">${(s.services || []).map(escapeHtml).join(', ')}</td><td>${escapeHtml(s.status)}</td><td><button class="secondary deleteStack" data-id="${escapeHtml(s.id)}">Delete</button></td></tr>`; });
            html += '</tbody></table>';
            $('stacksList').innerHTML = DOMPurify.sanitize(html);
            document.querySelectorAll('.deleteStack').forEach(b => b.addEventListener('click', async (e) => { if (!confirm(t('confirmDeleteStack') || 'Delete stack?')) return; try { await api('stacks/delete', 'POST', { id: e.target.dataset.id }); showMessage(t('deleted'), 'success'); loadStacks(); } catch (err) { showMessage(err.message, 'error'); } }));
        } catch (e) { setLoadError('stacksList', loadStacks); }
    }

    async function loadContainers() {
        setLoading('containersList');
        try {
            const d = await api('containers');
            if (!d.containers.length) { setEmpty('containersList', 'No containers.'); return; }
            let html = '<table><thead><tr><th>Name</th><th>Image</th><th>Node</th><th>Status</th><th>Actions</th></tr></thead><tbody>';
            d.containers.forEach(c => { html += `<tr><td>${escapeHtml(c.name)}</td><td class="muted">${escapeHtml(c.image)}</td><td class="muted">${escapeHtml(c.node)}</td><td>${escapeHtml(c.status)}</td><td><button class="secondary actContainer" data-id="${escapeHtml(c.id)}" data-action="stop">Stop</button><button class="secondary actContainer" data-id="${escapeHtml(c.id)}" data-action="delete">Delete</button></td></tr>`; });
            html += '</tbody></table>';
            $('containersList').innerHTML = DOMPurify.sanitize(html);
            document.querySelectorAll('.actContainer').forEach(b => b.addEventListener('click', async (e) => { try { await api('containers/action', 'POST', { id: e.target.dataset.id, action: e.target.dataset.action }); showMessage(e.target.dataset.action, 'success'); loadContainers(); } catch (err) { showMessage(err.message, 'error'); } }));
        } catch (e) { setLoadError('containersList', loadContainers); }
    }

    async function loadNetworks() {
        setLoading('networksList');
        try {
            const d = await api('networks');
            if (!d.networks.length) { setEmpty('networksList', 'No networks.'); return; }
            let html = '<table><thead><tr><th>Name</th><th>Driver</th><th>Scope</th></tr></thead><tbody>';
            d.networks.forEach(n => { html += `<tr><td>${escapeHtml(n.name)}</td><td class="muted">${escapeHtml(n.driver)}</td><td>${escapeHtml(n.scope)}</td></tr>`; });
            html += '</tbody></table>';
            $('networksList').innerHTML = DOMPurify.sanitize(html);
        } catch (e) { setLoadError('networksList', loadNetworks); }
    }

    async function loadVolumes() {
        setLoading('volumesList');
        try {
            const d = await api('volumes');
            if (!d.volumes.length) { setEmpty('volumesList', 'No volumes.'); return; }
            let html = '<table><thead><tr><th>Name</th><th>Driver</th><th>Size</th></tr></thead><tbody>';
            d.volumes.forEach(v => { html += `<tr><td>${escapeHtml(v.name)}</td><td class="muted">${escapeHtml(v.driver)}</td><td>${escapeHtml(v.size)}</td></tr>`; });
            html += '</tbody></table>';
            $('volumesList').innerHTML = DOMPurify.sanitize(html);
        } catch (e) { setLoadError('volumesList', loadVolumes); }
    }

    async function loadImages() {
        setLoading('imagesList');
        try {
            const d = await api('images');
            if (!d.images.length) { setEmpty('imagesList', 'No images.'); return; }
            let html = '<table><thead><tr><th>Name</th><th>Tags</th><th>Size</th><th>Actions</th></tr></thead><tbody>';
            d.images.forEach(i => { html += `<tr><td>${escapeHtml(i.name)}</td><td class="muted">${(i.tags || []).map(escapeHtml).join(', ')}</td><td>${escapeHtml(i.size)}</td><td><button class="secondary rmImage" data-id="${escapeHtml(i.id)}">Remove</button></td></tr>`; });
            html += '</tbody></table>';
            $('imagesList').innerHTML = DOMPurify.sanitize(html);
            document.querySelectorAll('.rmImage').forEach(b => b.addEventListener('click', async (e) => { try { await api('images/remove', 'POST', { id: e.target.dataset.id }); showMessage(t('removed'), 'success'); loadImages(); } catch (err) { showMessage(err.message, 'error'); } }));
        } catch (e) { setLoadError('imagesList', loadImages); }
    }

    async function loadPrune() {
        try {
            const d = await api('prune_policy');
            $('pruneResult').textContent = `Auto prune: ${d.prune_policy.enabled ? 'On' : 'Off'} | Threshold: ${d.prune_policy.threshold}% | Interval: ${d.prune_policy.interval}s | Targets: ${(d.prune_policy.targets || []).join(', ')}`;
        } catch (e) { $('pruneResult').textContent = t('loadError'); showMessage(e.message, 'error'); }
    }

    $('refreshAll').addEventListener('click', () => { loadDashboard(); showMessage(t('refreshed'), 'success'); });
    $('runPrune').addEventListener('click', async () => {
        if (!confirm(t('confirmPrune'))) return;
        try {
            const d = await api('prune', 'POST', { confirm: true });
            $('pruneResult').textContent = `Freed: ${JSON.stringify(d.freed)}`;
            showMessage(t('pruneStarted'), 'success');
        } catch (e) { showMessage(e.message, 'error'); }
    });
    $('pruneForm').addEventListener('submit', async (e) => { e.preventDefault(); const f = e.target; try { await api('prune_policy/save', 'POST', { enabled: f.enabled.checked, threshold: parseInt(f.threshold.value), interval: parseInt(f.interval.value), targets: f.targets.value.split(',').map(x => x.trim()) }); showMessage(t('saved'), 'success'); loadPrune(); } catch (err) { showMessage(err.message, 'error'); } });

    $('stackForm').addEventListener('submit', async (e) => { e.preventDefault(); const f = e.target; try { await api('stacks/deploy', 'POST', { name: f.name.value, compose: f.compose.value }); showMessage(t('deployed'), 'success'); f.reset(); loadStacks(); } catch (err) { showMessage(err.message, 'error'); } });

    const loaders = { dashboard: loadDashboard, nodes: loadNodes, services: loadServices, stacks: loadStacks, containers: loadContainers, networks: loadNetworks, volumes: loadVolumes, images: loadImages, cleanup: loadPrune };

    document.querySelectorAll('.tab').forEach(tab => tab.addEventListener('click', () => {
        document.querySelectorAll('.tab').forEach(x => { x.classList.remove('active'); x.setAttribute('aria-selected', 'false'); });
        document.querySelectorAll('.panel').forEach(x => x.classList.remove('active'));
        tab.classList.add('active'); tab.setAttribute('aria-selected', 'true');
        $(tab.dataset.tab + 'Panel').classList.add('active');
        const loader = loaders[tab.dataset.tab];
        if (loader) loader();
    }));

    (async () => {
        if (i18n) await i18n.loadPluginNamespaceFull('docker_swarm', '/api/plugins/docker-swarm/i18n');
        applyI18n();
        await loadDashboard();
    })();
})();
