/* --- ProxmoxVEx auto-header start ---
 * -------------------------------------------------------------------
 * File:        plugins/truenas/ui.js
 * Project:     ProxmoxVEx
 * Version:     1.2.437
 * Build:       2026.09.12
 * Description: Ui JS source
 * Docs:        https://proxmoxvex.com/docs
 * Generated:   2026-09-12
 * -------------------------------------------------------------------
 * --- ProxmoxVEx auto-header end --- */
(function () {
    const qs = new URLSearchParams(window.location.search);
    const theme = qs.get('theme') || 'modern-dark';
    if (theme === 'corp-light') { document.documentElement.setAttribute('data-theme', 'corp-light'); } else { document.documentElement.removeAttribute('data-theme'); }
    const $ = (id) => document.getElementById(id);
    const i18n = window.parent && window.parent.ProxmoxVExI18n;
    // English fallback so the page renders readable strings when opened
    // standalone (no parent ProxmoxVExI18n bridge).
    const EN_FALLBACK = {
        title: 'TrueNAS', overview: 'Overview', pools: 'Pools & Disks', datasets: 'Datasets',
        snapshots: 'Snapshots', shares: 'Shares', replication: 'Replication', services: 'Services',
        healthy: 'Healthy', unreachable: 'Unreachable', noInstances: 'No instances',
        noInstancesConfigured: 'No instances configured', add: 'Add', delete: 'Delete', run: 'Run',
        retry: 'Retry', loading: 'Loading…', loadError: 'Failed to load data.',
        noPools: 'No pools.', noDatasets: 'No datasets.', noSnapshots: 'No snapshots.',
        noShares: 'No shares.', noReplications: 'No replication tasks.', noServices: 'No services.',
        name: 'Name', dataset: 'Dataset', path: 'Path', type: 'Type', recursive: 'Recursive',
        searchDatasets: 'Search datasets...', searchSnapshots: 'Search snapshots...',
        colState: 'State', colUsage: 'Usage', colDisks: 'Disks', colUsed: 'Used',
        colAvailable: 'Available', colCreated: 'Created', colRunning: 'Running', actions: 'Actions',
        yes: 'Yes', no: 'No', start: 'Start', stop: 'Stop',
        instances: 'Instances', selectInstance: 'Select an instance',
        added: 'Added', deleted: 'Deleted', updated: 'Updated', started: 'Replication started.',
        confirmDeleteSnapshot: 'Delete snapshot?',
        confirmDeleteInstance: 'Delete this instance and all of its resources?',
        promptDatasetName: 'Type dataset name to confirm:',
        alreadyRunning: 'Replication is already running.',
        error: 'Error: {msg}',
    };
    const t = (k, p) => {
        let s;
        if (i18n) s = i18n.getT('truenas')(k, p ? { params: p } : undefined);
        // Fall back to the embedded English map when the bridge is absent or the
        // namespace lacks the key (loader returns the key itself for misses).
        if (!s || s === k) {
            s = EN_FALLBACK[k] || k;
            if (p) Object.keys(p).forEach(key => { s = s.replaceAll(`{${key}}`, p[key]); });
        }
        return s;
    };
    if (i18n) i18n.loadPluginNamespaceFull('truenas', '/api/plugins/truenas/i18n');

    let selectedInstance = '';

    async function api(path, method = 'GET', body = null) {
        const opts = { method, credentials: 'same-origin', headers: { 'X-Requested-With': 'XMLHttpRequest' } };
        if (body) { opts.headers['Content-Type'] = 'application/json'; opts.body = JSON.stringify(body); }
        const res = await fetch(path, opts);
        const data = await res.json().catch(() => ({}));
        if (!res.ok) throw new Error(data.error || `HTTP ${res.status}`);
        return data;
    }
    function escapeHtml(s) { const d = document.createElement('div'); d.textContent = String(s); return d.innerHTML; }
    function showMessage(text, type) { const m = $('message'); m.innerHTML = DOMPurify.sanitize(`<div class="message ${type}">${escapeHtml(text)}</div>`); setTimeout(() => { m.innerHTML = ''; }, 4000); }
    function applyI18n() {
        document.querySelectorAll('[data-i18n]').forEach(el => { el.textContent = t(el.dataset.i18n); });
        document.querySelectorAll('[data-i18n-ph]').forEach(el => { el.placeholder = t(el.dataset.i18nPh); });
    }
    function setLoading(id) { $(id).innerHTML = `<p class="empty">${escapeHtml(t('loading'))}</p>`; }
    function setLoadError(id, retry) {
        const c = $(id); c.innerHTML = '';
        const p = document.createElement('p'); p.className = 'empty'; p.textContent = t('loadError');
        const b = document.createElement('button'); b.className = 'secondary'; b.textContent = t('retry');
        b.addEventListener('click', retry);
        c.appendChild(p); c.appendChild(b);
    }

    async function loadInstances() {
        try {
            const d = await api('instances');
            const sel = $('instanceSelect');
            if (!d.instances.length) {
                sel.innerHTML = `<option disabled selected>${escapeHtml(t('noInstancesConfigured'))}</option>`;
                $('connChip').textContent = t('noInstances');
                $('connChip').classList.add('error');
                return;
            }
            sel.innerHTML = DOMPurify.sanitize(d.instances.map(i => `<option value="${escapeHtml(i.id)}">${escapeHtml(i.name)}</option>`).join(''));
            selectedInstance = d.instances[0].id;
            setInstanceChip(d.instances[0]);
            loadOverview();
        } catch (e) { showMessage(e.message, 'error'); }
    }

    function setInstanceChip(inst) {
        const chip = $('connChip');
        if (inst.healthy) { chip.textContent = t('healthy'); chip.className = 'chip'; } else { chip.textContent = t('unreachable'); chip.className = 'chip error'; }
    }

    async function loadOverview() { try { const params = new URLSearchParams(); if (selectedInstance) params.set('instance_id', selectedInstance); const d = await api('dashboard?' + params.toString()); $('overviewStats').innerHTML = DOMPurify.sanitize(`<div class="stat"><div class="value">${escapeHtml(d.instances)}</div><div class="muted">${escapeHtml(t('instances'))}</div></div><div class="stat"><div class="value">${escapeHtml(d.pools)}</div><div class="muted">${escapeHtml(t('pools'))}</div></div><div class="stat"><div class="value">${escapeHtml(d.datasets)}</div><div class="muted">${escapeHtml(t('datasets'))}</div></div><div class="stat"><div class="value">${escapeHtml(d.shares)}</div><div class="muted">${escapeHtml(t('shares'))}</div></div>`); } catch (e) { showMessage(e.message, 'error'); } }

    async function loadPools() {
        setLoading('poolsList');
        try { const params = new URLSearchParams(); if (selectedInstance) params.set('instance_id', selectedInstance); const d = await api('pools?' + params.toString()); if (!d.pools.length) { $('poolsList').innerHTML = `<p class="empty">${escapeHtml(t('noPools'))}</p>`; return; } let html = `<table><thead><tr><th scope="col">${escapeHtml(t('name'))}</th><th scope="col">${escapeHtml(t('colState'))}</th><th scope="col">${escapeHtml(t('colUsage'))}</th><th scope="col">${escapeHtml(t('colDisks'))}</th></tr></thead><tbody>`; d.pools.forEach(p => { html += `<tr><td>${escapeHtml(p.name)}</td><td>${escapeHtml(p.state)}</td><td class="muted">${escapeHtml(p.usage)}%</td><td class="muted">${(p.disks || []).map(d => escapeHtml(d.name)).join(', ')}</td></tr>`; }); html += '</tbody></table>'; $('poolsList').innerHTML = DOMPurify.sanitize(html); } catch (e) { setLoadError('poolsList', loadPools); showMessage(e.message, 'error'); }
    }

    async function loadDatasets() {
        setLoading('datasetsList');
        try { const params = new URLSearchParams(); if (selectedInstance) params.set('instance_id', selectedInstance); if ($('datasetSearch').value) params.set('q', $('datasetSearch').value); const d = await api('datasets?' + params.toString()); if (!d.datasets.length) { $('datasetsList').innerHTML = `<p class="empty">${escapeHtml(t('noDatasets'))}</p>`; return; } let html = `<table><thead><tr><th scope="col">${escapeHtml(t('name'))}</th><th scope="col">${escapeHtml(t('colUsed'))}</th><th scope="col">${escapeHtml(t('colAvailable'))}</th><th scope="col">${escapeHtml(t('actions'))}</th></tr></thead><tbody>`; d.datasets.forEach(ds => { html += `<tr><td>${escapeHtml(ds.name)}</td><td class="muted">${escapeHtml(ds.used)}</td><td class="muted">${escapeHtml(ds.available)}</td><td><button class="secondary deleteDs" data-id="${escapeHtml(ds.id)}" data-name="${escapeHtml(ds.name)}">${escapeHtml(t('delete'))}</button></td></tr>`; }); html += '</tbody></table>'; $('datasetsList').innerHTML = DOMPurify.sanitize(html); document.querySelectorAll('.deleteDs').forEach(b => b.addEventListener('click', async (e) => { const name = prompt(t('promptDatasetName')); if (!name) return; try { await api('datasets/delete', 'POST', { id: e.target.dataset.id, confirm: name }); showMessage(t('deleted'), 'success'); loadDatasets(); } catch (err) { showMessage(err.message, 'error'); } })); } catch (e) { setLoadError('datasetsList', loadDatasets); showMessage(e.message, 'error'); }
    }

    async function loadSnapshots() {
        setLoading('snapshotsList');
        try { const params = new URLSearchParams(); if (selectedInstance) params.set('instance_id', selectedInstance); if ($('snapshotSearch').value) params.set('q', $('snapshotSearch').value); const d = await api('snapshots?' + params.toString()); if (!d.snapshots.length) { $('snapshotsList').innerHTML = `<p class="empty">${escapeHtml(t('noSnapshots'))}</p>`; return; } let html = `<table><thead><tr><th scope="col">${escapeHtml(t('name'))}</th><th scope="col">${escapeHtml(t('dataset'))}</th><th scope="col">${escapeHtml(t('colCreated'))}</th><th scope="col">${escapeHtml(t('actions'))}</th></tr></thead><tbody>`; d.snapshots.forEach(s => { html += `<tr><td>${escapeHtml(s.name)}</td><td class="muted">${escapeHtml(s.dataset)}</td><td class="muted">${s.created ? new Date(s.created).toLocaleString() : '—'}</td><td><button class="secondary deleteSnap" data-id="${escapeHtml(s.id)}">${escapeHtml(t('delete'))}</button></td></tr>`; }); html += '</tbody></table>'; $('snapshotsList').innerHTML = DOMPurify.sanitize(html); document.querySelectorAll('.deleteSnap').forEach(b => b.addEventListener('click', async (e) => { if (!confirm(t('confirmDeleteSnapshot'))) return; try { await api('snapshots/delete', 'POST', { id: e.target.dataset.id }); showMessage(t('deleted'), 'success'); loadSnapshots(); } catch (err) { showMessage(err.message, 'error'); } })); } catch (e) { setLoadError('snapshotsList', loadSnapshots); showMessage(e.message, 'error'); }
    }

    async function loadShares() {
        setLoading('sharesList');
        try { const params = new URLSearchParams(); if (selectedInstance) params.set('instance_id', selectedInstance); const d = await api('shares?' + params.toString()); if (!d.shares.length) { $('sharesList').innerHTML = `<p class="empty">${escapeHtml(t('noShares'))}</p>`; return; } let html = `<table><thead><tr><th scope="col">${escapeHtml(t('type'))}</th><th scope="col">${escapeHtml(t('name'))}</th><th scope="col">${escapeHtml(t('path'))}</th></tr></thead><tbody>`; d.shares.forEach(s => { html += `<tr><td>${escapeHtml(s.type)}</td><td>${escapeHtml(s.name)}</td><td class="muted">${escapeHtml(s.path)}</td></tr>`; }); html += '</tbody></table>'; $('sharesList').innerHTML = DOMPurify.sanitize(html); } catch (e) { setLoadError('sharesList', loadShares); showMessage(e.message, 'error'); }
    }

    async function loadReplications() {
        setLoading('replicationsList');
        try { const params = new URLSearchParams(); if (selectedInstance) params.set('instance_id', selectedInstance); const d = await api('replications?' + params.toString()); if (!d.replications.length) { $('replicationsList').innerHTML = `<p class="empty">${escapeHtml(t('noReplications'))}</p>`; return; } let html = `<table><thead><tr><th scope="col">${escapeHtml(t('name'))}</th><th scope="col">${escapeHtml(t('colState'))}</th><th scope="col">${escapeHtml(t('actions'))}</th></tr></thead><tbody>`; d.replications.forEach(r => { const running = r.state === 'running'; html += `<tr><td>${escapeHtml(r.name)}</td><td>${escapeHtml(r.state)}</td><td><button class="secondary runRep" data-id="${escapeHtml(r.id)}" ${running ? 'disabled' : ''}>${running ? escapeHtml(t('colRunning')) : escapeHtml(t('run'))}</button></td></tr>`; }); html += '</tbody></table>'; $('replicationsList').innerHTML = DOMPurify.sanitize(html); document.querySelectorAll('.runRep').forEach(b => b.addEventListener('click', async (e) => { e.target.disabled = true; try { await api('replications/run', 'POST', { id: e.target.dataset.id }); showMessage(t('started'), 'success'); loadReplications(); } catch (err) { e.target.disabled = false; showMessage(err.message, 'error'); } })); } catch (e) { setLoadError('replicationsList', loadReplications); showMessage(e.message, 'error'); }
    }

    async function loadServices() {
        setLoading('servicesList');
        try { const params = new URLSearchParams(); if (selectedInstance) params.set('instance_id', selectedInstance); const d = await api('services?' + params.toString()); if (!d.services.length) { $('servicesList').innerHTML = `<p class="empty">${escapeHtml(t('noServices'))}</p>`; return; } let html = `<table><thead><tr><th scope="col">${escapeHtml(t('name'))}</th><th scope="col">${escapeHtml(t('colRunning'))}</th><th scope="col">${escapeHtml(t('actions'))}</th></tr></thead><tbody>`; d.services.forEach(s => { html += `<tr><td>${escapeHtml(s.name)}</td><td>${s.running ? `<span class="chip">${escapeHtml(t('yes'))}</span>` : `<span class="chip error">${escapeHtml(t('no'))}</span>`}</td><td><button class="secondary toggleSvc" data-id="${escapeHtml(s.id)}" data-run="${escapeHtml(!s.running)}">${s.running ? escapeHtml(t('stop')) : escapeHtml(t('start'))}</button></td></tr>`; }); html += '</tbody></table>'; $('servicesList').innerHTML = DOMPurify.sanitize(html); document.querySelectorAll('.toggleSvc').forEach(b => b.addEventListener('click', async (e) => { try { await api('services/set', 'POST', { id: e.target.dataset.id, running: e.target.dataset.run === 'true' }); showMessage(t('updated'), 'success'); loadServices(); } catch (err) { showMessage(err.message, 'error'); } })); } catch (e) { setLoadError('servicesList', loadServices); showMessage(e.message, 'error'); }
    }

    $('instanceSelect').addEventListener('change', (e) => { selectedInstance = e.target.value; loadOverview(); });

    $('datasetForm').addEventListener('submit', async (e) => { e.preventDefault(); const f = e.target; if (!selectedInstance) { showMessage(t('selectInstance'), 'error'); return; } try { await api('datasets/add', 'POST', { instance_id: selectedInstance, name: f.name.value }); showMessage(t('added'), 'success'); f.reset(); loadDatasets(); } catch (err) { showMessage(err.message, 'error'); } });

    $('snapshotForm').addEventListener('submit', async (e) => { e.preventDefault(); const f = e.target; if (!selectedInstance) { showMessage(t('selectInstance'), 'error'); return; } try { await api('snapshots/add', 'POST', { instance_id: selectedInstance, dataset: f.dataset.value, name: f.name.value, recursive: f.recursive.checked }); showMessage(t('added'), 'success'); f.reset(); loadSnapshots(); } catch (err) { showMessage(err.message, 'error'); } });

    $('shareForm').addEventListener('submit', async (e) => { e.preventDefault(); const f = e.target; if (!selectedInstance) { showMessage(t('selectInstance'), 'error'); return; } try { await api('shares/add', 'POST', { instance_id: selectedInstance, type: f.type.value, name: f.name.value, path: f.path.value }); showMessage(t('added'), 'success'); f.reset(); loadShares(); } catch (err) { showMessage(err.message, 'error'); } });

    $('datasetSearch').addEventListener('input', loadDatasets);
    $('snapshotSearch').addEventListener('input', loadSnapshots);

    document.querySelectorAll('.tab').forEach(t => t.addEventListener('click', () => {
        document.querySelectorAll('.tab').forEach(x => { x.classList.remove('active'); x.setAttribute('aria-selected', 'false'); });
        document.querySelectorAll('.panel').forEach(x => x.classList.remove('active'));
        t.classList.add('active'); t.setAttribute('aria-selected', 'true'); $(t.dataset.tab + 'Panel').classList.add('active');
        if (t.dataset.tab === 'overview') loadOverview();
        if (t.dataset.tab === 'pools') loadPools();
        if (t.dataset.tab === 'datasets') loadDatasets();
        if (t.dataset.tab === 'snapshots') loadSnapshots();
        if (t.dataset.tab === 'shares') loadShares();
        if (t.dataset.tab === 'replication') loadReplications();
        if (t.dataset.tab === 'services') loadServices();
    }));

    (async () => { if (i18n) await i18n.loadPluginNamespaceFull('truenas', '/api/plugins/truenas/i18n'); applyI18n(); await loadInstances(); })();
})();
