/* --- ProxmoxVEx auto-header start ---
 * -------------------------------------------------------------------
 * File:        web/src/stepup_modal.js
 * Project:     ProxmoxVEx
 * Version:     1.2.437
 * Build:       2026.09.12
 * Description: Step-up MFA modal + fetch interception (spec 038).
 * Docs:        https://proxmoxvex.com/docs
 * Generated:   2026-09-12
 * -------------------------------------------------------------------
 * --- ProxmoxVEx auto-header end --- */
// Step-up MFA modal + fetch interception (spec 038).
//
// Destructive endpoints answer 403 {requires_stepup: true} when the session has
// no live elevation. A global fetch wrapper catches that response, asks
// StepUpHost (mounted in the app shell) to collect a fresh factor, then retries
// the original request once on success.

(function installStepUpInterceptor() {
    if (window.__proxmoxvexStepUpFetchInstalled) return;
    window.__proxmoxvexStepUpFetchInstalled = true;
    const origFetch = window.fetch.bind(window);
    window.fetch = async function proxmoxvexStepUpFetch(...args) {
        const resp = await origFetch(...args);
        if (resp.status !== 403) return resp;
        let data;
        try {
            data = await resp.clone().json();
        } catch (_) {
            return resp; // non-JSON 403 — nothing to do
        }
        if (data && data.requires_2fa_setup) {
            // Admin enabled force-MFA mid-session — flip the app into the
            // mandatory enrollment screen.
            window.dispatchEvent(new CustomEvent('proxmoxvex:requires-2fa-setup'));
            return resp;
        }
        if (!data || !data.requires_stepup) return resp;
        if (typeof window.__proxmoxvexStepUpRequest !== 'function') return resp;
        const ok = await window.__proxmoxvexStepUpRequest(data);
        if (ok) return origFetch(...args); // elevated — retry once
        return resp;
    };
})();

function StepUpModal({ request, onDone }) {
    const { user } = useAuth();
    const { t } = useTranslation();
    const [code, setCode] = useState('');
    const [error, setError] = useState('');
    const [busy, setBusy] = useState(false);
    const [webauthnBusy, setWebauthnBusy] = useState(false);

    const methods = request.methods || [];
    const hasTotp = methods.includes('totp');
    const hasWebauthn = methods.includes('webauthn');

    const finish = (ok) => { onDone(ok); };

    const submitCode = async () => {
        if (!code || busy) return;
        setBusy(true);
        setError('');
        try {
            const r = await fetch(`${API_URL}/auth/stepup/verify`, {
                method: 'POST',
                credentials: 'include',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ code }),
            });
            const d = await r.json().catch(() => ({}));
            if (r.ok && d.success) return finish(true);
            setError(d.error || t('stepupInvalidCode') || 'Invalid code');
            setCode('');
        } catch (e) {
            setError(t('connectionError') || 'Connection error');
        }
        setBusy(false);
    };

    const submitWebauthn = async () => {
        if (!('credentials' in navigator) || !navigator.credentials.get) return;
        setWebauthnBusy(true);
        setError('');
        try {
            const b64urlToBuf = (s) => {
                const pad = '='.repeat((4 - s.length % 4) % 4);
                const bin = atob((s + pad).replace(/-/g, '+').replace(/_/g, '/'));
                const buf = new Uint8Array(bin.length);
                for (let i = 0; i < bin.length; i++) buf[i] = bin.charCodeAt(i);
                return buf.buffer;
            };
            const bufToB64url = (buf) => {
                const bin = String.fromCharCode(...new Uint8Array(buf));
                return btoa(bin).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
            };
            const begin = await fetch(`${API_URL}/webauthn/auth/begin`, {
                method: 'POST', headers: { 'Content-Type': 'application/json' },
                credentials: 'include', body: JSON.stringify({ username: user?.username }),
            });
            if (!begin.ok) throw new Error((await begin.json().catch(() => ({}))).error || `begin ${begin.status}`);
            const opts = await begin.json();
            const pko = opts.publicKey || opts;
            const publicKey = {
                ...pko,
                challenge: b64urlToBuf(pko.challenge),
                allowCredentials: (pko.allowCredentials || []).map(c => ({ ...c, id: b64urlToBuf(c.id) })),
            };
            const assertion = await navigator.credentials.get({ publicKey });
            if (!assertion) throw new Error('cancelled');
            const finishBody = {
                username: user?.username,
                id: assertion.id,
                rawId: bufToB64url(assertion.rawId),
                type: assertion.type,
                response: {
                    clientDataJSON: bufToB64url(assertion.response.clientDataJSON),
                    authenticatorData: bufToB64url(assertion.response.authenticatorData),
                    signature: bufToB64url(assertion.response.signature),
                    userHandle: assertion.response.userHandle ? bufToB64url(assertion.response.userHandle) : null,
                },
            };
            const fin = await fetch(`${API_URL}/webauthn/auth/finish`, {
                method: 'POST', headers: { 'Content-Type': 'application/json' },
                credentials: 'include', body: JSON.stringify(finishBody),
            });
            const fd = await fin.json().catch(() => ({}));
            if (!fin.ok || !fd.proof) throw new Error(fd.error || `finish ${fin.status}`);
            const r = await fetch(`${API_URL}/auth/stepup/verify`, {
                method: 'POST',
                credentials: 'include',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ webauthn_proof: fd.proof }),
            });
            const d = await r.json().catch(() => ({}));
            if (r.ok && d.success) return finish(true);
            setError(d.error || t('stepupInvalidCode') || 'Verification failed');
        } catch (e) {
            console.warn('stepup webauthn:', e);
            setError(t('stepupWebauthnFailed') || 'Security key verification failed');
        }
        setWebauthnBusy(false);
    };

    return (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-[200] p-4">
            <div className="bg-proxmox-card border border-proxmox-border rounded-xl w-full max-w-md shadow-2xl">
                <div className="p-6">
                    <div className="flex items-center gap-3 mb-4">
                        <div className="p-2 bg-proxmox-orange/20 rounded-lg">
                            <Icons.Shield className="w-6 h-6 text-proxmox-orange" />
                        </div>
                        <h2 className="text-lg font-semibold text-white">{t('stepupTitle')}</h2>
                    </div>
                    <p className="text-gray-400 text-sm mb-4">
                        {t('stepupDesc')}
                    </p>

                    {request.enrollment_required && (
                        <div className="mb-4 p-3 bg-yellow-500/10 border border-yellow-500/30 rounded-lg">
                            <p className="text-sm text-yellow-400">{t('stepupEnrollmentRequired')}</p>
                        </div>
                    )}

                    {hasTotp && (
                        <div className="space-y-3">
                            <input
                                type="text"
                                value={code}
                                onChange={e => { setError(''); setCode(e.target.value.replace(/\D/g, '').slice(0, 6)); }}
                                onKeyDown={e => e.key === 'Enter' && submitCode()}
                                placeholder="000000"
                                className="w-full text-center text-2xl tracking-[0.5em] bg-proxmox-dark border border-proxmox-border rounded-lg p-3 text-white font-mono"
                                autoFocus
                            />
                            <button
                                onClick={submitCode}
                                disabled={busy || code.length !== 6}
                                className="w-full px-4 py-2.5 bg-proxmox-orange hover:bg-orange-600 rounded-lg text-white font-medium transition-colors disabled:opacity-50 flex items-center justify-center gap-2"
                            >
                                {busy && <Icons.RotateCw className="w-4 h-4 animate-spin" />}
                                {t('stepupVerify')}
                            </button>
                        </div>
                    )}

                    {hasWebauthn && (
                        <button
                            onClick={submitWebauthn}
                            disabled={webauthnBusy}
                            className={`w-full px-4 py-2.5 ${hasTotp ? 'mt-3 bg-proxmox-dark border border-proxmox-border hover:bg-proxmox-hover' : 'bg-proxmox-orange hover:bg-orange-600'} rounded-lg text-white font-medium transition-colors disabled:opacity-50 flex items-center justify-center gap-2`}
                        >
                            {webauthnBusy && <Icons.RotateCw className="w-4 h-4 animate-spin" />}
                            {t('stepupUseSecurityKey')}
                        </button>
                    )}

                    {error && (
                        <div className="mt-4 p-3 bg-red-500/20 border border-red-500/30 rounded-lg">
                            <p className="text-sm text-red-400">{error}</p>
                        </div>
                    )}

                    <button
                        onClick={() => finish(false)}
                        className="w-full mt-4 px-4 py-2 text-sm text-gray-400 hover:text-white transition-colors"
                    >
                        {t('cancel')}
                    </button>
                </div>
            </div>
        </div>
    );
}

function StepUpHost() {
    const [pending, setPending] = useState(null);

    useEffect(() => {
        // Fetch wrapper registers here; resolves true (retry) or false (deny).
        window.__proxmoxvexStepUpRequest = (data) =>
            new Promise(resolve => setPending({ ...data, resolve }));
        return () => { window.__proxmoxvexStepUpRequest = null; };
    }, []);

    if (!pending) return null;
    return (
        <StepUpModal
            request={pending}
            onDone={(ok) => {
                const resolve = pending.resolve;
                setPending(null);
                resolve(ok);
            }}
        />
    );
}
