/* --- ProxmoxVEx auto-header start ---
 * -------------------------------------------------------------------
 * File:        web/src/i18n_bridge.js
 * Project:     ProxmoxVEx
 * Version:     1.2.437
 * Build:       2026.09.12
 * Description: I18N Bridge JS source
 * Docs:        https://proxmoxvex.com/docs
 * Generated:   2026-09-12
 * -------------------------------------------------------------------
 * --- ProxmoxVEx auto-header end --- */
(function () {
    // Auto-discover every inlined core locale, converting the safe JS variable
    // name (e.g. _i18n_core_zh_hans) back to the original language code.
    var coreLangs = {};
    var _i18nPrefix = '_i18n_core_';
    for (var _k in window) {
        if (_k.indexOf(_i18nPrefix) === 0 && typeof window[_k] === 'object' && window[_k] !== null) {
            var _code = _k.substring(_i18nPrefix.length).replace(/_/g, '-');
            coreLangs[_code] = window[_k];
        }
    }

    ProxmoxVExI18n.registerNamespaceBulk('core', coreLangs);

    // Backward-compatible `translations` object for contexts.js
    // contexts.js does: translations[language]?.[key]
    window.translations = coreLangs;
})();

// Legacy alias — the variable name contexts.js references directly.
var translations = window.translations;

// ISS-074: postMessage bridge for sandboxed plugin iframes. Plugins running
// without allow-same-origin cannot reach window.parent.ProxmoxVExI18n, so the
// parent answers a small RPC surface instead. This is additive — existing
// same-origin plugins keep working; new plugins can drop allow-same-origin.
(function () {
    if (typeof window === 'undefined' || window.__ProxmoxVExI18nBridge) return;
    window.__ProxmoxVExI18nBridge = true;
    window.addEventListener('message', function (ev) {
        var d = ev.data;
        if (!d || typeof d !== 'object' || d.__ProxmoxVEx_i18n_req !== true) return;
        // Only answer frames we actually host
        var iframes = document.querySelectorAll('iframe');
        var hosted = false;
        for (var i = 0; i < iframes.length; i++) {
            if (iframes[i].contentWindow === ev.source) { hosted = true; break; }
        }
        if (!hosted) return;
        var reply = function (payload) {
            ev.source.postMessage(Object.assign({ __ProxmoxVEx_i18n_res: true, id: d.id }, payload), ev.origin === 'null' ? '*' : ev.origin);
        };
        try {
            if (d.op === 't') {
                reply({ value: ProxmoxVExI18n.t(d.key, d.opts || {}) });
            } else if (d.op === 'register') {
                ProxmoxVExI18n.registerNamespaceBulk(d.ns, d.langs || {});
                reply({ ok: true });
            } else if (d.op === 'lang') {
                reply({ lang: (ProxmoxVExI18n.getLanguage && ProxmoxVExI18n.getLanguage()) || undefined });
            } else if (d.op === 'theme') {
                if (window.ProxmoxVExGetActiveTheme) reply({ theme: window.ProxmoxVExGetActiveTheme() });
                else reply({ theme: null });
            } else {
                reply({ error: 'unknown op' });
            }
        } catch (e) {
            reply({ error: String(e) });
        }
    });
})();
