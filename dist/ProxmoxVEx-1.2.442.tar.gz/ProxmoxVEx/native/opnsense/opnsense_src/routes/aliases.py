# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/native/opnsense/opnsense_src/routes/aliases.py
# Project:     ProxmoxVEx
# Version:     1.2.437
# Build:       2026.09.12
# Description: Aliases endpoint — list + CRUD.
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-12
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Alias route payloads — GET lists `/api/firewall/alias` items in the
canonical shape; POST dispatches create/update/delete on the AliasWriter
(spec 003 US2 — writer existed, route was missing)."""

from __future__ import annotations

import logging
from typing import Any

from opnsense_src._fwkit import ensure_fwkit_importable
from opnsense_src.client import OPNsenseClient, OPNsenseHost
from opnsense_src.routes._domain import dispatch_action, make_writer
from opnsense_src.writers import AliasInput, AliasWriter

ensure_fwkit_importable()

from ProxmoxVEx.native.fwkit.normalize import normalize_alias  # noqa: E402
from ProxmoxVEx.native.fwkit.payloads import client_error_envelope, ok  # noqa: E402

log = logging.getLogger(__name__)


def build_aliases_list_payload(host: OPNsenseHost) -> tuple[int, dict[str, Any]]:
    client = OPNsenseClient(host)
    try:
        out = client.get("/api/firewall/alias/searchItem")
        rows = out.get("rows", []) if isinstance(out, dict) else []
        aliases = [normalize_alias(r, "opnsense", i) for i, r in enumerate(rows)]
        return ok({"aliases": aliases, "total": len(aliases)})
    except Exception as e:
        return client_error_envelope(e, log_label="opnsense aliases list")


def _alias_input(body: dict[str, Any]) -> AliasInput:
    alias = body.get("alias") or {}
    if not isinstance(alias, dict):
        raise ValueError("alias must be an object")
    content = alias.get("content", "")
    if isinstance(content, list):
        content = "\n".join(str(e) for e in content)
    return AliasInput(
        name=str(alias.get("name", "")),
        type=str(alias.get("type", "host")),
        content=str(content),
        description=str(alias.get("description", "")),
        enabled=bool(alias.get("enabled", True)),
    )


def _uuid(body: dict[str, Any]) -> str:
    uid = str(body.get("uuid", ""))
    if not uid:
        raise ValueError("uuid is required")
    return uid


def build_aliases_action_payload(
    host: OPNsenseHost,
    plugin_dir: str,
    body: dict[str, Any],
    *,
    peer_host: OPNsenseHost | None = None,
    actor: str = "plugin",
) -> tuple[int, dict[str, Any]]:
    writer = make_writer(AliasWriter, host, peer_host, plugin_dir, actor)
    return dispatch_action(writer, body, {
        "create": lambda b: writer.create(_alias_input(b)),
        "update": lambda b: writer.update(_uuid(b), _alias_input(b)),
        "delete": lambda b: writer.delete(_uuid(b)),
    })
