# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/demo/seed.py
# Project:     ProxmoxVEx
# Version:     1.2.499
# Build:       2026.09.23
# Description: Seed synthetic demo fixtures when demo mode is enabled.
# Usage:       import ProxmoxVEx.demo.seed
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-23
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Seed synthetic demo fixtures when demo mode is enabled.

This module creates the demo user and a synthetic cluster record.  It is
idempotent so it can safely be run on every startup.
"""

import json
import logging
from datetime import UTC, datetime

from ProxmoxVEx.core.db import get_db
from ProxmoxVEx.demo import (
    DEMO_CLUSTER_HOST,
    DEMO_CLUSTER_ID,
    DEMO_PASSWORD,
    DEMO_ROLE,
    DEMO_USERNAME,
    is_demo_mode,
)
from ProxmoxVEx.utils.auth import hash_password


def _ensure_demo_user():
    """Create or reset the low-privilege demo user."""
    db = get_db()
    users = db.get_all_users()
    if DEMO_USERNAME in users:
        # Keep the seeded user's role in sync with DEMO_ROLE (upgrades from
        # viewer → admin for full read-only coverage of the demo UI).
        existing = users.get(DEMO_USERNAME) or {}
        if existing.get("role") != DEMO_ROLE:
            db.save_user(DEMO_USERNAME, dict(existing, role=DEMO_ROLE))
        return

    salt, password_hash = hash_password(DEMO_PASSWORD)
    demo_user = {
        "password_salt": salt,
        "password_hash": password_hash,
        "role": DEMO_ROLE,
        "permissions": [],
        "tenant": "",
        "auth_source": "demo",
        "is_demo": True,
        "display_name": "Demo User",
        "email": "",
        "enabled": True,
        "theme": "",
        "language": "",
        "ui_layout": "modern",
        "created_at": datetime.now(UTC).isoformat(),
    }
    db.save_user(DEMO_USERNAME, demo_user)
    logging.info(f"[DEMO_SEED] Created demo user '{DEMO_USERNAME}'")


# Synthetic demo clusters — one record per host the cluster mock serves.
# ``host`` selects the dataset in demo/cluster_mock.py; ``group_id`` and the
# latitude/longitude/location_label triple drive the sidebar grouping and the
# world map so the demo shows off multi-region organisation.
DEMO_GROUPS = [
    ("grp-production", "Production", "Primary production clusters", "#E86F2D", 0),
    ("grp-edge", "Edge", "Edge and lab sites", "#3B82F6", 1),
]

DEMO_CLUSTERS = [
    {
        "id": DEMO_CLUSTER_ID,
        "name": "Production EU",
        "host": DEMO_CLUSTER_HOST,
        "group_id": "grp-production",
        "sort_order": 0,
        "latitude": 50.1109,
        "longitude": 8.6821,
        "location_label": "Frankfurt, DE",
    },
    {
        "id": "demo-us",
        "name": "Production US",
        "host": "demo-us",
        "group_id": "grp-production",
        "sort_order": 1,
        "latitude": 39.0438,
        "longitude": -77.4874,
        "location_label": "Ashburn, US",
    },
    {
        "id": "demo-sg",
        "name": "Edge Lab Singapore",
        "host": "demo-sg",
        "group_id": "grp-edge",
        "sort_order": 0,
        "latitude": 1.3521,
        "longitude": 103.8198,
        "location_label": "Singapore, SG",
    },
]

_DEMO_CLUSTER_IDS = [c["id"] for c in DEMO_CLUSTERS]


def _ensure_demo_cluster_groups():
    """Create the cluster groups the demo clusters are filed under."""
    db = get_db()
    now = datetime.now(UTC).isoformat()
    for gid, name, desc, color, order in DEMO_GROUPS:
        db.execute(
            """
            INSERT OR IGNORE INTO cluster_groups
            (id, name, description, color, tenant_id, sort_order, created_at, updated_at)
            VALUES (?, ?, ?, ?, NULL, ?, ?, ?)
            """,
            (gid, name, desc, color, order, now, now),
        )
    logging.info("[DEMO_SEED] Ensured demo cluster groups")


def _ensure_demo_cluster():
    """Create the synthetic demo cluster records.

    Each cluster uses a ``demo*`` host which the manager mock intercepts and
    serves from a per-host fixture dataset — no real hypervisor connection is
    attempted.  Metadata (group, sort order, map location) is refreshed on
    every seed so reset/upgrade cycles converge to the same layout.
    """
    db = get_db()

    now = datetime.now(UTC).isoformat()
    for spec in DEMO_CLUSTERS:
        demo_cluster = {
            "name": spec["name"],
            "display_name": spec["name"],
            "host": spec["host"],
            "user": "demo",
            "pass": "",
            "ssl_verification": False,
            "migration_threshold": 30,
            "check_interval": 300,
            "auto_migrate": False,
            "balance_containers": False,
            "balance_local_disks": False,
            "dry_run": True,
            "enabled": True,
            "ha_enabled": False,
            "fallback_hosts": [],
            "ssh_user": "",
            "ssh_key": "",
            "ssh_port": 22,
            "api_port": 8006,
            "ha_settings": {},
            "group_id": spec["group_id"],
            "sort_order": spec["sort_order"],
            "latitude": spec["latitude"],
            "longitude": spec["longitude"],
            "location_label": spec["location_label"],
            "created_at": now,
            "updated_at": now,
        }
        db.save_cluster(spec["id"], demo_cluster)
        logging.info(f"[DEMO_SEED] Ensured demo cluster '{spec['id']}'")


def _ensure_demo_migration_history():
    """Seed a few migration rows per cluster so the Migrations view has data."""
    db = get_db()
    now = datetime.now(UTC)
    demo_migrations = [
        ("demo", 105, "k8s-w-01", "pve-demo-01", "pve-demo-02", "manual by demo@pve", "completed", 19.4, (now.timestamp() - 259200)),
        ("demo", 106, "k8s-w-02", "pve-demo-02", "pve-demo-03", "manual by demo@pve", "completed", 23.1, (now.timestamp() - 172800)),
        ("demo", 100, "web-01", "pve-demo-02", "pve-demo-01", "rebalance by ProxmoxVEx", "completed", 14.8, (now.timestamp() - 345600)),
        ("demo-us", 1105, "k8s-us-w-01", "pve-us-01", "pve-us-02", "manual by demo@pve", "completed", 21.7, (now.timestamp() - 200000)),
        ("demo-us", 1101, "orders-db-01", "pve-us-02", "pve-us-01", "rebalance by ProxmoxVEx", "completed", 38.2, (now.timestamp() - 300000)),
        ("demo-sg", 2105, "k3s-w-01", "pve-sg-02", "pve-sg-01", "manual by demo@pve", "completed", 12.6, (now.timestamp() - 150000)),
    ]
    cursor = db.conn.cursor()
    for cluster_id, vmid, vm_name, src, dst, reason, status, duration, ts in demo_migrations:
        cursor.execute(
            "SELECT COUNT(*) AS c FROM migration_history WHERE cluster_id = ? AND vmid = ?",
            (cluster_id, vmid),
        )
        row = cursor.fetchone()
        if row and (row["c"] if isinstance(row, dict) else row[0]):
            continue
        cursor.execute(
            """
            INSERT INTO migration_history
            (cluster_id, vmid, vm_name, source_node, target_node,
             reason, status, duration_seconds, timestamp)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (cluster_id, vmid, vm_name, src, dst, reason, status, duration, datetime.fromtimestamp(ts, UTC).isoformat()),
        )
    db.conn.commit()
    logging.info("[DEMO_SEED] Seeded demo migration history")


def _ensure_demo_alerts():
    """Seed alert rules per cluster so the Alerts view shows configured rules."""
    db = get_db()
    existing = db.get_all_alerts()
    alert_types = [
        ("node-cpu", "node_cpu", 85, 900),
        ("node-mem", "node_memory", 90, 900),
        ("storage", "storage", 80, 3600),
        ("vm-down", "vm_down", 0, 300),
    ]
    for cluster_id in _DEMO_CLUSTER_IDS:
        if any(a.get("cluster_id") == cluster_id for a in existing.values()):
            continue
        for suffix, atype, threshold, cooldown in alert_types:
            db.save_alert(
                f"{cluster_id}-{suffix}",
                {
                    "cluster_id": cluster_id,
                    "node": None,
                    "vmid": None,
                    "type": atype,
                    "threshold": threshold,
                    "enabled": True,
                    "notify_methods": ["email"],
                    "cooldown": cooldown,
                },
            )
    logging.info("[DEMO_SEED] Seeded demo alert rules")


def _ensure_demo_pbs_server():
    """Seed a synthetic PBS server so the backup-server surfaces show data.

    host='demo' port 8007 is intercepted by the cluster mock, which serves
    the PBS API from the ``pbs`` inventory fixture section — no real PBS
    is ever contacted.  It is linked to every demo cluster so the backup
    surfaces show coverage across regions.
    """
    db = get_db()
    cursor = db.conn.cursor()
    cursor.execute("SELECT COUNT(*) AS c FROM pbs_servers")
    row = cursor.fetchone()
    if row and (row["c"] if isinstance(row, dict) else row[0]):
        return

    now = datetime.now(UTC).isoformat()
    cursor.execute(
        """
        INSERT INTO pbs_servers
        (id, name, host, port, user, pass_encrypted, api_token_id,
         api_token_secret_encrypted, fingerprint, ssl_verify, enabled,
         linked_clusters, notes, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (
            "pbs-demo", "pbs-demo-01", DEMO_CLUSTER_HOST, 8007, "demo@pam",
            "", "demo@pam!demo", "", "", 0, 1,
            json.dumps(_DEMO_CLUSTER_IDS), "Synthetic demo backup server", now, now,
        ),
    )
    db.conn.commit()
    logging.info("[DEMO_SEED] Seeded demo PBS server")


def _ensure_demo_vmware_server():
    """Seed a synthetic vCenter so the VMware surface shows data.

    host='vcenter.demo.lab' is intercepted by the demo request mock and
    answered from the ``vcenter`` section of integrations.json.
    """
    db = get_db()
    cursor = db.conn.cursor()
    cursor.execute("SELECT COUNT(*) AS c FROM vmware_servers")
    row = cursor.fetchone()
    if row and (row["c"] if isinstance(row, dict) else row[0]):
        return

    now = datetime.now(UTC).isoformat()
    cursor.execute(
        """
        INSERT INTO vmware_servers
        (id, name, host, port, username, pass_encrypted, server_type,
         ssl_verify, enabled, linked_clusters, notes, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (
            "vmware-demo", "vcenter-01", "vcenter.demo.lab", 443,
            "demo@vsphere.local", db._encrypt("demo"), "vcenter",
            0, 1, '[]', "Synthetic demo vCenter", now, now,
        ),
    )
    db.conn.commit()
    logging.info("[DEMO_SEED] Seeded demo vCenter server")


def _ensure_demo_netapp_endpoint():
    """Seed a synthetic ONTAP endpoint for the NetApp plugin."""
    db = get_db()
    cursor = db.conn.cursor()
    try:
        cursor.execute("SELECT COUNT(*) AS c FROM netapp_endpoints")
    except Exception:
        return  # plugin tables not created yet
    row = cursor.fetchone()
    if row and (row["c"] if isinstance(row, dict) else row[0]):
        return

    now = datetime.now(UTC).isoformat()
    cursor.execute(
        """
        INSERT INTO netapp_endpoints
        (id, name, host, username, password_encrypted, ssl_verify, skip_nfs, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        ("ntap-demo", "ntap-01", "netapp.demo.lab", "demo", db._encrypt("demo"), 0, 0, now, now),
    )
    db.conn.commit()
    logging.info("[DEMO_SEED] Seeded demo NetApp endpoint")


def seed_demo():
    """Seed demo fixtures if demo mode is active."""
    if not is_demo_mode():
        return
    from ProxmoxVEx.demo import DEMO_SEED_VERSION

    logging.info(f"[DEMO_SEED] Seeding demo fixtures version {DEMO_SEED_VERSION}")
    try:
        _ensure_demo_user()
    except Exception as e:
        logging.error(f"[DEMO_SEED] Failed to seed demo user: {e}")
    try:
        _ensure_demo_cluster_groups()
    except Exception as e:
        logging.error(f"[DEMO_SEED] Failed to seed demo cluster groups: {e}")
    try:
        _ensure_demo_cluster()
    except Exception as e:
        logging.error(f"[DEMO_SEED] Failed to seed demo cluster: {e}")
    try:
        _ensure_demo_migration_history()
    except Exception as e:
        logging.error(f"[DEMO_SEED] Failed to seed migration history: {e}")
    try:
        _ensure_demo_alerts()
    except Exception as e:
        logging.error(f"[DEMO_SEED] Failed to seed alert rules: {e}")
    try:
        _ensure_demo_pbs_server()
    except Exception as e:
        logging.error(f"[DEMO_SEED] Failed to seed demo PBS server: {e}")
    try:
        _ensure_demo_vmware_server()
    except Exception as e:
        logging.error(f"[DEMO_SEED] Failed to seed demo vCenter server: {e}")
    try:
        _ensure_demo_netapp_endpoint()
    except Exception as e:
        logging.error(f"[DEMO_SEED] Failed to seed demo NetApp endpoint: {e}")
