# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/api/healthz.py
# Project:     ProxmoxVEx
# Version:     1.2.499
# Build:       2026.09.23
# Description: Spec 092/US026: deep readiness probe.
# Usage:       import ProxmoxVEx.api.healthz
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-23
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Spec 092/US026: deep readiness probe.

`/api/health` is a shallow liveness check (process up, version string) — load
balancers and alerts that watch it can't tell a wedged deployment from a
healthy one. `/api/healthz` reports per-dependency status: the app DB, every
configured cluster manager's connectivity, the cached license context's
validity, and disk headroom for the data volume. Each check runs in a worker
thread bounded by a timeout so a hung dependency marks itself failed instead
of hanging the probe — the response always arrives quickly.

The route is unauthenticated (it rides under the existing `/api/health`
public prefix) since readiness probes can't carry sessions, and it returns
only booleans per component — no internals leak.
"""

import logging
import shutil
import time
from concurrent.futures import ThreadPoolExecutor
from concurrent.futures import TimeoutError as FutTimeout

from flask import Blueprint, jsonify

from ProxmoxVEx.constants import CONFIG_DIR
from ProxmoxVEx.core.db import get_db
from ProxmoxVEx.globals import cluster_managers

bp = Blueprint("healthz", __name__)

# Per-check bound. 2s is generous for a SELECT 1 / flag read / statfs and keeps
# the worst-case probe latency at ~4 x 2s serial (checks run serially — a
# parallel fan-out would multiply connection pressure on a degraded system).
_CHECK_TIMEOUT = 2.0
# Disk is "up" while the config volume keeps this much headroom — below it
# sqlite/pg local state, logs, and snapshot scratch start failing anyway.
_DISK_MIN_FREE_BYTES = 128 * 1024 * 1024


def _db_ok() -> bool:
    return get_db().conn.execute("SELECT 1").fetchone() is not None


def _clusters_ok() -> bool:
    # No clusters configured is a valid (fresh-install) state — nothing is down.
    return all(getattr(m, "connected", False) for m in cluster_managers.values())


def _license_ok() -> bool:
    # Free/unlicensed tier is supported — the check only fails when a license
    # IS installed but has lapsed, since that's the state that breaks features.
    from ProxmoxVEx.services.licensing import LicensingService

    ctx = LicensingService().get_context(get_db())
    if ctx is None:
        return True
    if ctx.valid_until is None:
        return True
    from datetime import UTC, datetime

    return ctx.valid_until > datetime.now(UTC)


def _disk_ok() -> bool:
    return shutil.disk_usage(CONFIG_DIR).free > _DISK_MIN_FREE_BYTES


def _run_check(name, fn, timeout=_CHECK_TIMEOUT):
    """Run one probe in a thread with a hard bound — report, never raise."""
    with ThreadPoolExecutor(1) as ex:
        try:
            return name, bool(ex.submit(fn).result(timeout))
        except (FutTimeout, Exception) as e:
            logging.warning("[healthz] %s check failed: %s", name, e)
            return name, False


def _run_component_checks() -> dict:
    # Resolved per-request (not a module-level tuple of bound functions) so the
    # check fns stay patchable/hot-swappable.
    checks = (("db", _db_ok), ("clusters", _clusters_ok),
              ("license", _license_ok), ("disk", _disk_ok))
    return dict(_run_check(name, fn) for name, fn in checks)


@bp.route("/api/healthz", methods=["GET"])
def healthz():
    # spec 092/US084: while SIGTERM drain is in progress the instance must
    # report NOT ready so the LB/orchestrator pulls it before exit — but the
    # shallow /api/health liveness stays up (the process is still alive).
    from ProxmoxVEx.background import is_draining

    if is_draining():
        return jsonify(status="draining"), 503
    t0 = time.time()
    components = _run_component_checks()
    ok = all(components.values())
    if not ok:
        logging.warning(
            "[healthz] degraded: %s", {k: v for k, v in components.items() if not v}
        )
    return jsonify(
        status="ok" if ok else "degraded",
        components=components,
        elapsed_ms=round((time.time() - t0) * 1000, 1),
    ), (200 if ok else 503)


# ── spec 092/US031: public status feed for external status pages ──
# Same component checks as /healthz but cached 30s (status pages poll) and
# reduced to up/down names — plus sanitized status_incidents windows. No
# session required (it sits under the /api/health public prefix family);
# nothing internal leaks: no ids, actors, params, or check internals.
_status_cache: dict = {}
_STATUS_CACHE_TTL = 30.0
_INCIDENT_WINDOW_HOURS = 24


def _cached_components() -> dict:
    now = time.time()
    cached = _status_cache.get("components")
    if cached is None or (now - _status_cache.get("at", 0)) >= _STATUS_CACHE_TTL:
        cached = _run_component_checks()
        _status_cache["components"] = cached
        _status_cache["at"] = now
    return cached


def _public_incidents() -> list:
    """Recent status_incidents rows, reduced to public-safe fields."""
    try:
        from datetime import UTC, datetime, timedelta

        cutoff = (datetime.now(UTC) - timedelta(hours=_INCIDENT_WINDOW_HOURS)).isoformat()
        rows = get_db().conn.execute(
            "SELECT title, status, severity, message, started_at, resolved_at "
            "FROM status_incidents WHERE started_at >= ? ORDER BY started_at DESC LIMIT 50",
            (cutoff,),
        ).fetchall()
        return [
            {
                "title": r["title"],
                "status": r["status"],
                "severity": r["severity"],
                "message": (r["message"] or "")[:500],
                "started_at": r["started_at"],
                "resolved_at": r["resolved_at"],
            }
            for r in rows
        ]
    except Exception as e:
        logging.debug("[status/public] incidents unavailable: %s", e)
        return []


@bp.route("/api/status/public", methods=["GET"])
def public_status():
    components = _cached_components()
    ok = all(components.values())
    return jsonify(
        status="operational" if ok else "degraded",
        components=[{"name": k, "status": "up" if v else "down"} for k, v in components.items()],
        incidents=_public_incidents(),
        generated=time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
    )
