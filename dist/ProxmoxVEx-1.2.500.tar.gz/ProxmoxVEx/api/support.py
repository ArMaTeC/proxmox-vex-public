# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/api/support.py
# Project:     ProxmoxVEx
# Version:     1.2.499
# Build:       2026.09.23
# Description: Proxy blueprint for the proxmoxvex-support ticket
#              service.
# Usage:       import ProxmoxVEx.api.support
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-23
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Proxy blueprint for the proxmoxvex-support ticket service."""

import json
import logging
import os
from typing import Any, Tuple

import requests
from flask import Blueprint, Response, jsonify, request

from ProxmoxVEx.constants import ProxmoxVEx_VERSION
from ProxmoxVEx.core.db import get_db
from ProxmoxVEx.services.licensing import LicensingService, _node_fingerprint
from ProxmoxVEx.utils.auth import require_auth

bp = Blueprint("support", __name__)
service = LicensingService()
logger = logging.getLogger(__name__)

_TIMEOUT = 15


def _support_url() -> str:
    return os.environ.get("SUPPORT_SERVICE_URL", "").rstrip("/")


def _support_key() -> str:
    return os.environ.get("SUPPORT_SERVICE_API_KEY", "").strip()


def _configured() -> bool:
    return bool(_support_url() and _support_key())


def _headers() -> dict:
    return {"Authorization": f"Bearer {_support_key()}"}


def _ctx_or_error() -> Tuple[Any, Any]:
    """Return (ctx, error_response) — cached licence identity for this node."""
    ctx = service.get_context(get_db())
    if ctx is None or not getattr(ctx, "license_key", None):
        return None, (
            jsonify({
                "ok": False,
                "error": {
                    "code": "LICENCE_REQUIRED",
                    "message": "An activated licence is required to submit support tickets",
                },
            }),
            403,
        )
    return ctx, None


def _err(code: str, message: str, status: int):
    return jsonify({"ok": False, "error": {"code": code, "message": message}}), status


def _forward(method: str, path: str, **kwargs):
    """Forward a request to the support service; returns (body, status)."""
    if not _configured():
        return None, ("SERVICE_UNAVAILABLE", "Support service is not configured", 503)
    try:
        resp = requests.request(
            method,
            f"{_support_url()}{path}",
            headers=_headers(),
            timeout=_TIMEOUT,
            **kwargs,
        )
    except requests.RequestException as exc:
        logger.error("support proxy %s %s failed: %s", method, path, exc)
        return None, ("SERVICE_UNAVAILABLE", "Unable to reach support service", 503)
    try:
        body = resp.json()
    except ValueError:
        return None, ("SERVICE_ERROR", "Invalid response from support service", 502)
    return body, None


@bp.route("/api/v1/support/config", methods=["GET"])
@require_auth()
def support_config():
    """Expose whether in-app ticketing is available + the portal fallback URL."""
    ctx = service.get_context(get_db())
    entitled = bool(
        _configured()
        and ctx
        and getattr(ctx, "license_key", None)
        and ctx.tier_slug in {"basic", "advanced", "corporate"}
    )
    portal_url = os.environ.get(
        "SUPPORT_PORTAL_URL", "https://support.proxmoxvex.com/portal"
    )
    return jsonify({
        "ok": True,
        "data": {
            "enabled": entitled,
            "portal_url": portal_url,
            # Licence-free community form (portal #community route) — the link
            # shown to unlicensed users lands on a basic form, not the paid
            # licence-verify screen.
            "community_url": os.environ.get(
                "SUPPORT_COMMUNITY_URL", f"{portal_url}#community"
            ),
            "tier_slug": ctx.tier_slug if ctx else None,
        },
    })


def _licence_fields(ctx) -> dict:
    return {
        "license_key": ctx.license_key,
        "email": ctx.customer_email or "",
        "app_version": ProxmoxVEx_VERSION,
        "node_fingerprint": _node_fingerprint(),
    }


@bp.route("/api/v1/support/tickets", methods=["POST"])
@require_auth()
def create_ticket():
    """Create a ticket. Accepts JSON or multipart (attachments)."""
    ctx, err = _ctx_or_error()
    if err:
        return err

    if request.content_type and request.content_type.startswith("multipart/form-data"):
        # Rebuild the multipart body: JSON payload part + file parts.
        try:
            payload = json.loads(request.form.get("payload") or "{}")
        except json.JSONDecodeError:
            return _err("INVALID_REQUEST", "Invalid payload part", 400)
        payload.update(_licence_fields(ctx))
        files = [
            ("files", (f.filename, f.stream, f.mimetype))
            for f in request.files.getlist("files")
        ]
        body, error = _forward(
            "POST", "/v1/intake/tickets",
            data={"payload": json.dumps(payload)}, files=files or None,
        )
    else:
        data = request.get_json(silent=True) or {}
        payload = {
            "subject": data.get("subject") or "",
            "category": data.get("category") or "other",
            "urgency": data.get("urgency") or "normal",
            "message": data.get("message") or "",
            "idempotency_key": data.get("idempotency_key"),
        }
        payload.update(_licence_fields(ctx))
        body, error = _forward("POST", "/v1/intake/tickets", json=payload)

    if error:
        return _err(*error)
    return jsonify(body), 201


@bp.route("/api/v1/support/tickets", methods=["GET"])
@require_auth()
def list_tickets():
    ctx, err = _ctx_or_error()
    if err:
        return err
    body, error = _forward(
        "GET", "/v1/intake/tickets", params={"license_key": ctx.license_key}
    )
    if error:
        return _err(*error)
    return jsonify(body)


@bp.route("/api/v1/support/tickets/<reference>", methods=["GET"])
@require_auth()
def get_ticket(reference: str):
    ctx, err = _ctx_or_error()
    if err:
        return err
    body, error = _forward(
        "GET",
        f"/v1/intake/tickets/{reference}",
        params={"license_key": ctx.license_key},
    )
    if error:
        return _err(*error)
    return jsonify(body)


@bp.route("/api/v1/support/tickets/<reference>/replies", methods=["POST"])
@require_auth()
def reply_ticket(reference: str):
    ctx, err = _ctx_or_error()
    if err:
        return err
    if request.content_type and request.content_type.startswith("multipart/form-data"):
        try:
            payload = json.loads(request.form.get("payload") or "{}")
        except json.JSONDecodeError:
            return _err("INVALID_REQUEST", "Invalid payload part", 400)
        payload["license_key"] = ctx.license_key
        files = [
            ("files", (f.filename, f.stream, f.mimetype))
            for f in request.files.getlist("files")
        ]
        body, error = _forward(
            "POST", f"/v1/intake/tickets/{reference}/replies",
            data={"payload": json.dumps(payload)}, files=files or None,
        )
    else:
        data = request.get_json(silent=True) or {}
        body, error = _forward(
            "POST",
            f"/v1/intake/tickets/{reference}/replies",
            json={"license_key": ctx.license_key, "body": data.get("body") or ""},
        )
    if error:
        return _err(*error)
    return jsonify(body)


@bp.route(
    "/api/v1/support/tickets/<reference>/attachments/<attachment_id>",
    methods=["GET"],
)
@require_auth()
def download_attachment(reference: str, attachment_id: str):
    """Stream an attachment through the proxy (keeps the service-token private)."""
    ctx, err = _ctx_or_error()
    if err:
        return err
    if not _configured():
        return _err("SERVICE_UNAVAILABLE", "Support service is not configured", 503)
    try:
        resp = requests.get(
            f"{_support_url()}/v1/intake/tickets/{reference}/attachments/{attachment_id}",
            params={"license_key": ctx.license_key},
            headers=_headers(),
            timeout=_TIMEOUT,
            stream=True,
        )
    except requests.RequestException as exc:
        logger.error("support proxy attachment failed: %s", exc)
        return _err("SERVICE_UNAVAILABLE", "Unable to reach support service", 503)
    return Response(
        resp.iter_content(chunk_size=8192),
        status=resp.status_code,
        content_type=resp.headers.get("Content-Type", "application/octet-stream"),
        headers={
            "Content-Disposition": resp.headers.get(
                "Content-Disposition", "attachment"
            )
        },
    )
