# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/api/metrics_exporter.py
# Project:     ProxmoxVEx
# Version:     1.2.499
# Build:       2026.09.23
# Description: Prometheus / OpenMetrics exporter.
# Usage:       import ProxmoxVEx.api.metrics_exporter
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-23
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""
Prometheus / OpenMetrics exporter.

Apr 2026: One endpoint - /api/metrics - that lets any Prometheus/Grafana stack
scrape ProxmoxVEx with zero custom instrumentation. We expose a curated set of gauges
that match what admins typically want to alert on (node down, high CPU, quorum
at risk, etc). Most data is derived from existing in-memory state; APT update
availability is queried through Proxmox and cached briefly per node.

Auth: Bearer token via existing API tokens (admin-view role is enough), or the
endpoint can be made public by setting `metrics_public: true` in server settings —
some setups put ProxmoxVEx behind a mutual-TLS reverse proxy and want to skip auth.
"""

import logging
import threading
import time

from flask import Blueprint, Response, request

from ProxmoxVEx.api.helpers import load_server_settings
from ProxmoxVEx.core.db import get_db
from ProxmoxVEx.globals import (
    active_sessions,
    cluster_managers,
    pbs_managers,
    sessions_lock,
    vmware_managers,
)
from ProxmoxVEx.utils import auth as auth_state
from ProxmoxVEx.utils.auth import load_users, validate_api_token

bp = Blueprint("metrics_exporter", __name__)

_APT_UPDATE_CACHE_TTL = 15 * 60
_apt_update_cache = {}
_apt_update_cache_lock = threading.Lock()

# ── spec 092/US025: request/latency/upstream/queue instrumentation ──
# Hand-rolled like the rest of this exporter (the file deliberately avoids a
# prometheus_client dependency). Counted in app before/after hooks installed
# by install_metrics(); upstream calls are counted by core/manager.py's
# session.request wrapper — the single seam every cluster call flows through.
_REQ_LOCK = threading.Lock()
_REQ: dict = {}                                  # (method, route, status) -> count
_LAT_BUCKETS = (0.01, 0.05, 0.1, 0.25, 0.5, 1, 2.5, 5)
_LAT: dict = {}                                   # route -> {b, sum, count}
_UPSTREAM: dict = {}                              # result -> count
# Spec 092/US059: per-plugin bridge metrics — (plugin, status) call counts and
# a per-plugin latency histogram sharing the request buckets.
_PLUGIN_CALLS: dict = {}                          # (plugin, status) -> count
_PLUGIN_LAT: dict = {}                            # plugin -> {b, sum, count}


def record_plugin_call(plugin_id: str, status: str, seconds: float) -> None:
    """Count one plugin bridge dispatch ('ok' | 'error') and its latency."""
    try:
        with _REQ_LOCK:
            key = (str(plugin_id), str(status))
            _PLUGIN_CALLS[key] = _PLUGIN_CALLS.get(key, 0) + 1
            h = _PLUGIN_LAT.get(key[0])
            if h is None:
                h = _PLUGIN_LAT[key[0]] = {"b": [0] * len(_LAT_BUCKETS), "sum": 0.0, "count": 0}
            h["count"] += 1
            h["sum"] += seconds
            for i, le in enumerate(_LAT_BUCKETS):
                if seconds <= le:
                    h["b"][i] += 1
                    break
    except Exception:  # metrics must never break the call path
        pass


def record_upstream(result: str) -> None:
    """Count one upstream hypervisor call outcome ('ok' | 'error')."""
    try:
        with _REQ_LOCK:
            _UPSTREAM[str(result)] = _UPSTREAM.get(str(result), 0) + 1
    except Exception:  # metrics must never break the call path
        pass


def _record_request(method: str, route: str, status: int, seconds: float) -> None:
    with _REQ_LOCK:
        key = (method, route, status)
        _REQ[key] = _REQ.get(key, 0) + 1
        h = _LAT.get(route)
        if h is None:
            h = _LAT[route] = {"b": [0] * len(_LAT_BUCKETS), "sum": 0.0, "count": 0}
        h["count"] += 1
        h["sum"] += seconds
        for i, le in enumerate(_LAT_BUCKETS):
            if seconds <= le:
                h["b"][i] += 1
                break


def install_metrics(app) -> None:
    """Attach request-count/latency hooks. route = URL rule (ids collapse to
    <id> placeholders) so high-cardinality paths can't explode the series."""
    from flask import g as _g
    from flask import request as _req

    @app.before_request
    def _metrics_start():
        _g._metrics_t0 = time.time()

    @app.after_request
    def _metrics_end(resp):
        route = _req.url_rule.rule if _req.url_rule else "unmatched"
        t0 = getattr(_g, "_metrics_t0", None)
        _record_request(_req.method, route, resp.status_code,
                        (time.time() - t0) if t0 is not None else 0.0)
        return resp


def _queue_depth() -> int:
    """Live queued/running bulk-job count, read at scrape time."""
    try:
        from ProxmoxVEx.background import bulk_actions

        with bulk_actions.BULK_JOBS_LOCK:
            return sum(1 for j in bulk_actions.BULK_JOBS.values()
                       if getattr(j, "status", "") in ("starting", "running"))
    except Exception:
        return 0

# 870-caching-for-realtime-graph: seconds to keep a realtime graph snapshot valid.
REALTIME_GRAPH_CACHE_TTL = 30.0
_realtime_graph_cache = {}
_realtime_graph_cache_lock = threading.Lock()

# 871-lazy-loading-for-realtime-graph: maximum page size for paginated graph data.
REALTIME_GRAPH_PAGINATION_MAX = 100


def _escape_label(s):
    """Prometheus labels can't contain raw quotes, backslashes, or newlines."""
    if s is None:
        return ""
    return str(s).replace("\\", "\\\\").replace('"', '\\"').replace("\n", " ")


def _sample(name, value, labels=None, help_text=None, mtype=None):
    """Build one or two lines of Prometheus exposition format."""
    lines = []
    # The HELP/TYPE lines appear once per metric name — caller should emit those
    # before the first sample. Kept out of here so repeated _sample() calls don't
    # duplicate metadata.
    if labels:
        lbl = ",".join(f'{k}="{_escape_label(v)}"' for k, v in labels.items())
        lines.append(f"{name}{{{lbl}}} {value}")
    else:
        lines.append(f"{name} {value}")
    return lines


def _num(value, default=0):
    """Return a Prometheus-safe numeric value."""
    try:
        if value in (None, ""):
            return default
        return float(value)
    except Exception:
        return default


def _round_num(value, default=0, places=2):
    try:
        return round(float(value), places)
    except Exception:
        return default


def _pct(used, total):
    try:
        total = float(total or 0)
        if total <= 0:
            return 0
        return round((float(used or 0) / total) * 100, 2)
    except Exception:
        return 0


def _resource_type_label(resource_type):
    if resource_type == "qemu":
        return "vm"
    if resource_type == "lxc":
        return "lxc"
    return resource_type or "unknown"


def _node_apt_updates_available(cid, mgr, node):
    """Return 1 when any APT update is available on a node, otherwise 0.

    The Proxmox endpoint is read-only, but it can still be expensive across
    larger clusters. Cache per node briefly so frequent scrapes stay cheap.
    """
    if getattr(mgr, "cluster_type", "proxmox") != "proxmox":
        return None

    key = (cid, node)
    now = time.time()
    with _apt_update_cache_lock:
        cached = _apt_update_cache.get(key)
        if cached and now - cached.get("at", 0) < _APT_UPDATE_CACHE_TTL:
            return cached.get("available", 0)

    try:
        updates = mgr.get_node_apt_updates(node)
        available = 1 if updates else 0
    except Exception as e:
        logging.debug(f"[metrics] {cid}/{node} apt update check failed: {e}")
        available = 0

    with _apt_update_cache_lock:
        _apt_update_cache[key] = {"at": now, "available": available}
    return available


def _auth_ok():
    """Allow scrape if: (a) bearer token is valid API token, or (b) metrics_public=true."""
    settings = load_server_settings()
    if settings.get("metrics_public", False):
        return True
    auth = request.headers.get("Authorization", "")
    if auth.startswith("Bearer "):
        token = auth[7:].strip()
        try:
            info = validate_api_token(token)
            if info:
                return True
        except Exception as e:
            logging.debug(f"[metrics] token validate failed: {e}")
    return False


@bp.route("/api/metrics", methods=["GET"])
def prometheus_metrics():
    if not _auth_ok():
        return Response(
            "# unauthorized — set Authorization: Bearer <api_token>, or enable metrics_public\n",
            status=401,
            mimetype="text/plain; version=0.0.4",
        )

    out = []
    emit = out.append

    # ── ProxmoxVEx self metrics ──
    emit("# HELP ProxmoxVEx_info Build information")
    emit("# TYPE ProxmoxVEx_info gauge")
    try:
        from ProxmoxVEx.constants import ProxmoxVEx_BUILD, ProxmoxVEx_VERSION

        out.extend(_sample("ProxmoxVEx_info", 1, {"version": ProxmoxVEx_VERSION, "build": ProxmoxVEx_BUILD}))
    except Exception:
        pass

    emit("# HELP ProxmoxVEx_scrape_timestamp_seconds Unix time of this scrape")
    emit("# TYPE ProxmoxVEx_scrape_timestamp_seconds gauge")
    out.extend(_sample("ProxmoxVEx_scrape_timestamp_seconds", f"{time.time():.0f}"))

    # ── DB pool utilization (spec 092/US082): one pooled singleton plus
    # ad-hoc PGConnections (workers/reports/native) as the overflow analog —
    # an SRE sizes against overflow and watches checked_out for outages.
    try:
        pool = get_db().db_pool_stats()
        emit("# HELP ProxmoxVEx_db_pool_size Pooled connections configured")
        emit("# TYPE ProxmoxVEx_db_pool_size gauge")
        out.extend(_sample("ProxmoxVEx_db_pool_size", pool["size"]))
        emit("# HELP ProxmoxVEx_db_pool_checked_out Pooled connections currently in use")
        emit("# TYPE ProxmoxVEx_db_pool_checked_out gauge")
        out.extend(_sample("ProxmoxVEx_db_pool_checked_out", pool["checked_out"]))
        emit("# HELP ProxmoxVEx_db_pool_overflow Live connections beyond the pool")
        emit("# TYPE ProxmoxVEx_db_pool_overflow gauge")
        out.extend(_sample("ProxmoxVEx_db_pool_overflow", pool["overflow"]))
    except Exception as e:
        # pool stats must never break the scrape
        logging.debug(f"[metrics] db pool stats failed: {e}")

    # ── Session + auth state ──
    with sessions_lock:
        sessions = getattr(auth_state, "active_sessions", active_sessions)
        sess_total = len(sessions)
        active_users = set()
        for s in sessions.values():
            u = s.get("user", "?")
            if u and u != "?":
                active_users.add(u)
    emit("# HELP ProxmoxVEx_sessions_active Currently authenticated sessions")
    emit("# TYPE ProxmoxVEx_sessions_active gauge")
    out.extend(_sample("ProxmoxVEx_sessions_active", sess_total))
    emit("# HELP ProxmoxVEx_users_logged_in Unique ProxmoxVEx users with an active session")
    emit("# TYPE ProxmoxVEx_users_logged_in gauge")
    out.extend(_sample("ProxmoxVEx_users_logged_in", len(active_users)))

    try:
        users = load_users(readonly=True) or {}
        enabled_users = sum(1 for u in users.values() if u.get("enabled", True))
        emit("# HELP ProxmoxVEx_users_total Configured ProxmoxVEx user accounts")
        emit("# TYPE ProxmoxVEx_users_total gauge")
        out.extend(_sample("ProxmoxVEx_users_total", len(users)))
        emit("# HELP ProxmoxVEx_users_enabled Enabled ProxmoxVEx user accounts")
        emit("# TYPE ProxmoxVEx_users_enabled gauge")
        out.extend(_sample("ProxmoxVEx_users_enabled", enabled_users))
    except Exception as e:
        logging.debug(f"[metrics] user stats failed: {e}")

    # ── Clusters ──
    emit("# HELP ProxmoxVEx_cluster_connected 1 if ProxmoxVEx can reach the cluster API")
    emit("# TYPE ProxmoxVEx_cluster_connected gauge")
    emit("# HELP ProxmoxVEx_cluster_nodes_total Node count per cluster")
    emit("# TYPE ProxmoxVEx_cluster_nodes_total gauge")
    emit("# HELP ProxmoxVEx_cluster_nodes_online Online node count")
    emit("# TYPE ProxmoxVEx_cluster_nodes_online gauge")
    emit("# HELP ProxmoxVEx_cluster_vms_total VMs/CTs per cluster")
    emit("# TYPE ProxmoxVEx_cluster_vms_total gauge")
    emit("# HELP ProxmoxVEx_cluster_vms_running Running VMs/CTs per cluster")
    emit("# TYPE ProxmoxVEx_cluster_vms_running gauge")
    emit("# HELP ProxmoxVEx_cluster_quorum_held 1 if quorum is currently held")
    emit("# TYPE ProxmoxVEx_cluster_quorum_held gauge")

    emit("# HELP ProxmoxVEx_node_cpu_percent CPU usage percent per node")
    emit("# TYPE ProxmoxVEx_node_cpu_percent gauge")
    emit("# HELP ProxmoxVEx_node_mem_percent Memory usage percent per node")
    emit("# TYPE ProxmoxVEx_node_mem_percent gauge")
    emit("# HELP ProxmoxVEx_node_uptime_seconds Node uptime in seconds")
    emit("# TYPE ProxmoxVEx_node_uptime_seconds gauge")
    emit("# HELP ProxmoxVEx_node_online 1 if the node is online")
    emit("# TYPE ProxmoxVEx_node_online gauge")
    emit("# HELP ProxmoxVEx_node_apt_updates_available 1 if any APT package update is available on the node")
    emit("# TYPE ProxmoxVEx_node_apt_updates_available gauge")

    emit("# HELP ProxmoxVEx_guest_running 1 if the VM or LXC container is running")
    emit("# TYPE ProxmoxVEx_guest_running gauge")
    emit("# HELP ProxmoxVEx_guest_cpu_percent CPU usage percent per VM or LXC container")
    emit("# TYPE ProxmoxVEx_guest_cpu_percent gauge")
    emit("# HELP ProxmoxVEx_guest_mem_used_bytes Memory used by a VM or LXC container")
    emit("# TYPE ProxmoxVEx_guest_mem_used_bytes gauge")
    emit("# HELP ProxmoxVEx_guest_mem_total_bytes Configured memory limit for a VM or LXC container")
    emit("# TYPE ProxmoxVEx_guest_mem_total_bytes gauge")
    emit("# HELP ProxmoxVEx_guest_mem_percent Memory usage percent per VM or LXC container")
    emit("# TYPE ProxmoxVEx_guest_mem_percent gauge")
    emit("# HELP ProxmoxVEx_guest_disk_used_bytes Disk bytes used by a VM or LXC container")
    emit("# TYPE ProxmoxVEx_guest_disk_used_bytes gauge")
    emit("# HELP ProxmoxVEx_guest_disk_total_bytes Configured disk size for a VM or LXC container")
    emit("# TYPE ProxmoxVEx_guest_disk_total_bytes gauge")
    emit("# HELP ProxmoxVEx_guest_disk_percent Disk usage percent per VM or LXC container")
    emit("# TYPE ProxmoxVEx_guest_disk_percent gauge")
    emit(
        "# HELP ProxmoxVEx_guest_network_receive_bytes_total Cumulative network bytes received by a VM or LXC container"
    )
    emit("# TYPE ProxmoxVEx_guest_network_receive_bytes_total counter")
    emit(
        "# HELP ProxmoxVEx_guest_network_transmit_bytes_total Cumulative network bytes transmitted by a VM or LXC container"
    )
    emit("# TYPE ProxmoxVEx_guest_network_transmit_bytes_total counter")
    emit("# HELP ProxmoxVEx_guest_uptime_seconds Uptime in seconds for a VM or LXC container")
    emit("# TYPE ProxmoxVEx_guest_uptime_seconds gauge")
    # Ceph (#540) — only emitted for clusters that actually run Ceph
    emit("# HELP ProxmoxVEx_ceph_health_status Ceph cluster health (0=OK, 1=WARN, 2=ERR, 3=unknown)")
    emit("# TYPE ProxmoxVEx_ceph_health_status gauge")
    emit("# HELP ProxmoxVEx_ceph_osd_up Number of Ceph OSDs currently up")
    emit("# TYPE ProxmoxVEx_ceph_osd_up gauge")
    emit("# HELP ProxmoxVEx_ceph_osd_in Number of Ceph OSDs currently in")
    emit("# TYPE ProxmoxVEx_ceph_osd_in gauge")

    for cid, mgr in cluster_managers.items():
        cname = getattr(getattr(mgr, "config", None), "name", cid) or cid
        base = {"cluster_id": cid, "cluster": cname}
        connected = 1 if getattr(mgr, "is_connected", False) else 0
        out.extend(_sample("ProxmoxVEx_cluster_connected", connected, base))
        if not connected:
            continue

        # Node counts + per-node stats
        try:
            node_status = mgr.get_node_status() or {}
            nodes_total = len(node_status)
            nodes_online = 0
            for name, info in node_status.items():
                is_online = (info.get("status") == "online") or (not info.get("offline", False))
                if is_online:
                    nodes_online += 1
                nlabels = {**base, "node": name}
                out.extend(_sample("ProxmoxVEx_node_online", 1 if is_online else 0, nlabels))
                out.extend(
                    _sample(
                        "ProxmoxVEx_node_cpu_percent",
                        _round_num(info.get("cpu_percent", _num(info.get("cpu", 0)) * 100)),
                        nlabels,
                    )
                )
                out.extend(_sample("ProxmoxVEx_node_mem_percent", _round_num(info.get("mem_percent", 0)), nlabels))
                out.extend(_sample("ProxmoxVEx_node_uptime_seconds", _num(info.get("uptime", 0)), nlabels))
                apt_available = _node_apt_updates_available(cid, mgr, name) if is_online else 0
                if apt_available is not None:
                    out.extend(_sample("ProxmoxVEx_node_apt_updates_available", apt_available, nlabels))
            out.extend(_sample("ProxmoxVEx_cluster_nodes_total", nodes_total, base))
            out.extend(_sample("ProxmoxVEx_cluster_nodes_online", nodes_online, base))
            # Quorum: >50% online
            quorum = 1 if nodes_online * 2 > nodes_total else 0
            out.extend(_sample("ProxmoxVEx_cluster_quorum_held", quorum, base))
        except Exception as e:
            logging.debug(f"[metrics] {cid} node stats failed: {e}")

        # Ceph health (#540) — best-effort; get_ceph_health_summary returns None when
        # the cluster has no Ceph, so no ceph_* series are emitted for those clusters.
        # One SSH probe per cluster per scrape, consistent with the apt-updates metric.
        try:
            ceph = mgr.get_ceph_health_summary() if hasattr(mgr, "get_ceph_health_summary") else None
            if ceph:
                _cmap = {"HEALTH_OK": 0, "HEALTH_WARN": 1, "HEALTH_ERR": 2}
                out.extend(_sample("ProxmoxVEx_ceph_health_status", _cmap.get(ceph.get("status"), 3), base))
                out.extend(_sample("ProxmoxVEx_ceph_osd_up", _num(ceph.get("osd_up", 0)), base))
                out.extend(_sample("ProxmoxVEx_ceph_osd_in", _num(ceph.get("osd_in", 0)), base))
        except Exception as e:
            logging.debug(f"[metrics] {cid} ceph health failed: {e}")

        # VM counts
        try:
            vms = []
            if hasattr(mgr, "get_vm_resources"):
                vms = mgr.get_vm_resources() or []
            elif hasattr(mgr, "get_resources"):
                vms = [r for r in (mgr.get_resources() or []) if r.get("type") in ("qemu", "lxc")]
            out.extend(_sample("ProxmoxVEx_cluster_vms_total", len(vms), base))
            running = sum(1 for v in vms if v.get("status") == "running")
            out.extend(_sample("ProxmoxVEx_cluster_vms_running", running, base))

            for v in vms:
                vmid = v.get("vmid", "")
                labels = {
                    **base,
                    "node": v.get("node", ""),
                    "type": _resource_type_label(v.get("type")),
                    "vmid": vmid,
                    "name": v.get("name") or v.get("hostname") or str(vmid),
                }
                mem_used = _num(v.get("mem", 0))
                mem_total = _num(v.get("maxmem", 0))
                disk_used = _num(v.get("disk", 0))
                disk_total = _num(v.get("maxdisk", 0))
                out.extend(_sample("ProxmoxVEx_guest_running", 1 if v.get("status") == "running" else 0, labels))
                out.extend(
                    _sample(
                        "ProxmoxVEx_guest_cpu_percent",
                        _round_num(v.get("cpu_percent", _num(v.get("cpu", 0)) * 100)),
                        labels,
                    )
                )
                out.extend(_sample("ProxmoxVEx_guest_mem_used_bytes", mem_used, labels))
                out.extend(_sample("ProxmoxVEx_guest_mem_total_bytes", mem_total, labels))
                out.extend(
                    _sample(
                        "ProxmoxVEx_guest_mem_percent",
                        _round_num(v.get("mem_percent", _pct(mem_used, mem_total))),
                        labels,
                    )
                )
                out.extend(_sample("ProxmoxVEx_guest_disk_used_bytes", disk_used, labels))
                out.extend(_sample("ProxmoxVEx_guest_disk_total_bytes", disk_total, labels))
                out.extend(
                    _sample(
                        "ProxmoxVEx_guest_disk_percent",
                        _round_num(v.get("disk_percent", _pct(disk_used, disk_total))),
                        labels,
                    )
                )
                out.extend(_sample("ProxmoxVEx_guest_network_receive_bytes_total", _num(v.get("netin", 0)), labels))
                out.extend(_sample("ProxmoxVEx_guest_network_transmit_bytes_total", _num(v.get("netout", 0)), labels))
                out.extend(_sample("ProxmoxVEx_guest_uptime_seconds", _num(v.get("uptime", 0)), labels))
        except Exception as e:
            logging.debug(f"[metrics] {cid} vm list failed: {e}")

    # ── PBS backup servers ──
    if pbs_managers:
        emit("# HELP ProxmoxVEx_pbs_connected 1 if PBS is reachable")
        emit("# TYPE ProxmoxVEx_pbs_connected gauge")
        for pid, pmgr in pbs_managers.items():
            labels = {"pbs_id": pid, "pbs": getattr(pmgr, "name", "") or pid}
            out.extend(_sample("ProxmoxVEx_pbs_connected", 1 if getattr(pmgr, "connected", False) else 0, labels))

    # ── VMware/ESXi ──
    if vmware_managers:
        emit("# HELP ProxmoxVEx_esxi_connected 1 if ESXi/vCenter is reachable")
        emit("# TYPE ProxmoxVEx_esxi_connected gauge")
        for vid, vmgr in vmware_managers.items():
            labels = {"esxi_id": vid, "host": getattr(vmgr, "host", "") or vid}
            out.extend(_sample("ProxmoxVEx_esxi_connected", 1 if getattr(vmgr, "connected", False) else 0, labels))

    # ── spec 092/US025: HTTP request / upstream / queue instrumentation ──
    emit("# HELP http_requests_total HTTP requests by method, route and status")
    emit("# TYPE http_requests_total counter")
    emit("# HELP http_request_seconds HTTP request latency in seconds")
    emit("# TYPE http_request_seconds histogram")
    emit("# HELP upstream_calls_total Upstream hypervisor API calls by result")
    emit("# TYPE upstream_calls_total counter")
    emit("# HELP ProxmoxVEx_task_queue_depth Bulk task jobs queued or running")
    emit("# TYPE ProxmoxVEx_task_queue_depth gauge")
    out.extend(_sample("ProxmoxVEx_task_queue_depth", _queue_depth()))
    with _REQ_LOCK:
        req_items = sorted(_REQ.items())
        lat_items = sorted(_LAT.items())
        up_items = sorted(_UPSTREAM.items())
    for (m, route, status), n in req_items:
        out.extend(_sample("http_requests_total", n,
                           {"method": m, "route": route, "status": status}))
    for route, h in lat_items:
        cum = 0
        for i, le in enumerate(_LAT_BUCKETS):
            cum += h["b"][i]
            out.extend(_sample("http_request_seconds_bucket", cum,
                               {"route": route, "le": str(le)}))
        out.extend(_sample("http_request_seconds_bucket", h["count"],
                           {"route": route, "le": "+Inf"}))
        out.extend(_sample("http_request_seconds_sum", round(h["sum"], 6), {"route": route}))
        out.extend(_sample("http_request_seconds_count", h["count"], {"route": route}))
    for result, n in up_items:
        out.extend(_sample("upstream_calls_total", n, {"result": result}))

    # Spec 092/US059: per-plugin bridge counters + latency histogram.
    with _REQ_LOCK:
        pcall_items = sorted(_PLUGIN_CALLS.items())
        plat_items = sorted(_PLUGIN_LAT.items())
    for (pid, status), n in pcall_items:
        out.extend(_sample("plugin_bridge_calls_total", n,
                           {"plugin": pid, "status": status}))
    for pid, h in plat_items:
        cum = 0
        for i, le in enumerate(_LAT_BUCKETS):
            cum += h["b"][i]
            out.extend(_sample("plugin_bridge_seconds_bucket", cum,
                               {"plugin": pid, "le": str(le)}))
        out.extend(_sample("plugin_bridge_seconds_bucket", h["count"],
                           {"plugin": pid, "le": "+Inf"}))
        out.extend(_sample("plugin_bridge_seconds_sum", round(h["sum"], 6), {"plugin": pid}))
        out.extend(_sample("plugin_bridge_seconds_count", h["count"], {"plugin": pid}))

    body = "\n".join(out) + "\n"
    return Response(body, mimetype="text/plain; version=0.0.4; charset=utf-8")


def get_realtime_graph_data(key, fetch_func):
    """Return a cached realtime graph payload for `key` or fetch a fresh one.

    870-caching-for-realtime-graph: avoids expensive repeated Proxmox API calls
    for realtime graph endpoints that are polled by the frontend.
    """
    now = time.time()
    with _realtime_graph_cache_lock:
        cached = _realtime_graph_cache.get(key)
        if cached and (now - cached.get("at", 0)) < REALTIME_GRAPH_CACHE_TTL:
            return cached.get("data")
        data = fetch_func()
        _realtime_graph_cache[key] = {"at": now, "data": data}
    return data


def get_realtime_graph_data_lazy(key, page, per_page, fetch_func):
    """Return a paginated slice of the cached realtime graph data for `key`.

    871-lazy-loading-for-realtime-graph: avoids loading the entire graph dataset
    at once by returning a bounded `page`/`per_page` window.
    """
    all_items = get_realtime_graph_data(key, fetch_func)
    if not isinstance(all_items, list):
        return {"page": page, "per_page": per_page, "total": 0, "items": []}

    per_page = max(1, min(int(per_page), REALTIME_GRAPH_PAGINATION_MAX))
    page = max(1, int(page))
    total = len(all_items)
    start = (page - 1) * per_page
    end = start + per_page
    return {
        "page": page,
        "per_page": per_page,
        "total": total,
        "items": all_items[start:end],
    }


# 948-pagination-for-realtime-graph: dedicated paginated realtime graph helper.
REALTIME_GRAPH_PAGINATION = True


def get_realtime_graph_data_paginated(key, page, per_page, fetch_func):
    """Return a paginated window of realtime graph data for `key`.

    948-pagination-for-realtime-graph: applies stable pagination on top of the
    cached realtime graph dataset, exposing `page`/`per_page` metadata.
    """
    return get_realtime_graph_data_lazy(key, page, per_page, fetch_func)


# 949-batching-for-realtime-graph: fixed-size batch fetching for realtime graph data.
REALTIME_GRAPH_BATCH_SIZE = 50
REALTIME_GRAPH_BATCHING = True


def get_realtime_graph_data_batched(key, batch_size, fetch_func):
    """Return the next fixed-size batch of realtime graph data for `key`.

    949-batching-for-realtime-graph: breaks large realtime graph datasets into
    fixed-size chunks so callers can stream updates without loading everything.
    """
    batch_size = max(1, min(int(batch_size), REALTIME_GRAPH_PAGINATION_MAX))
    all_items = get_realtime_graph_data(key, fetch_func)
    if not isinstance(all_items, list):
        return {"batch": 1, "batch_size": batch_size, "total": 0, "items": []}
    return {
        "batch": 1,
        "batch_size": batch_size,
        "total": len(all_items),
        "items": all_items[:batch_size],
    }


# 950-indexing-for-realtime-graph: build an in-memory index for realtime graph data.
REALTIME_GRAPH_INDEXING = True


def get_realtime_graph_data_indexed(key, field, fetch_func):
    """Return an in-memory index of realtime graph data for `key` by `field`.

    950-indexing-for-realtime-graph: groups realtime graph items by the supplied
    `field` so callers can do O(1) lookups instead of scanning the full dataset.
    """
    all_items = get_realtime_graph_data(key, fetch_func)
    if not isinstance(all_items, list):
        return {"field": field, "total": 0, "index": {}}
    index = {}
    for item in all_items:
        if isinstance(item, dict) and field in item:
            index.setdefault(item[field], []).append(item)
        elif hasattr(item, field):
            index.setdefault(getattr(item, field), []).append(item)
    return {"field": field, "total": len(all_items), "index": index}


# 951-compression-for-realtime-graph: gzip-compressed realtime graph payloads.
REALTIME_GRAPH_COMPRESSION = True


def get_realtime_graph_data_compressed(key, fetch_func):
    """Return a gzip/base64-compressed realtime graph payload for `key`.

    951-compression-for-realtime-graph: reduces wire size for large realtime
    graph datasets by returning a gzip-compressed, base64-encoded payload.
    """
    import base64
    import gzip
    import json

    all_items = get_realtime_graph_data(key, fetch_func)
    if not isinstance(all_items, list):
        all_items = []
    payload = json.dumps(all_items).encode("utf-8")
    compressed = base64.b64encode(gzip.compress(payload)).decode("ascii")
    return {
        "compressed": True,
        "encoding": "base64",
        "format": "gzip",
        "total": len(all_items),
        "data": compressed,
    }


# 952-connection-pooling-for-realtime-graph: reusable connection pool for realtime graph fetches.
REALTIME_GRAPH_CONNECTION_POOL = True


class RealtimeGraphConnectionPool:
    """Reusable in-memory connection pool for realtime graph fetch workers."""

    def __init__(self, maxsize=20):
        self._maxsize = maxsize
        self._pool = []
        self._lock = threading.Lock()

    def acquire(self, factory=None):
        """Acquire a connection/fetch handle from the pool."""
        with self._lock:
            if self._pool:
                return self._pool.pop()
        if factory:
            return factory()
        return None

    def release(self, conn):
        """Return a connection/fetch handle to the pool."""
        if conn is None:
            return
        with self._lock:
            if len(self._pool) < self._maxsize:
                self._pool.append(conn)


_realtime_graph_pool = RealtimeGraphConnectionPool()


def get_realtime_graph_data_pooled(key, fetch_func):
    """Return realtime graph data for `key` through a pooled fetch handle.

    952-connection-pooling-for-realtime-graph: reuses pooled fetch handles to
    avoid repeatedly creating expensive Proxmox API connections.
    """
    # The pooled "handle" is the fetch callable itself — acquire(factory=)
    # invokes the factory, so passing fetch_func directly would eagerly run
    # the fetch and return its (non-callable) result instead of a handle.
    handle = _realtime_graph_pool.acquire(factory=lambda: fetch_func)
    try:
        return get_realtime_graph_data(key, handle)
    finally:
        _realtime_graph_pool.release(handle)


# 953-async-workers-for-realtime-graph: offload graph fetches to a worker pool.
REALTIME_GRAPH_ASYNC_WORKERS = True


def get_realtime_graph_data_async(key, fetch_func, executor=None):
    """Return a future/promise for realtime graph data for `key`.

    953-async-workers-for-realtime-graph: executes the Proxmox realtime graph
    fetch in a background worker so callers do not block the request thread.
    """
    import concurrent.futures

    def _fetch():
        return get_realtime_graph_data(key, fetch_func)

    if executor is None:
        executor = concurrent.futures.ThreadPoolExecutor(max_workers=4)
    return executor.submit(_fetch)


# 954-memory-optimisation-for-realtime-graph: cap in-memory realtime graph history.
REALTIME_GRAPH_MEMORY_OPTIMISATION = True
REALTIME_GRAPH_MEMORY_MAX_POINTS = 10000


def get_realtime_graph_data_optimised(key, fetch_func, max_points=None):
    """Return a memory-optimised realtime graph dataset for `key`.

    954-memory-optimisation-for-realtime-graph: keeps only the most recent
    `max_points` datapoints in memory to avoid unbounded growth of graph data.
    """
    if max_points is None:
        max_points = REALTIME_GRAPH_MEMORY_MAX_POINTS
    max_points = max(1, int(max_points))
    all_items = get_realtime_graph_data(key, fetch_func)
    if not isinstance(all_items, list):
        return {"max_points": max_points, "total": 0, "items": []}
    return {
        "max_points": max_points,
        "total": len(all_items),
        "items": all_items[-max_points:],
    }


# 955-incremental-updates-for-realtime-graph: only transmit new datapoints.
REALTIME_GRAPH_INCREMENTAL_UPDATES = True


def get_realtime_graph_data_incremental(key, since, fetch_func, timestamp_field="ts"):
    """Return realtime graph datapoints for `key` that are newer than `since`.

    955-incremental-updates-for-realtime-graph: filters the cached graph dataset
    to only include points whose `timestamp_field` value is greater than `since`.
    """
    since = int(since)
    all_items = get_realtime_graph_data(key, fetch_func)
    if not isinstance(all_items, list):
        return {"since": since, "total": 0, "items": []}
    new_items = [
        item
        for item in all_items
        if isinstance(item, dict)
        and timestamp_field in item
        and int(item[timestamp_field]) > since
    ]
    return {"since": since, "total": len(new_items), "items": new_items}
