# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/native/__init__.py
# Project:     ProxmoxVEx
# Version:     1.2.499
# Build:       2026.09.23
# Description: Native built-in integrations loader.
# Usage:       import ProxmoxVEx.native
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-23
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Native built-in integrations loader."""

import logging
import random
import time


class TransientError(Exception):
    """A failure that is safe to retry (network blip, 5xx, rate limit)."""


def with_retry(fn, *, attempts=4, base=0.5, cap=8.0, transient=None, sleep=None):
    """Wrap ``fn`` with jittered exponential backoff on transient errors.

    Spec 092/US057: native integrations call flaky remote endpoints
    (TrueNAS, PBS, firewalls); transient failures should retry instead of
    surfacing momentary blips as user-visible errors. ``transient`` is the
    exception tuple to retry (default: TransientError); ``sleep`` is
    injectable for tests. Non-transient exceptions propagate immediately.
    """
    transient = transient or (TransientError,)
    sleep = sleep or time.sleep
    log = logging.getLogger(__name__)

    def wrapper(*a, **kw):
        last = None
        for i in range(attempts):
            try:
                return fn(*a, **kw)
            except transient as e:
                last = e
                if i == attempts - 1:
                    break
                delay = min(cap, base * 2**i) + random.uniform(0, 0.3)
                log.warning("transient failure (%s); retry %d/%d in %.2fs", e, i + 1, attempts - 1, delay)
                sleep(delay)
        # `last` stays None only when attempts<=0 (loop never ran) — call fn
        # once directly instead of `raise None` (TypeError, and checkers flag
        # raising a possibly-None value)
        if last is None:
            return fn(*a, **kw)
        raise last

    return wrapper


def register_native(app):
    """Register all native built-in integration modules on the Flask app."""
    from ProxmoxVEx.native import (
        active_directory,
        docker_swarm,
        netapp_storage,
        opnsense,
        pfsense,
        portainer_rancher,
        proxmox_backup_server,
        truenas,
        vmware_vcenter,
        vyos,
        zabbix,
    )

    modules = [
        active_directory,
        docker_swarm,
        netapp_storage,
        opnsense,
        pfsense,
        portainer_rancher,
        proxmox_backup_server,
        truenas,
        vmware_vcenter,
        vyos,
        zabbix,
    ]
    for mod in modules:
        try:
            mod.register(app)
            logging.info(f"[NATIVE] {mod.__name__} registered")
        except Exception as e:
            logging.error(f"[NATIVE] {mod.__name__} failed to register: {e}")
