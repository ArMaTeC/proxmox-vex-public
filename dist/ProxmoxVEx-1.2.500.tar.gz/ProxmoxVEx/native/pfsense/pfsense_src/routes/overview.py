# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/native/pfsense/pfsense_src/routes/overview.py
# Project:     ProxmoxVEx
# Version:     1.2.499
# Build:       2026.09.23
# Description: Overview route payloads for pfSense — normalized to the
#              same snapshot shape OPNsense emits so
#              `compute_divergence` and the shared UI work identically
# Usage:       import
#              ProxmoxVEx.native.pfsense.pfsense_src.routes.overview
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-23
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Overview route payloads for pfSense — normalized to the same snapshot
shape OPNsense emits so `compute_divergence` and the shared UI work
identically on both platforms."""

from __future__ import annotations

import logging
from concurrent.futures import ThreadPoolExecutor
from typing import Any

from pfsense_src._fwkit import ensure_fwkit_importable
from pfsense_src.client import PFsenseClient, PFsenseClusterClient, PFsenseHost
from pfsense_src.collectors import (
    collect_carp_status,
    collect_certificates,
    collect_gateways,
    collect_hasync,
    collect_interfaces,
    collect_services,
    collect_system,
    collect_vpn,
)
from pfsense_src.configmap import read_section

ensure_fwkit_importable()

from ProxmoxVEx.native.fwkit.divergence import compute_divergence  # noqa: E402
from ProxmoxVEx.native.fwkit.payloads import client_error_envelope  # noqa: E402

log = logging.getLogger(__name__)

CERT_EXPIRY_WARNING_DAYS = 30


def _collect_config_sections(client: PFsenseClient) -> dict[str, list]:
    """Row lists the divergence detector fingerprints (rules/aliases/NAT/
    DHCP/DNS/VPN). Best-effort: a failed section just means that category
    can't be compared this pass."""
    out: dict[str, list] = {}
    for key, entity in (
        ("rules", "rules"), ("aliases", "aliases"), ("nat", "nat_forward"),
        ("dns", "dns_hosts"), ("wireguard", "wireguard"),
        ("ipsec", "ipsec_p1"), ("openvpn", "openvpn_server"),
    ):
        try:
            out[key] = read_section(client, entity)
        except Exception as e:
            log.debug("section %s read failed: %s", key, e)
    try:
        dhcpd = client.config_section("dhcpd")
        out["dhcp"] = [{"if": k, **(v if isinstance(v, dict) else {})} for k, v in (dhcpd or {}).items()] if isinstance(dhcpd, dict) else []
    except Exception as e:
        log.debug("dhcpd read failed: %s", e)
    return out


def build_overview(client: PFsenseClient) -> dict[str, Any]:
    """Single-shot snapshot for the Overview tab. Pure function — pass any client."""
    tasks = {
        "system": collect_system,
        "interfaces": collect_interfaces,
        "gateways": collect_gateways,
        "services": collect_services,
        "vpn": collect_vpn,
        "hasync": collect_hasync,
        "certs": collect_certificates,
        "carp": collect_carp_status,
        "sections": _collect_config_sections,
    }
    with ThreadPoolExecutor(max_workers=len(tasks), thread_name_prefix="pf-overview") as ex:
        futures = {name: ex.submit(fn, client) for name, fn in tasks.items()}
        results = {name: fut.result() for name, fut in futures.items()}

    certs = results["certs"]
    certs_expiring = [c for c in certs if c.get("days_to_expiry", 9999) <= CERT_EXPIRY_WARNING_DAYS]

    return {
        "system": results["system"],
        "interfaces": results["interfaces"],
        "gateways": results["gateways"],
        "services": results["services"],
        "vpn": results["vpn"],
        "hasync": results["hasync"],
        "carp": results["carp"],
        "certs": {
            "total": len(certs),
            "expiring_soon_count": len(certs_expiring),
            "expiring_soon": certs_expiring,
        },
        "sections": results["sections"],
    }


def build_overview_payload(host: PFsenseHost) -> tuple[int, dict[str, Any]]:
    client = PFsenseClient(host)
    try:
        return 200, {"ok": True, "data": build_overview(client)}
    except Exception as e:
        log.warning("overview failed for %s", host.name)
        return client_error_envelope(e, log_label="pfsense overview")


def build_overview_payload_cluster(
    host_a: PFsenseHost,
    host_b: PFsenseHost,
    name_a: str = "NODOA",
    name_b: str = "NODOB",
) -> tuple[int, dict[str, Any]]:
    """Run build_overview on both nodes in parallel and emit cluster shape —
    identical envelope to the OPNsense cluster payload."""
    client_a = PFsenseClient(host_a)
    client_b = PFsenseClient(host_b)
    cluster = PFsenseClusterClient(client_a, client_b, name_a=name_a, name_b=name_b)

    def _safe_build(c: PFsenseClient) -> dict[str, Any]:
        try:
            return {"ok": True, "snap": build_overview(c)}
        except Exception as e:
            status, payload = client_error_envelope(e, log_label="pfsense cluster node")
            return {"ok": False, "error": payload.get("error", "upstream"), "detail": payload.get("detail", str(e)), "status": status}

    with ThreadPoolExecutor(max_workers=2, thread_name_prefix="pf-cluster") as ex:
        fa = ex.submit(_safe_build, client_a)
        fb = ex.submit(_safe_build, client_b)
        ra, rb = fa.result(), fb.result()

    if not (ra["ok"] or rb["ok"]):
        return 502, {
            "ok": False,
            "error": "upstream",
            "detail": f"both nodes failed: A={ra.get('detail')} B={rb.get('detail')}",
        }

    snap_a = ra.get("snap")
    snap_b = rb.get("snap")
    divergence = compute_divergence(snap_a, snap_b) if (snap_a and snap_b) else []

    if snap_a:
        cluster.set_carp_cache(snap_a.get("carp"), None)
    if snap_b:
        cluster.set_carp_cache(None, snap_b.get("carp"))

    try:
        master_name = cluster.master_name() if (snap_a and snap_b) else (name_a if snap_a else name_b)
    except Exception:  # noqa: BLE001 — never let master resolution break the payload
        master_name = name_a

    return 200, {
        "ok": True,
        "cluster": True,
        "data": {
            "nodes": {
                "a": {"name": name_a, **ra} if ra["ok"] else {"name": name_a, **ra, "snap": None},
                "b": {"name": name_b, **rb} if rb["ok"] else {"name": name_b, **rb, "snap": None},
            },
            "divergence": divergence,
            "master": master_name,
            "names": {"a": name_a, "b": name_b},
        },
    }
