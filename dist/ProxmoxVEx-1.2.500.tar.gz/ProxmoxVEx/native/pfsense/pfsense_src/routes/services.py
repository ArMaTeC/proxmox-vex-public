# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/native/pfsense/pfsense_src/routes/services.py
# Project:     ProxmoxVEx
# Version:     1.2.499
# Build:       2026.09.23
# Description: Service route payloads for pfSense.
# Usage:       import
#              ProxmoxVEx.native.pfsense.pfsense_src.routes.services
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-23
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Service route payloads for pfSense."""

from __future__ import annotations

import logging
from typing import Any

from pfsense_src._fwkit import ensure_fwkit_importable
from pfsense_src.client import PFsenseClient, PFsenseHost
from pfsense_src.collectors import collect_services
from pfsense_src.routes._domain import dispatch_action, make_writer
from pfsense_src.writers import ServiceWriter

ensure_fwkit_importable()

from ProxmoxVEx.native.fwkit.normalize import normalize_service  # noqa: E402
from ProxmoxVEx.native.fwkit.payloads import client_error_envelope, ok  # noqa: E402

log = logging.getLogger(__name__)


def build_services_list_payload(host: PFsenseHost) -> tuple[int, dict[str, Any]]:
    client = PFsenseClient(host)
    try:
        svc = collect_services(client)
        items = [normalize_service(s, "pfsense", i) for i, s in enumerate(svc.get("items", []))]
        return ok({"services": items, "total": len(items)})
    except Exception as e:
        return client_error_envelope(e, log_label="pfsense services list")


def build_services_action_payload(
    host: PFsenseHost,
    plugin_dir: str,
    body: dict[str, Any],
    *,
    actor: str = "plugin",
) -> tuple[int, dict[str, Any]]:
    writer = make_writer(ServiceWriter, host, None, plugin_dir, actor)
    service = str(body.get("service", ""))
    action = str(body.get("action", "")).lower()
    if not service:
        return 400, {"ok": False, "error": "bad_request", "detail": "service is required"}
    return dispatch_action(writer, {"action": action}, {
        "start": lambda _b: writer.control(service, "start"),
        "stop": lambda _b: writer.control(service, "stop"),
        "restart": lambda _b: writer.control(service, "restart"),
        "reload": lambda _b: writer.control(service, "reload"),
        # Shared-manager verb: OPNsense calls it "reconfigure"; pfSense
        # maps it onto the FauxAPI reload action for UI parity.
        "reconfigure": lambda _b: writer.control(service, "reload"),
    })
