# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/native/pfsense/pfsense_src/routes/aliases.py
# Project:     ProxmoxVEx
# Version:     1.2.499
# Build:       2026.09.23
# Description: Alias route payloads for pfSense.
# Usage:       import
#              ProxmoxVEx.native.pfsense.pfsense_src.routes.aliases
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-23
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Alias route payloads for pfSense."""

from __future__ import annotations

import logging
from typing import Any

from pfsense_src._fwkit import ensure_fwkit_importable
from pfsense_src.client import PFsenseClient, PFsenseHost
from pfsense_src.routes._domain import dispatch_action, make_writer
from pfsense_src.writers import AliasWriter
from pfsense_src.writers.alias import alias_rows

ensure_fwkit_importable()

from ProxmoxVEx.native.fwkit.normalize import normalize_alias  # noqa: E402
from ProxmoxVEx.native.fwkit.payloads import client_error_envelope, ok  # noqa: E402

log = logging.getLogger(__name__)


def build_aliases_list_payload(host: PFsenseHost) -> tuple[int, dict[str, Any]]:
    client = PFsenseClient(host)
    try:
        rows = [normalize_alias(r, "pfsense", i) for i, r in enumerate(alias_rows(client))]
        return ok({"aliases": rows, "total": len(rows)})
    except Exception as e:
        return client_error_envelope(e, log_label="pfsense aliases list")


def build_aliases_action_payload(
    host: PFsenseHost,
    plugin_dir: str,
    body: dict[str, Any],
    *,
    peer_host: PFsenseHost | None = None,
    actor: str = "plugin",
) -> tuple[int, dict[str, Any]]:
    writer = make_writer(AliasWriter, host, peer_host, plugin_dir, actor)

    def _alias(b: dict[str, Any]) -> dict[str, Any]:
        alias = b.get("alias") or {}
        if not isinstance(alias, dict):
            raise ValueError("alias must be an object")
        return alias

    def _uuid(b: dict[str, Any]) -> str:
        uid = str(b.get("uuid") or b.get("name") or "")
        if not uid:
            raise ValueError("uuid (alias name) is required")
        return uid

    return dispatch_action(writer, body, {
        "create": lambda b: writer.create(_alias(b)),
        "update": lambda b: writer.update(_uuid(b), _alias(b)),
        "delete": lambda b: writer.delete(_uuid(b)),
    })
