# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/native/pfsense/pfsense_src/routes/logs.py
# Project:     ProxmoxVEx
# Version:     1.2.499
# Build:       2026.09.23
# Description: Firewall log payload — `available: False` surfaces
#              honestly when the FauxAPI build can't serve logs.
# Usage:       import
#              ProxmoxVEx.native.pfsense.pfsense_src.routes.logs
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-23
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Firewall log payload — `available: False` surfaces honestly when the
FauxAPI build can't serve logs."""

from __future__ import annotations

import logging
from typing import Any

from pfsense_src._fwkit import ensure_fwkit_importable
from pfsense_src.client import PFsenseClient, PFsenseHost
from pfsense_src.collectors import collect_firewall_log

ensure_fwkit_importable()

from ProxmoxVEx.native.fwkit.payloads import client_error_envelope  # noqa: E402

log = logging.getLogger(__name__)

DEFAULT_LIMIT = 100


def build_logs_payload(host: PFsenseHost, limit: object = DEFAULT_LIMIT) -> tuple[int, dict[str, Any]]:
    try:
        n = int(str(limit))
    except (TypeError, ValueError):
        n = DEFAULT_LIMIT
    n = max(1, min(1000, n))
    client = PFsenseClient(host)
    try:
        data = collect_firewall_log(client, n)
        return 200, {"ok": True, "data": data}
    except Exception as e:
        return client_error_envelope(e, log_label="pfsense logs")
