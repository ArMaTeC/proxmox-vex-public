# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/native/pfsense/pfsense_src/client/__init__.py
# Project:     ProxmoxVEx
# Version:     1.2.499
# Build:       2026.09.23
# Description: Package initializer for client
# Usage:       import ProxmoxVEx.native.pfsense.pfsense_src.client
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-23
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
from .cluster import PFsenseClusterClient  # noqa: F401
from .pfsense_client import (  # noqa: F401
    PFsenseAuthError,
    PFsenseClient,
    PFsenseError,
    PFsenseHost,
    PFsenseTimeoutError,
    PFsenseUnavailableError,
)
