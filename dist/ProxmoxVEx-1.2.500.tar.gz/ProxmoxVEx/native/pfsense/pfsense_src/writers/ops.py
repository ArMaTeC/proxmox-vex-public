# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/native/pfsense/pfsense_src/writers/ops.py
# Project:     ProxmoxVEx
# Version:     1.2.499
# Build:       2026.09.23
# Description: Platform operations for pfSense — apply/reload, config
#              backup/restore, reboot. (FauxAPI exposes
#              `system_reboot` but no halt — callers surface that as
# Usage:       import
#              ProxmoxVEx.native.pfsense.pfsense_src.writers.ops
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-23
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Platform operations for pfSense — apply/reload, config backup/restore,
reboot. (FauxAPI exposes `system_reboot` but no halt — callers surface that
as an `unsupported` detail rather than pretending.)"""

from __future__ import annotations

import contextlib
from dataclasses import asdict
from typing import Any

from pfsense_src._fwkit import ensure_fwkit_importable
from pfsense_src.client import PFsenseClient

ensure_fwkit_importable()

from ProxmoxVEx.native.fwkit.audit import AuditEntry, AuditLog, TimedAction, hash_payload  # noqa: E402
from ProxmoxVEx.native.fwkit.results import WriteResult  # noqa: E402


class OpsWriter:
    def __init__(self, client: PFsenseClient, audit: AuditLog, actor: str = "plugin", **_kw: Any) -> None:
        self.client = client
        self.audit = audit
        self.actor = actor

    def _run(self, action: str, fn, payload: Any, target: str) -> WriteResult:
        with TimedAction() as t:
            try:
                fn()
                ok, detail = True, ""
            except Exception as e:
                ok, detail = False, str(e)
        entry = AuditEntry.now(
            user=self.actor,
            action=action,
            target=target,
            host=self.client.host.name,
            result="ok" if ok else "error",
            duration_ms=t.elapsed_ms,
            detail=detail[:200],
            payload_sha256=hash_payload(payload),
        )
        with contextlib.suppress(OSError):
            self.audit.append(entry)
        return WriteResult(ok=ok, detail=detail, audit=asdict(entry))

    def apply(self) -> WriteResult:
        """`config_reload` — applies pending config.xml changes."""
        return self._run("apply", self.client.config_reload, {}, "pfsense/apply")

    def backup(self) -> dict[str, Any]:
        """Snapshot the running config; returns {ok, backups[]}."""
        with TimedAction() as t:
            try:
                self.client.config_backup()
                out = self.client.config_backup_list()
                backups = out.get("data", out) if isinstance(out, dict) else out
                ok, detail, rows = True, "", backups if isinstance(backups, list) else []
            except Exception as e:
                ok, detail, rows = False, str(e), []
        entry = AuditEntry.now(
            user=self.actor, action="backup", target="pfsense/config",
            host=self.client.host.name, result="ok" if ok else "error",
            duration_ms=t.elapsed_ms, detail=detail[:200],
        )
        with contextlib.suppress(OSError):
            self.audit.append(entry)
        return {"ok": ok, "backups": rows, "detail": detail}

    def list_backups(self) -> dict[str, Any]:
        out = self.client.config_backup_list()
        backups = out.get("data", out) if isinstance(out, dict) else out
        return {"ok": True, "backups": backups if isinstance(backups, list) else []}

    def restore(self, backup_file: str) -> WriteResult:
        """Restore a named config backup — the appliance reloads and may be
        briefly unreachable; the route surfaces that transitional state."""
        if not backup_file or "/" in backup_file or ".." in backup_file:
            return WriteResult(ok=False, detail="validation: invalid backup name")
        return self._run(
            "restore",
            lambda: self.client.config_restore(backup_file),
            {"backup_file": backup_file},
            "pfsense/config",
        )

    def reboot(self) -> WriteResult:
        return self._run("reboot", self.client.system_reboot, {}, "pfsense/system")

    def halt(self) -> WriteResult:
        """FauxAPI has no halt action — report honestly."""
        return WriteResult(ok=False, detail="unsupported: pfSense FauxAPI exposes reboot only, not halt")

    def firmware_check(self) -> dict[str, Any]:
        """Firmware update check via function_call → update info when the
        build supports it; `available: False` when it can't."""
        try:
            out = self.client.function_call({"function": "get_system_update_information", "args": []})
            data = out.get("data", out.get("return", out)) if isinstance(out, dict) else out
            return {"ok": True, "available": True, "info": data}
        except Exception as e:
            return {"ok": True, "available": False, "detail": str(e)}
