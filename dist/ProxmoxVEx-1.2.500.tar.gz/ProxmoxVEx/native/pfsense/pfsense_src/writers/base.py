# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/native/pfsense/pfsense_src/writers/base.py
# Project:     ProxmoxVEx
# Version:     1.2.499
# Build:       2026.09.23
# Description: Shared writer lifecycle for pfSense.
# Usage:       import
#              ProxmoxVEx.native.pfsense.pfsense_src.writers.base
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-23
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Shared writer lifecycle for pfSense.

pfSense has no per-object REST endpoints — a writer mutates a config.xml
row list and posts it back via `config_patch`. `SectionWriter` encodes the
standard lifecycle the OPNsense writers follow (spec 003 research):

  1. caller validates input → `mutate(rows)` returns (new_rows, row_id)
  2. `config_patch` the new row list
  3. apply via the entity's mechanism (filter_configure etc.)
  4. on apply failure → patch the *original* list back (rollback)
  5. HA: sync + verify the section on the peer via fwkit HAVerifier
  6. append an audit row (payload hashed, never verbatim)

Every concrete writer subclasses this and only implements `mutate()` plus
a `uuid_field` used for peer verification.
"""

from __future__ import annotations

import logging
from typing import Any, Callable

from pfsense_src._fwkit import ensure_fwkit_importable
from pfsense_src.client import PFsenseClient
from pfsense_src.configmap import SECTIONS, apply_for, read_section, synthetic_id, write_section

ensure_fwkit_importable()

from ProxmoxVEx.native.fwkit.audit import AuditEntry, AuditLog, TimedAction, hash_payload  # noqa: E402
from ProxmoxVEx.native.fwkit.hasync import (  # noqa: E402
    HAVerifier,
    pfsense_revision_getter,
    pfsense_sync_trigger,
)
from ProxmoxVEx.native.fwkit.results import WriteResult  # noqa: E402

log = logging.getLogger(__name__)


class SectionWriter:
    """Config-section writer with apply/rollback/HA-verify/audit lifecycle."""

    #: configmap SECTIONS key, e.g. "rules", "aliases", "nat_forward"
    entity: str = ""
    #: row field that identifies the written object on the peer
    uuid_field: str = "tracker"

    def __init__(
        self,
        client: PFsenseClient,
        audit: AuditLog,
        actor: str = "plugin",
        peer: PFsenseClient | None = None,
    ) -> None:
        self.client = client
        self.audit = audit
        self.actor = actor
        self.verifier = HAVerifier(
            client,
            peer,
            sync_trigger=pfsense_sync_trigger,
            revision_getter=pfsense_revision_getter,
        )

    # -- to implement by subclasses ----------------------------------------

    def mutate(self, rows: list[dict[str, Any]], action: str, payload: dict[str, Any]) -> tuple[list[dict[str, Any]], str]:
        """Return (new_rows, object_id). Raise ValueError on invalid input."""
        raise NotImplementedError

    # -- lifecycle ----------------------------------------------------------

    def _search_path(self) -> str:
        """Section path the HAVerifier fetches on the peer (`config/...`)."""
        return f"config/{SECTIONS[self.entity]['path'].replace('.', '/')}"

    def _target(self) -> str:
        return f"pfsense/{self.entity}"

    def _record(self, action: str, result: str, t: TimedAction, detail: str = "", payload: Any = None) -> dict[str, Any]:
        entry = AuditEntry.now(
            user=self.actor,
            action=f"{self.entity}.{action}",
            target=self._target(),
            host=self.client.host.name,
            result=result,
            duration_ms=t.elapsed_ms,
            detail=detail,
            payload_sha256=hash_payload(payload) if payload is not None else "",
        )
        try:
            self.audit.append(entry)
        except OSError as e:
            log.warning("audit log write failed: %s", e)
        from dataclasses import asdict

        return asdict(entry)

    def run(
        self,
        action: str,
        payload: dict[str, Any],
        *,
        verify: bool = True,
    ) -> WriteResult:
        """Execute the full write lifecycle and return a WriteResult."""
        original = read_section(self.client, self.entity)

        with TimedAction() as t:
            try:
                new_rows, obj_id = self.mutate(list(original), action, payload)
            except ValueError as e:
                entry = self._record(action, "error", t, str(e), payload)
                return WriteResult(ok=False, detail=str(e), audit=entry)

            try:
                write_section(self.client, self.entity, new_rows)
                apply_for(self.client, self.entity)
            except Exception as e:
                # Rollback: restore the pre-mutation row list so a failed
                # apply leaves the appliance in its prior state.
                log.warning("%s %s failed (%s); rolling back", self.entity, action, e)
                rollback_ok = True
                try:
                    write_section(self.client, self.entity, original)
                    apply_for(self.client, self.entity)
                except Exception as rb_err:
                    rollback_ok = False
                    log.error("rollback failed for %s: %s", self.entity, rb_err)
                entry = self._record(action, "error", t, str(e), payload)
                return WriteResult(
                    ok=False,
                    uuid=obj_id,
                    detail=str(e),
                    rolled_back=rollback_ok,
                    audit=entry,
                )

        sync_result: dict[str, Any] | None = None
        if verify:
            expect_present = action != "delete"
            sr = self.verifier.verify_item(
                self._search_path(),
                self.uuid_field,
                obj_id,
                expect_present=expect_present,
            )
            sync_result = sr.__dict__

        entry = self._record(action, "ok", t, payload=payload)
        return WriteResult(
            ok=True,
            uuid=obj_id,
            sync=sync_result,
            audit=entry,
        )

    # Convenience actions ---------------------------------------------------

    def create(self, row: dict[str, Any]) -> WriteResult:
        return self.run("create", row)

    def update(self, uuid: str, row: dict[str, Any]) -> WriteResult:
        return self.run("update", {**row, "uuid": uuid})

    def delete(self, uuid: str) -> WriteResult:
        return self.run("delete", {"uuid": uuid})


def make_section_mutator(
    entity: str,
    uuid_field: str,
    to_row: Callable[[dict[str, Any]], dict[str, Any]],
) -> Callable[[list[dict[str, Any]], str, dict[str, Any]], tuple[list[dict[str, Any]], str]]:
    """Factory producing `mutate()` for the common append/replace/remove shape.

    `to_row` converts the validated input dict into a config.xml row dict.
    The returned mutator handles create (append), update (replace by uuid),
    delete (remove by uuid), toggle (pfSense rows are disabled by the
    *presence* of `<disabled/>` — enabling must pop the key) and reorder
    (apply an ordered id list).
    """

    def mutate(rows: list[dict[str, Any]], action: str, payload: dict[str, Any]) -> tuple[list[dict[str, Any]], str]:
        def _id(i: int, r: dict[str, Any]) -> str:
            return synthetic_id(entity, i, r) if uuid_field == "tracker" else str(r.get(uuid_field) or synthetic_id(entity, i, r))

        def _idx(uid: str) -> int:
            for i, r in enumerate(rows):
                if str(r.get(uuid_field, "")) == uid or _id(i, r) == uid:
                    return i
            return -1

        if action == "create":
            row = to_row(payload)
            rows.append(row)
            return rows, _id(len(rows) - 1, row)

        uid = str(payload.get("uuid", ""))
        if action in ("update", "delete", "toggle"):
            i = _idx(uid)
            if i < 0:
                raise ValueError(f"{uuid_field}={uid} not found")
            if action == "delete":
                rows.pop(i)
                return rows, uid
            if action == "toggle":
                # <disabled/> presence disables the row — pop it to enable.
                if "disabled" in rows[i]:
                    rows[i].pop("disabled")
                else:
                    rows[i]["disabled"] = ""
                return rows, _id(i, rows[i])
            merged = {**rows[i], **to_row(payload)}
            rows[i] = merged
            return rows, _id(i, merged)

        if action == "reorder":
            order = payload.get("order") or []
            if not isinstance(order, list):
                raise ValueError("order must be a list of row ids")
            by_id = {_id(i, r): r for i, r in enumerate(rows)}
            seen = [by_id[u] for u in order if u in by_id]
            rest = [r for i, r in enumerate(rows) if r not in seen]
            return seen + rest, "reorder"

        if action == "move":
            # Parity contract: move `uuid` so it precedes `before` (append to
            # the end when `before` is empty). Derived into a reorder here so
            # the route surface matches OPNsense's single-row move.
            src = _idx(uid)
            if src < 0:
                raise ValueError(f"{uuid_field}={uid} not found")
            row = rows.pop(src)
            before = str(payload.get("before", ""))
            if before:
                dst = _idx(before)
                if dst < 0:
                    raise ValueError(f"{uuid_field}={before} not found")
            else:
                dst = len(rows)
            rows.insert(dst, row)
            return rows, uid

        raise ValueError(f"unsupported action {action!r}")

    return mutate
