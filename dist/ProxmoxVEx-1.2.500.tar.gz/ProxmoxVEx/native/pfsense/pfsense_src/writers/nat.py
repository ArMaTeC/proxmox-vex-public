# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/native/pfsense/pfsense_src/writers/nat.py
# Project:     ProxmoxVEx
# Version:     1.2.499
# Build:       2026.09.23
# Description: NAT writer — port-forward (`nat.rule`), outbound
#              (`nat.outbound.rule`) and 1:1 (`nat.onetoone`) kinds
#              share one class keyed by `kind`.
# Usage:       import
#              ProxmoxVEx.native.pfsense.pfsense_src.writers.nat
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-23
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""NAT writer — port-forward (`nat.rule`), outbound (`nat.outbound.rule`)
and 1:1 (`nat.onetoone`) kinds share one class keyed by `kind`."""

from __future__ import annotations

from typing import Any

from pfsense_src._fwkit import ensure_fwkit_importable

from .base import SectionWriter, make_section_mutator

ensure_fwkit_importable()

from ProxmoxVEx.native.fwkit.normalize import denormalize_nat  # noqa: E402

_KIND_ENTITY = {
    "port_forward": "nat_forward",
    "outbound": "nat_outbound",
    "one_to_one": "nat_one_to_one",
}


def _to_row(rule: dict[str, Any]) -> dict[str, Any]:
    if not rule.get("interface"):
        raise ValueError("interface is required")
    kind = str(rule.get("_kind", "port_forward"))
    if kind == "port_forward" and not rule.get("target"):
        raise ValueError("port-forward rules require a target")
    row = denormalize_nat(rule, "pfsense", kind)
    return row


class NatWriter(SectionWriter):
    """`kind` selects the config section; defaults to port_forward."""

    uuid_field = "tracker"

    def __init__(self, *args: Any, kind: str = "port_forward", **kwargs: Any) -> None:
        self.kind = kind if kind in _KIND_ENTITY else "port_forward"
        self.entity = _KIND_ENTITY[self.kind]
        super().__init__(*args, **kwargs)
        self._mutate = make_section_mutator(self.entity, self.uuid_field, _to_row)

    def _target(self) -> str:
        return f"pfsense/{self.entity}"

    def mutate(self, rows, action, payload):
        payload = {**payload, "_kind": self.kind}
        return self._mutate(rows, action, payload)
