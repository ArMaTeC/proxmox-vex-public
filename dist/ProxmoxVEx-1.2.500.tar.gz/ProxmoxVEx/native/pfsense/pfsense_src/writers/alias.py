# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/native/pfsense/pfsense_src/writers/alias.py
# Project:     ProxmoxVEx
# Version:     1.2.499
# Build:       2026.09.23
# Description: Alias writer — CRUD on `aliases.alias` plus reference
#              counting so the route layer can warn before deleting a
#              referenced alias (FR-007).
# Usage:       import
#              ProxmoxVEx.native.pfsense.pfsense_src.writers.alias
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-23
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Alias writer — CRUD on `aliases.alias` plus reference counting so the
route layer can warn before deleting a referenced alias (FR-007)."""

from __future__ import annotations

import re
from typing import Any

from pfsense_src._fwkit import ensure_fwkit_importable
from pfsense_src.client import PFsenseClient
from pfsense_src.configmap import listify, read_section

from .base import SectionWriter, make_section_mutator

ensure_fwkit_importable()

from ProxmoxVEx.native.fwkit.normalize import denormalize_alias  # noqa: E402

_NAME_RE = re.compile(r"^[A-Za-z][A-Za-z0-9_]{0,31}$")
_TYPES = ("host", "network", "port", "urltable")


def _validate(alias: dict[str, Any]) -> None:
    name = str(alias.get("name", ""))
    if not _NAME_RE.match(name):
        raise ValueError("alias name must match [A-Za-z][A-Za-z0-9_]{0,31}")
    if str(alias.get("type") or "host") not in _TYPES:
        raise ValueError(f"alias type must be one of {_TYPES}")


def _to_row(alias: dict[str, Any]) -> dict[str, Any]:
    _validate(alias)
    return denormalize_alias(alias, "pfsense")


def alias_ref_count(client: PFsenseClient, name: str) -> int:
    """Count references to an alias across rules + NAT — feeds the delete
    warning the UI shows (FR-007)."""
    refs = 0
    for entity in ("rules", "nat_forward", "nat_outbound", "nat_one_to_one"):
        try:
            rows = read_section(client, entity)
        except Exception:
            continue
        for row in rows:
            for side in ("source", "destination"):
                addr = row.get(side)
                if isinstance(addr, dict) and str(addr.get("address", "")) == name:
                    refs += 1
            if str(row.get("target", "")) == name:
                refs += 1
    return refs


def alias_rows(client: PFsenseClient) -> list[dict[str, Any]]:
    """Raw alias rows with ref counts attached for the list view."""
    rows = read_section(client, "aliases")
    for r in rows:
        name = str(r.get("name", ""))
        r["ref_count"] = alias_ref_count(client, name) if name else 0
    return listify(rows)


class AliasWriter(SectionWriter):
    entity = "aliases"
    uuid_field = "name"

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)
        self._mutate = make_section_mutator(self.entity, self.uuid_field, _to_row)

    def mutate(self, rows, action, payload):
        return self._mutate(rows, action, payload)

    def delete(self, uuid: str):  # noqa: D102 — adds ref-warning detail
        refs = alias_ref_count(self.client, uuid)
        result = self.run("delete", {"uuid": uuid})
        if result.ok and refs:
            result.extra["warnings"] = [f"alias '{uuid}' is referenced by {refs} rule(s)"]
        return result
