# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/native/pfsense/pfsense_src/writers/__init__.py
# Project:     ProxmoxVEx
# Version:     1.2.499
# Build:       2026.09.23
# Description: Write operations against pfSense via FauxAPI.
# Usage:       import ProxmoxVEx.native.pfsense.pfsense_src.writers
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-23
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Write operations against pfSense via FauxAPI.

All writers share the `SectionWriter` lifecycle (patch → apply → rollback
on failure → HA verify → audit) so behaviour matches the OPNsense writers.
"""

from .alias import AliasWriter  # noqa: F401
from .base import SectionWriter  # noqa: F401
from .dhcp import DhcpWriter  # noqa: F401
from .dns import DnsWriter  # noqa: F401
from .nat import NatWriter  # noqa: F401
from .ops import OpsWriter  # noqa: F401
from .rule import RuleWriter  # noqa: F401
from .services import ServiceWriter  # noqa: F401
from .vpn import VpnWriter  # noqa: F401
