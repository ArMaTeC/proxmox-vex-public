# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/native/pfsense/pfsense_src/collectors/services.py
# Project:     ProxmoxVEx
# Version:     1.2.499
# Build:       2026.09.23
# Description: Service status collector for pfSense.
# Usage:       import ProxmoxVEx.native.pfsense.pfsense_src.collectors
#              .services
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-23
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Service status collector for pfSense.

pfSense service state isn't in config.xml — it's probed per service via
`function_call` → `is_service_running`. We enumerate the known service set
from config (unbound, dnsmasq, dhcpd, ipsec, openvpn, captiveportal, ntpd,
syslogd, snmpd, sshd, wireguard) and probe each; probes that fail mark the
service `unknown` rather than guessing.
"""

from __future__ import annotations

import logging
from typing import Any, TypedDict

from pfsense_src.client import PFsenseClient

log = logging.getLogger(__name__)

#: services we can enumerate from config + probe via is_service_running
KNOWN_SERVICES = (
    "unbound", "dnsmasq", "dhcpd", "dhcrelay", "ipsec", "openvpn",
    "captiveportal", "ntpd", "syslogd", "snmpd", "sshd", "wireguard",
    "miniupnpd", "dpinger", "apinger",
)


class ServiceState(TypedDict):
    name: str
    running: bool | None
    status: str
    locked: bool


def _fn(client: PFsenseClient, name: str, *args: Any) -> Any:
    try:
        out = client.function_call({"function": name, "args": list(args)})
    except Exception as e:
        log.debug("function_call %s failed: %s", name, e)
        return None
    if isinstance(out, dict):
        return out.get("data", out.get("return", out))
    return out


def _running(v: Any) -> bool | None:
    if v is None:
        return None
    if isinstance(v, bool):
        return v
    if isinstance(v, (int, float)):
        return bool(v)
    s = str(v).strip().lower()
    if s in ("true", "1", "running", "yes"):
        return True
    if s in ("false", "0", "stopped", "no"):
        return False
    return None


def _enabled_in_config(client: PFsenseClient, name: str) -> bool:
    """Whether the service is configured at all (proxy for 'exists')."""
    section = {
        "unbound": "unbound", "dnsmasq": "dnsmasq", "dhcpd": "dhcpd",
        "ipsec": "ipsec", "openvpn": "openvpn", "wireguard": "wireguard",
        "ntpd": "ntpd", "syslogd": "syslog", "snmpd": "snmpd",
    }.get(name)
    if not section:
        return True  # core services always exist
    try:
        node = client.config_section(section)
        return bool(node)
    except Exception:
        return False


def collect_services(client: PFsenseClient) -> dict[str, Any]:
    items: list[ServiceState] = []
    for name in KNOWN_SERVICES:
        if not _enabled_in_config(client, name):
            continue
        running = _running(_fn(client, "is_service_running", name))
        items.append(ServiceState(
            name=name,
            running=running,
            status="running" if running else ("stopped" if running is False else "unknown"),
            locked=False,
        ))
    return {"items": items, "total": len(items)}
