# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/native/pfsense/pfsense_src/collectors/firewall_log.py
# Project:     ProxmoxVEx
# Version:     1.2.499
# Build:       2026.09.23
# Description: Firewall log collector for pfSense.
# Usage:       import ProxmoxVEx.native.pfsense.pfsense_src.collectors
#              .firewall_log
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-23
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Firewall log collector for pfSense.

FauxAPI has no log endpoint, so logs are read via `function_call` →
`pfSense_get_pf_rules`/`clog`-style helpers when the build permits it. On
builds where function_call is unavailable the collector returns an empty
list with `available: False` — the UI shows "logs unavailable" instead of
stale/empty data presented as current.
"""

from __future__ import annotations

import logging
from typing import Any, TypedDict

from pfsense_src.client import PFsenseClient

log = logging.getLogger(__name__)

DEFAULT_LIMIT = 100


class LogEntry(TypedDict, total=False):
    ts: str
    action: str
    interface: str
    src: str
    dst: str
    proto: str
    rule_label: str


def _fn(client: PFsenseClient, name: str, *args: Any) -> Any:
    try:
        out = client.function_call({"function": name, "args": list(args)})
    except Exception as e:
        log.debug("function_call %s failed: %s", name, e)
        return None
    if isinstance(out, dict):
        return out.get("data", out.get("return", out))
    return out


def collect_firewall_log(client: PFsenseClient, limit: int = DEFAULT_LIMIT) -> dict[str, Any]:
    """Best-effort log read. Returns {entries, available} — `available=False`
    when the appliance can't serve logs through FauxAPI."""
    rows = _fn(client, "get_firewall_log", limit)
    if rows is None:
        return {"entries": [], "available": False}
    entries: list[LogEntry] = []
    for r in (rows if isinstance(rows, list) else []):
        if not isinstance(r, dict):
            continue
        entries.append(LogEntry(
            ts=str(r.get("time") or r.get("ts") or ""),
            action=str(r.get("action") or ""),
            interface=str(r.get("interface") or r.get("if") or ""),
            src=str(r.get("src") or r.get("source") or ""),
            dst=str(r.get("dst") or r.get("destination") or ""),
            proto=str(r.get("proto") or r.get("protocol") or ""),
            rule_label=str(r.get("rulenum") or r.get("rule") or r.get("label") or ""),
        ))
    return {"entries": entries[-limit:], "available": True}
