# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/native/pfsense/pfsense_src/collectors/rules.py
# Project:     ProxmoxVEx
# Version:     1.2.499
# Build:       2026.09.23
# Description: Firewall rule collector — reads `filter.rule` via
#              config_get and normalizes each row through fwkit so the
#              UI sees the same shape as OPNsense rules.
# Usage:       import
#              ProxmoxVEx.native.pfsense.pfsense_src.collectors.rules
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-23
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Firewall rule collector — reads `filter.rule` via config_get and
normalizes each row through fwkit so the UI sees the same shape as
OPNsense rules."""

from __future__ import annotations

import logging
from typing import Any

from pfsense_src._fwkit import ensure_fwkit_importable
from pfsense_src.client import PFsenseClient
from pfsense_src.configmap import listify

ensure_fwkit_importable()

from ProxmoxVEx.native.fwkit.normalize import normalize_rule  # noqa: E402

log = logging.getLogger(__name__)


def collect_rules(client: PFsenseClient) -> list[dict[str, Any]]:
    """Canonical FirewallRule rows (see fwkit.normalize.normalize_rule)."""

    try:
        rows = listify(client.config_section("filter.rule"))
    except Exception as e:
        # Fall back to the legacy `rules` action when config_get is refused
        # (some FauxAPI builds restrict config access).
        log.debug("filter.rule read failed (%s); trying rules action", e)
        raw = client.rules()
        data = raw.get("data", raw) if isinstance(raw, dict) else raw
        rows = data if isinstance(data, list) else []
    return [normalize_rule(r, "pfsense", i) for i, r in enumerate(rows)]
