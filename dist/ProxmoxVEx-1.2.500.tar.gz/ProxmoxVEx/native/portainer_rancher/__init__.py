# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/native/portainer_rancher/__init__.py
# Project:     ProxmoxVEx
# Version:     1.2.499
# Build:       2026.09.23
# Description: Portainer + Rancher container-management native
#              integration (spec 006).
# Usage:       import ProxmoxVEx.native.portainer_rancher
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-23
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Portainer + Rancher container-management native integration (spec 006).

Registers the REST blueprint under ``/api/native/portainer_rancher/`` and a
small set of native-proxy routes (``/api/portainer_rancher/ui`` etc.) so the
module appears in the Native Integrations panel like other native modules.
"""

import logging
import os

from flask import send_file

from ProxmoxVEx.native.registry import register_native_route

from . import api, models

MODULE_ID = "portainer_rancher"
MODULE_NAME = "Portainer & Rancher"
MODULE_DIR = os.path.dirname(os.path.abspath(__file__))
log = logging.getLogger(f"native.{MODULE_ID}")


def _serve_ui():
    """GET — Serve the module HTML UI (iframe target for the native panel)."""
    html_path = os.path.join(MODULE_DIR, "ui.html")
    if os.path.exists(html_path):
        return send_file(html_path, mimetype="text/html")
    return {"error": "UI not found"}, 404


def _status():
    """Lightweight status handler for the shared native proxy."""
    try:
        pc = models.list_portainer_connections()
        rc = models.list_rancher_connections()
        return {
            "module": MODULE_ID,
            "status": "running",
            "portainer_connections": len(pc),
            "rancher_connections": len(rc),
        }
    except Exception as e:
        log.warning("[%s] status error: %s", MODULE_ID, e)
        return {"module": MODULE_ID, "status": "degraded", "error": str(e)}


def _config():
    """Config is managed inside the UI (connections are DB-backed); expose a
    read-only summary so the native panel's config modal isn't empty."""
    try:
        return {
            "note": "Connections are managed in the Portainer & Rancher UI.",
            "portainer_connections": len(models.list_portainer_connections()),
            "rancher_connections": len(models.list_rancher_connections()),
        }
    except Exception:
        return {"note": "Connections are managed in the Portainer & Rancher UI."}


def register(app):
    """Register the integration: tables, API blueprint and native routes."""
    try:
        from ProxmoxVEx.core.db import get_db

        models.ensure_tables(get_db().conn)
    except Exception as e:
        log.error("[%s] Failed to ensure tables: %s", MODULE_ID, e)

    app.register_blueprint(api.bp)
    register_native_route(MODULE_ID, "ui", _serve_ui)
    register_native_route(MODULE_ID, "status", _status)
    register_native_route(MODULE_ID, "config", _config)
    log.info("[NATIVE] %s registered", MODULE_ID)
