# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/native/portainer_rancher/operations.py
# Project:     ProxmoxVEx
# Version:     1.2.499
# Build:       2026.09.23
# Description: Container/workload power and lifecycle operations (US6
#              / FR-009..FR-011).
# Usage:       import ProxmoxVEx.native.portainer_rancher.operations
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-23
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Container/workload power and lifecycle operations (US6 / FR-009..FR-011).

Every operation is tracked in ``portainer_rancher_operations`` and mirrored
to the tamper-evident audit log by the API layer.
"""

import logging
from typing import Any, Dict

from . import models, portainer, rancher

log = logging.getLogger("native.portainer_rancher.operations")


def portainer_container_power(
    container_pk: int, action: str, actor: str = ""
) -> Dict[str, Any]:
    """Start/stop/restart/pause/unpause a container via Portainer."""
    if action not in models.CONTAINER_ACTIONS:
        raise portainer.PortainerError(
            "operation.failed", f"unsupported action {action}"
        )
    row = models.get_row("portainer_containers", container_pk)
    if not row:
        raise portainer.PortainerError("notfound", f"container {container_pk}")
    endpoint = models.get_row("portainer_endpoints", row["endpoint_pk"])
    if not endpoint:
        raise portainer.PortainerError(
            "notfound", f"endpoint {row['endpoint_pk']}"
        )
    conn = models.get_portainer_connection(row["connection_id"])
    if not conn:
        raise portainer.PortainerError(
            "notfound", f"connection {row['connection_id']}"
        )
    client = portainer.build_connector(conn)

    op_id = models.create_operation({
        "manager_type": "portainer",
        "connection_id": conn.id or 0,
        "action": f"container.{action}",
        "target": f"{endpoint['name']}/{row['name']}",
        "actor": actor,
    })
    try:
        result = client.container_action(
            int(endpoint["endpoint_id"]), row["container_id"], action
        )
    except portainer.PortainerError as e:
        models.finish_operation(op_id, "failed", error=e.message)
        raise
    models.finish_operation(op_id, "completed", result=str(result))
    return {"operation_id": op_id, "status": "completed", **result}


def portainer_stack_power(stack_pk: int, action: str, actor: str = "") -> Dict[str, Any]:
    """Start/stop a Portainer stack (where the edition supports it)."""
    if action not in models.STACK_ACTIONS:
        raise portainer.PortainerError(
            "operation.failed", f"unsupported stack action {action}"
        )
    row = models.get_row("portainer_stacks", stack_pk)
    if not row:
        raise portainer.PortainerError("notfound", f"stack {stack_pk}")
    conn = models.get_portainer_connection(row["connection_id"])
    if not conn:
        raise portainer.PortainerError(
            "notfound", f"connection {row['connection_id']}"
        )
    client = portainer.build_connector(conn)
    op_id = models.create_operation({
        "manager_type": "portainer",
        "connection_id": conn.id or 0,
        "action": f"stack.{action}",
        "target": row["name"],
        "actor": actor,
    })
    try:
        result = client.stack_action(int(row["stack_id"]), action)
    except portainer.PortainerError as e:
        models.finish_operation(op_id, "failed", error=e.message)
        raise
    models.finish_operation(op_id, "completed", result=str(result))
    return {"operation_id": op_id, "status": "completed", **result}


def _rancher_context(workload_pk: int):
    row = models.get_row("rancher_workloads", workload_pk)
    if not row:
        raise rancher.RancherError("notfound", f"workload {workload_pk}")
    conn = models.get_rancher_connection(row["connection_id"])
    if not conn:
        raise rancher.RancherError(
            "notfound", f"connection {row['connection_id']}"
        )
    project = models.get_row("rancher_projects", row["project_pk"]) if row.get("project_pk") else None
    project_id = (project or {}).get("project_id") or row.get("workload_id", "").split(":")[0]
    return row, conn, project_id


def rancher_workload_redeploy(workload_pk: int, actor: str = "") -> Dict[str, Any]:
    """Redeploy (restart) a Rancher workload."""
    row, conn, project_id = _rancher_context(workload_pk)
    client = rancher.build_connector(conn)
    op_id = models.create_operation({
        "manager_type": "rancher",
        "connection_id": conn.id or 0,
        "action": "workload.redeploy",
        "target": f"{row['namespace']}/{row['name']}",
        "actor": actor,
    })
    try:
        result = client.redeploy_workload(project_id, row["workload_id"])
    except rancher.RancherError as e:
        models.finish_operation(op_id, "failed", error=e.message)
        raise
    models.finish_operation(op_id, "completed", result=str(result))
    return {"operation_id": op_id, "status": "completed", **result}


def rancher_workload_scale(
    workload_pk: int, replicas: int, actor: str = ""
) -> Dict[str, Any]:
    """Scale a Rancher workload to ``replicas``."""
    if replicas < 0 or replicas > 1000:
        raise rancher.RancherError(
            "operation.failed", "replicas must be between 0 and 1000"
        )
    row, conn, project_id = _rancher_context(workload_pk)
    client = rancher.build_connector(conn)
    op_id = models.create_operation({
        "manager_type": "rancher",
        "connection_id": conn.id or 0,
        "action": f"workload.scale:{replicas}",
        "target": f"{row['namespace']}/{row['name']}",
        "actor": actor,
    })
    try:
        result = client.scale_workload(project_id, row["workload_id"], replicas)
    except rancher.RancherError as e:
        models.finish_operation(op_id, "failed", error=e.message)
        raise
    models.finish_operation(op_id, "completed", result=str(result))
    models.get_db().execute(
        "UPDATE rancher_workloads SET replicas = ? WHERE id = ?",
        (int(replicas), workload_pk),
    )
    return {"operation_id": op_id, "status": "completed", **result}


def rancher_pod_delete(workload_pk: int, actor: str = "") -> Dict[str, Any]:
    """Delete a pod in a Rancher-managed cluster (pod recreation by its
    controller performs a restart)."""
    row, conn, _project_id = _rancher_context(workload_pk)
    if row.get("kind") != "pod":
        raise rancher.RancherError(
            "operation.failed", "pod delete only applies to pod workloads"
        )
    cluster = models.get_row("rancher_clusters", row["cluster_pk"])
    if not cluster:
        raise rancher.RancherError("notfound", f"cluster {row['cluster_pk']}")
    client = rancher.build_connector(conn)
    op_id = models.create_operation({
        "manager_type": "rancher",
        "connection_id": conn.id or 0,
        "action": "pod.delete",
        "target": f"{row['namespace']}/{row['name']}",
        "actor": actor,
    })
    try:
        pod_name = row["workload_id"].split(":")[-1]
        result = client.delete_pod(
            cluster["cluster_id"], row.get("namespace") or "default", pod_name
        )
    except rancher.RancherError as e:
        models.finish_operation(op_id, "failed", error=e.message)
        raise
    models.finish_operation(op_id, "completed", result=str(result))
    return {"operation_id": op_id, "status": "completed", **result}
