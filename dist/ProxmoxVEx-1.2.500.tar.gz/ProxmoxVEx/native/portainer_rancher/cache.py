# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/native/portainer_rancher/cache.py
# Project:     ProxmoxVEx
# Version:     1.2.499
# Build:       2026.09.23
# Description: Small TTL cache used to keep large container
#              inventories browsable.
# Usage:       import ProxmoxVEx.native.portainer_rancher.cache
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-23
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Small TTL cache used to keep large container inventories browsable.

Cached rows live in the integration's SQLite tables; this module memoizes
expensive assembled views (unified workload lists, dashboards) for a short
window so the UI stays responsive with thousands of containers.
"""

import time
from typing import Any, Callable, Dict, Tuple

_TTL_SECONDS = 15
_store: Dict[str, Tuple[float, Any]] = {}


def get_or_compute(key: str, compute: Callable[[], Any], ttl: int = _TTL_SECONDS) -> Any:
    now = time.monotonic()
    entry = _store.get(key)
    if entry and now - entry[0] < ttl:
        return entry[1]
    value = compute()
    _store[key] = (now, value)
    return value


def invalidate(prefix: str = "") -> None:
    if not prefix:
        _store.clear()
        return
    for key in [k for k in _store if k.startswith(prefix)]:
        _store.pop(key, None)
