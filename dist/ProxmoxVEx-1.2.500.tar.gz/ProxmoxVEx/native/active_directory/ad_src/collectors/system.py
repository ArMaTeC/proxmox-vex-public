# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/native/active_directory/ad_src/collectors/system.py
# Project:     ProxmoxVEx
# Version:     1.2.499
# Build:       2026.09.23
# Description: System-level collector for Active Directory.
# Usage:       import ProxmoxVEx.native.active_directory.ad_src.collec
#              tors.system
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-23
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""System-level collector for Active Directory."""

from __future__ import annotations

from typing import Any

from ad_src.client import ADClient


def collect_system(client: ADClient) -> dict[str, Any]:
    """Return AD connection status as an ``{'ok': True, 'data': [...]}`` shape."""
    return client.test_connection()
