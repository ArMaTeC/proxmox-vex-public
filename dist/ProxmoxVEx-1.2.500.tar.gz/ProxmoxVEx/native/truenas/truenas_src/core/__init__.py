# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/native/truenas/truenas_src/core/__init__.py
# Project:     ProxmoxVEx
# Version:     1.2.499
# Build:       2026.09.23
# Description: Core layer: JSON-RPC/WS transport, connection
#              management, typed errors.
# Usage:       import ProxmoxVEx.native.truenas.truenas_src.core
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-23
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Core layer: JSON-RPC/WS transport, connection management, typed errors.

No Flask/ProxmoxVEx imports live here — this package is the part of the
plugin that is fully unit-testable without any host stubs.
"""
