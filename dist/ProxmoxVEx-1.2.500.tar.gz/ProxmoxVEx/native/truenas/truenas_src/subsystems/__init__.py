# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/native/truenas/truenas_src/subsystems/__init__.py
# Project:     ProxmoxVEx
# Version:     1.2.499
# Build:       2026.09.23
# Description: Subsystem collectors (pools, datasets, snapshots,
#              shares, replication, apps_vms, system) implementing the
#              ``Subsystem`` contract from ``core/subsystem.py``
# Usage:       import ProxmoxVEx.native.truenas.truenas_src.subsystems
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-23
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Subsystem collectors (pools, datasets, snapshots, shares, replication,
apps_vms, system) implementing the ``Subsystem`` contract from
``core/subsystem.py`` (brief §2).

F1 (this phase): every module is READ-ONLY — ``list``/``read``/``health``
only. Writers (create/update/delete) land per-subsystem starting F2, behind
the dry-run/confirm/audit write-path (brief §5). See
ProxmoxVEx_PLUGIN_TRUENAS_BRIEF.md §1/§2/§4.2 for the phase table and the
TrueNAS method list each module wraps.
"""
