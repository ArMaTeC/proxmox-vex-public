# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/native/truenas/truenas_src/routes/__init__.py
# Project:     ProxmoxVEx
# Version:     1.2.499
# Build:       2026.09.23
# Description: REST routes exposed to the ProxmoxVEx UI under
#              ``/api/truenas/<path>``, plus config load/save/masking.
# Usage:       import ProxmoxVEx.native.truenas.truenas_src.routes
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-23
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""REST routes exposed to the ProxmoxVEx UI under
``/api/truenas/<path>``, plus config load/save/masking."""
