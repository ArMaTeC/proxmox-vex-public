# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/native/proxmox_backup_server/pbs_src/client/__init__.py
# Project:     ProxmoxVEx
# Version:     1.2.499
# Build:       2026.09.23
# Description: Package initializer for client
# Usage:       import
#              ProxmoxVEx.native.proxmox_backup_server.pbs_src.client
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-23
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
from .pbs_client import (  # noqa: F401
    PBSAuthError,
    PBSClient,
    PBSError,
    PBSHost,
    PBSTimeoutError,
)
