/* --- ProxmoxVEx auto-header start ---
 * -------------------------------------------------------------------
 * File:        ProxmoxVEx/native/vyos/vyos.js
 * Project:     ProxmoxVEx
 * Version:     1.2.499
 * Build:       2026.09.23
 * Description: Vyos JS source
 * Docs:        https://proxmoxvex.com/docs
 * Generated:   2026-09-23
 * -------------------------------------------------------------------
 * --- ProxmoxVEx auto-header end --- */
/* VyOS view: declarative tabs rendered by the shared NativeDataView shell
   (replaces the previous raw JSON <pre> dump). */
(function () {
  'use strict';

  // VyOS returns nested dicts rather than row lists:
  //   interfaces → {interfaces: {<type>: {<name>: {address, description, hw-id}}}
  //   routes     → {"S>* 0.0.0.0/0": {proto, via}, ...}
  // The helpers below flatten them into table rows.

  function asText(v) {
    if (v == null) return null;
    return Array.isArray(v) ? v.join(', ') : String(v);
  }

  function flattenInterfaces(data) {
    var rows = [];
    var groups = (data && data.interfaces) || data || {};
    Object.keys(groups).forEach(function (type) {
      var entries = groups[type];
      if (!entries || typeof entries !== 'object') return;
      Object.keys(entries).forEach(function (name) {
        var e = entries[name] || {};
        rows.push({
          type: type,
          name: name,
          address: asText(e.address),
          description: e.description,
          hwid: e['hw-id']
        });
      });
    });
    return rows;
  }

  function flattenRoutes(data) {
    var rows = [];
    Object.keys(data || {}).forEach(function (key) {
      var r = data[key] || {};
      // Keys look like "S>* 0.0.0.0/0": flags then prefix.
      var parts = String(key).trim().split(/\s+/);
      var prefix = parts.length > 1 ? parts[parts.length - 1] : parts[0];
      var flags = parts.length > 1 ? parts.slice(0, -1).join(' ') : '';
      rows.push({ route: prefix, flags: flags, proto: r.proto, via: r.via });
    });
    return rows;
  }

  NativeDataView.boot({
    ns: 'vyos',
    apiBase: '/api/vyos',
    i18nBase: '/api/native/vyos/i18n',
    tabs: [
      {
        id: 'overview', label: 'overview', endpoint: 'overview',
        render: function (h, data) {
          var row = (data && data[0]) || {};
          h.root.appendChild(h.kpis([
            { label: h.t('interfaces'), value: row.interfaces_count },
            { label: h.t('routes'), value: row.routes_count }
          ]));
          h.section(h.t('router'), h.kv([
            [h.t('host'), row.host],
            [h.t('url'), row.url],
            [h.t('interfaces'), row.interfaces_ok ? h.badge('OK', 'ok') : h.badge('Error', 'err')],
            [h.t('routes'), row.routes_ok ? h.badge('OK', 'ok') : h.badge('Error', 'err')]
          ]));
          var sys = (row.system_data && row.system_data.system) || null;
          if (sys) h.section(h.t('system'), h.kv(sys));
        }
      },
      {
        id: 'interfaces', label: 'interfaces', endpoint: 'interfaces',
        render: function (h, data) {
          h.root.appendChild(h.table(flattenInterfaces(data), [
            { key: 'type', label: h.t('type'), render: function (v) { return h.badge(v, 'info'); } },
            { key: 'name', label: h.t('name') },
            { key: 'address', label: h.t('address') },
            { key: 'description', label: h.t('description') },
            {
              key: 'hwid', label: 'MAC',
              render: function (v) { return v ? h.el('span', { class: 'ndv-muted ndv-mono', text: v }) : null; }
            }
          ]));
        }
      },
      {
        id: 'routes', label: 'routes', endpoint: 'routes',
        render: function (h, data) {
          h.root.appendChild(h.table(flattenRoutes(data), [
            {
              key: 'route', label: h.t('route'),
              render: function (v, row) {
                return h.el('span', { class: 'ndv-mono', text: (row.flags ? row.flags + ' ' : '') + v });
              }
            },
            { key: 'proto', label: h.t('protocol'), render: function (v) { return h.badge(v, 'info'); } },
            { key: 'via', label: h.t('via') }
          ]));
        }
      }
    ]
  });
})();
