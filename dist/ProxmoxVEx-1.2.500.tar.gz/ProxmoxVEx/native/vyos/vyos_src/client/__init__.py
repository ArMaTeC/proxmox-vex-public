# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/native/vyos/vyos_src/client/__init__.py
# Project:     ProxmoxVEx
# Version:     1.2.499
# Build:       2026.09.23
# Description: VyOS HTTP API client package.
# Usage:       import ProxmoxVEx.native.vyos.vyos_src.client
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-23
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""VyOS HTTP API client package."""

from __future__ import annotations

from .vyos_client import (  # noqa: F401
    VyOSClient,
    VyOSHost,
)
