# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/native/vyos/vyos_src/collectors/__init__.py
# Project:     ProxmoxVEx
# Version:     1.2.499
# Build:       2026.09.23
# Description: Read-only collectors against a VyOS host.
# Usage:       import ProxmoxVEx.native.vyos.vyos_src.collectors
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-23
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Read-only collectors against a VyOS host.

Each collector takes a ``VyOSClient`` and returns an ``{'ok': True,
'data': [...]}`` shape, propagating API failures as ``ok``/``error``
responses.
"""

from __future__ import annotations

from .interfaces import collect_interfaces  # noqa: F401
from .routes import collect_routes  # noqa: F401
from .system import collect_system  # noqa: F401
