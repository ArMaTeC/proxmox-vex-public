# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/native/fwkit/normalize.py
# Project:     ProxmoxVEx
# Version:     1.2.499
# Build:       2026.09.23
# Description: Normalize OPNsense API rows and pfSense config.xml rows
#              into the canonical entity shapes consumed by `firewall-
#              manager.js` (specs/003 data-model.md).
# Usage:       import ProxmoxVEx.native.fwkit.normalize
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-23
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Normalize OPNsense API rows and pfSense config.xml rows into the canonical
entity shapes consumed by `firewall-manager.js` (specs/003 data-model.md).

Pure functions — no client imports. Anything platform-specific that has no
canonical slot is preserved under `extra` so nothing is silently dropped.
"""

from __future__ import annotations

from typing import Any


def _bool(v: Any, default: bool = False) -> bool:
    if isinstance(v, bool):
        return v
    if v is None:
        return default
    return str(v).strip().lower() in ("1", "true", "yes", "on", "enabled")


def _s(v: Any, default: str = "") -> str:
    if v is None:
        return default
    return str(v)


def _listify(v: Any) -> list:
    """pfSense XML→JSON often collapses single-element arrays into a dict."""
    if v is None:
        return []
    if isinstance(v, list):
        return v
    return [v]


# ---------------------------------------------------------------------------
# Firewall rules
# ---------------------------------------------------------------------------

def normalize_rule(row: dict[str, Any], platform: str, index: int = 0) -> dict[str, Any]:
    """Canonical FirewallRule. pfSense `disabled` is inverted vs canonical
    `enabled`; pfSense rows get a stable synthetic uuid from their config
    index (`pf-rule-<n>`) so the UI has an id to round-trip."""
    if platform == "pfsense":
        src, dst = row.get("source") or {}, row.get("destination") or {}
        if not isinstance(src, dict):
            src = {"address": src}
        if not isinstance(dst, dict):
            dst = {"address": dst}
        return {
            "uuid": _s(row.get("tracker") or f"pf-rules-{index}"),
            "interface": _s(row.get("interface")),
            "direction": _s(row.get("direction"), "in") or "in",
            "action": _s(row.get("type"), "pass"),
            "ipprotocol": _s(row.get("ipprotocol"), "inet"),
            "protocol": _s(row.get("protocol"), "any") or "any",
            "source_net": _s(src.get("address") or src.get("network"), "any") or "any",
            "source_port": _s(src.get("port")),
            "destination_net": _s(dst.get("address") or dst.get("network"), "any") or "any",
            "destination_port": _s(dst.get("port")),
            "description": _s(row.get("descr") or row.get("description")),
            "enabled": "disabled" not in row,
            "sequence": index,
            "extra": {"floating": _bool(row.get("floating")), "log": _bool(row.get("log"))},
        }
    return {
        "uuid": _s(row.get("uuid")),
        "interface": _s(row.get("interface")),
        "direction": _s(row.get("direction"), "in") or "in",
        "action": _s(row.get("action"), "pass"),
        "ipprotocol": _s(row.get("ipprotocol"), "inet"),
        "protocol": _s(row.get("protocol"), "any") or "any",
        "source_net": _s(row.get("source_net"), "any") or "any",
        "source_port": _s(row.get("source_port")),
        "destination_net": _s(row.get("destination_net"), "any") or "any",
        "destination_port": _s(row.get("destination_port")),
        "description": _s(row.get("description")),
        "enabled": _bool(row.get("enabled"), True),
        "sequence": int(row.get("sequence", index) or index),
        "extra": {"log": _bool(row.get("log"))},
    }


def denormalize_rule(rule: dict[str, Any], platform: str) -> dict[str, Any]:
    """Canonical FirewallRule → platform write payload."""
    if platform == "pfsense":
        out: dict[str, Any] = {
            "type": _s(rule.get("action"), "pass"),
            "interface": _s(rule.get("interface")),
            "ipprotocol": _s(rule.get("ipprotocol"), "inet"),
            "descr": _s(rule.get("description")),
            "source": {"address": _s(rule.get("source_net"), "any")},
            "destination": {"address": _s(rule.get("destination_net"), "any")},
        }
        proto = _s(rule.get("protocol"), "any")
        if proto != "any":
            out["protocol"] = proto
        if rule.get("source_port"):
            out["source"]["port"] = _s(rule["source_port"])
        if rule.get("destination_port"):
            out["destination"]["port"] = _s(rule["destination_port"])
        if not _bool(rule.get("enabled"), True):
            out["disabled"] = ""
        if rule.get("direction") and rule["direction"] != "in":
            out["direction"] = _s(rule["direction"])
        return out
    return {
        "action": _s(rule.get("action"), "pass"),
        "interface": _s(rule.get("interface")),
        "direction": _s(rule.get("direction"), "in") or "in",
        "ipprotocol": _s(rule.get("ipprotocol"), "inet"),
        "protocol": _s(rule.get("protocol"), "any") or "any",
        "source_net": _s(rule.get("source_net"), "any") or "any",
        "source_port": _s(rule.get("source_port")),
        "destination_net": _s(rule.get("destination_net"), "any") or "any",
        "destination_port": _s(rule.get("destination_port")),
        "description": _s(rule.get("description")),
        "enabled": "1" if _bool(rule.get("enabled"), True) else "0",
    }


# ---------------------------------------------------------------------------
# Aliases
# ---------------------------------------------------------------------------

def normalize_alias(row: dict[str, Any], platform: str, index: int = 0) -> dict[str, Any]:
    if platform == "pfsense":
        content = row.get("address", "")
        entries = [e for e in _s(content).split() if e] if isinstance(content, str) else _listify(content)
        return {
            "uuid": _s(row.get("name") or f"pf-aliases-{index}"),
            "name": _s(row.get("name")),
            "type": _s(row.get("type"), "host"),
            "content": entries,
            "description": _s(row.get("descr") or row.get("description")),
            "ref_count": int(row.get("ref_count", 0) or 0),
            "extra": {},
        }
    content = row.get("content", "")
    entries = [e for e in _s(content).replace("\n", ",").split(",") if e.strip()] if isinstance(content, str) else _listify(content)
    return {
        "uuid": _s(row.get("uuid")),
        "name": _s(row.get("name")),
        "type": _s(row.get("type"), "host"),
        "content": [e.strip() for e in entries],
        "description": _s(row.get("description") or row.get("descr")),
        "ref_count": int(row.get("ref_count", 0) or 0),
        "extra": {},
    }


def denormalize_alias(alias: dict[str, Any], platform: str) -> dict[str, Any]:
    content = alias.get("content") or []
    if isinstance(content, str):
        entries = [e.strip() for e in content.replace("\n", ",").split(",") if e.strip()]
    else:
        entries = [str(e) for e in content]
    if platform == "pfsense":
        return {
            "name": _s(alias.get("name")),
            "type": _s(alias.get("type"), "host"),
            "address": " ".join(entries),
            "descr": _s(alias.get("description")),
        }
    return {
        "name": _s(alias.get("name")),
        "type": _s(alias.get("type"), "host"),
        "content": "\n".join(entries),
        "description": _s(alias.get("description")),
        "enabled": "1",
    }


# ---------------------------------------------------------------------------
# NAT
# ---------------------------------------------------------------------------

def normalize_nat(row: dict[str, Any], platform: str, kind: str, index: int = 0) -> dict[str, Any]:
    if platform == "pfsense":
        src, dst = row.get("source") or {}, row.get("destination") or {}
        if not isinstance(src, dict):
            src = {"address": src}
        if not isinstance(dst, dict):
            dst = {"address": dst}
        target = row.get("target") or row.get("externalip") or row.get("external") or ""
        return {
            "uuid": f"pf-nat-{kind}-{index}",
            "kind": kind,
            "interface": _s(row.get("interface")),
            "protocol": _s(row.get("protocol"), "any") or "any",
            "source_net": _s(src.get("address") or src.get("network"), "any") or "any",
            "source_port": _s(src.get("port")),
            "destination_net": _s(dst.get("address") or dst.get("network"), "any") or "any",
            "destination_port": _s(dst.get("port")),
            "target": _s(target),
            "target_port": _s(row.get("local-port") or row.get("local_port")),
            "description": _s(row.get("descr") or row.get("description")),
            "enabled": "disabled" not in row,
            "extra": {"natreflection": _s(row.get("natreflection"))},
        }
    return {
        "uuid": _s(row.get("uuid")),
        "kind": kind,
        "interface": _s(row.get("interface")),
        "protocol": _s(row.get("protocol"), "any") or "any",
        "source_net": _s(row.get("source_net") or row.get("source"), "any") or "any",
        "source_port": _s(row.get("source_port")),
        "destination_net": _s(row.get("destination_net") or row.get("destination"), "any") or "any",
        "destination_port": _s(row.get("destination_port")),
        "target": _s(row.get("target")),
        "target_port": _s(row.get("target_port")),
        "description": _s(row.get("description") or row.get("descr")),
        "enabled": _bool(row.get("enabled"), True),
        "extra": {},
    }


def denormalize_nat(rule: dict[str, Any], platform: str, kind: str) -> dict[str, Any]:
    if platform == "pfsense":
        out: dict[str, Any] = {
            "interface": _s(rule.get("interface")),
            "descr": _s(rule.get("description")),
            "source": {"address": _s(rule.get("source_net"), "any")},
            "destination": {"address": _s(rule.get("destination_net"), "any")},
        }
        proto = _s(rule.get("protocol"), "any")
        if proto != "any":
            out["protocol"] = proto
        if rule.get("source_port"):
            out["source"]["port"] = _s(rule["source_port"])
        if rule.get("destination_port"):
            out["destination"]["port"] = _s(rule["destination_port"])
        if rule.get("target"):
            out["target"] = _s(rule["target"])
        if rule.get("target_port"):
            out["local-port"] = _s(rule["target_port"])
        if not _bool(rule.get("enabled"), True):
            out["disabled"] = ""
        return out
    return {
        "interface": _s(rule.get("interface")),
        "protocol": _s(rule.get("protocol"), "any") or "any",
        "source_net": _s(rule.get("source_net"), "any") or "any",
        "destination_net": _s(rule.get("destination_net"), "any") or "any",
        "target": _s(rule.get("target")),
        "target_port": _s(rule.get("target_port")),
        "description": _s(rule.get("description")),
        "enabled": "1" if _bool(rule.get("enabled"), True) else "0",
    }


# ---------------------------------------------------------------------------
# DHCP / DNS
# ---------------------------------------------------------------------------

def normalize_dhcp_mapping(row: dict[str, Any], platform: str, interface: str = "", index: int = 0) -> dict[str, Any]:
    if platform == "pfsense":
        return {
            "uuid": f"pf-dhcp-{interface}-{index}",
            "interface": _s(row.get("interface") or interface),
            "mac": _s(row.get("mac")),
            "ip": _s(row.get("ipaddr") or row.get("ip")),
            "hostname": _s(row.get("hostname")),
            "description": _s(row.get("descr") or row.get("description")),
            "extra": {},
        }
    return {
        "uuid": _s(row.get("uuid")),
        "interface": _s(row.get("interface") or interface),
        "mac": _s(row.get("mac")),
        "ip": _s(row.get("ip") or row.get("ipaddr")),
        "hostname": _s(row.get("hostname")),
        "description": _s(row.get("description") or row.get("descr")),
        "extra": {},
    }


def normalize_dhcp_scope(row: dict[str, Any], platform: str, index: int = 0) -> dict[str, Any]:
    if platform == "pfsense":
        rng = row.get("range") or {}
        return {
            "uuid": f"pf-scope-{_s(row.get('interface'), str(index))}",
            "interface": _s(row.get("interface")),
            "subnet": _s(row.get("subnet")),
            "range_from": _s(rng.get("from") if isinstance(rng, dict) else row.get("range_from")),
            "range_to": _s(rng.get("to") if isinstance(rng, dict) else row.get("range_to")),
            "description": _s(row.get("descr") or row.get("description")),
            "enabled": _bool(row.get("enable"), True),
            "extra": {},
        }
    return {
        "uuid": _s(row.get("uuid")),
        "interface": _s(row.get("interface")),
        "subnet": _s(row.get("subnet")),
        "range_from": _s(row.get("range_from") or (row.get("range") or {}).get("from", "") if isinstance(row.get("range"), dict) else row.get("range_from")),
        "range_to": _s(row.get("range_to") or (row.get("range") or {}).get("to", "") if isinstance(row.get("range"), dict) else row.get("range_to")),
        "description": _s(row.get("description") or row.get("descr")),
        "enabled": _bool(row.get("enabled"), True),
        "extra": {},
    }


def normalize_dns_host(row: dict[str, Any], platform: str, index: int = 0) -> dict[str, Any]:
    """Canonical DnsOverride host row (Unbound host override)."""
    if platform == "pfsense":
        return {
            "uuid": f"pf-dns-{index}",
            "hostname": _s(row.get("host") or row.get("hostname")),
            "domain": _s(row.get("domain")),
            "ip": _s(row.get("ip") or row.get("ipaddr")),
            "description": _s(row.get("descr") or row.get("description")),
            "extra": {},
        }
    return {
        "uuid": _s(row.get("uuid")),
        "hostname": _s(row.get("hostname") or row.get("host")),
        "domain": _s(row.get("domain")),
        "ip": _s(row.get("server") or row.get("ip") or row.get("ipaddr")),
        "description": _s(row.get("description") or row.get("descr")),
        "extra": {},
    }


def normalize_dns_domain(row: dict[str, Any], platform: str, index: int = 0) -> dict[str, Any]:
    if platform == "pfsense":
        return {
            "uuid": f"pf-dnsdom-{index}",
            "domain": _s(row.get("domain")),
            "ip": _s(row.get("ip") or row.get("ipaddr")),
            "description": _s(row.get("descr") or row.get("description")),
            "extra": {},
        }
    return {
        "uuid": _s(row.get("uuid")),
        "domain": _s(row.get("domain")),
        "ip": _s(row.get("ip") or row.get("ipaddr") or row.get("server")),
        "description": _s(row.get("description") or row.get("descr")),
        "extra": {},
    }


# ---------------------------------------------------------------------------
# VPN
# ---------------------------------------------------------------------------

def normalize_wg_peer(row: dict[str, Any], platform: str, index: int = 0) -> dict[str, Any]:
    if platform == "pfsense":
        allowed = row.get("allowedips") or row.get("allowed_ips") or []
        if isinstance(allowed, str):
            allowed = [a.strip() for a in allowed.split(",") if a.strip()]
        return {
            "uuid": f"pf-wg-{index}",
            "name": _s(row.get("name") or row.get("descr")),
            "public_key": _s(row.get("publickey") or row.get("public_key")),
            "allowed_ips": _listify(allowed),
            "endpoint_host": _s(row.get("endpoint") or row.get("endpoint_host")),
            "endpoint_port": _s(row.get("port") or row.get("endpoint_port")),
            "keepalive": _s(row.get("keepalive") or row.get("persistentkeepalive")),
            "enabled": "disabled" not in row,
            "extra": {},
        }
    allowed = row.get("allowed_ips") or row.get("allowedips") or []
    if isinstance(allowed, str):
        allowed = [a.strip() for a in allowed.split(",") if a.strip()]
    return {
        "uuid": _s(row.get("uuid")),
        "name": _s(row.get("name")),
        "public_key": _s(row.get("public_key") or row.get("publickey")),
        "allowed_ips": _listify(allowed),
        "endpoint_host": _s(row.get("endpoint_host") or row.get("endpoint")),
        "endpoint_port": _s(row.get("endpoint_port") or row.get("port")),
        "keepalive": _s(row.get("keepalive") or row.get("persistentkeepalive")),
        "enabled": _bool(row.get("enabled"), True),
        "extra": {},
    }


def normalize_ipsec_p1(row: dict[str, Any], platform: str, index: int = 0) -> dict[str, Any]:
    """Canonical IpsecTunnel phase-1 row."""
    if platform == "pfsense":
        return {
            "uuid": f"pf-ipsec-p1-{index}",
            "remote_addrs": _s(row.get("remote-gateway") or row.get("remote_addrs")),
            "ike_version": _s(row.get("iketype") or row.get("ike_version"), "ikev2"),
            "auth_method": _s(row.get("authentication_method") or row.get("auth_method"), "psk"),
            "proposal": _s(row.get("proposal") or row.get("encryption") or ""),
            "description": _s(row.get("descr") or row.get("description")),
            "enabled": "disabled" not in row,
            "extra": {"dpd": _s(row.get("dpd_delay"))},
        }
    return {
        "uuid": _s(row.get("uuid")),
        "remote_addrs": _s(row.get("remote_addrs") or row.get("remote")),
        "ike_version": _s(row.get("ike_version") or row.get("version"), "ikev2"),
        "auth_method": _s(row.get("auth_method"), "psk"),
        "proposal": _s(row.get("proposal") or row.get("proposals") or ""),
        "description": _s(row.get("description") or row.get("descr")),
        "enabled": _bool(row.get("enabled"), True),
        "extra": {},
    }


def normalize_openvpn(row: dict[str, Any], platform: str, role: str, index: int = 0) -> dict[str, Any]:
    """Canonical OpenVpnInstance row."""
    if platform == "pfsense":
        return {
            "uuid": f"pf-ovpn-{role}-{index}",
            "role": role,
            "protocol": _s(row.get("protocol"), "udp").lower(),
            "port": _s(row.get("local_port") or row.get("port")),
            "device_mode": _s(row.get("dev_mode") or row.get("device_mode"), "tun"),
            "local_net": _s(row.get("tunnel_network") or row.get("local_net")),
            "remote_net": _s(row.get("remote_network") or row.get("remote_net")),
            "description": _s(row.get("description") or row.get("descr")),
            "enabled": "disabled" not in row,
            "extra": {"cert_ref": _s(row.get("certref") or row.get("cert_ref"))},
        }
    return {
        "uuid": _s(row.get("uuid")),
        "role": role,
        "protocol": _s(row.get("protocol"), "udp").lower(),
        "port": _s(row.get("port") or row.get("local_port")),
        "device_mode": _s(row.get("device_mode") or row.get("dev_type"), "tun"),
        "local_net": _s(row.get("local_net") or row.get("tunnel_network")),
        "remote_net": _s(row.get("remote_net") or row.get("remote_network")),
        "description": _s(row.get("description") or row.get("descr")),
        "enabled": _bool(row.get("enabled"), True),
        "extra": {},
    }


def normalize_service(row: dict[str, Any], platform: str, index: int = 0) -> dict[str, Any]:
    """Canonical ServiceStatus row."""
    status = _s(row.get("status") or ("running" if _bool(row.get("running")) else "stopped"))
    return {
        "name": _s(row.get("name") or row.get("id")),
        "label": _s(row.get("label") or row.get("description") or row.get("name")),
        "status": status if status in ("running", "stopped") else ("running" if _bool(row.get("running")) else "stopped"),
        "locked": _bool(row.get("locked")),
        "extra": {},
    }
