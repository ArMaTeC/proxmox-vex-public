# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/native/opnsense/opnsense_src/writers/openvpn.py
# Project:     ProxmoxVEx
# Version:     1.2.499
# Build:       2026.09.23
# Description: OpenVPN provisioning writer —
#              `/api/openvpn/instances/*` covers both server and
#              client instances (role field selects). `reconfigure`
# Usage:       import
#              ProxmoxVEx.native.opnsense.opnsense_src.writers.openvpn
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-23
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""OpenVPN provisioning writer — `/api/openvpn/instances/*` covers both
server and client instances (role field selects). `reconfigure` applies.

TLS keys/auth material accepted in inputs is write-only — never echoed
back by read paths.
"""

from __future__ import annotations

import contextlib
import logging
from dataclasses import dataclass
from typing import Any

from opnsense_src.client import OPNsenseClient, OPNsenseError

from .alias import AliasResult, alias_result_to_dict
from .audit import AuditEntry, AuditLog, TimedAction, hash_payload
from .hasync_writer import HAVerifier, SyncResult

log = logging.getLogger(__name__)


@dataclass(frozen=True)
class OpenVpnInstanceInput:
    role: str  # "server" | "client"
    protocol: str = "udp4"          # udp4|udp6|tcp4|tcp6
    port: str = "1194"
    device_mode: str = "tun"        # tun | tap
    local_net: str = ""             # tunnel network (server)
    remote_net: str = ""
    cert_ref: str = ""
    remote: str = ""                # remote host (client)
    description: str = ""
    enabled: bool = True

    def to_payload(self) -> dict[str, Any]:
        return {
            "instance": {
                "enabled": "1" if self.enabled else "0",
                "role": self.role,
                "proto": self.protocol,
                "port": self.port,
                "dev_type": self.device_mode,
                "server": self.local_net,
                "remote_networks": self.remote_net,
                "cert": self.cert_ref,
                "remote": self.remote,
                "description": self.description,
            }
        }


OpenVpnResult = AliasResult
openvpn_result_to_dict = alias_result_to_dict


class OpenVpnWriter:
    BASE = "/api/openvpn/instances"

    def __init__(
        self,
        client: OPNsenseClient,
        audit: AuditLog,
        ha: HAVerifier | None = None,
        actor: str = "plugin",
        host_name: str = "",
    ) -> None:
        self.client = client
        self.audit = audit
        self.ha = ha
        self.actor = actor
        self.host_name = host_name or client.host.name

    # ----- read --------------------------------------------------------

    def search(self, phrase: str = "") -> list[dict[str, Any]]:
        params = {"searchPhrase": phrase} if phrase else {}
        out = self.client.get(f"{self.BASE}/search", **params)
        return out.get("rows", []) if isinstance(out, dict) else []

    def get(self, uuid: str) -> dict[str, Any]:
        return self.client.get(f"{self.BASE}/get/{uuid}")

    # ----- write --------------------------------------------------------

    def create(self, payload: OpenVpnInstanceInput) -> OpenVpnResult:
        self._validate(payload)
        with TimedAction() as t:
            try:
                resp = self.client.post(f"{self.BASE}/add", payload.to_payload())
            except OPNsenseError as e:
                self._record("openvpn.create", payload.description or payload.role, "error", t, str(e))
                return OpenVpnResult(ok=False, detail=str(e))
            uuid = str(resp.get("uuid", ""))
            if not uuid:
                self._record("openvpn.create", payload.role, "error", t, "no uuid in response")
                return OpenVpnResult(ok=False, detail="OPNsense did not return uuid")
            try:
                self._apply()
            except OPNsenseError as e:
                with contextlib.suppress(OPNsenseError):
                    self.client.post(f"{self.BASE}/del/{uuid}", {})
                self._record("openvpn.create", uuid, "error", t, f"apply failed → rolled back: {e}")
                return OpenVpnResult(ok=False, detail=f"apply failed → rolled back: {e}")
        sync = self._maybe_sync()
        entry = self._record("openvpn.create", uuid, "ok", t, payload.description,
                           payload_sha256=hash_payload(payload.to_payload()))
        return OpenVpnResult(ok=True, uuid=uuid, sync=sync, audit=entry)

    def update(self, uuid: str, payload: OpenVpnInstanceInput) -> OpenVpnResult:
        self._validate(payload)
        with TimedAction() as t:
            try:
                self.client.post(f"{self.BASE}/set/{uuid}", payload.to_payload())
                self._apply()
            except OPNsenseError as e:
                self._record("openvpn.update", uuid, "error", t, str(e))
                return OpenVpnResult(ok=False, uuid=uuid, detail=str(e))
        sync = self._maybe_sync()
        entry = self._record("openvpn.update", uuid, "ok", t,
                           payload_sha256=hash_payload(payload.to_payload()))
        return OpenVpnResult(ok=True, uuid=uuid, sync=sync, audit=entry)

    def delete(self, uuid: str) -> OpenVpnResult:
        with TimedAction() as t:
            try:
                self.client.post(f"{self.BASE}/del/{uuid}", {})
                self._apply()
            except OPNsenseError as e:
                self._record("openvpn.delete", uuid, "error", t, str(e))
                return OpenVpnResult(ok=False, uuid=uuid, detail=str(e))
        sync = self._maybe_sync()
        entry = self._record("openvpn.delete", uuid, "ok", t)
        return OpenVpnResult(ok=True, uuid=uuid, sync=sync, audit=entry)

    # ----- internals -----------------------------------------------------

    def _validate(self, payload: OpenVpnInstanceInput) -> None:
        if payload.role not in ("server", "client"):
            raise ValueError("role must be server|client")
        if payload.device_mode not in ("tun", "tap"):
            raise ValueError("device_mode must be tun|tap")
        if payload.role == "client" and not payload.remote:
            raise ValueError("client instances require a remote host")

    def _apply(self) -> None:
        self.client.post("/api/openvpn/service/reconfigure", {})

    def _maybe_sync(self) -> SyncResult | None:
        if self.ha is None:
            return None
        return self.ha.verify_robust(f"{self.BASE}/search")

    def _record(
        self,
        action: str,
        target: str,
        result: str,
        timer: TimedAction,
        detail: str = "",
        payload_sha256: str = "",
    ) -> AuditEntry:
        entry = AuditEntry.now(
            user=self.actor, action=action, target=target, host=self.host_name,
            result=result, duration_ms=timer.elapsed_ms, detail=detail,
            payload_sha256=payload_sha256,
        )
        try:
            self.audit.append(entry)
        except OSError as e:
            log.warning("audit log write failed: %s", e)
        return entry
