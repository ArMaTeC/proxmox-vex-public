# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/native/opnsense/opnsense_src/writers/ipsec.py
# Project:     ProxmoxVEx
# Version:     1.2.499
# Build:       2026.09.23
# Description: IPsec provisioning writer — `/api/ipsec/connections/*`
#              (the MVC model introduced in OPNsense 23.x). A tunnel =
#              a `connection` (phase-1) plus `children` (phase-2...
# Usage:       import
#              ProxmoxVEx.native.opnsense.opnsense_src.writers.ipsec
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-23
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""IPsec provisioning writer — `/api/ipsec/connections/*` (the MVC model
introduced in OPNsense 23.x). A tunnel = a `connection` (phase-1) plus
`children` (phase-2 traffic selectors). `reconfigure` applies.

Secret material (PSKs) is write-only — accepted in inputs, never returned
by read paths.
"""

from __future__ import annotations

import contextlib
import logging
from dataclasses import dataclass
from typing import Any

from opnsense_src.client import OPNsenseClient, OPNsenseError

from .alias import AliasResult, alias_result_to_dict
from .audit import AuditEntry, AuditLog, TimedAction, hash_payload
from .hasync_writer import HAVerifier, SyncResult

log = logging.getLogger(__name__)


@dataclass(frozen=True)
class IpsecConnectionInput:
    remote_addrs: str
    local_addrs: str = ""
    ike_version: str = "2"          # "1" | "2"
    auth_method: str = "psk"        # psk | pubkey
    proposals: str = "aes256-sha256-modp2048"
    description: str = ""
    psk: str = ""                    # write-only
    enabled: bool = True

    def to_payload(self) -> dict[str, Any]:
        return {
            "connection": {
                "enabled": "1" if self.enabled else "0",
                "proposals": self.proposals,
                "version": self.ike_version,
                "local_addrs": self.local_addrs,
                "remote_addrs": self.remote_addrs,
                "local": {"authentication": self.auth_method, "id": ""},
                "remote": {"authentication": self.auth_method, "id": ""},
                "description": self.description,
            }
        }


@dataclass(frozen=True)
class IpsecChildInput:
    connection_uuid: str
    local_net: str
    remote_net: str
    proposals: str = "aes256-sha256-modp2048"
    mode: str = "tunnel"            # tunnel | transport | beet
    start_action: str = "start"
    description: str = ""
    enabled: bool = True

    def to_payload(self) -> dict[str, Any]:
        return {
            "child": {
                "enabled": "1" if self.enabled else "0",
                "connection": self.connection_uuid,
                "local_ts": self.local_net,
                "remote_ts": self.remote_net,
                "esp_proposals": self.proposals,
                "mode": self.mode,
                "start_action": self.start_action,
                "description": self.description,
            }
        }


IpsecResult = AliasResult
ipsec_result_to_dict = alias_result_to_dict


class IpsecWriter:
    BASE = "/api/ipsec/connections"

    def __init__(
        self,
        client: OPNsenseClient,
        audit: AuditLog,
        ha: HAVerifier | None = None,
        actor: str = "plugin",
        host_name: str = "",
    ) -> None:
        self.client = client
        self.audit = audit
        self.ha = ha
        self.actor = actor
        self.host_name = host_name or client.host.name

    # ----- read --------------------------------------------------------

    def search_connections(self, phrase: str = "") -> list[dict[str, Any]]:
        params = {"searchPhrase": phrase} if phrase else {}
        out = self.client.get(f"{self.BASE}/searchConnection", **params)
        return out.get("rows", []) if isinstance(out, dict) else []

    def search_children(self, phrase: str = "") -> list[dict[str, Any]]:
        params = {"searchPhrase": phrase} if phrase else {}
        out = self.client.get(f"{self.BASE}/searchChild", **params)
        return out.get("rows", []) if isinstance(out, dict) else []

    # ----- write --------------------------------------------------------

    def create_connection(self, payload: IpsecConnectionInput) -> IpsecResult:
        self._validate_conn(payload)
        with TimedAction() as t:
            try:
                resp = self.client.post(f"{self.BASE}/addConnection", payload.to_payload())
            except OPNsenseError as e:
                self._record("ipsec.conn_create", payload.remote_addrs, "error", t, str(e))
                return IpsecResult(ok=False, detail=str(e))
            uuid = str(resp.get("uuid", ""))
            if not uuid:
                self._record("ipsec.conn_create", payload.remote_addrs, "error", t, "no uuid in response")
                return IpsecResult(ok=False, detail="OPNsense did not return uuid")
            try:
                self._apply()
            except OPNsenseError as e:
                with contextlib.suppress(OPNsenseError):
                    self.client.post(f"{self.BASE}/delConnection/{uuid}", {})
                self._record("ipsec.conn_create", uuid, "error", t, f"apply failed → rolled back: {e}")
                return IpsecResult(ok=False, detail=f"apply failed → rolled back: {e}")
        sync = self._maybe_sync("searchConnection")
        entry = self._record("ipsec.conn_create", uuid, "ok", t, payload.description,
                           payload_sha256=hash_payload(payload.to_payload()))
        return IpsecResult(ok=True, uuid=uuid, sync=sync, audit=entry)

    def update_connection(self, uuid: str, payload: IpsecConnectionInput) -> IpsecResult:
        self._validate_conn(payload)
        with TimedAction() as t:
            try:
                self.client.post(f"{self.BASE}/setConnection/{uuid}", payload.to_payload())
                self._apply()
            except OPNsenseError as e:
                self._record("ipsec.conn_update", uuid, "error", t, str(e))
                return IpsecResult(ok=False, uuid=uuid, detail=str(e))
        sync = self._maybe_sync("searchConnection")
        entry = self._record("ipsec.conn_update", uuid, "ok", t,
                           payload_sha256=hash_payload(payload.to_payload()))
        return IpsecResult(ok=True, uuid=uuid, sync=sync, audit=entry)

    def delete_connection(self, uuid: str) -> IpsecResult:
        with TimedAction() as t:
            try:
                self.client.post(f"{self.BASE}/delConnection/{uuid}", {})
                self._apply()
            except OPNsenseError as e:
                self._record("ipsec.conn_delete", uuid, "error", t, str(e))
                return IpsecResult(ok=False, uuid=uuid, detail=str(e))
        sync = self._maybe_sync("searchConnection")
        entry = self._record("ipsec.conn_delete", uuid, "ok", t)
        return IpsecResult(ok=True, uuid=uuid, sync=sync, audit=entry)

    def create_child(self, payload: IpsecChildInput) -> IpsecResult:
        if not payload.connection_uuid:
            raise ValueError("connection_uuid is required")
        if not payload.local_net or not payload.remote_net:
            raise ValueError("local_net and remote_net are required")
        with TimedAction() as t:
            try:
                resp = self.client.post(f"{self.BASE}/addChild", payload.to_payload())
            except OPNsenseError as e:
                self._record("ipsec.child_create", payload.connection_uuid, "error", t, str(e))
                return IpsecResult(ok=False, detail=str(e))
            uuid = str(resp.get("uuid", ""))
            try:
                self._apply()
            except OPNsenseError as e:
                with contextlib.suppress(OPNsenseError):
                    self.client.post(f"{self.BASE}/delChild/{uuid}", {})
                self._record("ipsec.child_create", uuid, "error", t, f"apply failed → rolled back: {e}")
                return IpsecResult(ok=False, detail=f"apply failed → rolled back: {e}")
        sync = self._maybe_sync("searchChild")
        entry = self._record("ipsec.child_create", uuid, "ok", t, payload.description,
                           payload_sha256=hash_payload(payload.to_payload()))
        return IpsecResult(ok=True, uuid=uuid, sync=sync, audit=entry)

    def delete_child(self, uuid: str) -> IpsecResult:
        with TimedAction() as t:
            try:
                self.client.post(f"{self.BASE}/delChild/{uuid}", {})
                self._apply()
            except OPNsenseError as e:
                self._record("ipsec.child_delete", uuid, "error", t, str(e))
                return IpsecResult(ok=False, uuid=uuid, detail=str(e))
        sync = self._maybe_sync("searchChild")
        entry = self._record("ipsec.child_delete", uuid, "ok", t)
        return IpsecResult(ok=True, uuid=uuid, sync=sync, audit=entry)

    # ----- internals -----------------------------------------------------

    def _validate_conn(self, payload: IpsecConnectionInput) -> None:
        if not payload.remote_addrs:
            raise ValueError("remote_addrs is required")
        if payload.ike_version not in ("1", "2", "ikev1", "ikev2"):
            raise ValueError("ike_version must be 1/2")
        if payload.auth_method not in ("psk", "pubkey", "eap"):
            raise ValueError("auth_method must be psk|pubkey|eap")

    def _apply(self) -> None:
        self.client.post("/api/ipsec/service/reconfigure", {})

    def _maybe_sync(self, search: str) -> SyncResult | None:
        if self.ha is None:
            return None
        return self.ha.verify_robust(f"{self.BASE}/{search}")

    def _record(
        self,
        action: str,
        target: str,
        result: str,
        timer: TimedAction,
        detail: str = "",
        payload_sha256: str = "",
    ) -> AuditEntry:
        entry = AuditEntry.now(
            user=self.actor, action=action, target=target, host=self.host_name,
            result=result, duration_ms=timer.elapsed_ms, detail=detail,
            payload_sha256=payload_sha256,
        )
        try:
            self.audit.append(entry)
        except OSError as e:
            log.warning("audit log write failed: %s", e)
        return entry
