# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/native/opnsense/opnsense_src/routes/_domain.py
# Project:     ProxmoxVEx
# Version:     1.2.499
# Build:       2026.09.23
# Description: Shared action-dispatch helper — every write route does
#              the same dance: dispatch the action verb on the writer
#              → map client errors to the standard envelope →
# Usage:       import
#              ProxmoxVEx.native.opnsense.opnsense_src.routes._domain
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-23
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Shared action-dispatch helper — every write route does the same dance:
dispatch the action verb on the writer → map client errors to the standard
envelope → serialize the result. Mirrors `pfsense_src/routes/_domain.py`
so both plugins' routes stay byte-for-byte symmetric in behaviour."""

from __future__ import annotations

import logging
from dataclasses import asdict, is_dataclass
from typing import Any, Callable, cast

from opnsense_src._fwkit import ensure_fwkit_importable
from opnsense_src.client import OPNsenseClient, OPNsenseHost
from opnsense_src.writers import AuditLog, HAVerifier

ensure_fwkit_importable()

from ProxmoxVEx.native.fwkit.payloads import (  # noqa: E402
    audit_log_path,
    client_error_envelope,
    err,
)

log = logging.getLogger(__name__)


def make_writer(
    factory: Callable[..., Any],
    host: OPNsenseHost,
    peer_host: OPNsenseHost | None,
    plugin_dir: str,
    actor: str,
    **kwargs: Any,
) -> Any:
    """Construct a writer with the standard audit + HA peer wiring.

    OPNsense writers take `ha: HAVerifier | None` — when a peer host is
    configured (cluster mode) the verifier syncs to the peer and confirms
    the write propagated (fwkit HAVerifier defaults are the OPNsense
    syncTo/revision transports).
    """
    client = OPNsenseClient(host)
    peer = OPNsenseClient(peer_host) if peer_host is not None else None
    ha = HAVerifier(client, peer) if peer is not None else None
    audit = AuditLog(audit_log_path(plugin_dir))
    return factory(client, audit, ha=ha, actor=actor, **kwargs)


def _serialize(result: Any) -> dict[str, Any]:
    """WriteResult/AliasResult → wire dict (dataclass-aware)."""
    if is_dataclass(result) and not isinstance(result, type):
        return asdict(result)
    if hasattr(result, "to_dict"):
        return cast(Any, result).to_dict()  # hasattr-guarded dynamic attr
    return dict(result) if isinstance(result, dict) else {"result": result}


def dispatch_action(
    writer: Any,
    body: dict[str, Any],
    actions: dict[str, Callable[..., Any]],
) -> tuple[int, dict[str, Any]]:
    """Run `actions[body["action"]]`; the callable takes the body and returns
    a result object, dict, or (status, payload)."""
    action = str(body.get("action", "")).lower()
    fn = actions.get(action)
    if fn is None:
        return err("bad_request", f"action must be one of {sorted(actions)}")
    try:
        result = fn(body)
    except ValueError as e:
        return err("validation", str(e))
    except Exception as e:
        return client_error_envelope(e, log_label=f"opnsense {action}")
    if isinstance(result, tuple):
        return result
    if isinstance(result, dict) and "ok" in result:
        status = 200 if result.get("ok") else 502
        if not result.get("ok"):
            return status, {**result, "error": result.get("error", "upstream")}
        return 200, {"ok": True, "data": result}
    d = _serialize(result)
    if not d.get("ok", True):
        return 502, {"ok": False, "error": "upstream", "detail": d.get("detail") or "write failed", "data": d}
    return 200, {"ok": True, "data": d}
