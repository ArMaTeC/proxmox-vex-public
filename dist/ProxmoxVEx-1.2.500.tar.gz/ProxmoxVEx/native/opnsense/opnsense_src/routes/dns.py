#!/usr/bin/env python3
# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/native/opnsense/opnsense_src/routes/dns.py
# Project:     ProxmoxVEx
# Version:     1.2.499
# Build:       2026.09.23
# Description: Combined DNS route for the shared firewall-manager UI.
# Usage:       import
#              ProxmoxVEx.native.opnsense.opnsense_src.routes.dns
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-23
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Combined DNS route for the shared firewall-manager UI.

pfSense's ``dns`` route returns ``{hosts, domains}`` in one payload and
accepts ``host_set|host_delete|domain_set|domain_delete``.  This adapter
gives OPNsense the identical surface by delegating to the existing Unbound
builders, translating the manager's field names (``ip``) to Unbound's
(``server``) so both plugins consume the same UI contract.
"""

from __future__ import annotations

from typing import Any

from opnsense_src._fwkit import ensure_fwkit_importable

ensure_fwkit_importable()

from ProxmoxVEx.native.fwkit.normalize import (  # noqa: E402
    normalize_dns_domain,
    normalize_dns_host,
)

from .unbound import (  # noqa: E402
    build_unbound_action_payload,
    build_unbound_domain_action_payload,
    build_unbound_domain_list_payload,
    build_unbound_list_payload,
)

# pfSense parity action surface → underlying Unbound builders.
_ACTION_MAP = {
    "host_set": "create",
    "host_delete": "delete",
    "domain_set": "create",
    "domain_delete": "delete",
}


def build_dns_list_payload(host) -> tuple[int, dict[str, Any]]:
    """Merge Unbound host overrides and domain forwards into one payload."""
    sh, hosts = build_unbound_list_payload(host)
    if not (isinstance(hosts, dict) and hosts.get("ok")):
        return sh, hosts
    sd, domains = build_unbound_domain_list_payload(host)
    if not (isinstance(domains, dict) and domains.get("ok")):
        return sd, domains
    h_rows = hosts.get("data", {}).get("hosts", [])
    d_rows = domains.get("data", {}).get("domains", [])
    return 200, {
        "ok": True,
        "data": {
            "hosts": [normalize_dns_host(r, "opnsense", i) for i, r in enumerate(h_rows)],
            "domains": [normalize_dns_domain(r, "opnsense", i) for i, r in enumerate(d_rows)],
        },
    }


def build_dns_action_payload(
    host,
    plugin_dir: str,
    body: dict[str, Any],
    *,
    peer_host=None,
    actor: str = "plugin",
) -> tuple[int, dict[str, Any]]:
    """Translate the shared DNS action surface onto the Unbound builders."""
    action = str(body.get("action", "")).lower()
    mapped = _ACTION_MAP.get(action)
    if mapped is None:
        return 400, {
            "ok": False,
            "error": "bad_request",
            "detail": "action must be host_set|host_delete|domain_set|domain_delete",
        }

    if action.startswith("host_"):
        # Unbound calls the override target "server"; the shared UI sends "ip".
        h = dict(body.get("host") or {})
        if "ip" in h and "server" not in h:
            h["server"] = h.pop("ip")
        translated = {"action": mapped, "host": h, "uuid": body.get("uuid", "")}
        return build_unbound_action_payload(
            host, plugin_dir, translated, actor=actor, peer_host=peer_host
        )
    d = dict(body.get("domain") or {})
    if "ip" in d and "server" not in d:
        d["server"] = d.pop("ip")
    translated = {"action": mapped, "domain": d, "uuid": body.get("uuid", "")}
    return build_unbound_domain_action_payload(
        host, plugin_dir, translated, actor=actor, peer_host=peer_host
    )
