# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/native/opnsense/opnsense_src/metrics/__init__.py
# Project:     ProxmoxVEx
# Version:     1.2.499
# Build:       2026.09.23
# Description: Prometheus metrics exporter for the OPNsense plugin.
# Usage:       import ProxmoxVEx.native.opnsense.opnsense_src.metrics
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-23
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Prometheus metrics exporter for the OPNsense plugin."""

from .exporter import render_metrics  # noqa: F401
