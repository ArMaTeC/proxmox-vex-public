# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/native/opnsense/opnsense_src/divergence.py
# Project:     ProxmoxVEx
# Version:     1.2.499
# Build:       2026.09.23
# Description: Compat shim — the divergence detector moved to
#              `ProxmoxVEx.native.fwkit.divergence` (extended with
#              config-section drift) so the pfSense plugin shares it.
# Usage:       import
#              ProxmoxVEx.native.opnsense.opnsense_src.divergence
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-23
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Compat shim — the divergence detector moved to
`ProxmoxVEx.native.fwkit.divergence` (extended with config-section drift)
so the pfSense plugin shares it.
"""

from opnsense_src._fwkit import ensure_fwkit_importable

ensure_fwkit_importable()

from ProxmoxVEx.native.fwkit.divergence import (  # noqa: E402,F401
    CONFIG_SECTIONS,
    Divergence,
    Severity,
    compute_divergence,
)
