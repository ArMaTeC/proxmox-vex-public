# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/native/zabbix/zabbix_src/routes/__init__.py
# Project:     ProxmoxVEx
# Version:     1.2.499
# Build:       2026.09.23
# Description: Read-only route payload builders for Zabbix.
# Usage:       import ProxmoxVEx.native.zabbix.zabbix_src.routes
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-23
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Read-only route payload builders for Zabbix."""

from __future__ import annotations

from .overview import (  # noqa: F401
    build_hosts_payload,
    build_overview_payload,
    build_problems_payload,
)
