# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/ids/capture.py
# Project:     ProxmoxVEx
# Version:     1.2.499
# Build:       2026.09.23
# Description: Packet/flow capture and agent coordination for the
#              IDS/IPS module.
# Usage:       import ProxmoxVEx.ids.capture
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-23
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Packet/flow capture and agent coordination for the IDS/IPS module."""

import logging

from ProxmoxVEx.ids import models

logger = logging.getLogger(__name__)


def start_capture_for_segment(segment_id: int, node_id: str = "") -> bool:
    """Start capturing traffic for a monitored segment."""
    logger.info("Starting capture for segment %s", segment_id)
    try:
        models.upsert_capture_job(segment_id, node_id or "local", "running")
        return True
    except Exception as e:
        logger.error("Failed to start capture for segment %s: %s", segment_id, e)
        return False


def stop_capture_for_segment(segment_id: int, reason: str | None = None) -> bool:
    """Stop capturing traffic for a monitored segment."""
    logger.info("Stopping capture for segment %s: %s", segment_id, reason)
    try:
        models.upsert_capture_job(segment_id, "local", "paused" if reason else "stopped", reason)
        return True
    except Exception as e:
        logger.error("Failed to stop capture for segment %s: %s", segment_id, e)
        return False


def process_packets(segment_id: int, packets: list) -> int:
    """Process a list of packets/flows for a segment and raise alerts."""
    from ProxmoxVEx.ids import actions, alerts, engine, policies

    if not models.get_segment(segment_id):
        logger.error("No segment found for packet processing: %s", segment_id)
        return 0

    policy = models.find_policy_for_segment(segment_id)
    detected = engine.analyze_traffic(segment_id, packets)
    for item in detected:
        alert = {
            "segment_id": segment_id,
            "rule_id": item.get("rule_id"),
            "threat_type": item.get("threat_type", "unknown"),
            "severity": item.get("severity", "medium"),
            "source": item.get("source", ""),
            "destination": item.get("destination", ""),
            "context": item.get("context", {}),
        }
        alert_id = alerts.create_alert(alert)
        if alert_id and policy:
            action = policies.resolve_action(alert, policy)
            if action and action != "alert" and action != "approval":
                actions.apply_action(alert_id, action)
    # Heartbeat only an already-running job — an on-demand /analyze pass must
    # not resurrect a stopped job or create a phantom 'running' row.
    job = models.get_capture_job(segment_id)
    if job and job.get("status") == "running":
        models.upsert_capture_job(segment_id, job.get("node_id") or "local", "running")
    return len(detected)
