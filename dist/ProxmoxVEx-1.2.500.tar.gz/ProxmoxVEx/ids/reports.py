# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/ids/reports.py
# Project:     ProxmoxVEx
# Version:     1.2.499
# Build:       2026.09.23
# Description: Report generation helpers for the IDS/IPS module.
# Usage:       import ProxmoxVEx.ids.reports
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-23
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Report generation helpers for the IDS/IPS module."""

import logging
from collections import Counter
from datetime import UTC, datetime
from typing import Any, Dict, List

from ProxmoxVEx.core.db import get_db
from ProxmoxVEx.ids import models

logger = logging.getLogger(__name__)


def _now() -> str:
    return datetime.now(UTC).isoformat()


def _in_window(ts: str, start: str, end: str) -> bool:
    try:
        dt = datetime.fromisoformat(ts)
        s = datetime.fromisoformat(start)
        e = datetime.fromisoformat(end)
        return s <= dt <= e
    except Exception:
        return False


def _filter_window(items: List[Dict[str, Any]], start: str, end: str) -> List[Dict[str, Any]]:
    return [i for i in items if _in_window(i.get("created_at", ""), start, end)]


def generate_summary(start: str, end: str) -> Dict[str, Any]:
    """Generate a summary report for a time window."""
    alerts = _filter_window(models.list_alerts(limit=10000), start, end)
    actions = _filter_window(_list_actions(), start, end)
    threats = Counter(a.get("threat_type", "unknown") for a in alerts)
    severities = Counter(a.get("severity", "low") for a in alerts)
    return {
        "start": start,
        "end": end,
        "alerts": len(alerts),
        "actions": len(actions),
        "top_threats": threats.most_common(10),
        "by_severity": dict(severities),
    }


def generate_timeline(start: str, end: str) -> List[Dict[str, Any]]:
    """Generate a chronological list of alerts and actions for a time window."""
    alerts = _filter_window(models.list_alerts(limit=10000), start, end)
    actions = _filter_window(_list_actions(), start, end)
    events = []
    for a in alerts:
        events.append({
            "timestamp": a.get("created_at"),
            "type": "alert",
            "threat_type": a.get("threat_type"),
            "severity": a.get("severity"),
            "source": a.get("source"),
            "action_taken": a.get("action_taken"),
        })
    for a in actions:
        events.append({
            "timestamp": a.get("applied_at"),
            "type": "action",
            "action_type": a.get("action_type"),
            "operator": a.get("operator"),
            "reason": a.get("reason"),
        })
    return sorted(events, key=lambda x: x["timestamp"], reverse=True)


def generate_export(start: str, end: str, fmt: str = "json") -> Dict[str, Any]:
    """Generate a downloadable export for a time window."""
    summary = generate_summary(start, end)
    timeline = generate_timeline(start, end)
    audit = _filter_window(_list_audit(), start, end)
    payload = {
        "generated_at": _now(),
        "start": start,
        "end": end,
        "format": fmt,
        "summary": summary,
        "timeline": timeline,
        "audit": audit,
    }
    return payload


def _list_actions() -> List[Dict[str, Any]]:
    conn = get_db().conn
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM ids_prevention_actions ORDER BY id DESC")
    return [dict(row) for row in cursor.fetchall()]


def _list_audit() -> List[Dict[str, Any]]:
    conn = get_db().conn
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM ids_audit_log ORDER BY id DESC")
    return [dict(row) for row in cursor.fetchall()]
