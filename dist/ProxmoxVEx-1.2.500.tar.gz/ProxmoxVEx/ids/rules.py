# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/ids/rules.py
# Project:     ProxmoxVEx
# Version:     1.2.499
# Build:       2026.09.23
# Description: Rule tuning, re-evaluation and default rule set helpers
#              for the IDS/IPS module.
# Usage:       import ProxmoxVEx.ids.rules
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-23
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Rule tuning, re-evaluation and default rule set helpers for the IDS/IPS module."""

import json
import logging
from pathlib import Path
from typing import Any, Dict, List, Optional

from ProxmoxVEx.ids import engine, models

logger = logging.getLogger(__name__)

RULESET_PATH = Path(__file__).parent / "ruleset.json"


def tune_rule(rule_id: int, thresholds: Dict[str, Any]) -> bool:
    """Update a rule's anomaly_config with new sensitivity thresholds."""
    rule = models.get_rule(rule_id)
    if not rule:
        return False
    config = json.loads(rule.get("anomaly_config") or "{}") or {}
    config.update(thresholds)
    return models.update_rule(rule_id, {"anomaly_config": config})


def re_evaluate(
    segment_id: int, packets: List[Dict[str, Any]], thresholds: Optional[Dict[str, Any]] = None
) -> List[Dict[str, Any]]:
    """Re-run analysis on a packet set using the latest or supplied thresholds."""
    if not models.get_segment(segment_id):
        raise ValueError("Segment not found")
    return engine.analyze_traffic(segment_id, packets, threshold_overrides=thresholds)


def load_ruleset(path: Path = RULESET_PATH) -> Dict[str, Any]:
    """Load a JSON rule set from disk."""
    if not path.exists():
        logger.warning("IDS rule set not found: %s", path)
        return {"rules": []}
    try:
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    except (json.JSONDecodeError, OSError) as e:
        logger.error("Failed to load IDS rule set: %s", e)
        return {"rules": []}


def import_ruleset(data: Dict[str, Any], created_by: str = "system") -> int:
    """Import a rule set dict into the database, skipping rules with the same name."""
    existing = {r["name"] for r in models.list_rules(enabled_only=False)}
    count = 0
    for rule in data.get("rules", []):
        if rule.get("name") in existing:
            continue
        try:
            models.create_rule(rule, created_by)
            count += 1
        except Exception as e:
            logger.warning("Failed to import rule %s: %s", rule.get("name"), e)
    return count


def seed_default_rules(created_by: str = "system") -> int:
    """Seed the default IDS/IPS rule set if no rules exist yet."""
    if models.list_rules(enabled_only=False):
        logger.info("IDS rules already present, skipping seed")
        return 0
    ruleset = load_ruleset()
    count = import_ruleset(ruleset, created_by)
    if count:
        logger.info("Seeded %s default IDS rules", count)
    return count
