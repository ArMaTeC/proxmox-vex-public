# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/background/__init__.py
# Project:     ProxmoxVEx
# Version:     1.2.499
# Build:       2026.09.23
# Description: Package initializer for background
# Usage:       import ProxmoxVEx.background
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-23
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
import logging
import threading
import time
from concurrent.futures import ThreadPoolExecutor

from ProxmoxVEx.models.tasks import QueuedTask, register_task

log = logging.getLogger(__name__)

# ── spec 092/US084: graceful shutdown drain state ──
# SIGTERM must not cut in-flight work: mark_draining() flips readiness
# (/api/healthz -> 503 so the LB pulls the instance), the drain loop waits
# for in-flight requests inside a deadline, then checkpoints live tasks.
_DRAIN_EVENT = threading.Event()
_IN_FLIGHT_LOCK = threading.Lock()
_in_flight = 0


def mark_draining() -> None:
    _DRAIN_EVENT.set()


def clear_draining() -> None:
    """Test/admin escape hatch — production only sets, never clears."""
    _DRAIN_EVENT.clear()


def is_draining() -> bool:
    return _DRAIN_EVENT.is_set()


def request_started() -> None:
    global _in_flight
    with _IN_FLIGHT_LOCK:
        _in_flight += 1


def request_finished() -> None:
    global _in_flight
    with _IN_FLIGHT_LOCK:
        _in_flight = max(0, _in_flight - 1)


def in_flight() -> int:
    with _IN_FLIGHT_LOCK:
        return _in_flight


def checkpoint_bulk_jobs() -> None:
    """Move live bulk jobs to a terminal 'interrupted' status — nothing may
    report 'running' across the restart, since the worker thread dies with
    the process and can't transition the job itself."""
    from ProxmoxVEx.background import bulk_actions

    with bulk_actions.BULK_JOBS_LOCK:
        for job in bulk_actions.BULK_JOBS.values():
            if getattr(job, "status", "") in ("starting", "running"):
                job.set_status("interrupted")


def drain_in_flight(timeout: float = 25.0) -> None:
    """Wait for in-flight requests to finish (bounded), then checkpoint
    tasks. The bound matters: a stuck request can't hold shutdown forever —
    the orchestrator's kill grace period wins eventually."""
    deadline = time.monotonic() + timeout
    while in_flight() and time.monotonic() < deadline:
        time.sleep(0.2)
    checkpoint_bulk_jobs()


# ── spec 092/US088: active-passive HA leader lock ──
# PROXMOXVEX_HA=1 opts a deployment into the two-node pattern: both
# instances race an UPDATE...RETURNING on the single leader_lock row; the
# winner's scheduler runs jobs, the loser's idles. A dead holder's lock
# expires after the TTL and the standby takes it with a higher fence
# token, so a stale leader that wakes up late can't split-brain writes.

class _LeaderState:
    is_leader = True   # HA off = single instance = always leader
    fence = 0
    owner = ""


LEADER = _LeaderState()


def ha_enabled() -> bool:
    import os

    return os.environ.get("PROXMOXVEX_HA", "").lower() in ("1", "true", "yes")


def is_leader() -> bool:
    """Single-instance installs are always leader — the HA lock only gates
    schedulers when PROXMOXVEX_HA is explicitly enabled."""
    if not ha_enabled():
        return True
    return LEADER.is_leader


def try_acquire_leadership(db, owner: str, ttl: float = 15.0):
    """One lock attempt: take/renew the row if we own it or it expired.
    Returns the new fence token on success, None when held by a live
    peer. The atomic UPDATE...RETURNING is the whole election — no
    read-then-write race window."""
    now = time.time()
    cur = db.conn.cursor()
    cur.execute(
        "UPDATE leader_lock SET owner = ?, ts = ?, fence = fence + 1 "
        "WHERE id = 1 AND (owner = ? OR ts < ?) RETURNING fence",
        (owner, now, owner, now - ttl),
    )
    row = cur.fetchone()
    db.conn.commit()
    return row[0] if row else None


def leader_tick(db, owner: str, ttl: float = 15.0) -> None:
    """One election round for THIS instance — updates LEADER state."""
    fence = try_acquire_leadership(db, owner, ttl)
    LEADER.owner = owner
    if fence is not None:
        if not LEADER.is_leader:
            log.info("[leader] %s acquired leadership (fence=%s)", owner, fence)
        LEADER.is_leader = True
        LEADER.fence = fence
    else:
        if LEADER.is_leader:
            log.info("[leader] %s lost leadership to a peer", owner)
        LEADER.is_leader = False
        LEADER.fence = 0


def leader_loop(db=None, ttl: float = 15.0) -> None:
    """Renew-or-yield forever at ttl/3 — three attempts per TTL so one
    transient failure doesn't cost the lock."""
    import os
    import socket

    from ProxmoxVEx.core.db import get_db

    owner = f"{socket.gethostname()}:{os.getpid()}"
    LEADER.is_leader = False  # HA mode: prove it, don't assume it
    while True:
        try:
            leader_tick(db or get_db(), owner, ttl)
        except Exception as e:
            log.warning("[leader] election round failed: %s", e)
        time.sleep(ttl / 3)


def start_leader_thread(ttl: float = 15.0):
    t = threading.Thread(target=leader_loop, kwargs={"ttl": ttl}, daemon=True)
    t.start()
    return t

WORKER = ThreadPoolExecutor(max_workers=4, thread_name_prefix="async-task")


def _run_task(task: QueuedTask, fn) -> None:
    task.set_status("running")
    try:
        task.result = fn(task)
        task.set_status("succeeded")
    except Exception as e:
        task.error = str(e)
        task.set_status("failed")
        log.exception("async task %s (%s) failed", task.id, task.kind)


def enqueue(kind: str, payload: dict, owner: str, fn) -> QueuedTask:
    """Register + submit fn(task) to the worker pool. Returns the task so the
    caller can hand its id to clients for polling."""
    task = register_task(QueuedTask(kind, payload, owner))
    WORKER.submit(_run_task, task, fn)
    return task


# ---------------------------------------------------------------------------
# spec 092/US076: configurable retention sweeper for history/task/event tables.
# audit_log/metrics_history/syslog already have bespoke prunes; these growth
# tables had none and grew unbounded. Per-table retention is admin-adjustable
# via server_settings (same convention as syslog_retention_days).
# ---------------------------------------------------------------------------

# table -> (timestamp_column, server_settings key, default retention days)
RETENTION_TABLES = {
    "scheduled_task_runs": ("started_at", "retention_task_runs_days", 30),
    "migration_history": ("timestamp", "retention_migration_history_days", 90),
    "drift_events": ("detected_at", "retention_drift_events_days", 90),
    "site_recovery_events": ("started_at", "retention_sr_events_days", 90),
}

_RETENTION_MIN_DAYS = 1
_RETENTION_MAX_DAYS = 3650


def retention_sweep(db=None) -> int:
    """Delete rows older than each table's configured retention window.

    Runs daily via _periodic_retention_sweep on the alert loop. Deletes go
    through run_heavy_write so a months-old first pass doesn't stall the
    event hub — same off-hub convention as cleanup_audit_log(). Returns the
    total rows swept.
    """
    from datetime import datetime, timedelta

    from ProxmoxVEx.core.db import get_db
    from ProxmoxVEx.core.dbcrypto import run_heavy_write

    db = db or get_db()
    total = 0
    for table, (ts_col, settings_key, default_days) in RETENTION_TABLES.items():
        try:
            days = default_days
            try:
                v = db.get_server_setting(settings_key, None)
                if v is not None:
                    days = int(v)
            except Exception:
                pass
            days = max(_RETENTION_MIN_DAYS, min(_RETENTION_MAX_DAYS, days))
            cutoff = (datetime.now() - timedelta(days=days)).isoformat()
            # table/ts_col are compile-time constants from RETENTION_TABLES —
            # never request input. rowcount isn't exposed through
            # run_heavy_write, so report via a COUNT diff (indexed predicate —
            # two extra COUNTs/day per table is cheap).
            cur = db.conn.cursor()
            cur.execute(f"SELECT COUNT(*) FROM {table} WHERE {ts_col} < ?", (cutoff,))  # nosec: B608
            # fetchone() is Optional — subscripting it directly trips checkers
            # (and would TypeError on a driver returning no row)
            _row = cur.fetchone()
            before = _row[0] if _row else 0
            if not before:
                continue
            run_heavy_write(
                statements=[(f"DELETE FROM {table} WHERE {ts_col} < ?", (cutoff,))]  # nosec: B608
            )
            cur.execute(f"SELECT COUNT(*) FROM {table} WHERE {ts_col} < ?", (cutoff,))  # nosec: B608
            _row = cur.fetchone()
            swept = before - (_row[0] if _row else 0)
            total += max(swept, 0)
            log.info("retention sweep: %s swept %d row(s) (retention=%dd)", table, swept, days)
        except Exception as e:
            log.warning("retention sweep: %s failed: %s", table, e)
    return total
