# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/background/bulk_actions.py
# Project:     ProxmoxVEx
# Version:     1.2.499
# Build:       2026.09.23
# Description: Bulk VM/LXC action background worker.
# Usage:       import ProxmoxVEx.background.bulk_actions
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-23
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Bulk VM/LXC action background worker.

003-ux-bulk-selection: dispatches start/stop/restart actions to multiple
guests concurrently, tracks per-VM results, and exposes a queryable job.
"""

import logging
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed

from ProxmoxVEx.globals import cluster_managers
from ProxmoxVEx.models.tasks import BulkActionTask
from ProxmoxVEx.utils.audit import log_audit
from ProxmoxVEx.utils.realtime import broadcast_action, push_immediate_update

BULK_JOBS = {}
BULK_JOBS_LOCK = threading.Lock()

VALID_BULK_ACTIONS = ["start", "stop", "shutdown", "reboot", "reset", "suspend", "resume"]

# 853-batching-for-bulk-operations: default number of guests per batch.
BULK_BATCH_SIZE = 50
BULK_BATCH_MAX = 200

# 857-async-workers-for-bulk-operations: number of concurrent VM actions per batch.
BULK_WORKER_THREADS = 10


def start_bulk_job(cluster_id, action, guests, params, username, denied_guests=None):
    """Enqueue a new bulk job and return the task instance.

    spec 092/US016 SC-032: ``denied_guests`` are guests that failed the
    per-item permission check — they're recorded as failed items before the
    worker starts (so one denied VM never aborts the batch) while only the
    allowed ``guests`` are dispatched. The task's total covers both so
    progress/results line up with what the user submitted.
    """
    task = BulkActionTask(cluster_id, action, guests, params)
    task.total = len(guests) + len(denied_guests or [])
    for g in denied_guests or []:
        task.add_result(g["vmid"], False, error="permission denied")
    with BULK_JOBS_LOCK:
        BULK_JOBS[task.id] = task

    t = threading.Thread(
        target=_bulk_worker,
        args=(task, cluster_id, action, guests, params, username),
        daemon=True,
    )
    t.start()
    return task


def get_bulk_job(job_id):
    """Fetch a bulk job by id or None."""
    with BULK_JOBS_LOCK:
        return BULK_JOBS.get(job_id)


def _run_vm_action(manager, guest, action, force):
    """Execute a single VM action in a worker thread.

    Returns a tuple of (vmid, node, vm_type, result_or_exception).
    """
    vmid = guest.get("vmid")
    node = guest.get("node")
    vm_type = guest.get("type")
    try:
        return vmid, node, vm_type, manager.vm_action(node, vmid, vm_type, action, force=force)
    except Exception as e:
        return vmid, node, vm_type, e


def _bulk_worker(task, cluster_id, action, guests, params, username):
    """Execute the bulk action for each guest, recording per-item results."""
    task.set_status("running")
    manager = cluster_managers.get(cluster_id)
    if not manager:
        task.error = "Cluster not found"
        task.set_status("failed")
        return

    force = params.get("force", False)
    action_map = {
        "start": "vm.started",
        "stop": "vm.stopped",
        "shutdown": "vm.stopped",
        "reboot": "vm.restarted",
        "reset": "vm.restarted",
        "suspend": "vm.suspended",
        "resume": "vm.resumed",
    }

    try:
        # 853-batching-for-bulk-operations: process the guest list in bounded
        # batches so one large request does not flood the cluster manager.
        batch_size = max(1, min(int(params.get("batch_size", BULK_BATCH_SIZE)), BULK_BATCH_MAX))
        total_guests = len(guests)
        for batch_start in range(0, total_guests, batch_size):
            # spec 092/US016 FR-046: a cancel request only affects queued
            # items — the batch currently in flight runs to completion, the
            # rest are recorded as cancelled and never dispatched.
            if task.cancel_requested:
                for g in guests[batch_start:]:
                    task.add_cancelled(g["vmid"])
                break
            batch = guests[batch_start:batch_start + batch_size]
            # 857-async-workers-for-bulk-operations: run the blocking vm_action
            # calls for this batch concurrently, then apply results serially.
            with ThreadPoolExecutor(max_workers=BULK_WORKER_THREADS) as executor:
                futures = [
                    executor.submit(_run_vm_action, manager, guest, action, force)
                    for guest in batch
                ]
                for future in as_completed(futures):
                    vmid, node, vm_type, result = future.result()
                    if isinstance(result, Exception):
                        logging.error(f"[BULK-ACTION] {action} failed for {vm_type}/{vmid}: {result}", exc_info=True)
                        task.add_result(vmid, False, error=str(result))
                        continue

                    if result and result.get("success"):
                        task.add_result(vmid, True, data=result.get("data"))
                        log_audit(
                            username,
                            action_map.get(action, f"vm.{action}"),
                            f"{vm_type.upper()} {vmid} on {node} - bulk {action}" + (" (force)" if force else ""),
                            cluster=manager.config.name,
                        )
                        broadcast_action(action, vm_type, str(vmid), {"node": node, "force": force}, cluster_id, username)
                    else:
                        error_msg = (result or {}).get("error", "Unknown error")
                        task.add_result(vmid, False, error=error_msg)

        push_immediate_update(cluster_id, delay=0.5)

        # cancelled items aren't counted in failed — a job whose items were
        # all cancelled reports "cancelled"; a mix reports with_errors.
        if task.cancelled > 0 and task.completed == 0 and task.failed == 0:
            final_status = "cancelled"
        elif task.failed == 0 and task.cancelled == 0:
            final_status = "completed"
        elif task.completed == 0:
            final_status = "failed"
        else:
            final_status = "completed_with_errors"
        task.set_status(final_status)

        # (spec 092/US019 FR-053) - persist job completion to the owner's
        # notification feed. Bulk jobs run detached from the request that
        # started them, so without a durable entry the outcome was lost the
        # moment the progress modal closed. Lazy-imported: api.push pulls in
        # the blueprint layer which must not be imported at worker start.
        try:
            from ProxmoxVEx.api.push import _push_to_inbox

            sev = "info" if final_status == "completed" else "warning"
            _push_to_inbox(
                username,
                f"Bulk {action} {final_status.replace('_', ' ')}",
                f"{task.completed} succeeded, {task.failed} failed"
                + (f", {task.cancelled} cancelled" if task.cancelled else ""),
                sev,
                "/#resources",
                f"bulk-{task.id}",
            )
        except Exception as _e:
            logging.warning(f"[BULK-ACTION] inbox notification failed: {_e}")

        # (spec 092/US038) - fire task.completed to registered webhook
        # endpoints; dispatch is async, guarded so it can't break the worker.
        try:
            from ProxmoxVEx.services import webhooks

            webhooks.dispatch("task.completed", {
                "job_id": task.id, "action": action, "status": final_status,
                "total": task.total, "completed": task.completed,
                "failed": task.failed, "cancelled": task.cancelled,
                "user": username,
            })
        except Exception as _e:
            logging.warning(f"[BULK-ACTION] webhook dispatch failed: {_e}")
    except Exception as e:
        logging.error(f"[BULK-ACTION] Unhandled job error: {e}", exc_info=True)
        task.error = str(e)
        task.set_status("failed")
