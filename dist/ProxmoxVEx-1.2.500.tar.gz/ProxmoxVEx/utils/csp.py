# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/utils/csp.py
# Project:     ProxmoxVEx
# Version:     1.2.499
# Build:       2026.09.23
# Description: CSP nonce helpers.
# Usage:       import ProxmoxVEx.utils.csp
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-23
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""CSP nonce helpers.

script-src dropped 'unsafe-inline' in favour of a per-request nonce (see
app.py::add_security_headers). Documents that are allowed to run inline
<script> blocks — the injected air-gap prelude and plugin iframe HTML — get
the nonce stamped into their markup at serve time so the browser matches
element and policy. Anything injected without the nonce stays blocked.
"""

import re
import secrets

# 24 bytes -> 32 chars of URL-safe base64; comfortably inside CSP's
# base64-value grammar and unguessable per request.
_NONCE_BYTES = 24

# Matches an opening <script ...> tag that does NOT already carry a nonce
# attribute, so stamped markup is idempotent and hand-nonced tags survive.
_SCRIPT_OPEN_RE = re.compile(r"<script(?![^>]*\bnonce=)", re.IGNORECASE)

# Rocket Loader opt-out: Cloudflare's edge rewriter defers <script> tags and
# re-creates them WITHOUT the nonce attribute, so the nonce'd script-src then
# blocks the very scripts we just authorised (observed on app.proxmoxvex.com —
# both index.html boot-progress blocks never ran). data-cfasync="false" is the
# documented per-script escape hatch. A second pass is needed because
# hand-nonced tags skip the nonce pass above.
_CFASYNC_RE = re.compile(r"<script(?![^>]*\bdata-cfasync=)", re.IGNORECASE)


def generate_nonce() -> str:
    """Return a fresh cryptographically random CSP nonce."""
    return secrets.token_urlsafe(_NONCE_BYTES)


def apply_nonce_to_scripts(html: str, nonce: str) -> str:
    """Stamp ``nonce=\"<nonce>\"`` onto every <script> tag that lacks one.

    Also stamps ``data-cfasync="false"`` so Cloudflare Rocket Loader leaves
    the tags untouched — its edge rewrite drops the nonce and the CSP then
    blocks the re-created script.

    External ``src=`` scripts do not need the nonce (script-src-elem
    'self' covers them) but carrying it is harmless and keeps the markup
    valid if the source list is ever tightened. Inline blocks require it —
    without the stamp they would be blocked by the nonce'd policy.
    """
    # The gate must be case-insensitive like _SCRIPT_OPEN_RE — a plain
    # `"<script" in html` check silently skipped stamping for <SCRIPT> tags,
    # which the nonce'd policy then blocked.
    if not nonce or "<script" not in html.lower():
        return html
    html = _SCRIPT_OPEN_RE.sub(f'<script nonce="{nonce}" data-cfasync="false"', html)
    return _CFASYNC_RE.sub('<script data-cfasync="false"', html)


def nonce_meta_tag(nonce: str) -> str:
    """``<meta>`` tag the frontend reads to learn the current request's nonce."""
    return f'<meta name="csp-nonce" content="{nonce}">'
