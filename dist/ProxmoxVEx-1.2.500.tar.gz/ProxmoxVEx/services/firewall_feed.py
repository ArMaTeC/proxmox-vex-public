# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/services/firewall_feed.py
# Project:     ProxmoxVEx
# Version:     1.2.499
# Build:       2026.09.23
# Description: Polls the licensing service's internal firewall
#              blocklist.
# Usage:       import ProxmoxVEx.services.firewall_feed
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-23
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Polls the licensing service's internal firewall blocklist.

The licensing service auto-bans scanner/abuse IPs (exploit probes, bad user
agents, storms) into ``blocked_ips`` and exposes them at
``GET /v1/internal/firewall/blocklist`` — the same feed the nftables sync
timer and the landing server already consume. This module mirrors the landing
server's poller: a daemon thread refreshes the set every ``_TTL`` seconds and
``is_blocked()`` lets the request pipeline return an early 403, so attackers
reaching the app/demo surfaces through Cloudflare Tunnel are rejected even
though host-level nftables cannot see their real IPs (tunneled traffic always
arrives from the local cloudflared peer).

It also reports back: error responses (404 exploit probes, 403s, 5xx) and
blocked-IP hits are queued and POSTed to ``/v1/usage/report`` so the
licensing detector's scan-storm, bad-path and scanner-UA rules see
app/demo-surface attacks — closing the loop between detection and
enforcement across all tunneled surfaces.

Fail-open by design: when ``PROXMOXVEX_FIREWALL_KEY`` (the shared
``LICENCE_ANALYTICS_INGEST_KEY`` secret) is not configured the feed is never
fetched, nothing is reported, and every request passes — self-hosted
installs without the licensing service are unaffected. A failed refresh
keeps the last known list; reporting sheds old events when the queue fills.
"""

import ipaddress
import json
import logging
import os
import threading
import time
from urllib.parse import quote

import requests

logger = logging.getLogger(__name__)

_TTL_S = 60.0
_lock = threading.Lock()
_blocked: set[str] = set()
_started = False


def _blocklist_url() -> str:
    explicit = os.environ.get("PROXMOXVEX_FIREWALL_BLOCKLIST_URL", "").strip()
    if explicit:
        return explicit
    # Same convention as services/licensing.py — the licensing base URL with
    # the internal blocklist path appended.
    base = os.environ.get("LICENCE_SERVICE_URL", "https://licensing.proxmoxvex.com").rstrip("/")
    return f"{base}/v1/internal/firewall/blocklist"


def _ingest_url() -> str:
    explicit = os.environ.get("PROXMOXVEX_ANALYTICS_INGEST_URL", "").strip()
    if explicit:
        return explicit
    # Derive from the blocklist endpoint so one PROXMOXVEX_FIREWALL_BLOCKLIST_URL
    # override (e.g. the docker bridge IP) configures both for same-host
    # containers — mirrors the landing server's BLOCKLIST_URL derivation.
    blocklist = _blocklist_url()
    if "/v1/" in blocklist:
        return blocklist.split("/v1/", 1)[0] + "/v1/usage/report"
    return ""


def _key() -> str:
    return os.environ.get("PROXMOXVEX_FIREWALL_KEY", "").strip()


def enabled() -> bool:
    return bool(_key())


def _refresh() -> None:
    try:
        resp = requests.get(
            _blocklist_url(), headers={"X-Analytics-Key": _key()}, timeout=10
        )
        resp.raise_for_status()
        ips = resp.json().get("data", {}).get("ips", [])
        if isinstance(ips, list):
            with _lock:
                _blocked.clear()
                _blocked.update(str(ip) for ip in ips)
    except Exception as exc:  # noqa: BLE001 - enforcement must never break the app
        logger.debug("firewall blocklist refresh failed: %s", exc)


def _loop() -> None:
    while True:
        _refresh()
        time.sleep(_TTL_S)


def start() -> None:
    """Spawn the poller thread once; a no-op when the key is not configured."""
    global _started
    if _started or not enabled():
        return
    _started = True
    threading.Thread(target=_loop, daemon=True, name="firewall-feed").start()


def is_blocked(ip: str | None) -> bool:
    if not ip or not enabled():
        return False
    start()
    with _lock:
        return ip in _blocked


def client_ip(request) -> str:
    """The IP that may legitimately be blocked for this request.

    Mirrors the licensing service's ``verified_client_ip``: a public socket
    peer is authoritative (a directly-connected attacker could otherwise forge
    CDN headers to get a victim IP banned), while a private/loopback peer —
    the docker bridge gateway or the local cloudflared — means CDN headers
    describe the real client. ``X-Forwarded-For`` uses the LAST hop because
    Cloudflare appends the true client at the end (the first hop is
    client-forgeable). This is intentionally independent of
    ``PROXMOXVEX_TRUSTED_PROXIES`` so the check works in the stock container
    where that list is empty.
    """
    peer = request.remote_addr or ""
    try:
        if peer and ipaddress.ip_address(peer).is_global:
            return peer
    except ValueError:
        return peer
    cf = (request.headers.get("CF-Connecting-IP") or "").strip()
    if cf:
        return cf
    tc = (request.headers.get("True-Client-IP") or "").strip()
    if tc:
        return tc
    xff = (request.headers.get("X-Forwarded-For") or "").strip()
    if xff:
        return xff.split(",")[-1].strip()
    return peer


# ---------------------------------------------------------------------------
# Detection reporting — forward hostile-looking traffic to the licensing
# analytics ingest so its detector (bad paths, scanner UAs, 404 storms) sees
# app/demo-surface attacks too. Same plumbing as the landing server: bounded
# in-memory queue, daemon flusher, one retry, fail-open.
# ---------------------------------------------------------------------------

_QUEUE_MAX = 2000
_BATCH_MAX = 50
_FLUSH_S = 10.0
_report_lock = threading.Lock()
_report_queue: list[dict] = []
_report_thread: threading.Thread | None = None

# Crawler/scanner UA fragments for the is_bot metric flag — kept in sync with
# the landing server's list (curl/python-requests deliberately absent: our
# customers legitimately drive the API with scripts).
_BOT_UA_PARTS = (
    "bot", "spider", "crawl", "slurp", "bingpreview", "yandex", "baidu",
    "duckduckbot", "facebookexternalhit", "twitterbot", "linkedinbot",
    "whatsapp", "telegrambot", "discordbot", "ahrefs", "semrush", "mj12",
    "dotbot", "petalbot", "headless", "phantom", "lighthouse", "pingdom",
    "uptimerobot", "scraper", "sqlmap", "nuclei", "nikto", "masscan",
)


def _enqueue(event: dict) -> None:
    global _report_thread
    with _report_lock:
        if len(_report_queue) >= _QUEUE_MAX:
            _report_queue.pop(0)  # shed oldest first — never block a request
        _report_queue.append(event)
        if _report_thread is None or not _report_thread.is_alive():
            _report_thread = threading.Thread(
                target=_report_loop, daemon=True, name="firewall-report"
            )
            _report_thread.start()


def _send_batch(batch: list[dict]) -> bool:
    try:
        resp = requests.post(
            _ingest_url(),
            data=json.dumps({"events": batch}),
            headers={
                "Content-Type": "application/json",
                "X-Analytics-Key": _key(),
                "User-Agent": "proxmoxvex-app-analytics/1.0",
            },
            timeout=5,
        )
        return 200 <= resp.status_code < 300
    except Exception as exc:  # noqa: BLE001 - reporting must never break the app
        logger.debug("firewall report flush failed: %s", exc)
        return False


def _report_loop() -> None:
    while True:
        time.sleep(_FLUSH_S)
        with _report_lock:
            if not _report_queue:
                return
            batch = _report_queue[:_BATCH_MAX]
            del _report_queue[: len(batch)]
        if not _send_batch(batch):
            with _report_lock:
                _report_queue[:0] = batch
                del _report_queue[_QUEUE_MAX:]


def _geo(request) -> str:
    for header in ("CF-IPCountry", "X-Country-Code", "X-Geo-Country"):
        value = request.headers.get(header)
        if value:
            return value.strip().upper()[:80]
    return ""


def _report(request, status: int, event_type: str) -> None:
    """Queue one event for the licensing ingest — never raises, never blocks."""
    try:
        if not enabled() or not _ingest_url():
            return
        ua = request.headers.get("User-Agent", "")[:400]
        _enqueue(
            {
                "event_type": event_type,
                "source": "app",
                "path": quote(request.path or "", safe="/")[:500],
                "referrer": (request.headers.get("Referer") or "")[:500],
                "ip_address": client_ip(request)[:45],
                "country": _geo(request),
                "language": (request.headers.get("Accept-Language", "")
                             .split(",", 1)[0].split(";", 1)[0].strip().lower()[:32]),
                "user_agent": ua,
                "is_bot": bool(ua) and any(p in ua.lower() for p in _BOT_UA_PARTS),
                "meta": {"status": status},
            }
        )
    except Exception as exc:  # noqa: BLE001
        logger.debug("firewall report enqueue failed: %s", exc)


def report_blocked(request) -> None:
    """Record that a banned IP still hit us — admins see the attack continue."""
    _report(request, 403, "blocked_hit")


def report_response(request, response) -> None:
    """Report error responses and SPA-shell hits to the licensing ingest.

    Errors feed the 404-scan-storm/rate detectors. The SPA catch-all
    (``/<path:subpath>``) serves ``index.html`` with a 200 for every unmatched
    path — exploit probes like ``/wp-admin/install.php`` therefore never
    produce an error, so they are reported explicitly: the licensing
    ``evaluate_event`` checks bad-path and scanner-UA signatures regardless
    of status, and the events double as app-surface visit analytics.
    """
    try:
        # flask.g flag set by the before-request block — the early 403 was
        # already reported as blocked_hit, don't double-count it.
        from flask import g

        if getattr(g, "_fw_blocked", False):
            return
    except Exception:
        pass
    if response.status_code >= 400:
        _report(request, response.status_code, "server_hit")
        return
    try:
        rule = str(request.url_rule or "")
    except Exception:
        return
    if rule in _SPA_RULES:
        _report(request, 200, "server_hit")


# Routes that serve the SPA shell — requests resolved to these are page loads
# (or probes that would otherwise look like normal traffic).
_SPA_RULES = {"/", "/<path:subpath>"}
