# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/services/__init__.py
# Project:     ProxmoxVEx
# Version:     1.2.499
# Build:       2026.09.23
# Description: Package initializer for services
# Usage:       import ProxmoxVEx.services
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-23
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
import threading

import requests
from requests.adapters import HTTPAdapter

# (spec 092/US011) - shared pooled sessions for ad-hoc HTTP callers. Cluster
# API traffic already rides per-manager cached sessions, but module-level
# requests.get() callers (internal cluster-creds, downloads, probes) built a
# throwaway session — and a fresh TCP+TLS handshake — per call. session_for
# returns one pooled Session per origin label. pool_block=False: exceeding
# maxsize opens a transient extra connection instead of stalling a request
# behind a full pool.
_sessions = {}
_sessions_lock = threading.Lock()


def session_for(key: str) -> requests.Session:
    s = _sessions.get(key)
    if s is None:
        with _sessions_lock:
            s = _sessions.get(key)
            if s is None:
                s = requests.Session()
                adapter = HTTPAdapter(
                    pool_connections=4,
                    pool_maxsize=8,
                    max_retries=1,
                    pool_block=False,
                )
                s.mount("https://", adapter)
                s.mount("http://", adapter)
                s.headers.update({"Connection": "keep-alive"})
                _sessions[key] = s
    return s
