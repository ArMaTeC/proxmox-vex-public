# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/services/webhooks.py
# Project:     ProxmoxVEx
# Version:     1.2.499
# Build:       2026.09.23
# Description: Outbound webhooks.
# Usage:       import ProxmoxVEx.services.webhooks
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-23
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Outbound webhooks.

Endpoints are stored in proxmoxvex_kv under ``webhooks:endpoints`` as a list of
{id, url, secret, events[], enabled, created_at}. ``dispatch(event_type,
payload)`` delivers a signed POST to every enabled endpoint subscribed to the
event type — on a daemon thread by default so producers never block on a slow
consumer (``sync=True`` for tests/callers that need delivery before returning).

Signatures follow the common Stripe/GitHub convention:
``X-VEx-Signature: sha256=<hmac(body, secret)>`` plus ``X-VEx-Event`` and
``X-VEx-Timestamp`` headers.
"""

import hashlib
import hmac
import ipaddress
import json
import logging
import os
import secrets
import socket
import threading
import time
import uuid
from urllib.parse import urlsplit

log = logging.getLogger(__name__)

_KV_KEY = "webhooks:endpoints"
_MAX_ENDPOINTS = 100
_TIMEOUT = 10
_RETRY_BACKOFF = (0.5, 2.0)  # seconds between attempts 1->2 and 2->3


def _db():
    from ProxmoxVEx.core.db import get_db

    return get_db()


def _allow_private() -> bool:
    # dev/test escape hatch — loopback targets are legitimate for local
    # integrations; never set on internet-facing installs.
    return os.environ.get("PROXMOXVEX_WEBHOOK_ALLOW_PRIVATE") == "1"


def _safe_url(url: str) -> str:
    """Validate a webhook target: http(s) only, no private/loopback/link-local
    hosts — a user-supplied URL must not reach the metadata service or the LAN
    (SSRF). Returns the URL unchanged when valid, raises ValueError otherwise."""
    parts = urlsplit(url or "")
    if parts.scheme not in ("http", "https") or not parts.hostname:
        raise ValueError("webhook target must be http(s) with a hostname")
    if _allow_private():
        return url
    try:
        infos = socket.getaddrinfo(parts.hostname, None)
        ips = {info[4][0] for info in infos}
    except OSError as e:
        raise ValueError("webhook target host does not resolve") from e
    for ip in ips:
        a = ipaddress.ip_address(ip)
        if a.is_private or a.is_loopback or a.is_link_local or a.is_multicast:
            raise ValueError("webhook target not allowed")
    return url


def list_endpoints() -> list:
    try:
        return _db().get_kv(_KV_KEY, []) or []
    except Exception:
        log.exception("webhooks: list_endpoints failed")
        return []


def _save_endpoints(endpoints: list) -> None:
    _db().set_kv(_KV_KEY, endpoints)


def add_endpoint(url: str, events: list) -> dict:
    _safe_url(url)  # raises ValueError on a bad/private target
    eps = list_endpoints()
    if len(eps) >= _MAX_ENDPOINTS:
        raise ValueError("webhook endpoint limit reached")
    ep = {
        "id": uuid.uuid4().hex[:12],
        "url": url,
        "secret": secrets.token_hex(20),
        "events": list(dict.fromkeys(events)),
        "enabled": True,
        "created_at": time.time(),
    }
    eps.append(ep)
    _save_endpoints(eps)
    return ep


def delete_endpoint(ep_id: str) -> bool:
    eps = list_endpoints()
    kept = [e for e in eps if e.get("id") != ep_id]
    if len(kept) == len(eps):
        return False
    _save_endpoints(kept)
    return True


def deliver(ep: dict, event: dict, max_attempts: int = 3) -> bool:
    """POST the event to ep['url'], HMAC-signed; retries on failure. Returns
    True on the first 2xx, False after max_attempts."""
    from ProxmoxVEx.services import session_for

    body = json.dumps(event, separators=(",", ":"), default=str).encode()
    sig = hmac.new(ep["secret"].encode(), body, hashlib.sha256).hexdigest()
    headers = {
        "Content-Type": "application/json",
        "X-VEx-Event": event["type"],
        "X-VEx-Signature": f"sha256={sig}",
        "X-VEx-Timestamp": str(int(time.time())),
    }
    for attempt in range(1, max_attempts + 1):
        try:
            r = session_for("webhooks").post(ep["url"], data=body,
                                             headers=headers, timeout=_TIMEOUT)
            if r.status_code < 300:
                return True
            log.warning("webhooks: %s -> HTTP %s (attempt %d/%d)",
                        ep["url"], r.status_code, attempt, max_attempts)
        except Exception as e:
            log.warning("webhooks: %s failed: %s (attempt %d/%d)",
                        ep["url"], e, attempt, max_attempts)
        if attempt < max_attempts:
            time.sleep(_RETRY_BACKOFF[min(attempt - 1, len(_RETRY_BACKOFF) - 1)])
    return False


def dispatch(event_type: str, payload: dict, sync: bool = False) -> None:
    """Deliver `event` to every enabled endpoint subscribed to event_type.
    Async on a daemon thread unless sync=True (tests / caller needs delivery)."""
    event = {"type": event_type, "data": payload, "ts": int(time.time())}
    try:
        targets = [e for e in list_endpoints()
                   if e.get("enabled") and event_type in (e.get("events") or [])]
    except Exception:
        log.exception("webhooks: dispatch lookup failed for %s", event_type)
        return
    if not targets:
        return

    def _fanout():
        for ep in targets:
            try:
                _safe_url(ep["url"])  # re-validate at send time — DNS may move
                deliver(ep, event)
            except Exception:
                log.exception("webhooks: delivery to %s failed", ep.get("url"))

    if sync:
        _fanout()
    else:
        threading.Thread(target=_fanout, daemon=True,
                         name=f"webhook-{event_type}").start()
