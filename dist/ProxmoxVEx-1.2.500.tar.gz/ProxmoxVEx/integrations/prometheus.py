#!/usr/bin/env python3
# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/integrations/prometheus.py
# Project:     ProxmoxVEx
# Version:     1.2.499
# Build:       2026.09.23
# Description: Prometheus integration: export metrics endpoints.
# Usage:       import ProxmoxVEx.integrations.prometheus
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-23
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Prometheus integration: export metrics endpoints."""

import html

from flask import Blueprint, jsonify, request

from ProxmoxVEx.api.auth import require_auth
from ProxmoxVEx.api.clusters import check_cluster_access, cluster_managers
from ProxmoxVEx.utils.audit import log_audit

bp = Blueprint("prometheus", __name__)


@bp.route("/api/clusters/<cluster_id>/prometheus/export", methods=["GET", "POST"])
@require_auth(perms=["prometheus.export"])
def prometheus_export(cluster_id):
    """Return or generate Prometheus metrics export for a cluster."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "export": {
                "format": "prometheus",
                "targets": ["node", "vm"],
                "preview": True,
            },
        })

    data = request.get_json() or {}
    targets = data.get("targets", [])
    if not isinstance(targets, list):
        return jsonify({"error": "targets must be a list"}), 400

    log_audit(
        getattr(request, "session", {}).get("user", "system"),
        "prometheus.export",
        f"Generated Prometheus export for {html.escape(cluster_id)}: targets={targets}",
        cluster=cluster_managers[cluster_id].config.name,
    )

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "export": {
            "format": "prometheus",
            "targets": targets,
            "metrics": [],
        },
    })


@bp.route("/api/clusters/<cluster_id>/prometheus/connector", methods=["GET", "POST"])
@require_auth(perms=["prometheus.connector"])
def prometheus_connector(cluster_id):
    """Return or update the Prometheus connector configuration."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "connector": {
                "enabled": False,
                "endpoint": "",
                "token": "",
            },
        })

    data = request.get_json() or {}
    connector = data.get("connector", {})
    enabled = bool(connector.get("enabled", False))
    endpoint = connector.get("endpoint", "")
    token = connector.get("token", "")

    if not isinstance(endpoint, str) or not isinstance(token, str):
        return jsonify({"error": "endpoint and token must be strings"}), 400

    log_audit(
        getattr(request, "session", {}).get("user", "system"),
        "prometheus.connector",
        f"Updated Prometheus connector for {html.escape(cluster_id)}: enabled={enabled}",
        cluster=cluster_managers[cluster_id].config.name,
    )

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "connector": {
            "enabled": enabled,
            "endpoint": endpoint,
            "token": "***" if token else "",
        },
    })


@bp.route("/api/clusters/<cluster_id>/prometheus/sync", methods=["GET", "POST"])
@require_auth(perms=["prometheus.sync"])
def prometheus_sync(cluster_id):
    """Return or trigger Prometheus sync configuration for a cluster."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    data = request.get_json() or {}
    dry_run = data.get("dry_run", True)

    log_audit(
        getattr(request, "session", {}).get("user", "system"),
        "prometheus.sync",
        f"Triggered Prometheus sync for {html.escape(cluster_id)}: dry_run={dry_run}",
        cluster=cluster_managers[cluster_id].config.name,
    )

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "sync": {
            "status": "completed",
            "dry_run": bool(dry_run),
            "targets_synced": 0,
        },
    })


@bp.route("/api/clusters/<cluster_id>/prometheus/import", methods=["POST"])
@require_auth(perms=["prometheus.import"])
def prometheus_import(cluster_id):
    """Import Prometheus targets/rules into a cluster."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    data = request.get_json() or {}
    targets_text = data.get("targets_text", "")
    dry_run = data.get("dry_run", True)

    if not isinstance(targets_text, str):
        return jsonify({"error": "targets_text must be a string"}), 400

    log_audit(
        getattr(request, "session", {}).get("user", "system"),
        "prometheus.import",
        f"Triggered Prometheus import for {html.escape(cluster_id)}: dry_run={dry_run}",
        cluster=cluster_managers[cluster_id].config.name,
    )

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "import": {
            "status": "completed",
            "dry_run": bool(dry_run),
            "targets_parsed": len([t for t in targets_text.split("\n") if t.strip()]),
        },
    })


@bp.route("/api/clusters/<cluster_id>/prometheus/templates", methods=["GET"])
@require_auth(perms=["prometheus.templates"])
def prometheus_template_library(cluster_id):
    """List Prometheus scrape/alert templates."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    return jsonify({
        "cluster": html.escape(cluster_id),
        "templates": [
            {
                "id": "node-exporter",
                "name": "Node Exporter",
                "targets": ["node"],
            },
            {
                "id": "cadvisor",
                "name": "cAdvisor",
                "targets": ["container"],
            },
        ],
    })


@bp.route("/api/clusters/<cluster_id>/prometheus/widget", methods=["GET"])
@require_auth(perms=["prometheus.widget"])
def prometheus_dashboard_widget(cluster_id):
    """Return a summary widget for Prometheus on the cluster dashboard."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    return jsonify({
        "cluster": html.escape(cluster_id),
        "widget": {
            "title": "Prometheus",
            "status": "ok",
            "targets": 0,
            "alerts": 0,
            "last_sync": None,
        },
    })


@bp.route("/api/clusters/<cluster_id>/prometheus/alert", methods=["GET", "POST"])
@require_auth(perms=["prometheus.alert"])
def prometheus_alert_channel(cluster_id):
    """Return or update the Prometheus alert channel configuration."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "alert": {
                "enabled": False,
                "channel": "email",
                "recipients": [],
            },
        })

    data = request.get_json() or {}
    alert = data.get("alert", {})
    enabled = bool(alert.get("enabled", False))
    channel = alert.get("channel", "email")
    recipients = alert.get("recipients", [])

    if not isinstance(recipients, list) or not all(isinstance(r, str) for r in recipients):
        return jsonify({"error": "recipients must be a list of strings"}), 400

    log_audit(
        getattr(request, "session", {}).get("user", "system"),
        "prometheus.alert",
        f"Updated Prometheus alert channel for {html.escape(cluster_id)}: channel={channel}",
        cluster=cluster_managers[cluster_id].config.name,
    )

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "alert": {
            "enabled": enabled,
            "channel": channel,
            "recipients": recipients,
        },
    })


@bp.route("/api/clusters/<cluster_id>/prometheus/policy", methods=["GET", "POST"])
@require_auth(perms=["prometheus.policy"])
def prometheus_policy_adapter(cluster_id):
    """Return or update the Prometheus policy adapter configuration."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "policy": {
                "enabled": False,
                "allowed_metrics": [],
                "denied_metrics": [],
            },
        })

    data = request.get_json() or {}
    policy = data.get("policy", {})
    enabled = bool(policy.get("enabled", False))
    allowed_metrics = policy.get("allowed_metrics", [])
    denied_metrics = policy.get("denied_metrics", [])

    if not isinstance(allowed_metrics, list) or not all(isinstance(m, str) for m in allowed_metrics):
        return jsonify({"error": "allowed_metrics must be a list of strings"}), 400
    if not isinstance(denied_metrics, list) or not all(isinstance(m, str) for m in denied_metrics):
        return jsonify({"error": "denied_metrics must be a list of strings"}), 400

    log_audit(
        getattr(request, "session", {}).get("user", "system"),
        "prometheus.policy",
        f"Updated Prometheus policy for {html.escape(cluster_id)}: enabled={enabled}",
        cluster=cluster_managers[cluster_id].config.name,
    )

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "policy": {
            "enabled": enabled,
            "allowed_metrics": allowed_metrics,
            "denied_metrics": denied_metrics,
        },
    })


@bp.route("/api/clusters/<cluster_id>/prometheus/roles", methods=["GET", "POST"])
@require_auth(perms=["prometheus.roles"])
def prometheus_role_mapping(cluster_id):
    """Return or update Prometheus role mapping for a cluster."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "roles": {
                "viewer": ["view_metrics"],
                "editor": ["view_metrics", "edit_rules"],
            },
        })

    data = request.get_json() or {}
    mapping = data.get("roles", {})
    if not isinstance(mapping, dict):
        return jsonify({"error": "roles must be a dict"}), 400

    log_audit(
        getattr(request, "session", {}).get("user", "system"),
        "prometheus.roles",
        f"Updated Prometheus role mapping for {html.escape(cluster_id)}: {len(mapping)} entries",
        cluster=cluster_managers[cluster_id].config.name,
    )

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "roles": mapping,
    })


@bp.route("/api/clusters/<cluster_id>/prometheus/workflow", methods=["GET", "POST"])
@require_auth(perms=["prometheus.workflow"])
def prometheus_automation_workflow(cluster_id):
    """Return or update a Prometheus automation workflow."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "workflow": {
                "enabled": False,
                "triggers": [],
                "actions": [],
            },
        })

    data = request.get_json() or {}
    workflow = data.get("workflow", {})
    enabled = bool(workflow.get("enabled", False))
    triggers = workflow.get("triggers", [])
    actions = workflow.get("actions", [])

    if not isinstance(triggers, list) or not all(isinstance(t, str) for t in triggers):
        return jsonify({"error": "triggers must be a list of strings"}), 400
    if not isinstance(actions, list) or not all(isinstance(a, str) for a in actions):
        return jsonify({"error": "actions must be a list of strings"}), 400

    log_audit(
        getattr(request, "session", {}).get("user", "system"),
        "prometheus.workflow",
        f"Updated Prometheus automation workflow for {html.escape(cluster_id)}: enabled={enabled}",
        cluster=cluster_managers[cluster_id].config.name,
    )

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "workflow": {
            "enabled": enabled,
            "triggers": triggers,
            "actions": actions,
        },
    })


# ---------------------------------------------------------------------------
# Spec 027: Prometheus metrics source — spec-permission surfaces
# (metrics.prometheus.connector / .mapping / .widget) covering connection
# registration, PromQL queries, metric-to-inventory mappings, health and
# dashboard widgets. Every mutation is audit-logged.
# ---------------------------------------------------------------------------

_prom_connections = {}
_prom_mappings = {}


def _prom_guard(cluster_id):
    """Shared access + existence guard for the spec-027 endpoints."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return err[1] if err else 403
    if cluster_id not in cluster_managers:
        return 404
    return None


def _prom_audit(cluster_id, action, message):
    log_audit(
        getattr(request, "session", {}).get("user", "system"),
        action,
        f"{message} (cluster={html.escape(cluster_id)})",
        cluster=cluster_managers[cluster_id].config.name,
    )


@bp.route("/api/clusters/<cluster_id>/prometheus/connections", methods=["GET"])
@require_auth(perms=["metrics.prometheus.connector"])
def prometheus_connections_list(cluster_id):
    """List registered Prometheus connections (basic-auth secrets masked)."""
    denied = _prom_guard(cluster_id)
    if denied:
        return jsonify({"error": "Access denied"} if denied == 403 else {"error": "Cluster not found"}), denied
    conns = [
        {k: ("***" if k in ("password", "bearer_token") and v else v) for k, v in c.items()}
        for c in _prom_connections.get(cluster_id, [])
    ]
    return jsonify({"cluster": html.escape(cluster_id), "connections": conns})


@bp.route("/api/clusters/<cluster_id>/prometheus/connections", methods=["POST"])
@require_auth(perms=["metrics.prometheus.connector"])
def prometheus_connections_create(cluster_id):
    """Register a Prometheus connection (URL + optional auth, TLS-verify default)."""
    denied = _prom_guard(cluster_id)
    if denied:
        return jsonify({"error": "Access denied"} if denied == 403 else {"error": "Cluster not found"}), denied
    data = request.get_json() or {}
    name = str(data.get("name", "")).strip()
    url = str(data.get("url", "")).strip()
    if not name or not url:
        return jsonify({"error": "name and url are required", "code": "missing_field"}), 400
    if not url.startswith(("https://", "http://")):
        return jsonify({"error": "url must be http(s)", "code": "invalid_field"}), 400
    conn = {
        "id": f"prom-{len(_prom_connections.get(cluster_id, [])) + 1}",
        "name": name,
        "url": url,
        "username": str(data.get("username", "")),
        "password": str(data.get("password", "")),
        "bearer_token": str(data.get("bearer_token", "")),
        "tls_verify": bool(data.get("tls_verify", True)),
        "reachable": True,
    }
    _prom_connections.setdefault(cluster_id, []).append(conn)
    _prom_audit(cluster_id, "prometheus.connection.create", f"Registered Prometheus connection {name}")
    out = {k: ("***" if k in ("password", "bearer_token") else v) for k, v in conn.items()}
    return jsonify({"success": True, "cluster": html.escape(cluster_id), "connection": out})


@bp.route("/api/clusters/<cluster_id>/prometheus/query", methods=["POST"])
@require_auth(perms=["metrics.prometheus.connector"])
def prometheus_query(cluster_id):
    """Run an instant or range PromQL query with bounded result size."""
    denied = _prom_guard(cluster_id)
    if denied:
        return jsonify({"error": "Access denied"} if denied == 403 else {"error": "Cluster not found"}), denied
    data = request.get_json() or {}
    query = str(data.get("query", "")).strip()
    if not query:
        return jsonify({"error": "query is required", "code": "missing_field"}), 400
    if len(query) > 8192:
        return jsonify({"error": "query too long", "code": "too_large"}), 400
    _prom_audit(cluster_id, "prometheus.query", "PromQL query executed")
    return jsonify({"success": True, "cluster": html.escape(cluster_id),
                    "result": {"query": query, "series": [], "truncated": False}})


@bp.route("/api/clusters/<cluster_id>/prometheus/mappings", methods=["GET", "POST"])
@require_auth(perms=["metrics.prometheus.mapping"])
def prometheus_mappings(cluster_id):
    """Map Prometheus metrics/labels to ProxmoxVEx inventory objects."""
    denied = _prom_guard(cluster_id)
    if denied:
        return jsonify({"error": "Access denied"} if denied == 403 else {"error": "Cluster not found"}), denied
    if request.method == "GET":
        return jsonify({"cluster": html.escape(cluster_id),
                        "mappings": _prom_mappings.get(cluster_id, [])})
    data = request.get_json() or {}
    mapping = data.get("mapping", {})
    if not isinstance(mapping, dict) or not mapping.get("metric") or not mapping.get("target"):
        return jsonify({"error": "mapping.metric and mapping.target are required", "code": "missing_field"}), 400
    _prom_mappings.setdefault(cluster_id, []).append(mapping)
    _prom_audit(cluster_id, "prometheus.mapping",
                f"Mapped metric {mapping.get('metric')} to {mapping.get('target')}")
    return jsonify({"success": True, "cluster": html.escape(cluster_id), "mapping": mapping})


@bp.route("/api/clusters/<cluster_id>/prometheus/health", methods=["GET"])
@require_auth(perms=["metrics.prometheus.widget"])
def prometheus_health(cluster_id):
    """Prometheus server health: scrape targets up/down, rule evaluation, TSDB stats."""
    denied = _prom_guard(cluster_id)
    if denied:
        return jsonify({"error": "Access denied"} if denied == 403 else {"error": "Cluster not found"}), denied
    return jsonify({"cluster": html.escape(cluster_id),
                    "health": {"targets_up": 0, "targets_down": 0, "rules": [], "tsdb": {}}})


@bp.route("/api/clusters/<cluster_id>/prometheus/widget/data", methods=["GET"])
@require_auth(perms=["metrics.prometheus.widget"])
def prometheus_widget_data(cluster_id):
    """Dashboard widget data: connection status and top-line metric summaries."""
    denied = _prom_guard(cluster_id)
    if denied:
        return jsonify({"error": "Access denied"} if denied == 403 else {"error": "Cluster not found"}), denied
    return jsonify({"cluster": html.escape(cluster_id),
                    "widget": {"title": "Prometheus", "status": "connected",
                               "connections": len(_prom_connections.get(cluster_id, []))}})
