#!/usr/bin/env python3
# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/integrations/docker.py
# Project:     ProxmoxVEx
# Version:     1.2.499
# Build:       2026.09.23
# Description: Docker integration: export cluster state to Docker
#              assets.
# Usage:       import ProxmoxVEx.integrations.docker
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-23
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Docker integration: export cluster state to Docker assets."""

import html

from flask import Blueprint, jsonify, request

from ProxmoxVEx.api.auth import require_auth
from ProxmoxVEx.api.clusters import check_cluster_access, cluster_managers
from ProxmoxVEx.utils.audit import log_audit

bp = Blueprint("docker", __name__)


@bp.route("/api/clusters/<cluster_id>/docker/export", methods=["GET", "POST"])
@require_auth(perms=["docker.export"])
def docker_export(cluster_id):
    """Return or generate Docker export assets for a cluster."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "export": {
                "format": "compose",
                "services": ["web", "db"],
                "preview": True,
            },
        })

    data = request.get_json() or {}
    export_format = data.get("format", "compose")
    services = data.get("services", [])

    if not isinstance(services, list):
        return jsonify({"error": "services must be a list"}), 400

    if export_format not in ("compose", "stack"):
        return jsonify({"error": "format must be compose or stack"}), 400

    log_audit(
        getattr(request, "session", {}).get("user", "system"),
        "docker.export",
        f"Generated Docker export for {html.escape(cluster_id)}: format={export_format}, services={services}",
        cluster=cluster_managers[cluster_id].config.name,
    )

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "export": {
            "format": export_format,
            "services": list(services),
            "assets": [],
        },
    })


@bp.route("/api/clusters/<cluster_id>/docker/connector", methods=["GET", "POST"])
@require_auth(perms=["docker.connector"])
def docker_connector(cluster_id):
    """Return or update Docker connector configuration."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "connector": {
                "enabled": False,
                "host": "",
                "port": 2375,
                "tls": False,
                "last_test": None,
            },
        })

    data = request.get_json() or {}
    connector = data.get("connector", {})
    host = connector.get("host", "").strip()
    port = connector.get("port", 2375)
    tls = connector.get("tls", False)

    if not isinstance(port, int) or not (1 <= port <= 65535):
        return jsonify({"error": "port must be an integer between 1 and 65535"}), 400

    log_audit(
        getattr(request, "session", {}).get("user", "system"),
        "docker.connector",
        f"Updated Docker connector for {html.escape(cluster_id)}: host={host}, port={port}, tls={tls}",
        cluster=cluster_managers[cluster_id].config.name,
    )

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "connector": {
            "enabled": bool(connector.get("enabled", False)),
            "host": host,
            "port": port,
            "tls": bool(tls),
            "last_test": None,
        },
    })


@bp.route("/api/clusters/<cluster_id>/docker/sync", methods=["GET", "POST"])
@require_auth(perms=["docker.sync"])
def docker_sync(cluster_id):
    """Trigger or return Docker sync status for a cluster."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "sync": {
                "status": "idle",
                "last_sync": None,
                "containers_synced": 0,
            },
        })

    data = request.get_json() or {}
    dry_run = data.get("dry_run", True)

    log_audit(
        getattr(request, "session", {}).get("user", "system"),
        "docker.sync",
        f"Triggered Docker sync for {html.escape(cluster_id)}: dry_run={dry_run}",
        cluster=cluster_managers[cluster_id].config.name,
    )

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "sync": {
            "status": "completed",
            "dry_run": bool(dry_run),
            "containers_synced": 0,
        },
    })


@bp.route("/api/clusters/<cluster_id>/docker/import", methods=["POST"])
@require_auth(perms=["docker.import"])
def docker_import(cluster_id):
    """Import Docker containers/compose into a cluster."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    data = request.get_json() or {}
    compose_text = data.get("compose_text", "")
    dry_run = data.get("dry_run", True)

    if not isinstance(compose_text, str):
        return jsonify({"error": "compose_text must be a string"}), 400

    log_audit(
        getattr(request, "session", {}).get("user", "system"),
        "docker.import",
        f"Triggered Docker import for {html.escape(cluster_id)}: dry_run={dry_run}",
        cluster=cluster_managers[cluster_id].config.name,
    )

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "import": {
            "status": "completed",
            "dry_run": bool(dry_run),
            "services_parsed": len([s for s in compose_text.split("\n") if s.strip().startswith("  ")]),
        },
    })


@bp.route("/api/clusters/<cluster_id>/docker/templates", methods=["GET"])
@require_auth(perms=["docker.templates"])
def docker_template_library(cluster_id):
    """List Docker compose templates available for the cluster."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    return jsonify({
        "cluster": html.escape(cluster_id),
        "templates": [
            {
                "id": "web-stack",
                "name": "Web Stack",
                "services": ["web", "db", "cache"],
            },
            {
                "id": "monitoring",
                "name": "Monitoring",
                "services": ["prometheus", "grafana"],
            },
        ],
    })


@bp.route("/api/clusters/<cluster_id>/docker/widget", methods=["GET"])
@require_auth(perms=["docker.widget"])
def docker_dashboard_widget(cluster_id):
    """Return a summary widget for Docker on the cluster dashboard."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    return jsonify({
        "cluster": html.escape(cluster_id),
        "widget": {
            "title": "Docker",
            "status": "ok",
            "containers": 0,
            "images": 0,
            "last_sync": None,
        },
    })


@bp.route("/api/clusters/<cluster_id>/docker/alert", methods=["GET", "POST"])
@require_auth(perms=["docker.alert"])
def docker_alert_channel(cluster_id):
    """Return or update the Docker alert channel configuration."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "alert": {
                "enabled": False,
                "channel": "email",
                "recipients": [],
            },
        })

    data = request.get_json() or {}
    alert = data.get("alert", {})
    enabled = bool(alert.get("enabled", False))
    channel = alert.get("channel", "email")
    recipients = alert.get("recipients", [])

    if not isinstance(recipients, list) or not all(isinstance(r, str) for r in recipients):
        return jsonify({"error": "recipients must be a list of strings"}), 400

    log_audit(
        getattr(request, "session", {}).get("user", "system"),
        "docker.alert",
        f"Updated Docker alert channel for {html.escape(cluster_id)}: channel={channel}",
        cluster=cluster_managers[cluster_id].config.name,
    )

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "alert": {
            "enabled": enabled,
            "channel": channel,
            "recipients": recipients,
        },
    })


@bp.route("/api/clusters/<cluster_id>/docker/policy", methods=["GET", "POST"])
@require_auth(perms=["docker.policy"])
def docker_policy_adapter(cluster_id):
    """Return or update the Docker policy adapter configuration."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "policy": {
                "enabled": False,
                "allowed_registries": [],
                "denied_images": [],
            },
        })

    data = request.get_json() or {}
    policy = data.get("policy", {})
    enabled = bool(policy.get("enabled", False))
    allowed_registries = policy.get("allowed_registries", [])
    denied_images = policy.get("denied_images", [])

    if not isinstance(allowed_registries, list) or not all(isinstance(r, str) for r in allowed_registries):
        return jsonify({"error": "allowed_registries must be a list of strings"}), 400
    if not isinstance(denied_images, list) or not all(isinstance(i, str) for i in denied_images):
        return jsonify({"error": "denied_images must be a list of strings"}), 400

    log_audit(
        getattr(request, "session", {}).get("user", "system"),
        "docker.policy",
        f"Updated Docker policy for {html.escape(cluster_id)}: enabled={enabled}",
        cluster=cluster_managers[cluster_id].config.name,
    )

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "policy": {
            "enabled": enabled,
            "allowed_registries": allowed_registries,
            "denied_images": denied_images,
        },
    })


@bp.route("/api/clusters/<cluster_id>/docker/roles", methods=["GET", "POST"])
@require_auth(perms=["docker.roles"])
def docker_role_mapping(cluster_id):
    """Return or update Docker role-to-user mapping."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "roles": [
                {"docker_role": "admin", "proxmox_role": "PVEAdmin"},
                {"docker_role": "viewer", "proxmox_role": "PVEAuditor"},
            ],
        })

    data = request.get_json() or {}
    mapping = data.get("mapping", [])

    if not isinstance(mapping, list):
        return jsonify({"error": "mapping must be a list"}), 400

    for item in mapping:
        if (
            not isinstance(item, dict)
            or not isinstance(item.get("docker_role"), str)
            or not isinstance(item.get("proxmox_role"), str)
        ):
            return jsonify({"error": "each mapping must have docker_role and proxmox_role strings"}), 400

    log_audit(
        getattr(request, "session", {}).get("user", "system"),
        "docker.roles",
        f"Updated Docker role mapping for {html.escape(cluster_id)}: {len(mapping)} entries",
        cluster=cluster_managers[cluster_id].config.name,
    )

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "roles": mapping,
    })


@bp.route("/api/clusters/<cluster_id>/docker/workflow", methods=["GET", "POST"])
@require_auth(perms=["docker.workflow"])
def docker_automation_workflow(cluster_id):
    """Return or update a Docker automation workflow."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "workflow": {
                "enabled": False,
                "triggers": [],
                "actions": [],
            },
        })

    data = request.get_json() or {}
    workflow = data.get("workflow", {})
    enabled = bool(workflow.get("enabled", False))
    triggers = workflow.get("triggers", [])
    actions = workflow.get("actions", [])

    if not isinstance(triggers, list) or not all(isinstance(t, str) for t in triggers):
        return jsonify({"error": "triggers must be a list of strings"}), 400
    if not isinstance(actions, list) or not all(isinstance(a, str) for a in actions):
        return jsonify({"error": "actions must be a list of strings"}), 400

    log_audit(
        getattr(request, "session", {}).get("user", "system"),
        "docker.workflow",
        f"Updated Docker automation workflow for {html.escape(cluster_id)}: enabled={enabled}",
        cluster=cluster_managers[cluster_id].config.name,
    )

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "workflow": {
            "enabled": enabled,
            "triggers": triggers,
            "actions": actions,
        },
    })
