#!/usr/bin/env python3
# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/integrations/kubernetes.py
# Project:     ProxmoxVEx
# Version:     1.2.499
# Build:       2026.09.23
# Description: Kubernetes integration for ProxmoxVEx.
# Usage:       import ProxmoxVEx.integrations.kubernetes
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-23
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Kubernetes integration for ProxmoxVEx.

Connects to existing Kubernetes clusters, persists connector configuration with
encrypted credentials, and exposes export, import, inventory, sync, node mapping,
alert forwarding, policy adapters, role mapping, templates and workflows.
"""

from __future__ import annotations

import html
import ipaddress
import json
import logging
import os
import re
import tempfile
from datetime import UTC, datetime
from typing import Any, cast
from urllib.parse import urlparse

import yaml
from flask import Blueprint, jsonify, request

from ProxmoxVEx.api.auth import require_auth
from ProxmoxVEx.api.clusters import check_cluster_access, cluster_managers
from ProxmoxVEx.integrations import kubernetes_db as kdb
from ProxmoxVEx.models.permissions import ROLE_ADMIN
from ProxmoxVEx.utils.audit import log_audit

bp = Blueprint("kubernetes", __name__)

_logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

ALLOWED_KINDS = {
    "Namespace",
    "Node",
    "Pod",
    "Deployment",
    "ReplicaSet",
    "StatefulSet",
    "DaemonSet",
    "Service",
    "Ingress",
    "ConfigMap",
    "Secret",
    "PersistentVolume",
    "PersistentVolumeClaim",
    "ServiceAccount",
    "Role",
    "ClusterRole",
    "RoleBinding",
    "ClusterRoleBinding",
    "Job",
    "CronJob",
}

NAMESPACED_KINDS = {
    "Pod",
    "Deployment",
    "ReplicaSet",
    "StatefulSet",
    "DaemonSet",
    "Service",
    "Ingress",
    "ConfigMap",
    "Secret",
    "PersistentVolumeClaim",
    "ServiceAccount",
    "Role",
    "RoleBinding",
    "Job",
    "CronJob",
}

CLUSTER_SCOPED_KINDS = ALLOWED_KINDS - NAMESPACED_KINDS

SYNC_KINDS = [
    "Node",
    "Namespace",
    "Pod",
    "Deployment",
    "Service",
    "ConfigMap",
    "Secret",
    "StatefulSet",
    "DaemonSet",
]

DEFAULT_EXPORT_KINDS = ["Deployment", "Service", "ConfigMap"]

MAX_MANIFEST_SIZE = 1024 * 1024
MAX_MANIFEST_DOCS = 50
CACHE_TTL_SECONDS = 300

# (api_class, list_all_namespaces_method, list_namespaced_method)
KIND_API_MAP: dict[str, tuple[str, str | None, str | None]] = {
    "Namespace": ("CoreV1Api", "list_namespace", None),
    "Node": ("CoreV1Api", "list_node", None),
    "Pod": ("CoreV1Api", "list_pod_for_all_namespaces", "list_namespaced_pod"),
    "Deployment": ("AppsV1Api", "list_deployment_for_all_namespaces", "list_namespaced_deployment"),
    "ReplicaSet": ("AppsV1Api", "list_replica_set_for_all_namespaces", "list_namespaced_replica_set"),
    "StatefulSet": ("AppsV1Api", "list_stateful_set_for_all_namespaces", "list_namespaced_stateful_set"),
    "DaemonSet": ("AppsV1Api", "list_daemon_set_for_all_namespaces", "list_namespaced_daemon_set"),
    "Service": ("CoreV1Api", "list_service_for_all_namespaces", "list_namespaced_service"),
    "ConfigMap": ("CoreV1Api", "list_config_map_for_all_namespaces", "list_namespaced_config_map"),
    "Secret": ("CoreV1Api", "list_secret_for_all_namespaces", "list_namespaced_secret"),
    "PersistentVolumeClaim": ("CoreV1Api", "list_persistent_volume_claim_for_all_namespaces", "list_namespaced_persistent_volume_claim"),
    "PersistentVolume": ("CoreV1Api", "list_persistent_volume", None),
    "ServiceAccount": ("CoreV1Api", "list_service_account_for_all_namespaces", "list_namespaced_service_account"),
    "Ingress": ("NetworkingV1Api", "list_ingress_for_all_namespaces", "list_namespaced_ingress"),
    "Role": ("RbacAuthorizationV1Api", "list_role_for_all_namespaces", "list_namespaced_role"),
    "RoleBinding": ("RbacAuthorizationV1Api", "list_role_binding_for_all_namespaces", "list_namespaced_role_binding"),
    "ClusterRole": ("RbacAuthorizationV1Api", "list_cluster_role", None),
    "ClusterRoleBinding": ("RbacAuthorizationV1Api", "list_cluster_role_binding", None),
    "Job": ("BatchV1Api", "list_job_for_all_namespaces", "list_namespaced_job"),
    "CronJob": ("BatchV1Api", "list_cron_job_for_all_namespaces", "list_namespaced_cron_job"),
}

KIND_READ_MAP: dict[str, tuple[str, str, str | None]] = {
    "Namespace": ("CoreV1Api", "read_namespace", None),
    "Node": ("CoreV1Api", "read_node", None),
    "Pod": ("CoreV1Api", "read_namespaced_pod", None),
    "Deployment": ("AppsV1Api", "read_namespaced_deployment", None),
    "ReplicaSet": ("AppsV1Api", "read_namespaced_replica_set", None),
    "StatefulSet": ("AppsV1Api", "read_namespaced_stateful_set", None),
    "DaemonSet": ("AppsV1Api", "read_namespaced_daemon_set", None),
    "Service": ("CoreV1Api", "read_namespaced_service", None),
    "ConfigMap": ("CoreV1Api", "read_namespaced_config_map", None),
    "Secret": ("CoreV1Api", "read_namespaced_secret", None),
    "PersistentVolumeClaim": ("CoreV1Api", "read_namespaced_persistent_volume_claim", None),
    "PersistentVolume": ("CoreV1Api", "read_persistent_volume", None),
    "ServiceAccount": ("CoreV1Api", "read_namespaced_service_account", None),
    "Ingress": ("NetworkingV1Api", "read_namespaced_ingress", None),
    "Role": ("RbacAuthorizationV1Api", "read_namespaced_role", None),
    "RoleBinding": ("RbacAuthorizationV1Api", "read_namespaced_role_binding", None),
    "ClusterRole": ("RbacAuthorizationV1Api", "read_cluster_role", None),
    "ClusterRoleBinding": ("RbacAuthorizationV1Api", "read_cluster_role_binding", None),
    "Job": ("BatchV1Api", "read_namespaced_job", None),
    "CronJob": ("BatchV1Api", "read_namespaced_cron_job", None),
}


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _cluster_name(cluster_id: str) -> str:
    try:
        return cluster_managers[cluster_id].config.name
    except Exception:
        return cluster_id


def _is_metadata_or_loopback(host: str) -> bool:
    """Return True for hosts that are unsafe as Kubernetes API targets."""
    if not host:
        return True
    h = host.lower()
    if h in ("localhost", "metadata", "metadata.google.internal", "169.254.169.254", "127.0.0.1", "::1", "0.0.0.0"):
        return True
    if h.startswith("metadata."):
        return True
    try:
        ip = ipaddress.ip_address(host)
        if ip.is_loopback or ip.is_link_local or ip.is_multicast or ip.is_unspecified:
            return True
    except ValueError:
        pass
    return False


def _is_safe_api_url(api_url: str) -> tuple[bool, str]:
    """Validate a user-supplied Kubernetes API URL and prevent SSRF."""
    try:
        parsed = urlparse(api_url)
    except Exception:
        return False, "Invalid URL"
    if parsed.scheme != "https":
        return False, "Only HTTPS URLs are allowed"
    if not parsed.hostname:
        return False, "URL must include a host"
    if parsed.username or parsed.password:
        return False, "URL must not contain credentials"
    if _is_metadata_or_loopback(parsed.hostname):
        return False, "URL host is not allowed"
    return True, ""


def _redact_secret(value: str) -> str:
    if not value:
        return ""
    return "*" * min(len(value), 32)


def _is_admin() -> bool:
    session = request.session  # type: ignore[attr-defined]
    return bool(session.get("role") == ROLE_ADMIN or ROLE_ADMIN in session.get("permissions", []))


def _get_k8s_cluster(cluster_id: str, missing_status: int = 404) -> tuple[dict[str, Any] | None, Any]:
    """Return the Kubernetes connector record or an HTTP error response."""
    record = kdb.get_k8s_cluster(cluster_id)
    if not record:
        return None, (jsonify({"error": "Kubernetes connector not configured"}), missing_status)
    return record, None


def _k8s_id(record: dict[str, Any]) -> str:
    return record["id"]


def _default_namespace(record: dict[str, Any]) -> str:
    return record.get("namespace_default") or "default"


def _get_client(record: dict[str, Any]) -> tuple[Any, str]:
    """Build an ``ApiClient`` from a connector record.

    Returns ``(client, error_message)``.
    """
    import kubernetes.client as kc
    import kubernetes.config as kconfig

    api_url = record["api_url"]
    verify_ssl = record["verify_ssl"]
    auth_type = record["auth_type"]

    plaintext = kdb.decrypt_auth_blob(record["cluster_id"])

    if auth_type == "token":
        config = kc.Configuration(host=api_url)
        config.verify_ssl = bool(verify_ssl)
        config.api_key = {"authorization": plaintext}
        config.api_key_prefix = {"authorization": "Bearer"}
        cast(Any, config).retries = 2
        return kc.ApiClient(config), ""

    if auth_type == "kubeconfig":
        try:
            kubeconfig = yaml.safe_load(plaintext)
            if not isinstance(kubeconfig, dict):
                return None, "Invalid kubeconfig: YAML did not decode to a mapping"
            client = kconfig.new_client_from_config_dict(config_dict=kubeconfig)
            if hasattr(client, "configuration") and client.configuration is not None:
                client.configuration.verify_ssl = bool(verify_ssl)
            return client, ""
        except Exception as exc:
            _logger.warning("Failed to build kubeconfig client: %s", exc)
            return None, f"Failed to load kubeconfig: {type(exc).__name__}"

    if auth_type == "certificate":
        try:
            data = json.loads(plaintext)
            cert_pem = data.get("client_cert", "")
            key_pem = data.get("client_key", "")
            ca_pem = data.get("ca_cert", "")
        except Exception:
            return None, "Certificate auth_blob must be a JSON object with client_cert and client_key"
        if not cert_pem or not key_pem:
            return None, "client_cert and client_key are required for certificate authentication"

        fd, cert_path = tempfile.mkstemp(prefix="k8s-cert-", suffix=".pem")
        with os.fdopen(fd, "w") as f:
            f.write(cert_pem)
        fd, key_path = tempfile.mkstemp(prefix="k8s-key-", suffix=".pem")
        with os.fdopen(fd, "w") as f:
            f.write(key_pem)
        ca_path = None
        if ca_pem:
            fd, ca_path = tempfile.mkstemp(prefix="k8s-ca-", suffix=".pem")
            with os.fdopen(fd, "w") as f:
                f.write(ca_pem)

        # cert_file/key_file are runtime kwargs in the client; stubs only expose them as attrs
        config = kc.Configuration(host=api_url)
        cast(Any, config).cert_file = cert_path
        cast(Any, config).key_file = key_path
        if ca_path:
            config.ssl_ca_cert = ca_path
        config.verify_ssl = bool(verify_ssl)
        return kc.ApiClient(config), ""

    return None, f"Unsupported auth_type: {auth_type}"


def _test_connection(record: dict[str, Any]) -> tuple[str, str]:
    """Return ``(status, message)`` after a lightweight Kubernetes API probe."""
    safe, msg = _is_safe_api_url(record["api_url"])
    if not safe:
        return "unreachable", msg

    client, err = _get_client(record)
    if not client:
        return "unreachable", err

    import kubernetes.client as kc

    try:
        v1 = kc.CoreV1Api(client)
        # list_namespace is a small, read-only operation that exercises auth.
        resp: Any = v1.list_namespace(_preload_content=False)
        if resp and resp.status == 200:
            return "reachable", "Connection successful"
        return "degraded", f"Unexpected HTTP status: {resp.status if resp else 'unknown'}"
    except kc.ApiException as exc:
        if exc.status == 401:
            return "unreachable", "Authentication failed (401)"
        if exc.status == 403:
            return "degraded", "Connected, but token lacks namespace list permission (403)"
        if (exc.status or 0) >= 500:
            return "degraded", f"Kubernetes API server error: {exc.status}"
        return "unreachable", f"Kubernetes API error: {exc.status}"
    except Exception as exc:
        _logger.warning("Kubernetes health check failed: %s", exc)
        return "unreachable", f"Connection failed: {type(exc).__name__}"


def _call_api_method(client: Any, api_class_name: str, method_name: str, **kwargs: Any) -> Any:
    import kubernetes.client as kc
    api_class = getattr(kc, api_class_name)
    api = api_class(client)
    method = getattr(api, method_name)
    return method(**kwargs)


def _list_resources_raw(client: Any, kind: str, namespace: str | None = None) -> list[dict[str, Any]]:
    """List resources by kind and return raw JSON ``items``."""
    import kubernetes.client as kc

    mapping = KIND_API_MAP.get(kind)
    if not mapping:
        raise ValueError(f"Unsupported kind: {kind}")
    api_class_name, all_method, ns_method = mapping

    try:
        if namespace:
            if not ns_method:
                raise ValueError(f"{kind} is not namespaced")
            resp = _call_api_method(client, api_class_name, ns_method, namespace=namespace, _preload_content=False)
        elif kind in CLUSTER_SCOPED_KINDS or not all_method:
            method = ns_method or all_method
            if not method:
                raise ValueError(f"{kind} has no list method")
            resp = _call_api_method(client, api_class_name, method, _preload_content=False)
        else:
            resp = _call_api_method(client, api_class_name, all_method, _preload_content=False)
        if not resp or not resp.data:
            return []
        return json.loads(resp.data.decode("utf-8")).get("items", [])
    except kc.ApiException as exc:
        if exc.status == 404:
            return []
        raise


def _read_resource_raw(client: Any, kind: str, namespace: str | None, name: str) -> dict[str, Any] | None:
    """Read a single resource and return raw JSON."""
    import kubernetes.client as kc

    mapping = KIND_READ_MAP.get(kind)
    if not mapping:
        raise ValueError(f"Unsupported kind: {kind}")
    api_class_name, method_name, _ = mapping
    kwargs: dict[str, Any] = {"name": name, "_preload_content": False}
    if kind in NAMESPACED_KINDS and namespace:
        kwargs["namespace"] = namespace
    try:
        resp = _call_api_method(client, api_class_name, method_name, **kwargs)
        if not resp or not resp.data:
            return None
        return json.loads(resp.data.decode("utf-8"))
    except kc.ApiException as exc:
        if exc.status == 404:
            return None
        raise


def _sanitize_export_manifest(obj: dict[str, Any]) -> dict[str, Any]:
    """Strip server-managed fields and redact secrets from an exported manifest."""
    if not isinstance(obj, dict):
        return obj

    if obj.get("kind") == "Secret":
        obj["data"] = {}
        obj.pop("stringData", None)

    metadata = obj.get("metadata", {})
    if isinstance(metadata, dict):
        for key in ["uid", "resourceVersion", "selfLink", "creationTimestamp", "managedFields", "generation"]:
            metadata.pop(key, None)
        annotations = metadata.get("annotations")
        if isinstance(annotations, dict):
            annotations.pop("kubectl.kubernetes.io/last-applied-configuration", None)

    obj.pop("status", None)
    return obj


def _resource_summary(item: dict[str, Any]) -> dict[str, Any]:
    """Build a short metadata summary for the resource cache and inventory list."""
    metadata = item.get("metadata", {}) or {}
    kind = item.get("kind", "")
    name = metadata.get("name", "")
    namespace = metadata.get("namespace")
    uid = metadata.get("uid", "")
    labels = metadata.get("labels", {}) or {}
    annotations = metadata.get("annotations", {}) or {}
    status = item.get("status", {}) or {}
    if kind == "Secret":
        status = {}
    return {
        "kind": kind,
        "name": name,
        "namespace": namespace,
        "uid": uid,
        "labels": labels,
        "annotations": annotations,
        "status": status,
    }


def _cache_resources(record: dict[str, Any], items: list[dict[str, Any]]) -> None:
    """Write raw resource JSON into the short-TTL cache."""
    k8s_id = _k8s_id(record)
    for item in items:
        metadata = item.get("metadata", {}) or {}
        kind = item.get("kind", "")
        name = metadata.get("name", "")
        namespace = metadata.get("namespace")
        if not kind or not name:
            continue
        summary = _resource_summary(item)
        kdb.upsert_k8s_resource(k8s_id, kind, namespace, name, summary)


def _sync_resources(record: dict[str, Any], kinds: list[str] | None = None) -> dict[str, int]:
    """Discover selected resources and write them to the cache."""
    client, err = _get_client(record)
    if not client:
        raise RuntimeError(err)

    k8s_id = _k8s_id(record)
    # Prune stale entries before refreshing.
    kdb.prune_k8s_resource_cache(k8s_id, max_age_seconds=CACHE_TTL_SECONDS)

    kinds = kinds or SYNC_KINDS
    counts: dict[str, int] = {}
    for kind in kinds:
        try:
            items = _list_resources_raw(client, kind)
            _cache_resources(record, items)
            counts[kind] = len(items)
        except Exception as exc:
            _logger.warning("Failed to sync %s for %s: %s", kind, k8s_id, exc)
            counts[kind] = 0
    return counts


def _live_counts(record: dict[str, Any]) -> tuple[dict[str, int], str, str]:
    """Return widget counts, status and a short message.

    Tries the live API first, then falls back to the cache for counts.
    """
    client, err = _get_client(record)
    counts = {"pods": 0, "services": 0, "deployments": 0, "nodes": 0}
    if client:
        try:
            for kind, key in [("Pod", "pods"), ("Service", "services"), ("Deployment", "deployments"), ("Node", "nodes")]:
                items = _list_resources_raw(client, kind)
                counts[key] = len(items)
            return counts, record.get("status", "unknown"), ""
        except Exception as exc:
            _logger.warning("Live widget counts failed for %s: %s", record["cluster_id"], exc)

    # Fallback to cache.
    k8s_id = _k8s_id(record)
    cached = kdb.list_k8s_resource_cache(k8s_id)
    kind_map = {"Pod": "pods", "Service": "services", "Deployment": "deployments", "Node": "nodes"}
    for row in cached:
        mapped = kind_map.get(row["kind"])
        if mapped:
            counts[mapped] += 1
    return counts, record.get("status", "unknown") or "unknown", err or ""


def _is_valid_cron(expr: str) -> bool:
    """Accept a 5-field cron expression or common @ shortcuts."""
    if expr.startswith("@"):
        return expr in ("@yearly", "@annually", "@monthly", "@weekly", "@daily", "@hourly")
    parts = expr.split()
    if len(parts) != 5:
        return False
    field_re = re.compile(r"^[\*0-9a-zA-Z,/-?LW#]+$")
    return all(field_re.match(part) for part in parts)


def _mask_connector(record: dict[str, Any]) -> dict[str, Any]:
    """Return a connector payload safe for API responses (secrets redacted)."""
    return {
        "id": record["id"],
        "cluster_id": record["cluster_id"],
        "name": record.get("name", record["cluster_id"]),
        "api_url": record["api_url"],
        "auth_type": record["auth_type"],
        "namespace_default": record.get("namespace_default", "default"),
        "verify_ssl": bool(record.get("verify_ssl", True)),
        "enabled": bool(record.get("enabled", True)),
        "status": record.get("status", "pending"),
        "last_health_check": record.get("last_health_check"),
        "health_message": record.get("health_message"),
    }


def _validate_manifest_docs(docs: list[Any], allow_cluster_scoped: bool = False) -> tuple[bool, str]:
    if len(docs) > MAX_MANIFEST_DOCS:
        return False, f"Too many documents (max {MAX_MANIFEST_DOCS})"
    dns_re = re.compile(r"^[a-z0-9]([-a-z0-9]*[a-z0-9])?$")
    for doc in docs:
        if not isinstance(doc, dict):
            return False, "Each manifest document must be a YAML/JSON mapping"
        if not all(k in doc for k in ("apiVersion", "kind", "metadata")):
            return False, "Each document must have apiVersion, kind, and metadata"
        kind = doc["kind"]
        if kind not in ALLOWED_KINDS:
            return False, f"Kind {kind} is not allowed"
        if kind in CLUSTER_SCOPED_KINDS and not allow_cluster_scoped:
            return False, f"Cluster-scoped kind {kind} requires allow_cluster_scoped=true"
        metadata = doc.get("metadata", {})
        if not isinstance(metadata, dict):
            return False, "metadata must be a mapping"
        name = metadata.get("name", "")
        if not dns_re.match(name) or len(name) > 253:
            return False, "metadata.name must be a valid DNS subdomain name"
        if "status" in doc:
            return False, "status field is prohibited in manifests"
        annotations = metadata.get("annotations", {})
        if isinstance(annotations, dict) and "kubectl.kubernetes.io/last-applied-configuration" in annotations:
            return False, "last-applied-configuration annotation is prohibited"
    return True, ""


def _apply_doc(dyn_client: Any, doc: dict[str, Any], namespace: str) -> str:
    """Apply a single manifest document using server-side apply when possible."""
    import kubernetes.client as kc

    api_version = doc.get("apiVersion")
    kind = doc.get("kind")
    name = doc.get("metadata", {}).get("name")
    manifest_ns = doc.get("metadata", {}).get("namespace")
    target_ns = namespace or manifest_ns or "default"

    try:
        resource = dyn_client.resources.get(api_version=api_version, kind=kind)
    except Exception as exc:
        raise RuntimeError(f"Unsupported resource {api_version}/{kind}: {exc}") from exc

    body = dict(doc)
    if kind in NAMESPACED_KINDS:
        body.setdefault("metadata", {})["namespace"] = target_ns

    try:
        if kind in NAMESPACED_KINDS:
            resource.server_side_apply(body=body, name=name, namespace=target_ns, field_manager="proxmoxvex")
        else:
            resource.server_side_apply(body=body, name=name, field_manager="proxmoxvex")
        return f"{kind}/{name} applied"
    except (kc.ApiException, Exception) as ssa_exc:
        # Fallback to create if server-side apply is unavailable.
        _logger.debug("server_side_apply failed, trying create: %s", ssa_exc)
        try:
            if kind in NAMESPACED_KINDS:
                resource.create(body=body, namespace=target_ns)
            else:
                resource.create(body=body)
            return f"{kind}/{name} created"
        except kc.ApiException as create_exc:
            if getattr(create_exc, "status", None) == 409:
                return f"{kind}/{name} already exists"
            raise


def _apply_manifest(record: dict[str, Any], docs: list[dict[str, Any]], namespace: str, allow_cluster_scoped: bool) -> tuple[list[str], str | None]:
    from kubernetes import dynamic

    client, err = _get_client(record)
    if not client:
        return [], err

    dyn_client = dynamic.DynamicClient(client)
    results: list[str] = []
    default_ns = namespace or _default_namespace(record)

    for doc in docs:
        kind = doc.get("kind")
        if kind in CLUSTER_SCOPED_KINDS and not allow_cluster_scoped:
            continue
        try:
            results.append(_apply_doc(dyn_client, doc, default_ns))
        except Exception as exc:
            _logger.warning("Failed to apply manifest doc: %s", exc)
            return results, f"Failed to apply {kind}: {type(exc).__name__}"
    return results, None


def _format_export_manifests(items: list[dict[str, Any]], fmt: str) -> Any:
    manifests = [_sanitize_export_manifest(item) for item in items]
    if fmt == "json":
        return manifests
    return yaml.safe_dump_all(manifests, sort_keys=False)


def _extract_export_items(record: dict[str, Any], kinds: list[str], namespace: str | None) -> list[dict[str, Any]]:
    client, err = _get_client(record)
    if not client:
        raise RuntimeError(err)
    items: list[dict[str, Any]] = []
    for kind in kinds:
        items.extend(_list_resources_raw(client, kind, namespace=namespace))
    return items


def _audit(action: str, cluster_id: str, details: str, include_cluster_name: bool = True) -> None:
    log_audit(
        request.session.get("user", "system"),  # type: ignore[attr-defined]
        action,
        details,
        cluster=_cluster_name(cluster_id) if include_cluster_name else None,
    )


def _send_alert(webhook_url: str, payload: dict[str, Any]) -> None:
    """Forward a JSON payload to a configured alert webhook."""
    try:
        import requests
        requests.post(webhook_url, json=payload, timeout=10)
    except Exception as exc:
        _logger.warning("Failed to forward Kubernetes alert to %s: %s", webhook_url, exc)


# ---------------------------------------------------------------------------
# Connector
# ---------------------------------------------------------------------------


@bp.route("/api/clusters/<cluster_id>/kubernetes/connector", methods=["GET", "POST"])
@require_auth(perms=["kubernetes.connector"])
def kubernetes_connector(cluster_id: str) -> Any:
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    record, error_resp = _get_k8s_cluster(cluster_id, missing_status=200)
    if error_resp:
        if request.method == "GET":
            return jsonify({
                "cluster": html.escape(cluster_id),
                "connector": _mask_connector({
                    "id": "", "cluster_id": cluster_id, "name": cluster_id,
                    "api_url": "", "auth_type": "token", "namespace_default": "default",
                    "verify_ssl": True, "enabled": False, "status": "pending",
                    "last_health_check": None, "health_message": None,
                }),
            })
        # POST below will create the record.
        record = None

    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "connector": _mask_connector(record) if record else _mask_connector({
                "id": "", "cluster_id": cluster_id, "name": cluster_id,
                "api_url": "", "auth_type": "token", "namespace_default": "default",
                "verify_ssl": True, "enabled": False, "status": "pending",
                "last_health_check": None, "health_message": None,
            }),
        })

    data = request.get_json() or {}
    connector = data.get("connector", {})
    api_url = (connector.get("api_url") or "").strip()
    namespace = (connector.get("namespace") or connector.get("namespace_default") or "default").strip()
    verify_ssl = bool(connector.get("verify_ssl", True))
    enabled = bool(connector.get("enabled", True))

    safe, msg = _is_safe_api_url(api_url)
    if not safe:
        return jsonify({"error": msg}), 400

    if not verify_ssl and not _is_admin():
        return jsonify({"error": "Disabling TLS verification requires admin privileges"}), 403

    # Determine authentication material and auth_type.
    token = connector.get("token", "").strip()
    kubeconfig = connector.get("kubeconfig", "").strip()
    client_cert = connector.get("client_cert", "").strip()
    client_key = connector.get("client_key", "").strip()
    ca_cert = connector.get("ca_cert", "").strip()

    if connector.get("auth_type"):
        auth_type = connector["auth_type"]
    elif kubeconfig:
        auth_type = "kubeconfig"
    elif client_cert and client_key:
        auth_type = "certificate"
    else:
        auth_type = "token"

    if auth_type == "token" and not token:
        return jsonify({"error": "token is required for token authentication"}), 400
    if auth_type == "kubeconfig" and not kubeconfig:
        return jsonify({"error": "kubeconfig is required for kubeconfig authentication"}), 400
    if auth_type == "certificate" and (not client_cert or not client_key):
        return jsonify({"error": "client_cert and client_key are required for certificate authentication"}), 400

    if auth_type == "token":
        auth_plaintext = token
    elif auth_type == "kubeconfig":
        auth_plaintext = kubeconfig
    else:
        auth_plaintext = json.dumps({"client_cert": client_cert, "client_key": client_key, "ca_cert": ca_cert})

    name = (connector.get("name") or cluster_id).strip()
    save_data = {
        "name": name,
        "api_url": api_url,
        "auth_type": auth_type,
        "auth_blob_plaintext": auth_plaintext,
        "namespace_default": namespace,
        "verify_ssl": verify_ssl,
        "enabled": enabled,
        "status": "pending",
    }
    kdb.save_k8s_cluster(cluster_id, save_data)

    # Test the connection and update status.
    record = kdb.get_k8s_cluster(cluster_id)
    if record:
        status, message = _test_connection(record)
        kdb.update_k8s_cluster_status(cluster_id, status, message)
        record = kdb.get_k8s_cluster(cluster_id)

    _audit(
        "kubernetes.connector",
        cluster_id,
        f"Updated Kubernetes connector for {html.escape(cluster_id)}: auth_type={auth_type}, namespace={namespace}, verify_ssl={verify_ssl}, enabled={enabled}",
    )

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "connector": _mask_connector(record) if record else _mask_connector(save_data),
    })


# ---------------------------------------------------------------------------
# Inventory
# ---------------------------------------------------------------------------


@bp.route("/api/clusters/<cluster_id>/kubernetes/inventory", methods=["GET"])
@require_auth(perms=["kubernetes.widget"])
def kubernetes_inventory(cluster_id: str) -> Any:
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    record, error_resp = _get_k8s_cluster(cluster_id)
    if not record:
        return error_resp

    kind = request.args.get("kind")
    namespace = request.args.get("namespace")
    page = request.args.get("page", "1")
    limit = request.args.get("limit", "50")
    try:
        page_i = max(1, int(page))
        limit_i = max(1, min(500, int(limit)))
    except ValueError:
        return jsonify({"error": "Invalid pagination"}), 400

    # Prefer the short-TTL cache; fallback to live query if cache is empty.
    k8s_id = _k8s_id(record)
    cached = kdb.list_k8s_resource_cache(k8s_id, kind=kind, namespace=namespace)
    if cached:
        rows = cached
    else:
        try:
            client, _ = _get_client(record)
            if not client:
                return jsonify({"error": "Kubernetes client not available"}), 503
            items = []
            if kind:
                items = _list_resources_raw(client, kind, namespace=namespace)
            else:
                for k in SYNC_KINDS:
                    items.extend(_list_resources_raw(client, k, namespace=namespace))
            rows = [_resource_summary(item) for item in items]
        except Exception as exc:
            _logger.warning("Live inventory failed for %s: %s", cluster_id, exc)
            return jsonify({"error": f"Failed to fetch inventory: {type(exc).__name__}"}), 503

    total = len(rows)
    start = (page_i - 1) * limit_i
    end = start + limit_i
    return jsonify({
        "cluster": html.escape(cluster_id),
        "kind": kind,
        "namespace": namespace,
        "page": page_i,
        "limit": limit_i,
        "total": total,
        "items": rows[start:end],
    })


@bp.route("/api/clusters/<cluster_id>/kubernetes/inventory/<kind>/<namespace>/<name>", methods=["GET"])
@require_auth(perms=["kubernetes.widget"])
def kubernetes_inventory_detail(cluster_id: str, kind: str, namespace: str, name: str) -> Any:
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if kind not in ALLOWED_KINDS:
        return jsonify({"error": "Unsupported kind"}), 400

    record, error_resp = _get_k8s_cluster(cluster_id)
    if not record:
        return error_resp

    ns = namespace if namespace != "-" else None
    client, _ = _get_client(record)
    if not client:
        return jsonify({"error": "Kubernetes client not available"}), 503

    item = _read_resource_raw(client, kind, ns, name)
    if not item:
        return jsonify({"error": "Resource not found"}), 404

    if kind == "Secret":
        item.get("data", {}).clear()
        item.pop("stringData", None)

    return jsonify({
        "cluster": html.escape(cluster_id),
        "item": _sanitize_export_manifest(item),
    })


# ---------------------------------------------------------------------------
# Sync
# ---------------------------------------------------------------------------


@bp.route("/api/clusters/<cluster_id>/kubernetes/sync", methods=["GET", "POST"])
@require_auth(perms=["kubernetes.sync"])
def kubernetes_sync(cluster_id: str) -> Any:
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    record, error_resp = _get_k8s_cluster(cluster_id)
    if not record:
        return error_resp

    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "sync": {
                "status": record.get("status", "pending"),
                "last_run": record.get("last_health_check"),
                "resources_synced": 0,
            },
        })

    data = request.get_json() or {}
    kinds = data.get("kinds", SYNC_KINDS)
    if not isinstance(kinds, list):
        return jsonify({"error": "kinds must be a list"}), 400

    try:
        counts = _sync_resources(record, kinds=kinds or SYNC_KINDS)
        status = "reachable"
        message = f"Synced {sum(counts.values())} resources"
    except Exception as exc:
        status = "degraded"
        message = f"Sync failed: {type(exc).__name__}"
        counts = {}
        _logger.warning("Kubernetes sync failed for %s: %s", cluster_id, exc)

    kdb.update_k8s_cluster_status(cluster_id, status, message)

    _audit(
        "kubernetes.sync",
        cluster_id,
        f"Triggered Kubernetes sync for {html.escape(cluster_id)}: kinds={kinds}, counts={counts}",
    )

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "sync": {
            "status": status,
            "last_run": datetime.now(UTC).isoformat(),
            "resources_synced": sum(counts.values()),
            "counts": counts,
        },
    })


# ---------------------------------------------------------------------------
# Export
# ---------------------------------------------------------------------------


@bp.route("/api/clusters/<cluster_id>/kubernetes/export", methods=["GET", "POST"])
@require_auth(perms=["kubernetes.export"])
def kubernetes_export(cluster_id: str) -> Any:
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    record, error_resp = _get_k8s_cluster(cluster_id)
    if not record:
        return error_resp

    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "export": {
                "format": "yaml",
                "resources": DEFAULT_EXPORT_KINDS,
                "preview": True,
            },
        })

    data = request.get_json() or {}
    fmt = data.get("format", "yaml")
    resources = data.get("resources", DEFAULT_EXPORT_KINDS)
    namespace = data.get("namespace") or None

    if fmt not in ("yaml", "json"):
        return jsonify({"error": "format must be yaml or json"}), 400
    if not isinstance(resources, list):
        return jsonify({"error": "resources must be a list"}), 400

    kinds = []
    for r in resources:
        title = (r or "").strip().title().replace(" ", "")
        if title == "Namespace":
            title = "Namespace"
        if title in ALLOWED_KINDS:
            kinds.append(title)
        elif f"{r}".strip().lower() in {k.lower() for k in ALLOWED_KINDS}:
            kinds.append(next(k for k in ALLOWED_KINDS if k.lower() == r.strip().lower()))

    if not kinds:
        return jsonify({"error": "No supported resource kinds requested"}), 400

    try:
        items = _extract_export_items(record, kinds, namespace)
    except Exception as exc:
        _logger.warning("Kubernetes export failed for %s: %s", cluster_id, exc)
        return jsonify({"error": f"Export failed: {type(exc).__name__}"}), 503

    result = _format_export_manifests(items, fmt)

    _audit(
        "kubernetes.export",
        cluster_id,
        f"Generated Kubernetes export for {html.escape(cluster_id)}: format={fmt}, resources={kinds}, namespace={namespace}",
    )

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "export": {
            "format": fmt,
            "resources": kinds,
            "namespace": namespace,
            "manifests": result if isinstance(result, list) else [],
            "manifest": result if isinstance(result, str) else None,
        },
    })


# ---------------------------------------------------------------------------
# Import
# ---------------------------------------------------------------------------


@bp.route("/api/clusters/<cluster_id>/kubernetes/import", methods=["POST"])
@require_auth(perms=["kubernetes.import"])
def kubernetes_import(cluster_id: str) -> Any:
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    record, error_resp = _get_k8s_cluster(cluster_id)
    if not record:
        return error_resp

    data = request.get_json() or {}
    manifest = (data.get("manifest") or "").strip()
    namespace = (data.get("namespace") or _default_namespace(record)).strip()
    allow_cluster_scoped = bool(data.get("allow_cluster_scoped", False))

    if not manifest:
        return jsonify({"error": "manifest is required"}), 400
    if len(manifest.encode("utf-8")) > MAX_MANIFEST_SIZE:
        return jsonify({"error": f"Manifest exceeds {MAX_MANIFEST_SIZE} bytes"}), 400

    if allow_cluster_scoped and not _is_admin():
        return jsonify({"error": "allow_cluster_scoped requires admin privileges"}), 403

    try:
        docs = list(yaml.safe_load_all(manifest))
    except yaml.YAMLError as exc:
        # Don't echo parser internals to the client (server info exposure);
        # the line/position detail stays in the server log.
        _logger.warning("Invalid manifest YAML for %s: %s", cluster_id, exc)
        return jsonify({"error": "Invalid YAML/JSON manifest"}), 400

    valid, msg = _validate_manifest_docs(docs, allow_cluster_scoped=allow_cluster_scoped)
    if not valid:
        return jsonify({"error": msg}), 400

    results, error = _apply_manifest(record, docs, namespace, allow_cluster_scoped)
    if error:
        return jsonify({"error": error, "results": results}), 400

    _audit(
        "kubernetes.import",
        cluster_id,
        f"Imported Kubernetes manifest for {html.escape(cluster_id)} in namespace {namespace}: {len(results)} resources",
    )

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "import": {
            "namespace": namespace,
            "resources": len(results),
            "status": "success",
            "results": results,
        },
    })


# ---------------------------------------------------------------------------
# Dashboard widget
# ---------------------------------------------------------------------------


@bp.route("/api/clusters/<cluster_id>/kubernetes/widget", methods=["GET"])
@require_auth(perms=["kubernetes.widget"])
def kubernetes_widget(cluster_id: str) -> Any:
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    record, error_resp = _get_k8s_cluster(cluster_id, missing_status=200)
    if not record:
        return jsonify({
            "cluster": html.escape(cluster_id),
            "widget": {
                "pods": 0,
                "services": 0,
                "deployments": 0,
                "nodes": 0,
                "status": "unknown",
                "message": "Kubernetes connector not configured",
            },
        })

    counts, status, message = _live_counts(record)
    return jsonify({
        "cluster": html.escape(cluster_id),
        "widget": {
            **counts,
            "status": status,
            "message": message,
        },
    })


# ---------------------------------------------------------------------------
# Node to VM mapping
# ---------------------------------------------------------------------------


@bp.route("/api/clusters/<cluster_id>/kubernetes/node-map", methods=["GET", "POST"])
@bp.route("/api/clusters/<cluster_id>/kubernetes/node-map/<node_name>", methods=["DELETE"])
@require_auth(perms=["kubernetes.import"])
def kubernetes_node_map(cluster_id: str, node_name: str | None = None) -> Any:
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    record, error_resp = _get_k8s_cluster(cluster_id)
    if not record:
        return error_resp

    k8s_id = _k8s_id(record)

    if request.method == "GET":
        mappings = kdb.get_k8s_node_vm_map(k8s_id)
        return jsonify({
            "cluster": html.escape(cluster_id),
            "node_map": mappings,
        })

    if request.method == "DELETE":
        if not node_name:
            return jsonify({"error": "node_name is required"}), 400
        kdb.delete_k8s_node_vm_map(k8s_id, node_name)
        _audit(
            "kubernetes.node_map.delete",
            cluster_id,
            f"Deleted Kubernetes node mapping {html.escape(node_name)} for {html.escape(cluster_id)}",
        )
        return jsonify({
            "success": True,
            "cluster": html.escape(cluster_id),
            "node_name": node_name,
        })

    data = request.get_json() or {}
    mapping = data.get("mapping", data)
    node = (mapping.get("node_name") or "").strip()
    if not node:
        return jsonify({"error": "node_name is required"}), 400
    proxmox_node = (mapping.get("proxmox_node") or "").strip() or None
    proxmox_vmid = mapping.get("proxmox_vmid")
    if proxmox_vmid is not None:
        try:
            proxmox_vmid = int(proxmox_vmid)
            if proxmox_vmid <= 0:
                raise ValueError
        except (TypeError, ValueError):
            return jsonify({"error": "proxmox_vmid must be a positive integer"}), 400
    vm_type = mapping.get("vm_type")
    if vm_type and vm_type not in kdb.SUPPORTED_VM_TYPES:
        return jsonify({"error": "vm_type must be qemu or lxc"}), 400
    strategy = mapping.get("matching_strategy", "manual")
    if strategy not in kdb.SUPPORTED_STRATEGIES:
        return jsonify({"error": "matching_strategy must be manual, hostname, or label"}), 400

    kdb.upsert_k8s_node_vm_map(k8s_id, node, {
        "proxmox_node": proxmox_node,
        "proxmox_vmid": proxmox_vmid,
        "vm_type": vm_type,
        "matching_strategy": strategy,
    })

    _audit(
        "kubernetes.node_map",
        cluster_id,
        f"Updated Kubernetes node mapping {html.escape(node)} for {html.escape(cluster_id)}",
    )

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "node_map": kdb.get_k8s_node_vm_map(k8s_id, node),
    })


# ---------------------------------------------------------------------------
# Alert channel
# ---------------------------------------------------------------------------


@bp.route("/api/clusters/<cluster_id>/kubernetes/alerts", methods=["GET", "POST"])
@require_auth(perms=["kubernetes.alerts"])
def kubernetes_alerts(cluster_id: str) -> Any:
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    record, error_resp = _get_k8s_cluster(cluster_id)
    if not record:
        return error_resp

    k8s_id = _k8s_id(record)

    if request.method == "GET":
        alerts = kdb.get_k8s_alert_channel(k8s_id) or {"enabled": False, "webhook_url": "", "events": ["error", "warning"], "include_resource_labels": False}
        if alerts.get("webhook_url"):
            alerts["webhook_url"] = alerts["webhook_url"]
        return jsonify({
            "cluster": html.escape(cluster_id),
            "alerts": alerts,
        })

    data = request.get_json() or {}
    alerts = data.get("alerts", {})
    enabled = bool(alerts.get("enabled", False))
    webhook_url = (alerts.get("webhook_url") or "").strip()
    events = alerts.get("events", [])
    include_labels = bool(alerts.get("include_resource_labels", False))

    if not isinstance(events, list):
        return jsonify({"error": "events must be a list"}), 400
    if enabled:
        if not webhook_url:
            return jsonify({"error": "webhook_url is required when alerts are enabled"}), 400
        safe, msg = _is_safe_api_url(webhook_url)
        if not safe:
            return jsonify({"error": msg}), 400

    payload = {
        "enabled": enabled,
        "webhook_url": webhook_url,
        "events": list(set(events)),
        "include_resource_labels": include_labels,
    }
    kdb.save_k8s_alert_channel(k8s_id, payload)

    _audit(
        "kubernetes.alerts",
        cluster_id,
        f"Updated Kubernetes alert channel for {html.escape(cluster_id)}: enabled={enabled}, events={payload['events']}",
    )

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "alerts": payload,
    })


# ---------------------------------------------------------------------------
# Policy adapter
# ---------------------------------------------------------------------------


@bp.route("/api/clusters/<cluster_id>/kubernetes/policy", methods=["GET", "POST"])
@require_auth(perms=["kubernetes.policy"])
def kubernetes_policy(cluster_id: str) -> Any:
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    record, error_resp = _get_k8s_cluster(cluster_id)
    if not record:
        return error_resp

    k8s_id = _k8s_id(record)

    if request.method == "GET":
        policy = kdb.get_k8s_policy_adapter(k8s_id) or {"enabled": False, "engine": "kyverno", "policies": [], "violation_count": 0}
        return jsonify({
            "cluster": html.escape(cluster_id),
            "policy": policy,
        })

    data = request.get_json() or {}
    policy = data.get("policy", {})
    enabled = bool(policy.get("enabled", False))
    engine = (policy.get("engine") or "kyverno").lower()
    policies = policy.get("policies", [])

    if engine not in kdb.SUPPORTED_ENGINES:
        return jsonify({"error": "invalid engine"}), 400
    if not isinstance(policies, list):
        return jsonify({"error": "policies must be a list"}), 400

    payload = {
        "enabled": enabled,
        "engine": engine,
        "policies": list(policies),
        "violation_count": int(policy.get("violation_count", 0)),
    }
    kdb.save_k8s_policy_adapter(k8s_id, payload)

    _audit(
        "kubernetes.policy",
        cluster_id,
        f"Updated Kubernetes policy adapter for {html.escape(cluster_id)}: enabled={enabled}, engine={engine}, policies={payload['policies']}",
    )

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "policy": payload,
    })


# ---------------------------------------------------------------------------
# Role mappings
# ---------------------------------------------------------------------------


@bp.route("/api/clusters/<cluster_id>/kubernetes/roles", methods=["GET", "POST"])
@require_auth(perms=["kubernetes.roles"])
def kubernetes_roles(cluster_id: str) -> Any:
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    record, error_resp = _get_k8s_cluster(cluster_id)
    if not record:
        return error_resp

    k8s_id = _k8s_id(record)

    if request.method == "GET":
        roles = kdb.list_k8s_role_mappings(k8s_id)
        return jsonify({
            "cluster": html.escape(cluster_id),
            "roles": roles,
        })

    data = request.get_json() or {}
    roles = data.get("roles", [])

    if not isinstance(roles, list):
        return jsonify({"error": "roles must be a list"}), 400

    cleaned: list[dict[str, Any]] = []
    for r in roles:
        if not isinstance(r, dict):
            return jsonify({"error": "each role must be a mapping"}), 400
        if "proxmox_role" not in r or "k8s_role" not in r:
            return jsonify({"error": "each role mapping must have proxmox_role and k8s_role"}), 400
        ns = r.get("k8s_namespace")
        if ns is not None and not isinstance(ns, str):
            return jsonify({"error": "k8s_namespace must be a string or null"}), 400
        cleaned.append({
            "proxmox_role": str(r["proxmox_role"]).strip(),
            "k8s_role": str(r["k8s_role"]).strip(),
            "k8s_namespace": ns,
            "enabled": bool(r.get("enabled", True)),
        })

    kdb.replace_k8s_role_mappings(k8s_id, cleaned)

    _audit(
        "kubernetes.roles",
        cluster_id,
        f"Updated Kubernetes role mapping for {html.escape(cluster_id)}: {len(cleaned)} mappings",
    )

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "roles": kdb.list_k8s_role_mappings(k8s_id),
    })


# ---------------------------------------------------------------------------
# Template library
# ---------------------------------------------------------------------------


@bp.route("/api/clusters/<cluster_id>/kubernetes/library", methods=["GET"])
@require_auth(perms=["kubernetes.library"])
def kubernetes_library(cluster_id: str) -> Any:
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    templates = kdb.list_k8s_templates()
    return jsonify({
        "cluster": html.escape(cluster_id),
        "library": [
            {
                "id": t["id"],
                "name": t["name"],
                "description": t.get("description", ""),
                "tags": t.get("tags", []),
                "default_namespace": t.get("default_namespace", "default"),
            }
            for t in templates
        ],
    })


@bp.route("/api/clusters/<cluster_id>/kubernetes/library/<template_id>", methods=["GET"])
@require_auth(perms=["kubernetes.library"])
def kubernetes_library_detail(cluster_id: str, template_id: str) -> Any:
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    template = kdb.get_k8s_template(template_id)
    if not template:
        return jsonify({"error": "Template not found"}), 404

    return jsonify({
        "cluster": html.escape(cluster_id),
        "template": {
            "id": template["id"],
            "name": template["name"],
            "description": template.get("description", ""),
            "tags": template.get("tags", []),
            "default_namespace": template.get("default_namespace", "default"),
            "parameter_schema": template.get("parameter_schema", {}),
        },
    })


@bp.route("/api/clusters/<cluster_id>/kubernetes/library/<template_id>/deploy", methods=["POST"])
@require_auth(perms=["kubernetes.import"])
def kubernetes_library_deploy(cluster_id: str, template_id: str) -> Any:
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    record, error_resp = _get_k8s_cluster(cluster_id)
    if not record:
        return error_resp

    template = kdb.get_k8s_template(template_id)
    if not template:
        return jsonify({"error": "Template not found"}), 404

    data = request.get_json() or {}
    namespace = (data.get("namespace") or template.get("default_namespace", "default")).strip()
    parameters = data.get("parameters", {})

    if not isinstance(parameters, dict):
        return jsonify({"error": "parameters must be an object"}), 400

    # Simple Python string substitution for template parameters.
    manifest_template = template.get("manifest_template", "")
    merged = {"namespace": namespace}
    merged.update(parameters)
    try:
        rendered = manifest_template.format(**merged)
    except KeyError as exc:
        _logger.warning("Template %s missing parameter for %s: %s", template_id, cluster_id, exc)
        return jsonify({"error": "Manifest template references a parameter that was not supplied"}), 400
    except Exception as exc:
        _logger.warning("Template %s render failed for %s: %s", template_id, cluster_id, exc)
        return jsonify({"error": "Manifest template render failed"}), 400

    try:
        docs = list(yaml.safe_load_all(rendered))
    except yaml.YAMLError as exc:
        _logger.warning("Rendered template %s is not valid YAML for %s: %s", template_id, cluster_id, exc)
        return jsonify({"error": "Rendered manifest is not valid YAML"}), 400

    valid, msg = _validate_manifest_docs(docs)
    if not valid:
        return jsonify({"error": msg}), 400

    results, error = _apply_manifest(record, docs, namespace, allow_cluster_scoped=False)
    if error:
        return jsonify({"error": error, "results": results}), 400

    _audit(
        "kubernetes.template.deploy",
        cluster_id,
        f"Deployed template {html.escape(template_id)} to {html.escape(cluster_id)} in namespace {namespace}",
    )

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "template_id": template_id,
        "namespace": namespace,
        "resources": len(results),
        "results": results,
    })


# ---------------------------------------------------------------------------
# Automation workflow
# ---------------------------------------------------------------------------


@bp.route("/api/clusters/<cluster_id>/kubernetes/workflow", methods=["GET", "POST"])
@require_auth(perms=["kubernetes.workflow"])
def kubernetes_workflow(cluster_id: str) -> Any:
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    record, error_resp = _get_k8s_cluster(cluster_id)
    if not record:
        return error_resp

    k8s_id = _k8s_id(record)

    if request.method == "GET":
        workflows = kdb.list_k8s_workflows(k8s_id)
        return jsonify({
            "cluster": html.escape(cluster_id),
            "workflow": workflows[0] if workflows else {"enabled": False, "schedule": "0 2 * * 0", "steps": ["discover", "sync", "validate"]},
        })

    data = request.get_json() or {}
    workflow = data.get("workflow", {})
    name = (workflow.get("name") or "default").strip()
    enabled = bool(workflow.get("enabled", False))
    schedule = workflow.get("schedule", "0 2 * * 0").strip()
    steps = workflow.get("steps", [])

    if not isinstance(steps, list) or not steps:
        return jsonify({"error": "steps must be a non-empty list"}), 400
    if not _is_valid_cron(schedule):
        return jsonify({"error": "Invalid cron expression"}), 400

    wf_id = kdb.save_k8s_workflow(k8s_id, {
        "name": name,
        "enabled": enabled,
        "schedule": schedule,
        "steps": steps,
    })

    _audit(
        "kubernetes.workflow",
        cluster_id,
        f"Updated Kubernetes workflow for {html.escape(cluster_id)}: enabled={enabled}, schedule={schedule}, steps={steps}",
    )

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "workflow": kdb.get_k8s_workflow(k8s_id, workflow_id=wf_id),
    })


@bp.route("/api/clusters/<cluster_id>/kubernetes/workflow/run", methods=["POST"])
@require_auth(perms=["kubernetes.workflow"])
def kubernetes_workflow_run(cluster_id: str) -> Any:
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    record, error_resp = _get_k8s_cluster(cluster_id)
    if not record:
        return error_resp

    k8s_id = _k8s_id(record)
    workflows = kdb.list_k8s_workflows(k8s_id)
    if not workflows:
        return jsonify({"error": "No workflow configured"}), 400

    workflow = workflows[0]
    steps = workflow.get("steps", [])
    results: dict[str, Any] = {}
    status = "success"

    for step in steps:
        try:
            if step == "discover":
                # Quick live probe.
                counts, _, _ = _live_counts(record)
                results["discover"] = counts
            elif step == "sync":
                counts = _sync_resources(record)
                results["sync"] = counts
            elif step == "validate":
                # Re-run connection test.
                test_status, message = _test_connection(record)
                kdb.update_k8s_cluster_status(cluster_id, test_status, message)
                results["validate"] = {"status": test_status, "message": message}
            elif step == "export":
                items = _extract_export_items(record, DEFAULT_EXPORT_KINDS, namespace=None)
                results["export"] = {"resources": len(items)}
            elif step == "deploy":
                results["deploy"] = {"note": "No template specified"}
            else:
                results[step] = {"note": "Unknown step"}
        except Exception as exc:
            results[step] = {"error": str(exc)}
            status = "failure"
            break

    run_at = datetime.now(UTC).isoformat()
    kdb.update_k8s_workflow_run(k8s_id, workflow["id"], status, run_at=run_at)

    _audit(
        "kubernetes.workflow.run",
        cluster_id,
        f"Ran Kubernetes workflow for {html.escape(cluster_id)}: status={status}, steps={list(results.keys())}",
    )

    return jsonify({
        "success": status == "success",
        "cluster": html.escape(cluster_id),
        "workflow": {
            "status": status,
            "last_run": run_at,
            "results": results,
        },
    })
