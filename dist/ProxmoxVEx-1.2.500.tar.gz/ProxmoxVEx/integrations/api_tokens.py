#!/usr/bin/env python3
# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/integrations/api_tokens.py
# Project:     ProxmoxVEx
# Version:     1.2.499
# Build:       2026.09.23
# Description: API Tokens integration: export endpoints.
# Usage:       import ProxmoxVEx.integrations.api_tokens
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-23
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""API Tokens integration: export endpoints."""

import html

from flask import Blueprint, jsonify, request

from ProxmoxVEx.api.auth import require_auth
from ProxmoxVEx.api.clusters import check_cluster_access, cluster_managers
from ProxmoxVEx.utils.audit import log_audit

bp = Blueprint("api_tokens", __name__)


# In-memory API Tokens export store.
_api_tokens_export = {}


@bp.route("/api/clusters/<cluster_id>/api-tokens/export", methods=["GET", "POST"])
@require_auth(perms=["api_tokens.export"])
def api_tokens_export(cluster_id):
    """Return or update the API Tokens export configuration.

    974-api-tokens-export: per-cluster API Tokens export settings.
    """
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "export": _api_tokens_export.get(
                cluster_id,
                {"enabled": False, "format": "json", "tokens": []},
            ),
        })

    data = request.get_json() or {}
    export = data.get("export", {})

    config = {
        "enabled": bool(export.get("enabled", False)),
        "format": html.escape(str(export.get("format", "json"))),
        "tokens": [html.escape(str(token)) for token in (export.get("tokens", []) if isinstance(export.get("tokens", []), list) else [])],
    }
    _api_tokens_export[cluster_id] = config
    log_audit(
        getattr(request, "session", {}).get("user", "system"),
        "api_tokens.export",
        f"Updated API Tokens export for {html.escape(cluster_id)}: enabled={config['enabled']}, format={config['format']}, tokens={len(config['tokens'])}",
        cluster=cluster_managers[cluster_id].config.name,
    )

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "export": config,
    })


# In-memory API Tokens connector store.
_api_tokens_connector = {}


@bp.route("/api/clusters/<cluster_id>/api-tokens/connector", methods=["GET", "POST"])
@require_auth(perms=["api_tokens.connector"])
def api_tokens_connector(cluster_id):
    """Return or update the API Tokens connector configuration.

    975-api-tokens-connector: per-cluster API Tokens connector settings.
    """
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "connector": _api_tokens_connector.get(
                cluster_id,
                {"enabled": False, "endpoint": "", "auth_method": "header"},
            ),
        })

    data = request.get_json() or {}
    connector = data.get("connector", {})

    config = {
        "enabled": bool(connector.get("enabled", False)),
        "endpoint": html.escape(str(connector.get("endpoint", ""))),
        "auth_method": html.escape(str(connector.get("auth_method", "header"))),
    }
    _api_tokens_connector[cluster_id] = config
    log_audit(
        getattr(request, "session", {}).get("user", "system"),
        "api_tokens.connector",
        f"Updated API Tokens connector for {html.escape(cluster_id)}: enabled={config['enabled']}, auth_method={config['auth_method']}",
        cluster=cluster_managers[cluster_id].config.name,
    )

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "connector": config,
    })


# In-memory API Tokens sync store.
_api_tokens_sync = {}


@bp.route("/api/clusters/<cluster_id>/api-tokens/sync", methods=["GET", "POST"])
@require_auth(perms=["api_tokens.sync"])
def api_tokens_sync(cluster_id):
    """Return or update the API Tokens sync configuration.

    976-api-tokens-sync: per-cluster API Tokens sync settings.
    """
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "sync": _api_tokens_sync.get(
                cluster_id,
                {"enabled": False, "source": "", "interval": 3600},
            ),
        })

    data = request.get_json() or {}
    sync = data.get("sync", {})

    try:
        interval = int(sync.get("interval", 3600))
    except (TypeError, ValueError):
        interval = 3600

    config = {
        "enabled": bool(sync.get("enabled", False)),
        "source": html.escape(str(sync.get("source", ""))),
        "interval": interval,
    }
    _api_tokens_sync[cluster_id] = config
    log_audit(
        getattr(request, "session", {}).get("user", "system"),
        "api_tokens.sync",
        f"Updated API Tokens sync for {html.escape(cluster_id)}: enabled={config['enabled']}, source={config['source']}, interval={config['interval']}",
        cluster=cluster_managers[cluster_id].config.name,
    )

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "sync": config,
    })


# In-memory API Tokens import store.
_api_tokens_import = {}


@bp.route("/api/clusters/<cluster_id>/api-tokens/import", methods=["GET", "POST"])
@require_auth(perms=["api_tokens.import"])
def api_tokens_import(cluster_id):
    """Return or update the API Tokens import configuration.

    977-api-tokens-import: per-cluster API Tokens import settings.
    """
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "import": _api_tokens_import.get(
                cluster_id,
                {"enabled": False, "format": "json", "mappings": []},
            ),
        })

    data = request.get_json() or {}
    import_cfg = data.get("import", {})

    def _clean_mapping(mapping):
        if not isinstance(mapping, dict):
            return None
        return {
            "source_field": html.escape(str(mapping.get("source_field", ""))),
            "target_field": html.escape(str(mapping.get("target_field", ""))),
        }

    mappings = import_cfg.get("mappings", [])
    if not isinstance(mappings, list):
        mappings = []
    cleaned = [m for m in (_clean_mapping(mapping) for mapping in mappings) if m is not None]

    config = {
        "enabled": bool(import_cfg.get("enabled", False)),
        "format": html.escape(str(import_cfg.get("format", "json"))),
        "mappings": cleaned,
    }
    _api_tokens_import[cluster_id] = config
    log_audit(
        getattr(request, "session", {}).get("user", "system"),
        "api_tokens.import",
        f"Updated API Tokens import for {html.escape(cluster_id)}: enabled={config['enabled']}, format={config['format']}, mappings={len(config['mappings'])}",
        cluster=cluster_managers[cluster_id].config.name,
    )

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "import": config,
    })


# In-memory API Tokens template library store.
_api_tokens_template_library = {}


@bp.route("/api/clusters/<cluster_id>/api-tokens/template-library", methods=["GET", "POST"])
@require_auth(perms=["api_tokens.template_library"])
def api_tokens_template_library(cluster_id):
    """Return or update the API Tokens template library.

    978-api-tokens-template-library: per-cluster API Tokens templates.
    """
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "templates": _api_tokens_template_library.get(
                cluster_id,
                [],
            ),
        })

    data = request.get_json() or {}
    templates = data.get("templates", []) if isinstance(data.get("templates", []), list) else []
    cleaned = [
        {
            "name": html.escape(str(template.get("name", ""))),
            "description": html.escape(str(template.get("description", ""))),
            "permissions": [html.escape(str(perm)) for perm in (template.get("permissions", []) if isinstance(template.get("permissions", []), list) else [])],
        }
        for template in templates
        if isinstance(template, dict)
    ]
    _api_tokens_template_library[cluster_id] = cleaned
    log_audit(
        getattr(request, "session", {}).get("user", "system"),
        "api_tokens.template_library",
        f"Updated API Tokens template library for {html.escape(cluster_id)}: {len(cleaned)} templates",
        cluster=cluster_managers[cluster_id].config.name,
    )

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "templates": cleaned,
    })


# In-memory API Tokens dashboard widget store.
_api_tokens_dashboard_widget = {}


@bp.route("/api/clusters/<cluster_id>/api-tokens/dashboard-widget", methods=["GET", "POST"])
@require_auth(perms=["api_tokens.dashboard_widget"])
def api_tokens_dashboard_widget(cluster_id):
    """Return or update the API Tokens dashboard widget configuration.

    979-api-tokens-dashboard-widget: per-cluster API Tokens dashboard widget settings.
    """
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "widget": _api_tokens_dashboard_widget.get(
                cluster_id,
                {"enabled": False, "position": "dashboard", "metrics": []},
            ),
        })

    data = request.get_json() or {}
    widget = data.get("widget", {})

    config = {
        "enabled": bool(widget.get("enabled", False)),
        "position": html.escape(str(widget.get("position", "dashboard"))),
        "metrics": [html.escape(str(metric)) for metric in (widget.get("metrics", []) if isinstance(widget.get("metrics", []), list) else [])],
    }
    _api_tokens_dashboard_widget[cluster_id] = config
    log_audit(
        getattr(request, "session", {}).get("user", "system"),
        "api_tokens.dashboard_widget",
        f"Updated API Tokens dashboard widget for {html.escape(cluster_id)}: enabled={config['enabled']}, position={config['position']}",
        cluster=cluster_managers[cluster_id].config.name,
    )

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "widget": config,
    })


# In-memory API Tokens alert channel store.
_api_tokens_alert_channel = {}


@bp.route("/api/clusters/<cluster_id>/api-tokens/alert-channel", methods=["GET", "POST"])
@require_auth(perms=["api_tokens.alert_channel"])
def api_tokens_alert_channel(cluster_id):
    """Return or update the API Tokens alert channel configuration.

    980-api-tokens-alert-channel: per-cluster API Tokens alert channel settings.
    """
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "alert_channel": _api_tokens_alert_channel.get(
                cluster_id,
                {"enabled": False, "severity": "warning", "events": []},
            ),
        })

    data = request.get_json() or {}
    channel = data.get("alert_channel", {})

    config = {
        "enabled": bool(channel.get("enabled", False)),
        "severity": html.escape(str(channel.get("severity", "warning"))),
        "events": [html.escape(str(event)) for event in (channel.get("events", []) if isinstance(channel.get("events", []), list) else [])],
    }
    _api_tokens_alert_channel[cluster_id] = config
    log_audit(
        getattr(request, "session", {}).get("user", "system"),
        "api_tokens.alert_channel",
        f"Updated API Tokens alert channel for {html.escape(cluster_id)}: enabled={config['enabled']}, severity={config['severity']}",
        cluster=cluster_managers[cluster_id].config.name,
    )

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "alert_channel": config,
    })


# In-memory API Tokens policy adapter store.
_api_tokens_policy_adapter = {}


@bp.route("/api/clusters/<cluster_id>/api-tokens/policy-adapter", methods=["GET", "POST"])
@require_auth(perms=["api_tokens.policy_adapter"])
def api_tokens_policy_adapter(cluster_id):
    """Return or update the API Tokens policy adapter configuration.

    981-api-tokens-policy-adapter: per-cluster API Tokens policy adapter rules.
    """
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "policy_adapter": _api_tokens_policy_adapter.get(
                cluster_id,
                {"enabled": False, "allow": [], "deny": []},
            ),
        })

    data = request.get_json() or {}
    adapter = data.get("policy_adapter", {})

    def _clean(items):
        return [html.escape(str(item)) for item in (items if isinstance(items, list) else [])]

    config = {
        "enabled": bool(adapter.get("enabled", False)),
        "allow": _clean(adapter.get("allow", [])),
        "deny": _clean(adapter.get("deny", [])),
    }
    _api_tokens_policy_adapter[cluster_id] = config
    log_audit(
        getattr(request, "session", {}).get("user", "system"),
        "api_tokens.policy_adapter",
        f"Updated API Tokens policy adapter for {html.escape(cluster_id)}: enabled={config['enabled']}, allow={len(config['allow'])}, deny={len(config['deny'])}",
        cluster=cluster_managers[cluster_id].config.name,
    )

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "policy_adapter": config,
    })


# In-memory API Tokens role mapping store.
_api_tokens_role_mapping = {}


@bp.route("/api/clusters/<cluster_id>/api-tokens/role-mapping", methods=["GET", "POST"])
@require_auth(perms=["api_tokens.role_mapping"])
def api_tokens_role_mapping(cluster_id):
    """Return or update the API Tokens role mapping configuration.

    982-api-tokens-role-mapping: per-cluster API Tokens role mapping rules.
    """
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "role_mapping": _api_tokens_role_mapping.get(
                cluster_id,
                {"enabled": False, "rules": []},
            ),
        })

    data = request.get_json() or {}
    mapping = data.get("role_mapping", {})

    def _clean_rule(rule):
        if not isinstance(rule, dict):
            return None
        return {
            "claim": html.escape(str(rule.get("claim", ""))),
            "value": html.escape(str(rule.get("value", ""))),
            "role": html.escape(str(rule.get("role", ""))),
        }

    rules = mapping.get("rules", [])
    if not isinstance(rules, list):
        rules = []
    cleaned = [r for r in (_clean_rule(rule) for rule in rules) if r is not None]

    config = {
        "enabled": bool(mapping.get("enabled", False)),
        "rules": cleaned,
    }
    _api_tokens_role_mapping[cluster_id] = config
    log_audit(
        getattr(request, "session", {}).get("user", "system"),
        "api_tokens.role_mapping",
        f"Updated API Tokens role mapping for {html.escape(cluster_id)}: enabled={config['enabled']}, rules={len(config['rules'])}",
        cluster=cluster_managers[cluster_id].config.name,
    )

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "role_mapping": config,
    })


# In-memory API Tokens automation workflow store.
_api_tokens_automation_workflow = {}


@bp.route("/api/clusters/<cluster_id>/api-tokens/automation-workflow", methods=["GET", "POST"])
@require_auth(perms=["api_tokens.automation_workflow"])
def api_tokens_automation_workflow(cluster_id):
    """Return or update the API Tokens automation workflow configuration.

    983-api-tokens-automation-workflow: per-cluster API Tokens automation workflow rules.
    """
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "automation_workflow": _api_tokens_automation_workflow.get(
                cluster_id,
                {"enabled": False, "triggers": [], "actions": []},
            ),
        })

    data = request.get_json() or {}
    workflow = data.get("automation_workflow", {})

    def _clean_trigger(trigger):
        if not isinstance(trigger, dict):
            return None
        return {
            "event": html.escape(str(trigger.get("event", ""))),
            "condition": html.escape(str(trigger.get("condition", ""))),
        }

    def _clean_action(action):
        if not isinstance(action, dict):
            return None
        return {
            "action": html.escape(str(action.get("action", ""))),
            "target": html.escape(str(action.get("target", ""))),
        }

    triggers = workflow.get("triggers", [])
    if not isinstance(triggers, list):
        triggers = []
    actions = workflow.get("actions", [])
    if not isinstance(actions, list):
        actions = []

    cleaned_triggers = [t for t in (_clean_trigger(t) for t in triggers) if t is not None]
    cleaned_actions = [a for a in (_clean_action(a) for a in actions) if a is not None]

    config = {
        "enabled": bool(workflow.get("enabled", False)),
        "triggers": cleaned_triggers,
        "actions": cleaned_actions,
    }
    _api_tokens_automation_workflow[cluster_id] = config
    log_audit(
        getattr(request, "session", {}).get("user", "system"),
        "api_tokens.automation_workflow",
        f"Updated API Tokens automation workflow for {html.escape(cluster_id)}: enabled={config['enabled']}, triggers={len(config['triggers'])}, actions={len(config['actions'])}",
        cluster=cluster_managers[cluster_id].config.name,
    )

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "automation_workflow": config,
    })
