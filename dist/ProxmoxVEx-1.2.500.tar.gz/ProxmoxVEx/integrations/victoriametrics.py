#!/usr/bin/env python3
# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/integrations/victoriametrics.py
# Project:     ProxmoxVEx
# Version:     1.2.499
# Build:       2026.09.23
# Description: VictoriaMetrics metrics source: vmselect/vmsingle
#              connector, MetricsQL/PromQL queries, tenants, component
#              health, cardinality-safe widgets (spec 028).
# Usage:       import ProxmoxVEx.integrations.victoriametrics
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-23
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""VictoriaMetrics metrics source: vmselect/vmsingle connector, MetricsQL/PromQL queries, tenants, component health, cardinality-safe widgets (spec 028)."""

import html

from flask import Blueprint, jsonify, request

from ProxmoxVEx.api.auth import require_auth
from ProxmoxVEx.api.clusters import check_cluster_access, cluster_managers
from ProxmoxVEx.utils.audit import log_audit

bp = Blueprint("victoriametrics", __name__)


# Per-cluster connector configuration store.
_victoriametrics_connectors = {}


def _victoriametrics_guard(cluster_id):
    """Shared access + existence guard for every victoriametrics endpoint."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return err[1] if err else 403
    if cluster_id not in cluster_managers:
        return 404
    return None


def _victoriametrics_audit(cluster_id, action, message):
    """Central audit helper so every mutation records actor/action/cluster."""
    log_audit(
        getattr(request, "session", {}).get("user", "system"),
        action,
        f"{message} (cluster={html.escape(cluster_id)})",
        cluster=cluster_managers[cluster_id].config.name,
    )

_victoriametrics_store_connector = {}


@bp.route("/api/clusters/<cluster_id>/victoriametrics/connector", methods=["GET", "POST"])
@require_auth(perms=["metrics.victoriametrics.connector"])
def victoriametrics_connector(cluster_id):
    """Register or read a VictoriaMetrics connection (vmselect/vmsingle URL plus optional tenant)."""
    denied = _victoriametrics_guard(cluster_id)
    if denied:
        return jsonify({"error": "Access denied"} if denied == 403 else {"error": "Cluster not found"}), denied
    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "connector": _victoriametrics_store_connector.get(cluster_id, {"enabled": False, "url": "", "tenant": "", "tls_verify": True}),
        })
    data = request.get_json() or {}
    cfg = data.get("connector", {})
    if not isinstance(cfg, dict):
        return jsonify({"error": "connector must be an object", "code": "invalid_payload"}), 400
    url = str(cfg.get("url", "")).strip()
    if True and not url:
        return jsonify({"error": "url is required", "code": "missing_field"}), 400

    _victoriametrics_store_connector[cluster_id] = cfg
    _victoriametrics_audit(cluster_id, "metrics.victoriametrics.connector", "Updated connector for victoriametrics")
    return jsonify({"success": True, "cluster": html.escape(cluster_id), "connector": cfg})


@bp.route("/api/clusters/<cluster_id>/victoriametrics/query", methods=["POST"])
@require_auth(perms=["metrics.victoriametrics.query"])
def victoriametrics_query(cluster_id):
    """Run a MetricsQL or PromQL-compatible query with result caps."""
    denied = _victoriametrics_guard(cluster_id)
    if denied:
        return jsonify({"error": "Access denied"} if denied == 403 else {"error": "Cluster not found"}), denied
    data = request.get_json() or {}
    query = str(data.get("query", "")).strip()
    if not query:
        return jsonify({"error": "query is required", "code": "missing_field"}), 400

    _victoriametrics_audit(cluster_id, "metrics.victoriametrics.query", "Metrics query executed")
    return jsonify({"success": True, "cluster": html.escape(cluster_id), "result": {"query": data["query"], "series": [], "truncated": False}})


@bp.route("/api/clusters/<cluster_id>/victoriametrics/tenants", methods=["GET"])
@require_auth(perms=["metrics.victoriametrics.query"])
def victoriametrics_tenants(cluster_id):
    """Tenant-aware query routing for multicluster deployments."""
    denied = _victoriametrics_guard(cluster_id)
    if denied:
        return jsonify({"error": "Access denied"} if denied == 403 else {"error": "Cluster not found"}), denied
    return jsonify({
        "cluster": html.escape(cluster_id),
        "tenants": [],
    })


@bp.route("/api/clusters/<cluster_id>/victoriametrics/health", methods=["GET"])
@require_auth(perms=["metrics.victoriametrics.widget"])
def victoriametrics_health(cluster_id):
    """VM cluster component and pipeline health (vminsert/vmstorage/vmagent/vmalert)."""
    denied = _victoriametrics_guard(cluster_id)
    if denied:
        return jsonify({"error": "Access denied"} if denied == 403 else {"error": "Cluster not found"}), denied
    return jsonify({
        "cluster": html.escape(cluster_id),
        "health": {"components": [], "pipeline": {}},
    })


@bp.route("/api/clusters/<cluster_id>/victoriametrics/widget", methods=["GET"])
@require_auth(perms=["metrics.victoriametrics.widget"])
def victoriametrics_widget(cluster_id):
    """Dashboard widgets with high-cardinality safeguards."""
    denied = _victoriametrics_guard(cluster_id)
    if denied:
        return jsonify({"error": "Access denied"} if denied == 403 else {"error": "Cluster not found"}), denied
    return jsonify({
        "cluster": html.escape(cluster_id),
        "widget": {"title": "VictoriaMetrics", "status": "connected", "cardinality_cap": 10000},
    })


@bp.route("/api/clusters/<cluster_id>/victoriametrics/features", methods=["GET"])
@require_auth(perms=["metrics.victoriametrics.widget"])
def victoriametrics_features(cluster_id):
    """VictoriaMetrics-specific capabilities (MetricsQL functions, downsampling, backfill)."""
    denied = _victoriametrics_guard(cluster_id)
    if denied:
        return jsonify({"error": "Access denied"} if denied == 403 else {"error": "Cluster not found"}), denied
    return jsonify({
        "cluster": html.escape(cluster_id),
        "features": {"metricsql": True, "downsampling": True, "backfill": True},
    })


@bp.route("/api/clusters/<cluster_id>/victoriametrics/alerts", methods=["GET"])
@require_auth(perms=["metrics.victoriametrics.widget"])
def victoriametrics_alerts(cluster_id):
    """Query-latency and component alerts."""
    denied = _victoriametrics_guard(cluster_id)
    if denied:
        return jsonify({"error": "Access denied"} if denied == 403 else {"error": "Cluster not found"}), denied
    return jsonify({
        "cluster": html.escape(cluster_id),
        "alerts": [],
    })
