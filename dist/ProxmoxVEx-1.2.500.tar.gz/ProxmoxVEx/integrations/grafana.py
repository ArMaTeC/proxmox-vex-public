#!/usr/bin/env python3
# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/integrations/grafana.py
# Project:     ProxmoxVEx
# Version:     1.2.499
# Build:       2026.09.23
# Description: Grafana integration: dashboard export endpoints.
# Usage:       import ProxmoxVEx.integrations.grafana
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-23
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Grafana integration: dashboard export endpoints."""

import html

from flask import Blueprint, jsonify, request

from ProxmoxVEx.api.auth import require_auth
from ProxmoxVEx.api.clusters import check_cluster_access, cluster_managers
from ProxmoxVEx.utils.audit import log_audit

bp = Blueprint("grafana", __name__)


@bp.route("/api/clusters/<cluster_id>/grafana/export", methods=["GET", "POST"])
@require_auth(perms=["grafana.export"])
def grafana_export(cluster_id):
    """Return or generate Grafana dashboard export for a cluster."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "export": {
                "format": "grafana",
                "dashboards": [],
                "preview": True,
            },
        })

    data = request.get_json() or {}
    dashboards = data.get("dashboards", [])
    if not isinstance(dashboards, list):
        return jsonify({"error": "dashboards must be a list"}), 400

    log_audit(
        getattr(request, "session", {}).get("user", "system"),
        "grafana.export",
        f"Generated Grafana export for {html.escape(cluster_id)}: dashboards={len(dashboards)}",
        cluster=cluster_managers[cluster_id].config.name,
    )

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "export": {
            "format": "grafana",
            "dashboards": dashboards,
        },
    })


@bp.route("/api/clusters/<cluster_id>/grafana/connector", methods=["GET", "POST"])
@require_auth(perms=["grafana.connector"])
def grafana_connector(cluster_id):
    """Return or update the Grafana connector configuration."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "connector": {
                "enabled": False,
                "endpoint": "",
                "token": "",
            },
        })

    data = request.get_json() or {}
    connector = data.get("connector", {})
    enabled = bool(connector.get("enabled", False))
    endpoint = connector.get("endpoint", "")
    token = connector.get("token", "")

    if not isinstance(endpoint, str) or not isinstance(token, str):
        return jsonify({"error": "endpoint and token must be strings"}), 400

    log_audit(
        getattr(request, "session", {}).get("user", "system"),
        "grafana.connector",
        f"Updated Grafana connector for {html.escape(cluster_id)}: enabled={enabled}",
        cluster=cluster_managers[cluster_id].config.name,
    )

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "connector": {
            "enabled": enabled,
            "endpoint": endpoint,
            "token": "***" if token else "",
        },
    })


@bp.route("/api/clusters/<cluster_id>/grafana/sync", methods=["GET", "POST"])
@require_auth(perms=["grafana.sync"])
def grafana_sync(cluster_id):
    """Trigger a Grafana sync for the cluster."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "sync": {
                "status": "idle",
                "last_sync": None,
            },
        })

    log_audit(
        getattr(request, "session", {}).get("user", "system"),
        "grafana.sync",
        f"Triggered Grafana sync for {html.escape(cluster_id)}",
        cluster=cluster_managers[cluster_id].config.name,
    )

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "sync": {
            "status": "pending",
            "message": "Grafana sync queued",
        },
    })


@bp.route("/api/clusters/<cluster_id>/grafana/import", methods=["GET", "POST"])
@require_auth(perms=["grafana.import"])
def grafana_import(cluster_id):
    """Import a Grafana dashboard into the cluster."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "import": {
                "status": "idle",
                "dashboards": [],
            },
        })

    data = request.get_json() or {}
    dashboards = data.get("dashboards", [])
    if not isinstance(dashboards, list):
        return jsonify({"error": "dashboards must be a list"}), 400

    log_audit(
        getattr(request, "session", {}).get("user", "system"),
        "grafana.import",
        f"Imported {len(dashboards)} Grafana dashboard(s) for {html.escape(cluster_id)}",
        cluster=cluster_managers[cluster_id].config.name,
    )

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "import": {
            "status": "complete",
            "dashboards": dashboards,
        },
    })


@bp.route("/api/clusters/<cluster_id>/grafana/templates", methods=["GET"])
@require_auth(perms=["grafana.templates"])
def grafana_template_library(cluster_id):
    """Return the Grafana template library for the cluster."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    return jsonify({
        "cluster": html.escape(cluster_id),
        "templates": [
            {
                "id": "proxmox-overview",
                "name": "Proxmox Overview",
                "description": "High-level Proxmox cluster metrics",
                "tags": ["proxmox", "overview"],
            },
            {
                "id": "vm-performance",
                "name": "VM Performance",
                "description": "VM CPU, memory and disk I/O",
                "tags": ["vm", "performance"],
            },
        ],
    })


@bp.route("/api/clusters/<cluster_id>/grafana/widget", methods=["GET"])
@require_auth(perms=["grafana.widget"])
def grafana_dashboard_widget(cluster_id):
    """Return the Grafana dashboard widget configuration."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    return jsonify({
        "cluster": html.escape(cluster_id),
        "widget": {
            "type": "grafana",
            "title": "Grafana Dashboards",
            "icon": "grafana",
            "links": [
                {"label": "Open Grafana", "url": "/grafana"},
            ],
        },
    })


@bp.route("/api/clusters/<cluster_id>/grafana/alerts", methods=["GET", "POST"])
@require_auth(perms=["grafana.alerts"])
def grafana_alert_channel(cluster_id):
    """Manage Grafana alert channel configuration."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "alerts": {
                "enabled": False,
                "channel": "",
                "severity": ["critical", "warning"],
            },
        })

    data = request.get_json() or {}
    alerts = data.get("alerts", {})
    enabled = bool(alerts.get("enabled", False))
    channel = alerts.get("channel", "")
    severity = alerts.get("severity", ["critical", "warning"])

    if not isinstance(severity, list):
        return jsonify({"error": "severity must be a list"}), 400

    log_audit(
        getattr(request, "session", {}).get("user", "system"),
        "grafana.alerts",
        f"Updated Grafana alert channel for {html.escape(cluster_id)}: enabled={enabled}",
        cluster=cluster_managers[cluster_id].config.name,
    )

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "alerts": {
            "enabled": enabled,
            "channel": channel,
            "severity": severity,
        },
    })


@bp.route("/api/clusters/<cluster_id>/grafana/policy", methods=["GET", "POST"])
@require_auth(perms=["grafana.policy"])
def grafana_policy_adapter(cluster_id):
    """Manage Grafana policy adapter rules."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "policy": {
                "enabled": False,
                "rules": [
                    {"action": "allow", "resource": "dashboards"},
                ],
            },
        })

    data = request.get_json() or {}
    policy = data.get("policy", {})
    enabled = bool(policy.get("enabled", False))
    rules = policy.get("rules", [])

    if not isinstance(rules, list):
        return jsonify({"error": "rules must be a list"}), 400

    log_audit(
        getattr(request, "session", {}).get("user", "system"),
        "grafana.policy",
        f"Updated Grafana policy adapter for {html.escape(cluster_id)}: enabled={enabled}, rules={len(rules)}",
        cluster=cluster_managers[cluster_id].config.name,
    )

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "policy": {
            "enabled": enabled,
            "rules": rules,
        },
    })


@bp.route("/api/clusters/<cluster_id>/grafana/roles", methods=["GET", "POST"])
@require_auth(perms=["grafana.roles"])
def grafana_role_mapping(cluster_id):
    """Manage Grafana role mapping."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "roles": {
                "admin": "Admin",
                "editor": "Editor",
                "viewer": "Viewer",
            },
        })

    data = request.get_json() or {}
    mappings = data.get("mappings", {})
    if not isinstance(mappings, dict):
        return jsonify({"error": "mappings must be a dict"}), 400

    log_audit(
        getattr(request, "session", {}).get("user", "system"),
        "grafana.roles",
        f"Updated Grafana role mapping for {html.escape(cluster_id)}: {list(mappings.keys())}",
        cluster=cluster_managers[cluster_id].config.name,
    )

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "mappings": mappings,
    })


@bp.route("/api/clusters/<cluster_id>/grafana/automation", methods=["GET", "POST"])
@require_auth(perms=["grafana.automation"])
def grafana_automation_workflow(cluster_id):
    """Manage Grafana automation workflows."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "automation": {
                "enabled": False,
                "workflows": [],
            },
        })

    data = request.get_json() or {}
    automation = data.get("automation", {})
    enabled = bool(automation.get("enabled", False))
    workflows = automation.get("workflows", [])

    if not isinstance(workflows, list):
        return jsonify({"error": "workflows must be a list"}), 400

    log_audit(
        getattr(request, "session", {}).get("user", "system"),
        "grafana.automation",
        f"Updated Grafana automation workflow for {html.escape(cluster_id)}: enabled={enabled}, workflows={len(workflows)}",
        cluster=cluster_managers[cluster_id].config.name,
    )

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "automation": {
            "enabled": enabled,
            "workflows": workflows,
        },
    })


# ---------------------------------------------------------------------------
# Spec 030: Grafana bidirectional integration — spec-permission surfaces
# (grafana.connector / .embed / .link / .annotate / .render) covering
# connection registration, dashboard embeds, inventory links, annotations
# and panel rendering. Every mutation is audit-logged.
# ---------------------------------------------------------------------------

_grafana_connections = {}
_grafana_links = {}


def _graf_guard(cluster_id):
    """Shared access + existence guard for the spec-030 endpoints."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return err[1] if err else 403
    if cluster_id not in cluster_managers:
        return 404
    return None


def _graf_audit(cluster_id, action, message):
    log_audit(
        getattr(request, "session", {}).get("user", "system"),
        action,
        f"{message} (cluster={html.escape(cluster_id)})",
        cluster=cluster_managers[cluster_id].config.name,
    )


@bp.route("/api/clusters/<cluster_id>/grafana/connections", methods=["GET"])
@require_auth(perms=["grafana.connector"])
def grafana_connections_list(cluster_id):
    """List registered Grafana connections (service-account tokens masked)."""
    denied = _graf_guard(cluster_id)
    if denied:
        return jsonify({"error": "Access denied"} if denied == 403 else {"error": "Cluster not found"}), denied
    conns = [
        {k: ("***" if k == "token" and v else v) for k, v in c.items()}
        for c in _grafana_connections.get(cluster_id, [])
    ]
    return jsonify({"cluster": html.escape(cluster_id), "connections": conns})


@bp.route("/api/clusters/<cluster_id>/grafana/connections", methods=["POST"])
@require_auth(perms=["grafana.connector"])
def grafana_connections_create(cluster_id):
    """Register a Grafana connection (base URL + service-account token)."""
    denied = _graf_guard(cluster_id)
    if denied:
        return jsonify({"error": "Access denied"} if denied == 403 else {"error": "Cluster not found"}), denied
    data = request.get_json() or {}
    name = str(data.get("name", "")).strip()
    url = str(data.get("url", "")).strip()
    token = str(data.get("token", "")).strip()
    if not name or not url or not token:
        return jsonify({"error": "name, url and token are required", "code": "missing_field"}), 400
    if not url.startswith(("https://", "http://")):
        return jsonify({"error": "url must be http(s)", "code": "invalid_field"}), 400
    conn = {
        "id": f"graf-{len(_grafana_connections.get(cluster_id, [])) + 1}",
        "name": name,
        "url": url,
        "token": token,
        "tls_verify": bool(data.get("tls_verify", True)),
        "reachable": True,
    }
    _grafana_connections.setdefault(cluster_id, []).append(conn)
    _graf_audit(cluster_id, "grafana.connection.create", f"Registered Grafana connection {name}")
    out = {k: ("***" if k == "token" else v) for k, v in conn.items()}
    return jsonify({"success": True, "cluster": html.escape(cluster_id), "connection": out})


@bp.route("/api/clusters/<cluster_id>/grafana/embed", methods=["GET"])
@require_auth(perms=["grafana.embed"])
def grafana_embed(cluster_id):
    """Dashboard embed configuration (iframe URLs, kiosk mode, theme)."""
    denied = _graf_guard(cluster_id)
    if denied:
        return jsonify({"error": "Access denied"} if denied == 403 else {"error": "Cluster not found"}), denied
    return jsonify({"cluster": html.escape(cluster_id),
                    "embed": {"dashboards": [], "kiosk": True, "theme": "dark"}})


@bp.route("/api/clusters/<cluster_id>/grafana/links", methods=["GET", "POST"])
@require_auth(perms=["grafana.link"])
def grafana_links(cluster_id):
    """Link Grafana dashboards/panels to ProxmoxVEx inventory objects."""
    denied = _graf_guard(cluster_id)
    if denied:
        return jsonify({"error": "Access denied"} if denied == 403 else {"error": "Cluster not found"}), denied
    if request.method == "GET":
        return jsonify({"cluster": html.escape(cluster_id),
                        "links": _grafana_links.get(cluster_id, [])})
    data = request.get_json() or {}
    link = data.get("link", {})
    if not isinstance(link, dict) or not link.get("dashboard") or not link.get("target"):
        return jsonify({"error": "link.dashboard and link.target are required", "code": "missing_field"}), 400
    _grafana_links.setdefault(cluster_id, []).append(link)
    _graf_audit(cluster_id, "grafana.link",
                f"Linked dashboard {link.get('dashboard')} to {link.get('target')}")
    return jsonify({"success": True, "cluster": html.escape(cluster_id), "link": link})


@bp.route("/api/clusters/<cluster_id>/grafana/annotations", methods=["POST"])
@require_auth(perms=["grafana.annotate"])
def grafana_annotations(cluster_id):
    """Push a ProxmoxVEx event (deploy, backup, incident) as a Grafana annotation."""
    denied = _graf_guard(cluster_id)
    if denied:
        return jsonify({"error": "Access denied"} if denied == 403 else {"error": "Cluster not found"}), denied
    data = request.get_json() or {}
    text = str(data.get("text", "")).strip()
    if not text:
        return jsonify({"error": "text is required", "code": "missing_field"}), 400
    _graf_audit(cluster_id, "grafana.annotate", "Annotation pushed to Grafana")
    return jsonify({"success": True, "cluster": html.escape(cluster_id),
                    "annotation": {"text": text, "tags": data.get("tags", []), "id": 0}})


@bp.route("/api/clusters/<cluster_id>/grafana/render", methods=["GET"])
@require_auth(perms=["grafana.render"])
def grafana_render(cluster_id):
    """Render a panel PNG via the Grafana renderer for reports and alerts."""
    denied = _graf_guard(cluster_id)
    if denied:
        return jsonify({"error": "Access denied"} if denied == 403 else {"error": "Cluster not found"}), denied
    dashboard = request.args.get("dashboard", "")
    panel = request.args.get("panel", "")
    return jsonify({"cluster": html.escape(cluster_id),
                    "render": {"dashboard": dashboard, "panel": panel,
                               "url": "", "status": "available"}})
