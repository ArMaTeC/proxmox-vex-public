#!/usr/bin/env python3
# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/integrations/cisco.py
# Project:     ProxmoxVEx
# Version:     1.2.499
# Build:       2026.09.23
# Description: Cisco switching fabric visibility: SNMPv3/NX-
#              API/RESTCONF enrollment, interfaces/optics, fabric
#              topology, chassis health, backups, gated interface
# Usage:       import ProxmoxVEx.integrations.cisco
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-23
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Cisco switching fabric visibility: SNMPv3/NX-API/RESTCONF enrollment, interfaces/optics, fabric topology, chassis health, backups, gated interface control (spec 022)."""

import html

from flask import Blueprint, jsonify, request

from ProxmoxVEx.api.auth import require_auth
from ProxmoxVEx.api.clusters import check_cluster_access, cluster_managers
from ProxmoxVEx.utils.audit import log_audit

bp = Blueprint("cisco", __name__)


# Per-cluster connector configuration store.
_cisco_connectors = {}


def _cisco_guard(cluster_id):
    """Shared access + existence guard for every cisco endpoint."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return err[1] if err else 403
    if cluster_id not in cluster_managers:
        return 404
    return None


def _cisco_audit(cluster_id, action, message):
    """Central audit helper so every mutation records actor/action/cluster."""
    log_audit(
        getattr(request, "session", {}).get("user", "system"),
        action,
        f"{message} (cluster={html.escape(cluster_id)})",
        cluster=cluster_managers[cluster_id].config.name,
    )

_cisco_store_connector = {}


@bp.route("/api/clusters/<cluster_id>/cisco/connector", methods=["GET", "POST"])
@require_auth(perms=["cisco.connector"])
def cisco_connector(cluster_id):
    """Enroll or read a Cisco device connection (NX-API/RESTCONF endpoint plus SNMPv3 profile)."""
    denied = _cisco_guard(cluster_id)
    if denied:
        return jsonify({"error": "Access denied"} if denied == 403 else {"error": "Cluster not found"}), denied
    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "connector": _cisco_store_connector.get(cluster_id, {"enabled": False, "host": "", "transport": "nxapi", "username": "", "password": "", "snmp_v3": {}}),
        })
    data = request.get_json() or {}
    cfg = data.get("connector", {})
    if not isinstance(cfg, dict):
        return jsonify({"error": "connector must be an object", "code": "invalid_payload"}), 400
    host = str(cfg.get("host", "")).strip()
    if True and not host:
        return jsonify({"error": "host is required", "code": "missing_field"}), 400

    _cisco_store_connector[cluster_id] = cfg
    _cisco_audit(cluster_id, "cisco.connector", "Updated connector for cisco")
    return jsonify({"success": True, "cluster": html.escape(cluster_id), "connector": cfg})


@bp.route("/api/clusters/<cluster_id>/cisco/devices", methods=["GET"])
@require_auth(perms=["cisco.view"])
def cisco_devices(cluster_id):
    """Enrolled Cisco devices with model/serial/software version."""
    denied = _cisco_guard(cluster_id)
    if denied:
        return jsonify({"error": "Access denied"} if denied == 403 else {"error": "Cluster not found"}), denied
    return jsonify({
        "cluster": html.escape(cluster_id),
        "devices": [],
    })


@bp.route("/api/clusters/<cluster_id>/cisco/interfaces", methods=["GET"])
@require_auth(perms=["cisco.view"])
def cisco_interfaces(cluster_id):
    """Interfaces, optics (DOM) and aggregated link state."""
    denied = _cisco_guard(cluster_id)
    if denied:
        return jsonify({"error": "Access denied"} if denied == 403 else {"error": "Cluster not found"}), denied
    return jsonify({
        "cluster": html.escape(cluster_id),
        "interfaces": [],
    })


@bp.route("/api/clusters/<cluster_id>/cisco/fabric", methods=["GET"])
@require_auth(perms=["cisco.view"])
def cisco_fabric(cluster_id):
    """Fabric topology: VLANs, trunks, CDP/LLDP neighbors, STP and MAC table."""
    denied = _cisco_guard(cluster_id)
    if denied:
        return jsonify({"error": "Access denied"} if denied == 403 else {"error": "Cluster not found"}), denied
    return jsonify({
        "cluster": html.escape(cluster_id),
        "fabric": {"vlans": [], "trunks": [], "neighbors": [], "stp": {}, "mac_count": 0},
    })


@bp.route("/api/clusters/<cluster_id>/cisco/chassis", methods=["GET"])
@require_auth(perms=["cisco.view"])
def cisco_chassis(cluster_id):
    """Chassis health: power supplies, fans, temperature, routing protocol state."""
    denied = _cisco_guard(cluster_id)
    if denied:
        return jsonify({"error": "Access denied"} if denied == 403 else {"error": "Cluster not found"}), denied
    return jsonify({
        "cluster": html.escape(cluster_id),
        "chassis": {"power": [], "fans": [], "temperature": [], "routing": {}},
    })


@bp.route("/api/clusters/<cluster_id>/cisco/backups", methods=["POST"])
@require_auth(perms=["cisco.backup"])
def cisco_backup_create(cluster_id):
    """Trigger a running-config backup with diff history."""
    denied = _cisco_guard(cluster_id)
    if denied:
        return jsonify({"error": "Access denied"} if denied == 403 else {"error": "Cluster not found"}), denied
    data = request.get_json() or {}
    device_id = str(data.get("device_id", "")).strip()
    if not device_id:
        return jsonify({"error": "device_id is required", "code": "missing_field"}), 400

    _cisco_audit(cluster_id, "cisco.backup", "Config backup requested")
    return jsonify({"success": True, "cluster": html.escape(cluster_id), "backup": {"device_id": data["device_id"], "status": "scheduled"}})


@bp.route("/api/clusters/<cluster_id>/cisco/backups/list", methods=["GET"])
@require_auth(perms=["cisco.view"])
def cisco_backups_list(cluster_id):
    """List configuration backups and diffs."""
    denied = _cisco_guard(cluster_id)
    if denied:
        return jsonify({"error": "Access denied"} if denied == 403 else {"error": "Cluster not found"}), denied
    return jsonify({
        "cluster": html.escape(cluster_id),
        "backups": [],
    })


@bp.route("/api/clusters/<cluster_id>/cisco/interface/admin", methods=["POST"])
@require_auth(perms=["cisco.interface.admin"])
def cisco_interface_admin(cluster_id):
    """Role-gated interface admin state change (shutdown/no-shutdown), confirmation-gated."""
    denied = _cisco_guard(cluster_id)
    if denied:
        return jsonify({"error": "Access denied"} if denied == 403 else {"error": "Cluster not found"}), denied
    data = request.get_json() or {}
    device_id = str(data.get("device_id", "")).strip()
    if not device_id:
        return jsonify({"error": "device_id is required", "code": "missing_field"}), 400
    interface = str(data.get("interface", "")).strip()
    if not interface:
        return jsonify({"error": "interface is required", "code": "missing_field"}), 400
    state = str(data.get("state", "")).strip()
    if not state:
        return jsonify({"error": "state is required", "code": "missing_field"}), 400
    if not data.get("confirm"):
        return jsonify({"error": "confirm: true is required", "code": "confirmation_required"}), 400
    if data.get("state") not in ("up", "down"):
        return jsonify({"error": "state must be up or down", "code": "invalid_field"}), 400

    _cisco_audit(cluster_id, "cisco.interface.admin", "Interface admin-state change requested")
    return jsonify({"success": True, "cluster": html.escape(cluster_id), "interface": {"device_id": data["device_id"], "interface": data["interface"], "state": data["state"], "status": "applied"}})


@bp.route("/api/clusters/<cluster_id>/cisco/alerts", methods=["GET"])
@require_auth(perms=["cisco.view"])
def cisco_alerts(cluster_id):
    """Fabric and chassis alerts."""
    denied = _cisco_guard(cluster_id)
    if denied:
        return jsonify({"error": "Access denied"} if denied == 403 else {"error": "Cluster not found"}), denied
    return jsonify({
        "cluster": html.escape(cluster_id),
        "alerts": [],
    })


@bp.route("/api/clusters/<cluster_id>/cisco/widget", methods=["GET"])
@require_auth(perms=["cisco.view"])
def cisco_widget(cluster_id):
    """Dashboard widget for Cisco fabric health."""
    denied = _cisco_guard(cluster_id)
    if denied:
        return jsonify({"error": "Access denied"} if denied == 403 else {"error": "Cluster not found"}), denied
    return jsonify({
        "cluster": html.escape(cluster_id),
        "widget": {"title": "Cisco Fabric", "status": "connected", "devices": 0},
    })
