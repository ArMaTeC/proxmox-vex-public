# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/converter/__init__.py
# Project:     ProxmoxVEx
# Version:     1.2.499
# Build:       2026.09.23
# Description: ProxmoxVEx Converter Module Built-in LXC ↔ VM
#              conversion, disk resize, and clone-replace operations.
# Usage:       import ProxmoxVEx.converter
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-23
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""
ProxmoxVEx Converter Module
Built-in LXC ↔ VM conversion, disk resize, and clone-replace operations.
"""
