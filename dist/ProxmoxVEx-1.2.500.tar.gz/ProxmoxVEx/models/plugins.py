# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/models/plugins.py
# Project:     ProxmoxVEx
# Version:     1.2.499
# Build:       2026.09.23
# Description: Plugin/native-integration tier registry for license
#              enforcement.
# Usage:       import ProxmoxVEx.models.plugins
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-23
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Plugin/native-integration tier registry for license enforcement.

Plugins under plugins/<id>/manifest.json self-declare their required tier via
a "min_license_tier" field (added per-plugin based on complexity). This scans
the manifests instead of a hand-maintained mapping so new plugins are covered
automatically as long as their manifest declares a tier (missing/absent
means "basic" - i.e. included with any active license).

Native integrations (ProxmoxVEx/native/<id>/) are a fixed, built-in set that
doesn't grow via user-installed plugins, so their tier requirements are kept
in a small static map here instead.
"""

import json
import logging
import time
from pathlib import Path

from ProxmoxVEx.constants import PLUGINS_DIR

TIER_RANK = {"community": 0, "basic": 0, "advanced": 1, "corporate": 2}

VALID_TIERS = set(TIER_RANK)

# Built-in native integrations under ProxmoxVEx/native/<id>/ - fixed set,
# not user-installable, so a static map is appropriate here.
NATIVE_INTEGRATION_TIERS = {
    "active_directory": "advanced",
    "docker_swarm": "advanced",
    "netapp_storage": "corporate",
    "opnsense": "advanced",
    "pfsense": "advanced",
    "portainer_rancher": "advanced",
    "proxmox_backup_server": "basic",
    "truenas": "advanced",
    "vmware_vcenter": "corporate",
    "vyos": "advanced",
    "zabbix": "advanced",
}

_manifest_cache: dict[str, str] = {}
_manifest_cache_at = 0.0
_MANIFEST_CACHE_TTL_SECONDS = 30


def _load_plugin_tiers() -> dict[str, str]:
    """Scan plugins/<id>/manifest.json for min_license_tier, cached briefly."""
    tiers: dict[str, str] = {}
    plugins_path = Path(PLUGINS_DIR)
    if plugins_path.exists():
        for d in plugins_path.iterdir():
            if not d.is_dir() or d.name.startswith(("_", ".")):
                continue
            manifest_file = d / "manifest.json"
            if not manifest_file.exists():
                continue
            try:
                with open(manifest_file, encoding="utf-8") as f:
                    manifest = json.load(f)
                tier = manifest.get("min_license_tier", "basic")
                if tier not in VALID_TIERS:
                    tier = "basic"
                tiers[d.name] = tier
            except Exception as e:
                logging.warning("[LICENSING] Failed to read manifest for %s: %s", d.name, e)
                tiers[d.name] = "basic"

    # License-gated plugins are no longer shipped in the install package, so
    # their manifest.json is absent until downloaded. Fall back to the plugin
    # catalog's declared tier so they are not silently treated as "basic"
    # before installation (spec 036-plugin-license-delivery).
    catalog_file = plugins_path / "directory.json"
    if catalog_file.exists():
        try:
            with open(catalog_file, encoding="utf-8") as f:
                catalog = json.load(f)
            for entry in catalog.get("plugins", []):
                slug = entry.get("slug")
                if not slug or slug in tiers:
                    continue
                if not (entry.get("is_paid") or entry.get("download_required")):
                    continue
                tier = entry.get("min_tier_slug", "basic")
                tiers[slug] = tier if tier in VALID_TIERS else "basic"
        except Exception as e:
            logging.warning("[LICENSING] Failed to read plugin directory: %s", e)
    return tiers


def get_plugin_tier_requirement(plugin_id: str) -> str:
    """Return the minimum license tier slug required to use a plugin.

    Defaults to "basic" (included with any active license) for plugins with
    no manifest or no declared tier, so an undeclared plugin never silently
    becomes unusable.
    """
    global _manifest_cache, _manifest_cache_at
    now = time.monotonic()
    if now - _manifest_cache_at > _MANIFEST_CACHE_TTL_SECONDS:
        _manifest_cache = _load_plugin_tiers()
        _manifest_cache_at = now
    return _manifest_cache.get(plugin_id, "basic")


def get_native_tier_requirement(module_id: str) -> str:
    """Return the minimum license tier slug required to use a native integration."""
    return NATIVE_INTEGRATION_TIERS.get(module_id, "basic")


def read_plugin_manifest(plugin_id: str) -> dict | None:
    """Read plugins/<id>/manifest.json, returning None when absent/unreadable."""
    manifest_file = Path(PLUGINS_DIR) / plugin_id / "manifest.json"
    try:
        with open(manifest_file, encoding="utf-8") as f:
            manifest = json.load(f)
        return manifest if isinstance(manifest, dict) else None
    except Exception:
        return None


def get_plugin_permissions(plugin_id: str) -> list[str]:
    """Return the manifest-declared permission scopes for a plugin.

    Spec 092/US054: the host bridge limits plugins to these scopes, so a
    manifest with no `permissions` array yields [] (deny-by-default on the
    scoped bridge surface). Read per-call so manifest edits take effect on
    the next request without a plugin reload.
    """
    manifest = read_plugin_manifest(plugin_id) or {}
    perms = manifest.get("permissions", [])
    return [p for p in perms if isinstance(p, str)] if isinstance(perms, list) else []
