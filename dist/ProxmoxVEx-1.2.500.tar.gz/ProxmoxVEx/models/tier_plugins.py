# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/models/tier_plugins.py
# Project:     ProxmoxVEx
# Version:     1.2.499
# Build:       2026.09.23
# Description: Tier-to-plugin allow-list model.
# Usage:       import ProxmoxVEx.models.tier_plugins
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-23
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Tier-to-plugin allow-list model.

Stores which plugin slugs are permitted for each license tier.  When a
configuration exists for a tier, it takes precedence over the manifest's
"min_license_tier" declaration, allowing admins to customise plugin
availability per subscription level.
"""

from typing import List, Optional


def ensure_tier_plugins_table(conn) -> None:
    """Create the tier_plugins table if it does not yet exist."""
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS tier_plugins (
            tier_slug TEXT NOT NULL,
            plugin_slug TEXT NOT NULL,
            PRIMARY KEY (tier_slug, plugin_slug)
        )
        """
    )


def get_tier_plugins(conn, tier_slug: str) -> Optional[List[str]]:
    """Return the allowed plugin slugs for a tier, or None if not configured."""
    cur = conn.execute(
        "SELECT plugin_slug FROM tier_plugins WHERE tier_slug = ?",
        (tier_slug,),
    )
    rows = cur.fetchall()
    if not rows:
        return None
    return [row[0] for row in rows]


def set_tier_plugins(conn, tier_slug: str, plugin_slugs: List[str]) -> None:
    """Replace the allowed plugin list for a tier."""
    conn.execute("DELETE FROM tier_plugins WHERE tier_slug = ?", (tier_slug,))
    if plugin_slugs:
        conn.executemany(
            "INSERT INTO tier_plugins (tier_slug, plugin_slug) VALUES (?, ?)",
            [(tier_slug, slug) for slug in set(plugin_slugs)],
        )
    conn.commit()
