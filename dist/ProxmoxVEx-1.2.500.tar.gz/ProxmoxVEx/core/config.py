# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/core/config.py
# Project:     ProxmoxVEx
# Version:     1.2.499
# Build:       2026.09.23
# Description: ProxmoxVEx Config Management - Layer 3 Encryption key
#              management and config load/save.
# Usage:       import ProxmoxVEx.core.config
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-23
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""
ProxmoxVEx Config Management - Layer 3
Encryption key management and config load/save.
"""

import json
import logging
import os
import re
from pathlib import Path

from ProxmoxVEx.constants import CONFIG_FILE_ENCRYPTED
from ProxmoxVEx.core.db import ENCRYPTION_AVAILABLE, get_db
from ProxmoxVEx.globals import cluster_managers

try:
    from cryptography.fernet import Fernet
except ImportError:  # optional dep — ENCRYPTION_AVAILABLE (core.db) gates all uses
    # explicit None binding (vs suppress()) keeps the name defined so type
    # checkers don't flag uses as possibly-unbound
    # Assigning None over an imported class trips both [misc] (assign to a
    # type) and [assignment] (None vs type[Fernet]) — suppress both.
    Fernet = None  # type: ignore[assignment,misc]


def get_or_create_encryption_key():
    """Get the master key — now resolved by `ProxmoxVEx.core.keystore`.

    Kept as a back-compat shim so older imports (audit.py, plugins) keep
    working.  The actual resolution logic moved to keystore.load_master_key()
    which supports systemd LoadCredentialEncrypted, env vars, /etc/ProxmoxVEx/,
    user-config and the legacy CONFIG_DIR location (in priority order).

    (Stufe 1+2 of the security-review response).
    """
    if not ENCRYPTION_AVAILABLE:
        return None
    try:
        from ProxmoxVEx.core.keystore import load_master_key

        return load_master_key().key_b64
    except Exception as e:
        logging.error(f"[CONFIG] keystore.load_master_key() failed: {e}")
        return None


def get_fernet():
    """Get Fernet encryption instance"""
    # `Fernet is None` restates the ENCRYPTION_AVAILABLE correlation so the
    # checker knows the name is bound before the call below.
    if not ENCRYPTION_AVAILABLE or Fernet is None:
        return None

    key = get_or_create_encryption_key()
    if key:
        return Fernet(key)
    return None


def load_config():
    """Load configuration from SQLite database

    refactored to use SQLite
    Automatically migrates existing JSON/encrypted files on first run
    """
    logging.info("=== Loading config from SQLite ===")

    try:
        db = get_db()
        config = db.get_all_clusters()

        if config:
            logging.info(f"✓ Loaded {len(config)} clusters from SQLite: {list(config.keys())}")
            return config
        else:
            logging.info("No clusters in database yet")
            return {}
    except Exception as e:
        logging.error(f"Failed to load config from database: {e}")
        import traceback

        logging.error(traceback.format_exc())

        # Emergency fallback to legacy files
        logging.info("Attempting legacy fallback...")
        return _load_config_legacy()


def _load_config_legacy():
    """Legacy config loader - used as fallback if database fails

    Plain-JSON CONFIG_FILE (clusters.JSON) fallback dropped. The
    only legacy path still trusted here is the Fernet-encrypted .enc file (which
    was already encrypted-at-rest). A plain-text spill would defeat the whole
    SQLCipher migration done in v0.9.10. If both DB load and the .enc fallback
    fail, return empty and let the caller deal with it — operator has to fix the
    DB, not bring back a JSON file.
    """
    fernet = get_fernet()

    # Encrypted-only legacy fallback
    if fernet and os.path.exists(CONFIG_FILE_ENCRYPTED):
        try:
            with open(CONFIG_FILE_ENCRYPTED, "rb") as f:
                encrypted_data = f.read()
            decrypted_data = fernet.decrypt(encrypted_data)
            config = json.loads(decrypted_data.decode("utf-8"))
            if config:
                logging.info(f"✓ Loaded {len(config)} clusters from legacy encrypted file")
                return config
        except Exception as e:
            logging.error(f"Failed to load legacy encrypted config: {e}")

    return {}


def save_config():
    """Save configuration to SQLite database

    SQLite instead of JSON now
    """
    if not cluster_managers:
        logging.warning("save_config called with no clusters - skipping")
        return False

    try:
        db = get_db()

        for cluster_id, manager in cluster_managers.items():
            try:
                # Sanitize fallback_hosts
                fallback_hosts = getattr(manager.config, "fallback_hosts", []) or []
                if not isinstance(fallback_hosts, list):
                    fallback_hosts = []
                fallback_hosts = [str(h) for h in fallback_hosts if h]

                cluster_data = {
                    "name": manager.config.name,
                    "host": manager.config.host,
                    "user": manager.config.user,
                    "pass": manager.config.pass_,
                    "ssl_verification": getattr(manager.config, "ssl_verification", True),
                    "migration_threshold": getattr(manager.config, "migration_threshold", 30),
                    "migration_tolerance": getattr(manager.config, "migration_tolerance", 10),
                    "check_interval": getattr(manager.config, "check_interval", 300),
                    "auto_migrate": getattr(manager.config, "auto_migrate", False),
                    "balance_containers": getattr(manager.config, "balance_containers", False),
                    "balance_local_disks": getattr(manager.config, "balance_local_disks", False),
                    "proxlb_tags_enabled": bool(getattr(manager.config, "proxlb_tags_enabled", False)),
                    "dry_run": getattr(manager.config, "dry_run", False),
                    "enabled": getattr(manager.config, "enabled", True),
                    "ha_enabled": getattr(manager.config, "ha_enabled", False),
                    "fallback_hosts": fallback_hosts,
                    "ssh_user": getattr(manager.config, "ssh_user", ""),
                    "ssh_key": getattr(manager.config, "ssh_key", ""),
                    "ssh_port": getattr(manager.config, "ssh_port", 22),
                    "ha_settings": getattr(manager.config, "ha_settings", {}),
                    "excluded_nodes": getattr(manager.config, "excluded_nodes", []),
                    "api_token_user": getattr(manager.config, "api_token_user", ""),
                    "api_token_secret": getattr(manager.config, "api_token_secret", ""),
                    "cluster_type": getattr(manager, "cluster_type", "proxmox"),
                    "vnc_tunnel": bool(getattr(manager.config, "vnc_tunnel", False)),  # Apr 2026
                    # (#364) - load-balancer settings used to be set
                    # on the in-memory config object but never made it into the
                    # save dict, so they reverted on the next reload.
                    "predictive_balancing": bool(getattr(manager.config, "predictive_balancing", False)),
                    "predictive_threshold": float(getattr(manager.config, "predictive_threshold", 0.0) or 0.0),
                    "balance_cpu_weight": float(getattr(manager.config, "balance_cpu_weight", 1.0) or 1.0),
                    "balance_mem_weight": float(getattr(manager.config, "balance_mem_weight", 1.0) or 1.0),
                    "balance_io_weight": float(getattr(manager.config, "balance_io_weight", 1.0) or 1.0),
                    "cpu_baseline": getattr(manager.config, "cpu_baseline", "") or "",
                    "backup_sla_max_age_hours": int(getattr(manager.config, "backup_sla_max_age_hours", 0) or 0),
                    # Proxmox API port override (default 8006). Direct-TLS only.
                    "api_port": int(getattr(manager.config, "api_port", 8006) or 8006),
                }

                db.save_cluster(cluster_id, cluster_data)
            except Exception as e:
                logging.error(f"Error saving cluster {cluster_id}: {e}")
                continue

        logging.debug(f"Saved {len(cluster_managers)} clusters to SQLite")
        return True

    except Exception as e:
        logging.error(f"Failed to save config to database: {e}")
        return False


# ── spec 092/US085: boot-time env validation ──
# Misconfig must abort startup naming the variable and the fix — a typo'd
# DSN otherwise surfaces as a cryptic psycopg2 error at first query, and a
# bad port as a silent fallback to a port the operator didn't ask for.

_PORT_ENV_VARS = (
    "PROXMOXVEX_PORT",
    "PROXMOXVEX_HTTP_PORT",
    "PROXMOXVEX_VNC_WS_PORT",
    "PROXMOXVEX_SSH_WS_PORT",
)
# Kubernetes injects tcp://<cluster-ip>:<port> when a Service is named
# proxmoxvex — the same form app.py's runtime port parser accepts.
_K8S_PORT_RE = re.compile(r"^tcp://[^:]*:(\d+)$")


class ConfigError(Exception):
    """Fatal startup misconfiguration — carries the full actionable list."""


def validate_startup_config(env=None):
    """Validate env config before serving; return (errors, warnings).

    errors   — boot must abort; each names the variable + how to fix it.
    warnings — insecure defaults that still allow boot (logged loudly).
    """
    env = os.environ if env is None else env
    errors: list[str] = []
    warnings: list[str] = []

    # PostgreSQL is the only supported backend — anything else fails later
    # with a driver error that never mentions the env var.
    url = (env.get("PROXMOXVEX_DATABASE_URL") or "").strip()
    if url and not url.startswith(("postgres://", "postgresql://")):
        errors.append(
            "PROXMOXVEX_DATABASE_URL is not a PostgreSQL DSN — "
            "set e.g. postgresql://user:pass@host:5432/proxmoxvex (or unset for the localhost default)"
        )

    for var in _PORT_ENV_VARS:
        v = (env.get(var) or "").strip()
        if not v:
            continue
        m = _K8S_PORT_RE.match(v)
        raw = m.group(1) if m else v
        if not raw.isdigit() or not (1 <= int(raw) <= 65535):
            errors.append(f"{var}={v!r} is not a usable port — set an integer 1-65535 or unset it")

    # The shipped demo token secret forges demo sessions — fine for the
    # local sandbox it's meant for, dangerous anywhere reachable.
    from ProxmoxVEx.demo import DEMO_ENV_VAR

    if (env.get(DEMO_ENV_VAR) or "").lower() in ("1", "true", "yes"):
        secret = env.get("PROXMOXVEX_DEMO_TOKEN_SECRET", "demo-secret-change-in-production")
        if secret == "demo-secret-change-in-production":
            warnings.append(
                "PROXMOXVEX_DEMO_TOKEN_SECRET is the shipped default — demo sessions are forgeable; "
                "set a random value (openssl rand -hex 32) if this instance is reachable"
            )

    return errors, warnings


# ---------------------------------------------------------------------------
# spec 092/US092: read-only root filesystem support.
#
# When the container runs with `read_only: true`, every path the app writes
# to must be an explicit mount. The image carries a pristine plugin copy at
# /app/plugins-seed because a fresh /app/plugins volume starts empty and
# would shadow the shipped plugin set; ensure_plugins_seeded restores it on
# first boot only — an already-populated volume is never overwritten, so
# installed plugin upgrades stay authoritative.
# ---------------------------------------------------------------------------

PLUGINS_SEED_DIR = os.environ.get("PROXMOXVEX_PLUGINS_SEED", "/app/plugins-seed")


def writable_paths_report(paths):
    """Map each path -> True when it accepts writes. Used by the boot check
    to name the missing mount instead of failing deep inside a request."""
    report = {}
    for path, _label in paths:
        p = str(path)
        if os.access(p, os.W_OK):
            report[p] = True
            continue
        if os.path.exists(p):
            # An existing dir that isn't writable rejects writes outright —
            # don't soften that to a parent check.
            report[p] = False
            continue
        # A path may not exist yet on a writable parent — probe the parent.
        parent = os.path.dirname(p) or "."
        report[p] = os.path.exists(parent) and os.access(parent, os.W_OK)
    return report


def required_writable_paths():
    """The persistent/scratch paths ProxmoxVEx writes to at runtime — every
    entry must be a volume or tmpfs when the rootfs is read-only."""
    import tempfile

    from ProxmoxVEx.constants import CONFIG_DIR, LOG_DIR, PLUGINS_DIR

    root = os.path.abspath(".")
    return [
        (CONFIG_DIR, "config volume (settings, keys, backups)"),
        (os.path.join(root, LOG_DIR), "logs volume"),
        (os.path.join(root, PLUGINS_DIR), "plugins volume (install/update)"),
        (tempfile.gettempdir(), "tmpfs /tmp"),
    ]


def check_writable_paths(log=None):
    """Warn at boot when a required write path is unwritable — the operator
    sees the missing mount name, not a late crash mid-request. Returns the
    list of (path, label) that failed; non-fatal by design."""
    failed = []
    report = writable_paths_report(required_writable_paths())
    for path, label in required_writable_paths():
        if not report.get(str(path)):
            failed.append((str(path), label))
    if failed and log is not None:
        for path, label in failed:
            log.warning(
                "[STARTUP] %s is not writable (%s) — on a read-only rootfs "
                "deployment add a volume or tmpfs mount for this path",
                path,
                label,
            )
    return failed


def ensure_plugins_seeded(plugins_dir=None, seed_dir=None):
    """First-boot seeding: copy the shipped plugin set into an empty plugins
    volume. No-op when the target already has content or no seed exists."""
    import shutil

    from ProxmoxVEx.constants import PLUGINS_DIR

    target = Path(plugins_dir) if plugins_dir else Path(PLUGINS_DIR)
    seed = Path(seed_dir) if seed_dir else Path(PLUGINS_SEED_DIR)
    if not seed.is_dir():
        return False
    if not target.is_dir():
        # A missing plugins dir only appears on layouts without the baked
        # tree — create it when the parent is writable (fresh volume root).
        try:
            target.mkdir(parents=True)
        except OSError:
            return False
    if any(target.iterdir()):
        return False
    for entry in seed.iterdir():
        dest = target / entry.name
        if entry.is_dir():
            shutil.copytree(entry, dest)
        else:
            shutil.copy2(entry, dest)
    return True
