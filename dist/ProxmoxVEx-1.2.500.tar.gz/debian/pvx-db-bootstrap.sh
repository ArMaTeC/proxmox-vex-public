#!/bin/sh
# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        debian/pvx-db-bootstrap.sh
# Project:     ProxmoxVEx
# Version:     1.2.499
# Build:       2026.09.23
# Description: Pvx Db Bootstrap SH source
# Usage:       bash debian/pvx-db-bootstrap.sh
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-23
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
set -u

[ -n "${PROXMOXVEX_DATABASE_URL:-}" ] && exit 0
command -v pg_isready >/dev/null 2>&1 || exit 0

DBUSER="${PGUSER:-proxmoxvex}"
DBPASS="${PGPASSWORD:-proxmoxvex}"
DBNAME="${PGDATABASE:-proxmoxvex}"
DBHOST="${PGHOST:-localhost}"

# Only bootstrap a local server; remote PGHOST values are the operator's job.
case "$DBHOST" in
    localhost|127.0.0.1|::1|"") ;;
    *) exit 0 ;;
esac

# Postgres may still be starting (we only order After=postgresql.service,
# which can finish before the cluster accepts connections).
i=0
while [ "$i" -lt 30 ]; do
    pg_isready -q -h "$DBHOST" -p "${PGPORT:-5432}" && break
    i=$((i + 1))
    sleep 1
done
pg_isready -q -h "$DBHOST" -p "${PGPORT:-5432}" || exit 0

su -s /bin/sh postgres -c \
    "psql -tAc \"SELECT 1 FROM pg_roles WHERE rolname='$DBUSER'\"" \
    | grep -q 1 || su -s /bin/sh postgres -c \
    "psql -c \"CREATE ROLE $DBUSER LOGIN PASSWORD '$DBPASS'\""
su -s /bin/sh postgres -c \
    "psql -tAc \"SELECT 1 FROM pg_database WHERE datname='$DBNAME'\"" \
    | grep -q 1 || su -s /bin/sh postgres -c \
    "createdb -O $DBUSER $DBNAME"
exit 0
