<!-- GENERATED:START -->
# Compliance Frameworks & Hardening Assessment

`compliance-frameworks` v1.0.0

Assess clusters against versioned control catalogs (CIS Controls v8.1, NIST SP 800-53 r5 subset, NIST SP 800-171 r2, ISO/IEC 27001:2022 Annex A, CMMC L2): automated node-hardening and CVE checks crosswalk into every enabled framework, manual controls resolve via attestation, and auditor-facing evidence reports export as HTML.

**Author:** ProxmoxVEx Team | **Category:** Security | **License tier:** `corporate` | **Requires ProxmoxVEx:** ≥ 1.2.23 | **Trusted:** True

## Permissions
- `clusters:read`
- `nodes:read`

## Configuration
_No config schema declared._

## Events subscribed
_None._
<!-- GENERATED:END -->
