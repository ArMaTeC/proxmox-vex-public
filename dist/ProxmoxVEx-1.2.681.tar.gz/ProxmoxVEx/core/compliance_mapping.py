# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/core/compliance_mapping.py
# Project:     ProxmoxVEx
# Version:     1.2.674
# Build:       2026.10.21
# Description: Compliance framework control mappings for ProxmoxVEx
#              hardening checks.
# Usage:       import ProxmoxVEx.core.compliance_mapping
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-10-21
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Compliance framework control mappings for ProxmoxVEx hardening checks.

Maps internal hardening control IDs (e.g. 'pam_faillock') to the corresponding
control references in major compliance frameworks.

This is best-effort technical coverage mapping, NOT a substitute for a formal
compliance audit. Every audit deliverable should be reviewed by a qualified
compliance SME against the current revision of the applicable framework.

Frameworks covered:
- CMMC L1                        (FAR 52.204-21, 17 basic safeguarding requirements)
- CMMC L2 / NIST SP 800-171 R2   (110 controls, 14 families)
- NIST SP 800-53 R5 (Mod)        (federal civilian baseline)
- DISA STIG (RHEL 9 / Ubuntu 22) (where a direct rule is known; STIG rules
                                  are versioned, refs may need refresh per release)
- ISO/IEC 27001:2022 Annex A     (93 controls, 4 themes)
- BSI IT-Grundschutz Kompendium  (modules SYS / OPS / NET / DER / CON / APP)
- VS-NfD                         (largely a profile over BSI Grundschutz +
                                  ProxmoxVEx-specific informational checks)

Where a control has no direct mapping in a given framework, the entry is
omitted (do NOT fabricate refs). The PDF generator surfaces 'no direct mapping'
explicitly so reviewers see the gap rather than a fake reference.
"""

# Family code → human-readable label.
# Codes are framework-specific; NIST 800-171 and 800-53 use the same letters
# for the most part (AC, AU, CM, IA, SC, SI etc.).
FAMILY_LABELS = {
    "AC": "Access Control",
    "AT": "Awareness and Training",
    "AU": "Audit and Accountability",
    "CA": "Assessment, Authorization, and Monitoring",
    "CM": "Configuration Management",
    "CP": "Contingency Planning",
    "IA": "Identification and Authentication",
    "IR": "Incident Response",
    "MA": "Maintenance",
    "MP": "Media Protection",
    "PE": "Physical Protection",
    "PL": "Planning",
    "PS": "Personnel Security",
    "RA": "Risk Assessment",
    "SA": "System and Services Acquisition",
    "SC": "System and Communications Protection",
    "SI": "System and Information Integrity",
    "SR": "Supply Chain Risk Management",
    # ISO 27001:2022 Annex A themes
    "A.5": "Organizational controls",
    "A.6": "People controls",
    "A.7": "Physical controls",
    "A.8": "Technological controls",
    # BSI IT-Grundschutz layer codes (subset)
    "SYS": "IT-Systeme",
    "OPS": "Betrieb",
    "NET": "Netze und Kommunikation",
    "DER": "Detektion und Reaktion",
    "CON": "Konzeption und Vorgehensweise",
    # ANSSI-BP-028 section codes (French) — used by Diffusion Restreinte + RGS
    "materiel": "Configuration matérielle",
    "noyau": "Configuration du noyau Linux",
    "partitionnement": "Partitionnement système",
    "comptes": "Comptes d'accès",
    "controle_acces": "Contrôle d'accès",
    "fichiers": "Fichiers et répertoires",
    "paquets": "Gestion des paquets",
    "services": "Configuration des services",
    "journalisation": "Journalisation",
    "surveillance": "Surveillance du système de fichiers",
    "APP": "Anwendungen",
    # PCI DSS v4.0 — principal requirement numbers used as families
    "PCI-2": "Req 2 — Apply Secure Configurations to All System Components",
    "PCI-3": "Req 3 — Protect Stored Account Data",
    "PCI-6": "Req 6 — Develop and Maintain Secure Systems and Software",
    "PCI-7": "Req 7 — Restrict Access by Business Need to Know",
    "PCI-8": "Req 8 — Identify Users and Authenticate Access",
    "PCI-10": "Req 10 — Log and Monitor All Access",
    "PCI-11": "Req 11 — Test Security of Systems and Networks",
    # HIPAA Security Rule — 45 CFR §164.312 technical safeguards
    "164.312(a)": "Access Control",
    "164.312(b)": "Audit Controls",
    "164.312(c)": "Integrity",
    "164.312(d)": "Person or Entity Authentication",
    "164.312(e)": "Transmission Security",
    # SOC 2 Trust Services Criteria
    "CC6": "Logical and Physical Access Controls",
    "CC7": "System Operations",
    # CIS Critical Security Controls v8.1 — section numbers
    "CIS-3": "Data Protection",
    "CIS-4": "Secure Configuration of Enterprise Assets and Software",
    "CIS-5": "Account Management",
    "CIS-8": "Audit Log Management",
    "CIS-10": "Malware Defenses",
    "CIS-13": "Network Monitoring and Defense",
    # ENS (RD 311/2022) — Anexo II measure groups (Spanish names kept verbatim)
    "op.acc": "Control de acceso",
    "op.exp": "Explotación",
    "op.mon": "Monitorización",
    "mp.com": "Comunicaciones",
    "mp.si": "Soportes de información",
    # Cyber Essentials — the five technical control themes
    "CE-FW": "Firewalls",
    "CE-SC": "Secure Configuration",
    "CE-UAC": "User Access Control",
    "CE-MP": "Malware Protection",
    "CE-SUM": "Security Update Management",
    # Catch-all
    "OTHER": "Other / Cross-cutting",
}


# ──────────────────────────────────────────────────────────────────────────
# Per-framework: { internal_control_id: [ {ref, title, family} ... ] }
#
# An internal control may map to multiple framework controls (1:N) — the
# common case for things like ssh_crypto which covers both crypto strength
# (IA / SC) and integrity protection (SC).
# ──────────────────────────────────────────────────────────────────────────

# CMMC Level 2 = NIST SP 800-171 R2 mapping. Refs use the CMMC notation
# (e.g. AC.L2-3.1.8) which embeds the NIST 800-171 control number (3.1.8).
CMMC_L2_NIST_171 = {
    "pam_faillock": [
        {"ref": "AC.L2-3.1.8", "family": "AC", "title": "Limit unsuccessful logon attempts"},
    ],
    "session_limit": [
        {"ref": "AC.L2-3.1.10", "family": "AC", "title": "Use session lock with pattern-hiding displays"},
        {"ref": "AC.L2-3.1.11", "family": "AC", "title": "Terminate user session after defined condition"},
    ],
    "shell_timeout": [
        {"ref": "AC.L2-3.1.11", "family": "AC", "title": "Terminate user session after defined condition"},
    ],
    "login_banners": [
        {
            "ref": "AC.L2-3.1.9",
            "family": "AC",
            "title": "Provide privacy and security notices consistent with applicable CUI rules",
        },
    ],
    "inactive_accounts": [
        {"ref": "IA.L2-3.5.6", "family": "IA", "title": "Disable identifiers after a defined period of inactivity"},
    ],
    "pw_quality": [
        {
            "ref": "IA.L2-3.5.7",
            "family": "IA",
            "title": "Enforce minimum password complexity and change of characters when new passwords are created",
        },
    ],
    "pw_history": [
        {
            "ref": "IA.L2-3.5.8",
            "family": "IA",
            "title": "Prohibit password reuse for a specified number of generations",
        },
    ],
    "pw_aging": [
        {"ref": "IA.L2-3.5.6", "family": "IA", "title": "Disable identifiers after a defined period of inactivity"},
    ],
    "pw_hash_rounds": [
        {
            "ref": "IA.L2-3.5.10",
            "family": "IA",
            "title": "Store and transmit only cryptographically-protected passwords",
        },
    ],
    "ssh_crypto": [
        {
            "ref": "IA.L2-3.5.10",
            "family": "IA",
            "title": "Store and transmit only cryptographically-protected passwords",
        },
        {
            "ref": "SC.L2-3.13.11",
            "family": "SC",
            "title": "Employ FIPS-validated cryptography when used to protect the confidentiality of CUI",
        },
    ],
    "ssh_perms": [
        {"ref": "AC.L2-3.1.5", "family": "AC", "title": "Employ the principle of least privilege"},
        {"ref": "CM.L2-3.4.6", "family": "CM", "title": "Employ the principle of least functionality"},
    ],
    "file_perms": [
        {"ref": "AC.L2-3.1.5", "family": "AC", "title": "Employ the principle of least privilege"},
        {
            "ref": "AU.L2-3.3.8",
            "family": "AU",
            "title": "Protect audit information and audit logging tools from unauthorized access",
        },
    ],
    "default_umask": [
        {"ref": "AC.L2-3.1.5", "family": "AC", "title": "Employ the principle of least privilege"},
    ],
    "apparmor": [
        {"ref": "AC.L2-3.1.5", "family": "AC", "title": "Employ the principle of least privilege"},
        {
            "ref": "CM.L2-3.4.7",
            "family": "CM",
            "title": "Restrict, disable, prevent the use of nonessential programs, functions, ports, protocols and services",
        },
    ],
    "fs_modules": [
        {
            "ref": "CM.L2-3.4.7",
            "family": "CM",
            "title": "Restrict, disable, prevent the use of nonessential programs, functions, ports, protocols and services",
        },
        {"ref": "CM.L2-3.4.6", "family": "CM", "title": "Employ the principle of least functionality"},
    ],
    "usb_storage": [
        {"ref": "MP.L2-3.8.7", "family": "MP", "title": "Control the use of removable media on system components"},
        {
            "ref": "MP.L2-3.8.8",
            "family": "MP",
            "title": "Prohibit the use of portable storage devices when such devices have no identifiable owner",
        },
    ],
    "mount_options": [
        {"ref": "CM.L2-3.4.6", "family": "CM", "title": "Employ the principle of least functionality"},
        {
            "ref": "SC.L2-3.13.4",
            "family": "SC",
            "title": "Prevent unauthorized and unintended information transfer via shared system resources",
        },
    ],
    "core_dumps": [
        {"ref": "SC.L2-3.13.16", "family": "SC", "title": "Protect the confidentiality of CUI at rest"},
    ],
    "audit_rules": [
        {"ref": "AU.L2-3.3.1", "family": "AU", "title": "Create and retain system audit logs and records"},
        {
            "ref": "AU.L2-3.3.2",
            "family": "AU",
            "title": "Ensure that the actions of individual system users can be uniquely traced",
        },
    ],
    "audit_boot": [
        {"ref": "AU.L2-3.3.4", "family": "AU", "title": "Alert in the event of an audit logging process failure"},
    ],
    "auditd_service": [
        {"ref": "AU.L2-3.3.1", "family": "AU", "title": "Create and retain system audit logs and records"},
    ],
    "audit_immutable": [
        {
            "ref": "AU.L2-3.3.8",
            "family": "AU",
            "title": "Protect audit information and audit logging tools from unauthorized access",
        },
        {
            "ref": "AU.L2-3.3.9",
            "family": "AU",
            "title": "Limit management of audit logging functionality to a subset of privileged users",
        },
    ],
    "aide_audit_protect": [
        {
            "ref": "AU.L2-3.3.8",
            "family": "AU",
            "title": "Protect audit information and audit logging tools from unauthorized access",
        },
        {
            "ref": "SI.L2-3.14.1",
            "family": "SI",
            "title": "Identify, report, and correct system flaws in a timely manner",
        },
    ],
    "journald": [
        {"ref": "AU.L2-3.3.1", "family": "AU", "title": "Create and retain system audit logs and records"},
    ],
    "process_acct": [
        {"ref": "AU.L2-3.3.1", "family": "AU", "title": "Create and retain system audit logs and records"},
    ],
    "sysstat": [
        {"ref": "AU.L2-3.3.1", "family": "AU", "title": "Create and retain system audit logs and records"},
    ],
    "file_integrity": [
        {
            "ref": "SI.L2-3.14.1",
            "family": "SI",
            "title": "Identify, report, and correct system flaws in a timely manner",
        },
        {"ref": "CM.L2-3.4.1", "family": "CM", "title": "Establish and maintain baseline configurations"},
    ],
    "debsums": [
        {
            "ref": "SI.L2-3.14.1",
            "family": "SI",
            "title": "Identify, report, and correct system flaws in a timely manner",
        },
        {"ref": "CM.L2-3.4.1", "family": "CM", "title": "Establish and maintain baseline configurations"},
    ],
    "mem_protection": [
        {"ref": "SI.L2-3.14.7", "family": "SI", "title": "Identify unauthorized use of organizational systems"},
    ],
    "sysctl_hardening": [
        {"ref": "CM.L2-3.4.6", "family": "CM", "title": "Employ the principle of least functionality"},
        {
            "ref": "SC.L2-3.13.4",
            "family": "SC",
            "title": "Prevent unauthorized and unintended information transfer via shared system resources",
        },
    ],
    "pkg_cleanup": [
        {
            "ref": "CM.L2-3.4.7",
            "family": "CM",
            "title": "Restrict, disable, prevent the use of nonessential programs, functions, ports, protocols and services",
        },
        {
            "ref": "CM.L2-3.4.8",
            "family": "CM",
            "title": "Apply deny-by-exception policy to prevent unauthorized software",
        },
    ],
    "remove_legacy_svcs": [
        {
            "ref": "CM.L2-3.4.7",
            "family": "CM",
            "title": "Restrict, disable, prevent the use of nonessential programs, functions, ports, protocols and services",
        },
    ],
    "disable_services": [
        {
            "ref": "CM.L2-3.4.7",
            "family": "CM",
            "title": "Restrict, disable, prevent the use of nonessential programs, functions, ports, protocols and services",
        },
    ],
    "net_protocols": [
        {
            "ref": "CM.L2-3.4.7",
            "family": "CM",
            "title": "Restrict, disable, prevent the use of nonessential programs, functions, ports, protocols and services",
        },
        {"ref": "SC.L2-3.13.6", "family": "SC", "title": "Deny network communications by default; allow by exception"},
    ],
    "restrict_compilers": [
        {
            "ref": "CM.L2-3.4.7",
            "family": "CM",
            "title": "Restrict, disable, prevent the use of nonessential programs, functions, ports, protocols and services",
        },
    ],
    "cron_hardening": [
        {"ref": "AC.L2-3.1.5", "family": "AC", "title": "Employ the principle of least privilege"},
    ],
    "pam_tmpdir": [
        {"ref": "SC.L2-3.13.16", "family": "SC", "title": "Protect the confidentiality of CUI at rest"},
    ],
    "pve_fail2ban": [
        {
            "ref": "SI.L2-3.14.6",
            "family": "SI",
            "title": "Monitor systems including network traffic to detect attacks and indicators",
        },
        {"ref": "AC.L2-3.1.8", "family": "AC", "title": "Limit unsuccessful logon attempts"},
    ],
    "apt_show_versions": [
        {
            "ref": "SI.L2-3.14.1",
            "family": "SI",
            "title": "Identify, report, and correct system flaws in a timely manner",
        },
    ],
    "backup_dns": [
        {"ref": "SC.L2-3.13.6", "family": "SC", "title": "Deny network communications by default; allow by exception"},
    ],
    "postfix_banner": [
        {"ref": "SC.L2-3.13.13", "family": "SC", "title": "Control and monitor the use of mobile code"},
    ],
}


# CMMC Level 1 (FAR 52.204-21 / NIST 800-171 subset). Uses a smaller subset
# of the NIST 800-171 controls focused on basic safeguarding of FCI.
# Refs use the FAR clause numbering (b)(1) through (b)(15).
CMMC_L1 = {
    "pam_faillock": [
        {"ref": "AC.L1-3.1.20", "family": "AC", "title": "Verify and control connections to external systems"},
    ],
    "login_banners": [
        {"ref": "AC.L1-3.1.22", "family": "AC", "title": "Control posted information on publicly accessible systems"},
    ],
    "pw_quality": [
        {"ref": "IA.L1-3.5.1", "family": "IA", "title": "Identify users, processes, and devices"},
        {"ref": "IA.L1-3.5.2", "family": "IA", "title": "Authenticate identities of users, processes, devices"},
    ],
    "pw_hash_rounds": [
        {"ref": "IA.L1-3.5.2", "family": "IA", "title": "Authenticate identities of users, processes, devices"},
    ],
    "ssh_crypto": [
        {"ref": "IA.L1-3.5.2", "family": "IA", "title": "Authenticate identities of users, processes, devices"},
    ],
    "ssh_perms": [
        {"ref": "AC.L1-3.1.1", "family": "AC", "title": "Limit system access to authorized users"},
    ],
    "file_perms": [
        {"ref": "AC.L1-3.1.1", "family": "AC", "title": "Limit system access to authorized users"},
    ],
    "apparmor": [
        {"ref": "AC.L1-3.1.1", "family": "AC", "title": "Limit system access to authorized users"},
    ],
    # Audit/accountability is NOT a CMMC Level 1 domain - L1 covers only
    # AC / IA / MP / PE / SC / SI (17 practices from FAR 52.204-21). audit_rules
    # and auditd_service map to AU.L2-3.3.1 at Level 2 (see CMMC_L2_NIST_171), so
    # they're intentionally absent here.
    "mem_protection": [
        {"ref": "SI.L1-3.14.1", "family": "SI", "title": "Identify, report, and correct system flaws"},
    ],
    "file_integrity": [
        {"ref": "SI.L1-3.14.1", "family": "SI", "title": "Identify, report, and correct system flaws"},
    ],
    "debsums": [
        {"ref": "SI.L1-3.14.1", "family": "SI", "title": "Identify, report, and correct system flaws"},
    ],
    "sysctl_hardening": [
        {
            "ref": "SC.L1-3.13.5",
            "family": "SC",
            "title": "Implement subnetworks for publicly accessible system components",
        },
    ],
}


# NIST SP 800-53 Revision 5 mapping (Mod baseline)
NIST_800_53 = {
    "pam_faillock": [
        {"ref": "AC-7", "family": "AC", "title": "Unsuccessful Logon Attempts"},
    ],
    "session_limit": [
        {"ref": "AC-12", "family": "AC", "title": "Session Termination"},
        {"ref": "AC-11", "family": "AC", "title": "Device Lock"},
    ],
    "shell_timeout": [
        {"ref": "AC-12", "family": "AC", "title": "Session Termination"},
    ],
    "login_banners": [
        {"ref": "AC-8", "family": "AC", "title": "System Use Notification"},
    ],
    "inactive_accounts": [
        {"ref": "AC-2(3)", "family": "AC", "title": "Account Management — Disable Accounts"},
    ],
    "pw_quality": [
        {"ref": "IA-5(1)", "family": "IA", "title": "Authenticator Management — Password-Based Authentication"},
    ],
    "pw_history": [
        {"ref": "IA-5(1)", "family": "IA", "title": "Authenticator Management — Password-Based Authentication"},
    ],
    "pw_aging": [
        {"ref": "IA-5(1)", "family": "IA", "title": "Authenticator Management — Password-Based Authentication"},
    ],
    "pw_hash_rounds": [
        {"ref": "IA-5(1)", "family": "IA", "title": "Authenticator Management — Password-Based Authentication"},
        {"ref": "SC-13", "family": "SC", "title": "Cryptographic Protection"},
    ],
    "ssh_crypto": [
        {"ref": "SC-13", "family": "SC", "title": "Cryptographic Protection"},
        {
            "ref": "SC-8(1)",
            "family": "SC",
            "title": "Transmission Confidentiality and Integrity — Cryptographic Protection",
        },
    ],
    "ssh_perms": [
        {"ref": "AC-3", "family": "AC", "title": "Access Enforcement"},
        {"ref": "CM-7", "family": "CM", "title": "Least Functionality"},
    ],
    "file_perms": [
        {"ref": "AC-3", "family": "AC", "title": "Access Enforcement"},
        {"ref": "AU-9", "family": "AU", "title": "Protection of Audit Information"},
    ],
    "default_umask": [
        {"ref": "AC-3", "family": "AC", "title": "Access Enforcement"},
    ],
    "apparmor": [
        {"ref": "AC-6", "family": "AC", "title": "Least Privilege"},
        {"ref": "AC-3", "family": "AC", "title": "Access Enforcement"},
    ],
    "fs_modules": [
        {"ref": "CM-7", "family": "CM", "title": "Least Functionality"},
    ],
    "usb_storage": [
        {"ref": "MP-7", "family": "MP", "title": "Media Use"},
        {"ref": "AC-19", "family": "AC", "title": "Access Control for Mobile Devices"},
    ],
    "mount_options": [
        {"ref": "CM-7", "family": "CM", "title": "Least Functionality"},
    ],
    "core_dumps": [
        {"ref": "SC-28", "family": "SC", "title": "Protection of Information at Rest"},
    ],
    "audit_rules": [
        {"ref": "AU-2", "family": "AU", "title": "Event Logging"},
        {"ref": "AU-12", "family": "AU", "title": "Audit Record Generation"},
        {"ref": "AU-3", "family": "AU", "title": "Content of Audit Records"},
    ],
    "audit_boot": [
        {"ref": "AU-5", "family": "AU", "title": "Response to Audit Logging Process Failures"},
    ],
    "auditd_service": [
        {"ref": "AU-12", "family": "AU", "title": "Audit Record Generation"},
    ],
    "audit_immutable": [
        {"ref": "AU-9", "family": "AU", "title": "Protection of Audit Information"},
        {"ref": "AU-9(3)", "family": "AU", "title": "Cryptographic Protection of Audit Records"},
    ],
    "aide_audit_protect": [
        {"ref": "AU-9", "family": "AU", "title": "Protection of Audit Information"},
        {"ref": "SI-7", "family": "SI", "title": "Software, Firmware, and Information Integrity"},
    ],
    "journald": [
        {"ref": "AU-2", "family": "AU", "title": "Event Logging"},
    ],
    "process_acct": [
        {"ref": "AU-2", "family": "AU", "title": "Event Logging"},
    ],
    "sysstat": [
        {"ref": "AU-2", "family": "AU", "title": "Event Logging"},
    ],
    "file_integrity": [
        {"ref": "SI-7", "family": "SI", "title": "Software, Firmware, and Information Integrity"},
        {"ref": "CM-3", "family": "CM", "title": "Configuration Change Control"},
    ],
    "debsums": [
        {"ref": "SI-7", "family": "SI", "title": "Software, Firmware, and Information Integrity"},
    ],
    "mem_protection": [
        {"ref": "SI-16", "family": "SI", "title": "Memory Protection"},
    ],
    "sysctl_hardening": [
        {"ref": "SC-7", "family": "SC", "title": "Boundary Protection"},
        {"ref": "CM-7", "family": "CM", "title": "Least Functionality"},
    ],
    "pkg_cleanup": [
        {"ref": "CM-7(5)", "family": "CM", "title": "Least Functionality — Authorized Software / Allow-by-Exception"},
    ],
    "remove_legacy_svcs": [
        {"ref": "CM-7", "family": "CM", "title": "Least Functionality"},
    ],
    "disable_services": [
        {"ref": "CM-7", "family": "CM", "title": "Least Functionality"},
    ],
    "net_protocols": [
        {"ref": "CM-7", "family": "CM", "title": "Least Functionality"},
        {"ref": "SC-7", "family": "SC", "title": "Boundary Protection"},
    ],
    "pve_fail2ban": [
        {"ref": "AC-7", "family": "AC", "title": "Unsuccessful Logon Attempts"},
        {"ref": "SI-4", "family": "SI", "title": "System Monitoring"},
    ],
    "cron_hardening": [
        {"ref": "AC-6", "family": "AC", "title": "Least Privilege"},
    ],
    "pam_tmpdir": [
        {"ref": "SC-28", "family": "SC", "title": "Protection of Information at Rest"},
    ],
    "apt_show_versions": [
        {"ref": "SI-2", "family": "SI", "title": "Flaw Remediation"},
    ],
    "restrict_compilers": [
        {"ref": "CM-7", "family": "CM", "title": "Least Functionality"},
    ],
}


# DISA STIG (RHEL 9 / Ubuntu 22.04 — refs are RHEL 9 STIG IDs where known).
# STIG IDs change between releases, so review against the deployed STIG baseline.
DISA_STIG = {
    "pam_faillock": [
        {
            "ref": "RHEL-09-411075",
            "family": "AC",
            "title": "RHEL 9 must automatically lock an account when three unsuccessful logon attempts occur during a 15-minute time period.",
        },
    ],
    "pw_quality": [
        {
            "ref": "RHEL-09-611045",
            "family": "IA",
            "title": "RHEL 9 must ensure the password complexity module is enabled in the system-auth file.",
        },
        {
            "ref": "RHEL-09-611040",
            "family": "IA",
            "title": "RHEL 9 must ensure the password complexity module is enabled in the password-auth file.",
        },
    ],
    "pw_history": [
        {
            "ref": "RHEL-09-611015",
            "family": "IA",
            "title": "RHEL 9 must be configured in the password-auth file to prohibit password reuse for a minimum of five generations.",
        },
        {
            "ref": "RHEL-09-611020",
            "family": "IA",
            "title": "RHEL 9 must be configured in the system-auth file to prohibit password reuse for a minimum of five generations.",
        },
    ],
    "pw_aging": [
        {
            "ref": "RHEL-09-411010",
            "family": "AC",
            "title": "RHEL 9 user account passwords for new users or password changes must have a 60-day maximum password lifetime restriction in /etc/login.defs.",
        },
        {
            "ref": "RHEL-09-611080",
            "family": "IA",
            "title": "RHEL 9 passwords must have a 24 hours minimum password lifetime restriction in /etc/shadow.",
        },
    ],
    "pw_hash_rounds": [
        {
            "ref": "RHEL-09-611055",
            "family": "IA",
            "title": "RHEL 9 system-auth must be configured to use a sufficient number of hashing rounds",
        },
        {
            "ref": "RHEL-09-611050",
            "family": "IA",
            "title": "RHEL 9 password-auth must be configured to use a sufficient number of hashing rounds",
        },
    ],
    "ssh_crypto": [
        {
            "ref": "RHEL-09-255065",
            "family": "IA",
            "title": "The RHEL 9 SSH server must be configured to use only DOD-approved encryption ciphers employing FIPS 140-3 validated cryptographic hash algorithms to protect the confidentiality of SSH server connections.",
        },
        {
            "ref": "RHEL-09-255075",
            "family": "IA",
            "title": "The RHEL 9 SSH server must be configured to use only Message Authentication Codes (MACs) employing FIPS 140-3 validated cryptographic hash algorithms.",
        },
    ],
    "ssh_perms": [
        {
            "ref": "RHEL-09-255115",
            "family": "CM",
            "title": "RHEL 9 SSH server configuration file must have mode 0600 or less permissive",
        },
        {
            "ref": "RHEL-09-255110",
            "family": "CM",
            "title": "RHEL 9 SSH server configuration file must be owned by root",
        },
        {
            "ref": "RHEL-09-255105",
            "family": "CM",
            "title": "RHEL 9 SSH server configuration file must be group-owned by root",
        },
    ],
    "session_limit": [
        {
            "ref": "RHEL-09-412040",
            "family": "AC",
            "title": "RHEL 9 must limit the number of concurrent sessions to ten for all accounts and/or account types",
        },
    ],
    "shell_timeout": [
        {
            "ref": "RHEL-09-412035",
            "family": "AC",
            "title": "RHEL 9 must automatically exit interactive command shell user sessions after 10 minutes of inactivity",
        },
    ],
    "login_banners": [
        {
            "ref": "RHEL-09-211020",
            "family": "AC",
            "title": "RHEL 9 must display the Standard Mandatory DOD Notice and Consent Banner before granting local or remote access to the system via a command line user logon.",
        },
    ],
    "inactive_accounts": [
        {
            "ref": "RHEL-09-411050",
            "family": "AC",
            "title": "RHEL 9 must disable account identifiers (individuals, groups, roles, and devices) after 35 days of inactivity.",
        },
    ],
    "audit_rules": [
        {
            "ref": "RHEL-09-654215",
            "family": "AU",
            "title": "RHEL 9 must generate audit records for all account creations, modifications, disabling, and termination events that affect /etc/sudoers.",
        },
        {
            "ref": "RHEL-09-654225",
            "family": "AU",
            "title": "RHEL 9 must generate audit records for all account creations, modifications, disabling, and termination events that affect /etc/group.",
        },
    ],
    "audit_boot": [
        {
            "ref": "RHEL-09-212055",
            "family": "AU",
            "title": "RHEL 9 must enable auditing of processes that start prior to the audit daemon.",
        },
    ],
    "auditd_service": [
        {"ref": "RHEL-09-653015", "family": "AU", "title": "RHEL 9 audit service must be enabled"},
    ],
    "audit_immutable": [
        {
            "ref": "RHEL-09-654275",
            "family": "AU",
            "title": "RHEL 9 audit system must protect auditing rules from unauthorized change.",
        },
        {
            "ref": "RHEL-09-653025",
            "family": "AU",
            "title": "RHEL 9 audit system must take appropriate action when the audit storage volume is full",
        },
    ],
    "aide_audit_protect": [
        {
            "ref": "RHEL-09-651025",
            "family": "AU",
            "title": "RHEL 9 must use cryptographic mechanisms to protect the integrity of audit tools",
        },
        {
            "ref": "RHEL-09-232035",
            "family": "AU",
            "title": "RHEL 9 audit tools must have a mode of 0755 or less permissive",
        },
    ],
    "journald": [
        {"ref": "RHEL-09-211040", "family": "AU", "title": "RHEL 9 systemd-journald service must be enabled"},
    ],
    "apparmor": [
        {"ref": "UBTU-22-431015", "family": "AC", "title": "Ubuntu 22.04 LTS must be configured to use AppArmor"},
        {
            "ref": "RHEL-09-431010",
            "family": "AC",
            "title": "RHEL 9 must use a Linux Security Module configured to enforce limits on system services.",
        },
    ],
    "fs_modules": [
        {"ref": "RHEL-09-231195", "family": "CM", "title": "RHEL 9 must disable mounting of cramfs"},
    ],
    "usb_storage": [
        {"ref": "RHEL-09-291010", "family": "MP", "title": "RHEL 9 must be configured to disable USB mass storage"},
    ],
    "core_dumps": [
        {"ref": "RHEL-09-213090", "family": "SC", "title": "RHEL 9 must disable storing core dumps"},
        {
            "ref": "RHEL-09-213100",
            "family": "SC",
            "title": "RHEL 9 must disable acquiring, saving, and processing core dumps",
        },
    ],
    "mount_options": [
        {"ref": "RHEL-09-231115", "family": "CM", "title": "RHEL 9 must mount /dev/shm with the noexec option"},
        {"ref": "RHEL-09-231130", "family": "CM", "title": "RHEL 9 must mount /tmp with the noexec option"},
    ],
    "mem_protection": [
        {
            "ref": "RHEL-09-213070",
            "family": "SC",
            "title": "RHEL 9 must implement address space layout randomization (ASLR) to protect its memory from unauthorized code execution.",
        },
    ],
    "file_integrity": [
        {"ref": "RHEL-09-651010", "family": "SI", "title": "RHEL 9 must have the AIDE package installed"},
        {
            "ref": "RHEL-09-651015",
            "family": "SI",
            "title": "RHEL 9 must routinely check the baseline configuration for unauthorized changes and notify the system administrator when anomalies in the operation of any security functions are discovered.",
        },
    ],
    "sysctl_hardening": [
        {
            "ref": "RHEL-09-253015",
            "family": "SC",
            "title": "RHEL 9 must ignore Internet Protocol version 4 (IPv4) Internet Control Message Protocol (ICMP) redirect messages.",
        },
        {
            "ref": "RHEL-09-253035",
            "family": "SC",
            "title": "RHEL 9 must use reverse path filtering on all IPv4 interfaces",
        },
        {"ref": "RHEL-09-253010", "family": "SC", "title": "RHEL 9 must be configured to use TCP syncookies"},
    ],
    # Rebuild 2026-06-15 (RHEL 9 STIG V2R8, web-verified). Intentionally unmapped:
    #  - pve_fail2ban: RHEL 9 STIG dropped the RHEL-7/8 host-based-IDS (SI-4) rule.
    # Partial coverage (real ID, partial intent): journald 211040 = "service enabled" only
    # (no STIG rule for compress/forward/persistent); fs_modules = cramfs (231195) only --
    # freevxfs/squashfs/udf/etc. are CIS, not STIG. ssh_crypto omits KEX (no server-side
    # KexAlgorithms STIG rule in V2R8; governed by the FIPS crypto-policy 671xxx range).
}


# ISO/IEC 27001:2022 Annex A controls (93 controls in 4 themes:
# A.5 Organizational, A.6 People, A.7 Physical, A.8 Technological).
ISO_27001 = {
    "pam_faillock": [
        {"ref": "A.8.5", "family": "A.8", "title": "Secure authentication"},
    ],
    "pw_quality": [
        {"ref": "A.5.17", "family": "A.5", "title": "Authentication information"},
    ],
    "pw_history": [
        {"ref": "A.5.17", "family": "A.5", "title": "Authentication information"},
    ],
    "pw_aging": [
        {"ref": "A.5.17", "family": "A.5", "title": "Authentication information"},
    ],
    "pw_hash_rounds": [
        {"ref": "A.5.17", "family": "A.5", "title": "Authentication information"},
        {"ref": "A.8.24", "family": "A.8", "title": "Use of cryptography"},
    ],
    "ssh_crypto": [
        {"ref": "A.8.24", "family": "A.8", "title": "Use of cryptography"},
        {"ref": "A.8.20", "family": "A.8", "title": "Networks security"},
    ],
    "ssh_perms": [
        {"ref": "A.5.18", "family": "A.5", "title": "Access rights"},
    ],
    "file_perms": [
        {"ref": "A.8.3", "family": "A.8", "title": "Information access restriction"},
    ],
    "default_umask": [
        {"ref": "A.8.3", "family": "A.8", "title": "Information access restriction"},
    ],
    "session_limit": [
        {"ref": "A.8.5", "family": "A.8", "title": "Secure authentication"},
    ],
    "shell_timeout": [
        {"ref": "A.8.5", "family": "A.8", "title": "Secure authentication"},
    ],
    "login_banners": [
        {"ref": "A.5.10", "family": "A.5", "title": "Acceptable use of information and other associated assets"},
    ],
    "inactive_accounts": [
        {"ref": "A.5.18", "family": "A.5", "title": "Access rights"},
    ],
    "apparmor": [
        {"ref": "A.8.2", "family": "A.8", "title": "Privileged access rights"},
        {"ref": "A.8.18", "family": "A.8", "title": "Use of privileged utility programs"},
    ],
    "fs_modules": [
        {"ref": "A.8.9", "family": "A.8", "title": "Configuration management"},
    ],
    "usb_storage": [
        {"ref": "A.7.10", "family": "A.7", "title": "Storage media"},
    ],
    "mount_options": [
        {"ref": "A.8.9", "family": "A.8", "title": "Configuration management"},
    ],
    "core_dumps": [
        {"ref": "A.8.10", "family": "A.8", "title": "Information deletion"},
        {"ref": "A.8.11", "family": "A.8", "title": "Data masking"},
    ],
    "audit_rules": [
        {"ref": "A.8.15", "family": "A.8", "title": "Logging"},
    ],
    "audit_boot": [
        {"ref": "A.8.15", "family": "A.8", "title": "Logging"},
    ],
    "auditd_service": [
        {"ref": "A.8.15", "family": "A.8", "title": "Logging"},
    ],
    "audit_immutable": [
        {"ref": "A.8.15", "family": "A.8", "title": "Logging"},
        {"ref": "A.8.34", "family": "A.8", "title": "Protection of information systems during audit testing"},
    ],
    "aide_audit_protect": [
        {"ref": "A.8.15", "family": "A.8", "title": "Logging"},
        {"ref": "A.8.34", "family": "A.8", "title": "Protection of information systems during audit testing"},
    ],
    "journald": [
        {"ref": "A.8.15", "family": "A.8", "title": "Logging"},
    ],
    "process_acct": [
        {"ref": "A.8.15", "family": "A.8", "title": "Logging"},
    ],
    "file_integrity": [
        {"ref": "A.8.32", "family": "A.8", "title": "Change management"},
        {"ref": "A.8.16", "family": "A.8", "title": "Monitoring activities"},
    ],
    "debsums": [
        {"ref": "A.8.32", "family": "A.8", "title": "Change management"},
    ],
    "mem_protection": [
        {"ref": "A.8.27", "family": "A.8", "title": "Secure system architecture and engineering principles"},
    ],
    "sysctl_hardening": [
        {"ref": "A.8.20", "family": "A.8", "title": "Networks security"},
        {"ref": "A.8.9", "family": "A.8", "title": "Configuration management"},
    ],
    "pkg_cleanup": [
        {"ref": "A.8.9", "family": "A.8", "title": "Configuration management"},
    ],
    "remove_legacy_svcs": [
        {"ref": "A.8.9", "family": "A.8", "title": "Configuration management"},
    ],
    "disable_services": [
        {"ref": "A.8.9", "family": "A.8", "title": "Configuration management"},
    ],
    "net_protocols": [
        {"ref": "A.8.20", "family": "A.8", "title": "Networks security"},
        {"ref": "A.8.21", "family": "A.8", "title": "Security of network services"},
    ],
    "pve_fail2ban": [
        {"ref": "A.8.16", "family": "A.8", "title": "Monitoring activities"},
        {"ref": "A.5.7", "family": "A.5", "title": "Threat intelligence"},
    ],
    "apt_show_versions": [
        {"ref": "A.8.8", "family": "A.8", "title": "Management of technical vulnerabilities"},
    ],
    "cron_hardening": [
        {"ref": "A.8.2", "family": "A.8", "title": "Privileged access rights"},
    ],
    "pam_tmpdir": [
        {"ref": "A.8.10", "family": "A.8", "title": "Information deletion"},
    ],
    "restrict_compilers": [
        {"ref": "A.8.19", "family": "A.8", "title": "Installation of software on operational systems"},
    ],
}


# BSI IT-Grundschutz Kompendium (subset — modules SYS, OPS, NET, DER, CON).
BSI_GRUNDSCHUTZ = {
    "pam_faillock": [
        {"ref": "ORP.4.A23", "family": "ORP", "title": "Regelung für passwortverarbeitende Anwendungen und IT-Systeme"},
    ],
    "pw_quality": [
        {"ref": "ORP.4.A22", "family": "ORP", "title": "Regelung zur Passwortqualität"},
        {"ref": "ORP.4.A8", "family": "ORP", "title": "Regelung des Passwortgebrauchs"},
    ],
    "pw_aging": [
        {"ref": "ORP.4.A23", "family": "ORP", "title": "Regelung für passwortverarbeitende Anwendungen und IT-Systeme"},
    ],
    "pw_history": [
        {"ref": "ORP.4.A23", "family": "ORP", "title": "Regelung für passwortverarbeitende Anwendungen und IT-Systeme"},
        {"ref": "ORP.4.A8", "family": "ORP", "title": "Regelung des Passwortgebrauchs"},
    ],
    "pw_hash_rounds": [
        {"ref": "CON.1.A1", "family": "CON", "title": "Auswahl geeigneter kryptografischer Verfahren"},
    ],
    "ssh_crypto": [
        {"ref": "SYS.1.3.A8", "family": "SYS", "title": "Verschlüsselter Zugriff über Secure Shell"},
        {"ref": "CON.1.A1", "family": "CON", "title": "Auswahl geeigneter kryptografischer Verfahren"},
    ],
    "ssh_perms": [
        {"ref": "SYS.1.3.A8", "family": "SYS", "title": "Verschlüsselter Zugriff über Secure Shell"},
    ],
    "file_perms": [
        {
            "ref": "SYS.1.3.A14",
            "family": "SYS",
            "title": "Verhinderung des Ausspähens von Informationen über das System und über Benutzende",
        },
        {"ref": "ORP.4.A7", "family": "ORP", "title": "Vergabe von Zugriffsrechten"},
    ],
    "default_umask": [
        {
            "ref": "SYS.1.3.A14",
            "family": "SYS",
            "title": "Verhinderung des Ausspähens von Informationen über das System und über Benutzende",
        },
    ],
    "apparmor": [
        {
            "ref": "SYS.1.3.A10",
            "family": "SYS",
            "title": "Verhinderung der Ausbreitung bei der Ausnutzung von Schwachstellen",
        },
        {
            "ref": "SYS.1.3.A16",
            "family": "SYS",
            "title": "Zusätzliche Verhinderung der Ausbreitung bei der Ausnutzung von Schwachstellen",
        },
    ],
    "inactive_accounts": [
        {"ref": "ORP.4.A7", "family": "ORP", "title": "Vergabe von Zugriffsrechten"},
    ],
    "vsnfd_kernel_lockdown": [
        {"ref": "SYS.1.3.A17", "family": "SYS", "title": "Zusätzlicher Schutz des Kernels"},
    ],
    "vsnfd_password_min_12": [
        {"ref": "ORP.4.A22", "family": "ORP", "title": "Regelung zur Passwortqualität"},
    ],
    "fs_modules": [
        {"ref": "SYS.1.1.A6", "family": "SYS", "title": "Deaktivierung nicht benötigter Dienste"},
    ],
    "usb_storage": [
        {"ref": "SYS.1.3.A3", "family": "SYS", "title": "Kein automatisches Einbinden von Wechsellaufwerken"},
        {"ref": "SYS.1.1.A5", "family": "SYS", "title": "Schutz von Schnittstellen"},
    ],
    "mount_options": [
        {"ref": "SYS.1.1.A16", "family": "SYS", "title": "Sichere Installation und Grundkonfiguration von Servern"},
    ],
    "core_dumps": [
        {"ref": "SYS.1.3.A4", "family": "SYS", "title": "Schutz vor Ausnutzung von Schwachstellen in Anwendungen"},
    ],
    "audit_rules": [
        {
            "ref": "OPS.1.1.5.A3",
            "family": "OPS",
            "title": "Konfiguration der Protokollierung auf System- und Netzebene",
        },
        {"ref": "DER.1.A5", "family": "DER", "title": "Einsatz von mitgelieferten Systemfunktionen zur Detektion"},
    ],
    "audit_boot": [
        {
            "ref": "OPS.1.1.5.A3",
            "family": "OPS",
            "title": "Konfiguration der Protokollierung auf System- und Netzebene",
        },
    ],
    "auditd_service": [
        {
            "ref": "OPS.1.1.5.A1",
            "family": "OPS",
            "title": "Erstellung einer Sicherheitsrichtlinie für die Protokollierung",
        },
        {
            "ref": "OPS.1.1.5.A3",
            "family": "OPS",
            "title": "Konfiguration der Protokollierung auf System- und Netzebene",
        },
    ],
    "audit_immutable": [
        {"ref": "OPS.1.1.5.A10", "family": "OPS", "title": "Zugriffsschutz für Protokollierungsdaten"},
    ],
    "aide_audit_protect": [
        {"ref": "DER.1.A18", "family": "DER", "title": "Durchführung regelmäßiger Integritätskontrollen"},
        {"ref": "OPS.1.1.5.A10", "family": "OPS", "title": "Zugriffsschutz für Protokollierungsdaten"},
    ],
    "journald": [
        {
            "ref": "OPS.1.1.5.A3",
            "family": "OPS",
            "title": "Konfiguration der Protokollierung auf System- und Netzebene",
        },
    ],
    "process_acct": [
        {
            "ref": "OPS.1.1.5.A3",
            "family": "OPS",
            "title": "Konfiguration der Protokollierung auf System- und Netzebene",
        },
    ],
    "file_integrity": [
        {"ref": "DER.1.A18", "family": "DER", "title": "Durchführung regelmäßiger Integritätskontrollen"},
        {"ref": "SYS.1.1.A27", "family": "SYS", "title": "Hostbasierte Angriffserkennung"},
    ],
    "debsums": [
        {"ref": "DER.1.A18", "family": "DER", "title": "Durchführung regelmäßiger Integritätskontrollen"},
    ],
    "mem_protection": [
        {"ref": "SYS.1.3.A4", "family": "SYS", "title": "Schutz vor Ausnutzung von Schwachstellen in Anwendungen"},
        {"ref": "SYS.1.3.A17", "family": "SYS", "title": "Zusätzlicher Schutz des Kernels"},
    ],
    "sysctl_hardening": [
        {"ref": "SYS.1.3.A4", "family": "SYS", "title": "Schutz vor Ausnutzung von Schwachstellen in Anwendungen"},
    ],
    "net_protocols": [
        {"ref": "SYS.1.1.A6", "family": "SYS", "title": "Deaktivierung nicht benötigter Dienste"},
    ],
    "pkg_cleanup": [
        {"ref": "SYS.1.1.A6", "family": "SYS", "title": "Deaktivierung nicht benötigter Dienste"},
    ],
    "remove_legacy_svcs": [
        {"ref": "SYS.1.1.A6", "family": "SYS", "title": "Deaktivierung nicht benötigter Dienste"},
    ],
    "disable_services": [
        {"ref": "SYS.1.1.A6", "family": "SYS", "title": "Deaktivierung nicht benötigter Dienste"},
    ],
    "restrict_compilers": [
        {"ref": "SYS.1.3.A5", "family": "SYS", "title": "Sichere Installation von Software-Paketen"},
    ],
    "pve_fail2ban": [
        {"ref": "DER.1.A5", "family": "DER", "title": "Einsatz von mitgelieferten Systemfunktionen zur Detektion"},
        {"ref": "SYS.1.1.A27", "family": "SYS", "title": "Hostbasierte Angriffserkennung"},
    ],
    # VS-NfD-specific informational checks -> BSI Grundschutz
    "vsnfd_disk_encryption": [
        {"ref": "SYS.1.1.A34", "family": "SYS", "title": "Festplattenverschlüsselung"},
        {"ref": "SYS.1.5.A28", "family": "SYS", "title": "Verschlüsselung von virtuellen IT-Systemen"},
    ],
    "vsnfd_audit_retention": [
        {"ref": "OPS.1.1.5.A8", "family": "OPS", "title": "Archivierung von Protokollierungsdaten"},
    ],
    "vsnfd_journald_size": [
        {
            "ref": "OPS.1.1.5.A3",
            "family": "OPS",
            "title": "Konfiguration der Protokollierung auf System- und Netzebene",
        },
    ],
    "vsnfd_secure_boot": [
        {"ref": "SYS.1.1.A36", "family": "SYS", "title": "Absicherung des Bootvorgangs"},
    ],
    # Rebuild 2026-06-15 (BSI IT-Grundschutz, web-verified). Dropped the fabricated
    # SYS.1.3.A19/A22 and the ENTFALLEN SYS.1.3.A1/A11; remapped DER.4.A4->DER.1.A18,
    # SYS.1.5.A4->SYS.1.1.A34; fixed all ORP.4 family tags (were 'OPS'). Intentionally
    # unmapped (no defensible Grundschutz server requirement): cron_hardening, session_limit,
    # shell_timeout (idle-lock is client req SYS.2.1), login_banners (no banner req in GS),
    # pam_tmpdir, apt_show_versions (patch-mgmt = OPS.1.1.3, A-number unconfirmed).
}


# ──────────────────────────────────────────────────────────────────────────
# ANSSI-BP-028 v2.0 (2022-10-03) — "Recommandations de configuration d'un
# système GNU/Linux". The recognised French national Linux-hardening baseline.
# Both Diffusion Restreinte (protection regime under Instruction interministérielle
# n° 901 / II 901) and the RGS reference ANSSI-BP-028 as the concrete technical
# hardening measure set, so 'dr' + 'rgs' both inherit this mapping — same as
# 'vs-nfd' inherits BSI Grundschutz.
# R-numbers + French titles verified against the official ANSSI PDF
# (v2.0, "Liste des recommandations" p.71-73). Checks with NO defensible BP-028
# recommendation are INTENTIONALLY UNMAPPED (no fabrication, per the BSI rebuild note):
#   ssh_crypto / ssh_perms  -> BP-028 defers OpenSSH to a separate ANSSI note (NT-SSH)
#   vsnfd_kernel_lockdown   -> only Annexe A (non-numbered), not a recommendation
#   vsnfd_disk_encryption   -> no LUKS/FDE recommendation in v2.0
#   pve_fail2ban            -> host lockout is R67 (pam_faillock); no fail2ban item
#   restrict_compilers / debsums / process_acct / vsnfd_audit_retention -> no matching R-number
# ──────────────────────────────────────────────────────────────────────────
ANSSI_BP028 = {
    "pam_faillock": [
        {"ref": "R67", "family": "services", "title": "Sécuriser les authentifications distante par PAM"},
    ],
    "pw_quality": [
        {"ref": "R67", "family": "services", "title": "Sécuriser les authentifications distante par PAM"},
        {"ref": "R31", "family": "comptes", "title": "Utiliser des mots de passe robustes"},
    ],
    "pw_aging": [
        {"ref": "R31", "family": "comptes", "title": "Utiliser des mots de passe robustes"},
    ],
    "pw_history": [
        {"ref": "R31", "family": "comptes", "title": "Utiliser des mots de passe robustes"},
    ],
    "pw_hash_rounds": [
        {"ref": "R68", "family": "services", "title": "Protéger les mots de passe stockés"},
        {"ref": "R31", "family": "comptes", "title": "Utiliser des mots de passe robustes"},
    ],
    "file_perms": [
        {
            "ref": "R50",
            "family": "fichiers",
            "title": "Restreindre les droits d'accès aux fichiers et aux répertoires sensibles",
        },
        {"ref": "R51", "family": "fichiers", "title": "Changer les secrets et droits d'accès dès l'installation"},
    ],
    "default_umask": [
        {"ref": "R36", "family": "controle_acces", "title": "Modifier la valeur par défaut de UMASK"},
    ],
    "apparmor": [
        {"ref": "R45", "family": "controle_acces", "title": "Activer les profils de sécurité AppArmor"},
        {
            "ref": "R37",
            "family": "controle_acces",
            "title": "Utiliser des fonctionnalités de contrôle d'accès obligatoire MAC",
        },
    ],
    "inactive_accounts": [
        {"ref": "R30", "family": "comptes", "title": "Désactiver les comptes utilisateur inutilisés"},
    ],
    "vsnfd_password_min_12": [
        {"ref": "R67", "family": "services", "title": "Sécuriser les authentifications distante par PAM"},
    ],
    "fs_modules": [
        {"ref": "R10", "family": "noyau", "title": "Désactiver le chargement des modules noyau"},
    ],
    "usb_storage": [
        {"ref": "R10", "family": "noyau", "title": "Désactiver le chargement des modules noyau"},
    ],
    "mount_options": [
        {"ref": "R28", "family": "partitionnement", "title": "Partitionnement type"},
    ],
    "core_dumps": [
        {"ref": "R14", "family": "noyau", "title": "Paramétrer les options de configuration des systèmes de fichiers"},
        {"ref": "R8", "family": "noyau", "title": "Paramétrer les options de configuration de la mémoire"},
    ],
    "audit_rules": [
        {"ref": "R73", "family": "journalisation", "title": "Journaliser l'activité système avec auditd"},
    ],
    "audit_boot": [
        {"ref": "R73", "family": "journalisation", "title": "Journaliser l'activité système avec auditd"},
    ],
    "auditd_service": [
        {"ref": "R73", "family": "journalisation", "title": "Journaliser l'activité système avec auditd"},
    ],
    "audit_immutable": [
        {"ref": "R73", "family": "journalisation", "title": "Journaliser l'activité système avec auditd"},
    ],
    "aide_audit_protect": [
        {"ref": "R77", "family": "surveillance", "title": "Protéger la base de données des scellés"},
    ],
    "journald": [
        {"ref": "R71", "family": "journalisation", "title": "Mettre en place un système de journalisation"},
        {
            "ref": "R72",
            "family": "journalisation",
            "title": "Mettre en place des journaux d'activité de service dédiés",
        },
    ],
    "file_integrity": [
        {"ref": "R76", "family": "surveillance", "title": "Sceller et vérifier l'intégrité des fichiers"},
        {"ref": "R77", "family": "surveillance", "title": "Protéger la base de données des scellés"},
    ],
    "mem_protection": [
        {"ref": "R9", "family": "noyau", "title": "Paramétrer les options de configuration du noyau"},
        {"ref": "R8", "family": "noyau", "title": "Paramétrer les options de configuration de la mémoire"},
        {"ref": "R11", "family": "noyau", "title": "Activer et configurer le LSM Yama"},
    ],
    "sysctl_hardening": [
        {"ref": "R9", "family": "noyau", "title": "Paramétrer les options de configuration du noyau"},
        {"ref": "R8", "family": "noyau", "title": "Paramétrer les options de configuration de la mémoire"},
        {"ref": "R12", "family": "noyau", "title": "Paramétrer les options de configuration du réseau IPv4"},
        {"ref": "R14", "family": "noyau", "title": "Paramétrer les options de configuration des systèmes de fichiers"},
    ],
    "net_protocols": [
        {"ref": "R10", "family": "noyau", "title": "Désactiver le chargement des modules noyau"},
        {"ref": "R13", "family": "noyau", "title": "Désactiver le plan IPv6"},
    ],
    "pkg_cleanup": [
        {"ref": "R58", "family": "paquets", "title": "N'installer que les paquets strictement nécessaires"},
    ],
    "remove_legacy_svcs": [
        {"ref": "R62", "family": "services", "title": "Désactiver les services non nécessaires"},
        {"ref": "R58", "family": "paquets", "title": "N'installer que les paquets strictement nécessaires"},
    ],
    "disable_services": [
        {"ref": "R62", "family": "services", "title": "Désactiver les services non nécessaires"},
        {"ref": "R63", "family": "services", "title": "Désactiver les fonctionnalités des services non essentielles"},
    ],
    "vsnfd_journald_size": [
        {"ref": "R28", "family": "partitionnement", "title": "Partitionnement type"},
    ],
    "vsnfd_secure_boot": [
        {"ref": "R3", "family": "materiel", "title": "Activer le démarrage sécurisé UEFI"},
        {"ref": "R4", "family": "materiel", "title": "Remplacer les clés préchargées"},
    ],
}


# ──────────────────────────────────────────────────────────────────────────
# PCI DSS v4.0.1 — requirement numbers verified against the published standard.
# Key refs: 8.3.4 lockout (≤10 attempts, ≥30 min); 8.3.6 ≥12-char passwords;
# 8.3.7 no reuse of last 4; 8.3.9 90-day rotation for password-only auth;
# 8.2.6 disable inactive accounts ≤90 days; 8.2.8 15-min idle re-auth;
# 8.3.2 strong crypto for authentication data; 10.2.1 audit trails;
# 10.3.2 audit-trail protection; 10.5.1 12-month log retention;
# 11.5.2 file-integrity monitoring; 2.2.x secure configuration;
# 3.5.1 stored-PAN encryption; 6.3.1 vulnerability identification.
# Checks with no defensible PCI ref stay unmapped (login_banners, backup_dns,
# postfix_banner, sysstat, vsnfd_secure_boot, vsnfd_kernel_lockdown,
# pam_password_repair).
# ──────────────────────────────────────────────────────────────────────────
PCI_DSS = {
    "fs_modules": [{"ref": "2.2.4", "family": "PCI-2", "title": "Only necessary services, protocols, daemons and functions are enabled"}],
    "core_dumps": [{"ref": "2.2.1", "family": "PCI-2", "title": "Configuration standards defined and applied to all system components"}],
    "mount_options": [{"ref": "2.2.1", "family": "PCI-2", "title": "Configuration standards defined and applied to all system components"}],
    "net_protocols": [{"ref": "2.2.5", "family": "PCI-2", "title": "Insecure services, protocols and ports are not used"}],
    "disable_services": [{"ref": "2.2.4", "family": "PCI-2", "title": "Only necessary services, protocols, daemons and functions are enabled"}],
    "remove_legacy_svcs": [{"ref": "2.2.5", "family": "PCI-2", "title": "Insecure services, protocols and ports are not used"}],
    "restrict_compilers": [{"ref": "2.2.4", "family": "PCI-2", "title": "Only necessary services, protocols, daemons and functions are enabled"}],
    "pkg_cleanup": [{"ref": "2.2.4", "family": "PCI-2", "title": "Only necessary services, protocols, daemons and functions are enabled"}],
    "usb_storage": [{"ref": "2.2.4", "family": "PCI-2", "title": "Only necessary services, protocols, daemons and functions are enabled"}],
    "journald": [{"ref": "10.2.1", "family": "PCI-10", "title": "Audit logs are enabled and active"}],
    "ssh_perms": [{"ref": "7.2.2", "family": "PCI-7", "title": "Access is assigned based on least privileges necessary"}],
    "ssh_crypto": [
        {"ref": "2.2.7", "family": "PCI-2", "title": "Non-console administrative access is encrypted using strong cryptography"},
        {"ref": "8.3.2", "family": "PCI-8", "title": "Strong cryptography renders authentication factors unreadable in transit and storage"},
    ],
    "sshd_hardening": [{"ref": "8.3.4", "family": "PCI-8", "title": "Invalid authentication attempts are limited (lockout after ≤10 attempts, ≥30 min)"}],
    "pam_faillock": [{"ref": "8.3.4", "family": "PCI-8", "title": "Invalid authentication attempts are limited (lockout after ≤10 attempts, ≥30 min)"}],
    "pve_fail2ban": [{"ref": "8.3.4", "family": "PCI-8", "title": "Invalid authentication attempts are limited (lockout after ≤10 attempts, ≥30 min)"}],
    "pam_nullok_removal": [{"ref": "8.3.1", "family": "PCI-8", "title": "All user access is authenticated via at least one authentication factor"}],
    "pw_quality": [{"ref": "8.3.6", "family": "PCI-8", "title": "Passwords are minimum 12 characters and contain letters and numbers"}],
    "vsnfd_password_min_12": [{"ref": "8.3.6", "family": "PCI-8", "title": "Passwords are minimum 12 characters and contain letters and numbers"}],
    "pw_history": [{"ref": "8.3.7", "family": "PCI-8", "title": "A new password may not match any of the last four used"}],
    "pw_aging": [{"ref": "8.3.9", "family": "PCI-8", "title": "Passwords used as the sole authentication factor are changed at least every 90 days"}],
    "pw_hash_rounds": [{"ref": "8.3.2", "family": "PCI-8", "title": "Strong cryptography renders authentication factors unreadable in transit and storage"}],
    "file_perms": [{"ref": "7.2.2", "family": "PCI-7", "title": "Access is assigned based on least privileges necessary"}],
    "default_umask": [{"ref": "7.2.2", "family": "PCI-7", "title": "Access is assigned based on least privileges necessary"}],
    "apparmor": [{"ref": "7.2.2", "family": "PCI-7", "title": "Access is assigned based on least privileges necessary"}],
    "cron_hardening": [{"ref": "7.2.2", "family": "PCI-7", "title": "Access is assigned based on least privileges necessary"}],
    "pam_tmpdir": [{"ref": "2.2.6", "family": "PCI-2", "title": "System security parameters are not misused"}],
    "mem_protection": [{"ref": "2.2.6", "family": "PCI-2", "title": "System security parameters are not misused"}],
    "sysctl_hardening": [{"ref": "2.2.6", "family": "PCI-2", "title": "System security parameters are not misused"}],
    "inactive_accounts": [{"ref": "8.2.6", "family": "PCI-8", "title": "Inactive user accounts are removed or disabled within 90 days"}],
    "session_limit": [{"ref": "8.2.8", "family": "PCI-8", "title": "Sessions idle more than 15 minutes require re-authentication"}],
    "shell_timeout": [{"ref": "8.2.8", "family": "PCI-8", "title": "Sessions idle more than 15 minutes require re-authentication"}],
    "file_integrity": [{"ref": "11.5.2", "family": "PCI-11", "title": "A change-detection mechanism (file-integrity monitoring) is deployed"}],
    "debsums": [{"ref": "11.5.2", "family": "PCI-11", "title": "A change-detection mechanism (file-integrity monitoring) is deployed"}],
    "aide_audit_protect": [
        {"ref": "11.5.2", "family": "PCI-11", "title": "A change-detection mechanism (file-integrity monitoring) is deployed"},
        {"ref": "10.3.2", "family": "PCI-10", "title": "Audit log files are protected from unauthorized modifications"},
    ],
    "audit_rules": [{"ref": "10.2.1", "family": "PCI-10", "title": "Audit logs are enabled and active"}],
    "audit_boot": [{"ref": "10.2.1", "family": "PCI-10", "title": "Audit logs are enabled and active"}],
    "auditd_service": [{"ref": "10.2.1", "family": "PCI-10", "title": "Audit logs are enabled and active"}],
    "process_acct": [{"ref": "10.2.1", "family": "PCI-10", "title": "Audit logs are enabled and active"}],
    "audit_immutable": [{"ref": "10.3.2", "family": "PCI-10", "title": "Audit log files are protected from unauthorized modifications"}],
    "vsnfd_audit_retention": [{"ref": "10.5.1", "family": "PCI-10", "title": "Audit log history is retained for at least 12 months"}],
    "vsnfd_journald_size": [{"ref": "10.5.1", "family": "PCI-10", "title": "Audit log history is retained for at least 12 months"}],
    "vsnfd_disk_encryption": [{"ref": "3.5.1", "family": "PCI-3", "title": "PAN is rendered unreadable wherever it is stored using strong cryptography"}],
    "apt_show_versions": [{"ref": "6.3.1", "family": "PCI-6", "title": "Security vulnerabilities are identified and addressed"}],
}


# ──────────────────────────────────────────────────────────────────────────
# HIPAA Security Rule — 45 CFR §164.312 Technical Safeguards. Paragraph-level
# refs only: the rule names implementation specifications ((a)(2)(i)–(iv),
# (e)(2)(i)–(ii)), not product settings, so this is intentionally a coverage
# indicator for the technical-safeguards subset — NOT a HIPAA assessment
# (administrative §164.308, physical §164.310 and organizational §164.314/316
# safeguards cannot be measured by SSH hardening checks).
# ──────────────────────────────────────────────────────────────────────────
HIPAA_TECH = {
    "ssh_perms": [{"ref": "164.312(a)(1)", "family": "164.312(a)", "title": "Access control — technical controls allowing access only to authorized persons or software"}],
    "file_perms": [{"ref": "164.312(a)(1)", "family": "164.312(a)", "title": "Access control — technical controls allowing access only to authorized persons or software"}],
    "default_umask": [{"ref": "164.312(a)(1)", "family": "164.312(a)", "title": "Access control — technical controls allowing access only to authorized persons or software"}],
    "apparmor": [{"ref": "164.312(a)(1)", "family": "164.312(a)", "title": "Access control — technical controls allowing access only to authorized persons or software"}],
    "pam_tmpdir": [{"ref": "164.312(a)(1)", "family": "164.312(a)", "title": "Access control — technical controls allowing access only to authorized persons or software"}],
    "mem_protection": [{"ref": "164.312(a)(1)", "family": "164.312(a)", "title": "Access control — technical controls allowing access only to authorized persons or software"}],
    "sysctl_hardening": [{"ref": "164.312(a)(1)", "family": "164.312(a)", "title": "Access control — technical controls allowing access only to authorized persons or software"}],
    "inactive_accounts": [{"ref": "164.312(a)(1)", "family": "164.312(a)", "title": "Access control — technical controls allowing access only to authorized persons or software"}],
    "session_limit": [{"ref": "164.312(a)(2)(iii)", "family": "164.312(a)", "title": "Automatic logoff — electronic sessions terminate after a predetermined time of inactivity"}],
    "shell_timeout": [{"ref": "164.312(a)(2)(iii)", "family": "164.312(a)", "title": "Automatic logoff — electronic sessions terminate after a predetermined time of inactivity"}],
    "vsnfd_disk_encryption": [{"ref": "164.312(a)(2)(iv)", "family": "164.312(a)", "title": "Encryption and decryption — mechanism to encrypt and decrypt ePHI (Addressable)"}],
    "auditd_service": [{"ref": "164.312(b)", "family": "164.312(b)", "title": "Audit controls — mechanisms that record and examine activity in systems containing ePHI"}],
    "audit_rules": [{"ref": "164.312(b)", "family": "164.312(b)", "title": "Audit controls — mechanisms that record and examine activity in systems containing ePHI"}],
    "audit_boot": [{"ref": "164.312(b)", "family": "164.312(b)", "title": "Audit controls — mechanisms that record and examine activity in systems containing ePHI"}],
    "journald": [{"ref": "164.312(b)", "family": "164.312(b)", "title": "Audit controls — mechanisms that record and examine activity in systems containing ePHI"}],
    "process_acct": [{"ref": "164.312(b)", "family": "164.312(b)", "title": "Audit controls — mechanisms that record and examine activity in systems containing ePHI"}],
    "vsnfd_audit_retention": [{"ref": "164.312(b)", "family": "164.312(b)", "title": "Audit controls — mechanisms that record and examine activity in systems containing ePHI"}],
    "vsnfd_journald_size": [{"ref": "164.312(b)", "family": "164.312(b)", "title": "Audit controls — mechanisms that record and examine activity in systems containing ePHI"}],
    "file_integrity": [
        {"ref": "164.312(c)(1)", "family": "164.312(c)", "title": "Integrity — protect ePHI from improper alteration or destruction"},
        {"ref": "164.312(c)(2)", "family": "164.312(c)", "title": "Mechanism to authenticate ePHI — corroborate that ePHI has not been altered or destroyed"},
    ],
    "debsums": [{"ref": "164.312(c)(1)", "family": "164.312(c)", "title": "Integrity — protect ePHI from improper alteration or destruction"}],
    "aide_audit_protect": [
        {"ref": "164.312(c)(1)", "family": "164.312(c)", "title": "Integrity — protect ePHI from improper alteration or destruction"},
        {"ref": "164.312(c)(2)", "family": "164.312(c)", "title": "Mechanism to authenticate ePHI — corroborate that ePHI has not been altered or destroyed"},
    ],
    "audit_immutable": [{"ref": "164.312(c)(1)", "family": "164.312(c)", "title": "Integrity — protect ePHI from improper alteration or destruction"}],
    "vsnfd_secure_boot": [{"ref": "164.312(c)(1)", "family": "164.312(c)", "title": "Integrity — protect ePHI from improper alteration or destruction"}],
    "vsnfd_kernel_lockdown": [{"ref": "164.312(c)(1)", "family": "164.312(c)", "title": "Integrity — protect ePHI from improper alteration or destruction"}],
    "pw_quality": [{"ref": "164.312(d)", "family": "164.312(d)", "title": "Person or entity authentication — verify a person or entity seeking access is the one claimed"}],
    "pw_history": [{"ref": "164.312(d)", "family": "164.312(d)", "title": "Person or entity authentication — verify a person or entity seeking access is the one claimed"}],
    "pw_aging": [{"ref": "164.312(d)", "family": "164.312(d)", "title": "Person or entity authentication — verify a person or entity seeking access is the one claimed"}],
    "pw_hash_rounds": [{"ref": "164.312(d)", "family": "164.312(d)", "title": "Person or entity authentication — verify a person or entity seeking access is the one claimed"}],
    "pam_faillock": [{"ref": "164.312(d)", "family": "164.312(d)", "title": "Person or entity authentication — verify a person or entity seeking access is the one claimed"}],
    "pam_nullok_removal": [{"ref": "164.312(d)", "family": "164.312(d)", "title": "Person or entity authentication — verify a person or entity seeking access is the one claimed"}],
    "ssh_crypto": [
        {"ref": "164.312(e)(1)", "family": "164.312(e)", "title": "Transmission security — guard against unauthorized access to ePHI transmitted over a network"},
        {"ref": "164.312(e)(2)(ii)", "family": "164.312(e)", "title": "Encryption — mechanism to encrypt ePHI whenever deemed appropriate (Addressable)"},
    ],
}


# ──────────────────────────────────────────────────────────────────────────
# SOC 2 — AICPA Trust Services Criteria. Only the criteria measurable by host
# configuration are mapped: CC6.x (logical access) and CC7.x (system
# operations/monitoring). Refs are the standard CC point-of-focus numbers.
# ──────────────────────────────────────────────────────────────────────────
SOC2_TSC = {
    "ssh_perms": [
        {"ref": "CC6.1", "family": "CC6", "title": "Logical access security software, infrastructure and architectures restrict access to authorized users"},
        {"ref": "CC6.3", "family": "CC6", "title": "Access is authorized based on roles and removed when no longer needed"},
    ],
    "file_perms": [
        {"ref": "CC6.1", "family": "CC6", "title": "Logical access security software, infrastructure and architectures restrict access to authorized users"},
        {"ref": "CC6.3", "family": "CC6", "title": "Access is authorized based on roles and removed when no longer needed"},
    ],
    "default_umask": [{"ref": "CC6.1", "family": "CC6", "title": "Logical access security software, infrastructure and architectures restrict access to authorized users"}],
    "apparmor": [
        {"ref": "CC6.1", "family": "CC6", "title": "Logical access security software, infrastructure and architectures restrict access to authorized users"},
        {"ref": "CC6.8", "family": "CC6", "title": "Controls prevent or detect and act upon unauthorized or malicious software"},
    ],
    "pam_tmpdir": [{"ref": "CC6.1", "family": "CC6", "title": "Logical access security software, infrastructure and architectures restrict access to authorized users"}],
    "session_limit": [{"ref": "CC6.1", "family": "CC6", "title": "Logical access security software, infrastructure and architectures restrict access to authorized users"}],
    "shell_timeout": [{"ref": "CC6.1", "family": "CC6", "title": "Logical access security software, infrastructure and architectures restrict access to authorized users"}],
    "pam_faillock": [{"ref": "CC6.1", "family": "CC6", "title": "Logical access security software, infrastructure and architectures restrict access to authorized users"}],
    "pam_nullok_removal": [{"ref": "CC6.1", "family": "CC6", "title": "Logical access security software, infrastructure and architectures restrict access to authorized users"}],
    "inactive_accounts": [{"ref": "CC6.2", "family": "CC6", "title": "Credentials are registered, authorized and deprovisioned over the user lifecycle"}],
    "pw_quality": [{"ref": "CC6.2", "family": "CC6", "title": "Credentials are registered, authorized and deprovisioned over the user lifecycle"}],
    "pw_history": [{"ref": "CC6.2", "family": "CC6", "title": "Credentials are registered, authorized and deprovisioned over the user lifecycle"}],
    "pw_aging": [{"ref": "CC6.2", "family": "CC6", "title": "Credentials are registered, authorized and deprovisioned over the user lifecycle"}],
    "pw_hash_rounds": [{"ref": "CC6.2", "family": "CC6", "title": "Credentials are registered, authorized and deprovisioned over the user lifecycle"}],
    "sshd_hardening": [{"ref": "CC6.1", "family": "CC6", "title": "Logical access security software, infrastructure and architectures restrict access to authorized users"}],
    "sysctl_hardening": [{"ref": "CC6.6", "family": "CC6", "title": "Boundary protections restrict unauthorized traffic and access attempts"}],
    "net_protocols": [{"ref": "CC6.6", "family": "CC6", "title": "Boundary protections restrict unauthorized traffic and access attempts"}],
    "fs_modules": [{"ref": "CC6.6", "family": "CC6", "title": "Boundary protections restrict unauthorized traffic and access attempts"}],
    "disable_services": [{"ref": "CC6.6", "family": "CC6", "title": "Boundary protections restrict unauthorized traffic and access attempts"}],
    "remove_legacy_svcs": [{"ref": "CC6.6", "family": "CC6", "title": "Boundary protections restrict unauthorized traffic and access attempts"}],
    "pve_fail2ban": [{"ref": "CC6.6", "family": "CC6", "title": "Boundary protections restrict unauthorized traffic and access attempts"}],
    "ssh_crypto": [{"ref": "CC6.7", "family": "CC6", "title": "Transmission and movement of data is restricted to authorized channels using encryption"}],
    "usb_storage": [{"ref": "CC6.7", "family": "CC6", "title": "Transmission and movement of data is restricted — removable media controlled"}],
    "vsnfd_disk_encryption": [{"ref": "CC6.1", "family": "CC6", "title": "Data at rest protected per the entity's confidentiality commitments (encryption of stored data)"}],
    "mem_protection": [{"ref": "CC6.8", "family": "CC6", "title": "Controls prevent or detect and act upon unauthorized or malicious software"}],
    "auditd_service": [
        {"ref": "CC7.1", "family": "CC7", "title": "Detection and monitoring procedures identify configuration changes and susceptibilities"},
        {"ref": "CC7.2", "family": "CC7", "title": "System is monitored to detect potential malicious software and other events"},
    ],
    "audit_rules": [
        {"ref": "CC7.1", "family": "CC7", "title": "Detection and monitoring procedures identify configuration changes and susceptibilities"},
        {"ref": "CC7.2", "family": "CC7", "title": "System is monitored to detect potential malicious software and other events"},
    ],
    "audit_boot": [{"ref": "CC7.2", "family": "CC7", "title": "System is monitored to detect potential malicious software and other events"}],
    "journald": [{"ref": "CC7.1", "family": "CC7", "title": "Detection and monitoring procedures identify configuration changes and susceptibilities"}],
    "process_acct": [{"ref": "CC7.1", "family": "CC7", "title": "Detection and monitoring procedures identify configuration changes and susceptibilities"}],
    "sysstat": [{"ref": "CC7.1", "family": "CC7", "title": "Detection and monitoring procedures identify configuration changes and susceptibilities"}],
    "apt_show_versions": [{"ref": "CC7.1", "family": "CC7", "title": "Detection and monitoring procedures identify vulnerabilities to cyber threats"}],
    "file_integrity": [{"ref": "CC7.2", "family": "CC7", "title": "System is monitored to detect changes to configurations and files"}],
    "debsums": [{"ref": "CC7.2", "family": "CC7", "title": "System is monitored to detect changes to configurations and files"}],
    "aide_audit_protect": [{"ref": "CC7.2", "family": "CC7", "title": "System is monitored to detect changes to configurations and files"}],
    "audit_immutable": [{"ref": "CC7.2", "family": "CC7", "title": "System is monitored to detect changes to configurations and files"}],
    "vsnfd_audit_retention": [{"ref": "CC7.2", "family": "CC7", "title": "System is monitored — log retention supports evaluation of events"}],
    "vsnfd_journald_size": [{"ref": "CC7.2", "family": "CC7", "title": "System is monitored — adequate log storage supports evaluation of events"}],
}


# ──────────────────────────────────────────────────────────────────────────
# CIS Critical Security Controls v8.1 — refs are the standard control.safeguard
# numbers (e.g. 4.8 = "Uninstall or Disable Unnecessary Services"). Only
# host-hardening-mappable safeguards are listed; CIS v8 is largely inventory /
# process-oriented, so most safeguards legitimately have no check.
# ──────────────────────────────────────────────────────────────────────────
CIS_V8 = {
    "mount_options": [{"ref": "4.1", "family": "CIS-4", "title": "Establish and maintain a secure configuration process for enterprise assets"}],
    "core_dumps": [{"ref": "4.1", "family": "CIS-4", "title": "Establish and maintain a secure configuration process for enterprise assets"}],
    "sysctl_hardening": [{"ref": "4.1", "family": "CIS-4", "title": "Establish and maintain a secure configuration process for enterprise assets"}],
    "default_umask": [{"ref": "4.1", "family": "CIS-4", "title": "Establish and maintain a secure configuration process for enterprise assets"}],
    "cron_hardening": [{"ref": "4.1", "family": "CIS-4", "title": "Establish and maintain a secure configuration process for enterprise assets"}],
    "pam_tmpdir": [{"ref": "4.1", "family": "CIS-4", "title": "Establish and maintain a secure configuration process for enterprise assets"}],
    "session_limit": [{"ref": "4.3", "family": "CIS-4", "title": "Configure automatic session locking on enterprise assets"}],
    "shell_timeout": [{"ref": "4.3", "family": "CIS-4", "title": "Configure automatic session locking on enterprise assets"}],
    "pam_nullok_removal": [{"ref": "4.7", "family": "CIS-4", "title": "Manage default accounts on enterprise assets and software"}],
    "disable_services": [{"ref": "4.8", "family": "CIS-4", "title": "Uninstall or disable unnecessary services on enterprise assets and software"}],
    "remove_legacy_svcs": [{"ref": "4.8", "family": "CIS-4", "title": "Uninstall or disable unnecessary services on enterprise assets and software"}],
    "fs_modules": [{"ref": "4.8", "family": "CIS-4", "title": "Uninstall or disable unnecessary services on enterprise assets and software"}],
    "net_protocols": [{"ref": "4.8", "family": "CIS-4", "title": "Uninstall or disable unnecessary services on enterprise assets and software"}],
    "pkg_cleanup": [{"ref": "4.8", "family": "CIS-4", "title": "Uninstall or disable unnecessary services on enterprise assets and software"}],
    "restrict_compilers": [{"ref": "4.8", "family": "CIS-4", "title": "Uninstall or disable unnecessary services on enterprise assets and software"}],
    "pw_quality": [{"ref": "5.2", "family": "CIS-5", "title": "Use unique passwords for all enterprise assets"}],
    "pw_history": [{"ref": "5.2", "family": "CIS-5", "title": "Use unique passwords for all enterprise assets"}],
    "pw_aging": [{"ref": "5.2", "family": "CIS-5", "title": "Use unique passwords for all enterprise assets"}],
    "pw_hash_rounds": [{"ref": "5.2", "family": "CIS-5", "title": "Use unique passwords for all enterprise assets"}],
    "pam_faillock": [{"ref": "5.2", "family": "CIS-5", "title": "Use unique passwords for all enterprise assets"}],
    "inactive_accounts": [{"ref": "5.3", "family": "CIS-5", "title": "Disable dormant accounts"}],
    "sshd_hardening": [{"ref": "5.4", "family": "CIS-5", "title": "Restrict administrator privileges to dedicated administrator accounts"}],
    "ssh_perms": [{"ref": "5.4", "family": "CIS-5", "title": "Restrict administrator privileges to dedicated administrator accounts"}],
    "ssh_crypto": [{"ref": "3.10", "family": "CIS-3", "title": "Encrypt sensitive data in transit"}],
    "vsnfd_disk_encryption": [{"ref": "3.11", "family": "CIS-3", "title": "Encrypt sensitive data at rest"}],
    "auditd_service": [{"ref": "8.2", "family": "CIS-8", "title": "Collect audit logs"}],
    "journald": [{"ref": "8.2", "family": "CIS-8", "title": "Collect audit logs"}],
    "process_acct": [{"ref": "8.2", "family": "CIS-8", "title": "Collect audit logs"}],
    "vsnfd_journald_size": [{"ref": "8.3", "family": "CIS-8", "title": "Ensure adequate audit log storage"}],
    "vsnfd_audit_retention": [{"ref": "8.3", "family": "CIS-8", "title": "Ensure adequate audit log storage"}],
    "audit_rules": [{"ref": "8.5", "family": "CIS-8", "title": "Collect detailed audit logs"}],
    "audit_boot": [{"ref": "8.5", "family": "CIS-8", "title": "Collect detailed audit logs"}],
    "usb_storage": [{"ref": "10.3", "family": "CIS-10", "title": "Disable autorun and autoplay for removable media"}],
    "mem_protection": [{"ref": "10.4", "family": "CIS-10", "title": "Enable anti-exploitation features (e.g. ASLR, DEP)"}],
    "apparmor": [{"ref": "10.4", "family": "CIS-10", "title": "Enable anti-exploitation features (e.g. mandatory access control)"}],
    "pve_fail2ban": [{"ref": "13.3", "family": "CIS-13", "title": "Deploy a network intrusion detection / blocking solution"}],
}


# ──────────────────────────────────────────────────────────────────────────
# ENS — Esquema Nacional de Seguridad (Real Decreto 311/2022, Anexo II).
# Refs are the real ENS measure codes (op.acc / op.exp / op.mon / mp.*) —
# Spanish titles kept verbatim. Only the basic/media-category measures with a
# host-hardening equivalent are mapped; ENS is largely organizational, so most
# of Anexo II legitimately has no SSH check.
# ──────────────────────────────────────────────────────────────────────────
ENS_RD311 = {
    "ssh_perms": [{"ref": "op.acc.2", "family": "op.acc", "title": "Requisitos de acceso — mecanismos de control de acceso en los recursos"}],
    "file_perms": [{"ref": "op.acc.2", "family": "op.acc", "title": "Requisitos de acceso — mecanismos de control de acceso en los recursos"}],
    "default_umask": [{"ref": "op.acc.2", "family": "op.acc", "title": "Requisitos de acceso — mecanismos de control de acceso en los recursos"}],
    "apparmor": [
        {"ref": "op.acc.2", "family": "op.acc", "title": "Requisitos de acceso — mecanismos de control de acceso en los recursos"},
        {"ref": "op.exp.6", "family": "op.exp", "title": "Protección frente a código dañino"},
    ],
    "pam_tmpdir": [{"ref": "op.acc.2", "family": "op.acc", "title": "Requisitos de acceso — mecanismos de control de acceso en los recursos"}],
    "inactive_accounts": [{"ref": "op.acc.4", "family": "op.acc", "title": "Proceso de gestión de derechos de acceso — mínimo privilegio, revisión periódica"}],
    "pam_faillock": [{"ref": "op.acc.6", "family": "op.acc", "title": "Mecanismo de autenticación — bloqueo por intentos fallidos"}],
    "pw_quality": [{"ref": "op.acc.6", "family": "op.acc", "title": "Mecanismo de autenticación — robustez de credenciales"}],
    "pw_history": [{"ref": "op.acc.6", "family": "op.acc", "title": "Mecanismo de autenticación — cambio periódico, no reutilización"}],
    "pw_aging": [{"ref": "op.acc.6", "family": "op.acc", "title": "Mecanismo de autenticación — caducidad de credenciales"}],
    "pw_hash_rounds": [{"ref": "op.acc.6", "family": "op.acc", "title": "Mecanismo de autenticación — protección criptográfica de credenciales"}],
    "pam_nullok_removal": [{"ref": "op.acc.6", "family": "op.acc", "title": "Mecanismo de autenticación — identificación y autenticación de usuarios"}],
    "session_limit": [{"ref": "op.acc.6", "family": "op.acc", "title": "Mecanismo de autenticación — control de sesiones"}],
    "shell_timeout": [{"ref": "op.acc.6", "family": "op.acc", "title": "Mecanismo de autenticación — control de sesiones"}],
    "sshd_hardening": [{"ref": "op.acc.6", "family": "op.acc", "title": "Mecanismo de autenticación — autenticación reforzada de acceso administrativo"}],
    "fs_modules": [{"ref": "op.exp.2", "family": "op.exp", "title": "Configuración de seguridad — funcionalidad mínima"}],
    "core_dumps": [{"ref": "op.exp.2", "family": "op.exp", "title": "Configuración de seguridad — seguridad por defecto"}],
    "mount_options": [{"ref": "op.exp.2", "family": "op.exp", "title": "Configuración de seguridad — guía de bastionado"}],
    "disable_services": [{"ref": "op.exp.2", "family": "op.exp", "title": "Configuración de seguridad — funcionalidad mínima"}],
    "remove_legacy_svcs": [{"ref": "op.exp.2", "family": "op.exp", "title": "Configuración de seguridad — funcionalidad mínima"}],
    "net_protocols": [{"ref": "op.exp.2", "family": "op.exp", "title": "Configuración de seguridad — funcionalidad mínima"}],
    "pkg_cleanup": [{"ref": "op.exp.2", "family": "op.exp", "title": "Configuración de seguridad — funcionalidad mínima"}],
    "restrict_compilers": [{"ref": "op.exp.2", "family": "op.exp", "title": "Configuración de seguridad — funcionalidad mínima"}],
    "usb_storage": [{"ref": "op.exp.2", "family": "op.exp", "title": "Configuración de seguridad — funcionalidad mínima"}],
    "cron_hardening": [{"ref": "op.exp.2", "family": "op.exp", "title": "Configuración de seguridad — seguridad por defecto"}],
    "sysctl_hardening": [{"ref": "op.exp.2", "family": "op.exp", "title": "Configuración de seguridad — guía de bastionado"}],
    "mem_protection": [{"ref": "op.exp.6", "family": "op.exp", "title": "Protección frente a código dañino"}],
    "vsnfd_secure_boot": [{"ref": "op.exp.2", "family": "op.exp", "title": "Configuración de seguridad — cadena de arranque confiable"}],
    "vsnfd_kernel_lockdown": [{"ref": "op.exp.2", "family": "op.exp", "title": "Configuración de seguridad — protección del núcleo"}],
    "apt_show_versions": [{"ref": "op.exp.4", "family": "op.exp", "title": "Mantenimiento y actualizaciones de seguridad"}],
    "file_integrity": [
        {"ref": "op.exp.3", "family": "op.exp", "title": "Gestión de la configuración de seguridad — integridad de la configuración"},
        {"ref": "op.mon.1", "family": "op.mon", "title": "Detección de intrusión"},
    ],
    "debsums": [{"ref": "op.exp.3", "family": "op.exp", "title": "Gestión de la configuración de seguridad — integridad de la configuración"}],
    "auditd_service": [{"ref": "op.exp.8", "family": "op.exp", "title": "Registro de la actividad — registro de auditoría activado en los servidores"}],
    "audit_rules": [{"ref": "op.exp.8", "family": "op.exp", "title": "Registro de la actividad — usuario, fecha, objeto, tipo y resultado del evento"}],
    "audit_boot": [{"ref": "op.exp.8", "family": "op.exp", "title": "Registro de la actividad — registro de auditoría activado en los servidores"}],
    "journald": [{"ref": "op.exp.8", "family": "op.exp", "title": "Registro de la actividad — registro de auditoría activado en los servidores"}],
    "process_acct": [{"ref": "op.exp.8", "family": "op.exp", "title": "Registro de la actividad — registro de auditoría activado en los servidores"}],
    "sysstat": [{"ref": "op.exp.8", "family": "op.exp", "title": "Registro de la actividad — registro de auditoría activado en los servidores"}],
    "audit_immutable": [{"ref": "op.exp.8", "family": "op.exp", "title": "Registro de la actividad — protección de los registros"}],
    "vsnfd_audit_retention": [{"ref": "op.exp.8", "family": "op.exp", "title": "Registro de la actividad — conservación de los registros"}],
    "vsnfd_journald_size": [{"ref": "op.exp.8", "family": "op.exp", "title": "Registro de la actividad — capacidad de almacenamiento"}],
    "pve_fail2ban": [{"ref": "op.mon.1", "family": "op.mon", "title": "Detección de intrusión"}],
    "aide_audit_protect": [{"ref": "op.mon.1", "family": "op.mon", "title": "Detección de intrusión"}],
    "ssh_crypto": [
        {"ref": "mp.com.2", "family": "mp.com", "title": "Protección de la confidencialidad de las comunicaciones"},
        {"ref": "mp.com.3", "family": "mp.com", "title": "Protección de la integridad y de la autenticidad de las comunicaciones"},
    ],
    "vsnfd_disk_encryption": [{"ref": "mp.si.2", "family": "mp.si", "title": "Criptografía de soportes de información"}],
}


# ──────────────────────────────────────────────────────────────────────────
# Cyber Essentials (NCSC, UK) — the scheme defines five technical control
# themes, not publicly-numbered controls. Refs therefore name the theme
# itself; this is an honest theme-level mapping, not a fabricated numbering.
# ──────────────────────────────────────────────────────────────────────────
CYBER_ESSENTIALS = {
    "sysctl_hardening": [
        {"ref": "Firewalls", "family": "CE-FW", "title": "Boundary protection — only safe and necessary network services accessible"},
        {"ref": "Secure Configuration", "family": "CE-SC", "title": "Devices and software configured to reduce vulnerabilities"},
    ],
    "net_protocols": [
        {"ref": "Firewalls", "family": "CE-FW", "title": "Boundary protection — only safe and necessary network services accessible"},
        {"ref": "Secure Configuration", "family": "CE-SC", "title": "Devices and software configured to reduce vulnerabilities"},
    ],
    "pve_fail2ban": [{"ref": "Firewalls", "family": "CE-FW", "title": "Boundary protection — block unauthorized access attempts"}],
    "fs_modules": [{"ref": "Secure Configuration", "family": "CE-SC", "title": "Remove or disable unnecessary functionality"}],
    "core_dumps": [{"ref": "Secure Configuration", "family": "CE-SC", "title": "Devices and software configured to reduce vulnerabilities"}],
    "mount_options": [{"ref": "Secure Configuration", "family": "CE-SC", "title": "Devices and software configured to reduce vulnerabilities"}],
    "disable_services": [{"ref": "Secure Configuration", "family": "CE-SC", "title": "Remove or disable unnecessary software and services"}],
    "remove_legacy_svcs": [{"ref": "Secure Configuration", "family": "CE-SC", "title": "Remove or disable unnecessary software and services"}],
    "restrict_compilers": [{"ref": "Secure Configuration", "family": "CE-SC", "title": "Remove or disable unnecessary software and services"}],
    "cron_hardening": [{"ref": "Secure Configuration", "family": "CE-SC", "title": "Devices and software configured to reduce vulnerabilities"}],
    "default_umask": [{"ref": "Secure Configuration", "family": "CE-SC", "title": "Devices and software configured to reduce vulnerabilities"}],
    "usb_storage": [{"ref": "Secure Configuration", "family": "CE-SC", "title": "Remove or disable unnecessary functionality"}],
    "ssh_crypto": [{"ref": "Secure Configuration", "family": "CE-SC", "title": "Devices and software configured to reduce vulnerabilities"}],
    "ssh_perms": [{"ref": "User Access Control", "family": "CE-UAC", "title": "Administrative privileges granted only to those who need them"}],
    "file_perms": [{"ref": "User Access Control", "family": "CE-UAC", "title": "Access to data and services assigned on a need-to-know basis"}],
    "sshd_hardening": [{"ref": "User Access Control", "family": "CE-UAC", "title": "Administrative privileges granted only to those who need them"}],
    "pam_faillock": [{"ref": "User Access Control", "family": "CE-UAC", "title": "Brute-force protection on authentication"}],
    "pam_nullok_removal": [{"ref": "User Access Control", "family": "CE-UAC", "title": "Accounts protected by authentication"}],
    "pw_quality": [{"ref": "User Access Control", "family": "CE-UAC", "title": "Password quality controls"}],
    "pw_history": [{"ref": "User Access Control", "family": "CE-UAC", "title": "Password quality controls"}],
    "pw_aging": [{"ref": "User Access Control", "family": "CE-UAC", "title": "Password quality controls"}],
    "pw_hash_rounds": [{"ref": "User Access Control", "family": "CE-UAC", "title": "Passwords protected with suitable hashing"}],
    "inactive_accounts": [{"ref": "User Access Control", "family": "CE-UAC", "title": "Accounts disabled promptly when no longer needed"}],
    "session_limit": [{"ref": "User Access Control", "family": "CE-UAC", "title": "Accounts protected by authentication"}],
    "shell_timeout": [{"ref": "User Access Control", "family": "CE-UAC", "title": "Accounts protected by authentication"}],
    "apparmor": [{"ref": "Malware Protection", "family": "CE-MP", "title": "Restrict execution of unauthorized/malicious code"}],
    "mem_protection": [{"ref": "Malware Protection", "family": "CE-MP", "title": "Restrict execution of unauthorized/malicious code"}],
    "apt_show_versions": [{"ref": "Security Update Management", "family": "CE-SUM", "title": "Devices and software kept updated and licensed"}],
    "pkg_cleanup": [{"ref": "Security Update Management", "family": "CE-SUM", "title": "Remove software that is no longer supported"}],
}


# Master lookup
FRAMEWORK_MAPPING = {
    "cmmc1": CMMC_L1,
    "cmmc2": CMMC_L2_NIST_171,
    "nist53": NIST_800_53,
    "stig": DISA_STIG,
    "iso": ISO_27001,
    "bsi": BSI_GRUNDSCHUTZ,
    "vs-nfd": BSI_GRUNDSCHUTZ,  # VS-NfD inherits BSI Grundschutz refs
    "dr": ANSSI_BP028,  # Diffusion Restreinte (II 901) — French Linux baseline = ANSSI-BP-028
    "rgs": ANSSI_BP028,  # RGS references ANSSI-BP-028 for Linux system hardening
    "pci": PCI_DSS,
    "hipaa": HIPAA_TECH,  # 45 CFR §164.312 technical safeguards only — see HIPAA_META note
    "soc2": SOC2_TSC,
    "cisv8": CIS_V8,  # CIS Critical Security Controls v8.1
    "ens": ENS_RD311,
    "ce": CYBER_ESSENTIALS,
    # gdpr / dora have no backend mapping on purpose — they are organizational
    # & legal frameworks shown as indicator-only cards (like nis2), not
    # technical control catalogues that could be meaningfully assessed by SSH
    # hardening checks.
}


# ──────────────────────────────────────────────────────────────────────────
# Remediation hints — short, actionable, in English. Keep these focused on
# WHAT the operator should do; the specific shell command is in the apply
# block of `_HARDENING_PROFILES` (manager.py).
# ──────────────────────────────────────────────────────────────────────────
REMEDIATION = {
    "pam_faillock": {
        "summary": "Lock accounts after 5 failed login attempts.",
        "how_to_fix": 'ProxmoxVEx > Settings > Hardening > Apply "PAM faillock". Manually: edit /etc/security/faillock.conf with deny=5, unlock_time=900, fail_interval=900, then enable faillock in /etc/pam.d/common-auth and common-account.',
    },
    "session_limit": {
        "summary": "Limit concurrent sessions per user (TMOUT + maxlogins).",
        "how_to_fix": "Set TMOUT=900 in /etc/profile.d/tmout.sh and maxlogins in /etc/security/limits.conf. Apply via ProxmoxVEx hardening or manual.",
    },
    "shell_timeout": {
        "summary": "Auto-logout idle interactive shells after a defined idle time.",
        "how_to_fix": "Set TMOUT=900 in /etc/profile.d/tmout.sh and ensure it is exported and read-only. ProxmoxVEx hardening apply handles this.",
    },
    "login_banners": {
        "summary": "Display a legal/security warning banner before login.",
        "how_to_fix": "Populate /etc/issue, /etc/issue.net, /etc/motd with the appropriate notice (DoD CnC banner for federal use). Apply via ProxmoxVEx.",
    },
    "inactive_accounts": {
        "summary": "Disable user accounts after a defined period of inactivity (35 days for STIG).",
        "how_to_fix": "Set INACTIVE=35 in /etc/default/useradd and run useradd -D -f 35. ProxmoxVEx hardening enforces 35 days by default.",
    },
    "pw_quality": {
        "summary": "Enforce password complexity (length, character classes).",
        "how_to_fix": "Configure /etc/security/pwquality.conf with minlen=14 (12 for VS-NfD), minclass=4, dcredit/ucredit/lcredit/ocredit=-1.",
    },
    "pw_history": {
        "summary": "Prevent password reuse for the last N generations (5+ recommended).",
        "how_to_fix": 'In /etc/pam.d/common-password, set "remember=5" on the pam_pwhistory line.',
    },
    "pw_aging": {
        "summary": "Set sensible password aging (max 60-90 days, min 1 day, warn 7 days).",
        "how_to_fix": "Edit /etc/login.defs: PASS_MAX_DAYS 60, PASS_MIN_DAYS 1, PASS_WARN_AGE 7. Existing accounts: chage -M 60 -m 1 -W 7 <user>.",
    },
    "pw_hash_rounds": {
        "summary": "Use strong password hashing (yescrypt or SHA-512 with rounds≥5000).",
        "how_to_fix": "In /etc/pam.d/common-password: pam_unix.so ... yescrypt rounds=5 OR sha512 rounds=10000. ProxmoxVEx enforces yescrypt by default.",
    },
    "ssh_crypto": {
        "summary": "Restrict SSH to strong ciphers, KEX algorithms and MACs only.",
        "how_to_fix": "Append to /etc/ssh/sshd_config (or drop into /etc/ssh/sshd_config.d/): KexAlgorithms curve25519-sha256,curve25519-sha256@libssh.org; Ciphers chacha20-poly1305@openssh.com,aes256-gcm@openssh.com; MACs hmac-sha2-512-etm@openssh.com,hmac-sha2-256-etm@openssh.com. Reload sshd.",
    },
    "ssh_perms": {
        "summary": "sshd_config and host keys must be 0600 owned by root:root.",
        "how_to_fix": "chmod 600 /etc/ssh/sshd_config /etc/ssh/ssh_host_*_key; chown root:root /etc/ssh/*",
    },
    "file_perms": {
        "summary": "Critical config files have correct ownership and restrictive perms.",
        "how_to_fix": "ProxmoxVEx hardening apply enforces 644/640/600 on /etc/passwd, /etc/shadow, /etc/gshadow, /etc/group and similar.",
    },
    "default_umask": {
        "summary": "Default umask 027 so newly created files are not world-readable.",
        "how_to_fix": "Set UMASK 027 in /etc/login.defs and umask 027 in /etc/profile.d/umask.sh.",
    },
    "apparmor": {
        "summary": "Enable AppArmor with all profiles in enforce mode.",
        "how_to_fix": "apt install apparmor apparmor-profiles apparmor-utils; systemctl enable --now apparmor; aa-enforce /etc/apparmor.d/*",
    },
    "fs_modules": {
        "summary": "Disable unused/legacy filesystem kernel modules (cramfs, freevxfs, jffs2, hfs, hfsplus, udf, etc).",
        "how_to_fix": 'Add "install <module> /bin/true" entries to /etc/modprobe.d/cis-fs.conf and blacklist them.',
    },
    "usb_storage": {
        "summary": "Disable USB mass storage kernel module on servers.",
        "how_to_fix": 'echo "install usb-storage /bin/true" > /etc/modprobe.d/cis-usb.conf and blacklist usb-storage.',
    },
    "mount_options": {
        "summary": "/dev/shm, /tmp, /var/tmp mounted with nodev,nosuid,noexec.",  # nosec: B108 - compliance documentation text, not a temp path
        "how_to_fix": "Adjust /etc/fstab entries for tmpfs and tmp partitions. Remount: mount -o remount,nodev,nosuid,noexec /dev/shm.",
    },
    "core_dumps": {
        "summary": "Disable core dumps for SUID programs and unprivileged users.",
        "how_to_fix": 'Add "* hard core 0" to /etc/security/limits.conf and "fs.suid_dumpable = 0" to /etc/sysctl.d/.',
    },
    "audit_rules": {
        "summary": "auditd has rules for time changes, account events, MAC changes, network changes, file deletes, privilege use, etc.",
        "how_to_fix": "Drop a CIS-aligned ruleset into /etc/audit/rules.d/cis.rules and run augenrules --load. ProxmoxVEx hardening ships a complete ruleset.",
    },
    "audit_boot": {
        "summary": "Kernel auditing is enabled at boot via audit=1 GRUB parameter.",
        "how_to_fix": "Append audit=1 audit_backlog_limit=8192 to GRUB_CMDLINE_LINUX in /etc/default/grub, update-grub, reboot.",
    },
    "auditd_service": {
        "summary": "auditd service is enabled and running.",
        "how_to_fix": "apt install auditd; systemctl enable --now auditd",
    },
    "audit_immutable": {
        "summary": "Audit configuration is in immutable mode (-e 2) so rules cannot be changed without reboot.",
        "how_to_fix": 'Append "-e 2" as the LAST line of /etc/audit/rules.d/99-immutable.rules; augenrules --load; reboot to take effect.',
    },
    "aide_audit_protect": {
        "summary": "AIDE monitors /var/log/audit for tampering.",
        "how_to_fix": "Install aide; add /var/log/audit to /etc/aide/aide.conf.d/; aideinit; schedule daily aide --check.",
    },
    "journald": {
        "summary": "systemd-journald configured for persistent storage, compression, sane size cap.",
        "how_to_fix": "Edit /etc/systemd/journald.conf: Storage=persistent, Compress=yes, SystemMaxUse=2G, MaxRetentionSec=180day. Restart systemd-journald.",
    },
    "process_acct": {
        "summary": "Process accounting (acct/psacct) is enabled.",
        "how_to_fix": "apt install acct; systemctl enable --now acct",
    },
    "sysstat": {
        "summary": "sysstat (sar) is collecting system performance data.",
        "how_to_fix": 'apt install sysstat; set ENABLED="true" in /etc/default/sysstat; systemctl enable --now sysstat',
    },
    "file_integrity": {
        "summary": "AIDE (or equivalent) maintains a file-integrity baseline DB.",
        "how_to_fix": "apt install aide; aideinit; schedule daily aide --check via cron or systemd timer.",
    },
    "debsums": {
        "summary": "debsums verifies installed package files match their original checksums.",
        "how_to_fix": 'apt install debsums; schedule daily "debsums --all" run; alert on differences.',
    },
    "mem_protection": {
        "summary": "Memory protection enabled (NX, ASLR full).",
        "how_to_fix": "kernel.randomize_va_space=2 in /etc/sysctl.d/. NX requires NX-capable CPU + 64-bit kernel (default on Proxmox).",
    },
    "sysctl_hardening": {
        "summary": "Network/kernel sysctl hardening (rp_filter, syncookies, kptr_restrict, dmesg_restrict, etc.).",
        "how_to_fix": "ProxmoxVEx ships /etc/sysctl.d/99-ProxmoxVEx-hardening.conf with the full set. Apply via the hardening UI or sysctl --system.",
    },
    "pkg_cleanup": {
        "summary": "Remove unused/orphaned packages.",
        "how_to_fix": "apt autoremove --purge; apt purge $(deborphan)",
    },
    "remove_legacy_svcs": {
        "summary": "Remove legacy/insecure services (rsh, rlogin, telnet, nis, talk).",
        "how_to_fix": "apt purge rsh-* rlogin-* telnet telnetd talk talkd ntalk nis ypbind",
    },
    "disable_services": {
        "summary": "Disable services not needed on a Proxmox node (cups, avahi-daemon, etc.).",
        "how_to_fix": "systemctl disable --now cups avahi-daemon (only if your environment does not need them).",
    },
    "net_protocols": {
        "summary": "Disable rare network protocols (DCCP, SCTP, RDS, TIPC).",
        "how_to_fix": 'Add "install <proto> /bin/true" entries to /etc/modprobe.d/cis-net.conf.',
    },
    "restrict_compilers": {
        "summary": "Restrict gcc/cc and other build tools to root only on production servers.",
        "how_to_fix": "chmod 700 /usr/bin/gcc* /usr/bin/cc* /usr/bin/as ld (re-evaluate if you need to build modules locally).",
    },
    "cron_hardening": {
        "summary": "cron and at restricted to root via /etc/cron.allow and /etc/at.allow.",
        "how_to_fix": "echo root > /etc/cron.allow; echo root > /etc/at.allow; rm -f /etc/cron.deny /etc/at.deny; chmod 640 /etc/cron.allow /etc/at.allow.",
    },
    "pam_tmpdir": {
        "summary": "Per-user private /tmp via pam_tmpdir.",
        "how_to_fix": "apt install libpam-tmpdir; ensure pam_tmpdir.so is referenced in /etc/pam.d/common-session.",
    },
    "pve_fail2ban": {
        "summary": "fail2ban running with a [proxmox] jail for pveproxy/pvedaemon brute-force protection.",
        "how_to_fix": 'ProxmoxVEx > Settings > Hardening > Apply "fail2ban (PVE)". Auto-detects Debian version and picks iptables or nftables banaction.',
    },
    "apt_show_versions": {
        "summary": "apt-show-versions is installed for tracking which packages have updates pending.",
        "how_to_fix": 'apt install apt-show-versions; schedule "apt-show-versions -u" runs to identify outdated packages.',
    },
    "backup_dns": {
        "summary": "A secondary / backup DNS resolver is configured.",
        "how_to_fix": "Add a second nameserver entry in /etc/resolv.conf or your systemd-resolved config.",
    },
    "postfix_banner": {
        "summary": "Postfix mail banner does not disclose the OS / version.",
        "how_to_fix": "In /etc/postfix/main.cf set: smtpd_banner = $myhostname ESMTP. Reload postfix.",
    },
    "pam_password_repair": {
        "summary": 'Repairs a broken /etc/pam.d/common-password stack where pam_pwhistory.so use_authtok appears without a preceding pam_pwquality.so. Triggers "Authentication token manipulation error" on every passwd call until repaired.',
        "how_to_fix": 'ProxmoxVEx > Settings > Hardening > Apply "Repair PAM password stack (recovery)". Either inserts pam_pwquality.so before pam_pwhistory.so (preferred) or strips use_authtok from pwhistory if libpam-pwquality is not installed. Backup of the original file is saved as common-password.bak.repair-<timestamp>.',
    },
    "vsnfd_disk_encryption": {
        "summary": "Disk encryption (LUKS or ZFS native) for VS-NfD-classified data at rest.",
        "how_to_fix": "INFORMATIONAL — must be planned at install time. ProxmoxVEx cannot retroactively encrypt; document operator decision per BSI guidance.",
    },
    "vsnfd_audit_retention": {
        "summary": "journald MaxRetentionSec ≥ 6 months for VS-NfD audit retention.",
        "how_to_fix": "In /etc/systemd/journald.conf set MaxRetentionSec=180day. Ensure SystemMaxUse is sized accordingly.",
    },
    "vsnfd_journald_size": {
        "summary": "journald SystemMaxUse ≥ 1G to retain enough audit history.",
        "how_to_fix": "In /etc/systemd/journald.conf set SystemMaxUse=1G (or larger) and restart systemd-journald.",
    },
    "vsnfd_secure_boot": {
        "summary": "UEFI Secure Boot is enabled (or documented as compensating control).",
        "how_to_fix": "INFORMATIONAL — enable Secure Boot in UEFI; ensure shim/grub are signed. ProxmoxVEx detects but cannot enable Secure Boot.",
    },
    "vsnfd_kernel_lockdown": {
        "summary": "Linux kernel lockdown mode (integrity or confidentiality) is active.",
        "how_to_fix": 'Add "lockdown=integrity" (or "confidentiality") to GRUB_CMDLINE_LINUX, update-grub, reboot. Requires Secure Boot for full effect.',
    },
    "vsnfd_password_min_12": {
        "summary": "Minimum password length 12 (BSI-conformant).",
        "how_to_fix": "Set minlen=12 in /etc/security/pwquality.conf (ProxmoxVEx CIS profile uses minlen=14 by default which already satisfies this).",
    },
}


# ──────────────────────────────────────────────────────────────────────────
# Per-control severity (audit-style risk rating)
#
# - high          : Direct compromise / data-loss risk if missing
# - medium        : Defense-in-depth, detection or meaningful hardening gap
# - low           : Hygiene / good practice with marginal direct impact
# - informational : VS-NfD or operator-decision items that have no automated apply
# ──────────────────────────────────────────────────────────────────────────
SEVERITY = {
    # High — direct exposure
    "pam_faillock": "high",
    "sshd_hardening": "high",  # Root SSH login policy + MaxAuthTries
    "pam_nullok_removal": "high",  # Blocks empty-password PAM auth
    "ssh_crypto": "high",
    "ssh_perms": "high",
    "file_perms": "high",
    "pw_quality": "high",
    "pw_hash_rounds": "high",
    "audit_rules": "high",
    "apparmor": "high",
    "mem_protection": "high",
    "pve_fail2ban": "high",
    "usb_storage": "high",
    "audit_immutable": "high",
    "aide_audit_protect": "high",
    "core_dumps": "high",
    # Medium — detection / partial defense / config hygiene with real impact
    "pw_history": "medium",
    "pw_aging": "medium",
    "login_banners": "medium",
    "file_integrity": "medium",
    "audit_boot": "medium",
    "auditd_service": "medium",
    "journald": "medium",
    "inactive_accounts": "medium",
    "session_limit": "medium",
    "shell_timeout": "medium",
    "fs_modules": "medium",
    "mount_options": "medium",
    "sysctl_hardening": "medium",
    "debsums": "medium",
    "net_protocols": "medium",
    "disable_services": "medium",
    "remove_legacy_svcs": "medium",
    "restrict_compilers": "medium",
    "pam_tmpdir": "medium",
    "cron_hardening": "medium",
    "process_acct": "medium",
    "sysstat": "medium",
    "apt_show_versions": "medium",
    "pkg_cleanup": "medium",
    # Low — minor hygiene
    "default_umask": "low",
    "backup_dns": "low",
    "postfix_banner": "low",
    # Recovery / operational fixers — not a real compliance gap, but high-severity
    # if triggered (system can't change passwords).
    "pam_password_repair": "high",
    # Informational — VS-NfD specific, no auto-apply
    "vsnfd_disk_encryption": "informational",
    "vsnfd_audit_retention": "informational",
    "vsnfd_journald_size": "informational",
    "vsnfd_secure_boot": "informational",
    "vsnfd_kernel_lockdown": "informational",
    "vsnfd_password_min_12": "informational",
}


# Severity → recommended remediation timeline. Aligned with what most internal
# audit programs use (ISO 27001 surveillance audit, SOC2 Type II frequency).
RECOMMENDED_TIMELINE = {
    "high": {"days": 30, "label": "Within 30 days"},
    "medium": {"days": 90, "label": "Within 90 days"},
    "low": {"days": 180, "label": "Within 180 days"},
    "informational": {"days": None, "label": "Operator decision, document outcome"},
}


# Severity → priority numeric (1 = highest).
PRIORITY_LEVEL = {
    "high": 1,
    "medium": 2,
    "low": 3,
    "informational": 4,
}


# ──────────────────────────────────────────────────────────────────────────
# Framework metadata — for the cover page / scope statement.
# Keep this current with the actually-mapped revision.
# ──────────────────────────────────────────────────────────────────────────
FRAMEWORK_META = {
    "cmmc1": {
        "full_name": "CMMC Level 1 (FAR 52.204-21)",
        "revision": "CMMC Model 2.0, March 2024",
        "source_url": "https://dodcio.defense.gov/CMMC/",
        "control_count": 17,
        "note": "Basic safeguarding of Federal Contract Information (FCI) — the 15 FAR 52.204-21 requirements, expressed as 17 CMMC practices.",
    },
    "cmmc2": {
        "full_name": "CMMC Level 2 / NIST SP 800-171",
        "revision": "NIST SP 800-171 Rev. 2 (Feb 2020). CMMC L2 mirrors all 110 NIST 800-171 controls.",
        "source_url": "https://csrc.nist.gov/pubs/sp/800/171/r2/upd1/final",
        "control_count": 110,
        "note": "Required for handling Controlled Unclassified Information (CUI). 110 controls in 14 families.",
    },
    "nist53": {
        "full_name": "NIST SP 800-53 (Mod baseline)",
        "revision": "NIST SP 800-53 Rev. 5, September 2020",
        "source_url": "https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final",
        "control_count": 287,
        "note": "Federal civilian baseline. Mod baseline = ~287 controls. ProxmoxVEx maps the technical-control subset relevant to a Linux hypervisor.",
    },
    "stig": {
        "full_name": "DISA STIG (RHEL 9 / Ubuntu 22.04)",
        "revision": "RHEL 9 STIG (current) + Ubuntu 22.04 STIG (current). Refs may need refresh per release.",
        "source_url": "https://public.cyber.mil/stigs/",
        "control_count": None,
        "note": "Defense Information Systems Agency Security Technical Implementation Guide. Refs assume RHEL 9 baseline; Ubuntu 22.04 refs are equivalent.",
    },
    "iso": {
        "full_name": "ISO/IEC 27001:2022 Annex A",
        "revision": "ISO/IEC 27001:2022, October 2022 — supersedes 2013 / 2017 amendments",
        "source_url": "https://www.iso.org/standard/27001",
        "control_count": 93,
        "note": "93 controls in 4 themes: Organizational, People, Physical, Technological. ProxmoxVEx covers the Technological controls applicable to Linux node hardening.",
    },
    "bsi": {
        "full_name": "BSI IT-Grundschutz Kompendium",
        "revision": "BSI IT-Grundschutz Kompendium Edition 2024",
        "source_url": "https://www.bsi.bund.de/dok/itgs",
        "control_count": None,
        "note": "Bundesamt für Sicherheit in der Informationstechnik. Modules SYS / OPS / NET / DER / CON / APP. ProxmoxVEx focuses on SYS.1.3 (general Linux server) and adjacent modules.",
    },
    "vs-nfd": {
        "full_name": "VS-NfD (Verschlusssache - Nur für den Dienstgebrauch)",
        "revision": "VS-Anweisung (VSA), based on BSI IT-Grundschutz; ProxmoxVEx adds 6 informational checks",
        "source_url": "https://www.bsi.bund.de/EN/Themen/ZertifizierungundAnerkennung/Produktzertifizierung/Zertifizierung-und-Anerkennung-VS/zertifizierung-und-anerkennung-vs_node.html",
        "control_count": None,
        "note": "German national restricted-use classification. ProxmoxVEx provides a Proxmox-safe BSI Grundschutz subset + 6 VS-NfD-specific informational checks.",
    },
    "dr": {
        "full_name": "Diffusion Restreinte (II 901)",
        "revision": "Instruction interministérielle n° 901; technical Linux baseline = ANSSI-BP-028 v2.0 (2022-10-03)",
        "source_url": "https://cyber.gouv.fr/publications/recommandations-de-securite-relatives-un-systeme-gnulinux",
        "control_count": None,
        "note": "French national restricted classification. II 901 sets the protection regime for DR-level information systems; ProxmoxVEx maps the technical Linux-hardening measures to ANSSI-BP-028 (the recognised French baseline). Audit-prep evidence — not a homologation.",
    },
    "rgs": {
        "full_name": "RGS (Référentiel Général de Sécurité)",
        "revision": "RGS v2.0; Linux-hardening implementation reference = ANSSI-BP-028 v2.0 (2022-10-03)",
        "source_url": "https://cyber.gouv.fr/le-referentiel-general-de-securite-rgs-version-20",
        "control_count": None,
        "note": "French general security framework for administrations. RGS points to ANSSI technical guides for implementation; ProxmoxVEx maps the Linux node-hardening subset to ANSSI-BP-028. Technical-config evidence only.",
    },
    "pci": {
        "full_name": "PCI DSS (Payment Card Industry Data Security Standard)",
        "revision": "PCI DSS v4.0.1 (June 2024). Mandatory future-dated requirements effective since 31 March 2025.",
        "source_url": "https://www.pcisecuritystandards.org/document_library/",
        "control_count": 360,
        "note": "Global baseline for protecting payment account data — 12 principal requirements. ProxmoxVEx maps the technical host-hardening subset (Reqs 2, 3, 6, 7, 8, 10, 11) relevant to infrastructure components. Network segmentation, MFA deployment, policy and testing requirements need separate evidence.",
    },
    "hipaa": {
        "full_name": "HIPAA Security Rule — Technical Safeguards",
        "revision": "45 CFR §164.312 (technical safeguards only)",
        "source_url": "https://www.ecfr.gov/current/title-45/subtitle-A/subchapter-C/part-164",
        "control_count": 9,
        "note": "Only §164.312 technical safeguards are mapped — the largest share of the Security Rule (administrative §164.308, physical §164.310, organizational §164.314/316) is process/policy and cannot be measured by SSH hardening checks. Treat as a technical-coverage indicator, never a HIPAA assessment.",
    },
    "soc2": {
        "full_name": "SOC 2 — AICPA Trust Services Criteria",
        "revision": "AICPA Trust Services Criteria (2017, revised March 2022) — Common Criteria CC6/CC7 subset",
        "source_url": "https://us.aicpa.org/interestareas/frc/assuranceadvisoryservices/trustdataintegritytaskforce",
        "control_count": 33,
        "note": "Only the Common Criteria points-of-focus measurable via host configuration are mapped (CC6 logical access, CC7 system operations). Availability, confidentiality processing-integrity and organizational criteria require separate evidence. Audit-prep indicator, not a SOC 2 attestation.",
    },
    "cisv8": {
        "full_name": "CIS Critical Security Controls",
        "revision": "CIS Critical Security Controls v8.1 (June 2024)",
        "source_url": "https://www.cisecurity.org/controls/v8",
        "control_count": 153,
        "note": "18 controls / 153 safeguards. ProxmoxVEx maps the host-hardening-mappable safeguards (sections 3, 4, 5, 8, 10, 13) — the majority of CIS v8 is inventory, process and governance work outside SSH check scope.",
    },
    "ens": {
        "full_name": "ENS — Esquema Nacional de Seguridad",
        "revision": "Real Decreto 311/2022, Anexo II (Spain)",
        "source_url": "https://ens.ccn.cni.es/",
        "control_count": None,
        "note": "Spanish national security framework mandatory for public-sector and supplier systems. ProxmoxVEx maps the technical measures (op.acc / op.exp / op.mon / mp.com / mp.si) equivalent to Linux node hardening — most of Anexo II is organizational. Coverage indicator for audit prep, not an ENS certification.",
    },
    "ce": {
        "full_name": "Cyber Essentials (NCSC, UK)",
        "revision": "Cyber Essentials Requirements for IT Infrastructure (Montpellier, April 2023)",
        "source_url": "https://www.ncsc.gov.uk/cyberessentials/",
        "control_count": None,
        "note": "UK baseline certification — five technical control themes (firewalls, secure configuration, user access control, malware protection, security update management). The scheme defines themes, not numbered controls, so the mapping is at theme level. Coverage indicator only.",
    },
}


# ──────────────────────────────────────────────────────────────────────────
# Compliance posture rating thresholds. Used by the PDF report to label the
# overall coverage with a categorical posture statement.
#
# Important: high-severity controls are weighted more — a cluster that passes
# 100% of LOW but 0% of HIGH is not "substantially compliant". The function
# `evaluate_posture(stats)` applies this logic.
# ──────────────────────────────────────────────────────────────────────────
POSTURE_LEVELS = [
    # ordered from best to worst; first matching threshold wins
    {
        "id": "substantial",
        "label": "Substantially Compliant",
        "min_overall_pct": 95,
        "min_high_pct": 100,
        "description": "Coverage is materially complete with all high-severity controls satisfied. Suitable to enter formal audit with focus on documentation and process evidence.",
    },
    {
        "id": "largely",
        "label": "Largely Compliant",
        "min_overall_pct": 85,
        "min_high_pct": 90,
        "description": "Most controls are satisfied; remaining gaps include at most a small number of medium-severity items. Closeable in a single remediation cycle.",
    },
    {
        "id": "partial",
        "label": "Partially Compliant",
        "min_overall_pct": 65,
        "min_high_pct": 70,
        "description": "Significant control gaps remain, including high-severity items. Coverage is below the level expected to enter a formal certification audit.",
    },
    {
        "id": "marginal",
        "label": "Marginally Compliant",
        "min_overall_pct": 40,
        "min_high_pct": 0,
        "description": "Substantial remediation required across multiple control families before any audit deliverable can be produced.",
    },
    {
        "id": "noncompliant",
        "label": "Non-Compliant",
        "min_overall_pct": 0,
        "min_high_pct": 0,
        "description": "Comprehensive remediation required. Recommend a structured hardening project before re-running the assessment.",
    },
]


# ──────────────────────────────────────────────────────────────────────────
# Glossary — for auditors / managers who don't speak Linux fluently.
# Plain-language definitions of the technical terms used in the report.
# ──────────────────────────────────────────────────────────────────────────
GLOSSARY = {
    "AIDE": "Advanced Intrusion Detection Environment — a host-based file-integrity monitor for Linux. Maintains a hash database of selected files; alerts on unauthorized modification.",
    "AppArmor": "Linux Mandatory Access Control framework; restricts what files and capabilities a given program can access, even when running as root.",
    "auditd": "The Linux audit daemon — collects security-relevant kernel and userspace events (logon, syscalls, file access, privilege changes) into a tamper-resistant log.",
    "journald": "systemd-journald — the system log collector on modern Linux. Replaces the older syslog file format with a structured, indexable journal.",
    "LUKS": "Linux Unified Key Setup — the standard full-disk-encryption format on Linux.",
    "PAM": "Pluggable Authentication Modules — the authentication framework for Linux. Modules implement password complexity, account lockout, MFA, etc.",
    "pwquality": "libpwquality — Linux password complexity policy library used by PAM (length, character classes, dictionary checks).",
    "sysctl": "Linux kernel runtime parameter interface (e.g. network stack tuning, memory protections). Settings live in /etc/sysctl.d/.",
    "ASLR": "Address Space Layout Randomization — a memory protection that randomizes the location of executable code and data, making exploitation harder.",
    "NX": "No-eXecute — CPU-enforced memory protection bit that prevents code execution in data pages.",
    "TPM": "Trusted Platform Module — hardware crypto chip used for measured boot, key sealing and secure storage of credentials.",
    "yescrypt": "Modern password-hashing function (replaces SHA-512 crypt); designed to be hard to crack on GPUs/ASICs.",
    "PVE": "Proxmox Virtual Environment — the open-source hypervisor management platform ProxmoxVEx orchestrates.",
    "ProxmoxVEx": "The multi-cluster Proxmox VE management platform that produced this report.",
    "SUID": "Set User ID — a special permission bit that runs an executable with the privileges of its owner instead of the calling user.",
    "fail2ban": "Log-based brute-force protection — bans IPs that exceed a failed-login threshold via firewall rules.",
    "KEX": "Key Exchange algorithm — the SSH protocol step where client and server agree on a shared session key.",
    "CIS": "Center for Internet Security — publishes hardening benchmarks for Linux, Windows, container platforms, etc.",
    "CMMC": "Cybersecurity Maturity Model Certification — U.S. Department of Defense framework for protecting Federal Contract Information and Controlled Unclassified Information.",
    "NIST 800-171": "NIST publication: Protecting Controlled Unclassified Information in Nonfederal Systems and Organizations. The technical baseline behind CMMC L2.",
    "NIST 800-53": "NIST publication: Security and Privacy Controls for Information Systems and Organizations. Federal civilian baseline.",
    "STIG": "DISA Security Technical Implementation Guide — DoD-mandated configuration standard.",
    "ISO 27001": "International standard for Information Security Management Systems (ISMS). Annex A lists the controls organisations are expected to evaluate.",
    "NIS2": "Network and Information Security Directive 2 — EU regulation for operators of essential services (effective Oct 2024).",
    "KRITIS": "German implementation of NIS2 — Critical Infrastructure regulation by the BSI.",
    "BSI": "Bundesamt für Sicherheit in der Informationstechnik — the German Federal Office for Information Security.",
    "IT-Grundschutz": "BSI methodology and control catalogue for information security in German government / industry.",
    "VS-NfD": 'Verschlusssache - Nur für den Dienstgebrauch — German national classification level "For Official Use Only".',
    "ANSSI": "Agence nationale de la sécurité des systèmes d'information — the French national cybersecurity authority (the French counterpart to the German BSI).",
    "ANSSI-BP-028": "ANSSI's \"Recommandations de configuration d'un système GNU/Linux\" (v2.0, 2022) — the recognised French Linux system-hardening baseline (numbered recommendations R1–R80).",
    "Diffusion Restreinte": 'French national "Restricted" protection level for sensitive information; the information-system protection regime is set by Instruction interministérielle n° 901 (II 901). Rough analogue of German VS-NfD.',
    "II 901": "Instruction interministérielle n° 901 — French regulation defining the protection of information systems handling Diffusion Restreinte information.",
    "RGS": "Référentiel Général de Sécurité — the French general security framework mandatory for administrations' information systems (crypto, authentication, audit, timestamping).",
    "OVMF": "Open Virtual Machine Firmware — the UEFI implementation used in QEMU / KVM virtual machines.",
    "Secure Boot": "UEFI feature that allows only firmware-signed boot loaders to run, preventing certain rootkit/bootkit attacks.",
    "PCI DSS": "Payment Card Industry Data Security Standard — global baseline (currently v4.0.1) for protecting payment account data, maintained by the PCI Security Standards Council.",
    "HIPAA": "Health Insurance Portability and Accountability Act — US regulation; its Security Rule (45 CFR §164.312) defines technical safeguards for electronic protected health information (ePHI).",
    "SOC 2": "AICPA attestation framework — auditors report on a service organisation's controls against the Trust Services Criteria (security, availability, confidentiality, processing integrity, privacy).",
    "CIS Controls": "CIS Critical Security Controls (v8.1) — 18 prioritized controls / 153 safeguards published by the Center for Internet Security.",
    "ENS": "Esquema Nacional de Seguridad — Spanish national security framework (Real Decreto 311/2022) mandatory for public-sector systems and their suppliers.",
    "Cyber Essentials": "UK government-backed baseline certification (NCSC) covering five technical control themes: firewalls, secure configuration, user access control, malware protection, security update management.",
    "GDPR": "General Data Protection Regulation (EU 2016/679) — Art. 32 requires technical and organizational measures appropriate to risk, including pseudonymisation, encryption and resilience of systems.",
    "DORA": "Digital Operational Resilience Act (EU 2022/2554) — EU regulation on ICT risk for the financial sector (applies from 17 Jan 2025).",
}


# ──────────────────────────────────────────────────────────────────────────
# Standardised audit methodology language. Reused verbatim by the PDF.
# ──────────────────────────────────────────────────────────────────────────
METHODOLOGY = {
    "overview": (
        "ProxmoxVEx executes deterministic checks over SSH against each in-scope "
        "cluster node and compares the observed configuration against the expected "
        "value defined by the selected hardening profile. Each check has a "
        'documented "check command" and an expected output; deviations are recorded '
        "as findings. No manual sampling is performed: 100% of in-scope nodes are "
        "evaluated on every report run."
    ),
    "procedures": [
        (
            "Inquiry",
            'ProxmoxVEx reads the configured hardening profile (e.g. "CMMC L2") and resolves it to a list of internal control checks via FRAMEWORK_MAPPING.',
        ),
        (
            "Inspection",
            "ProxmoxVEx connects to each node via SSH and inspects configuration files, runtime kernel parameters, service status and file permissions.",
        ),
        (
            "Re-performance",
            "ProxmoxVEx executes the documented check command on each node and verifies the actual output matches the expected value.",
        ),
        (
            "Evidence capture",
            "When verbose mode is enabled, ProxmoxVEx records the exact check command and the actual node output for each control, included in Appendix C.",
        ),
    ],
    "sampling": '100% of in-scope cluster nodes evaluated. No statistical sampling applied. SSH unreachable nodes are reported as "not evaluated" rather than passed or failed.',
    "criteria": "Mappings between internal checks and framework control IDs are maintained in ProxmoxVEx/core/compliance_mapping.py. Mappings should be re-verified against the current revision of the applicable framework before the report is used as input to a formal audit.",
    "limitations": (
        "ProxmoxVEx assesses technical configuration only. The following are out of scope and must be evaluated separately by a qualified auditor: "
        "(1) administrative policies and procedures, "
        "(2) personnel security and awareness training, "
        "(3) physical security of the data centre, "
        "(4) incident response plans and tabletop exercises, "
        "(5) supply chain risk management."
    ),
}


# ──────────────────────────────────────────────────────────────────────────
# Helper functions
# ──────────────────────────────────────────────────────────────────────────


def get_mapping(framework_id):
    """Return the (mapping, family_labels) tuple for a framework id, or empty if unknown."""
    return FRAMEWORK_MAPPING.get(framework_id, {}), FAMILY_LABELS


def remediation_for(internal_id):
    """Return remediation hint dict, or a stub if not present."""
    return REMEDIATION.get(
        internal_id,
        {
            "summary": f"No prescribed remediation for {internal_id}.",
            "how_to_fix": "Consult ProxmoxVEx Hardening tool for the apply command, or the relevant CIS / STIG benchmark.",
        },
    )


def severity_for(internal_id):
    """Return severity level for an internal control id (high/medium/low/informational)."""
    return SEVERITY.get(internal_id, "medium")  # conservative default


def framework_meta(framework_id):
    """Return metadata dict for a framework id, or a stub if unknown."""
    return FRAMEWORK_META.get(
        framework_id,
        {
            "full_name": framework_id,
            "revision": "Unknown revision",
            "source_url": "",
            "control_count": None,
            "note": "",
        },
    )


def evaluate_posture(overall_pct, high_pct):
    """Pick the posture level for a given (overall_pct, high_severity_pct) pair.

    Returns the posture dict from POSTURE_LEVELS, falling back to noncompliant.
    """
    if overall_pct is None:
        overall_pct = 0
    if high_pct is None:
        high_pct = 100  # no high-severity controls in scope => gate vacuously satisfied (matches dashboard.js)
    for lvl in POSTURE_LEVELS:
        if overall_pct >= lvl["min_overall_pct"] and high_pct >= lvl["min_high_pct"]:
            return lvl
    return POSTURE_LEVELS[-1]
