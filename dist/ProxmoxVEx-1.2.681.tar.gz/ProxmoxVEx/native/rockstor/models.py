# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/native/rockstor/models.py
# Project:     ProxmoxVEx
# Version:     1.2.669
# Build:       2026.10.21
# Description: Rockstor plugin data models and persistence helpers.
# Usage:       import ProxmoxVEx.native.rockstor.models
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-10-21
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Rockstor plugin data models and persistence helpers.

All Rockstor API size fields (pool.size/free/usage, share.size/rusage/eusage)
are reported in KiB — the plugin stores them verbatim in ``*_kib`` columns so
the UI can format against a consistent unit.
"""

import json
import logging
import re
import uuid as uuid_mod
from dataclasses import asdict, dataclass
from datetime import UTC, datetime
from typing import Any, Dict, List, Optional

from ProxmoxVEx.core.db import get_db

log = logging.getLogger("plugin.rockstor.models")

CONNECTIVITY_STATES = {"unknown", "reachable", "degraded", "unreachable"}
AUTH_TYPES = {"password", "access_key"}
RAID_LEVELS = {"single", "raid0", "raid1", "raid5", "raid6", "raid10", "dup"}
COMPRESSION_TYPES = {"no", "zlib", "lzo", "zstd"}
POOL_ACTIONS = {"scrub", "balance", "delete"}
_URL_RE = re.compile(r"^https?://[^\s]+$|^mock://[^\s]+$")
_NAME_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.\-]{0,127}$")


@dataclass
class Connection:
    id: Optional[int] = None
    display_name: str = ""
    endpoint_url: str = ""
    tls_verify: bool = True
    credential_ref: str = ""
    connectivity_status: str = "unknown"
    auth_type: str = "password"
    version: str = ""
    hostname: str = ""
    last_successful_contact: Optional[str] = None
    created_at: Optional[str] = None
    updated_at: Optional[str] = None

    def to_dict(self, include_credentials: bool = False) -> Dict[str, Any]:
        data = asdict(self)
        if not include_credentials:
            data.pop("credential_ref", None)
        return data


def _now_iso() -> str:
    return datetime.now(UTC).isoformat()


def ensure_tables(conn) -> None:
    """Create Rockstor plugin tables if they do not exist."""
    cursor = conn.cursor()
    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS rockstor_connections (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            display_name TEXT NOT NULL,
            endpoint_url TEXT NOT NULL,
            tls_verify INTEGER DEFAULT 1,
            credential_ref TEXT NOT NULL,
            connectivity_status TEXT DEFAULT 'unknown',
            auth_type TEXT NOT NULL DEFAULT 'password',
            version TEXT,
            hostname TEXT,
            last_successful_contact TEXT,
            created_at TEXT,
            updated_at TEXT
        )
        """
    )
    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS rockstor_pools (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            connection_id INTEGER NOT NULL,
            remote_id INTEGER NOT NULL,
            name TEXT,
            uuid TEXT,
            raid TEXT,
            size_kib BIGINT DEFAULT 0,
            free_kib BIGINT DEFAULT 0,
            used_kib BIGINT DEFAULT 0,
            compression TEXT,
            role TEXT,
            is_mounted INTEGER DEFAULT 0,
            last_seen TEXT,
            UNIQUE(connection_id, remote_id)
        )
        """
    )
    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS rockstor_shares (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            connection_id INTEGER NOT NULL,
            remote_id INTEGER NOT NULL,
            name TEXT,
            pool_name TEXT,
            pool_remote_id INTEGER,
            size_kib BIGINT DEFAULT 0,
            rusage_kib BIGINT DEFAULT 0,
            eusage_kib BIGINT DEFAULT 0,
            compression_algo TEXT,
            owner TEXT,
            grp TEXT,
            perms TEXT,
            replica INTEGER DEFAULT 0,
            is_mounted INTEGER DEFAULT 0,
            last_seen TEXT,
            UNIQUE(connection_id, remote_id)
        )
        """
    )
    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS rockstor_snapshots (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            connection_id INTEGER NOT NULL,
            share_remote_id INTEGER NOT NULL,
            share_name TEXT,
            name TEXT NOT NULL,
            writable INTEGER DEFAULT 0,
            uvisible INTEGER DEFAULT 0,
            snap_type TEXT DEFAULT 'admin',
            size_kib BIGINT DEFAULT 0,
            toc TEXT,
            last_seen TEXT,
            UNIQUE(connection_id, share_remote_id, name)
        )
        """
    )
    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS rockstor_operations (
            id TEXT PRIMARY KEY,
            connection_id INTEGER,
            action TEXT NOT NULL,
            target_type TEXT,
            target TEXT,
            params TEXT DEFAULT '{}',
            status TEXT DEFAULT 'pending',
            result TEXT,
            error TEXT,
            actor TEXT,
            created_at TEXT,
            finished_at TEXT
        )
        """
    )
    _widen_kib_columns(conn)
    _add_missing_columns(conn)
    conn.commit()
    log.info("[rockstor] Ensured plugin tables exist")


# *_kib columns must survive real NAS capacities: SQLite INTEGER is 64-bit
# already, but Postgres INTEGER is int4 and overflows above ~2 TiB in KiB
# ("integer out of range" on upsert). Widen existing int4 installs.
_KIB_COLUMNS = {
    "rockstor_pools": ("size_kib", "free_kib", "used_kib"),
    "rockstor_shares": ("size_kib", "rusage_kib", "eusage_kib"),
    "rockstor_snapshots": ("size_kib",),
}


def _widen_kib_columns(conn) -> None:
    try:
        from ProxmoxVEx.core.db_pg import PGConnection
    except Exception:
        return
    if not isinstance(conn, PGConnection):
        return
    for table, cols in _KIB_COLUMNS.items():
        for col in cols:
            conn.execute(
                f"ALTER TABLE {table} ALTER COLUMN {col} TYPE BIGINT"  # nosec: B608 - identifiers from internal constant map
            )


def _add_missing_columns(conn) -> None:
    """Add columns introduced after the table first shipped (auth_type).

    Dialect-agnostic: probe the column; if it is missing, ALTER TABLE —
    ADD COLUMN works identically on Postgres and the SQLite test fake."""
    try:
        conn.execute("SELECT auth_type FROM rockstor_connections LIMIT 0")
    except Exception:
        conn.execute(
            "ALTER TABLE rockstor_connections "
            "ADD COLUMN auth_type TEXT NOT NULL DEFAULT 'password'"
        )


def _encrypt_credential(credential: Dict[str, Any]) -> str:
    """Store a credential blob as an encrypted JSON reference."""
    if not credential:
        return ""
    payload = json.dumps(credential)
    return get_db()._encrypt(payload)


def _decrypt_credential(ref: str) -> Dict[str, Any]:
    """Retrieve a credential blob from an encrypted reference."""
    if not ref:
        return {}
    try:
        plain = get_db()._decrypt(ref)
        return json.loads(plain)
    except Exception as e:
        log.error("[rockstor] Failed to decrypt credential reference: %s", e)
        return {}


def validate_connection_input(data: Dict[str, Any]) -> Dict[str, str]:
    errors: Dict[str, str] = {}
    name = (data.get("display_name") or "").strip()
    if not name or len(name) > 128:
        errors["display_name"] = "Required and must be <= 128 characters"
    url = (data.get("endpoint_url") or "").strip()
    if not url or not _URL_RE.match(url):
        errors["endpoint_url"] = "Required and must be a valid http(s) URL"
    if (data.get("auth_type") or "password") not in AUTH_TYPES:
        errors["auth_type"] = f"Must be one of {sorted(AUTH_TYPES)}"
    cred = data.get("credential") or {}
    if not (cred.get("username") and cred.get("password")):
        errors["credential.username"] = "Username and password required"
    # Rockstor ships a self-signed TLS cert, so verification can be disabled —
    # but only as an explicit opt-in, never silently.
    if not data.get("tls_verify", True) and not data.get("tls_insecure_ack"):
        errors["tls_verify"] = "Disabling TLS verification requires tls_insecure_ack=true"
    return errors


def create_connection(data: Dict[str, Any]) -> Connection:
    db = get_db()
    now = _now_iso()
    ref = _encrypt_credential(data.get("credential") or {})
    # conn.execute() keeps the cursor so lastrowid is captured on both
    # SQLite (native lastrowid) and Postgres (adapter tracks lastval()).
    cur = db.conn.execute(
        """
        INSERT INTO rockstor_connections
        (display_name, endpoint_url, tls_verify, credential_ref,
         connectivity_status, auth_type, version, hostname,
         last_successful_contact, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (
            data["display_name"].strip(),
            data["endpoint_url"].strip().rstrip("/"),
            1 if data.get("tls_verify", True) else 0,
            ref,
            data.get("connectivity_status", "unknown"),
            data.get("auth_type") or "password",
            data.get("version", ""),
            data.get("hostname", ""),
            data.get("last_successful_contact"),
            now,
            now,
        ),
    )
    db.conn.commit()
    conn = get_connection(int(cur.lastrowid))
    assert conn is not None  # row was just inserted via lastrowid
    return conn


def _row_to_connection(row: Optional[Any]) -> Optional[Connection]:
    if not row:
        return None
    data = dict(row)
    data["tls_verify"] = bool(data.get("tls_verify", 1))
    return Connection(**{k: v for k, v in data.items() if k in Connection.__dataclass_fields__})


def get_connection(conn_id: int) -> Optional[Connection]:
    row = get_db().query_one("SELECT * FROM rockstor_connections WHERE id = ?", (conn_id,))
    return _row_to_connection(row)


def list_connections() -> List[Connection]:
    rows = get_db().query("SELECT * FROM rockstor_connections")
    return [c for c in (_row_to_connection(r) for r in rows) if c is not None]


def delete_connection(conn_id: int) -> bool:
    db = get_db()
    for table in ("rockstor_pools", "rockstor_shares", "rockstor_snapshots"):
        db.execute(f"DELETE FROM {table} WHERE connection_id = ?", (conn_id,))
    db.execute("DELETE FROM rockstor_operations WHERE connection_id = ?", (conn_id,))
    db.execute("DELETE FROM rockstor_connections WHERE id = ?", (conn_id,))
    return True


def update_connection_status(
    conn_id: int, status: str, last_contact: Optional[str] = None,
    version: Optional[str] = None, hostname: Optional[str] = None,
) -> None:
    db = get_db()
    db.execute(
        "UPDATE rockstor_connections SET connectivity_status = ?, "
        "last_successful_contact = ?, version = COALESCE(?, version), "
        "hostname = COALESCE(?, hostname), updated_at = ? WHERE id = ?",
        (status, last_contact, version, hostname, _now_iso(), conn_id),
    )


def get_connection_credential(conn_id: int) -> Dict[str, Any]:
    conn = get_connection(conn_id)
    if not conn:
        return {}
    return _decrypt_credential(conn.credential_ref)


def find_connection_by_id_or_uuid(value: Any) -> Optional[Connection]:
    try:
        return get_connection(int(value))
    except (TypeError, ValueError):
        return None


# ---- Inventory upsert / list helpers ----


def _upsert(table: str, conflict: str, lead_cols: List[Any], fields: Dict[str, Any]) -> None:
    db = get_db()
    cols = ", ".join(fields.keys())
    placeholders = ", ".join(["?"] * (len(lead_cols) + len(fields)))
    updates = ", ".join(f"{k} = excluded.{k}" for k in fields)
    lead_names = ", ".join(
        {"rockstor_pools": ["connection_id", "remote_id"],
         "rockstor_shares": ["connection_id", "remote_id"],
         "rockstor_snapshots": ["connection_id", "share_remote_id"]}[table]
    )
    db.execute(
        f"INSERT INTO {table} ({lead_names}, {cols}, last_seen) "
        f"VALUES ({placeholders}, ?) "
        f"ON CONFLICT({conflict}) DO UPDATE SET {updates}, last_seen = excluded.last_seen",
        (*lead_cols, *fields.values(), _now_iso()),
    )


def upsert_pool(connection_id: int, fields: Dict[str, Any]) -> None:
    _upsert("rockstor_pools", "connection_id, remote_id", [connection_id, fields.pop("remote_id")], fields)


def upsert_share(connection_id: int, fields: Dict[str, Any]) -> None:
    _upsert("rockstor_shares", "connection_id, remote_id", [connection_id, fields.pop("remote_id")], fields)


def upsert_snapshot(connection_id: int, share_remote_id: int, fields: Dict[str, Any]) -> None:
    _upsert("rockstor_snapshots", "connection_id, share_remote_id, name", [connection_id, share_remote_id], fields)


def list_rows(table: str, connection_id: Optional[int] = None, **filters) -> List[Dict[str, Any]]:
    db = get_db()
    sql = f"SELECT * FROM {table}"
    params: List[Any] = []
    clauses = []
    if connection_id is not None:
        clauses.append("connection_id = ?")
        params.append(connection_id)
    for key, value in filters.items():
        if value is not None:
            clauses.append(f"{key} = ?")
            params.append(value)
    if clauses:
        sql += " WHERE " + " AND ".join(clauses)
    sql += " ORDER BY id"
    return [dict(r) for r in db.query(sql, tuple(params))]


def get_pool(connection_id: int, remote_id: int) -> Optional[Dict[str, Any]]:
    rows = list_rows("rockstor_pools", connection_id, remote_id=remote_id)
    return rows[0] if rows else None


def get_share(connection_id: int, remote_id: int) -> Optional[Dict[str, Any]]:
    rows = list_rows("rockstor_shares", connection_id, remote_id=remote_id)
    return rows[0] if rows else None


def remove_stale(table: str, connection_id: int, seen_remote_ids: List[int]) -> int:
    """Delete cached rows whose remote ids vanished from the appliance."""
    db = get_db()
    if seen_remote_ids:
        marks = ",".join("?" for _ in seen_remote_ids)
        cur = db.execute(
            f"DELETE FROM {table} WHERE connection_id = ? AND remote_id NOT IN ({marks})",
            (connection_id, *seen_remote_ids),
        )
    else:
        cur = db.execute(f"DELETE FROM {table} WHERE connection_id = ?", (connection_id,))
    return cur.rowcount if cur is not None else 0


def remove_stale_snapshots(connection_id: int, share_remote_id: int, seen_names: List[str]) -> int:
    db = get_db()
    if seen_names:
        marks = ",".join("?" for _ in seen_names)
        cur = db.execute(
            "DELETE FROM rockstor_snapshots WHERE connection_id = ? AND share_remote_id = ? "
            f"AND name NOT IN ({marks})",
            (connection_id, share_remote_id, *seen_names),
        )
    else:
        cur = db.execute(
            "DELETE FROM rockstor_snapshots WHERE connection_id = ? AND share_remote_id = ?",
            (connection_id, share_remote_id),
        )
    return cur.rowcount if cur is not None else 0


# ---- Operations (job tracker) ----

TERMINAL_OP_STATUSES = {"completed", "failed", "unreachable", "cancelled"}


def _record_task(op_id: str, action: str, status: str, actor: str = "", detail: str = "") -> None:
    """Mirror a Rockstor operation lifecycle event into the shared task tray."""
    try:
        import time

        from ProxmoxVEx.core.plugin_tasks import record_plugin_task

        record_plugin_task(
            "rockstor",
            op_id,
            "rockstor",
            action,
            detail=detail or f"Rockstor {action}",
            status=status,
            user=actor,
            endtime=time.time() if status in TERMINAL_OP_STATUSES else None,
        )
    except Exception as e:
        log.debug("[rockstor] task-tray mirror failed: %s", e)


def create_operation(
    connection_id: Optional[int], action: str, target_type: str, target: str,
    params: Optional[Dict[str, Any]], actor: str,
) -> str:
    db = get_db()
    op_id = uuid_mod.uuid4().hex
    db.execute(
        "INSERT INTO rockstor_operations (id, connection_id, action, target_type, target, "
        "params, status, actor, created_at) VALUES (?, ?, ?, ?, ?, ?, 'pending', ?, ?)",
        (op_id, connection_id, action, target_type, target, json.dumps(params or {}), actor, _now_iso()),
    )
    _record_task(op_id, action, "pending", actor=actor, detail=f"{target_type} {target}".strip())
    return op_id


def update_operation(op_id: str, **fields) -> None:
    db = get_db()
    if not fields:
        return
    cols = ", ".join(f"{k} = ?" for k in fields)
    db.execute(f"UPDATE rockstor_operations SET {cols} WHERE id = ?", (*fields.values(), op_id))


def finish_operation(op_id: str, status: str, result: Any = None, error: str = "") -> None:
    db = get_db()
    db.execute(
        "UPDATE rockstor_operations SET status = ?, result = ?, error = ?, finished_at = ? WHERE id = ?",
        (status, json.dumps(result) if result is not None else None, error, _now_iso(), op_id),
    )
    row = db.query_one(
        "SELECT action, target_type, target, actor FROM rockstor_operations WHERE id = ?", (op_id,)
    )
    if row:
        _record_task(
            op_id, row["action"], status, actor=(row["actor"] or ""),
            detail=error or f"{row['target_type'] or ''} {row['target'] or ''}".strip(),
        )


def get_operation(op_id: str) -> Optional[Dict[str, Any]]:
    row = get_db().query_one("SELECT * FROM rockstor_operations WHERE id = ?", (op_id,))
    return dict(row) if row else None


def list_operations(connection_id: Optional[int] = None, limit: int = 100) -> List[Dict[str, Any]]:
    db = get_db()
    if connection_id is not None:
        rows = db.query(
            "SELECT * FROM rockstor_operations WHERE connection_id = ? ORDER BY created_at DESC LIMIT ?",
            (connection_id, limit),
        )
    else:
        rows = db.query("SELECT * FROM rockstor_operations ORDER BY created_at DESC LIMIT ?", (limit,))
    return [dict(r) for r in rows]


def retry_operation(op_id: str, actor: str = "") -> Optional[str]:
    """Clone a terminal operation's params into a new pending row."""
    op = get_operation(op_id)
    if not op:
        return None
    try:
        params = json.loads(op.get("params") or "{}")
    except (json.JSONDecodeError, TypeError):
        params = {}
    return create_operation(
        op.get("connection_id"), op.get("action") or "", op.get("target_type") or "",
        op.get("target") or "", params, actor or op.get("actor") or "unknown",
    )


def operation_params(op: Dict[str, Any]) -> Dict[str, Any]:
    try:
        return json.loads(op.get("params") or "{}")
    except (json.JSONDecodeError, TypeError):
        return {}


def valid_name(value: str) -> bool:
    return bool(_NAME_RE.match(value or ""))
