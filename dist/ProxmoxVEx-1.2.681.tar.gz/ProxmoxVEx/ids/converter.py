# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/ids/converter.py
# Project:     ProxmoxVEx
# Version:     1.2.662
# Build:       2026.10.21
# Description: Convert Suricata/Snort .rules files into ProxmoxVEx
#              IDS/IPS JSON rules.
# Usage:       import ProxmoxVEx.ids.converter
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-10-21
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Convert Suricata/Snort .rules files into ProxmoxVEx IDS/IPS JSON rules.

The converter extracts simple, port-based signatures. Rules that rely on
content/flow/PCRE options are skipped because the current engine matches on
packet/flow fields (source, destination, dport, sport, payload_size).
"""

import io
import logging
import re
import tarfile
from typing import Any, Dict, List, Tuple

logger = logging.getLogger(__name__)

# Port variables commonly found in ET/Snort rules.
_PORT_VARS = {
    "$HTTP_PORTS": [80, 81, 82, 83, 88, 443, 5555, 8000, 8080, 8081, 8443, 8888],
    "$HTTPS_PORTS": [443, 8443],
    "$SSH_PORTS": [22],
    "$TELNET_PORTS": [23],
    "$FTP_PORTS": [21, 20],
    "$DNS_PORTS": [53],
    "$SMTP_PORTS": [25, 465, 587],
    "$SHTTP_PORTS": [443],
    "$ORACLE_PORTS": [1521],
    "$MSSQL_PORTS": [1433],
    "$MYSQL_PORTS": [3306],
    "$POSTGRES_PORTS": [5432],
    "$SNMP_PORTS": [161, 162],
    "$LDAP_PORTS": [389, 636],
    "$SIP_PORTS": [5060, 5061],
    "$RDP_PORTS": [3389],
    "$VNC_PORTS": [5900, 5901, 5902],
    "$REDIS_PORTS": [6379],
    "$MONGO_PORTS": [27017, 27018, 27019],
    "$ELASTIC_PORTS": [9200, 9300],
    "$SMB_PORTS": [139, 445],
    "$NFS_PORTS": [2049],
    "$ISCSI_PORTS": [3260],
    "$KUBERNETES_PORTS": [6443],
    "$DOCKER_PORTS": [2375, 2376],
    "$ETCD_PORTS": [2379, 2380],
    "$KAFKA_PORTS": [9092],
    "$RABBIT_PORTS": [5672],
    "$PROMETHEUS_PORTS": [9090],
    "$GRAFANA_PORTS": [3000],
    "$JENKINS_PORTS": [8080, 8443],
    "$ZOOKEEPER_PORTS": [2181],
    "$MODBUS_PORTS": [502],
    "$BACNET_PORTS": [47808],
    "$IPMI_PORTS": [623],
    "$WINRM_PORTS": [5985, 5986],
    "$NTP_PORTS": [123],
}

# Severity mapping by classtype; lower index = more severe.
_SEVERITY_BY_CLASS = {
    "trojan-activity": "critical",
    "successful-admin": "high",
    "unsuccessful-admin": "high",
    "attempted-admin": "high",
    "successful-user": "high",
    "attempted-user": "medium",
    "network-scan": "medium",
    "denial-of-service": "high",
    "misc-attack": "medium",
    "web-application-attack": "high",
    "web-application-activity": "medium",
    "attempted-recon": "low",
    "misc-activity": "low",
    "policy-violation": "low",
    "protocol-anomaly": "medium",
    "attempted-dos": "high",
    "successful-dos": "critical",
    "attempted-recon-largescale": "medium",
    "not-suspicious": "low",
    "unknown": "low",
}

# Header: action proto src_var src_port dir dst_var dst_port
_HEADER_RE = re.compile(
    r"^(?P<action>\w+)\s+"
    r"(?P<proto>\w+)\s+"
    r"(?P<src>[^\s]+)\s+"
    r"(?P<sport>[^\s]+)\s+"
    r"(?P<dir>->|<>)\s+"
    r"(?P<dst>[^\s]+)\s+"
    r"(?P<dport>[^\s]+)\s*\((?P<options>.*)\)\s*$"
)


def _parse_options(options: str) -> List[Tuple[str, str]]:
    """Parse Suricata rule options into an ordered ``(key, value)`` list.

    A real rule repeats keys (``content:`` appears once per clause), so a
    dict would silently drop all but the last — which is how a rule like
    ``content:"GET"; http_method; content:"/list.js.php"; http_uri;`` got
    flattened to ``content=GET`` and fired on every request. Flag-only
    options (``nocase``, ``noalert``...) come back as ``(key, "")``.
    """
    parsed: List[Tuple[str, str]] = []
    # Split on ';' outside double quotes so quoted ';' inside content
    # values survives.
    for part in re.split(r';(?=(?:[^"]*"[^"]*")*[^"]*$)', options):
        part = part.strip()
        if not part:
            continue
        if ":" in part:
            key, value = part.split(":", 1)
            parsed.append((key.strip(), value.strip().strip('"').strip("'")))
        else:
            parsed.append((part, ""))
    return parsed


# Options the engine can either honour or safely ignore (metadata/matcher
# hints that don't change a single-content substring match).
_SUPPORTED_OPTIONS = {
    "msg", "sid", "rev", "gid", "classtype", "priority", "reference",
    "metadata", "service", "flow", "content", "fast_pattern", "threshold",
    "detection_filter", "tag",
}

# Short tokens appear in virtually every request line — a bare substring
# rule on them can only ever false-positive (this is the class that banned
# real clients, e.g. content:-r matching the python-requests User-Agent).
# 5 rejects the observed junk class: GET/POST/PUT/-r/.js/.php/FROM/INTO/SET.
_MIN_CONTENT_LEN = 5


class _UndecodableContent(Exception):
    pass


def _decode_content(content: str) -> Any:
    """Decode a Suricata ``content`` literal for substring matching.

    ``|xx yy|`` hex blobs become their raw bytes (via latin-1 so byte
    values map 1:1 onto codepoints). Returns ``None`` when the content
    cannot be honoured by a plain substring search: negation (``!"..."``),
    or an undecodable token.
    """
    if content.startswith("!"):
        return None

    def _blob(match: "re.Match[str]") -> str:
        try:
            return bytes(
                int(b, 16) for b in match.group(1).split()
            ).decode("latin-1")
        except ValueError:
            raise _UndecodableContent from None

    try:
        decoded = re.sub(r"\|([0-9a-fA-F ]+)\|", _blob, content)
    except _UndecodableContent:
        return None
    return decoded


def _resolve_port(token: str, direction: str) -> List[int]:
    """Return a list of integer ports if the token can be mapped for this direction."""
    token = token.strip()
    if token in _PORT_VARS:
        return _PORT_VARS[token]
    if token in ("any", "$HOME_NET", "$EXTERNAL_NET", "$HOME_NET", "$HTTP_SERVERS", "$SQL_SERVERS"):
        return []
    # Literal single port
    try:
        return [int(token)]
    except ValueError:
        # Port range like 1:1024 or list like [80,443]
        try:
            return [int(p) for p in re.split(r"[:,]", token) if p.strip().isdigit()]
        except ValueError:
            return []


def _severity(classtype: str, priority: str) -> str:
    if priority:
        try:
            p = int(priority)
            if p <= 1:
                return "critical"
            if p <= 2:
                return "high"
            if p <= 3:
                return "medium"
            return "low"
        except ValueError:
            pass
    return _SEVERITY_BY_CLASS.get(classtype, "medium")


def _threat_type(msg: str, classtype: str) -> str:
    # Prefer a short token from the message or classtype.
    if classtype:
        return classtype.split("-")[0]
    tokens = [t for t in re.split(r"[^a-zA-Z0-9_]", msg) if t]
    for t in tokens:
        if t.lower() in (
            "malware",
            "trojan",
            "c2",
            "scan",
            "brute",
            "ddos",
            "dos",
            "exploit",
            "shell",
            "web",
            "sql",
            "xss",
            "rce",
            "recon",
        ):
            return t.lower()
    return "suspicious"


def convert_rule(line: str) -> Dict[str, Any]:
    """Convert a single Suricata/Snort rule line into a ProxmoxVEx rule dict."""
    line = line.strip()
    if not line or line.startswith("#") or line.startswith("//"):
        raise ValueError("Comment or empty line")

    m = _HEADER_RE.match(line)
    if not m:
        raise ValueError("Could not parse rule header")

    options_list = _parse_options(m.group("options"))

    # Any option outside the supported set means the rule carries matching
    # semantics the engine cannot express (http_* scoping, pcre, flowbits,
    # positional modifiers, protocol fields...) — converting it anyway would
    # produce a signature broader than the author wrote, i.e. guaranteed
    # false positives. Skip rather than approximate.
    unsupported = sorted(
        {k for k, _ in options_list if k not in _SUPPORTED_OPTIONS}
    )
    if unsupported:
        raise ValueError(
            "Rule uses options not supported by the current engine: "
            + ", ".join(unsupported)
        )

    options = dict(options_list)
    msg = options.get("msg", "Unknown rule")
    classtype = options.get("classtype", "")
    priority = options.get("priority", "")
    sid = options.get("sid", "")
    rev = options.get("rev", "")

    # The engine matches ONE content substring; a rule with several content
    # clauses ANDs them — not expressible, so skip. Negated content is also
    # unexpressible. Hex blobs are decoded so |2e 2e 2f| matches '../' as
    # Suricata intends.
    contents = [v for k, v in options_list if k == "content"]
    if len(contents) > 1:
        raise ValueError("Multi-content rules are not supported")

    content = ""
    if contents:
        decoded = _decode_content(contents[0])
        if decoded is None:
            raise ValueError("Content clause not supported by the engine")
        if len(decoded) < _MIN_CONTENT_LEN:
            raise ValueError("Content too short to discriminate")
        # ';' would break the engine's ';'-separated signature parse —
        # content=;;... parses as an empty (match-all) content.
        if ";" in decoded:
            raise ValueError("Content contains a signature separator")
        content = decoded

    dports = _resolve_port(m.group("dport"), "dport")
    sports = _resolve_port(m.group("sport"), "sport")
    flow = options.get("flow", "")

    # Try to build a simple signature. Prefer dport, fall back to sport.
    conditions = []
    if dports:
        conditions.append(",".join(f"dport={p}" for p in dports))
    elif sports:
        conditions.append(",".join(f"sport={p}" for p in sports))

    if not conditions and not content:
        raise ValueError("No usable literal port or content in rule header")

    if content:
        conditions.append(f"content={content}")
    if flow and "to_server" in flow:
        conditions.append("flow=to_server")
    elif flow and "to_client" in flow:
        conditions.append("flow=to_client")

    signature = ";".join(conditions)

    sev = _severity(classtype, priority)
    threshold = 1 if sev in ("critical", "high") else 5 if sev == "medium" else 20

    return {
        "name": f"ET {sid}: {msg}"[:120] if sid else msg[:120],
        "enabled": True,
        "rule_type": "signature",
        "signature": signature,
        "anomaly_config": {"threshold": threshold, "source": "ET Open"},
        "severity": sev,
        "threat_type": _threat_type(msg, classtype),
        "description": f"{msg} (sid:{sid} rev:{rev}, classtype:{classtype})",
    }


def convert_rules(text: str) -> Tuple[List[Dict[str, Any]], List[Dict[str, str]]]:
    """Convert a multi-line .rules file. Returns (converted, skipped)."""
    converted: List[Dict[str, Any]] = []
    skipped: List[Dict[str, str]] = []
    seen_names = set()
    for line in text.splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        try:
            rule = convert_rule(line)
            # Deduplicate by name.
            if rule["name"] in seen_names:
                continue
            seen_names.add(rule["name"])
            converted.append(rule)
        except ValueError as e:
            skipped.append({"line": line[:120], "reason": str(e)})
    return converted, skipped


def convert_ruleset_archive(archive_bytes: bytes) -> Tuple[List[Dict[str, Any]], List[Dict[str, str]], List[str]]:
    """Extract and convert rules from a Suricata .tar.gz archive.

    Returns (converted_rules, skipped_infos, filenames).
    """
    converted: List[Dict[str, Any]] = []
    skipped: List[Dict[str, str]] = []
    filenames: List[str] = []
    seen_names = set()

    with tarfile.open(fileobj=io.BytesIO(archive_bytes), mode="r:gz") as tar:
        for member in tar.getmembers():
            if not member.isfile() or not member.name.endswith(".rules"):
                continue
            filenames.append(member.name)
            f = tar.extractfile(member)
            if not f:
                continue
            text = f.read().decode("utf-8", errors="replace")
            for line in text.splitlines():
                line = line.strip()
                if not line or line.startswith("#"):
                    continue
                try:
                    rule = convert_rule(line)
                    if rule["name"] in seen_names:
                        continue
                    seen_names.add(rule["name"])
                    converted.append(rule)
                except ValueError as e:
                    skipped.append({"file": member.name, "line": line[:120], "reason": str(e)})

    return converted, skipped, filenames
