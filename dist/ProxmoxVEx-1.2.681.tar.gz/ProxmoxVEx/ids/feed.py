# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/ids/feed.py
# Project:     ProxmoxVEx
# Version:     1.2.681
# Build:       2026.10.22
# Description: Fetch and import public IDS rule feeds into the
#              ProxmoxVEx IDS/IPS module.
# Usage:       import ProxmoxVEx.ids.feed
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-10-22
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Fetch and import public IDS rule feeds into the ProxmoxVEx IDS/IPS module."""

import json
import logging
import urllib.error
import urllib.request
from pathlib import Path
from typing import Any, Dict, Optional

from ProxmoxVEx.ids import converter, models

logger = logging.getLogger(__name__)

# Default ET Open feed for Suricata. Updated daily.
DEFAULT_RULESET_URL = "https://rules.emergingthreats.net/open/suricata/emerging.rules.tar.gz"
DEFAULT_VERSION_URL = "https://rules.emergingthreats.net/open/suricata/version.txt"
# Snort community ruleset (alternative). Requires a real Snort/Suricata engine to use.
SNORT_COMMUNITY_URL = "https://www.snort.org/rules/community"


def _http_get(url: str, timeout: int = 30) -> bytes:
    """Download the contents of a URL into memory."""
    req = urllib.request.Request(url, headers={"User-Agent": "ProxmoxVEx-ids-feed/1.0"})
    with urllib.request.urlopen(req, timeout=timeout) as response:  # nosec: fixed URLs above, user overrides below
        return response.read()


def get_latest_version(url: str = DEFAULT_VERSION_URL, timeout: int = 10) -> Optional[str]:
    """Fetch the latest version string from the upstream feed."""
    try:
        return _http_get(url, timeout=timeout).decode("utf-8", errors="replace").strip()
    except (urllib.error.URLError, OSError) as e:
        logger.warning("Could not fetch IDS feed version: %s", e)
        return None


def fetch_ruleset(url: str = DEFAULT_RULESET_URL, timeout: int = 120) -> Optional[bytes]:
    """Download a Suricata/Snort ruleset archive."""
    logger.info("Fetching IDS rule feed from %s", url)
    try:
        return _http_get(url, timeout=timeout)
    except (urllib.error.URLError, OSError) as e:
        logger.error("Failed to fetch IDS rule feed: %s", e)
        return None


def _refresh_or_create(existing: Dict[str, Any], rule: Dict[str, Any], created_by: str) -> str:
    """Insert a converted rule, or refresh a same-named row's fields.

    Feed rules carry stable names (``ET <sid>: <msg>``) but their
    signatures evolve with each upstream rev. Name-dedup alone left stale
    signatures in place forever — on collision we now update the signature
    and derived fields while preserving the operator's ``enabled`` toggle.
    """
    name = rule.get("name") or "unknown"
    row = existing.get(name)
    if row is None:
        models.create_rule(rule, created_by)
        return "imported"
    fields: Dict[str, Any] = {
        k: rule.get(k)
        for k in ("signature", "severity", "threat_type", "description")
        if k in rule and rule.get(k) != row.get(k)
    }
    # Row stores anomaly_config as its JSON string; normalise before compare
    # or every sync would report a false diff.
    if json.dumps(rule.get("anomaly_config")) != json.dumps(
        json.loads(row["anomaly_config"]) if row.get("anomaly_config") else None
    ):
        fields["anomaly_config"] = rule.get("anomaly_config")
    if fields:
        models.update_rule(row["id"], fields)
        return "updated"
    return "unchanged"


def import_ruleset_text(text: str, created_by: str = "feed-import") -> Dict[str, Any]:
    """Convert a plain .rules text and import into the database."""
    converted, skipped = converter.convert_rules(text)
    existing = {r["name"]: r for r in models.list_rules(enabled_only=False)}
    imported = updated = 0
    for rule in converted:
        try:
            outcome = _refresh_or_create(existing, rule, created_by)
            if outcome == "imported":
                imported += 1
                existing[rule.get("name") or "unknown"] = rule
            elif outcome == "updated":
                updated += 1
        except Exception as e:  # noqa: BLE001
            rule_name = rule.get("name") or "unknown"
            logger.warning("Failed to import rule %s: %s", rule_name, e)
            skipped.append({"name": str(rule_name), "reason": str(e)})
    return {"imported": imported, "updated": updated, "skipped": len(skipped), "skipped_reasons": skipped[:10]}


def import_ruleset_archive(archive_bytes: bytes, created_by: str = "feed-import") -> Dict[str, Any]:
    """Extract a .tar.gz ruleset archive and import the converted rules."""
    converted, skipped, filenames = converter.convert_ruleset_archive(archive_bytes)
    existing = {r["name"]: r for r in models.list_rules(enabled_only=False)}
    imported = updated = 0
    for rule in converted:
        try:
            outcome = _refresh_or_create(existing, rule, created_by)
            if outcome == "imported":
                imported += 1
                existing[rule.get("name") or "unknown"] = rule
            elif outcome == "updated":
                updated += 1
        except Exception as e:  # noqa: BLE001
            rule_name = rule.get("name") or "unknown"
            logger.warning("Failed to import rule %s: %s", rule_name, e)
            skipped.append({"name": str(rule_name), "reason": str(e)})
    return {
        "imported": imported,
        "updated": updated,
        "skipped": len(skipped),
        "files": filenames,
        "skipped_reasons": skipped[:10],
    }


def update_from_feed(
    ruleset_url: str = DEFAULT_RULESET_URL,
    version_url: str = DEFAULT_VERSION_URL,
    created_by: str = "feed-update",
) -> Dict[str, Any]:
    """Check upstream version, download the ruleset and import converted rules."""
    version = get_latest_version(version_url)
    archive = fetch_ruleset(ruleset_url)
    if archive is None:
        return {"error": "Failed to download feed", "version": version}
    result = import_ruleset_archive(archive, created_by)
    result["version"] = version
    return result


def import_local_file(path: Path, created_by: str = "local-import") -> Dict[str, Any]:
    """Import a local .rules file."""
    text = path.read_text(encoding="utf-8", errors="replace")
    return import_ruleset_text(text, created_by)
