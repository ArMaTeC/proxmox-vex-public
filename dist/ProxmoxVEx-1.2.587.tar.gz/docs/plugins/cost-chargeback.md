<!-- GENERATED:START -->
# Cost Chargeback

`cost-chargeback` v1.0.3

Calculate VM/LXC running costs by CPU, RAM, storage, network, and power and allocate to tenants.

**Author:** ProxmoxVEx Team | **Category:** Cost & Billing | **License tier:** `advanced` | **Requires ProxmoxVEx:** ≥ 1.2.23

## Permissions
_No host scopes declared._

## Configuration
_No config schema declared._

## Events subscribed
_None._
<!-- GENERATED:END -->
