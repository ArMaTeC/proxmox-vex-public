# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/native/opnsense/opnsense_src/writers/audit.py
# Project:     ProxmoxVEx
# Version:     1.2.565
# Build:       2026.09.30
# Description: Compat shim — the audit recorder moved to
#              `ProxmoxVEx.native.fwkit.audit` so the pfSense plugin
#              shares it. Keep this module so existing
# Usage:       import
#              ProxmoxVEx.native.opnsense.opnsense_src.writers.audit
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-30
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Compat shim — the audit recorder moved to `ProxmoxVEx.native.fwkit.audit`
so the pfSense plugin shares it. Keep this module so existing
`opnsense_src.writers.audit` imports (routes, writers, tests) keep working.
"""

from opnsense_src._fwkit import ensure_fwkit_importable

ensure_fwkit_importable()

from ProxmoxVEx.native.fwkit.audit import (  # noqa: E402,F401
    AuditEntry,
    AuditLog,
    TimedAction,
    hash_payload,
)
