# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/native/opnsense/opnsense_src/__init__.py
# Project:     ProxmoxVEx
# Version:     1.2.565
# Build:       2026.09.30
# Description: Package initializer for opnsense_src
# Usage:       import ProxmoxVEx.native.opnsense.opnsense_src
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-30
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
