# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/native/vmware_vcenter/vcenter_src/client/__init__.py
# Project:     ProxmoxVEx
# Version:     1.2.565
# Build:       2026.09.30
# Description: Package initializer for client
# Usage:       import
#              ProxmoxVEx.native.vmware_vcenter.vcenter_src.client
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-30
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
from .vcenter_client import (  # noqa: F401
    VCenterAuthError,
    VCenterClient,
    VCenterError,
    VCenterHost,
    VCenterTimeoutError,
)
