# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/native/zabbix/zabbix_src/client/__init__.py
# Project:     ProxmoxVEx
# Version:     1.2.565
# Build:       2026.09.30
# Description: Zabbix JSON-RPC client package.
# Usage:       import ProxmoxVEx.native.zabbix.zabbix_src.client
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-30
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Zabbix JSON-RPC client package."""

from __future__ import annotations

from .zabbix_client import (  # noqa: F401
    ZabbixClient,
    ZabbixHost,
)
