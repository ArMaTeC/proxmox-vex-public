# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/native/zabbix/zabbix_src/collectors/problems.py
# Project:     ProxmoxVEx
# Version:     1.2.565
# Build:       2026.09.30
# Description: Problems collector for Zabbix.
# Usage:       import
#              ProxmoxVEx.native.zabbix.zabbix_src.collectors.problems
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-30
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Problems collector for Zabbix."""

from __future__ import annotations

from typing import Any

from zabbix_src.client import ZabbixClient


def collect_problems(client: ZabbixClient) -> dict[str, Any]:
    """Return Zabbix problems as an ``{'ok': True, 'data': [...]}`` shape."""
    return client.list_problems()
