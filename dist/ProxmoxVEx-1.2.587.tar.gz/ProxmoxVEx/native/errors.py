# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/native/errors.py
# Project:     ProxmoxVEx
# Version:     1.2.565
# Build:       2026.09.30
# Description: Shared connectivity-error classifier for native
#              integrations.
# Usage:       import ProxmoxVEx.native.errors
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-30
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Shared connectivity-error classifier for native integrations.

Native module clients (``vyos_src``, ``zabbix_src``, …) historically caught
``Exception`` and returned ``{"ok": False, "error": str(e)}`` — the raw
``requests``/``urllib3`` exception repr. The shared ``native-dataview.js``
frontend categorizes on ``payload.error`` (``unconfigured``/``auth``/
``timeout``/generic), so raw exception text always fell through to the generic
card and showed the user a multi-line stack fragment.

``classify_error`` maps exceptions to a stable machine code plus a single-line
human detail:

- ``auth``        — HTTP 401/403
- ``tls``         — SSL/certificate failures
- ``timeout``     — connect/read timeouts
- ``unreachable`` — refused/DNS/unroutable connections
- ``api``         — other HTTP error statuses
- ``dependency``  — missing client library (e.g. "requests not installed")
- ``internal``    — everything else

Classification is duck-typed (class-name walk + ``response.status_code``) so
it works regardless of which HTTP library raised and does not require
``requests`` to be importable.
"""

from __future__ import annotations

from typing import Any

_DETAIL_LIMIT = 200


def _class_names(exc: BaseException) -> set[str]:
    return {cls.__name__ for cls in type(exc).__mro__}


def _first_line(text: Any) -> str:
    line = str(text or "").splitlines()[0] if text else ""
    return line[:_DETAIL_LIMIT]


def classify_error(exc: BaseException) -> dict:
    """Map a connectivity exception to ``{"error": <code>, "detail": <line>}``."""
    names = _class_names(exc)
    message = _first_line(exc)

    # HTTP status first — an HTTPError is also a RequestException/IOError in
    # some libs, so it must outrank the generic connectivity buckets.
    response = getattr(exc, "response", None)
    status = getattr(response, "status_code", None)
    if status in (401, 403):
        return {"error": "auth", "detail": message or f"HTTP {status}"}
    if "HTTPError" in names and status:
        return {"error": "api", "detail": message or f"HTTP {status}"}

    if "ImportError" in names or "ModuleNotFoundError" in names or "requests not installed" in message:
        return {"error": "dependency", "detail": message}

    if any("SSL" in n or "TLS" in n for n in names) or "ssl" in message.lower() and "certificate" in message.lower():
        return {"error": "tls", "detail": message}

    if any("Timeout" in n for n in names) or "TimeoutError" in names:
        return {"error": "timeout", "detail": message or "Connection timed out"}

    unreachable_names = {
        "ConnectionError",
        "NewConnectionError",
        "ConnectTimeoutError",
        "gaierror",
        "NameResolutionError",
        "ConnectionRefusedError",
        "ConnectionResetError",
        "ConnectionAbortedError",
        "NetworkUnreachable",
        "MaxRetryError",
        "FailedToEstablishConnection",
        "OSError",
    }
    if names & unreachable_names:
        # HTTPError subclasses of ConnectionError (or stray 401/403 paths not
        # carrying .response) still win the auth bucket via message sniffing.
        lowered = message.lower()
        if "401" in lowered or "403" in lowered or "unauthorized" in lowered or "forbidden" in lowered:
            return {"error": "auth", "detail": message}
        return {"error": "unreachable", "detail": message}

    return {"error": "internal", "detail": message}
