# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/api/schedules.py
# Project:     ProxmoxVEx
# Version:     1.2.565
# Build:       2026.09.30
# Description: scheduler + update schedule routes - split from
#              monolith dec 2025
# Usage:       import ProxmoxVEx.api.schedules
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-30
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""scheduler + update schedule routes - split from monolith dec 2025"""

import json
import logging
import os
import threading
import time
from datetime import datetime, timedelta

from flask import Blueprint, jsonify, request

from ProxmoxVEx.api.helpers import check_cluster_access, safe_error
from ProxmoxVEx.api.nodes import cleanup_deleted_scripts, cleanup_orphaned_excluded_vms
from ProxmoxVEx.constants import CONFIG_DIR
from ProxmoxVEx.core.db import get_db
from ProxmoxVEx.globals import cluster_managers
from ProxmoxVEx.models.permissions import ROLE_ADMIN
from ProxmoxVEx.utils.audit import log_audit
from ProxmoxVEx.utils.auth import build_authz_user, get_user_record, require_auth
from ProxmoxVEx.utils.rbac import has_permission

bp = Blueprint("schedules", __name__)


def _perm_for_action(action):
    # ISS-077: shell_command executes arbitrary commands as the service user, and
    # webhook hits arbitrary URLs — both must require admin, not a VM permission.
    if action in ("shell_command", "webhook"):
        return "admin"
    # Scheduling an action requires the same permission as running it by hand
    return {
        "start": "vm.start",
        "stop": "vm.stop",
        "shutdown": "vm.stop",
        "reboot": "vm.restart",
        "snapshot": "vm.snapshot",
    }.get(action, "vm.start")


def _require_action_perm(action):
    # returns an error response if the caller can't perform `action`, else None
    user = build_authz_user(getattr(request, "session", {}).get("user", ""), getattr(request, "session", {}))
    perm = _perm_for_action(action)
    if not has_permission(user, perm):
        # snyk:ignore:Cross-site Scripting (XSS)
        return jsonify({"error": f"Permission denied: {perm} required to schedule a {action} action"}), 403
    return None


# ============================================

SCHEDULES_FILE = os.path.join(CONFIG_DIR, "scheduled_actions.json")
_scheduler_thread = None
_scheduler_running = False


def load_schedules() -> dict:
    """Load scheduled actions from SQLite database

    SQLite migration
    """
    try:
        db = get_db()
        cursor = db.conn.cursor()
        # US075: trashed schedules stay in the table for restore but are
        # invisible to the scheduler and the UI list.
        cursor.execute("SELECT * FROM scheduled_actions WHERE deleted_at IS NULL")

        actions = []
        last_id = 0
        # (#337): name + vm_type are persisted via columns added in the
        # db migration block. On legacy rows both come back as NULL — fall back
        # to a sensible default so the frontend form doesn't render blank.
        row_keys = [d[0] for d in cursor.description] if cursor.description else []
        has_name = "name" in row_keys
        has_vm_type = "vm_type" in row_keys
        for row in cursor.fetchall():
            if row["id"] > last_id:
                last_id = row["id"]
            actions.append({
                "id": row["id"],
                "cluster_id": row["cluster_id"],
                "vmid": row["vmid"],
                "vm_type": (row["vm_type"] if has_vm_type and row["vm_type"] else "qemu"),
                "action": row["action"],
                "schedule_type": row["schedule_type"],
                "time": row["schedule_time"],
                "days": json.loads(row["schedule_days"] or "[]"),
                "date": row["schedule_date"],
                "enabled": bool(row["enabled"]),
                "last_run": row["last_run"],
                "name": (row["name"] if has_name and row["name"] else ""),
                "created_by": row["created_by"],
            })

        return {"actions": actions, "last_id": last_id}
    except Exception as e:
        logging.error(f"Error loading schedules from database: {e}")
        # Legacy fallback
        try:
            if os.path.exists(SCHEDULES_FILE):
                with open(SCHEDULES_FILE) as f:
                    return json.load(f)
        except Exception as e2:
            logging.debug(f"Legacy schedules file fallback failed: {e2}")
    return {"actions": [], "last_id": 0}


def save_schedules(schedules):
    """Save scheduled actions to SQLite database

    SQLite migration
    """
    try:
        db = get_db()
        cursor = db.conn.cursor()

        # Clear existing schedules — only ACTIVE rows: trashed rows (US075)
        # must survive this rewrite-all save so restore still works.
        cursor.execute("DELETE FROM scheduled_actions WHERE deleted_at IS NULL")

        now = datetime.now().isoformat()
        # (#337): include name + vm_type - previously dropped silently
        for action in schedules.get("actions", []):
            cursor.execute(
                """
                INSERT INTO scheduled_actions
                (id, cluster_id, vmid, vm_type, action, schedule_type, schedule_time,
                 schedule_days, schedule_date, enabled, last_run, name, created_by, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
                (
                    action.get("id"),
                    action.get("cluster_id"),
                    action.get("vmid"),
                    action.get("vm_type", "qemu"),
                    action.get("action", ""),
                    action.get("schedule_type", "daily"),
                    action.get("time", ""),
                    json.dumps(action.get("days", [])),
                    action.get("date"),
                    1 if action.get("enabled", True) else 0,
                    action.get("last_run"),
                    action.get("name") or None,
                    action.get("created_by"),
                    now,
                ),
            )

        db.conn.commit()
    except Exception as e:
        logging.error(f"Error saving schedules: {e}")


def check_schedules():
    """Check if any scheduled actions need to run

    Called every minute by the scheduler thread
    This is deliberately simple - no cron expressions, just specific times
    """
    global _scheduler_running

    while _scheduler_running:
        try:
            schedules = load_schedules()
            now = datetime.now()
            current_time = now.strftime("%H:%M")
            current_day = now.strftime("%A").lower()
            current_date = now.strftime("%Y-%m-%d")

            modified = False

            for action in schedules.get("actions", []):
                if not action.get("enabled", True):
                    continue

                should_run = False
                schedule_type = action.get("schedule_type", "daily")
                schedule_time = action.get("time", "")

                # Check if it's time to run
                if schedule_time == current_time:
                    if schedule_type == "once":
                        # One-time schedule - check date
                        if action.get("date") == current_date:
                            should_run = True
                            action["enabled"] = False  # Disable after running
                            modified = True

                    elif schedule_type == "daily":
                        should_run = True

                    elif schedule_type == "weekly":
                        # Check if today is in the selected days
                        days = action.get("days", [])
                        if current_day in days:
                            should_run = True

                    elif schedule_type == "weekdays":
                        if current_day not in ["saturday", "sunday"]:
                            should_run = True

                    elif schedule_type == "weekends" and current_day in ["saturday", "sunday"]:
                        should_run = True

                if should_run:
                    # Check if we already ran this minute (prevent double execution)
                    last_run = action.get("last_run", "")
                    if last_run == f"{current_date} {current_time}":
                        continue

                    # Execute the action
                    execute_scheduled_action(action)
                    action["last_run"] = f"{current_date} {current_time}"
                    action["run_count"] = action.get("run_count", 0) + 1
                    modified = True

            if modified:
                save_schedules(schedules)

            # Check for scheduled rolling updates
            try:
                check_scheduled_updates()
            except Exception as e:
                logging.error(f"[SCHEDULER] Scheduled updates check error: {e}")

            # Daily cleanup tasks at 03:00
            if current_time == "03:00":
                try:
                    # Cleanup soft-deleted scripts after 20 days
                    cleanup_deleted_scripts()
                    # Cleanup orphaned excluded VMs (VMs that no longer exist)
                    cleanup_orphaned_excluded_vms()
                    logging.info("[SCHEDULER] Daily cleanup completed")
                except Exception as e:
                    logging.error(f"[SCHEDULER] Daily cleanup error: {e}")

        except Exception as e:
            logging.error(f"Scheduler error: {e}")

        # Sleep for 60 seconds (check every minute)
        for _ in range(60):
            if not _scheduler_running:
                break
            time.sleep(1)


def execute_scheduled_action(action):
    """Execute a scheduled VM action

    This is basically the same as the manual action endpoints
    but called from the scheduler

    Added rolling_update for automatic node updates
    """
    cluster_id = action.get("cluster_id")
    vmid = action.get("vmid")
    vm_type = action.get("vm_type", "qemu")
    action_type = action.get("action")

    logging.info(f"[SCHEDULER] Executing {action_type} on {vm_type}/{vmid} in {cluster_id}")

    if cluster_id not in cluster_managers:
        logging.error(f"[SCHEDULER] Cluster {cluster_id} not found")
        return

    mgr = cluster_managers[cluster_id]
    if not mgr.is_connected:
        logging.error(f"[SCHEDULER] Cluster {cluster_id} not connected")
        return

    try:
        # Handle rolling_update action type separately
        if action_type == "rolling_update":
            execute_scheduled_rolling_update(mgr, cluster_id, action)
            return

        # Find the node where the VM is running
        resources = mgr.get_vm_resources()
        vm = next((r for r in resources if r.get("vmid") == vmid), None)

        if not vm:
            logging.error(f"[SCHEDULER] VM {vmid} not found")
            return

        node = vm.get("node")
        host, port = mgr.host, mgr.api_port

        # Build the API URL based on action
        if action_type == "start":
            url = f"https://{host}:{port}/api2/json/nodes/{node}/{vm_type}/{vmid}/status/start"
        elif action_type == "stop":
            url = f"https://{host}:{port}/api2/json/nodes/{node}/{vm_type}/{vmid}/status/stop"
        elif action_type == "shutdown":
            url = f"https://{host}:{port}/api2/json/nodes/{node}/{vm_type}/{vmid}/status/shutdown"
        elif action_type == "reboot":
            url = f"https://{host}:{port}/api2/json/nodes/{node}/{vm_type}/{vmid}/status/reboot"
        elif action_type == "snapshot":
            # Create a snapshot with timestamp
            snap_name = f"scheduled_{datetime.now().strftime('%Y%m%d_%H%M')}"
            url = f"https://{host}:{port}/api2/json/nodes/{node}/{vm_type}/{vmid}/snapshot"
            response = mgr._create_session().post(url, data={"snapname": snap_name})
            logging.info(f"[SCHEDULER] Snapshot result: {response.status_code}")
            return
        else:
            logging.error(f"[SCHEDULER] Unknown action: {action_type}")
            return

        response = mgr._create_session().post(url)
        logging.info(f"[SCHEDULER] {action_type} result: {response.status_code}")

        # Log the action
        log_audit(
            "scheduler", f"scheduled.{action_type}", f"Scheduled {action_type} executed on VM {vmid} in {cluster_id}"
        )

    except Exception as e:
        logging.error(f"[SCHEDULER] Failed to execute {action_type}: {e}")


def execute_scheduled_rolling_update(mgr, cluster_id: str, action: dict):
    """Execute a scheduled rolling update on a cluster

    This runs the same rolling update logic but triggered by scheduler
    """
    try:
        # Get update config from action
        config = action.get("config", {})
        include_reboot = config.get("include_reboot", False)
        skip_evacuation = config.get("skip_evacuation", False)
        skip_up_to_date = config.get("skip_up_to_date", True)
        evacuation_timeout = config.get("evacuation_timeout", 1800)
        wait_for_reboot = config.get("wait_for_reboot", True)

        logging.info(f"[SCHEDULER] Starting scheduled rolling update for cluster {cluster_id}")
        logging.info(f"[SCHEDULER] Config: reboot={include_reboot}, skip_evacuation={skip_evacuation}")

        # Check if already running
        if hasattr(mgr, "_rolling_update") and mgr._rolling_update and mgr._rolling_update.get("status") == "running":
            logging.warning("[SCHEDULER] Rolling update already in progress, skipping")
            return

        # Get nodes
        node_status = mgr.get_node_status()
        nodes_to_update = list(node_status.keys()) if node_status else []

        if not nodes_to_update:
            logging.warning("[SCHEDULER] No nodes available for update")
            return

        # Initialize rolling update state
        mgr._rolling_update = {
            "status": "running",
            "started_at": time.strftime("%Y-%m-%d %H:%M:%S"),
            "include_reboot": include_reboot,
            "skip_up_to_date": skip_up_to_date,
            "skip_evacuation": skip_evacuation,
            "wait_for_reboot": wait_for_reboot,
            "pause_on_evacuation_error": False,
            "force_all": False,
            "evacuation_timeout": evacuation_timeout,
            "update_timeout": 900,
            "reboot_timeout": 600,
            "nodes": nodes_to_update,
            "current_index": 0,
            "current_node": nodes_to_update[0],
            "current_step": "starting",
            "completed_nodes": [],
            "skipped_nodes": [],
            "failed_nodes": [],
            "rebooting_nodes": [],
            "paused_reason": None,
            "paused_details": None,
            "logs": [f"[{time.strftime('%H:%M:%S')}] Scheduled rolling update started"],
            "scheduled": True,
        }

        def run_scheduled_update():
            try:
                for idx, node_name in enumerate(nodes_to_update):
                    if not hasattr(mgr, "_rolling_update") or mgr._rolling_update.get("status") != "running":
                        break
                    mgr._rolling_update["current_index"] = idx
                    mgr._rolling_update["current_node"] = node_name
                    mgr._rolling_update["logs"].append(f"[{time.strftime('%H:%M:%S')}] Processing {node_name}")
                    if skip_up_to_date:
                        try:
                            mgr.refresh_node_apt(node_name)
                            time.sleep(3)
                            if not mgr.get_node_apt_updates(node_name):
                                mgr._rolling_update["logs"].append(
                                    f"[{time.strftime('%H:%M:%S')}] {node_name} up-to-date, skipping"
                                )
                                mgr._rolling_update["skipped_nodes"].append(node_name)
                                continue
                        except Exception as e:
                            logging.warning(f"[SCHEDULER] Check failed for {node_name}: {e}")
                    mgr._rolling_update["current_step"] = "maintenance"
                    mgr.enter_maintenance_mode(node_name, skip_evacuation=skip_evacuation)
                    if not skip_evacuation:
                        mgr._rolling_update["current_step"] = "evacuating"
                        waited = 0
                        evacuation_ok = False
                        while waited < evacuation_timeout:
                            if node_name in mgr.nodes_in_maintenance:
                                task = mgr.nodes_in_maintenance[node_name]
                                if task.status == "completed":
                                    evacuation_ok = True
                                    break
                                elif task.status == "completed_with_errors":
                                    fv = getattr(task, "failed_vms", [])
                                    mgr._rolling_update["logs"].append(
                                        f"[{time.strftime('%H:%M:%S')}] ⚠️ Evacuation: {getattr(task, 'migrated_vms', 0)}/{getattr(task, 'total_vms', 0)} migrated, {len(fv)} failed - continuing"
                                    )
                                    evacuation_ok = True
                                    break
                                elif task.status == "failed":
                                    break
                            time.sleep(5)
                            waited += 5
                        if not evacuation_ok:
                            mgr._rolling_update["logs"].append(
                                f"[{time.strftime('%H:%M:%S')}] ✗ Evacuation failed on {node_name}, skipping"
                            )
                            mgr._rolling_update["failed_nodes"].append({
                                "node": node_name,
                                "error": "Evacuation failed",
                            })
                            mgr.exit_maintenance_mode(node_name)
                            continue
                    mgr._rolling_update["current_step"] = "updating"
                    update_task = mgr.start_node_update(node_name, reboot=include_reboot, force=True)
                    if update_task:
                        waited = 0
                        while waited < (1800 if include_reboot else 900):
                            if update_task.status in ["completed", "failed"]:
                                break
                            time.sleep(10)
                            waited += 10
                        if update_task.status == "completed":
                            mgr._rolling_update["logs"].append(f"[{time.strftime('%H:%M:%S')}] ✓ {node_name} updated")
                            mgr._rolling_update["completed_nodes"].append(node_name)
                            if include_reboot:
                                mgr._rolling_update["current_step"] = "rebooting"
                                mgr._rolling_update["rebooting_nodes"].append(node_name)
                                if wait_for_reboot:
                                    mgr._rolling_update["logs"].append(
                                        f"[{time.strftime('%H:%M:%S')}] Waiting for {node_name} to reboot..."
                                    )
                                    ow = 0
                                    while ow < 120:
                                        try:
                                            ns = mgr.get_node_status()
                                            if node_name not in ns or ns[node_name].get("status") != "online":
                                                break
                                        except Exception as e:
                                            logging.debug(f"[SCHEDULER] node-status poll failed while waiting for {node_name} to go offline: {e}")
                                            break
                                        time.sleep(5)
                                        ow += 5
                                    rw = 0
                                    came_back = False
                                    while rw < 600:
                                        try:
                                            ns = mgr.get_node_status()
                                            if node_name in ns and ns[node_name].get("status") == "online":
                                                mgr._rolling_update["logs"].append(
                                                    f"[{time.strftime('%H:%M:%S')}] ✓ {node_name} back online"
                                                )
                                                if node_name in mgr._rolling_update["rebooting_nodes"]:
                                                    mgr._rolling_update["rebooting_nodes"].remove(node_name)
                                                came_back = True
                                                # Give HA services time to start
                                                # before trying to disable maintenance. 10s was
                                                # too short → ha-manager rejected the disable
                                                # call and node stayed in maintenance.
                                                time.sleep(30)
                                                break
                                        except Exception as e:
                                            logging.debug(f"[SCHEDULER] node-status poll failed while waiting for {node_name} online: {e}")
                                        time.sleep(10)
                                        rw += 10
                                    if not came_back:
                                        mgr._rolling_update["logs"].append(
                                            f"[{time.strftime('%H:%M:%S')}] ⚠ {node_name} did not come back online within 600s"
                                        )
                                else:
                                    mgr._rolling_update["logs"].append(
                                        f"[{time.strftime('%H:%M:%S')}] {node_name} rebooting (wait_for_reboot=False)"
                                    )
                        else:
                            mgr._rolling_update["logs"].append(
                                f"[{time.strftime('%H:%M:%S')}] ✗ {node_name} update failed"
                            )
                            mgr._rolling_update["failed_nodes"].append({"node": node_name, "error": "Update failed"})
                    # Exit_maintenance_mode now retries internally;
                    # if it still returns False the node is stuck and we log it
                    # for the post-loop sweep below.
                    if not mgr.exit_maintenance_mode(node_name):
                        mgr._rolling_update["logs"].append(
                            f"[{time.strftime('%H:%M:%S')}] ⚠ {node_name} maintenance exit failed — will retry at end"
                        )

                # Final sweep: any node still flagged as in
                # maintenance gets one more shot, after a longer settle time.
                # Catches the case where the node took >600s to reboot or HA
                # services were still starting when we tried to exit.
                stuck_nodes = []
                try:
                    with mgr.maintenance_lock:
                        stuck_nodes = list(mgr.nodes_in_maintenance.keys())
                except Exception as e:
                    logging.debug(f"[SCHEDULER] maintenance-lock read failed during stuck-node sweep: {e}")
                if stuck_nodes:
                    mgr._rolling_update["logs"].append(
                        f"[{time.strftime('%H:%M:%S')}] Cleanup: {len(stuck_nodes)} node(s) still in maintenance, retrying..."
                    )
                    time.sleep(15)
                    for nn in stuck_nodes:
                        if mgr.exit_maintenance_mode(nn):
                            mgr._rolling_update["logs"].append(
                                f"[{time.strftime('%H:%M:%S')}] ✓ {nn} maintenance cleared on retry"
                            )
                        else:
                            mgr._rolling_update["logs"].append(
                                f"[{time.strftime('%H:%M:%S')}] ✗ {nn} STILL in maintenance — manual intervention needed"
                            )
                            mgr._rolling_update["failed_nodes"].append({
                                "node": nn,
                                "error": "Stuck in maintenance after rolling update",
                            })

                # Finished
                mgr._rolling_update["status"] = "completed"
                mgr._rolling_update["logs"].append(f"[{time.strftime('%H:%M:%S')}] Scheduled rolling update completed")

                # Log audit
                log_audit(
                    "scheduler",
                    "scheduled.rolling_update",
                    f"Scheduled rolling update completed: {len(mgr._rolling_update['completed_nodes'])} updated, "
                    f"{len(mgr._rolling_update['skipped_nodes'])} skipped, "
                    f"{len(mgr._rolling_update['failed_nodes'])} failed",
                )

            except Exception as e:
                logging.error(f"[SCHEDULER] Rolling update error: {e}")
                if hasattr(mgr, "_rolling_update"):
                    mgr._rolling_update["status"] = "failed"
                    mgr._rolling_update["logs"].append(f"[{time.strftime('%H:%M:%S')}] ERROR: {e}")

        update_thread = threading.Thread(target=run_scheduled_update, daemon=True)
        update_thread.start()

        logging.info(f"[SCHEDULER] Rolling update thread started for {cluster_id}")

    except Exception as e:
        logging.error(f"[SCHEDULER] Failed to start scheduled rolling update: {e}")


def start_scheduler():
    """Start the scheduler background thread"""
    global _scheduler_thread, _scheduler_running

    if _scheduler_thread and _scheduler_thread.is_alive():
        return

    _scheduler_running = True
    _scheduler_thread = threading.Thread(target=check_schedules, daemon=True)
    _scheduler_thread.start()
    logging.info("Scheduler started")


def stop_scheduler():
    """Stop the scheduler"""
    global _scheduler_running
    _scheduler_running = False


# API endpoints for scheduled actions


@bp.route("/api/schedules", methods=["GET"])
@require_auth()
def get_schedules():
    """Get all scheduled actions

    Filters by user's accessible clusters unless admin
    """
    schedules = load_schedules()

    user = getattr(request, "session", {}).get("user", "")
    # (perf) indexed single-row fetch — load_users() scanned/decrypted all users
    user_data = get_user_record(user)
    is_admin = user_data.get("role") == ROLE_ADMIN

    # (CodeAnt IDOR) - use the real access model. The old filter read the raw
    # user_data['clusters'] field and FELL OPEN (`if not user_clusters` -> returned every tenant's
    # schedules) when it was empty. get_user_clusters returns None only for a genuine admin/
    # default-tenant all-cluster user; otherwise it's the caller's reachable cluster set.
    from ProxmoxVEx.utils.rbac import get_user_clusters

    _ud = dict(user_data)
    _ud["username"] = user
    allowed = get_user_clusters(_ud)
    if is_admin or allowed is None:
        return jsonify(schedules.get("actions", []))

    filtered = [a for a in schedules.get("actions", []) if a.get("cluster_id") in allowed]
    return jsonify(filtered)


@bp.route("/api/schedules", methods=["POST"])
@require_auth()  # per-action permission checked below
def create_schedule():
    """Create a new scheduled action

    Body:
    - cluster_id: Cluster ID
    - vmid: VM ID
    - vm_type: 'qemu' or 'lxc'
    - action: 'start', 'stop', 'shutdown', 'reboot', 'snapshot'
    - schedule_type: 'once', 'daily', 'weekly', 'weekdays', 'weekends'
    - time: 'HH:MM' format
    - date: (for once) 'YYYY-MM-DD' format
    - days: (for weekly) ['monday', 'wednesday', 'friday']
    - name: Optional friendly name
    """
    data = request.json or {}

    required = ["cluster_id", "vmid", "action", "schedule_type", "time"]
    for field in required:
        if not data.get(field):
            # snyk:ignore:Cross-site Scripting (XSS)
            return jsonify({"error": f"{field} is required"}), 400

    # Verify tenant has access to this cluster
    ok, _ = check_cluster_access(data["cluster_id"])
    if not ok:
        return jsonify({"error": "Access denied to this cluster"}), 403

    # Validate time format
    time_str = data.get("time", "")
    try:
        datetime.strptime(time_str, "%H:%M")
    except ValueError:
        return jsonify({"error": "Time must be in HH:MM format"}), 400

    # Validate action
    valid_actions = ["start", "stop", "shutdown", "reboot", "snapshot"]
    if data["action"] not in valid_actions:
        # snyk:ignore:Cross-site Scripting (XSS)
        return jsonify({"error": f"Action must be one of: {valid_actions}"}), 400

    perm_err = _require_action_perm(data["action"])
    if perm_err:
        return perm_err

    # Validate schedule type
    valid_types = ["once", "daily", "weekly", "weekdays", "weekends"]
    if data["schedule_type"] not in valid_types:
        # snyk:ignore:Cross-site Scripting (XSS)
        return jsonify({"error": f"Schedule type must be one of: {valid_types}"}), 400

    # For 'once' type, require date
    if data["schedule_type"] == "once" and not data.get("date"):
        return jsonify({"error": "Date is required for one-time schedules"}), 400

    # For 'weekly' type, require days
    if data["schedule_type"] == "weekly" and not data.get("days"):
        return jsonify({"error": "Days are required for weekly schedules"}), 400

    schedules = load_schedules()

    # Generate new ID
    new_id = schedules.get("last_id", 0) + 1
    schedules["last_id"] = new_id

    # Create the schedule
    new_schedule = {
        "id": new_id,
        "cluster_id": data["cluster_id"],
        "vmid": int(data["vmid"]),
        "vm_type": data.get("vm_type", "qemu"),
        "action": data["action"],
        "schedule_type": data["schedule_type"],
        "time": time_str,
        "date": data.get("date"),
        "days": data.get("days", []),
        "name": data.get("name", f"{data['action']} VM {data['vmid']}"),
        "enabled": True,
        "created_by": getattr(request, "session", {}).get("user", "unknown"),
        "created_at": datetime.now().isoformat(),
        "run_count": 0,
    }

    if "actions" not in schedules:
        schedules["actions"] = []

    schedules["actions"].append(new_schedule)
    save_schedules(schedules)

    log_audit(
        getattr(request, "session", {}).get("user", "system"),
        "schedule.created",
        f"Created schedule '{new_schedule['name']}' for VM {data['vmid']}",
    )

    return jsonify({"success": True, "schedule": new_schedule})


@bp.route("/api/schedules/<int:schedule_id>", methods=["PUT"])
@require_auth()  # per-action permission checked below
def update_schedule(schedule_id):
    """Update a scheduled action"""
    data = request.json or {}
    schedules = load_schedules()

    # Find the schedule
    schedule = next((s for s in schedules.get("actions", []) if s.get("id") == schedule_id), None)
    if not schedule:
        return jsonify({"error": "Schedule not found"}), 404

    # Verify tenant has access to this schedule's cluster
    ok, _ = check_cluster_access(schedule.get("cluster_id", ""))
    if not ok:
        return jsonify({"error": "Access denied to this cluster"}), 403

    # Validate action if being updated
    if "action" in data:
        valid_actions = ["start", "stop", "shutdown", "reboot", "snapshot"]
        if data["action"] not in valid_actions:
            # snyk:ignore:Cross-site Scripting (XSS)
            return jsonify({"error": f"Action must be one of: {valid_actions}"}), 400

    # need the perm for the effective action — the new one if it's changing, else the
    # one already stored (so a no-action edit still can't be made without the right perm)
    perm_err = _require_action_perm(data.get("action", schedule.get("action", "start")))
    if perm_err:
        return perm_err

    # Validate time format if being updated
    if "time" in data:
        try:
            datetime.strptime(data["time"], "%H:%M")
        except ValueError:
            return jsonify({"error": "Time must be in HH:MM format"}), 400

    # Validate schedule type if being updated
    if "schedule_type" in data:
        valid_types = ["once", "daily", "weekly", "weekdays", "weekends"]
        if data["schedule_type"] not in valid_types:
            # snyk:ignore:Cross-site Scripting (XSS)
            return jsonify({"error": f"Schedule type must be one of: {valid_types}"}), 400

    # For 'once' type, require date
    schedule_type = data.get("schedule_type", schedule.get("schedule_type"))
    if schedule_type == "once" and "date" in data and not data.get("date"):
        return jsonify({"error": "Date is required for one-time schedules"}), 400

    # For 'weekly' type, require days
    if schedule_type == "weekly" and "days" in data and not data.get("days"):
        return jsonify({"error": "Days are required for weekly schedules"}), 400

    # Update fields (vmid/vm_type added Mar 2026 - #133)
    updatable = ["name", "vmid", "vm_type", "action", "schedule_type", "time", "date", "days", "enabled"]
    for field in updatable:
        if field in data:
            schedule[field] = data[field]

    save_schedules(schedules)

    log_audit(getattr(request, "session", {}).get("user", "system"), "schedule.updated", f"Updated schedule ID {schedule_id}")

    return jsonify({"success": True, "schedule": schedule})


@bp.route("/api/schedules/<int:schedule_id>", methods=["DELETE"])
@require_auth()  # per-action permission checked below
def delete_schedule(schedule_id):
    """Delete a scheduled action"""
    schedules = load_schedules()

    # verify tenant access before deleting
    schedule = next((s for s in schedules.get("actions", []) if s.get("id") == schedule_id), None)
    if not schedule:
        return jsonify({"error": "Schedule not found"}), 404
    ok, _ = check_cluster_access(schedule.get("cluster_id", ""))
    if not ok:
        return jsonify({"error": "Access denied to this cluster"}), 403

    perm_err = _require_action_perm(schedule.get("action", "start"))
    if perm_err:
        return perm_err

    # US075: soft-delete — the row stays for restore inside the retention
    # window; load_schedules' deleted_at filter hides it everywhere.
    try:
        get_db().soft_delete_row("scheduled_actions", "id", schedule_id)
    except Exception as e:
        logging.error(f"Failed to soft-delete schedule {schedule_id}: {e}")
        return jsonify({"error": "Failed to delete schedule"}), 500

    log_audit(getattr(request, "session", {}).get("user", "system"), "schedule.deleted", f"Deleted schedule ID {schedule_id}")

    return jsonify({"success": True})


@bp.route("/api/schedules/<int:schedule_id>/restore", methods=["POST"])
@require_auth()
def restore_schedule(schedule_id):
    """Restore a soft-deleted scheduled action (US075)."""
    db = get_db()
    cursor = db.conn.cursor()
    cursor.execute(
        "SELECT cluster_id, action FROM scheduled_actions WHERE id = ? AND deleted_at IS NOT NULL",
        (schedule_id,),
    )
    row = cursor.fetchone()
    if not row:
        return jsonify({"error": "Schedule not found in trash"}), 404
    ok, _ = check_cluster_access(row["cluster_id"] or "")
    if not ok:
        return jsonify({"error": "Access denied to this cluster"}), 403
    perm_err = _require_action_perm(row["action"] or "start")
    if perm_err:
        return perm_err

    db.restore_row("scheduled_actions", "id", schedule_id)
    log_audit(
        getattr(request, "session", {}).get("user", "system"),
        "schedule.restored",
        f"Restored schedule ID {schedule_id}",
    )
    return jsonify({"success": True})


# ============================================

# ============================================
# Scheduled Updates API
# Automatic rolling update scheduling (SQLite storage)
# ============================================


def load_update_schedule(cluster_id: str) -> dict:
    """Load update schedule for a cluster from SQLite"""
    default = {
        "enabled": False,
        "schedule_type": "recurring",
        "day": "sunday",
        "time": "03:00",
        "include_reboot": True,
        "skip_evacuation": False,
        "skip_up_to_date": True,
        "evacuation_timeout": 1800,
        "last_run": None,
        "next_run": None,
    }
    try:
        db = get_db()
        cursor = db.conn.cursor()

        # Ensure table exists (migration for existing databases)
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS update_schedules (
                cluster_id TEXT PRIMARY KEY,
                enabled INTEGER DEFAULT 0,
                schedule_type TEXT DEFAULT 'recurring',
                day TEXT DEFAULT 'sunday',
                time TEXT DEFAULT '03:00',
                include_reboot INTEGER DEFAULT 1,
                skip_evacuation INTEGER DEFAULT 0,
                skip_up_to_date INTEGER DEFAULT 1,
                evacuation_timeout INTEGER DEFAULT 1800,
                last_run TEXT,
                next_run TEXT,
                created_by TEXT,
                created_at TEXT,
                updated_at TEXT
            )
        """)

        cursor.execute("SELECT * FROM update_schedules WHERE cluster_id = ?", (cluster_id,))
        row = cursor.fetchone()
        if row:
            return {
                "enabled": bool(row["enabled"]),
                "schedule_type": row["schedule_type"] or "recurring",
                "day": row["day"] or "sunday",
                "time": row["time"] or "03:00",
                "include_reboot": bool(row["include_reboot"]),
                "skip_evacuation": bool(row["skip_evacuation"]),
                "skip_up_to_date": bool(row["skip_up_to_date"]),
                "evacuation_timeout": row["evacuation_timeout"] or 1800,
                "last_run": row["last_run"],
                "next_run": row["next_run"],
            }
    except Exception as e:
        logging.error(f"Error loading update schedule: {e}")
    return default


def save_update_schedule(cluster_id: str, schedule: dict, user: str = "system"):
    """Save update schedule for a cluster to SQLite"""
    try:
        db = get_db()
        cursor = db.conn.cursor()
        now = datetime.now().isoformat()

        # Use INSERT OR REPLACE for older SQLite compatibility
        cursor.execute(
            """
            INSERT OR REPLACE INTO update_schedules
            (cluster_id, enabled, schedule_type, day, time, include_reboot, skip_evacuation,
             skip_up_to_date, evacuation_timeout, last_run, next_run, created_by, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
            (
                cluster_id,
                1 if schedule.get("enabled") else 0,
                schedule.get("schedule_type", "recurring"),
                schedule.get("day", "sunday"),
                schedule.get("time", "03:00"),
                1 if schedule.get("include_reboot", True) else 0,
                1 if schedule.get("skip_evacuation", False) else 0,
                1 if schedule.get("skip_up_to_date", True) else 0,
                schedule.get("evacuation_timeout", 1800),
                schedule.get("last_run"),
                schedule.get("next_run"),
                user,
                now,
                now,
            ),
        )
        db.conn.commit()
    except Exception as e:
        logging.error(f"Error saving update schedule: {e}")


def update_schedule_last_run(cluster_id: str, last_run: str, next_run: str | None):
    """Update last_run and next_run for a schedule"""
    try:
        db = get_db()
        cursor = db.conn.cursor()
        cursor.execute(
            """
            UPDATE update_schedules SET last_run = ?, next_run = ?, updated_at = ?
            WHERE cluster_id = ?
        """,
            (last_run, next_run, datetime.now().isoformat(), cluster_id),
        )
        db.conn.commit()
    except Exception as e:
        logging.error(f"Error updating schedule last_run: {e}")


def load_all_update_schedules() -> dict:
    """Load all enabled update schedules from SQLite"""
    schedules = {}
    try:
        db = get_db()
        cursor = db.conn.cursor()
        cursor.execute("SELECT * FROM update_schedules WHERE enabled = 1")
        for row in cursor.fetchall():
            schedules[row["cluster_id"]] = {
                "enabled": bool(row["enabled"]),
                "schedule_type": row["schedule_type"] or "recurring",
                "day": row["day"] or "sunday",
                "time": row["time"] or "03:00",
                "include_reboot": bool(row["include_reboot"]),
                "skip_evacuation": bool(row["skip_evacuation"]),
                "skip_up_to_date": bool(row["skip_up_to_date"]),
                "evacuation_timeout": row["evacuation_timeout"] or 1800,
                "last_run": row["last_run"],
                "next_run": row["next_run"],
            }
    except Exception as e:
        logging.error(f"Error loading all update schedules: {e}")
    return schedules


@bp.route("/api/clusters/<cluster_id>/updates/schedule", methods=["GET"])
@require_auth(perms=["cluster.view"])
def get_update_schedule(cluster_id):
    """Get the scheduled update configuration for a cluster"""
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied to this cluster"}), 403

    schedule = load_update_schedule(cluster_id)
    return jsonify(schedule)


@bp.route("/api/clusters/<cluster_id>/updates/schedule", methods=["POST"])
@require_auth(perms=["backup.schedule"])
def set_update_schedule(cluster_id):
    """Set the scheduled update configuration for a cluster"""
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied to this cluster"}), 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    data = request.json or {}
    usr = getattr(request, "session", {}).get("user", "system")

    schedule: dict = {
        "enabled": data.get("enabled", False),
        "schedule_type": data.get("schedule_type", "recurring"),
        "day": data.get("day", "sunday"),
        "time": data.get("time", "03:00"),
        "include_reboot": data.get("include_reboot", True),
        "skip_evacuation": data.get("skip_evacuation", False),
        "skip_up_to_date": data.get("skip_up_to_date", True),
        "evacuation_timeout": data.get("evacuation_timeout", 1800),
        "wait_for_reboot": data.get("wait_for_reboot", True),
        "last_run": None,
        "next_run": None,
    }

    # Calculate next run time
    if schedule["enabled"]:
        schedule["next_run"] = calculate_next_update_run(schedule["day"], schedule["time"])

    save_update_schedule(cluster_id, schedule, usr)

    # Log audit
    mgr = cluster_managers[cluster_id]
    log_audit(
        usr,
        "update.schedule",
        f"Update schedule {'enabled' if schedule['enabled'] else 'disabled'} for {mgr.config.name}",
        cluster=mgr.config.name,
    )

    return jsonify({"success": True, "schedule": schedule})


@bp.route("/api/clusters/<cluster_id>/updates/schedule", methods=["DELETE"])
@require_auth(perms=["backup.schedule"])
def delete_update_schedule(cluster_id):
    """Delete/disable the scheduled update for a cluster"""
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied to this cluster"}), 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    try:
        db = get_db()
        cursor = db.conn.cursor()
        cursor.execute("DELETE FROM update_schedules WHERE cluster_id = ?", (cluster_id,))
        db.conn.commit()

        usr = getattr(request, "session", {}).get("user", "system")
        mgr = cluster_managers[cluster_id]
        log_audit(
            usr, "update.schedule.deleted", f"Update schedule deleted for {mgr.config.name}", cluster=mgr.config.name
        )

        return jsonify({"success": True})
    except Exception as e:
        _ = safe_error(e, "Schedule operation failed")
        return jsonify({"error": "Schedule operation failed"}), 500


def calculate_next_update_run(day: str, time_str: str) -> str:
    """Calculate the next scheduled run time"""
    try:
        now = datetime.now()
        hour, minute = map(int, time_str.split(":"))

        day_map = {
            "monday": 0,
            "tuesday": 1,
            "wednesday": 2,
            "thursday": 3,
            "friday": 4,
            "saturday": 5,
            "sunday": 6,
            "daily": -1,
        }

        target_day = day_map.get(day.lower(), -1)

        if target_day == -1:  # Daily
            next_run = now.replace(hour=hour, minute=minute, second=0, microsecond=0)
            if next_run <= now:
                next_run += timedelta(days=1)
        else:
            days_ahead = target_day - now.weekday()
            if days_ahead < 0:
                days_ahead += 7
            next_run = now + timedelta(days=days_ahead)
            next_run = next_run.replace(hour=hour, minute=minute, second=0, microsecond=0)
            if next_run <= now:
                next_run += timedelta(days=7)

        return next_run.strftime("%Y-%m-%d %H:%M:%S")
    except Exception as e:
        logging.error(f"Error calculating next run: {e}")
        return ""


def check_scheduled_updates():
    """Check if any scheduled updates should run - called by scheduler"""
    try:
        schedules = load_all_update_schedules()
        now = datetime.now()

        for cluster_id, schedule in schedules.items():
            if not schedule.get("enabled"):
                continue

            if cluster_id not in cluster_managers:
                continue

            mgr = cluster_managers[cluster_id]
            if not mgr.is_connected:
                continue

            # Check schedule_type - 'once' schedules that already ran should be skipped
            schedule_type = schedule.get("schedule_type", "recurring")
            if schedule_type == "once" and schedule.get("last_run"):
                continue

            # Check if it's time to run
            day = schedule.get("day", "sunday")
            time_str = schedule.get("time", "03:00")

            try:
                hour, minute = map(int, time_str.split(":"))
            except Exception:
                # malformed time in DB = schedule never fires — log once per pass
                logging.warning(f"[SCHEDULER] bad time format {time_str!r} for update schedule on {cluster_id}")
                continue

            day_map = {
                "monday": 0,
                "tuesday": 1,
                "wednesday": 2,
                "thursday": 3,
                "friday": 4,
                "saturday": 5,
                "sunday": 6,
            }

            is_correct_day = day == "daily" or now.weekday() == day_map.get(day.lower(), -1)
            is_correct_time = now.hour == hour and now.minute == minute

            if is_correct_day and is_correct_time:
                # Check if already ran today (for recurring)
                if schedule_type == "recurring":
                    last_run = schedule.get("last_run")
                    if last_run:
                        try:
                            last_run_date = datetime.fromisoformat(last_run).date()
                            if last_run_date == now.date():
                                continue  # Already ran today
                        except Exception as e:
                            # unparseable last_run falls through to "run" — that
                            # can duplicate a rolling update, so log it
                            logging.warning(f"[SCHEDULER] unparseable last_run {last_run!r} on {cluster_id}: {e}")

                # Check if rolling update already running
                if (
                    hasattr(mgr, "_rolling_update")
                    and mgr._rolling_update
                    and mgr._rolling_update.get("status") == "running"
                ):
                    continue

                logging.info(f"[SCHEDULER] Starting scheduled update for cluster {cluster_id} (type: {schedule_type})")

                # Execute the scheduled rolling update
                action = {
                    "cluster_id": cluster_id,
                    "action": "rolling_update",
                    "config": {
                        "include_reboot": schedule.get("include_reboot", True),
                        "skip_evacuation": schedule.get("skip_evacuation", False),
                        "skip_up_to_date": schedule.get("skip_up_to_date", True),
                        "evacuation_timeout": schedule.get("evacuation_timeout", 1800),
                    },
                }

                execute_scheduled_rolling_update(mgr, cluster_id, action)

                # Update last run time
                last_run_str = now.isoformat()
                next_run_str = calculate_next_update_run(day, time_str) if schedule_type == "recurring" else None
                update_schedule_last_run(cluster_id, last_run_str, next_run_str)

                # Disable 'once' schedules after running
                if schedule_type == "once":
                    schedule["enabled"] = False
                    schedule["last_run"] = last_run_str
                    save_update_schedule(cluster_id, schedule)
                    logging.info(f"[SCHEDULER] One-time schedule disabled for {cluster_id}")

    except Exception as e:
        logging.error(f"Error checking scheduled updates: {e}")
