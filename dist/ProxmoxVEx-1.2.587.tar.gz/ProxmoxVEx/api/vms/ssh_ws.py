# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/api/vms/ssh_ws.py
# Project:     ProxmoxVEx
# Version:     1.2.565
# Build:       2026.09.30
# Description: Standalone SSH websocket server launcher (split from
#              api/vms.py).
# Usage:       import ProxmoxVEx.api.vms.ssh_ws
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-30
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Standalone SSH websocket server launcher (split from api/vms.py)."""

import logging
import sys


def start_ssh_websocket_server(port=5002, ssl_cert=None, ssl_key=None, host="127.0.0.1"):
    """Start a dedicated WebSocket server for SSH terminal proxying

    runs as separate process to avoid gevent/asyncio conflicts.
    Gevent monkey-patches asyncio which breaks the websockets library.
    By using a subprocess, we get a clean Python interpreter.
    """
    import os
    import subprocess

    # Create a standalone script that runs the SSH WebSocket server
    server_script = '''#!/usr/bin/env python3
"""Standalone SSH WebSocket Server - runs without gevent"""
import asyncio
import contextlib
import json
import logging
import os
import re
import ssl
import sys
import threading
import warnings
from urllib.parse import parse_qs, quote_plus, unquote, urlparse

warnings.filterwarnings('ignore')

PORT = int(os.environ.get('PROXMOXVEX_SSH_WS_PORT') or os.environ.get('SSH_WS_PORT', '5002'))
BIND_HOST = os.environ.get('PROXMOXVEX_SSH_WS_HOST') or os.environ.get('SSH_WS_HOST', '127.0.0.1')
SSL_CERT = os.environ.get('PROXMOXVEX_SSH_WS_SSL_CERT') or os.environ.get('SSH_WS_SSL_CERT', '')
SSL_KEY = os.environ.get('PROXMOXVEX_SSH_WS_SSL_KEY') or os.environ.get('SSH_WS_SSL_KEY', '')
# The standalone subprocess does not import vms.py; it needs its own copy of this constant.
_WS_FALLBACK_HOST = os.environ.get('PROXMOXVEX_WS_FALLBACK_HOST', '0.0.0.0')
ProxmoxVEx_URL = os.environ.get('PROXMOXVEX_URL') or 'http://127.0.0.1:5000'

# TLS verification for outbound ProxmoxVEx API calls.
# Defaults to True (verify). Set PROXMOXVEX_VERIFY_SSL=0 to disable explicitly.
VERIFY_SSL = os.environ.get('PROXMOXVEX_VERIFY_SSL', '1').strip().lower() not in ('0', 'false', 'no', 'off')

try:
    import paramiko
    import requests
    import urllib3
    import websockets
    from requests.adapters import HTTPAdapter
    urllib3.disable_warnings()
except ImportError as e:
    logging.info(f"Missing library: {e}")
    sys.exit(1)


def apply_ssh_host_key_policy(client, known_hosts_path=None):
    """Trust-on-first-use host key policy with persistent known_hosts storage.

    Mirrors ProxmoxVEx.utils.ssh.apply_ssh_host_key_policy so this standalone
    server can run without importing the full package.
    """
    path = known_hosts_path or os.path.join(
        os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))),
        'config',
        '.ssh_known_hosts',
    )

    class _PersistentTOFUPolicy:
        def missing_host_key(self, client, hostname, key):
            with contextlib.suppress(Exception):
                client.get_host_keys().add(hostname, key.get_name(), key)
                os.makedirs(os.path.dirname(path), exist_ok=True)
                client.save_host_keys(path)
                os.chmod(path, 0o600)

    if os.path.exists(path):
        with contextlib.suppress(Exception):
            client.load_host_keys(path)
    client.set_missing_host_key_policy(_PersistentTOFUPolicy())


# Mirrors ProxmoxVEx.services.session_for — pooled keep-alive sessions so the
# internal validate/cluster-creds calls reuse connections instead of paying a
# fresh TCP(+TLS) handshake per request. Local copy: this standalone subprocess
# intentionally runs without importing the package.
_sessions = {}
_sessions_lock = threading.Lock()


def session_for(key):
    s = _sessions.get(key)
    if s is None:
        with _sessions_lock:
            s = _sessions.get(key)
            if s is None:
                s = requests.Session()
                adapter = HTTPAdapter(
                    pool_connections=4, pool_maxsize=8, max_retries=1, pool_block=False
                )
                s.mount("https://", adapter)
                s.mount("http://", adapter)
                s.headers.update({"Connection": "keep-alive"})
                _sessions[key] = s
    return s


async def ssh_handler(websocket):
    """SSH WebSocket handler with user credential prompt and SSH key support

    Supports both password and SSH key authentication
    Frontend can pre-fetch the IP and pass it as query parameter
    """
    path = websocket.request.path if hasattr(websocket, 'request') else websocket.path
    logging.info(f"SSH WebSocket connection: {path}")
    parsed = urlparse(path)
    query = parse_qs(parsed.query)
    ws_token = query.get('token', [None])[0]
    session_id = query.get('session', [None])[0]  # Backwards compat
    prefetched_ip = query.get('ip', [None])[0]  # IP pre-fetched by frontend
    if prefetched_ip:
        prefetched_ip = unquote(prefetched_ip)
        # (CodeAnt CWE-117) - prefetched_ip is unquoted user input; strip CR/LF so
        # it can't forge log lines (self-contained: this runs in the standalone WS subprocess).
        logging.info("Frontend provided IP: " + str(prefetched_ip).replace(chr(10), ' ').replace(chr(13), ' '))
    # Accept both shell and termproxy paths.
    # termproxy: /api/clusters/<cid>/vms/<node>/<vm_type>/<vmid>/termwebsocket
    #            with ?ticket=, ?port=, ?user=, ?host= from the frontend.
    m_term = re.match(r'/api/clusters/([^/]+)/vms/([^/]+)/(qemu|lxc)/([0-9]+)/termwebsocket', parsed.path)
    if m_term:
        await termproxy_handler(websocket, query, m_term, ws_token, session_id)
        return

    # Match both /shell and /shellws
    match = re.match(r'/api/clusters/([^/]+)/nodes/([^/]+)/shell(?:ws)?', parsed.path)
    if not match:
        logging.error(f"Invalid path: {parsed.path}")
        await websocket.send('{"status":"error","message":"Invalid path"}')
        await websocket.close(1008, "Invalid path")
        return

    cluster_id, node = match.groups()
    logging.info(f"Cluster: {cluster_id}, Node: {node}")
    # Prefer WS token auth (single-use, doesn't leak session)
    auth_token = ws_token or session_id
    if not auth_token:
        logging.info("No token or session provided")
        await websocket.send('{"status":"error","message":"No auth token provided"}')
        await websocket.close(1008, "No auth")
        return

    # Validate via main server. When called with ws_token + cluster_id,
    # the response now also carries `cluster_context` (host/node_ips/ssh_port) so we
    # don't need a second authenticated round-trip. The WS subprocess holds only the
    # consumed ws-token, no session cookie, so cluster-creds was previously
    # unreachable from here.
    node_ip = None
    cluster_host = None
    cluster_port = None
    node_ips = {}
    try:
        if ws_token:
            validate_url = (
                f"{ProxmoxVEx_URL}/api/ws/token/validate"
                f"?token={ws_token}&cluster_id={quote_plus(cluster_id)}&node={quote_plus(node)}"
            )
            logging.info(f"Validating WS token (cluster={cluster_id}, node={node})...")
        else:
            validate_url = f"{ProxmoxVEx_URL}/api/auth/validate"
            logging.info("Validating session (legacy)...")
        headers = {'X-Session-ID': session_id} if session_id else {}
        cookies = {'session': session_id} if session_id else {}
        # nosec B501 — localhost-to-ProxmoxVEx (ProxmoxVEx_URL = 127.0.0.1:port) with our
        # own self-signed cert. Same-host trust boundary; attacker with local
        # cert-read access already has more direct attack paths. 2026-06-04.
        r = session_for("internal-api").get(validate_url, cookies=cookies, headers=headers, timeout=8, verify=VERIFY_SSL)

        if r.status_code == 403:
            logging.error(f"Auth failed: 403 (no access to cluster {cluster_id})")
            await websocket.send(json.dumps({'status': 'error', 'message': f'No access to cluster {cluster_id}'}))
            await websocket.close(1008, "Forbidden")
            return
        if r.status_code != 200:
            logging.error(f"Auth failed: {r.status_code}")
            await websocket.send('{"status":"error","message":"Session ungültig - bitte neu einloggen"}')
            await websocket.close(1008, "Invalid auth")
            return

        # Pull the cluster context out of the validate response (ws-token path only)
        if ws_token:
            try:
                payload = r.json() or {}
                ctx = payload.get('cluster_context') or {}
                cluster_host = ctx.get('host')
                cluster_port = ctx.get('port')
                node_ips = ctx.get('node_ips') or {}
                node_ip = node_ips.get(node) or node_ips.get(node.lower())
                logging.info(f"validate→ host={cluster_host} node_ips={node_ips} resolved_node_ip={node_ip}")
            except Exception as e:
                logging.info(f"Could not parse validate payload: {e}")
        # Legacy session path: fall back to cluster-creds with the session cookie.
        if not ws_token and session_id:
            try:
                logging.info(f"Fetching cluster creds from: {ProxmoxVEx_URL}/api/internal/cluster-creds/{cluster_id}")
                # nosec B501 — same-host ProxmoxVEx self-signed cert, see 2026-06-04 audit
                rc = session_for("internal-api").get(f"{ProxmoxVEx_URL}/api/internal/cluster-creds/{cluster_id}",
                                  cookies={'session': session_id}, timeout=10, verify=VERIFY_SSL)
                if rc.status_code == 200:
                    creds = rc.json()
                    cluster_host = creds.get('host')
                    cluster_port = creds.get('port')
                    node_ips = creds.get('node_ips', {})
                    node_ip = node_ips.get(node) or node_ips.get(node.lower())
            except Exception as e:
                logging.info(f"Could not get node IP from API: {e}")
        logging.info("Auth successful")
    except requests.exceptions.ConnectionError as e:
        logging.error(f"Connection error to main server: {e}")
        # Never skip auth, even if main server is unreachable
        await websocket.send('{"status":"error","message":"Authentifizierung fehlgeschlagen - Server nicht erreichbar"}')
        await websocket.close(1011, "Auth server unreachable")
        return
    except Exception as e:
        logging.error(f"Auth error: {e}")
        await websocket.send('{"status":"error","message":"Authentifizierungsfehler"}')
        await websocket.close(1011, "Auth error")
        return

    # cluster_host fallback for node_ip (single-node setups where only the host
    # was registered).
    if not node_ip and cluster_host:
        node_ip = cluster_host
        logging.info(f"Using cluster host as fallback: {cluster_host}")
    if not cluster_port:
        cluster_port = 8006
    # (CodeAnt CWE-918) - build the SSH allow-list. prefetched_ip from
    # URL and user-supplied creds.host below must both be in this set; otherwise
    # an authenticated user could turn ProxmoxVEx into an SSH jump host for any
    # internal IP. Set comes from server-side resolution only.
    allowed_hosts = set()
    if cluster_host:
        allowed_hosts.add(cluster_host)
    allowed_hosts.update(v for v in (node_ips or {}).values() if v)

    if prefetched_ip:
        if prefetched_ip in allowed_hosts:
            node_ip = prefetched_ip
            logging.info(f"Using prefetched IP (allow-list match): {node_ip}")
        else:
            logging.info(f"REJECT prefetched ?ip={prefetched_ip!r} not in {sorted(allowed_hosts)}")
            await websocket.send(json.dumps({
                'status': 'error',
                'message': f"Prefetched IP {prefetched_ip!r} is not a known node of cluster {cluster_id}."
            }))
            await websocket.close(1008, "prefetched ip not allowed")
            return

    # If we still don't have an IP, allow manual entry (but allow-list still applies)
    allow_manual_ip = False
    if not node_ip:
        logging.info("No IP found - allowing manual entry")
        node_ip = ""  # Empty - user must provide
        allow_manual_ip = True

    logging.info(f"Final node IP for {node}: {node_ip or '(manual entry required)'}")
    logging.info(f"Allow-list for host override: {sorted(allowed_hosts) or '(empty - no manual override permitted)'}")
    # Send need_credentials status - frontend will show login dialog
    await websocket.send(json.dumps({
        'status': 'need_credentials',
        'node': node,
        'ip': node_ip,
        'allowManualIp': allow_manual_ip
    }))

    # Wait for credentials from user
    try:
        creds_msg = await asyncio.wait_for(websocket.recv(), timeout=300)
        creds = json.loads(creds_msg)
        ssh_user = creds.get('username', 'root')
        ssh_pass = creds.get('password', '')
        ssh_key = creds.get('privateKey', '')

        # (CodeAnt CWE-918) - host override is gated by allow_hosts.
        # Empty set rejects all overrides (no-resolved-cluster case).
        user_ip = creds.get('host', '').strip()
        if user_ip:
            if user_ip not in allowed_hosts:
                logging.info(f"REJECT user host override: {user_ip!r} not in {sorted(allowed_hosts)}")
                await websocket.send(json.dumps({
                    'status': 'error',
                    'message': f"Host {user_ip!r} is not a known node of cluster {cluster_id}. Manual override blocked."
                }))
                await websocket.close(1008, "host not allowed")
                return
            node_ip = user_ip
            logging.info(f"Using user-provided IP (allow-list match): {node_ip}")
        if not node_ip:
            await websocket.send('{"status":"error","message":"Host/IP address required"}')
            return

        if not ssh_pass and not ssh_key:
            await websocket.send('{"status":"error","message":"Password or SSH key required"}')
            return

    except asyncio.TimeoutError:
        await websocket.send('{"status":"error","message":"Login timeout"}')
        await websocket.close(1008, "Timeout")
        return
    except Exception as e:
        logging.error(f"Credentials receive error: {e}")
        await websocket.send('{"status":"error","message":"Failed to receive credentials"}')
        return

    # Send connecting status
    await websocket.send('{"status":"connecting"}')

    # Connect SSH
    ssh = paramiko.SSHClient()
    apply_ssh_host_key_policy(ssh)

    try:
        logging.info(f"Connecting SSH to {ssh_user}@{node_ip}...")
        # Try SSH key authentication first if provided
        if ssh_key:
            try:
                import io
                # Parse the private key
                key_file = io.StringIO(ssh_key)

                # Try different key types
                pkey = None
                for key_class in [paramiko.RSAKey, paramiko.Ed25519Key, paramiko.ECDSAKey, getattr(paramiko, 'DSSKey', None)]:
                    if key_class is None:
                        continue
                    try:
                        key_file.seek(0)
                        pkey = key_class.from_private_key(key_file, password=ssh_pass if ssh_pass else None)
                        break
                    except Exception as _e:
                        continue

                if pkey:
                    logging.info("Using SSH key authentication")
                    ssh.connect(node_ip, port=22, username=ssh_user, pkey=pkey, timeout=10, look_for_keys=False, allow_agent=False)
                else:
                    raise Exception("Could not parse SSH key - unsupported format")

            except Exception as key_error:
                logging.error(f"SSH key auth failed: {key_error}")
                await websocket.send(f'{{"status":"error","message":"SSH key error: {str(key_error)}"}}')
                return
        else:
            # Password authentication
            ssh.connect(node_ip, port=22, username=ssh_user, password=ssh_pass, timeout=10, look_for_keys=False, allow_agent=False)

        channel = ssh.invoke_shell(term='xterm-256color', width=120, height=40)
        channel.settimeout(0.1)

        logging.info(f"SSH connected: {cluster_id}/{node}")
        # Send connected status - frontend will clear terminal
        await websocket.send('{"status":"connected"}')

        async def ssh_to_ws():
            while True:
                try:
                    if channel.recv_ready():
                        data = channel.recv(4096)
                        if data:
                            await websocket.send(data.decode('utf-8', errors='replace'))
                    await asyncio.sleep(0.01)
                except Exception as _e:
                    break

        async def ws_to_ssh():
            with contextlib.suppress(Exception):
                async for message in websocket:
                    if isinstance(message, str):
                        if message.startswith('{"type":"resize"'):
                            with contextlib.suppress(Exception):
                                data = json.loads(message)
                                if data.get('type') == 'resize':
                                    channel.resize_pty(width=data.get('cols', 120), height=data.get('rows', 40))
                        elif message.startswith('{'):
                            # Ignore other JSON messages (like old credential format)
                            pass
                        else:
                            channel.send(message.encode())
                    else:
                        channel.send(message)

        await asyncio.gather(ssh_to_ws(), ws_to_ssh(), return_exceptions=True)
    except paramiko.AuthenticationException as e:
        logging.error(f"SSH auth failed: {e}")
        await websocket.send('\\r\\n\\x1b[31mSSH Authentication Failed\\x1b[0m\\r\\nCheck cluster credentials.\\r\\n')
    except Exception as e:
        logging.error(f"SSH error: {e}")
        with contextlib.suppress(Exception):
            await websocket.send(f"\\r\\n\\x1b[31mSSH Error: {e}\\x1b[0m\\r\\n")
    finally:
        with contextlib.suppress(Exception):
            ssh.close()
        logging.info(f"SSH disconnected: {cluster_id}/{node}")
# Proxmox termproxy proxy.
# Frontend has already POSTed /termproxy on the main app and got a ticket.
# It sends the ticket+port+host+user as query params on the WS open.
# We connect to PVE's vncwebsocket with that ticket, send the
# `user:ticket\\n` handshake, wait for "OK", then proxy bytes both ways.
# No SSH, no second login — the cluster auth happens server-side at the
# /termproxy POST step.
async def termproxy_handler(client_ws, query, m_term, ws_token, session_id):
    cluster_id, node, vm_type, vmid_str = m_term.groups()
    logging.info(f"[TERMPROXY] {vm_type}/{vmid_str} on {node} cluster={cluster_id}")
    auth_token = ws_token or session_id
    if not auth_token:
        await client_ws.send('{"status":"error","message":"No auth token"}')
        await client_ws.close(1008, "No auth")
        return

    # Validate via main server (cluster-scope check + inline cluster context)
    # Response carries cluster_context so we don't need a second
    # authenticated round-trip from the WS subprocess.
    validate_payload = {}
    try:
        if ws_token:
            validate_url = (
                f"{ProxmoxVEx_URL}/api/ws/token/validate"
                f"?token={ws_token}&cluster_id={quote_plus(cluster_id)}&node={quote_plus(node)}"
            )
        else:
            validate_url = f"{ProxmoxVEx_URL}/api/auth/validate"
        headers = {'X-Session-ID': session_id} if session_id else {}
        cookies = {'session': session_id} if session_id else {}
        # nosec B501 — localhost-to-ProxmoxVEx (ProxmoxVEx_URL = 127.0.0.1:port) with our
        # own self-signed cert. Same-host trust boundary; attacker with local
        # cert-read access already has more direct attack paths. 2026-06-04.
        r = session_for("internal-api").get(validate_url, cookies=cookies, headers=headers, timeout=8, verify=VERIFY_SSL)
        if r.status_code == 403:
            await client_ws.send(json.dumps({'status': 'error', 'message': f'No access to cluster {cluster_id}'}))
            await client_ws.close(1008, "Forbidden")
            return
        if r.status_code != 200:
            await client_ws.send('{"status":"error","message":"Invalid session"}')
            await client_ws.close(1008, "auth")
            return
        try:
            validate_payload = r.json() or {}
        except Exception as _e:
            validate_payload = {}
    except Exception as e:
        logging.error(f"[TERMPROXY] auth validate failed: {e}")
        await client_ws.send('{"status":"error","message":"Auth server unreachable"}')
        await client_ws.close(1011, "auth")
        return

    # Frontend gave us the termproxy ticket+port already (via POST /termproxy).
    # 2026-06-05 (security audit C-1): the PVE session cookie (auth_ticket =
    # PVEAuthCookie, effectively root on pve:8006) is NO LONGER taken from the
    # browser query — we resolve it server-side below from the validate /
    # cluster-creds cluster_context.
    pve_ticket = query.get('ticket', [None])[0]
    pve_port = query.get('port', [None])[0]
    pve_host = query.get('host', [None])[0]
    pve_user = query.get('user', [None])[0]
    pve_auth = None  # resolved server-side from cluster_context, see below
    if not (pve_ticket and pve_port and pve_host and pve_user):
        logging.info(f"[TERMPROXY] missing query params; got: ticket={bool(pve_ticket)} port={pve_port} host={pve_host} user={pve_user}")
        await client_ws.send('{"status":"error","message":"Missing termproxy params"}')
        await client_ws.close(1008, "params")
        return

    pve_ticket = unquote(pve_ticket)
    pve_user = unquote(pve_user)
    pve_host = unquote(pve_host)

    # (CodeAnt CWE-918) - SSRF gate. Use the cluster_context already
    # returned by the validate call; fall back to cluster-creds only on the legacy
    # session-cookie path (ws-token flow has no session cookie to authenticate it).
    allowed_hosts = set()
    ctx = (validate_payload or {}).get('cluster_context') or {}
    if ctx.get('host'):
        allowed_hosts.add(ctx['host'])
    allowed_hosts.update(v for v in (ctx.get('node_ips') or {}).values() if v)
    # C-1: server-side PVE session cookie (ws-token flow)
    if ctx.get('pve_auth_ticket'):
        pve_auth = ctx['pve_auth_ticket']
    # 2026-06-04: pull per-cluster ssl_verify out of the same context for
    # the PVE wss-proxy below. Defaults to False because PVE ships self-signed
    # certs and most labs run them. Admins toggle on once they've installed
    # a real cert + the cluster's `ssl_verify` config field is true.
    verify_pve_tls = bool(ctx.get('verify_pve_tls', False))
    if not allowed_hosts and session_id:
        try:
            cr = session_for("internal-api").get(f"{ProxmoxVEx_URL}/api/internal/cluster-creds/{cluster_id}",
                              cookies={'session': session_id}, timeout=10, verify=VERIFY_SSL)  # nosec B501 — localhost-to-ProxmoxVEx self-signed cert; same-host trust boundary, see 2026-06-04 audit
            if cr.status_code == 200:
                cr_data = cr.json() or {}
                if cr_data.get('host'):
                    allowed_hosts.add(cr_data['host'])
                allowed_hosts.update(v for v in (cr_data.get('node_ips') or {}).values() if v)
                # Honour the cluster-side ssl_verify flag from the creds payload.
                if 'verify_pve_tls' in cr_data:
                    verify_pve_tls = bool(cr_data['verify_pve_tls'])
                # C-1: server-side PVE session cookie (session-cookie flow)
                if cr_data.get('pve_auth_ticket'):
                    pve_auth = cr_data['pve_auth_ticket']
            else:
                logging.info(f"[TERMPROXY] cluster-creds non-200 ({cr.status_code}); allow-list empty")
        except Exception as e:
            logging.error(f"[TERMPROXY] cluster-creds legacy fetch failed: {e}")
    if pve_host not in allowed_hosts:
        logging.info(f"[TERMPROXY] REJECT host {pve_host!r} (not in {sorted(allowed_hosts)})")
        await client_ws.send(json.dumps({
            'status': 'error',
            'message': f"Host {pve_host!r} is not a known node of cluster {cluster_id}."
        }))
        await client_ws.close(1008, "host not allowed")
        return

    # C-1: the PVE session cookie must have come from the server-side
    # cluster_context (not the browser). If it's missing the cluster has no
    # password auth (termproxy can't work) or the mint failed — fail closed.
    if not pve_auth:
        logging.info(f"[TERMPROXY] no server-side PVE auth ticket for cluster {cluster_id}")
        await client_ws.send('{"status":"error","message":"Console auth unavailable for this cluster (needs user/password auth)"}')
        await client_ws.close(1011, "no-pve-auth")
        return

    # Connect to PVE WS — Cookie uses session auth ticket; URL uses termproxy ticket.
    pve_path = f"/api2/json/nodes/{node}/{vm_type}/{vmid_str}/vncwebsocket?port={pve_port}&vncticket={quote_plus(pve_ticket)}"
    pve_url = f"wss://{pve_host}:8006{pve_path}"
    # (CodeAnt sensitive-data-in-url) - never log the vncticket (a live PVE console
    # credential in the query string); redact it (self-contained: runs in the WS subprocess).
    logging.info("[TERMPROXY] connecting to PVE: " + pve_url.split('vncticket=')[0] + "vncticket=[REDACTED]")
    # 2026-06-04: TLS verify is gated by the per-cluster ssl_verify flag
    # (exposed via /api/internal/cluster-creds as `verify_pve_tls`). Default
    # is False because PVE ships self-signed certs by default; admins flip
    # it on once they have a real cert + uploaded the CA. Hard-disabling
    # check_hostname + verify_mode used to be unconditional — now it's the
    # opt-out path with a logged warning so cert posture is observable.
    pve_ssl = ssl.create_default_context()
    if not verify_pve_tls:
        pve_ssl.check_hostname = False
        pve_ssl.verify_mode = ssl.CERT_NONE
        logging.info(f"[TERMPROXY] TLS verify DISABLED for PVE host {pve_host!r} (cluster ssl_verify=false)")
    try:
        pve_ws = await websockets.connect(
            pve_url,
            additional_headers={'Cookie': f'PVEAuthCookie={pve_auth}'},
            ssl=pve_ssl,
            open_timeout=10,
        )
    except Exception as e:
        logging.error(f"[TERMPROXY] PVE WS connect failed: {type(e).__name__}: {e}")
        await client_ws.send(f'{{"status":"error","message":"PVE WS connect failed: {type(e).__name__}"}}')
        await client_ws.close(1011, "pve")
        return

    # Send PVE auth handshake: user:ticket\\n
    try:
        await pve_ws.send(f"{pve_user}:{pve_ticket}\\n")
        first = await asyncio.wait_for(pve_ws.recv(), timeout=5.0)
        first_str = first.decode('utf-8', errors='replace') if isinstance(first, (bytes, bytearray)) else (first or '')
        if not first_str.startswith('OK'):
            logging.info(f"[TERMPROXY] PVE rejected handshake: {first_str!r}")
            await client_ws.send(f'{{"status":"error","message":"PVE rejected: {first_str[:80]!r}"}}')
            await pve_ws.close()
            await client_ws.close(1011, "pve-auth")
            return
        logging.info("[TERMPROXY] PVE handshake OK")
    except Exception as e:
        logging.error(f"[TERMPROXY] handshake error: {type(e).__name__}: {e}")
        await client_ws.send(f'{{"status":"error","message":"handshake error: {type(e).__name__}"}}')
        try:
            await pve_ws.close()
        except Exception as _e:
            logging.debug(f"[TERMPROXY] pve_ws.close() failed: {_e}")
        await client_ws.close(1011, "handshake")
        return

    await client_ws.send('{"status":"connected"}')

    # Bidirectional proxy
    async def pve_to_client():
        try:
            async for msg in pve_ws:
                # PVE termproxy sends raw bytes (TTY output)
                if isinstance(msg, (bytes, bytearray)):
                    await client_ws.send(msg.decode('utf-8', errors='replace'))
                else:
                    await client_ws.send(msg)
        except Exception as e:
            logging.info(f"[TERMPROXY] PVE→client: {type(e).__name__}: {e}")
    async def client_to_pve():
        try:
            async for msg in client_ws:
                if isinstance(msg, str):
                    # Resize protocol: JSON {type:'resize', cols, rows}
                    if msg.startswith('{'):
                        with contextlib.suppress(Exception):
                            j = json.loads(msg)
                            if j.get('type') == 'resize':
                                cols = int(j.get('cols', 80))
                                rows = int(j.get('rows', 24))
                                await pve_ws.send(f"1:{cols}:{rows}:")
                                continue
                    payload_len = len(msg.encode('utf-8'))
                    await pve_ws.send(f"0:{payload_len}:{msg}")
                else:
                    try:
                        text = msg.decode('utf-8')
                    except Exception as _e:
                        text = msg.decode('latin-1', errors='replace')
                    await pve_ws.send(f"0:{len(msg)}:{text}")
        except Exception as e:
            logging.info(f"[TERMPROXY] client→PVE: {type(e).__name__}: {e}")
    try:
        await asyncio.gather(pve_to_client(), client_to_pve(), return_exceptions=True)
    finally:
        try:
            await pve_ws.close()
        except Exception as _e:
            logging.debug(f"[TERMPROXY] pve_ws.close() failed: {_e}")
        logging.info(f"[TERMPROXY] session ended {vm_type}/{vmid_str}")
async def main():
    ssl_context = None
    if SSL_CERT and SSL_KEY and os.path.exists(SSL_CERT) and os.path.exists(SSL_KEY):
        ssl_context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        ssl_context.load_cert_chain(SSL_CERT, SSL_KEY)

    # Issue #71/#95: empty host = all interfaces (dual-stack IPv4+IPv6)
    ws_host = BIND_HOST if BIND_HOST else _WS_FALLBACK_HOST
    display_host = BIND_HOST or _WS_FALLBACK_HOST
    # (#388): wire the lenient_process_request hook so PVE 9.1.x
    # hosts (and any middlebox that strips the Upgrade token from Connection)
    # don't trigger InvalidUpgrade at SSH WS handshake. Was only on VNC before.
    # crcro on issue #388 reported the exact SSH-WS InvalidUpgrade trace this fixes.
    _lpr_ssh = None
    try:
        sys.path.insert(0, os.environ.get('PROXMOXVEX_PKG_BASE') or os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
        from ProxmoxVEx.utils.ws_lenient import lenient_process_request as _lpr_ssh
    except Exception as _e:
        logging.warning(f"[SSH-WS] WARNING: lenient_process_request not importable ({_e}) — strict handshake only")
    serve_kwargs = {'ssl': ssl_context, 'compression': None, 'ping_interval': 30, 'ping_timeout': 10}
    if _lpr_ssh is not None:
        serve_kwargs['process_request'] = _lpr_ssh
    try:
        async with websockets.serve(ssh_handler, ws_host, PORT, **serve_kwargs):
            logging.info(f"SSH WebSocket server ready on {display_host}:{PORT} (lenient-hook={_lpr_ssh is not None})")
            await asyncio.Future()
    except OSError as e:
        if ':' in str(display_host):
            logging.error(f"SSH WebSocket: IPv6 bind failed ({e}), falling back to {_WS_FALLBACK_HOST}")
            async with websockets.serve(ssh_handler, _WS_FALLBACK_HOST, PORT, **serve_kwargs):
                logging.info(f"SSH WebSocket server ready on {_WS_FALLBACK_HOST}:{PORT}")
                await asyncio.Future()
        else:
            raise

if __name__ == '__main__':
    asyncio.run(main())
'''

    # Write the helper script where the service user can actually write.
    # 2026-06-09 (#528 akagoldsmith): the Debian package lives under
    # /usr/lib/ProxmoxVEx (root-owned, read-only for the ProxmoxVEx service user), so
    # writing into the package's api/ dir failed with EACCES and the SSH-WS
    # subprocess never started — port 5002 stayed dead. Fall back to a writable dir;
    # the subprocess gets the package base via PROXMOXVEX_PKG_BASE below so its
    # `import ProxmoxVEx.*` still resolves from wherever the script ends up.
    import tempfile

    pkg_base = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))  # one extra level: module lives in api/vms/
    script_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))  # keep generated .ssh_ws_server.py in api/
    if not os.access(script_dir, os.W_OK):
        script_dir = tempfile.gettempdir()
    script_path = os.path.join(script_dir, ".ssh_ws_server.py")

    from ProxmoxVEx.utils.server_control import kill_existing_on_port

    try:
        kill_existing_on_port(port, "tcp")

        with open(script_path, "w") as f:
            f.write(server_script)

        # Set environment variables for the subprocess
        env = os.environ.copy()
        env["PROXMOXVEX_PKG_BASE"] = pkg_base  # #528: subprocess may live outside the pkg dir now
        env["SSH_WS_PORT"] = str(port)
        env["SSH_WS_HOST"] = host  # Issue #71: IPv6 support
        main_port = port - 2
        env["ProxmoxVEx_URL"] = f"https://127.0.0.1:{main_port}" if ssl_cert else f"http://127.0.0.1:{main_port}"
        if ssl_cert:
            env["SSH_WS_SSL_CERT"] = ssl_cert
        if ssl_key:
            env["SSH_WS_SSL_KEY"] = ssl_key

        # Start as subprocess (completely separate process, no gevent)
        # Use same working directory as main server
        proc = subprocess.Popen(
            [sys.executable, script_path],
            env=env,
            cwd=os.getcwd(),  # Ensure same working dir for config file access
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            start_new_session=True,
        )

        # Read output in background
        def read_output():
            # stdout is PIPE so it's always set — `or ()` just narrows the
            # declared Optional for the type checker
            for line in proc.stdout or ():
                line = line.decode("utf-8", errors="replace").strip()
                if line:
                    logging.info(f"[SSH-WS] {line}")

        import threading

        output_thread = threading.Thread(target=read_output, daemon=True)
        output_thread.start()

        logging.info(f"SSH WebSocket server subprocess started (PID: {proc.pid})")
    except Exception as e:
        logging.error(f"Failed to start SSH WebSocket server: {e}")
