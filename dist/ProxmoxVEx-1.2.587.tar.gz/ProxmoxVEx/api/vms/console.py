# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/api/vms/console.py
# Project:     ProxmoxVEx
# Version:     1.2.565
# Build:       2026.09.30
# Description: console routes for the vms API (split from api/vms.py).
# Usage:       import ProxmoxVEx.api.vms.console
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-30
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""console routes for the vms API (split from api/vms.py)."""

import contextlib
import html
import json
import logging
import re
import socket
import ssl
import threading
import time
from typing import cast
from urllib.parse import quote as url_quote
from urllib.parse import urlencode

from flask import current_app, jsonify

from ProxmoxVEx.api.helpers import check_cluster_access, register_task_user
from ProxmoxVEx.api.realtime import sock
from ProxmoxVEx.globals import cluster_managers
from ProxmoxVEx.models.permissions import ROLE_ADMIN
from ProxmoxVEx.utils.audit import log_audit
from ProxmoxVEx.utils.auth import get_user_record, require_auth, validate_session
from ProxmoxVEx.utils.rbac import get_user_permissions, user_can_access_vm
from ProxmoxVEx.utils.ssh import apply_ssh_host_key_policy

from .common import (
    _WS_FALLBACK_HOST,
    VNC_PVE_CONNECT_TIMEOUT,
    _access_denied,
    _api_error,
    _apply_vnc_socket_options,
    _pve_url,
    _safe_vnc_passthrough,
    bp,
    request,
)


@bp.route("/api/clusters/<cluster_id>/vms/<node>/<vm_type>/<int:vmid>/console", methods=["GET"])
@bp.route("/api/clusters/<cluster_id>/vms/<node>/<vm_type>/<int:vmid>/vnc", methods=["GET"])
@require_auth()
def get_console_ticket(cluster_id, node, vm_type, vmid):
    """Get VNC console ticket for VM - Now uses VM ACLs"""
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()

    if cluster_id not in cluster_managers:
        # lgtm[py/reflected-xss]
        return jsonify({"error": "Cluster not found"}), 404

    # (perf) indexed single-row fetch — load_users() scanned/decrypted all users
    user = get_user_record(request.session["user"])
    user["username"] = request.session["user"]

    mgr = cluster_managers[cluster_id]
    console_perm = "vm.console"
    if not user_can_access_vm(user, cluster_id, vmid, console_perm, vm_type):
        # lgtm[py/reflected-xss]
        return jsonify({"error": f"Permission denied: {html.escape(str(console_perm))}"}), 403

    result = mgr.get_vnc_ticket(node, vmid, vm_type)

    if result.get("success"):
        # Log who opened the console
        usr = request.session.get("user", "unknown")
        log_audit(usr, "vm.console", f"VNC console opened: {vm_type}/{vmid} on {node}", cluster=mgr.config.name)

        # Tag the vncproxy task with the ProxmoxVEx user who opened it,
        # so the taskbar shows YOUR user (not the shared PVE credential). Every other
        # task-creating action registers; the console path was the one that never did.
        if result.get("upid"):
            register_task_user(result["upid"], usr, cluster_id)

        # Stable VNC Mode (D). Frontend opt-in via ?stable=1.
        # Returns an additional AES-256-GCM session key + handle the WS handler
        # picks up on connect. Inner-encryption layer survives TLS-inspection
        # middleboxes that re-encrypt the outer TLS and modify binary RFB bytes.
        if request.args.get("stable") == "1":
            try:
                import base64 as _b64
                import secrets as _secrets

                from ProxmoxVEx.utils import vnc_crypto

                key = vnc_crypto.generate_session_key()
                sid = _secrets.token_urlsafe(16)
                vnc_crypto.stash_session_key(sid, key)
                result["stable"] = {
                    "session_id": sid,
                    "key_b64": _b64.b64encode(key).decode("ascii"),
                    "frame_format": "aes256-gcm-seq32-iv96",
                    "protocol_version": 1,
                }
            except Exception as _enc_err:
                logging.warning(f"[VNC] stable-mode key generation failed (falling back to plain): {_enc_err}")

        # lgtm[py/reflected-xss]
        return jsonify(result)
    # lgtm[py/reflected-xss]
    return jsonify({
        "error": result.get("error", "Failed")
    }), 500  # snyk:ignore:Cross-site Scripting (XSS)  # snyk:ignore:Server Information Exposure


# Framebuffer grab for the "Console Available" tile preview.
# Uses QEMU `screendump` over qm monitor (NOT vncproxy) — a vncproxy shows up
# as a "console opened" task in the PVE log on every grab, which spammed the
# log; screendump is invisible there. Needs node exec (API /execute or SSH);
# on API-token-only clusters without SSH it just fails and the tile shows the
# icon. Cached so re-renders don't re-run qm monitor.
_vm_screenshot_cache = {}  # {f"{cid}:{vmid}": (mono_ts, png_bytes)}


_vm_screenshot_lock = threading.Lock()


_VM_SCREENSHOT_TTL = 60.0


# RFB fallback for the console tile. screendump (qm monitor) is the
# primary grab, but it comes back empty/black for some guests — the big one being
# Windows on the virtio-gpu / QXL driver, where the HMP dump just doesn't render.
# In that case pull ONE frame straight off the vncproxy (RFB), which works no matter
# the guest GPU because it's QEMU's own VNC server. shared=1 so we don't kick an open
# console. Costs a single "console opened" line in the PVE log, hence fallback-only.
def _screenshot_via_rfb(mgr, node, vm_type, vmid, max_width=480, timeout=10):
    import json as _json
    import ssl as _ssl
    import urllib.parse
    import urllib.request

    import websocket as ws_client

    from ProxmoxVEx.utils import vnc_grab

    host, port = mgr.host, mgr.api_port

    ssl_ctx = _ssl.create_default_context()
    # (CodeAnt) - gate TLS verify on the per-cluster ssl_verify flag
    # (default off: PVE ships self-signed; honoured when the admin enables it).
    _verify_tls = bool(getattr(mgr, "_ssl_verify", False))
    if not _verify_tls:
        ssl_ctx.check_hostname = False
        ssl_ctx.verify_mode = _ssl.CERT_NONE

    # login → vncproxy ticket/port (same flow as vnc_poll)
    login_data = urllib.parse.urlencode({"username": mgr.config.user, "password": mgr.config.pass_}).encode("utf-8")
    login_req = urllib.request.Request(
        _pve_url(f"https://{host}:{port}/api2/json/access/ticket"), data=login_data, method="POST"
    )
    with urllib.request.urlopen(login_req, context=ssl_ctx, timeout=10) as r:
        login_result = _json.loads(r.read().decode("utf-8"))
    pve_ticket = login_result["data"]["ticket"]
    csrf_token = login_result["data"]["CSRFPreventionToken"]

    vnc_url = f"https://{host}:{port}/api2/json/nodes/{node}/{vm_type}/{vmid}/vncproxy"
    vnc_req = urllib.request.Request(
        _pve_url(vnc_url), data=urllib.parse.urlencode({"websocket": "1"}).encode("utf-8"), method="POST"
    )
    vnc_req.add_header("Cookie", f"PVEAuthCookie={pve_ticket}")
    vnc_req.add_header("CSRFPreventionToken", csrf_token)
    with urllib.request.urlopen(vnc_req, context=ssl_ctx, timeout=10) as r:
        vnc_result = _json.loads(r.read().decode("utf-8"))
    vnc_ticket = vnc_result["data"]["ticket"]
    vnc_port = vnc_result["data"]["port"]

    # optional SSH tunnel for clusters where 8006 isn't directly reachable from us
    tunnel_endpoint = None
    target_host, target_port = host, 8006
    try:
        if bool(getattr(mgr.config, "vnc_tunnel", False)):
            from ProxmoxVEx.utils import vnc_tunnel as _vt

            _ssh_user = getattr(mgr.config, "ssh_user", None) or (mgr.config.user or "root").split("@")[0]
            _ssh_port = getattr(mgr.config, "ssh_port", 22) or 22
            tunnel_endpoint = _vt.acquire(
                cluster_id=getattr(mgr, "id", ""),
                pve_host=host,
                ssh_user=_ssh_user,
                ssh_port=_ssh_port,
                ssh_key_content=getattr(mgr.config, "ssh_key", "") or "",
                ssh_password=getattr(mgr.config, "pass_", "") or "",
                target_host="127.0.0.1",
                target_port=8006,
            )
            target_host, target_port = "127.0.0.1", tunnel_endpoint.local_port
    except Exception as te:
        logging.warning(f"[Screenshot] RFB tunnel setup failed ({te}) — direct")
        tunnel_endpoint = None
        target_host, target_port = host, 8006

    encoded_ticket = url_quote(vnc_ticket, safe="")
    pve_ws_path = f"/api2/json/nodes/{node}/{vm_type}/{vmid}/vncwebsocket?port={vnc_port}&vncticket={encoded_ticket}"
    pve_ws_url = f"wss://{target_host}:{target_port}{pve_ws_path}"
    pve_ws = None
    try:
        # PVE 9.1+ drops the vncwebsocket upgrade unless the client advertises
        # the "binary" WebSocket subprotocol (noVNC uses the same).
        pve_ws = ws_client.create_connection(
            pve_ws_url,
            sslopt=({} if _verify_tls else {"cert_reqs": _ssl.CERT_NONE}),
            header={"Cookie": f"PVEAuthCookie={pve_ticket}", "Host": f"{host}:{port}"},
            subprotocols=["binary"],
            timeout=timeout,
        )
        img = vnc_grab.grab_frame(pve_ws, vnc_ticket, timeout=timeout)
    finally:
        try:
            if pve_ws:
                pve_ws.close()
        except Exception as _e:
            pass
        try:
            if tunnel_endpoint:
                tunnel_endpoint.stop()
        except Exception as _e:
            pass

    # same blank-guard as screendump — a genuinely-off display shouldn't render a black tile
    # grab_frame always returns an RGB image, so getextrema() yields per-band
    # (lo, hi) pairs — cast past Pillow's single-band union member.
    ex = cast("tuple[tuple[int, int], ...]", img.getextrema())
    if max(hi for _lo, hi in ex) <= 10:
        raise OSError("blank framebuffer (display likely off)")
    # lgtm[py/reflected-xss]
    return vnc_grab.to_png_thumbnail(img, max_width=max_width)


@bp.route("/api/clusters/<cluster_id>/vms/<node>/<vm_type>/<int:vmid>/screenshot", methods=["GET"])
@require_auth()
def get_vm_screenshot(cluster_id, node, vm_type, vmid):
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()
    from ProxmoxVEx.demo import is_demo_mode

    if is_demo_mode():
        # Demo clusters are fixture-backed mocks — there is no hypervisor to
        # screendump/RFB against, so every grab 502'd after a full timeout
        # (and the console tile retried it per guest). Fail fast instead.
        # lgtm[py/reflected-xss]
        return jsonify({"error": "screenshots unavailable in demo mode"}), 404
    if cluster_id not in cluster_managers:
        # lgtm[py/reflected-xss]
        return jsonify({"error": "Cluster not found"}), 404
    if vm_type not in ("qemu", "lxc"):
        # Only QEMU and LXC expose a console we can screenshot
        # lgtm[py/reflected-xss]
        return jsonify({"error": "screenshot only available for qemu and lxc"}), 400

    # (perf) indexed single-row fetch — load_users() scanned/decrypted all users
    user = get_user_record(request.session["user"])
    user["username"] = request.session["user"]
    mgr = cluster_managers[cluster_id]
    if getattr(mgr, "cluster_type", "proxmox") != "proxmox":
        # lgtm[py/reflected-xss]
        return jsonify({"error": "screenshot only available on proxmox"}), 400
    if not user_can_access_vm(user, cluster_id, vmid, "vm.console", vm_type):
        # lgtm[py/reflected-xss]
        return jsonify({"error": "Permission denied: vm.console"}), 403

    cache_key = f"{cluster_id}:{vmid}"
    now = time.monotonic()
    if request.args.get("fresh") != "1":
        with _vm_screenshot_lock:
            hit = _vm_screenshot_cache.get(cache_key)
        if hit and (now - hit[0]) < _VM_SCREENSHOT_TTL:
            resp = current_app.response_class(hit[1], mimetype="image/png")
            resp.headers["Cache-Control"] = "private, max-age=60"
            resp.headers["X-Screenshot-Cache"] = "hit"
            # lgtm[py/reflected-xss]
            return resp

    # LXC has no QEMU monitor, so go straight to an RFB frame from the
    # PVE vncproxy/websocket; QEMU tries the lighter qm monitor screendump
    # first and falls back to the same RFB path.
    if vm_type == "lxc":
        try:
            png = _screenshot_via_rfb(mgr, node, vm_type, vmid, max_width=480, timeout=10)
        except Exception as e:
            logging.info(f"[Screenshot] RFB failed {vm_type}/{vmid}@{node}: {e}")
            return _api_error("screenshot unavailable", status=502)
    else:
        # screendump via qm monitor — no vncproxy, so no "console opened" PVE task
        try:
            from ProxmoxVEx.utils import vnc_grab

            png = vnc_grab.screendump_to_png(mgr, node, vmid, max_width=480, timeout=20)
        except Exception as e:
            # screendump came back empty/blank, or can't run (API-token-only / no SSH).
            # The common one is Windows on virtio-gpu/QXL — qm monitor screendump renders
            # nothing there, so the tile only ever showed the icon. Fall back to a one-off
            # RFB frame off the vncproxy (guest-GPU-independent) before giving up.
            logging.info(f"[Screenshot] screendump failed {vm_type}/{vmid}@{node}: {e} — trying RFB")
            try:
                png = _screenshot_via_rfb(mgr, node, vm_type, vmid, max_width=480, timeout=10)
            except Exception as e2:
                logging.info(f"[Screenshot] RFB fallback also failed {vm_type}/{vmid}@{node}: {e2}")
                return _api_error("screenshot unavailable", status=502)

    with _vm_screenshot_lock:
        _vm_screenshot_cache[cache_key] = (time.monotonic(), png)
        # keep the cache from growing unbounded on big estates
        if len(_vm_screenshot_cache) > 512:
            oldest = sorted(_vm_screenshot_cache.items(), key=lambda kv: kv[1][0])[:128]
            for k, _ in oldest:
                _vm_screenshot_cache.pop(k, None)

    resp = current_app.response_class(png, mimetype="image/png")
    resp.headers["Cache-Control"] = "private, max-age=60"
    resp.headers["X-Screenshot-Cache"] = "miss"
    # lgtm[py/reflected-xss]
    return resp


# HTTP-polling fallback for the VNC proxy. Used when the WS
# leg between browser and ProxmoxVEx is killed by a security middlebox (rare
# but real: CrowdStrike with WS DPI on, Zscaler strict mode). Same auth, same
# Stable-Mode crypto, same SSH tunnel for the second leg — only the transport
# changes from "one persistent WSS" to "many short HTTPS POSTs". Higher latency,
# but goes through anything that allows plain HTTPS.
@bp.route("/api/clusters/<cluster_id>/vms/<node>/<vm_type>/<int:vmid>/vnc-poll", methods=["POST"])
@require_auth()
def vnc_poll(cluster_id, node, vm_type, vmid):
    """Action-dispatched HTTP-polling endpoint for VNC.

    Body shapes:
      {action: 'open',  enc_session?: '...'}    -> {ok, poll_id, ...}
      {action: 'send',  poll_id, data_b64}      -> {ok, sent}
      {action: 'recv',  poll_id, max_wait?}     -> {ok, chunks_b64, closed}
      {action: 'close', poll_id}                -> {ok}
    """
    from ProxmoxVEx.utils import vnc_polling as _poll

    body = request.get_json(silent=True) or {}
    action = body.get("action")

    # All actions need cluster + perm checks
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()
    if cluster_id not in cluster_managers:
        # lgtm[py/reflected-xss]
        return jsonify({"error": "Cluster not found"}), 404

    # (perf) indexed single-row fetch — load_users() scanned/decrypted all users
    user = get_user_record(request.session["user"])
    user["username"] = request.session["user"]
    mgr = cluster_managers[cluster_id]
    console_perm = "vm.console"
    if not user_can_access_vm(user, cluster_id, vmid, console_perm, vm_type):
        # lgtm[py/reflected-xss]
        return jsonify({"error": f"Permission denied: {html.escape(str(console_perm))}"}), 403

    if vm_type not in ("qemu", "lxc"):
        # lgtm[py/reflected-xss]
        return jsonify({"error": "invalid vm_type"}), 400

    # ───── action: open ─────
    if action == "open":
        # acquire PVE auth + vncproxy ticket (mirrors the WS handler flow)
        import base64 as _b64
        import json as _json
        import ssl as _ssl
        import urllib.parse
        import urllib.request

        import websocket as ws_client

        host, port = mgr.host, mgr.api_port

        ssl_ctx = _ssl.create_default_context()
        # (CodeAnt) - gate TLS verify on the per-cluster ssl_verify flag
        # (default off: PVE ships self-signed; honoured when the admin enables it).
        _verify_tls = bool(getattr(mgr, "_ssl_verify", False))
        if not _verify_tls:
            ssl_ctx.check_hostname = False
            ssl_ctx.verify_mode = _ssl.CERT_NONE

        try:
            login_data = urllib.parse.urlencode({
                "username": mgr.config.user,
                "password": mgr.config.pass_,
            }).encode("utf-8")
            login_req = urllib.request.Request(
                _pve_url(f"https://{host}:{port}/api2/json/access/ticket"), data=login_data, method="POST"
            )
            with urllib.request.urlopen(login_req, context=ssl_ctx, timeout=10) as r:
                login_result = _json.loads(r.read().decode("utf-8"))
            pve_ticket = login_result["data"]["ticket"]
            csrf_token = login_result["data"]["CSRFPreventionToken"]

            # (#352 follow-up) - same single-vncproxy fix applies
            # to the polling endpoint. If JS provides pve_port + pve_ticket in
            # the open body, reuse them so noVNC's RFB password matches PVE's.
            pve_port_q = body.get("pve_port")
            pve_ticket_q = body.get("pve_ticket")
            _ppt_ok, _ppt_port = _safe_vnc_passthrough(pve_port_q, pve_ticket_q)
            if pve_port_q and pve_ticket_q and _ppt_ok:
                vnc_ticket = pve_ticket_q
                vnc_port = _ppt_port
            else:
                vnc_url = f"https://{host}:{port}/api2/json/nodes/{node}/{vm_type}/{vmid}/vncproxy"
                vnc_req = urllib.request.Request(
                    _pve_url(vnc_url), data=urllib.parse.urlencode({"websocket": "1"}).encode("utf-8"), method="POST"
                )
                vnc_req.add_header("Cookie", f"PVEAuthCookie={pve_ticket}")
                vnc_req.add_header("CSRFPreventionToken", csrf_token)
                with urllib.request.urlopen(vnc_req, context=ssl_ctx, timeout=10) as r:
                    vnc_result = _json.loads(r.read().decode("utf-8"))
                vnc_ticket = vnc_result["data"]["ticket"]
                vnc_port = vnc_result["data"]["port"]
        except Exception:
            logging.exception("pve auth/proxy failed")
            # lgtm[py/reflected-xss]
            return jsonify({"error": "pve auth/proxy failed"}), 502

        encoded_ticket = url_quote(vnc_ticket, safe="")
        pve_ws_path = (
            f"/api2/json/nodes/{node}/{vm_type}/{vmid}/vncwebsocket?port={vnc_port}&vncticket={encoded_ticket}"
        )

        # Optional SSH tunnel (same path as WS handler)
        tunnel_endpoint = None
        target_host = host
        target_port = 8006
        try:
            if bool(getattr(mgr.config, "vnc_tunnel", False)):
                from ProxmoxVEx.utils import vnc_tunnel as _vt

                _ssh_user = getattr(mgr.config, "ssh_user", None) or (mgr.config.user or "root").split("@")[0]
                _ssh_port = getattr(mgr.config, "ssh_port", 22) or 22
                tunnel_endpoint = _vt.acquire(
                    cluster_id=cluster_id,
                    pve_host=host,
                    ssh_user=_ssh_user,
                    ssh_port=_ssh_port,
                    ssh_key_content=getattr(mgr.config, "ssh_key", "") or "",
                    ssh_password=getattr(mgr.config, "pass_", "") or "",
                    target_host="127.0.0.1",
                    target_port=8006,
                )
                target_host = "127.0.0.1"
                target_port = tunnel_endpoint.local_port
                logging.info(f"[VncPoll] tunnel routed via 127.0.0.1:{target_port} → SSH → {host}:{port}")
        except Exception as te:
            logging.warning(f"[VncPoll] tunnel setup failed ({te}) — direct WSS to PVE")
            tunnel_endpoint = None
            target_host = host
            target_port = 8006

        pve_ws_url = f"wss://{target_host}:{target_port}{pve_ws_path}"
        try:
            pve_ws = ws_client.create_connection(
                pve_ws_url,
                sslopt=({} if _verify_tls else {"cert_reqs": _ssl.CERT_NONE}),
                header={"Cookie": f"PVEAuthCookie={pve_ticket}", "Host": f"{host}:{port}"},
                subprotocols=["binary"],
                timeout=VNC_PVE_CONNECT_TIMEOUT,
            )
            _apply_vnc_socket_options(pve_ws.sock)
        except Exception:
            try:
                if tunnel_endpoint:
                    tunnel_endpoint.stop()
            except Exception:
                pass
            logging.exception("pve ws connect failed")
            # lgtm[py/reflected-xss]
            return jsonify({"error": "pve ws connect failed"}), 502

        # Optional Stable-Mode crypto
        crypto_session = None
        enc_sid = body.get("enc_session")
        if enc_sid:
            try:
                from ProxmoxVEx.utils import vnc_crypto as _vc

                key = _vc.claim_session_key(enc_sid)
                if key:
                    crypto_session = _vc.VncCryptoSession(key)
            except Exception as ce:
                logging.warning(f"[VncPoll] crypto setup failed ({ce}) — plain mode")

        sess = _poll.VncPollSession(
            poll_id=_poll.new_poll_id(),
            pve_ws=pve_ws,
            tunnel_endpoint=tunnel_endpoint,
            crypto_session=crypto_session,
            cluster_id=cluster_id,
            vm_type=vm_type,
            vmid=vmid,
            host=host,
        )
        _poll.register(sess)
        log_audit(
            request.session.get("user", "unknown"),
            "vm.console",
            f"VNC poll session opened: {vm_type}/{vmid} on {node}",
            cluster=mgr.config.name,
        )
        logging.info(
            f"[VncPoll] open id={sess.poll_id[:8]} {vm_type}/{vmid}@{node} crypto={'on' if crypto_session else 'off'} tunnel={'on' if tunnel_endpoint else 'off'}"
        )
        # lgtm[py/reflected-xss]
        return jsonify({
            "ok": True,
            "poll_id": sess.poll_id,
            "transport": "http-polling",
            "recv_max_wait": _poll.RECV_LONG_POLL_DEFAULT,
        })

    # All other actions require an existing poll_id
    poll_id = body.get("poll_id") or ""
    sess = _poll.get(poll_id)
    if not sess:
        # lgtm[py/reflected-xss]
        return jsonify({"error": "unknown or expired poll session"}), 404
    if sess.cluster_id != cluster_id or sess.vm_type != vm_type or sess.vmid != vmid:
        # lgtm[py/reflected-xss]
        return jsonify({"error": "poll session does not match resource"}), 403

    if action == "send":
        try:
            n = sess.send(body.get("data_b64", ""))
        except Exception:
            logging.exception("send failed")
            # lgtm[py/reflected-xss]
            return jsonify({"error": "send failed", "closed": sess.closed}), 502
        # lgtm[py/reflected-xss]
        return jsonify({"ok": True, "sent": n})

    if action == "recv":
        max_wait = float(body.get("max_wait", 5.0) or 5.0)
        chunks = sess.recv(max_wait=max_wait)
        import base64 as _b64

        # lgtm[py/reflected-xss]
        return jsonify({
            "ok": True,
            "chunks_b64": [_b64.b64encode(c).decode("ascii") for c in chunks],
            "closed": sess.closed,
        })

    if action == "close":
        _poll.drop(poll_id)
        # lgtm[py/reflected-xss]
        return jsonify({"ok": True})

    # lgtm[py/reflected-xss]
    return jsonify({"error": f"unknown action {html.escape(str(action))}"}), 400


@bp.route("/api/clusters/<cluster_id>/nodes/<node>/shell", methods=["POST"])
@require_auth(perms=["node.shell"])
def get_node_shell_ticket(cluster_id, node):
    """Get shell ticket for node - requires node.shell permission"""
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()

    if cluster_id not in cluster_managers:
        # lgtm[py/reflected-xss]
        return jsonify({"error": "Cluster not found"}), 404

    mgr = cluster_managers[cluster_id]
    result = mgr.get_node_shell_ticket(node)

    # audit - shell access is sensitive
    usr = getattr(request, "session", {}).get("user", "system")
    log_audit(usr, "node.shell_access", f"Shell access requested for node {node}", cluster=mgr.config.name)

    if result["success"]:
        # lgtm[py/reflected-xss]
        return jsonify(result)
    else:
        # lgtm[py/reflected-xss]
        return jsonify({
            "error": result["error"]
        }), 500  # snyk:ignore:Cross-site Scripting (XSS)  # snyk:ignore:Server Information Exposure


# 2026-06-05 (security audit H-1/H-2): the console WS proxies self-mint a PVE
# ticket for whatever vmid is in the URL, so checking the `vm.console` permission
# alone is a BOLA — a console-capable user could reach ANY VM on ANY cluster/
# tenant. Every console entry point must also confirm THIS user is authorised for
# THIS cluster AND VM. Works without request.session (the async/standalone
# handlers don't have one) by taking the resolved user dict directly.
def _console_authz(user, cluster_id, vmid, vm_type=None):
    """Return (ok, reason) — user must have cluster access AND per-VM console access."""
    from ProxmoxVEx.utils.rbac import get_user_clusters, get_vm_acls, user_can_access_vm

    if not user:
        # lgtm[py/reflected-xss]
        return False, "no user"
    if user.get("role") == ROLE_ADMIN:
        # lgtm[py/reflected-xss]
        return True, None
    username = user.get("username", "") or ""
    # cluster gate (mirrors helpers.check_cluster_access, but no request.session)
    allowed = get_user_clusters(user)
    if allowed is not None and cluster_id not in allowed:
        # (perf) TTL-cached ACL map — load_vm_acls() re-queried every row per VM
        cluster_acls = get_vm_acls().get(cluster_id, {}) or {}
        if not any(username in (a.get("users") or []) or "*" in (a.get("users") or []) for a in cluster_acls.values()):
            # lgtm[py/reflected-xss]
            return False, "no cluster access"
    # per-VM gate
    try:
        vmid_int = int(vmid)
    except (TypeError, ValueError):
        # lgtm[py/reflected-xss]
        return False, "bad vmid"
    if not user_can_access_vm(user, cluster_id, vmid_int, "vm.console", vm_type):
        # lgtm[py/reflected-xss]
        return False, "no VM access"
    # lgtm[py/reflected-xss]
    return True, None


# WebSocket proxy for VNC - using geventwebsocket
def handle_vnc_websocket(ws, cluster_id, node, vm_type, vmid):
    """Handle VNC WebSocket connection"""
    logging.info(f"\n{'=' * 60}")
    logging.info(f"VNC WEBSOCKET: {vm_type}/{vmid} on {node}")
    logging.info(f"{'=' * 60}")
    if cluster_id not in cluster_managers:
        logging.error(f"ERROR: Cluster {cluster_id} not found")
        return

    manager = cluster_managers[cluster_id]
    host, port = manager.host, manager.api_port

    logging.info(f"Target host: {host}")
    pve_ws = None
    running = True

    try:
        import json
        import urllib.parse
        import urllib.request

        import websocket
        from gevent import sleep as gsleep
        from gevent import spawn

        # Create SSL context
        ssl_context = ssl.create_default_context()
        # (CodeAnt) - gate TLS verify on the per-cluster ssl_verify flag
        # (default off: PVE ships self-signed; honoured when the admin enables it).
        _verify_tls = bool(getattr(manager, "_ssl_verify", False))
        if not _verify_tls:
            ssl_context.check_hostname = False
            ssl_context.verify_mode = ssl.CERT_NONE

        # Step 1: Login
        logging.info("Step 1: Login...")
        login_data = urlencode({"username": manager.config.user, "password": manager.config.pass_}).encode("utf-8")

        login_req = urllib.request.Request(
            _pve_url(f"https://{host}:{port}/api2/json/access/ticket"), data=login_data, method="POST"
        )

        with urllib.request.urlopen(login_req, context=ssl_context, timeout=10) as response:
            login_result = json.loads(response.read().decode("utf-8"))

        pve_ticket = login_result["data"]["ticket"]
        csrf_token = login_result["data"]["CSRFPreventionToken"]
        logging.info("Got PVE ticket")
        # (#352 follow-up) - single-vncproxy mode. If the JS
        # already got a vncproxy ticket+port via /console, reuse it so the VNC
        # password noVNC uses matches the password PVE's vncterm expects. PVE
        # 9.1.x generates fresh random VNC password per vncproxy call.
        pve_port_q = request.args.get("pve_port")
        pve_ticket_q = request.args.get("pve_ticket")
        _ppt_ok, _ppt_port = _safe_vnc_passthrough(pve_port_q, pve_ticket_q)
        if pve_port_q and pve_ticket_q and _ppt_ok:
            vnc_ticket = pve_ticket_q
            port = _ppt_port
            logging.info(f"Reusing JS-issued vncproxy ticket port={port}")
        else:
            logging.info("Step 2: Get VNC ticket...")
            if vm_type == "qemu":
                vnc_url = f"https://{host}:{port}/api2/json/nodes/{node}/qemu/{vmid}/vncproxy"
            else:
                vnc_url = f"https://{host}:{port}/api2/json/nodes/{node}/lxc/{vmid}/vncproxy"
            vnc_data = urlencode({"websocket": "1"}).encode("utf-8")
            vnc_req = urllib.request.Request(_pve_url(vnc_url), data=vnc_data, method="POST")
            vnc_req.add_header("Cookie", f"PVEAuthCookie={pve_ticket}")
            vnc_req.add_header("CSRFPreventionToken", csrf_token)
            with urllib.request.urlopen(vnc_req, context=ssl_context, timeout=10) as response:
                vnc_result = json.loads(response.read().decode("utf-8"))
            vnc_ticket = vnc_result["data"]["ticket"]
            port = vnc_result["data"]["port"]
            logging.info(f"Got VNC ticket, port={port} (no JS pass-through — PVE 9.1.x users may hit issue #352)")
        # Step 3: Connect to Proxmox WebSocket
        logging.info("Step 3: Connect to Proxmox...")
        encoded_vnc_ticket = url_quote(vnc_ticket, safe="")

        if vm_type == "qemu":
            pve_ws_path = f"/api2/json/nodes/{node}/qemu/{vmid}/vncwebsocket?port={port}&vncticket={encoded_vnc_ticket}"
        else:
            pve_ws_path = f"/api2/json/nodes/{node}/lxc/{vmid}/vncwebsocket?port={port}&vncticket={encoded_vnc_ticket}"

        pve_ws_url = f"wss://{host}:{port}{pve_ws_path}"

        pve_ws = websocket.create_connection(
            pve_ws_url,
            sslopt=({} if _verify_tls else {"cert_reqs": ssl.CERT_NONE}),
            header={"Cookie": f"PVEAuthCookie={pve_ticket}"},
            subprotocols=["binary"],
            timeout=VNC_PVE_CONNECT_TIMEOUT,
        )
        # TCP_NODELAY + keepalive: survives idle conntrack drops
        _apply_vnc_socket_options(pve_ws.sock)

        logging.info("✓ Connected to Proxmox!")
        pve_ws.settimeout(0.1)

        bytes_sent = 0
        bytes_received = 0

        # Greenlet to read from Proxmox and send to client
        def proxmox_to_client():
            nonlocal bytes_received, running
            try:
                while running:
                    try:
                        data = pve_ws.recv()
                        if data:
                            bytes_received += len(data)
                            ws.send(data)
                    except websocket.WebSocketTimeoutException:
                        gsleep(0.01)
                    except websocket.WebSocketConnectionClosedException:
                        logging.info("Proxmox closed")
                        running = False
                        break
                    except Exception as e:
                        if running:
                            logging.error(f"PVE->Client error: {e}")
                        running = False
                        break
            except Exception as e:
                logging.error(f"proxmox_to_client crashed: {e}")
                running = False

        # Start the proxmox reader greenlet
        pve_reader = spawn(proxmox_to_client)

        logging.info("Step 4: Proxy running...")
        # Main loop: read from client, send to Proxmox
        while running:
            try:
                data = ws.receive()
                if data is None:
                    logging.info("Client disconnected")
                    running = False
                    break
                if data:
                    bytes_sent += len(data)
                    pve_ws.send(data)
            except Exception as e:
                if running:
                    err_str = str(e)
                    if "closed" not in err_str.lower():
                        logging.error(f"Client->PVE error: {e}")
                running = False
                break

        running = False
        pve_reader.kill()

        logging.info(f"Session ended: sent {bytes_sent}, received {bytes_received}")
    except Exception as e:
        logging.exception(f"VNC proxy error: {type(e).__name__}: {e}")
    finally:
        running = False
        if pve_ws:
            with contextlib.suppress(Exception):
                pve_ws.close()
        logging.info(f"{'=' * 60}\n")


@bp.route("/api/clusters/<cluster_id>/vms/<node>/<vm_type>/<int:vmid>/vncwebsocket")
def vnc_websocket_route(cluster_id, node, vm_type, vmid):
    """WebSocket endpoint for VNC - redirect to dedicated WS port

    Auth via query param since WebSocket can't send custom headers
    """
    # 2026-06-10: don't call check_cluster_access() here. This route has no
    # @require_auth (it authenticates via the ?token=/?session= query param below,
    # because a WebSocket can't send custom headers), so request.session isn't
    # populated yet and check_cluster_access() would blow up with
    # AttributeError: 'Request' object has no attribute 'session' on every GET.
    # The cluster gate is enforced by _console_authz() below — it does the same
    # get_user_clusters() + VM-ACL fallback against the resolved query-param user.
    # Prefer WS token, session as fallback
    from ProxmoxVEx.utils.realtime import validate_ws_token

    ws_token = request.args.get("token")
    session_id = request.args.get("session")

    auth_user = None
    if ws_token:
        token_data = validate_ws_token(ws_token)
        if not token_data:
            # lgtm[py/reflected-xss]
            return jsonify({"error": "Invalid token", "code": "INVALID_TOKEN"}), 401
        auth_user = token_data["user"]
        token_data["role"]
    elif session_id:
        session = validate_session(session_id)
        if not session:
            # lgtm[py/reflected-xss]
            return jsonify({"error": "Invalid session", "code": "INVALID_SESSION"}), 401
        auth_user = session["user"]
        session["role"]
    else:
        # lgtm[py/reflected-xss]
        return jsonify({"error": "Auth required", "code": "AUTH_REQUIRED"}), 401

    # Check permissions
    # (perf) indexed single-row fetch — load_users() scanned/decrypted all users
    user = get_user_record(auth_user)
    get_user_permissions(user)
    # 2026-06-10 (#537/RBAC): coarse "global vm.console perm OR admin" pre-check dropped
    # the per-VM _console_authz gate below is authoritative and portal/custom-role aware.
    # H-1/H-2: cluster + per-VM gate (vm.console alone isn't enough)
    user["username"] = auth_user
    _ok, _why = _console_authz(user, cluster_id, vmid, vm_type)
    if not _ok:
        # lgtm[py/reflected-xss]
        return jsonify({"error": "Permission denied", "code": "INSUFFICIENT_PERMISSIONS"}), 403

    # This route is just a fallback - actual WebSocket handling is done by the
    # dedicated WebSocket server started in start_vnc_websocket_server()
    # 2026-06-10: removed a redundant local `from flask import request` here
    # request is already module-level, and the local re-import made `request` a
    # function-local, so the request.args.get(...) auth lookup above raised
    # UnboundLocalError once check_cluster_access (which used to crash first) was gone.
    logging.info(f"\n*** VNC ROUTE HIT (HTTP): {vm_type}/{vmid} on {node} ***")
    logging.info(f"HTTP_UPGRADE: {request.environ.get('HTTP_UPGRADE', 'NONE')}")
    logging.info(f"wsgi.websocket: {request.environ.get('wsgi.websocket', 'NONE')}")
    # Try geventwebsocket first
    ws = request.environ.get("wsgi.websocket")
    if ws is not None:
        logging.info("Using geventwebsocket handler...")
        handle_vnc_websocket(ws, cluster_id, node, vm_type, vmid)
        # lgtm[py/reflected-xss]
        return ""

    # If not a websocket, return error
    # lgtm[py/reflected-xss]
    return jsonify({"error": "WebSocket connection required"}), 426


# Standalone VNC WebSocket Server using websockets library
def start_vnc_websocket_server(port=5001, ssl_cert=None, ssl_key=None, host="127.0.0.1"):
    """Start a dedicated WebSocket server for VNC proxying"""
    import asyncio
    import re
    import threading

    from ProxmoxVEx.utils.server_control import kill_existing_on_port

    try:
        import websockets
    except ImportError:
        logging.warning("WARNING: 'websockets' library not installed. VNC console will not work.")
        logging.info("Install with: pip install websockets")
        return

    kill_existing_on_port(port, "tcp")

    # Event to signal server is ready
    server_ready = threading.Event()

    async def vnc_handler(websocket):
        """Handle VNC WebSocket connections

        Auth via query param since WebSocket can't send custom headers
        """
        # Get path from websocket
        path = websocket.request.path if hasattr(websocket, "request") else websocket.path

        logging.info(f"\n{'=' * 60}")
        logging.info(f"VNC WebSocket connected: {path}")
        logging.info(f"{'=' * 60}")
        # Authenticate via single-use WS token (not session in URL)
        from urllib.parse import parse_qs, urlparse

        parsed = urlparse(path)
        query_params = parse_qs(parsed.query)
        ws_token = query_params.get("token", [None])[0]
        # Backwards compat, accept session= too for now
        session_id = query_params.get("session", [None])[0]

        # Stable VNC Mode (D): if frontend asked for an encrypted
        # tunnel via /console?stable=1, it gets back an enc_session id which it
        # then passes here. We claim the matching AES-256-GCM key (one-shot,
        # auto-expires after 60s if never claimed) and use it to wrap forwarded
        # frames in both directions. None → plain mode (default, backwards-compat).
        crypto_session = None
        enc_sid = query_params.get("enc_session", [None])[0]
        if enc_sid:
            try:
                from ProxmoxVEx.utils import vnc_crypto as _vc

                _key = _vc.claim_session_key(enc_sid)
                if _key:
                    crypto_session = _vc.VncCryptoSession(_key)
                    logging.info(f"[VNC] stable mode active for sid={enc_sid[:8]}...")
                else:
                    logging.error(
                        f"[VNC] enc_session={enc_sid[:8]}... not found / expired — falling back to plain mode"
                    )
            except Exception as _e:
                logging.error(f"[VNC] crypto setup failed ({_e}) — falling back to plain mode")
        if ws_token:
            from ProxmoxVEx.utils.realtime import validate_ws_token

            token_data = validate_ws_token(ws_token)
            if not token_data:
                logging.error("ERROR: Invalid or expired WS token")
                await websocket.close(1002, "Invalid token")
                return
            # check perms from token
            # (perf) indexed fetch with legacy fallback — load_users() scanned/decrypted all users
            user = get_user_record(token_data["user"])
            user["username"] = token_data["user"]
            # 2026-06-10 (#537 abyss1): the per-VM _console_authz gate below (H-1/H-2) is the
            # authoritative check (cluster + per-VM vm.console via user_can_access_vm). The old
            # coarse "global vm.console perm OR admin" pre-check here rejected Client-Portal users
            # — they hold per-VM console access through the portal model, not a global RBAC perm
            # so the portal console hung at "Connecting…". Dropped; _console_authz still enforces it.
            logging.info(f"User {token_data['user']} authenticated for VNC (ws_token)")
        elif session_id:
            session = validate_session(session_id)
            if not session:
                logging.error("ERROR: Invalid session")
                await websocket.close(1002, "Invalid session")
                return
            user = get_user_record(session["user"])
            user["username"] = session["user"]
            # #537: per-VM _console_authz below is the authoritative gate (see ws_token note).
            logging.info(f"User {session['user']} authenticated for VNC (session)")
        else:
            logging.error("ERROR: No token or session provided")
            await websocket.close(1002, "Authentication required")
            return

        # Parse path: /api/clusters/{cluster_id}/vms/{node}/{vm_type}/{vmid}/vncwebsocket
        match = re.match(r"/api/clusters/([^/]+)/vms/([^/]+)/(qemu|lxc)/(\d+)/vncwebsocket", parsed.path)
        if not match:
            logging.error(f"ERROR: Invalid path: {parsed.path}")
            await websocket.close(1002, "Invalid path")
            return

        cluster_id, node, vm_type, vmid = match.groups()
        vmid = int(vmid)

        logging.info(f"Cluster: {cluster_id}, Node: {node}, Type: {vm_type}, VMID: {vmid}")
        # H-1/H-2: cluster + per-VM gate before we self-mint a PVE ticket for this vmid
        _ok, _why = _console_authz(user, cluster_id, vmid, vm_type)
        if not _ok:
            logging.error(f"ERROR: console authz denied ({_why}) for {cluster_id}/{vmid}")
            await websocket.close(1002, "Permission denied")
            return

        if cluster_id not in cluster_managers:
            logging.error(f"ERROR: Cluster {cluster_id} not found")
            await websocket.close(1002, "Cluster not found")
            return

        manager = cluster_managers[cluster_id]
        host, port = manager.host, manager.api_port

        pve_ws = None
        # bound before the try so the finally's tunnel cleanup can reference it
        # even if the ticket/vncproxy setup raises first
        tunnel_endpoint = None

        try:
            import json
            import urllib.parse
            import urllib.request

            import websocket as ws_client

            ssl_ctx = ssl.create_default_context()
            # (CodeAnt) - gate TLS verify on the per-cluster ssl_verify flag
            # (default off: PVE ships self-signed; honoured when the admin enables it).
            _verify_tls = bool(getattr(manager, "_ssl_verify", False))
            if not _verify_tls:
                ssl_ctx.check_hostname = False
                ssl_ctx.verify_mode = ssl.CERT_NONE

            # Login to Proxmox to get auth ticket
            login_data = urlencode({"username": manager.config.user, "password": manager.config.pass_}).encode("utf-8")

            login_req = urllib.request.Request(
                _pve_url(f"https://{host}:{port}/api2/json/access/ticket"), data=login_data, method="POST"
            )

            # Wrap synchronous urllib.urlopen in asyncio.to_thread
            # so concurrent VNC handlers don't serialize on the TLS handshake.
            import asyncio as _aiowrap

            def _do_urlopen(req):
                with urllib.request.urlopen(req, context=ssl_ctx, timeout=10) as r:
                    # lgtm[py/reflected-xss]
                    return r.read()

            login_body = await _aiowrap.to_thread(_do_urlopen, login_req)
            login_result = json.loads(login_body.decode("utf-8"))

            pve_ticket = login_result["data"]["ticket"]
            csrf_token = login_result["data"]["CSRFPreventionToken"]

            # Issue #352 follow-up. Single-vncproxy fast path.
            # If the JS already obtained a vncproxy ticket+port via /console
            # (which it always does — that's where it gets the VNC RFB password
            # for noVNC), reuse THAT ticket here instead of issuing a fresh
            # vncproxy call. PVE 9.1.x generates a random VNC password per
            # vncproxy call. Two calls = two different passwords; noVNC sends
            # DES(password_A) but PVE's vncterm is initialised with password_B,
            # so RFB auth fails (the customer-visible recv=60B + ttfb≈1s pattern).
            # Older PVE was tolerant because passwords were derived from the
            # ticket prefix. Newer PVE is strict.
            pve_port_q = query_params.get("pve_port", [None])[0]
            pve_ticket_q = query_params.get("pve_ticket", [None])[0]
            # sec-review: validate the passthrough; null it on garbage so both this
            # block AND the auth-header reuse below fall back cleanly to a fresh vncproxy.
            _ppt_ok, _ppt_port = _safe_vnc_passthrough(pve_port_q, pve_ticket_q)
            if not _ppt_ok:
                pve_port_q = pve_ticket_q = None
            if pve_port_q and pve_ticket_q:
                # Single-vncproxy mode: trust the caller-supplied port+ticket.
                vnc_ticket = pve_ticket_q
                port = _ppt_port
                logging.info(f"[VNC] reusing JS-issued vncproxy ticket port={port} (single-call mode)")
            else:
                # Backwards-compat fallback: issue our own vncproxy. This still
                # works on older PVE where two vncproxy calls produce matching
                # passwords (or where noVNC isn't used in the browser).
                if vm_type == "qemu":
                    vnc_url = f"https://{host}:{port}/api2/json/nodes/{node}/qemu/{vmid}/vncproxy"
                else:
                    vnc_url = f"https://{host}:{port}/api2/json/nodes/{node}/lxc/{vmid}/vncproxy"
                vnc_data = urlencode({"websocket": "1"}).encode("utf-8")
                vnc_req = urllib.request.Request(_pve_url(vnc_url), data=vnc_data, method="POST")
                vnc_req.add_header("Cookie", f"PVEAuthCookie={pve_ticket}")
                vnc_req.add_header("CSRFPreventionToken", csrf_token)
                vnc_body = await _aiowrap.to_thread(_do_urlopen, vnc_req)
                vnc_result = json.loads(vnc_body.decode("utf-8"))
                vnc_ticket = vnc_result["data"]["ticket"]
                port = vnc_result["data"]["port"]
                logging.warning(
                    f"[VNC] no pve_port/pve_ticket in URL — issued fresh vncproxy (port={port}). Update the frontend to pass JS-issued ticket through to avoid PVE 9.1.x password-mismatch (issue #352)."
                )

            encoded_vnc_ticket = url_quote(vnc_ticket, safe="")

            if vm_type == "qemu":
                pve_ws_path = (
                    f"/api2/json/nodes/{node}/qemu/{vmid}/vncwebsocket?port={port}&vncticket={encoded_vnc_ticket}"
                )
            else:
                pve_ws_path = (
                    f"/api2/json/nodes/{node}/lxc/{vmid}/vncwebsocket?port={port}&vncticket={encoded_vnc_ticket}"
                )

            # VNC SSH-Tunnel-Mode (D2 / second leg).
            # If the cluster is flagged with vnc_tunnel=True, we open a persistent
            # SSH connection to the PVE node and forward localhost:RAND→pve:8006
            # through it. The WSS connection then goes to localhost:RAND instead
            # of pve:8006, so the WSS bytes ride inside SSH which TLS-inspection
            # engines can't decrypt (no trust-anchor for the SSH host key).
            # Multi-user: each session gets its own ephemeral local port.
            tunnel_endpoint = None
            tunnel_target_host = host
            tunnel_target_port = 8006
            try:
                _use_tunnel = bool(getattr(manager.config, "vnc_tunnel", False))
            except Exception as _e:
                _use_tunnel = False

            if _use_tunnel:
                try:
                    from ProxmoxVEx.utils import vnc_tunnel as _vt

                    _ssh_user = (
                        getattr(manager.config, "ssh_user", None) or (manager.config.user or "root").split("@")[0]
                    )
                    _ssh_port = getattr(manager.config, "ssh_port", 22) or 22
                    _ssh_key = getattr(manager.config, "ssh_key", "") or ""
                    _ssh_pass = getattr(manager.config, "pass_", "") or ""
                    # _vt.acquire() is sync. On the *first* call for a
                    # cluster it builds the SSH transport (~1-2s on a fast LAN, more
                    # over WAN). If we ran it directly on the event loop, that 1-2s
                    # blocks websockets.serve from completing opening handshakes for
                    # other concurrent connections — which is exactly the "5/5 timed
                    # out during opening handshake" we saw in the multi-user test.
                    # Offload to a worker so the event loop stays free.
                    import asyncio as _aio_acq

                    tunnel_endpoint = await _aio_acq.to_thread(
                        _vt.acquire,
                        cluster_id=cluster_id,
                        pve_host=host,
                        ssh_user=_ssh_user,
                        ssh_port=_ssh_port,
                        ssh_key_content=_ssh_key,
                        ssh_password=_ssh_pass,
                        target_host="127.0.0.1",
                        target_port=8006,
                    )
                    # Reroute the WSS through the local listener
                    tunnel_target_host = "127.0.0.1"
                    tunnel_target_port = tunnel_endpoint.local_port
                    logging.info(
                        f"[VNC] SSH tunnel mode active for cluster={cluster_id}: "
                        f"WSS routed via 127.0.0.1:{tunnel_target_port} → SSH → {host}:{port}"
                    )
                except Exception as _tun_err:
                    logging.warning(
                        f"[VNC] SSH tunnel setup failed ({_tun_err}) — falling back "
                        f"to direct WSS to {host}:{port}. Customer may still see "
                        "TLS-inspection issues until SSH is fixed."
                    )
                    tunnel_endpoint = None
                    tunnel_target_host = host
                    tunnel_target_port = 8006

            pve_ws_url = f"wss://{tunnel_target_host}:{tunnel_target_port}{pve_ws_path}"

            # (#352 follow-up) - auth-context for the PVE WS upgrade.
            # When we're REUSING the JS-issued vncproxy ticket, the ticket was
            # bound to the manager's existing auth context (API token or stored
            # access cookie). Using a fresh login's cookie produces "permission
            # denied - invalid PVEVNC ticket" on PVE 9.1.x. Reuse the manager's
            # stored auth instead. Backwards-compat path keeps the fresh login.
            ws_auth_header = {"Host": f"{host}:{port}"}
            if pve_port_q and pve_ticket_q:
                if getattr(manager, "_using_api_token", False) and getattr(manager, "_api_token", None):
                    ws_auth_header["Authorization"] = f"PVEAPIToken={manager._api_token}"
                elif getattr(manager, "_ticket", None):
                    ws_auth_header["Cookie"] = f"PVEAuthCookie={manager._ticket}"
                else:
                    ws_auth_header["Cookie"] = f"PVEAuthCookie={pve_ticket}"
            else:
                ws_auth_header["Cookie"] = f"PVEAuthCookie={pve_ticket}"

            # Ws_client.create_connection is synchronous; offload to
            # a worker thread so concurrent VNC handlers don't serialize on the
            # TLS+WS-Upgrade handshake (~1-2s each) on the event loop.
            import asyncio as _asyncio_for_connect
            import time as _t_connect

            _connect_started = _t_connect.monotonic()
            # PVE 9.1+ drops the vncwebsocket upgrade unless the client advertises
            # the "binary" WebSocket subprotocol (noVNC uses the same).
            pve_ws = await _asyncio_for_connect.to_thread(
                ws_client.create_connection,
                pve_ws_url,
                sslopt=({} if _verify_tls else {"cert_reqs": ssl.CERT_NONE}),
                header=ws_auth_header,
                subprotocols=["binary"],
                timeout=VNC_PVE_CONNECT_TIMEOUT,
            )
            _connect_ms = int((_t_connect.monotonic() - _connect_started) * 1000)

            # Apr 2026: TCP_NODELAY + aggressive keepalive (replaces older Comment).
            # Nagle off = no 40ms input lag for keystrokes/mouse; keepalive on = stateful
            # firewalls don't drop the session during natural idle periods.
            _apply_vnc_socket_options(pve_ws.sock)

            logging.info(f"[VNC] connected to {host} for {vm_type}/{vmid} in {_connect_ms}ms")
            if _connect_ms > 3000:
                logging.warning(
                    f"[VNC] slow PVE connect: {_connect_ms}ms — possible TLS-inspection / EDR latency on the path to {host}"
                )

            import asyncio

            bytes_sent = 0
            bytes_received = 0
            running = True
            stop_evt = asyncio.Event()
            # Time-to-first-byte from PVE side; helps distinguish
            # "couldn't connect" from "connected but stuck mid-handshake" in support
            _ttfb_ms = None
            _session_started = _t_connect.monotonic()

            # (#312/#92): the old loop used settimeout(0.001) + asyncio.sleep(0.005)
            # to fake non-blocking recv. That's a busy-wait that blocks the event loop on every
            # recv() call — under load or network jitter it drops bytes and the session dies after
            # a few minutes. Switch to blocking recv in a worker thread via asyncio.to_thread.
            pve_ws.settimeout(None)  # blocking mode — to_thread handles the blocking call

            async def proxmox_to_client():
                """Forward data from Proxmox to browser (blocking recv handled in thread).

                In Stable VNC Mode (crypto_session is not None): plain RFB bytes
                from PVE are wrapped in an AES-256-GCM frame before they hit the
                browser-side WebSocket. The middlebox can re-encrypt our outer
                TLS but sees opaque ciphertext inside, so it can't pattern-match
                or modify the binary RFB.
                """
                nonlocal bytes_received, running, _ttfb_ms
                while running:
                    try:
                        data = await asyncio.to_thread(pve_ws.recv)
                        if not data:
                            running = False
                            break
                        if _ttfb_ms is None:
                            _ttfb_ms = int((_t_connect.monotonic() - _session_started) * 1000)
                        bytes_received += len(data)
                        if isinstance(data, str):
                            data = data.encode("latin-1")
                        if crypto_session is not None:
                            data = crypto_session.encrypt(data)
                        await websocket.send(data)
                    except ws_client.WebSocketConnectionClosedException:
                        running = False
                        break
                    except Exception as e:
                        if running:
                            logging.debug(f"[VNC] PVE->Client: {e}")
                        running = False
                        break
                stop_evt.set()

            async def client_to_proxmox():
                """Forward data from browser to Proxmox (blocking send handled in thread).

                In Stable VNC Mode: each browser-side WebSocket frame is an
                AES-256-GCM ciphertext blob. We unwrap it (which also verifies
                the auth tag — if a middlebox modified bytes mid-flight, decrypt
                raises and we close the session with code 4099 and a clear
                'integrity check failed' reason instead of letting RFB later
                fail with a confusing 'Authentication failed').
                """
                nonlocal bytes_sent, running
                try:
                    async for message in websocket:
                        if not running:
                            break
                        bytes_sent += len(message)
                        if isinstance(message, str):
                            message = message.encode("latin-1")
                        if crypto_session is not None:
                            try:
                                message = crypto_session.decrypt(message)
                            except Exception as _crypto_err:
                                logging.warning(
                                    f"[VNC] integrity check FAILED on browser→PVE frame "
                                    f"(host={host} vm={vm_type}/{vmid}): {_crypto_err}. "
                                    "TLS-inspection / EDR is modifying packets mid-flight."
                                )
                                running = False
                                with contextlib.suppress(Exception):
                                    await websocket.close(4099, f"integrity_check_failed: {_crypto_err}")
                                break
                        await asyncio.to_thread(pve_ws.send, message)
                except Exception as e:
                    if running and "close" not in str(e).lower():
                        logging.debug(f"[VNC] Client->PVE: {e}")
                finally:
                    running = False
                    stop_evt.set()

            async def pve_keepalive():
                """Keepalive for pvedaemon idle timeout (#312).

                Two-layer: WS ping every 15s AND an RFB-level FramebufferUpdateRequest
                every 20s. pveproxy sits between us and qemu and can timeout based on
                RFB traffic, not WS frames — the browser's WS ping alone doesn't always
                count as activity on the qemu side. By injecting an RFB incremental
                update request we produce real RFB traffic that flows end-to-end.

                RFB FramebufferUpdateRequest wire format (8 bytes, Big-Endian):
                  U8  message-type = 3
                  U8  incremental  = 1   (only changed regions -> cheap)
                  U16 x            = 0
                  U16 y            = 0
                  U16 width        = 0xFFFF  (server clamps to FB size)
                  U16 height       = 0xFFFF

                15s grace before first RFB frame so the RFB handshake completes first
                injecting our bytes into the handshake would confuse qemu.
                """
                import time as _time

                RFB_FB_UPDATE_REQUEST = b"\x03\x01\x00\x00\x00\x00\xff\xff\xff\xff"
                session_start = _time.monotonic()
                ws_ping_interval = 15
                rfb_interval = 20
                next_rfb_at = session_start + 15 + rfb_interval  # 15s grace + 20s first interval
                while running:
                    try:
                        await asyncio.wait_for(stop_evt.wait(), timeout=ws_ping_interval)
                        break  # stop_evt was set — session ending
                    except asyncio.TimeoutError:
                        pass
                    if not running:
                        break
                    # WS-layer ping (cheap, keeps any websocket-aware intermediary happy)
                    try:
                        await asyncio.to_thread(pve_ws.ping)
                    except Exception as _e:
                        break
                    # RFB-layer keepalive (keeps pveproxy/qemu from declaring the session idle)
                    now = _time.monotonic()
                    if now >= next_rfb_at:
                        try:
                            await asyncio.to_thread(pve_ws.send_binary, RFB_FB_UPDATE_REQUEST)
                            next_rfb_at = now + rfb_interval
                        except Exception as e:
                            logging.debug(f"[VNC] RFB keepalive send failed: {e}")
                            break

            task1 = asyncio.create_task(proxmox_to_client())
            task2 = asyncio.create_task(client_to_proxmox())
            task3 = asyncio.create_task(pve_keepalive())

            done, pending = await asyncio.wait([task1, task2, task3], return_when=asyncio.FIRST_COMPLETED)

            running = False

            for task in pending:
                task.cancel()
                with contextlib.suppress(asyncio.CancelledError):
                    await task

            # Richer session-end diagnostic. Helps support correlate
            # short / weird sessions with network / inspection issues. Format is
            # easy to grep + machine-parseable.
            _duration_ms = int((_t_connect.monotonic() - _session_started) * 1000)
            _ttfb_str = f"{_ttfb_ms}ms" if _ttfb_ms is not None else "never"
            _short_session = _duration_ms < 5000 and bytes_received < 4096
            _level = logging.WARNING if _short_session else logging.INFO
            logging.log(
                _level,
                f"[VNC] session ended host={host} vm={vm_type}/{vmid} "
                f"connect={_connect_ms}ms ttfb={_ttfb_str} duration={_duration_ms}ms "
                f"sent={bytes_sent}B recv={bytes_received}B "
                f"{'SHORT_OR_EMPTY — middlebox/EDR may be interfering' if _short_session else ''}",
            )

        except Exception as e:
            logging.exception(f"VNC WS handler error: {type(e).__name__}: {e}")
        finally:
            # Pve_ws.close() is a SYNC call from the websocket-client
            # library. It runs the TLS close handshake which on a tunneled SSH leg
            # can block when the far end is gone. If we run it on the event loop,
            # ALL subsequent VNC handshakes on this server queue behind it (we hit
            # this in the multi-user concurrency test: 1st session OK, then 5 in
            # parallel all timeout). Offload to a worker with a short upper bound.
            if pve_ws:
                try:
                    import asyncio as _aio_close

                    await _aio_close.wait_for(_aio_close.to_thread(pve_ws.close), timeout=2.0)
                except Exception as _e:
                    pass
            try:
                if tunnel_endpoint is not None:
                    tunnel_endpoint.stop()
            except Exception as _tend:
                logging.debug(f"[VNC] tunnel cleanup error: {_tend}")
            logging.info(f"{'=' * 60}\n")

    async def main():
        nonlocal server_ready
        ssl_context = None
        if ssl_cert and ssl_key:
            ssl_context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
            ssl_context.load_cert_chain(ssl_cert, ssl_key)
            proto = "wss"
        else:
            proto = "ws"

        # Suppress websocket error logs from bots/scanners
        import logging as ws_logging

        ws_logging.getLogger("websockets").setLevel(ws_logging.CRITICAL)

        # Added ping keepalive like SSH server has, was causing random disconnects
        # Feb 2026: host='' means all interfaces (asyncio creates IPv4+IPv6 listeners)
        # (#352): lenient Connection-header recovery for PVE 9.1.8-9 hosts
        # and middlebox-stripped Upgrade tokens. See ProxmoxVEx/utils/ws_lenient.py.
        from ProxmoxVEx.utils.ws_lenient import lenient_process_request as _lpr_vnc

        ws_host = host if host else _WS_FALLBACK_HOST
        display_host = host or _WS_FALLBACK_HOST
        try:
            async with websockets.serve(
                vnc_handler,
                ws_host,
                port,
                ssl=ssl_context,
                compression=None,
                ping_interval=20,
                ping_timeout=10,
                process_request=_lpr_vnc,
            ):
                logging.info(f"VNC WebSocket Server ready on {proto}://{display_host}:{port}")
                server_ready.set()
                await asyncio.Future()  # Run forever
        except OSError as bind_err:
            # Issue #71: IPv6 bind failed, fall back to 0.0.0.0
            if ":" in str(host):
                logging.error(f"VNC WebSocket: IPv6 bind failed ({bind_err}), falling back to {_WS_FALLBACK_HOST}")
                async with websockets.serve(
                    vnc_handler,
                    _WS_FALLBACK_HOST,
                    port,
                    ssl=ssl_context,
                    compression=None,
                    ping_interval=20,
                    ping_timeout=10,
                    process_request=_lpr_vnc,
                ):
                    logging.info(f"VNC WebSocket Server ready on {proto}://0.0.0.0:{port}")
                    server_ready.set()
                    await asyncio.Future()
            else:
                raise

    # Run in thread, with proper fallback for gevent environments
    # (#388 follow-up) - capture exception into a shared box so the
    # caller waiting on server_ready can surface it loudly in the journal
    # instead of just "may not be ready yet". Silent thread death is the
    # hardest pattern to debug at the customer.
    thread_err = {}  # exception sink — populated if the thread crashes pre-bind

    def run_server():
        try:
            # Try asyncio.run() first (clean Python, no gevent)
            asyncio.run(main())
        except RuntimeError as e:
            if "cannot be called from a running event loop" in str(e):
                # Gevent monkey-patches asyncio, need explicit event loop
                logging.info("VNC WebSocket: gevent detected, using new event loop")
                loop = asyncio.new_event_loop()
                asyncio.set_event_loop(loop)
                try:
                    loop.run_until_complete(main())
                finally:
                    loop.close()
            else:
                logging.exception(f"VNC WebSocket Server RuntimeError: {e}")
                thread_err["err"] = ("RuntimeError", str(e))
        except (KeyboardInterrupt, SystemExit):
            pass
        except OSError as e:
            # bind failures land here — port in use, permission denied, AppArmor block, etc.
            logging.exception(f"VNC WebSocket Server bind failed (port {port}): {e}")
            thread_err["err"] = ("OSError", f"bind error: {e}")
        except TypeError as e:
            # signature mismatches with websockets library (e.g. older websockets)
            logging.exception(f"VNC WebSocket Server TypeError (likely websockets lib version mismatch): {e}")
            thread_err["err"] = ("TypeError", str(e))
        except Exception as e:
            logging.exception(f"VNC WebSocket Server crashed: {type(e).__name__}: {e}")
            thread_err["err"] = (type(e).__name__, str(e))

    logging.info(f"VNC WebSocket: starting thread, target port {port}")
    ws_thread = threading.Thread(target=run_server, daemon=True, name=f"vnc-ws:{port}")
    ws_thread.start()

    # (#388): if the thread is dead at this point and never set
    # server_ready, surface WHY in the log so support can act. Silent failure
    # was the customer-visible symptom that hid the underlying cause.
    if server_ready.wait(timeout=5):
        logging.info(f"VNC WebSocket Server started successfully on port {port}")
    else:
        # Wait briefly for the thread to fully die so thread_err has a chance to populate
        ws_thread.join(timeout=1)
        if thread_err.get("err"):
            etype, emsg = thread_err["err"]
            logging.error(
                f"[VNC] startup failed — thread died with {etype}: {emsg}. "
                f"Port {port} will NOT be bound. Console connections to this server will fail. "
                f"Most common causes: (a) port already in use by another process, "
                f"(b) websockets library version mismatch (need ≥11.0; we expect "
                f"the post-13.x process_request signature), "
                f"(c) AppArmor/SELinux blocking the bind, "
                f"(d) SSL cert path missing or unreadable. "
                f"Run: ss -tlnp | grep ':{port}'  +  pip show websockets  +  journalctl -u ProxmoxVEx -p err"
            )
        elif not ws_thread.is_alive():
            logging.error(
                f"[VNC] startup timed out — thread died silently within 5s without setting "
                f"server_ready and without raising an exception we could capture. "
                f"Port {port} will NOT be bound. Probable causes: SystemExit / os._exit "
                f"in a downstream import or a fatal C-level signal. "
                f"Run: journalctl -u ProxmoxVEx --since '1 minute ago'"
            )
        else:
            logging.warning(
                f"[VNC] startup slow — server_ready not set after 5s but thread is still alive. "
                f"Port {port} may bind shortly. If it never does, the asyncio event loop "
                f"is likely blocked at startup."
            )


# Keep flask-sock version as backup (renamed)
@sock.route("/api/clusters/<cluster_id>/vms/<node>/<vm_type>/<int:vmid>/vncwebsocket")
def vnc_websocket_proxy(ws, cluster_id, node, vm_type, vmid):
    """WebSocket proxy for VNC connection via Flask-Sock (same port as main app)"""
    from gevent import sleep as gsleep
    from gevent import spawn

    logging.info(f"\n{'=' * 60}")
    logging.info(f"VNC WEBSOCKET: {vm_type}/{vmid} on {node}")
    logging.info(f"{'=' * 60}")
    # Prefer WS token, session as legacy fallback
    from ProxmoxVEx.utils.realtime import validate_ws_token

    ws_token = request.args.get("token")
    session_id = request.args.get("session")

    auth_user = None
    if ws_token:
        token_data = validate_ws_token(ws_token)
        if not token_data:
            with contextlib.suppress(BaseException):
                ws.send("Invalid or expired token")
            return
        # (perf) indexed single-row fetch — load_users() scanned/decrypted all users
        user = get_user_record(token_data["user"])
        get_user_permissions(user)
        # #537/RBAC: coarse "global vm.console OR admin" pre-check dropped — _console_authz below is authoritative.
        auth_user = token_data["user"]
    elif session_id:
        session = validate_session(session_id)
        if not session:
            with contextlib.suppress(BaseException):
                ws.send("Invalid session")
            return
        # (perf) indexed single-row fetch — load_users() scanned/decrypted all users
        user = get_user_record(session["user"])
        get_user_permissions(user)
        # #537/RBAC: coarse pre-check dropped — _console_authz below is authoritative.
        auth_user = session["user"]
    else:
        with contextlib.suppress(BaseException):
            ws.send("Authentication required")
        return

    logging.info(f"User {auth_user} authenticated for VNC")
    # H-1/H-2: cluster + per-VM gate before this proxy self-mints a PVE ticket
    user["username"] = auth_user
    _ok, _why = _console_authz(user, cluster_id, vmid, vm_type)
    if not _ok:
        with contextlib.suppress(BaseException):
            ws.send("Permission denied")
        return

    # 2026-06-04 (PR #523 / Aikido SSRF triage): `node` flows raw into the
    # PVE vncproxy URL path below. The route's string converter blocks '/'
    # but not '..', so a crafted node could path-manipulate the request on the
    # (trusted) PVE host. Validate against the same node-name shape api/nodes.py
    # uses (_NODE_NAME_RE). vmid is already int-safe via the <int:vmid> route
    # converter, and vm_type only ever reaches the URL through the qemu/lxc
    # if/else — node is the only raw segment. (Closed the Aikido PR in favour
    # of this: its vm_type regex would have regressed the qemu/lxc normalisation.)
    if not re.match(r"^[a-zA-Z][a-zA-Z0-9.\-]{0,62}$", node or "") or vm_type not in ("qemu", "lxc"):
        with contextlib.suppress(BaseException):
            ws.send("Invalid node or vm_type")
        return

    if cluster_id not in cluster_managers:
        logging.error(f"ERROR: Cluster {cluster_id} not found")
        return

    manager = cluster_managers[cluster_id]
    host, port = manager.host, manager.api_port

    logging.info(f"Target host: {host}")
    pve_ws = None
    running = True

    try:
        import json
        import urllib.parse
        import urllib.request

        import websocket

        # Create SSL context
        ssl_context = ssl.create_default_context()
        # (CodeAnt) - gate TLS verify on the per-cluster ssl_verify flag
        # (default off: PVE ships self-signed; honoured when the admin enables it).
        _verify_tls = bool(getattr(manager, "_ssl_verify", False))
        if not _verify_tls:
            ssl_context.check_hostname = False
            ssl_context.verify_mode = ssl.CERT_NONE

        # Step 1: Login
        logging.info("Step 1: Login...")
        login_data = urlencode({"username": manager.config.user, "password": manager.config.pass_}).encode("utf-8")

        login_req = urllib.request.Request(
            _pve_url(f"https://{host}:{port}/api2/json/access/ticket"), data=login_data, method="POST"
        )

        with urllib.request.urlopen(login_req, context=ssl_context, timeout=10) as response:
            login_result = json.loads(response.read().decode("utf-8"))

        pve_ticket = login_result["data"]["ticket"]
        csrf_token = login_result["data"]["CSRFPreventionToken"]
        logging.info("Got PVE ticket")
        # (#352 follow-up) - single-vncproxy mode. If the JS
        # already got a vncproxy ticket+port via /console, reuse it so the VNC
        # password noVNC uses matches the password PVE's vncterm expects. PVE
        # 9.1.x generates fresh random VNC password per vncproxy call.
        pve_port_q = request.args.get("pve_port")
        pve_ticket_q = request.args.get("pve_ticket")
        _ppt_ok, _ppt_port = _safe_vnc_passthrough(pve_port_q, pve_ticket_q)
        if pve_port_q and pve_ticket_q and _ppt_ok:
            vnc_ticket = pve_ticket_q
            port = _ppt_port
            logging.info(f"Reusing JS-issued vncproxy ticket port={port}")
        else:
            logging.info("Step 2: Get VNC ticket...")
            if vm_type == "qemu":
                vnc_url = f"https://{host}:{port}/api2/json/nodes/{node}/qemu/{vmid}/vncproxy"
            else:
                vnc_url = f"https://{host}:{port}/api2/json/nodes/{node}/lxc/{vmid}/vncproxy"
            vnc_data = urlencode({"websocket": "1"}).encode("utf-8")
            vnc_req = urllib.request.Request(_pve_url(vnc_url), data=vnc_data, method="POST")
            vnc_req.add_header("Cookie", f"PVEAuthCookie={pve_ticket}")
            vnc_req.add_header("CSRFPreventionToken", csrf_token)
            with urllib.request.urlopen(vnc_req, context=ssl_context, timeout=10) as response:
                vnc_result = json.loads(response.read().decode("utf-8"))
            vnc_ticket = vnc_result["data"]["ticket"]
            port = vnc_result["data"]["port"]
            logging.info(f"Got VNC ticket, port={port} (no JS pass-through — PVE 9.1.x users may hit issue #352)")
        # Step 3: Connect to Proxmox WebSocket
        logging.info("Step 3: Connect to Proxmox...")
        encoded_vnc_ticket = url_quote(vnc_ticket, safe="")

        if vm_type == "qemu":
            pve_ws_path = f"/api2/json/nodes/{node}/qemu/{vmid}/vncwebsocket?port={port}&vncticket={encoded_vnc_ticket}"
        else:
            pve_ws_path = f"/api2/json/nodes/{node}/lxc/{vmid}/vncwebsocket?port={port}&vncticket={encoded_vnc_ticket}"

        pve_ws_url = f"wss://{host}:{port}{pve_ws_path}"

        pve_ws = websocket.create_connection(
            pve_ws_url,
            sslopt=({} if _verify_tls else {"cert_reqs": ssl.CERT_NONE}),
            header={"Cookie": f"PVEAuthCookie={pve_ticket}"},
            subprotocols=["binary"],
            timeout=VNC_PVE_CONNECT_TIMEOUT,
        )
        # TCP_NODELAY + keepalive (consolidated helper)
        _apply_vnc_socket_options(pve_ws.sock)

        logging.info("✓ Connected!")
        pve_ws.settimeout(0.1)

        bytes_sent = 0
        bytes_received = 0

        # Greenlet to read from Proxmox and send to client
        def proxmox_to_client():
            nonlocal bytes_received, running
            try:
                while running:
                    try:
                        data = pve_ws.recv()
                        if data:
                            bytes_received += len(data)
                            ws.send(data)
                    except websocket.WebSocketTimeoutException:
                        gsleep(0.01)
                    except websocket.WebSocketConnectionClosedException:
                        logging.info("Proxmox closed")
                        running = False
                        break
                    except Exception as e:
                        if running:
                            logging.error(f"PVE->Client error: {e}")
                        running = False
                        break
            except Exception as e:
                logging.error(f"proxmox_to_client crashed: {e}")
                running = False

        # Start the proxmox reader greenlet
        pve_reader = spawn(proxmox_to_client)

        logging.info("Step 4: Proxy running...")
        # Main loop: read from client, send to Proxmox
        while running:
            try:
                data = ws.receive(timeout=0.1)
                if data is None:
                    logging.info("Client disconnected")
                    running = False
                    break
                if data:
                    bytes_sent += len(data)
                    pve_ws.send(data)
            except TimeoutError:
                gsleep(0.01)
            except Exception as e:
                if "timed out" not in str(e).lower() and "timeout" not in str(e).lower():
                    logging.error(f"Client->PVE error: {e}")
                    running = False
                    break
                gsleep(0.01)

        running = False
        pve_reader.kill()

        logging.info(f"Session ended: sent {bytes_sent}, received {bytes_received}")
    except Exception as e:
        logging.exception(f"SSH proxy error: {type(e).__name__}: {e}")
    finally:
        running = False
        if pve_ws:
            with contextlib.suppress(Exception):
                pve_ws.close()
        logging.info(f"{'=' * 60}\n")


# Proxmox built-in termproxy (xterm.js) for LXC + QEMU.
# Same idea as the VNC proxy above but talks PVE's text-frame termproxy
# protocol instead of RFB. No second login: the ProxmoxVEx session is
# already trusted to act as the cluster admin user, so we log into PVE
# server-side, fetch the termproxy ticket, send the `user:ticket\n`
# handshake to PVE on behalf of the browser, then bidirectionally proxy
# bytes between the ProxmoxVEx client WS and the PVE WS.
#
# Wire protocol (verbatim from pve-xtermjs/src/www/main.js):
#   client → PVE  (after auth):  "0:<len>:<data>"  (xterm input bytes)
#                                "1:<cols>:<rows>:" (resize, no body)
#                                "2"               (keepalive, optional)
#   PVE → client (after auth):   raw text bytes (TTY output, no framing)
#                                first message after handshake: "OK"
#
# Our wrapper handles the framing on both sides so the browser-side
# component is plain xterm.js with no PVE-specific glue.
@bp.route("/api/clusters/<cluster_id>/vms/<node>/<vm_type>/<int:vmid>/termproxy", methods=["POST"])
@require_auth(perms=["vm.console"])
def get_termproxy_ticket_api(cluster_id, node, vm_type, vmid):
    """issues a PVE termproxy ticket for a VM/CT.

    Server-side: log into PVE with cluster credentials (NOT API token, since
    termproxy needs a real session cookie), POST /termproxy, return both the
    auth_ticket (used as PVEAuthCookie) and the termproxy_ticket (used as
    ?vncticket=) so the standalone WS server can complete the handshake.
    """
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()
    if cluster_id not in cluster_managers:
        # lgtm[py/reflected-xss]
        return jsonify({"error": "Cluster not found"}), 404
    if vm_type not in ("qemu", "lxc"):
        # lgtm[py/reflected-xss]
        return jsonify({"error": "Unsupported vm_type"}), 400

    # H-1/H-2: per-VM gate (cluster access alone isn't enough for a console)
    from flask import g as _g

    _u = getattr(_g, "current_user", None)
    if _u is None:
        _u = get_user_record(request.session.get("user", ""))
    _u = dict(_u)
    _u["username"] = request.session.get("user", "")
    _ok2, _why2 = _console_authz(_u, cluster_id, vmid, vm_type)
    if not _ok2:
        # lgtm[py/reflected-xss]
        return jsonify({"error": "Permission denied: no access to this VM"}), 403

    mgr = cluster_managers[cluster_id]
    pve_pwd = getattr(mgr.config, "pass_", None) or getattr(mgr.config, "password", None)
    pve_usr = getattr(mgr.config, "user", None) or "root@pam"
    if not pve_pwd:
        # lgtm[py/reflected-xss]
        return jsonify({
            "error": "Cluster has no stored password — termproxy needs user/pass auth (API tokens cannot mint termproxy tickets)."
        }), 400

    import ssl as _ssl
    import urllib.request as _urlreq
    from urllib.parse import urlencode as _urlencode

    ssl_ctx = _ssl.create_default_context()
    # (CodeAnt) - gate TLS verify on the per-cluster ssl_verify flag
    # (default off: PVE ships self-signed; honoured when the admin enables it).
    _verify_tls = bool(getattr(mgr, "_ssl_verify", False))
    if not _verify_tls:
        ssl_ctx.check_hostname = False
        ssl_ctx.verify_mode = _ssl.CERT_NONE
    host, port = mgr.host, mgr.api_port

    # Step 1: real PVE session login
    try:
        login_req = _urlreq.Request(
            _pve_url(f"https://{host}:{port}/api2/json/access/ticket"),
            data=_urlencode({"username": pve_usr, "password": pve_pwd}).encode("utf-8"),
            method="POST",
        )
        with _urlreq.urlopen(login_req, context=ssl_ctx, timeout=10) as resp:
            login_result = json.loads(resp.read().decode("utf-8"))
        auth_ticket = login_result["data"]["ticket"]
        csrf_token = login_result["data"]["CSRFPreventionToken"]
        pve_login_user = login_result["data"].get("username") or pve_usr
    except Exception as e:
        logging.exception(f"[TERMPROXY-API] PVE login failed: {e}")
        # lgtm[py/reflected-xss]
        # snyk:ignore:Cross-site Scripting (XSS)
        return jsonify({
            "error": f"PVE login failed: {type(e).__name__}"
        }), 500  # snyk:ignore:Cross-site Scripting (XSS)

    # Step 2: POST /termproxy with the session cookie
    try:
        if vm_type == "qemu":
            tp_url = f"https://{host}:{port}/api2/json/nodes/{node}/qemu/{vmid}/termproxy"
        else:
            tp_url = f"https://{host}:{port}/api2/json/nodes/{node}/lxc/{vmid}/termproxy"
        tp_req = _urlreq.Request(_pve_url(tp_url), data=b"", method="POST")
        tp_req.add_header("Cookie", f"PVEAuthCookie={auth_ticket}")
        tp_req.add_header("CSRFPreventionToken", csrf_token)
        with _urlreq.urlopen(tp_req, context=ssl_ctx, timeout=10) as resp:
            tp_result = json.loads(resp.read().decode("utf-8"))
        term_ticket = tp_result["data"]["ticket"]
        term_port = tp_result["data"]["port"]
        term_user = tp_result["data"].get("user") or pve_login_user
    except Exception as e:
        logging.exception(f"[TERMPROXY-API] termproxy ticket failed: {e}")
        # lgtm[py/reflected-xss]
        # snyk:ignore:Cross-site Scripting (XSS)
        return jsonify({
            "error": f"termproxy ticket failed: {type(e).__name__}"
        }), 500  # snyk:ignore:Cross-site Scripting (XSS)

    log_audit(
        request.session.get("user", "unknown"),
        "vm.terminal",
        f"Terminal opened: {vm_type}/{vmid} on {node}",
        cluster=getattr(mgr.config, "name", cluster_id),
    )

    # 2026-06-05 (security audit C-1): the PVE session ticket (auth_ticket =
    # PVEAuthCookie = effectively root on pve:8006) is NO LONGER returned to the
    # browser. The standalone WS subprocess fetches it server-side via the
    # cluster-creds / ws-token-validate internal path right before the PVE WS
    # connect. Only the per-console termproxy ticket (scoped to this vmid:port)
    # leaves to the client.
    # lgtm[py/reflected-xss]
    return jsonify({
        "success": True,
        "host": host,
        "port": term_port,
        "ticket": term_ticket,
        "user": term_user,
        "node": node,
        "vmid": vmid,
        "vm_type": vm_type,
    })


# Terminal/Shell WebSocket proxy (legacy - flask-sock version, kept for non-gevent setups)
@sock.route("/api/clusters/<cluster_id>/nodes/<node>/shellws")
def node_shell_websocket_proxy(ws, cluster_id, node):
    """WebSocket proxy for node shell via SSH"""

    # Feb 2026: Authentication + authorization (was missing entirely - critical security fix)
    # Prefer single-use WS token, session as legacy fallback
    from ProxmoxVEx.utils.realtime import validate_ws_token

    ws_token = request.args.get("token")
    session_id = request.args.get("session")

    if ws_token:
        token_data = validate_ws_token(ws_token)
        if not token_data:
            logging.error("SHELL WS: Invalid or expired token")
            with contextlib.suppress(Exception):
                ws.send('{"status":"error","message":"Invalid or expired token"}')
            return
        session = {"user": token_data["user"]}
    elif session_id:
        valid_session = validate_session(session_id)
        if not valid_session:
            logging.error("SHELL WS: Invalid session")
            with contextlib.suppress(Exception):
                ws.send('{"status":"error","message":"Invalid session"}')
            return
        session = valid_session
    else:
        logging.error("SHELL WS: No token or session provided")
        with contextlib.suppress(Exception):
            ws.send('{"status":"error","message":"Authentication required"}')
        return

    # Check permissions - require node.shell or admin role
    # (perf) indexed single-row fetch — load_users() scanned/decrypted all users
    user = get_user_record(session["user"])
    user_perms = get_user_permissions(user)
    # 2026-06-10 (RBAC): gate on the node.shell perm only - admin holds it via
    # all-perms so the explicit admin bypass was redundant; a custom role with node.shell now works.
    if "node.shell" not in user_perms:
        logging.error(f"SHELL WS: User {session['user']} lacks node.shell permission")
        with contextlib.suppress(Exception):
            ws.send('{"status":"error","message":"Permission denied"}')
        return

    # Check cluster access based on user's allowed clusters
    from ProxmoxVEx.utils.rbac import get_user_clusters

    allowed_clusters = get_user_clusters(user)
    if allowed_clusters is not None and cluster_id not in allowed_clusters:
        logging.error(f"SHELL WS: User {session['user']} denied access to cluster {cluster_id}")
        with contextlib.suppress(Exception):
            ws.send('{"status":"error","message":"Access denied to this cluster"}')
        return

    logging.info(f"SHELL WS: User {session['user']} authenticated for shell on {cluster_id}/{node}")

    logging.info("")
    logging.info("========================================")
    logging.info(f"SSH SHELL: {cluster_id}/{node}")
    logging.info("========================================")

    # Check paramiko availability first
    try:
        import paramiko
    except ImportError:
        logging.error("paramiko not installed!")
        with contextlib.suppress(Exception):
            ws.send('{"status":"error","message":"SSH library (paramiko) not installed on server"}')
        return

    if cluster_id not in cluster_managers:
        logging.error(f"Cluster {cluster_id} not found")
        with contextlib.suppress(Exception):
            ws.send('{"status":"error","message":"Cluster not found"}')
        return

    manager = cluster_managers[cluster_id]
    cluster_host = manager.config.host
    cluster_port = getattr(manager.config, "port", 8006)

    # Get node IP address from cluster status
    logging.info(f"Step 1: Getting IP for node {node}...")

    # First authenticate with cluster
    if not manager.connect_to_proxmox():
        logging.error("Failed to authenticate with cluster!")
        with contextlib.suppress(Exception):
            ws.send('{"status":"error","message":"Cluster auth failed"}')
        return

    node_ip = None
    try:
        cluster_url = f"https://{cluster_host}:{cluster_port}/api2/json/cluster/status"
        cluster_response = manager._create_session().get(cluster_url, timeout=5)
        if cluster_response.status_code == 200:
            cluster_data = cluster_response.json().get("data", [])
            for item in cluster_data:
                if item.get("type") == "node" and item.get("name") == node:
                    node_ip = item.get("ip")
                    logging.info(f"  Found node IP: {node_ip}")
                    break
    except Exception as e:
        logging.error(f"  Error getting cluster status: {e}")

    if not node_ip:
        prefetched_ip = (request.args.get("ip") or "").strip()
        if prefetched_ip:
            node_ip = prefetched_ip
            logging.info(f"  Using frontend-provided IP: {node_ip}")

    if not node_ip:
        node_ip = cluster_host
        logging.info(f"  Using cluster host: {node_ip}")

    # Request credentials from client
    try:
        ws.send(f'{{"status":"need_credentials","node":"{node}","ip":"{node_ip}"}}')
    except Exception as e:
        logging.error(f"Failed to send need_credentials: {e}")
        return

    logging.info("Step 2: Waiting for SSH credentials...")

    # Wait for credentials from client
    try:
        cred_msg = ws.receive(timeout=60)
        if not cred_msg:
            logging.error("No credentials received")
            return

        creds = json.loads(cred_msg)
        ssh_user = creds.get("username", "root")
        ssh_pass = creds.get("password", "")
        ssh_key = creds.get("privateKey", "")
        user_host = (creds.get("host") or "").strip()
        if user_host:
            node_ip = user_host
            logging.info(f"  Using user-provided host: {node_ip}")

        if not ssh_pass and not ssh_key:
            with contextlib.suppress(Exception):
                ws.send('{"status":"error","message":"Password or SSH key required"}')
            return

        logging.info(f"  Got credentials for user: {ssh_user}")

    except Exception as e:
        logging.error(f"Error receiving credentials: {e}")
        with contextlib.suppress(Exception):
            ws.send('{"status":"error","message":"Credentials timeout"}')
        return

    # Tell client we're connecting
    try:
        ws.send('{"status":"connecting"}')
    except Exception as _e:
        return

    logging.info(f"Step 3: Connecting SSH to {ssh_user}@{node_ip}...")

    # bound before the try so the finally's cleanup can reference them even if
    # SSHClient()/connect() raises
    ssh = None
    channel = None
    try:
        # Create SSH client
        ssh = paramiko.SSHClient()
        apply_ssh_host_key_policy(ssh)

        # Prefer SSH key authentication if a key was provided
        if ssh_key:
            import io

            key_file = io.StringIO(ssh_key)
            pkey = None
            for key_class in [
                paramiko.RSAKey,
                paramiko.Ed25519Key,
                paramiko.ECDSAKey,
                getattr(paramiko, "DSSKey", None),
            ]:
                if key_class is None:
                    continue
                try:
                    key_file.seek(0)
                    pkey = key_class.from_private_key(key_file, password=ssh_pass if ssh_pass else None)
                    break
                except Exception:
                    continue
            if pkey is None:
                with contextlib.suppress(Exception):
                    ws.send('{"status":"error","message":"Could not parse SSH key"}')
                return
            ssh.connect(
                hostname=node_ip,
                port=22,
                username=ssh_user,
                pkey=pkey,
                timeout=30,
                allow_agent=False,
                look_for_keys=False,
            )
        else:
            # Password authentication
            ssh.connect(
                hostname=node_ip,
                port=22,
                username=ssh_user,
                password=ssh_pass,
                timeout=30,
                allow_agent=False,
                look_for_keys=False,
            )

        logging.info("Step 4: SSH connected! Opening shell...")

        # Get interactive shell
        channel = ssh.invoke_shell(term="xterm-256color", width=120, height=40)
        channel.settimeout(0.1)

        ws.send('{"status":"connected"}')
        logging.info("Step 5: Shell ready!")

        stop_event = threading.Event()

        # Thread: SSH -> WebSocket
        def ssh_to_ws():
            try:
                while not stop_event.is_set():
                    try:
                        if channel.recv_ready():
                            data = channel.recv(4096)
                            if data:
                                ws.send(data)
                        else:
                            import time

                            time.sleep(0.01)
                    except socket.timeout:
                        continue
                    except Exception as e:
                        logging.error(f"SSH recv error: {e}")
                        break
            except Exception as _e:
                pass
            finally:
                stop_event.set()

        ssh_thread = threading.Thread(target=ssh_to_ws)
        ssh_thread.daemon = True
        ssh_thread.start()

        # Main loop: WebSocket -> SSH
        while not stop_event.is_set():
            try:
                data = ws.receive()
                if data is None:
                    logging.info("Client disconnected")
                    break

                # Handle JSON messages
                if isinstance(data, str) and data.startswith("{"):
                    try:
                        msg = json.loads(data)
                        # Handle resize
                        if msg.get("type") == "resize":
                            channel.resize_pty(width=msg.get("cols", 120), height=msg.get("rows", 40))
                        continue
                    except Exception as _e:
                        pass

                # Send to SSH — paramiko Channel.send wants bytes; encode text frames
                if isinstance(data, str):
                    channel.send(data.encode("utf-8"))
                else:
                    channel.send(data)

            except Exception as e:
                logging.error(f"WS recv error: {e}")
                break

        stop_event.set()

    except paramiko.AuthenticationException:
        logging.error("SSH authentication failed!")
        ws.send('{"status":"error","message":"SSH login failed - wrong username or password"}')
    except paramiko.SSHException as e:
        logging.error(f"SSH error: {e}")
        ws.send(f'{{"status":"error","message":"SSH error: {str(e)}"}}')
    except Exception as e:
        logging.exception(f"Shell error: {e}")
        ws.send(f'{{"status":"error","message":"{str(e)}"}}')
    finally:
        with contextlib.suppress(Exception):
            if channel is not None:
                channel.close()
        with contextlib.suppress(Exception):
            if ssh is not None:
                ssh.close()
        logging.info("========================================")
        logging.info(f"SSH SESSION ENDED: {node}")
        logging.info("========================================")
