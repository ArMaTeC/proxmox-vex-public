# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/api/vms/node_mgmt.py
# Project:     ProxmoxVEx
# Version:     1.2.565
# Build:       2026.09.30
# Description: node_mgmt routes for the vms API (split from
#              api/vms.py).
# Usage:       import ProxmoxVEx.api.vms.node_mgmt
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-30
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""node_mgmt routes for the vms API (split from api/vms.py)."""

import logging
import re
import shlex
import socket
import threading
import time

from flask import jsonify

from ProxmoxVEx.api.helpers import check_cluster_access, get_connected_manager
from ProxmoxVEx.core.config import save_config
from ProxmoxVEx.globals import cluster_managers
from ProxmoxVEx.utils.audit import log_audit
from ProxmoxVEx.utils.auth import require_auth
from ProxmoxVEx.utils.realtime import broadcast_action
from ProxmoxVEx.utils.sanitization import sanitize_int
from ProxmoxVEx.utils.ssh import apply_ssh_host_key_policy, get_paramiko
from ProxmoxVEx.utils.stepup import require_stepup

from .common import (
    _access_denied,
    _api_error,
    _cluster_not_connected,
    _cluster_not_found,
    _validate_host,
    bp,
    request,
)


# Resource Mappings API
@bp.route("/api/clusters/<cluster_id>/datacenter/mapping/pci", methods=["GET"])
@require_auth(perms=["cluster.view"])
def get_pci_mappings(cluster_id):
    """Get PCI device mappings"""
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()
    manager, _ = get_connected_manager(cluster_id)
    if not manager:
        if cluster_id not in cluster_managers:
            return _cluster_not_found()
        return _cluster_not_connected()

    try:
        host, port = manager.host, manager.api_port
        url = f"https://{host}:{port}/api2/json/cluster/mapping/pci"
        response = manager._create_session().get(url, timeout=5)

        if response.status_code == 200:
            # lgtm[py/reflected-xss]
            return jsonify(response.json().get("data", []))
        # lgtm[py/reflected-xss]
        return jsonify([])
    except Exception:
        return _api_error("Failed to get PCI mappings", status=500)


@bp.route("/api/clusters/<cluster_id>/datacenter/mapping/usb", methods=["GET"])
@require_auth(perms=["cluster.view"])
def get_usb_mappings(cluster_id):
    """Get USB device mappings"""
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()
    manager, _ = get_connected_manager(cluster_id)
    if not manager:
        if cluster_id not in cluster_managers:
            return _cluster_not_found()
        return _cluster_not_connected()

    try:
        host, port = manager.host, manager.api_port
        url = f"https://{host}:{port}/api2/json/cluster/mapping/usb"
        response = manager._create_session().get(url, timeout=5)

        if response.status_code == 200:
            # lgtm[py/reflected-xss]
            return jsonify(response.json().get("data", []))
        # lgtm[py/reflected-xss]
        return jsonify([])
    except Exception:
        return _api_error("Failed to get USB mappings", status=500)


# Maintenance Mode API Routes
@bp.route("/api/clusters/<cluster_id>/nodes/<node_name>/maintenance-preview", methods=["GET"])
@require_auth(perms=["node.maintenance"])
def maintenance_capacity_preview_api(cluster_id, node_name):
    # #611 — read-only pre-flight: does evacuating this node overcommit the
    # remaining nodes' RAM past `threshold`? Non-blocking hint for the UI.
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()
    if cluster_id not in cluster_managers:
        # lgtm[py/reflected-xss]
        return jsonify({"error": "Cluster not found"}), 404
    mgr = cluster_managers[cluster_id]
    try:
        threshold = float(request.args.get("threshold", 90))
    except (TypeError, ValueError):
        threshold = 90.0
    threshold = max(1.0, min(100.0, threshold))
    try:
        # lgtm[py/reflected-xss]
        return jsonify(mgr.maintenance_capacity_preview(node_name, threshold=threshold))
    except Exception:
        return _api_error("Failed to compute maintenance preview", status=500)


@bp.route("/api/clusters/<cluster_id>/nodes/<node_name>/maintenance", methods=["PUT"])
@require_auth(perms=["node.maintenance"])
def set_maintenance_mode(cluster_id, node_name):
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()

    if cluster_id not in cluster_managers:
        # lgtm[py/reflected-xss]
        return jsonify({"error": "Cluster not found"}), 404

    mgr = cluster_managers[cluster_id]
    data = request.json or {}
    enable = data.get("enable", True)
    skip_evacuation = data.get("skip_evacuation", False)  # For non-reboot updates
    usr = getattr(request, "session", {}).get("user", "system")

    if enable:
        task = mgr.enter_maintenance_mode(node_name, skip_evacuation=skip_evacuation)

        if skip_evacuation:
            log_audit(
                usr,
                "node.maintenance_entered",
                f"Node {node_name} entered maintenance mode (skip_evacuation=True)",
                cluster=mgr.config.name,
            )
            broadcast_action(
                "maintenance_enter",
                "node",
                node_name,
                {"status": "completed", "skip_evacuation": True},
                cluster_id,
                usr,
            )
        else:
            log_audit(
                usr, "node.maintenance_entered", f"Node {node_name} entered maintenance mode", cluster=mgr.config.name
            )
            broadcast_action("maintenance_enter", "node", node_name, {"status": "evacuating"}, cluster_id, usr)

        # lgtm[py/reflected-xss]
        return jsonify({
            "message": f"Entering maintenance mode for {node_name}",
            "skip_evacuation": skip_evacuation,
            "warning": "VMs not evacuated - they may be affected if update fails!" if skip_evacuation else None,
            "task": task.to_dict(),
        })
    else:
        success = mgr.exit_maintenance_mode(node_name)
        if success:
            log_audit(
                usr, "node.maintenance_exited", f"Node {node_name} exited maintenance mode", cluster=mgr.config.name
            )
            broadcast_action("maintenance_exit", "node", node_name, {}, cluster_id, usr)
            # lgtm[py/reflected-xss]
            return jsonify({"message": f"Exited maintenance mode for {node_name}"})
        else:
            # lgtm[py/reflected-xss]
            # snyk:ignore:Cross-site Scripting (XSS)
            return jsonify({
                "error": f"Node {node_name} is not in maintenance mode"
            }), 400  # snyk:ignore:Cross-site Scripting (XSS)


@bp.route("/api/clusters/<cluster_id>/nodes/<node_name>/maintenance", methods=["GET"])
@require_auth(perms=["node.view"])
def get_maintenance_status(cluster_id, node_name):
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()

    if cluster_id not in cluster_managers:
        # lgtm[py/reflected-xss]
        return jsonify({"error": "Cluster not found"}), 404

    mgr = cluster_managers[cluster_id]
    # Force-refresh from PVE so we don't return stale data
    mgr.refresh_maintenance_status()
    status = mgr.get_maintenance_status(node_name)

    # lgtm[py/reflected-xss]
    return jsonify(status if status else {"maintenance_mode": False})


@bp.route("/api/clusters/<cluster_id>/nodes/<node_name>/maintenance", methods=["DELETE"])
@require_auth(perms=["node.maintenance"])
def exit_maintenance_mode_api(cluster_id, node_name):
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()

    if cluster_id not in cluster_managers:
        # lgtm[py/reflected-xss]
        return jsonify({"error": "Cluster not found"}), 404

    mgr = cluster_managers[cluster_id]
    success = mgr.exit_maintenance_mode(node_name)
    usr = getattr(request, "session", {}).get("user", "system")

    if success:
        log_audit(usr, "node.maintenance_exited", f"Node {node_name} exited maintenance mode", cluster=mgr.config.name)
        broadcast_action("maintenance_exit", "node", node_name, {}, cluster_id, usr)
        # lgtm[py/reflected-xss]
        return jsonify({"message": f"Exited maintenance mode for {node_name}"})
    else:
        # lgtm[py/reflected-xss]
        # snyk:ignore:Cross-site Scripting (XSS)
        return jsonify({
            "error": f"Node {node_name} is not in maintenance mode"
        }), 400  # snyk:ignore:Cross-site Scripting (XSS)


@bp.route("/api/clusters/<cluster_id>/nodes/<node_name>/maintenance/acknowledge", methods=["POST"])
@require_auth(perms=["node.maintenance"])
def acknowledge_maintenance_warning(cluster_id, node_name):
    """Acknowledge maintenance warning (e.g., when some VMs couldn't migrate)"""
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()
    if cluster_id not in cluster_managers:
        # lgtm[py/reflected-xss]
        return jsonify({"error": "Cluster not found"}), 404

    manager = cluster_managers[cluster_id]

    # Store acknowledgment in maintenance task
    if node_name in manager.nodes_in_maintenance:
        manager.nodes_in_maintenance[node_name].acknowledged = True

        user = getattr(request, "session", {}).get("user", "system")
        log_audit(
            user,
            "node.maintenance_acknowledged",
            f"User acknowledged maintenance warning for {node_name}",
            cluster=manager.config.name,
        )

        # Broadcast update
        broadcast_action("maintenance_acknowledged", "node", node_name, {}, cluster_id, user)

        # lgtm[py/reflected-xss]
        return jsonify({"message": f"Maintenance warning acknowledged for {node_name}"})
    else:
        # lgtm[py/reflected-xss]
        # snyk:ignore:Cross-site Scripting (XSS)
        return jsonify({
            "error": f"Node {node_name} is not in maintenance mode"
        }), 400  # snyk:ignore:Cross-site Scripting (XSS)


# =============================================================================
# NODE CLUSTER MANAGEMENT API - Join/Remove nodes from cluster
# Added by Node Management Integration
# =============================================================================


@bp.route("/api/clusters/<cluster_id>/nodes/join/test", methods=["POST"])
@require_auth(perms=["cluster.admin"])
def test_node_connection(cluster_id):
    """Test SSH connection to a new node and gather system info"""
    # Pre-flight check before join, also detects orphaned cluster configs
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()

    if cluster_id not in cluster_managers:
        # lgtm[py/reflected-xss]
        return jsonify({"error": "Cluster not found"}), 404

    paramiko = get_paramiko()
    if not paramiko:
        # lgtm[py/reflected-xss]
        return jsonify({"error": "SSH not available. Install paramiko: pip install paramiko"}), 500

    data = request.get_json() or {}
    node_ip = _validate_host(data.get("node_ip", ""))
    username = data.get("username", "root")
    password = data.get("password", "")
    ssh_port = sanitize_int(data.get("ssh_port", 22), default=22, min_val=1, max_val=65535)

    if not node_ip:
        # lgtm[py/reflected-xss]
        return jsonify({
            "success": False,
            "error": "Node IP is required (must be a valid hostname or IP address)",
        }), 400  # snyk:ignore:Cross-site Scripting (XSS)
    if not password:
        # lgtm[py/reflected-xss]
        return jsonify({
            "success": False,
            "error": "SSH password is required",
        }), 400  # snyk:ignore:Cross-site Scripting (XSS)

    try:
        # Connect via SSH
        ssh = paramiko.SSHClient()
        apply_ssh_host_key_policy(ssh)
        ssh.connect(node_ip, port=ssh_port, username=username, password=password, timeout=15)

        # Get hostname
        stdin, stdout, stderr = ssh.exec_command("hostname")
        hostname = stdout.read().decode().strip()

        # Check if Proxmox is installed
        stdin, stdout, stderr = ssh.exec_command('pveversion 2>/dev/null || echo "NOT_INSTALLED"')
        pve_output = stdout.read().decode().strip()
        proxmox_installed = "NOT_INSTALLED" not in pve_output
        proxmox_version = pve_output if proxmox_installed else None

        # Check if already in a cluster
        stdin, stdout, stderr = ssh.exec_command('pvecm status 2>/dev/null || echo "NO_CLUSTER"')
        cluster_output = stdout.read().decode().strip()
        already_in_cluster = "NO_CLUSTER" not in cluster_output and "Cluster information" in cluster_output

        current_cluster = None
        if already_in_cluster:
            # Extract cluster name
            for line in cluster_output.split("\n"):
                if "Cluster Name:" in line:
                    current_cluster = line.split(":")[1].strip()
                    break

        # Check for orphaned cluster config files
        # /etc/PVE/ is a FUSE mount (pmxcfs), test -f doesn't always work there
        # so we also use ls and check for leftover node directories
        stdin, stdout, stderr = ssh.exec_command(
            "test -f /etc/corosync/authkey && echo HAS_AUTHKEY; "
            "test -f /etc/corosync/corosync.conf && echo HAS_COROSYNC; "
            "ls /etc/pve/corosync.conf 2>/dev/null && echo HAS_PVE_COROSYNC; "
            "ls /etc/pve/nodes/ 2>/dev/null | wc -l"
        )
        orphan_output = stdout.read().decode().strip()
        has_old_config = (
            "HAS_AUTHKEY" in orphan_output or "HAS_COROSYNC" in orphan_output or "HAS_PVE_COROSYNC" in orphan_output
        )

        # Check if /etc/pve/nodes/ has dirs for other nodes (leftover from old cluster)
        try:
            lines = orphan_output.strip().split("\n")
            node_dir_count = int(lines[-1]) if lines[-1].isdigit() else 0
            if node_dir_count > 1:
                has_old_config = True
        except Exception as _e:
            pass

        ssh.close()

        # lgtm[py/reflected-xss]
        return jsonify({
            "success": True,
            "info": {
                "hostname": hostname,
                "ip": node_ip,
                "proxmox_installed": proxmox_installed,
                "proxmox_version": proxmox_version,
                "already_in_cluster": already_in_cluster,
                "current_cluster": current_cluster,
                "has_old_config": has_old_config,
            },
        })

    except paramiko.AuthenticationException:
        # lgtm[py/reflected-xss]
        return jsonify({
            "success": False,
            "error": "Authentication failed. Check username/password.",
        }), 401  # snyk:ignore:Cross-site Scripting (XSS)
    except paramiko.SSHException:
        return _api_error("SSH error", status=500, success=False)
    except socket.timeout:
        # lgtm[py/reflected-xss]
        return jsonify({
            "success": False,
            "error": "Connection timeout. Check IP and network.",
        }), 500  # snyk:ignore:Cross-site Scripting (XSS)
    except Exception:
        return _api_error("Connection failed", status=500, success=False)


@bp.route("/api/clusters/<cluster_id>/nodes/join", methods=["POST"])
@require_auth(perms=["cluster.admin"])
def join_node_to_cluster(cluster_id):
    """Add a new node to the Proxmox cluster"""
    # This uses SSH + interactive shell because pvecm add prompts for password
    # Force rejoin option added to handle nodes removed via pvecm delnode that still have stale configs
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()

    if cluster_id not in cluster_managers:
        # lgtm[py/reflected-xss]
        return jsonify({"error": "Cluster not found"}), 404

    paramiko = get_paramiko()
    if not paramiko:
        # lgtm[py/reflected-xss]
        return jsonify({"error": "SSH not available. Install paramiko: pip install paramiko"}), 500

    mgr = cluster_managers[cluster_id]
    data = request.get_json() or {}

    node_ip = _validate_host(data.get("node_ip", ""))
    username = data.get("username", "root")
    password = data.get("password", "")
    ssh_port = sanitize_int(data.get("ssh_port", 22), default=22, min_val=1, max_val=65535)
    link0_address = data.get("link0_address", "").strip()
    force_rejoin = data.get("force", False)  # Clean old cluster config before join

    if not node_ip or not password:
        # lgtm[py/reflected-xss]
        return jsonify({
            "success": False,
            "error": "Node IP and password are required",
        }), 400  # snyk:ignore:Cross-site Scripting (XSS)

    try:
        # Get join information from existing cluster
        # Use direct API call (same as get_join_info which works)
        # instead of api_request() wrapper which was silently failing
        host, port = mgr.host, mgr.api_port
        join_url = f"https://{host}:{port}/api2/json/cluster/config/join"
        join_resp = mgr._create_session().get(join_url, timeout=10)

        if join_resp.status_code != 200:
            logging.error(f"Join info API returned {join_resp.status_code}: {join_resp.text[:500]}")
            # lgtm[py/reflected-xss]
            return jsonify({
                "success": False,
                "error": f"Could not get cluster join information (HTTP {join_resp.status_code})",
            }), 500

        join_info = join_resp.json().get("data", {})
        logging.info(
            f"[Join] Got join info keys: {list(join_info.keys()) if isinstance(join_info, dict) else type(join_info)}"
        )

        # Extract fingerprint and join address from nodelist
        # Proxmox returns fingerprint per-node as 'pve_fp', not top-level
        fingerprint = ""
        join_addr = None

        # Check top-level first (some PVE versions)
        if isinstance(join_info, dict):
            fingerprint = join_info.get("fingerprint", "") or ""

        # Iterate nodelist for pve_fp and ring0_addr
        nodelist = join_info.get("nodelist", []) if isinstance(join_info, dict) else []
        for node_data in nodelist:
            if isinstance(node_data, dict):
                # Get fingerprint from first node that has it
                if not fingerprint and node_data.get("pve_fp"):
                    fingerprint = node_data["pve_fp"]
                # Find best node to join to
                if not join_addr and node_data.get("ring0_addr"):
                    join_addr = node_data["ring0_addr"]
                # Also try pve_addr as fallback for join address
                if not join_addr and node_data.get("pve_addr"):
                    join_addr = node_data["pve_addr"]

        if not join_addr:
            # Fallback to cluster host
            join_addr = mgr.config.host

        if not fingerprint:
            # Fallback: extract fingerprint from Proxmox SSL certificate
            # Same method as get_join_info uses - this is the cert fingerprint
            # that pvecm add --fingerprint expects
            logging.warning(f"[Join] No pve_fp in API response, extracting from SSL certificate of {host}")
            try:
                import hashlib
                import socket
                import ssl

                context = ssl.create_default_context()
                context.check_hostname = False
                context.verify_mode = ssl.CERT_NONE

                with socket.create_connection((host, 8006), timeout=5) as sock, context.wrap_socket(
                    sock, server_hostname=host
                ) as ssock:
                    cert_der = ssock.getpeercert(binary_form=True)
                    # getpeercert(binary_form=True) may return None if the peer
                    # presented no certificate — don't hash a bogus fingerprint.
                    if cert_der:
                        fp_hex = hashlib.sha256(cert_der).hexdigest()
                        fingerprint = ":".join(fp_hex[i : i + 2].upper() for i in range(0, len(fp_hex), 2))
                        logging.info(f"[Join] Got SSL fingerprint: {fingerprint[:20]}...")
            except Exception as ssl_err:
                logging.error(f"[Join] SSL fingerprint extraction failed: {ssl_err}")

        if not fingerprint:
            logging.error(
                f"[Join] No fingerprint found! join_info type={type(join_info).__name__}, "
                f"nodelist={len(nodelist)} entries, "
                f"first_node_keys={list(nodelist[0].keys()) if nodelist and isinstance(nodelist[0], dict) else 'N/A'}"
            )
            # lgtm[py/reflected-xss]
            return jsonify({
                "success": False,
                "error": "Could not get cluster fingerprint. Check server logs for details.",
            }), 500

        # Connect to new node via SSH
        ssh = paramiko.SSHClient()
        apply_ssh_host_key_policy(ssh)
        ssh.connect(node_ip, port=ssh_port, username=username, password=password, timeout=30)

        # Clean old cluster config if force rejoin
        # This is needed when a node was removed from a cluster but still has
        # old corosync/pve config files (authkey, corosync.conf, etc.)
        if force_rejoin:
            logging.info(f"[Join] Force rejoin: cleaning old cluster config on {node_ip}")
            channel = ssh.invoke_shell()
            time.sleep(0.5)
            if channel.recv_ready():
                channel.recv(4096)

            cleanup_commands = [
                "systemctl stop pve-cluster corosync 2>/dev/null",
                "sleep 1",
                "killall -9 pmxcfs 2>/dev/null",
                "sleep 1",
                "rm -f /var/lock/pve-cluster.lck /var/lock/pvecm.lock /var/lib/pve-cluster/.pmxcfs.lockfile",
                "pmxcfs -l &",
                "sleep 3",
                "rm -f /etc/corosync/authkey",
                "rm -f /etc/corosync/corosync.conf",
                "rm -f /etc/pve/corosync.conf",
                "killall -9 pmxcfs 2>/dev/null",
                "sleep 1",
                "rm -f /var/lock/pve-cluster.lck /var/lock/pvecm.lock /var/lib/pve-cluster/.pmxcfs.lockfile",
                "systemctl start pve-cluster",
                "sleep 3",
                "echo CLEANUP_DONE",
            ]
            for cmd in cleanup_commands:
                # paramiko Channel.send wants bytes (it re-encodes str via
                # asbytes internally — encode explicitly so it's type-clean)
                channel.send((cmd + "\n").encode("utf-8"))
                time.sleep(0.5)

            time.sleep(5)
            cleanup_output = ""
            for _ in range(20):
                if channel.recv_ready():
                    cleanup_output += channel.recv(4096).decode("utf-8", errors="ignore")
                if "CLEANUP_DONE" in cleanup_output:
                    break
                time.sleep(0.5)

            channel.close()
            logging.info(f"[Join] Cleanup output: {cleanup_output[-500:]}")

            # Reconnect SSH after pve-cluster restart
            ssh.close()
            time.sleep(2)
            ssh = paramiko.SSHClient()
            apply_ssh_host_key_policy(ssh)
            ssh.connect(node_ip, port=ssh_port, username=username, password=password, timeout=30)

        # Use interactive shell for pvecm add (it prompts for password)
        channel = ssh.invoke_shell()
        time.sleep(0.5)

        # Clear initial output
        if channel.recv_ready():
            channel.recv(4096)

        # Build and send the join command
        join_cmd = f"pvecm add {join_addr} --fingerprint {fingerprint}"
        if force_rejoin:
            join_cmd += " --force"
        if link0_address:
            join_cmd += f" --link0 {link0_address}"

        channel.send((join_cmd + "\n").encode("utf-8"))
        time.sleep(2)  # Wait for password prompt

        # Read output to check for password prompt
        output = ""
        for _ in range(10):
            if channel.recv_ready():
                output += channel.recv(4096).decode("utf-8", errors="ignore")
            time.sleep(0.5)
            if "password" in output.lower() or "Password" in output:
                break

        # Send password for the cluster root user
        channel.send((password + "\n").encode("utf-8"))

        # Wait for completion (join can take 30-60 seconds)
        time.sleep(5)
        full_output = output
        for _ in range(60):  # Wait up to 60 seconds
            if channel.recv_ready():
                chunk = channel.recv(4096).decode("utf-8", errors="ignore")
                full_output += chunk
                if "successfully" in chunk.lower() or "joined" in chunk.lower():
                    break
                if "error" in chunk.lower() or "failed" in chunk.lower():
                    break
            time.sleep(1)

        channel.close()
        ssh.close()

        # Check result
        if "error" in full_output.lower() or "failed" in full_output.lower():
            # Extract error message
            error_lines = [_l for _l in full_output.split("\n") if "error" in _l.lower() or "failed" in _l.lower()]
            error_msg = error_lines[0] if error_lines else "Join command failed"
            # lgtm[py/reflected-xss]
            return jsonify({
                "success": False,
                "error": error_msg,
            }), 500  # snyk:ignore:Cross-site Scripting (XSS)  # snyk:ignore:Server Information Exposure

        # Log the action
        user = getattr(request, "session", {}).get("user", "system")
        log_audit(user, "cluster.node_joined", f"Node {node_ip} joined cluster", cluster=mgr.config.name)

        # Update fallback hosts and HA after node join
        # Without this, the new node won't be a fallback target until HA's periodic 60s refresh
        def _post_join_update():
            """Background task: update fallback hosts + HA after join settles"""
            time.sleep(15)  # Wait for Proxmox cluster to sync the new node
            try:
                # Refresh connection to discover new node
                mgr.connect_to_proxmox()

                # Rediscover fallback hosts (includes the new node)
                if hasattr(mgr, "_auto_discover_fallback_hosts"):
                    old_fallbacks = list(mgr.config.fallback_hosts or [])
                    mgr._auto_discover_fallback_hosts()
                    new_fallbacks = list(mgr.config.fallback_hosts or [])
                    if old_fallbacks != new_fallbacks:
                        logging.info(
                            f"[Join] Updated fallback hosts after node join: {old_fallbacks} → {new_fallbacks}"
                        )

                # If HA is active, update its node tracking
                if hasattr(mgr, "ha_enabled") and mgr.ha_enabled:
                    if hasattr(mgr, "_ha_update_fallback_hosts"):
                        mgr._ha_update_fallback_hosts()
                    logging.info("[Join] HA fallback hosts updated after node join")

            except Exception as e:
                logging.warning(f"[Join] Post-join update error (non-critical): {e}")

        threading.Thread(target=_post_join_update, daemon=True).start()

        # lgtm[py/reflected-xss]
        return jsonify({"success": True, "message": "Node joined cluster"})

    except paramiko.AuthenticationException:
        # lgtm[py/reflected-xss]
        return jsonify({
            "success": False,
            "error": "SSH authentication failed",
        }), 401  # snyk:ignore:Cross-site Scripting (XSS)
    except Exception as e:
        logging.error(f"Error joining node to cluster: {e}")
        return _api_error("Failed to join node to cluster", status=500, success=False)


@bp.route("/api/clusters/<cluster_id>/nodes/<node_name>/can-remove", methods=["GET"])
@require_auth(perms=["cluster.admin"])
def check_can_remove_node(cluster_id, node_name):
    """Check if a node can be safely removed from the cluster"""
    # Blockers vs warnings: blockers prevent removal, warnings are recommendations
    # Offline check is a warning not a blocker because pvecm delnode runs on another node
    try:
        ok, _ = check_cluster_access(cluster_id)
        if not ok:
            return _access_denied()

        if cluster_id not in cluster_managers:
            # lgtm[py/reflected-xss]
            return jsonify({
                "can_remove": False,
                "error": "Cluster not found",
                "blockers": ["Cluster not found"],
            }), 200  # snyk:ignore:Cross-site Scripting (XSS)

        mgr = cluster_managers[cluster_id]

        # Check maintenance status
        in_maintenance = node_name in mgr.nodes_in_maintenance
        maintenance_complete = False
        if in_maintenance:
            task = mgr.nodes_in_maintenance[node_name]
            maintenance_complete = getattr(task, "status", None) in ["completed", "completed_with_errors"]

        # Check if node is offline
        is_offline = True
        try:
            host, port = mgr.host, mgr.api_port
            nodes_url = f"https://{host}:{port}/api2/json/nodes"
            nodes_resp = mgr._create_session().get(nodes_url, timeout=10)
            nodes_list = nodes_resp.json().get("data", []) if nodes_resp.status_code == 200 else []
            for n in nodes_list:
                if n.get("node") == node_name:
                    is_offline = n.get("status") != "online"
                    break
        except Exception as e:
            logging.debug(f"[RemoveNode] Could not check node status: {e}")

        # Check for VMs/CTs on the node
        has_vms = False
        vm_count = 0
        try:
            host, port = mgr.host, mgr.api_port
            session = mgr._create_session()
            resources = []
            for endpoint in [f"/nodes/{node_name}/qemu", f"/nodes/{node_name}/lxc"]:
                try:
                    r = session.get(f"https://{host}:{port}/api2/json{endpoint}", timeout=10)
                    if r.status_code == 200:
                        resources += r.json().get("data", [])
                except Exception as _e:
                    pass
            vm_count = len(resources)
            has_vms = vm_count > 0
        except Exception as _e:
            pass

        # Determine blockers
        # Pvecm delnode runs on a REMAINING online node,
        # so the target node doesn't need to be offline.
        # It just needs VMs evacuated (maintenance complete).
        blockers = []
        warnings = []
        if not in_maintenance:
            blockers.append("Node must be in maintenance mode first")
        if not maintenance_complete and in_maintenance:
            blockers.append("Maintenance/evacuation must be complete")
        if has_vms:
            blockers.append(f"Node still has {vm_count} VM(s)/Container(s) - evacuate first")
        if not is_offline:
            warnings.append(
                "Node is still online - it will be removed from cluster config. Recommended: shutdown node after removal."
            )

        can_remove = len(blockers) == 0

        # lgtm[py/reflected-xss]
        return jsonify({
            "can_remove": can_remove,
            "in_maintenance": in_maintenance,
            "maintenance_complete": maintenance_complete,
            "is_offline": is_offline,
            "has_vms": has_vms,
            "vm_count": vm_count,
            "blockers": blockers,
            "warnings": warnings,
        })
    except Exception as e:
        logging.error(f"[RemoveNode] check_can_remove error: {e}")
        # lgtm[py/reflected-xss]
        return jsonify({
            "can_remove": False,
            "error": "Failed to check node removal",
            "blockers": ["Failed to check node removal"],
        }), 200


@bp.route("/api/clusters/<cluster_id>/nodes/<node_name>/cluster-membership", methods=["DELETE"])
@require_auth(perms=["cluster.admin"])
def remove_node_from_cluster(cluster_id, node_name):
    """Remove a node from the Proxmox cluster"""
    # Runs pvecm delnode on a remaining online node, then SSHs into the
    # removed node to clean up stale configs (authkey, corosync.conf, lock files)
    # IP must be resolved BEFORE delnode or we might wipe the wrong node!
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()

    # Validate node_name strictly. URL-routed param flows into
    # `pvecm delnode {node_name}` via SSH (line ~2617). Without validation, a
    # request like .../nodes/pve1;curl%20attacker/cluster-membership becomes a
    # shell-injection chain even though the route is gated to cluster.admin.
    # PVE/Debian node names follow RFC-1035-ish DNS rules: letter-led, then
    # letters/digits/hyphens, max ~63 chars. Reject anything else.
    if not re.match(r"^[a-zA-Z][a-zA-Z0-9.\-]{0,62}$", node_name or ""):
        # lgtm[py/reflected-xss]
        return jsonify({"success": False, "error": "Invalid node name"}), 400  # snyk:ignore:Cross-site Scripting (XSS)

    if cluster_id not in cluster_managers:
        # lgtm[py/reflected-xss]
        return jsonify({"error": "Cluster not found"}), 404

    paramiko = get_paramiko()
    if not paramiko:
        # lgtm[py/reflected-xss]
        return jsonify({"error": "SSH not available. Install paramiko: pip install paramiko"}), 500

    mgr = cluster_managers[cluster_id]
    data = request.get_json() or {}

    if not data.get("confirm"):
        # lgtm[py/reflected-xss]
        return jsonify({
            "success": False,
            "error": "Confirmation required",
        }), 400  # snyk:ignore:Cross-site Scripting (XSS)

    # Maintenance is recommended but not strictly required
    # pvecm delnode runs on another node, not on the target
    in_maintenance = node_name in mgr.nodes_in_maintenance
    if not in_maintenance:
        logging.warning(f"[RemoveNode] {node_name} not in maintenance mode - proceeding anyway")

    try:
        # Get cluster credentials for SSH - same pattern as HA
        cluster_config = mgr.config
        ssh_user = getattr(cluster_config, "ssh_user", None) or ""
        if not ssh_user:
            api_user = cluster_config.user
            ssh_user = (api_user or "root").split("@")[0]  # PR #62 (ry-ops): null-safe
        ssh_password = getattr(cluster_config, "pass_", "") or ""
        ssh_key_content = getattr(cluster_config, "ssh_key", "") or ""

        # Find an online node to execute the removal from
        host, port = mgr.host, mgr.api_port
        nodes_url = f"https://{host}:{port}/api2/json/nodes"
        nodes_resp = mgr._create_session().get(nodes_url, timeout=10)
        nodes = nodes_resp.json().get("data", []) if nodes_resp.status_code == 200 else []

        online_node = None
        online_node_ip = None

        for node in nodes:
            if node.get("node") != node_name and node.get("status") == "online":
                online_node = node.get("node")
                online_node_ip = mgr._get_node_ip(online_node) or cluster_config.host
                break

        if not online_node:
            # lgtm[py/reflected-xss]
            return jsonify({
                "success": False,
                "error": "No online node found to execute removal",
            }), 500  # snyk:ignore:Cross-site Scripting (XSS)

        if not online_node_ip:
            # _get_node_ip() + cluster_config.host can both come back empty —
            # don't call ssh.connect() with a null hostname.
            # lgtm[py/reflected-xss]
            return jsonify({
                "success": False,
                "error": "Could not determine an IP for the online node",
            }), 500  # snyk:ignore:Cross-site Scripting (XSS)

        # CRITICAL: Resolve the target node's IP BEFORE removal
        # After pvecm delnode, the node is gone from cluster config and _get_node_ip
        # would return wrong/stale data, potentially wiping another node's config!
        removed_node_ip = mgr._get_node_ip(node_name) if hasattr(mgr, "_get_node_ip") else None
        logging.info(f"[RemoveNode] Pre-resolved IP for {node_name}: {removed_node_ip}")

        # Connect to an online node via SSH
        ssh = paramiko.SSHClient()
        apply_ssh_host_key_policy(ssh)

        # Try SSH key first, then password
        connected = False
        if ssh_key_content:
            try:
                import io

                key_file = io.StringIO(ssh_key_content)
                pkey = None
                for key_class in [
                    paramiko.RSAKey,
                    paramiko.Ed25519Key,
                    paramiko.ECDSAKey,
                    getattr(paramiko, "DSSKey", None),
                ]:
                    if key_class is None:
                        continue
                    try:
                        key_file.seek(0)
                        pkey = key_class.from_private_key(key_file)
                        break
                    except Exception as _e:
                        continue
                if pkey:
                    ssh.connect(online_node_ip, port=22, username=ssh_user, pkey=pkey, timeout=30)
                    connected = True
            except Exception as key_err:
                logging.debug(f"[RemoveNode] SSH key auth failed: {key_err}")

        if not connected and ssh_password:
            ssh.connect(online_node_ip, port=22, username=ssh_user, password=ssh_password, timeout=30)
            connected = True

        if not connected:
            # lgtm[py/reflected-xss]
            return jsonify({
                "success": False,
                "error": "Could not authenticate via SSH. Configure SSH key or password.",
            }), 500

        # Execute pvecm delnode command. Apr 2026: shlex.quote belt-and-braces
        # — node_name is already regex-validated at the top of the function,
        # but the second layer keeps things safe if the regex ever loosens.
        cmd = f"pvecm delnode {shlex.quote(node_name)}"
        stdin, stdout, stderr = ssh.exec_command(cmd, timeout=60)

        exit_code = stdout.channel.recv_exit_status()
        stdout_text = stdout.read().decode("utf-8", errors="ignore")
        stderr_text = stderr.read().decode("utf-8", errors="ignore")

        ssh.close()

        if exit_code != 0:
            error_msg = stderr_text or stdout_text or "Unknown error"
            # lgtm[py/reflected-xss]
            return jsonify({
                "success": False,
                "error": f"Failed to remove node: {error_msg}",
            }), 500  # snyk:ignore:Cross-site Scripting (XSS)  # snyk:ignore:Server Information Exposure

        # SSH into the REMOVED node and clean up old cluster config
        # pvecm delnode only updates the remaining nodes' config, the removed node
        # still has stale corosync/authkey/pve config that blocks future joins
        # IMPORTANT: removed_node_ip was resolved BEFORE pvecm delnode (see above)
        # Lock files (.pmxcfs.lockfile) are the #1 reason PVE-cluster won't start after cleanup
        cleanup_result = {"success": False, "message": "Skipped - could not determine node IP"}

        if removed_node_ip:
            try:
                logging.info(f"[RemoveNode] Cleaning up cluster config on removed node {node_name} ({removed_node_ip})")
                ssh_cleanup = paramiko.SSHClient()
                apply_ssh_host_key_policy(ssh_cleanup)

                # Try to connect to the removed node
                cleanup_connected = False
                if ssh_key_content:
                    try:
                        import io

                        key_file = io.StringIO(ssh_key_content)
                        pkey = None
                        for key_class in [
                            paramiko.RSAKey,
                            paramiko.Ed25519Key,
                            paramiko.ECDSAKey,
                            getattr(paramiko, "DSSKey", None),
                        ]:
                            if key_class is None:
                                continue
                            try:
                                key_file.seek(0)
                                pkey = key_class.from_private_key(key_file)
                                break
                            except Exception as _e:
                                continue
                        if pkey:
                            ssh_cleanup.connect(removed_node_ip, port=22, username=ssh_user, pkey=pkey, timeout=15)
                            cleanup_connected = True
                    except Exception as _e:
                        pass
                if not cleanup_connected and ssh_password:
                    try:
                        ssh_cleanup.connect(
                            removed_node_ip, port=22, username=ssh_user, password=ssh_password, timeout=15
                        )
                        cleanup_connected = True
                    except Exception as _e:
                        pass

                if cleanup_connected:
                    # SAFETY CHECK: Verify we're on the correct node before wiping config!
                    stdin, stdout, stderr = ssh_cleanup.exec_command("hostname", timeout=10)
                    actual_hostname = stdout.read().decode().strip()

                    # Case-insensitive compare - Proxmox uses lowercase node names
                    # but hostname might be "Pve1" while node_name is "pve1"
                    if actual_hostname.lower() != node_name.lower():
                        cleanup_result = {
                            "success": False,
                            "message": f"Hostname mismatch! Expected {node_name} but got {actual_hostname} - cleanup ABORTED to protect wrong node",
                        }
                        logging.error(
                            f"[RemoveNode] CRITICAL: Hostname mismatch on {removed_node_ip}! Expected '{node_name}', got '{actual_hostname}'. Cleanup aborted!"
                        )
                        ssh_cleanup.close()
                    else:
                        # Use invoke_shell for cleanup because:
                        # /etc/pve/ is a FUSE mount (pmxcfs). exec_command can't properly
                        # background pmxcfs -l. invoke_shell handles this correctly.
                        channel = ssh_cleanup.invoke_shell()
                        time.sleep(0.5)
                        if channel.recv_ready():
                            channel.recv(4096)  # clear prompt

                        cleanup_commands = [
                            "systemctl stop pve-cluster corosync 2>/dev/null",
                            "sleep 1",
                            "killall -9 pmxcfs 2>/dev/null",
                            "sleep 1",
                            "rm -f /var/lock/pve-cluster.lck /var/lock/pvecm.lock /var/lib/pve-cluster/.pmxcfs.lockfile",
                            "pmxcfs -l &",
                            "sleep 3",
                            "rm -f /etc/corosync/authkey",
                            "rm -f /etc/corosync/corosync.conf",
                            "rm -f /etc/pve/corosync.conf",
                            "killall -9 pmxcfs 2>/dev/null",
                            "sleep 1",
                            "rm -f /var/lock/pve-cluster.lck /var/lock/pvecm.lock /var/lib/pve-cluster/.pmxcfs.lockfile",
                            "systemctl start pve-cluster",
                            "echo CLEANUP_DONE",
                        ]

                        for cmd in cleanup_commands:
                            channel.send((cmd + "\n").encode("utf-8"))
                            time.sleep(0.5)

                        # Wait for completion
                        time.sleep(5)
                        cleanup_output = ""
                        for _ in range(20):
                            if channel.recv_ready():
                                cleanup_output += channel.recv(4096).decode("utf-8", errors="ignore")
                            if "CLEANUP_DONE" in cleanup_output:
                                break
                            time.sleep(0.5)

                        channel.close()
                        ssh_cleanup.close()

                        logging.info(f"[RemoveNode] Cleanup output on {node_name}: {cleanup_output[-500:]}")

                        if "CLEANUP_DONE" in cleanup_output:
                            cleanup_result = {"success": True, "message": "Old cluster config cleaned up"}
                            logging.info(f"[RemoveNode] Cleanup on {node_name} successful")
                        else:
                            cleanup_result = {
                                "success": False,
                                "message": f"Cleanup uncertain - check node manually. Output: {cleanup_output[-200:]}",
                            }
                            logging.warning(f"[RemoveNode] Cleanup on {node_name} uncertain")
                else:
                    cleanup_result = {"success": False, "message": "Could not SSH into removed node for cleanup"}
                    logging.warning(f"[RemoveNode] Could not connect to {removed_node_ip} for cleanup")
            except Exception as cleanup_ex:
                cleanup_result = {"success": False, "message": str(cleanup_ex)}
                logging.warning(f"[RemoveNode] Cleanup error on {node_name}: {cleanup_ex}")

        # Clean up maintenance task
        if node_name in mgr.nodes_in_maintenance:
            del mgr.nodes_in_maintenance[node_name]

        # Clean up excluded_nodes - remove the deleted node
        excluded = getattr(mgr.config, "excluded_nodes", []) or []
        if node_name in excluded:
            excluded.remove(node_name)
            mgr.config.excluded_nodes = excluded
            logging.info(f"Removed {node_name} from excluded_nodes")

        # Clean up fallback_hosts - remove IPs of deleted node
        # Use pre-resolved IP (removed_node_ip) instead of _get_node_ip()
        # because _get_node_ip() queries Proxmox API which no longer knows this node after pvecm delnode!
        fallback = getattr(mgr.config, "fallback_hosts", []) or []
        if removed_node_ip and removed_node_ip in fallback:
            fallback.remove(removed_node_ip)
            mgr.config.fallback_hosts = fallback
            logging.info(f"Removed {removed_node_ip} from fallback_hosts")

        # Clean up HA node status for removed node
        if hasattr(mgr, "ha_node_status") and node_name in mgr.ha_node_status:
            with mgr.ha_lock:
                del mgr.ha_node_status[node_name]
            logging.info(f"[RemoveNode] Cleaned up HA tracking for {node_name}")

        # Clean up HA recovery state
        if hasattr(mgr, "ha_recovery_in_progress"):
            mgr.ha_recovery_in_progress.pop(node_name, None)

        # Save changes to database
        save_config()

        # Full fallback rediscovery in background
        # This ensures the fallback list is fully accurate after removal
        def _post_remove_update():
            """Background: rediscover fallback hosts after node removal"""
            time.sleep(5)  # Wait for cluster to settle
            try:
                mgr.connect_to_proxmox()
                if hasattr(mgr, "_auto_discover_fallback_hosts"):
                    mgr.config.fallback_hosts = []  # Clear and rediscover
                    mgr._auto_discover_fallback_hosts()
                    logging.info(f"[RemoveNode] Rediscovered fallback hosts: {mgr.config.fallback_hosts}")
                    save_config()
                if hasattr(mgr, "ha_enabled") and mgr.ha_enabled and hasattr(mgr, "_ha_update_fallback_hosts"):
                    mgr._ha_update_fallback_hosts()
            except Exception as e:
                logging.warning(f"[RemoveNode] Post-remove update error (non-critical): {e}")

        threading.Thread(target=_post_remove_update, daemon=True).start()

        # Log the action
        user = getattr(request, "session", {}).get("user", "system")
        log_audit(user, "cluster.node_removed", f"Node {node_name} removed from cluster", cluster=mgr.config.name)

        # Broadcast the change
        broadcast_action("node_removed", "cluster", node_name, {}, cluster_id, user)

        # lgtm[py/reflected-xss]
        return jsonify({
            "success": True,
            "message": f"Node {node_name} has been removed from the cluster",
            "cleanup": cleanup_result,
        })

    except paramiko.AuthenticationException:
        # lgtm[py/reflected-xss]
        return jsonify({
            "success": False,
            "error": "SSH authentication failed. Check cluster credentials.",
        }), 401  # snyk:ignore:Cross-site Scripting (XSS)
    except Exception as e:
        logging.error(f"Error removing node from cluster: {e}")
        return _api_error("Failed to remove node from cluster", status=500, success=False)


# Node Action API (reboot/shutdown)
@bp.route("/api/clusters/<cluster_id>/nodes/<node_name>/action/<action>", methods=["POST"])
@require_auth(perms=["node.reboot"])
def node_action_api(cluster_id, node_name, action):
    """Perform action on node (reboot, shutdown) - requires maintenance mode"""
    denied = require_stepup("node.power")
    if denied is not None:
        return denied
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()

    if cluster_id not in cluster_managers:
        # lgtm[py/reflected-xss]
        return jsonify({"error": "Cluster not found"}), 404

    if action not in ["reboot", "shutdown"]:
        # lgtm[py/reflected-xss]
        # snyk:ignore:Cross-site Scripting (XSS)
        return jsonify({
            "error": f"Invalid action: {action}. Valid: reboot, shutdown"
        }), 400  # snyk:ignore:Cross-site Scripting (XSS)

    paramiko = get_paramiko()
    if not paramiko:
        # lgtm[py/reflected-xss]
        return jsonify({"error": "SSH not available. Install paramiko: pip install paramiko"}), 500

    mgr = cluster_managers[cluster_id]

    # check node is in maintenance
    if node_name not in mgr.nodes_in_maintenance:
        # lgtm[py/reflected-xss]
        # snyk:ignore:Cross-site Scripting (XSS)
        return jsonify({
            "error": f"Node {node_name} not in maintenance mode"
        }), 400  # snyk:ignore:Cross-site Scripting (XSS)

    maintenance_task = mgr.nodes_in_maintenance[node_name]
    if maintenance_task.status not in ["completed", "completed_with_errors"]:
        # lgtm[py/reflected-xss]
        return jsonify({"error": "Evacuation still in progress"}), 400

    user = getattr(request, "session", {}).get("user", "system")

    try:
        node_ip = mgr._get_node_ip(node_name)
        if not node_ip:
            # lgtm[py/reflected-xss]
            # snyk:ignore:Cross-site Scripting (XSS)
            return jsonify({
                "error": f"Could not determine IP for {node_name}"
            }), 500  # snyk:ignore:Cross-site Scripting (XSS)

        ssh = mgr._ssh_connect(node_ip)
        if not ssh:
            if not getattr(mgr.config, "ssh_key", ""):
                # lgtm[py/reflected-xss]
                return jsonify({"error": "SSH connection failed"}), 500
            # lgtm[py/reflected-xss]
            return jsonify({"error": "SSH connection failed."}), 500

        try:
            # Check if we're already root (common on Proxmox)
            stdin, stdout, stderr = ssh.exec_command("id -u")
            uid = stdout.read().decode().strip()
            is_root = uid == "0"

            # Always use PTY for reliable execution
            transport = ssh.get_transport()
            channel = transport.open_session()
            channel.get_pty()
            channel.settimeout(10)

            # Use shutdown commands which are more reliable
            if is_root:
                if action == "reboot":
                    channel.exec_command("shutdown -r now")
                else:
                    channel.exec_command("shutdown -h now")
            else:
                if action == "reboot":
                    channel.exec_command("sudo shutdown -r now")
                else:
                    channel.exec_command("sudo shutdown -h now")

            # Wait briefly for command to be sent
            time.sleep(2)

            # Try to read any output
            try:
                output = channel.recv(1024).decode()
                logging.info(f"Node {action} output: {output}")
            except Exception as _e:
                pass

            channel.close()
            ssh.close()

            # Audit log
            log_audit(user, f"node.{action}", f"Node {node_name} {action} initiated")

            # Broadcast to all clients
            broadcast_action(f"node_{action}", "node", node_name, {}, cluster_id, user)

            # lgtm[py/reflected-xss]
            return jsonify({"success": True, "message": f"Node {node_name} {action} initiated"})

        except Exception as e:
            ssh.close()
            logging.error(f"Error executing {action} on {node_name}: {e}")
            return _api_error("Failed to execute node action", status=500)

    except Exception as e:
        logging.error(f"Node action error: {e}")
        return _api_error("Node action failed", status=500)


# Node Update API Routes
@bp.route("/api/clusters/<cluster_id>/nodes/<node_name>/update", methods=["POST"])
@require_auth(perms=["node.update"])
def start_node_update(cluster_id, node_name):
    """Start updating a node (must be in maintenance mode unless force=true)"""
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()

    if cluster_id not in cluster_managers:
        # lgtm[py/reflected-xss]
        return jsonify({"error": "Cluster not found"}), 404

    paramiko = get_paramiko()
    if not paramiko:
        # lgtm[py/reflected-xss]
        return jsonify({"error": "SSH nicht verfuegbar. Bitte installiere paramiko"}), 500

    mgr = cluster_managers[cluster_id]
    data = request.json or {}
    reboot = data.get("reboot", True)
    force = data.get("force", False)

    # check maintenance mode (unless force)
    if not force:
        if node_name not in mgr.nodes_in_maintenance:
            # lgtm[py/reflected-xss]
            # snyk:ignore:Cross-site Scripting (XSS)
            return jsonify({
                "error": f"Node {node_name} ist nicht im Wartungsmodus."
            }), 400  # snyk:ignore:Cross-site Scripting (XSS)

        maintenance_task = mgr.nodes_in_maintenance[node_name]
        if maintenance_task.status not in ["completed", "completed_with_errors"]:
            # lgtm[py/reflected-xss]
            return jsonify({"error": "Evacuation in progress."}), 400

    task = mgr.start_node_update(node_name, reboot, force)

    if task:
        usr = getattr(request, "session", {}).get("user", "system")
        mode = "(forced)" if force else "(maintenance)"
        log_audit(usr, "node.update_started", f"Node {node_name} update started {mode}", cluster=mgr.config.name)
        # lgtm[py/reflected-xss]
        return jsonify({"success": True, "message": f"Update started for {node_name}", "task": task.to_dict()})
    else:
        # lgtm[py/reflected-xss]
        return jsonify({"error": "Update konnte nicht gestartet werden"}), 500


@bp.route("/api/clusters/<cluster_id>/nodes/<node_name>/update", methods=["GET"])
@require_auth(perms=["node.view"])
def get_update_status(cluster_id, node_name):
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()

    if cluster_id not in cluster_managers:
        # lgtm[py/reflected-xss]
        return jsonify({"error": "Cluster not found"}), 404

    mgr = cluster_managers[cluster_id]
    status = mgr.get_update_status(node_name)

    # lgtm[py/reflected-xss]
    return jsonify(status if status else {"is_updating": False})


@bp.route("/api/clusters/<cluster_id>/nodes/<node_name>/update", methods=["DELETE"])
@require_auth(perms=["node.update"])
def clear_update_status_api(cluster_id, node_name):
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()

    if cluster_id not in cluster_managers:
        # lgtm[py/reflected-xss]
        return jsonify({"error": "Cluster not found"}), 404

    mgr = cluster_managers[cluster_id]
    success = mgr.clear_update_status(node_name)

    if success:
        # lgtm[py/reflected-xss]
        return jsonify({"message": f"Update status cleared for {node_name}"})
    # lgtm[py/reflected-xss]
    # snyk:ignore:Cross-site Scripting (XSS)
    return jsonify({
        "error": f"No completed update found for {node_name}"
    }), 400  # snyk:ignore:Cross-site Scripting (XSS)
