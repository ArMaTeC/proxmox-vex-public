# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/api/vms/firewall.py
# Project:     ProxmoxVEx
# Version:     1.2.565
# Build:       2026.09.30
# Description: firewall routes for the vms API (split from
#              api/vms.py).
# Usage:       import ProxmoxVEx.api.vms.firewall
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-30
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""firewall routes for the vms API (split from api/vms.py)."""

import logging

from flask import jsonify

from ProxmoxVEx.api.helpers import check_cluster_access, get_connected_manager
from ProxmoxVEx.globals import cluster_managers
from ProxmoxVEx.utils.audit import log_audit
from ProxmoxVEx.utils.auth import require_auth

from .common import (
    _access_denied,
    _api_error,
    _cluster_not_connected,
    _cluster_not_found,
    _pve_error,
    _require_vm_access,
    bp,
    request,
)


# Firewall API
@bp.route("/api/clusters/<cluster_id>/datacenter/firewall/options", methods=["GET"])
@require_auth(perms=["cluster.view"])
def get_firewall_options(cluster_id):
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()

    manager, _ = get_connected_manager(cluster_id)
    if not manager:
        if cluster_id not in cluster_managers:
            return _cluster_not_found()
        return _cluster_not_connected()

    try:
        host, port = manager.host, manager.api_port
        url = f"https://{host}:{port}/api2/json/cluster/firewall/options"
        r = manager._create_session().get(url, timeout=5)

        if r.status_code == 200:
            # lgtm[py/reflected-xss]
            return jsonify(r.json().get("data", {}))
        # lgtm[py/reflected-xss]
        return jsonify({})
    except Exception as _e:
        # lgtm[py/reflected-xss]
        return jsonify({})


@bp.route("/api/clusters/<cluster_id>/datacenter/firewall/options", methods=["PUT"])
@require_auth(perms=["cluster.config"])
def set_firewall_options(cluster_id):
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()

    manager, _ = get_connected_manager(cluster_id)
    if not manager:
        if cluster_id not in cluster_managers:
            return _cluster_not_found()
        return _cluster_not_connected()

    try:
        host, port = manager.host, manager.api_port
        url = f"https://{host}:{port}/api2/json/cluster/firewall/options"
        data = request.json or {}

        r = manager._create_session().put(url, data=data, timeout=10)

        if r.status_code == 200:
            usr = getattr(request, "session", {}).get("user", "system")
            log_audit(usr, "firewall.options_changed", "Firewall options updated", cluster=manager.config.name)
            # lgtm[py/reflected-xss]
            return jsonify({"success": True, "message": "Firewall options updated"})
        # lgtm[py/reflected-xss]
        return _pve_error(r)
    except Exception:
        return _api_error("Failed to set firewall options", status=500)


@bp.route("/api/clusters/<cluster_id>/datacenter/firewall/rules", methods=["GET"])
@require_auth(perms=["cluster.view"])
def get_firewall_rules(cluster_id):
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()

    manager, _ = get_connected_manager(cluster_id)
    if not manager:
        if cluster_id not in cluster_managers:
            return _cluster_not_found()
        return _cluster_not_connected()

    try:
        host, port = manager.host, manager.api_port
        url = f"https://{host}:{port}/api2/json/cluster/firewall/rules"
        r = manager._create_session().get(url, timeout=5)

        if r.status_code == 200:
            # lgtm[py/reflected-xss]
            return jsonify(r.json().get("data", []))
        # lgtm[py/reflected-xss]
        return jsonify([])
    except Exception as _e:
        # lgtm[py/reflected-xss]
        return jsonify([])


@bp.route("/api/clusters/<cluster_id>/datacenter/firewall/rules", methods=["POST"])
@require_auth(perms=["cluster.config"])
def create_firewall_rule(cluster_id):
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()

    manager, _ = get_connected_manager(cluster_id)
    if not manager:
        if cluster_id not in cluster_managers:
            return _cluster_not_found()
        return _cluster_not_connected()

    try:
        host, port = manager.host, manager.api_port
        url = f"https://{host}:{port}/api2/json/cluster/firewall/rules"
        data = request.json or {}

        r = manager._create_session().post(url, data=data, timeout=10)

        if r.status_code == 200:
            usr = getattr(request, "session", {}).get("user", "system")
            log_audit(usr, "firewall.rule_created", "Firewall rule created", cluster=manager.config.name)
            # lgtm[py/reflected-xss]
            return jsonify({"success": True, "message": "Firewall rule created"})
        # lgtm[py/reflected-xss]
        return _pve_error(r)
    except Exception:
        return _api_error("Failed to create firewall rule", status=500)


@bp.route("/api/clusters/<cluster_id>/datacenter/firewall/rules/<int:pos>", methods=["PUT"])
@require_auth(perms=["cluster.config"])
def update_firewall_rule(cluster_id, pos):
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()

    manager, _ = get_connected_manager(cluster_id)
    if not manager:
        if cluster_id not in cluster_managers:
            return _cluster_not_found()
        return _cluster_not_connected()

    try:
        host, port = manager.host, manager.api_port
        url = f"https://{host}:{port}/api2/json/cluster/firewall/rules/{pos}"
        data = request.json or {}

        r = manager._create_session().put(url, data=data, timeout=10)

        if r.status_code == 200:
            # lgtm[py/reflected-xss]
            return jsonify({"success": True, "message": "Firewall rule updated"})
        # lgtm[py/reflected-xss]
        return _pve_error(r)
    except Exception:
        return _api_error("Failed to update firewall rule", status=500)


@bp.route("/api/clusters/<cluster_id>/datacenter/firewall/rules/<int:pos>", methods=["DELETE"])
@require_auth(perms=["cluster.config"])
def delete_firewall_rule(cluster_id, pos):
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()

    manager, _ = get_connected_manager(cluster_id)
    if not manager:
        if cluster_id not in cluster_managers:
            return _cluster_not_found()
        return _cluster_not_connected()

    try:
        host, port = manager.host, manager.api_port
        url = f"https://{host}:{port}/api2/json/cluster/firewall/rules/{pos}"

        response = manager._create_session().delete(url, timeout=10)

        if response.status_code == 200:
            # lgtm[py/reflected-xss]
            return jsonify({"success": True, "message": "Firewall rule deleted"})
        # lgtm[py/reflected-xss]
        return _pve_error(response)
    except Exception:
        return _api_error("Failed to delete firewall rule", status=500)


@bp.route("/api/clusters/<cluster_id>/datacenter/firewall/groups", methods=["GET"])
@require_auth(perms=["cluster.view"])
def get_firewall_groups(cluster_id):
    """Get firewall security groups"""
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()
    manager, _ = get_connected_manager(cluster_id)
    if not manager:
        if cluster_id not in cluster_managers:
            return _cluster_not_found()
        return _cluster_not_connected()

    try:
        host, port = manager.host, manager.api_port
        url = f"https://{host}:{port}/api2/json/cluster/firewall/groups"
        response = manager._create_session().get(url, timeout=5)

        if response.status_code == 200:
            # lgtm[py/reflected-xss]
            return jsonify(response.json().get("data", []))
        # lgtm[py/reflected-xss]
        return jsonify([])
    except Exception:
        return _api_error("Failed to get firewall groups", status=500)


@bp.route("/api/clusters/<cluster_id>/datacenter/firewall/aliases", methods=["GET"])
@require_auth(perms=["cluster.view"])
def get_firewall_aliases(cluster_id):
    """Get firewall aliases"""
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()
    manager, _ = get_connected_manager(cluster_id)
    if not manager:
        if cluster_id not in cluster_managers:
            return _cluster_not_found()
        return _cluster_not_connected()

    try:
        host, port = manager.host, manager.api_port
        url = f"https://{host}:{port}/api2/json/cluster/firewall/aliases"
        response = manager._create_session().get(url, timeout=5)

        if response.status_code == 200:
            # lgtm[py/reflected-xss]
            return jsonify(response.json().get("data", []))
        # lgtm[py/reflected-xss]
        return jsonify([])
    except Exception:
        return _api_error("Failed to get firewall aliases", status=500)


@bp.route("/api/clusters/<cluster_id>/datacenter/firewall/ipset", methods=["GET"])
@require_auth(perms=["cluster.view"])
def get_firewall_ipsets(cluster_id):
    """Get firewall IP sets"""
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()
    manager, _ = get_connected_manager(cluster_id)
    if not manager:
        if cluster_id not in cluster_managers:
            return _cluster_not_found()
        return _cluster_not_connected()

    try:
        host, port = manager.host, manager.api_port
        url = f"https://{host}:{port}/api2/json/cluster/firewall/ipset"
        response = manager._create_session().get(url, timeout=5)

        if response.status_code == 200:
            # lgtm[py/reflected-xss]
            return jsonify(response.json().get("data", []))
        # lgtm[py/reflected-xss]
        return jsonify([])
    except Exception:
        return _api_error("Failed to get firewall IP sets", status=500)


# ============================================
# Per-VM/CT Firewall API
# ============================================


def _vm_fw_url(manager, node, vmtype, vmid, sub=""):
    host, port = manager.host, manager.api_port
    # lgtm[py/reflected-xss]
    return f"https://{host}:{port}/api2/json/nodes/{node}/{vmtype}/{vmid}/firewall{sub}"


@bp.route("/api/clusters/<cluster_id>/vms/<node>/<vmtype>/<vmid>/firewall/options", methods=["GET"])
@require_auth(perms=["vm.view"])
def get_vm_firewall_options(cluster_id, node, vmtype, vmid):
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()
    denied = _require_vm_access(cluster_id, vmid, "vm.view", vmtype)
    if denied:
        # lgtm[py/reflected-xss]
        return denied
    manager, _ = get_connected_manager(cluster_id)
    if not manager:
        if cluster_id not in cluster_managers:
            return _cluster_not_found()
        return _cluster_not_connected()
    try:
        r = manager._create_session().get(_vm_fw_url(manager, node, vmtype, vmid, "/options"), timeout=5)
        if r.status_code == 200:
            # lgtm[py/reflected-xss]
            return jsonify(r.json().get("data", {}))
        # lgtm[py/reflected-xss]
        return jsonify({})
    except Exception as _e:
        # lgtm[py/reflected-xss]
        return jsonify({})


@bp.route("/api/clusters/<cluster_id>/vms/<node>/<vmtype>/<vmid>/firewall/options", methods=["PUT"])
@require_auth(perms=["vm.config"])
def set_vm_firewall_options(cluster_id, node, vmtype, vmid):
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()
    denied = _require_vm_access(cluster_id, vmid, "vm.config", vmtype)
    if denied:
        # lgtm[py/reflected-xss]
        return denied
    manager, _ = get_connected_manager(cluster_id)
    if not manager:
        if cluster_id not in cluster_managers:
            return _cluster_not_found()
        return _cluster_not_connected()
    try:
        data = request.json or {}
        r = manager._create_session().put(_vm_fw_url(manager, node, vmtype, vmid, "/options"), data=data, timeout=10)
        if r.status_code == 200:
            usr = getattr(request, "session", {}).get("user", "system")
            log_audit(usr, "vm.firewall.options", f"VM {vmid} firewall options updated", cluster=manager.config.name)
            # lgtm[py/reflected-xss]
            return jsonify({"success": True})
        # lgtm[py/reflected-xss]
        return _pve_error(r)
    except Exception:
        return _api_error("Failed to set VM firewall options", status=500)


@bp.route("/api/clusters/<cluster_id>/vms/<node>/<vmtype>/<vmid>/firewall/rules", methods=["GET"])
@require_auth(perms=["vm.view"])
def get_vm_firewall_rules(cluster_id, node, vmtype, vmid):
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()
    denied = _require_vm_access(cluster_id, vmid, "vm.view", vmtype)
    if denied:
        # lgtm[py/reflected-xss]
        return denied
    manager, _ = get_connected_manager(cluster_id)
    if not manager:
        if cluster_id not in cluster_managers:
            return _cluster_not_found()
        return _cluster_not_connected()
    try:
        url = _vm_fw_url(manager, node, vmtype, vmid, "/rules")
        r = manager._create_session().get(url, timeout=5)
        if r.status_code == 200:
            # lgtm[py/reflected-xss]
            return jsonify(r.json().get("data", []))
        logging.warning(f"VM FW rules GET failed: {r.status_code} {r.text[:200]}")
        # lgtm[py/reflected-xss]
        return jsonify([])
    except Exception as e:
        logging.warning(f"VM FW rules GET exception: {e}")
        # lgtm[py/reflected-xss]
        return jsonify([])


@bp.route("/api/clusters/<cluster_id>/vms/<node>/<vmtype>/<vmid>/firewall/rules", methods=["POST"])
@require_auth(perms=["vm.config"])
def create_vm_firewall_rule(cluster_id, node, vmtype, vmid):
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()
    denied = _require_vm_access(cluster_id, vmid, "vm.config", vmtype)
    if denied:
        # lgtm[py/reflected-xss]
        return denied
    manager, _ = get_connected_manager(cluster_id)
    if not manager:
        if cluster_id not in cluster_managers:
            return _cluster_not_found()
        return _cluster_not_connected()
    try:
        data = request.json or {}
        url = _vm_fw_url(manager, node, vmtype, vmid, "/rules")
        r = manager._create_session().post(url, data=data, timeout=10)
        if r.status_code == 200:
            usr = getattr(request, "session", {}).get("user", "system")
            log_audit(usr, "vm.firewall.rule_created", f"VM {vmid} firewall rule created", cluster=manager.config.name)
            # lgtm[py/reflected-xss]
            return jsonify({"success": True})
        # Extract Proxmox error message
        try:
            pve_err = r.json().get("errors", r.json().get("data", r.text))
        except Exception as _e:
            pve_err = r.text
        logging.warning(f"VM FW rule create failed: {r.status_code} data={data} pve_response={r.text[:300]}")
        # lgtm[py/reflected-xss]
        return jsonify({
            "error": pve_err,
            "status": r.status_code,
        }), r.status_code  # snyk:ignore:Cross-site Scripting (XSS)  # snyk:ignore:Server Information Exposure
    except Exception:
        return _api_error("Failed to create VM firewall rule", status=500)


@bp.route("/api/clusters/<cluster_id>/vms/<node>/<vmtype>/<vmid>/firewall/rules/<int:pos>", methods=["PUT"])
@require_auth(perms=["vm.config"])
def update_vm_firewall_rule(cluster_id, node, vmtype, vmid, pos):
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()
    denied = _require_vm_access(cluster_id, vmid, "vm.config", vmtype)
    if denied:
        # lgtm[py/reflected-xss]
        return denied
    manager, _ = get_connected_manager(cluster_id)
    if not manager:
        if cluster_id not in cluster_managers:
            return _cluster_not_found()
        return _cluster_not_connected()
    try:
        data = request.json or {}
        r = manager._create_session().put(
            _vm_fw_url(manager, node, vmtype, vmid, f"/rules/{pos}"), data=data, timeout=10
        )
        if r.status_code == 200:
            # lgtm[py/reflected-xss]
            return jsonify({"success": True})
        # lgtm[py/reflected-xss]
        return _pve_error(r)
    except Exception:
        return _api_error("Failed to update VM firewall rule", status=500)


@bp.route("/api/clusters/<cluster_id>/vms/<node>/<vmtype>/<vmid>/firewall/rules/<int:pos>", methods=["DELETE"])
@require_auth(perms=["vm.config"])
def delete_vm_firewall_rule(cluster_id, node, vmtype, vmid, pos):
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()
    denied = _require_vm_access(cluster_id, vmid, "vm.config", vmtype)
    if denied:
        # lgtm[py/reflected-xss]
        return denied
    manager, _ = get_connected_manager(cluster_id)
    if not manager:
        if cluster_id not in cluster_managers:
            return _cluster_not_found()
        return _cluster_not_connected()
    try:
        r = manager._create_session().delete(_vm_fw_url(manager, node, vmtype, vmid, f"/rules/{pos}"), timeout=10)
        if r.status_code == 200:
            usr = getattr(request, "session", {}).get("user", "system")
            log_audit(
                usr, "vm.firewall.rule_deleted", f"VM {vmid} firewall rule {pos} deleted", cluster=manager.config.name
            )
            # lgtm[py/reflected-xss]
            return jsonify({"success": True})
        # lgtm[py/reflected-xss]
        return _pve_error(r)
    except Exception:
        return _api_error("Failed to delete VM firewall rule", status=500)


@bp.route("/api/clusters/<cluster_id>/vms/<node>/<vmtype>/<vmid>/firewall/aliases", methods=["GET"])
@require_auth(perms=["vm.view"])
def get_vm_firewall_aliases(cluster_id, node, vmtype, vmid):
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()
    denied = _require_vm_access(cluster_id, vmid, "vm.view", vmtype)
    if denied:
        # lgtm[py/reflected-xss]
        return denied
    manager, _ = get_connected_manager(cluster_id)
    if not manager:
        if cluster_id not in cluster_managers:
            return _cluster_not_found()
        return _cluster_not_connected()
    try:
        r = manager._create_session().get(_vm_fw_url(manager, node, vmtype, vmid, "/aliases"), timeout=5)
        if r.status_code == 200:
            # lgtm[py/reflected-xss]
            return jsonify(r.json().get("data", []))
        # lgtm[py/reflected-xss]
        return jsonify([])
    except Exception as _e:
        # lgtm[py/reflected-xss]
        return jsonify([])


@bp.route("/api/clusters/<cluster_id>/vms/<node>/<vmtype>/<vmid>/firewall/aliases", methods=["POST"])
@require_auth(perms=["vm.config"])
def create_vm_firewall_alias(cluster_id, node, vmtype, vmid):
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()
    denied = _require_vm_access(cluster_id, vmid, "vm.config", vmtype)
    if denied:
        # lgtm[py/reflected-xss]
        return denied
    manager, _ = get_connected_manager(cluster_id)
    if not manager:
        if cluster_id not in cluster_managers:
            return _cluster_not_found()
        return _cluster_not_connected()
    try:
        data = request.json or {}
        r = manager._create_session().post(_vm_fw_url(manager, node, vmtype, vmid, "/aliases"), data=data, timeout=10)
        if r.status_code == 200:
            # lgtm[py/reflected-xss]
            return jsonify({"success": True})
        # lgtm[py/reflected-xss]
        return _pve_error(r)
    except Exception:
        return _api_error("Failed to create VM firewall alias", status=500)


@bp.route("/api/clusters/<cluster_id>/vms/<node>/<vmtype>/<vmid>/firewall/aliases/<name>", methods=["PUT"])
@require_auth(perms=["vm.config"])
def update_vm_firewall_alias(cluster_id, node, vmtype, vmid, name):
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()
    denied = _require_vm_access(cluster_id, vmid, "vm.config", vmtype)
    if denied:
        # lgtm[py/reflected-xss]
        return denied
    manager, _ = get_connected_manager(cluster_id)
    if not manager:
        if cluster_id not in cluster_managers:
            return _cluster_not_found()
        return _cluster_not_connected()
    try:
        data = request.json or {}
        r = manager._create_session().put(
            _vm_fw_url(manager, node, vmtype, vmid, f"/aliases/{name}"), data=data, timeout=10
        )
        if r.status_code == 200:
            # lgtm[py/reflected-xss]
            return jsonify({"success": True})
        # lgtm[py/reflected-xss]
        return _pve_error(r)
    except Exception:
        return _api_error("Failed to update VM firewall alias", status=500)


@bp.route("/api/clusters/<cluster_id>/vms/<node>/<vmtype>/<vmid>/firewall/aliases/<name>", methods=["DELETE"])
@require_auth(perms=["vm.config"])
def delete_vm_firewall_alias(cluster_id, node, vmtype, vmid, name):
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()
    denied = _require_vm_access(cluster_id, vmid, "vm.config", vmtype)
    if denied:
        # lgtm[py/reflected-xss]
        return denied
    manager, _ = get_connected_manager(cluster_id)
    if not manager:
        if cluster_id not in cluster_managers:
            return _cluster_not_found()
        return _cluster_not_connected()
    try:
        r = manager._create_session().delete(_vm_fw_url(manager, node, vmtype, vmid, f"/aliases/{name}"), timeout=10)
        if r.status_code == 200:
            # lgtm[py/reflected-xss]
            return jsonify({"success": True})
        # lgtm[py/reflected-xss]
        return _pve_error(r)
    except Exception:
        return _api_error("Failed to delete VM firewall alias", status=500)


@bp.route("/api/clusters/<cluster_id>/vms/<node>/<vmtype>/<vmid>/firewall/ipset", methods=["GET"])
@require_auth(perms=["vm.view"])
def get_vm_firewall_ipsets(cluster_id, node, vmtype, vmid):
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()
    denied = _require_vm_access(cluster_id, vmid, "vm.view", vmtype)
    if denied:
        # lgtm[py/reflected-xss]
        return denied
    manager, _ = get_connected_manager(cluster_id)
    if not manager:
        if cluster_id not in cluster_managers:
            return _cluster_not_found()
        return _cluster_not_connected()
    try:
        r = manager._create_session().get(_vm_fw_url(manager, node, vmtype, vmid, "/ipset"), timeout=5)
        if r.status_code == 200:
            # lgtm[py/reflected-xss]
            return jsonify(r.json().get("data", []))
        # lgtm[py/reflected-xss]
        return jsonify([])
    except Exception as _e:
        # lgtm[py/reflected-xss]
        return jsonify([])


@bp.route("/api/clusters/<cluster_id>/vms/<node>/<vmtype>/<vmid>/firewall/ipset", methods=["POST"])
@require_auth(perms=["vm.config"])
def create_vm_firewall_ipset(cluster_id, node, vmtype, vmid):
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()
    denied = _require_vm_access(cluster_id, vmid, "vm.config", vmtype)
    if denied:
        # lgtm[py/reflected-xss]
        return denied
    manager, _ = get_connected_manager(cluster_id)
    if not manager:
        if cluster_id not in cluster_managers:
            return _cluster_not_found()
        return _cluster_not_connected()
    try:
        data = request.json or {}
        r = manager._create_session().post(_vm_fw_url(manager, node, vmtype, vmid, "/ipset"), data=data, timeout=10)
        if r.status_code == 200:
            # lgtm[py/reflected-xss]
            return jsonify({"success": True})
        # lgtm[py/reflected-xss]
        return _pve_error(r)
    except Exception:
        return _api_error("Failed to create VM firewall IP set", status=500)


@bp.route("/api/clusters/<cluster_id>/vms/<node>/<vmtype>/<vmid>/firewall/ipset/<name>", methods=["GET"])
@require_auth(perms=["vm.view"])
def get_vm_firewall_ipset_content(cluster_id, node, vmtype, vmid, name):
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()
    denied = _require_vm_access(cluster_id, vmid, "vm.view", vmtype)
    if denied:
        # lgtm[py/reflected-xss]
        return denied
    manager, _ = get_connected_manager(cluster_id)
    if not manager:
        if cluster_id not in cluster_managers:
            return _cluster_not_found()
        return _cluster_not_connected()
    try:
        r = manager._create_session().get(_vm_fw_url(manager, node, vmtype, vmid, f"/ipset/{name}"), timeout=5)
        if r.status_code == 200:
            # lgtm[py/reflected-xss]
            return jsonify(r.json().get("data", []))
        # lgtm[py/reflected-xss]
        return jsonify([])
    except Exception as _e:
        # lgtm[py/reflected-xss]
        return jsonify([])


@bp.route("/api/clusters/<cluster_id>/vms/<node>/<vmtype>/<vmid>/firewall/ipset/<name>", methods=["POST"])
@require_auth(perms=["vm.config"])
def add_vm_firewall_ipset_entry(cluster_id, node, vmtype, vmid, name):
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()
    denied = _require_vm_access(cluster_id, vmid, "vm.config", vmtype)
    if denied:
        # lgtm[py/reflected-xss]
        return denied
    manager, _ = get_connected_manager(cluster_id)
    if not manager:
        if cluster_id not in cluster_managers:
            return _cluster_not_found()
        return _cluster_not_connected()
    try:
        data = request.json or {}
        r = manager._create_session().post(
            _vm_fw_url(manager, node, vmtype, vmid, f"/ipset/{name}"), data=data, timeout=10
        )
        if r.status_code == 200:
            # lgtm[py/reflected-xss]
            return jsonify({"success": True})
        # lgtm[py/reflected-xss]
        return _pve_error(r)
    except Exception:
        return _api_error("Failed to add IP set entry", status=500)


@bp.route("/api/clusters/<cluster_id>/vms/<node>/<vmtype>/<vmid>/firewall/ipset/<name>/<path:cidr>", methods=["DELETE"])
@require_auth(perms=["vm.config"])
def delete_vm_firewall_ipset_entry(cluster_id, node, vmtype, vmid, name, cidr):
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()
    denied = _require_vm_access(cluster_id, vmid, "vm.config", vmtype)
    if denied:
        # lgtm[py/reflected-xss]
        return denied
    manager, _ = get_connected_manager(cluster_id)
    if not manager:
        if cluster_id not in cluster_managers:
            return _cluster_not_found()
        return _cluster_not_connected()
    try:
        r = manager._create_session().delete(
            _vm_fw_url(manager, node, vmtype, vmid, f"/ipset/{name}/{cidr}"), timeout=10
        )
        if r.status_code == 200:
            # lgtm[py/reflected-xss]
            return jsonify({"success": True})
        # lgtm[py/reflected-xss]
        return _pve_error(r)
    except Exception:
        return _api_error("Failed to delete IP set entry", status=500)


@bp.route("/api/clusters/<cluster_id>/vms/<node>/<vmtype>/<vmid>/firewall/ipset/<name>", methods=["DELETE"])
@require_auth(perms=["vm.config"])
def delete_vm_firewall_ipset(cluster_id, node, vmtype, vmid, name):
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()
    denied = _require_vm_access(cluster_id, vmid, "vm.config", vmtype)
    if denied:
        # lgtm[py/reflected-xss]
        return denied
    manager, _ = get_connected_manager(cluster_id)
    if not manager:
        if cluster_id not in cluster_managers:
            return _cluster_not_found()
        return _cluster_not_connected()
    try:
        r = manager._create_session().delete(_vm_fw_url(manager, node, vmtype, vmid, f"/ipset/{name}"), timeout=10)
        if r.status_code == 200:
            # lgtm[py/reflected-xss]
            return jsonify({"success": True})
        # lgtm[py/reflected-xss]
        return _pve_error(r)
    except Exception:
        return _api_error("Failed to delete VM firewall IP set", status=500)


@bp.route("/api/clusters/<cluster_id>/vms/<node>/<vmtype>/<vmid>/firewall/refs", methods=["GET"])
@require_auth(perms=["vm.view"])
def get_vm_firewall_refs(cluster_id, node, vmtype, vmid):
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()
    denied = _require_vm_access(cluster_id, vmid, "vm.view", vmtype)
    if denied:
        # lgtm[py/reflected-xss]
        return denied
    manager, _ = get_connected_manager(cluster_id)
    if not manager:
        if cluster_id not in cluster_managers:
            return _cluster_not_found()
        return _cluster_not_connected()
    try:
        r = manager._create_session().get(_vm_fw_url(manager, node, vmtype, vmid, "/refs"), timeout=5)
        if r.status_code == 200:
            # lgtm[py/reflected-xss]
            return jsonify(r.json().get("data", []))
        # lgtm[py/reflected-xss]
        return jsonify([])
    except Exception as _e:
        # lgtm[py/reflected-xss]
        return jsonify([])


@bp.route("/api/clusters/<cluster_id>/vms/<node>/<vmtype>/<vmid>/firewall/log", methods=["GET"])
@require_auth(perms=["vm.view"])
def get_vm_firewall_log(cluster_id, node, vmtype, vmid):
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()
    denied = _require_vm_access(cluster_id, vmid, "vm.view", vmtype)
    if denied:
        # lgtm[py/reflected-xss]
        return denied
    manager, _ = get_connected_manager(cluster_id)
    if not manager:
        if cluster_id not in cluster_managers:
            return _cluster_not_found()
        return _cluster_not_connected()
    try:
        params = {}
        if request.args.get("limit"):
            params["limit"] = request.args["limit"]
        if request.args.get("start"):
            params["start"] = request.args["start"]
        r = manager._create_session().get(_vm_fw_url(manager, node, vmtype, vmid, "/log"), params=params, timeout=10)
        if r.status_code == 200:
            # lgtm[py/reflected-xss]
            return jsonify(r.json().get("data", []))
        # lgtm[py/reflected-xss]
        return jsonify([])
    except Exception as _e:
        # lgtm[py/reflected-xss]
        return jsonify([])
