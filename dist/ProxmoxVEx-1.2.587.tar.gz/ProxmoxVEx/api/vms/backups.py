# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/api/vms/backups.py
# Project:     ProxmoxVEx
# Version:     1.2.565
# Build:       2026.09.30
# Description: backups routes for the vms API (split from api/vms.py).
# Usage:       import ProxmoxVEx.api.vms.backups
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-30
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""backups routes for the vms API (split from api/vms.py)."""

import logging
from urllib.parse import quote as url_quote

from flask import jsonify

from ProxmoxVEx.api.helpers import check_cluster_access, get_connected_manager, validate
from ProxmoxVEx.globals import cluster_managers
from ProxmoxVEx.utils.audit import log_audit
from ProxmoxVEx.utils.auth import get_user_record, require_auth
from ProxmoxVEx.utils.rbac import user_can_access_vm
from ProxmoxVEx.utils.stepup import require_stepup

from .common import (
    _access_denied,
    _api_error,
    _cluster_not_connected,
    _cluster_not_found,
    _pve_error,
    _require_vm_access,
    bp,
    request,
)

# ============================================

# VM Backup Management
# Get backups for a specific VM, restore, delete
# ============================================


@bp.route("/api/clusters/<cluster_id>/vms/<node>/<vm_type>/<int:vmid>/backups", methods=["GET"])
@require_auth(perms=["backup.view"])
def get_vm_backups(cluster_id, node, vm_type, vmid):
    """Get all backups for a specific VM

    Scans all backup-capable storages for vzdump files matching the vmid
    """
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        # snyk:ignore:python/XSS - constant 403 response; taint from check_cluster_access does not reach the error message
        # lgtm[py/reflected-xss]
        return jsonify({"error": "Access denied to this cluster"}), 403
    denied = _require_vm_access(cluster_id, vmid, "vm.view", vm_type)
    if denied:
        # lgtm[py/reflected-xss]
        return denied
    manager, _ = get_connected_manager(cluster_id)
    if not manager:
        if cluster_id not in cluster_managers:
            return _cluster_not_found()
        return _cluster_not_connected()

    try:
        host, port = manager.host, manager.api_port
        session = manager._create_session()

        backups = []

        # get all storages that can hold backups
        # This is kinda slow if you have lots of storages but whatever
        storage_url = f"https://{host}:{port}/api2/json/nodes/{node}/storage"
        stor_resp = session.get(storage_url, timeout=5)

        if stor_resp.status_code != 200:
            # lgtm[py/reflected-xss]
            return jsonify([])

        storages = stor_resp.json().get("data", [])

        for storage in storages:
            # Only check storages that can hold backups
            content = storage.get("content", "")
            if "backup" not in content:
                continue

            stor_name = storage.get("storage")
            content_url = f"https://{host}:{port}/api2/json/nodes/{node}/storage/{stor_name}/content"
            try:
                # #143: pass vmid filter — critical for PBS storages which can have
                # thousands of backups. Without it PVE returns ALL backups and we hang
                content_resp = session.get(content_url, params={"content": "backup", "vmid": vmid}, timeout=(5, 30))
            except Exception as _e:
                continue

            if content_resp.status_code != 200:
                continue

            items = content_resp.json().get("data", [])

            for item in items:
                # vzdump naming: vzdump-{type}-{vmid}-{date}_{time}.{ext}
                # Proxmox naming conventions are weird but ok
                volid = item.get("volid", "")
                filename = volid.split("/")[-1] if "/" in volid else volid.split(":")[-1]

                # double-check vmid match (PVE filter isn't always exact)
                # #143: PBS volids use path format backup/vm/{vmid}/ instead of vzdump filename
                if (
                    f"-{vmid}-" in filename
                    or filename.startswith(f"vzdump-{vm_type[:4]}-{vmid}")
                    or f"/vm/{vmid}/" in volid
                    or f"/ct/{vmid}/" in volid
                ):
                    backups.append({
                        "volid": volid,
                        "storage": stor_name,
                        "filename": filename,
                        "size": item.get("size", 0),
                        "ctime": item.get("ctime", 0),  # creation time
                        "format": item.get("format", "unknown"),
                        "notes": item.get("notes", ""),
                    })

        # sort by creation time, newest first
        backups.sort(key=lambda x: x.get("ctime", 0), reverse=True)

        # lgtm[py/reflected-xss]
        return jsonify(backups)

    except Exception as e:
        logging.error(f"[BACKUP] Error getting VM backups: {e}")
        return _api_error("Failed to get VM backups", status=500)


# spec 092/US041: body schema — validated before the handler runs. vzdump's
# mode/compress enumerations reject anything upstream would 400 on anyway.
_BACKUP_CREATE_SCHEMA = {
    "storage": {"type": str, "default": "local", "max_length": 80},
    "mode": {"type": str, "default": "snapshot",
             "enum": ["stop", "suspend", "snapshot"]},
    "compress": {"type": str, "default": "zstd",
                 "enum": ["0", "1", "gzip", "lzo", "zstd"]},
    "notes": {"type": str, "default": "", "max_length": 4000},
}


@bp.route("/api/clusters/<cluster_id>/vms/<node>/<vm_type>/<int:vmid>/backups/create", methods=["POST"])
@require_auth(perms=["backup.create"])
@validate(_BACKUP_CREATE_SCHEMA)
def create_vm_backup(cluster_id, node, vm_type, vmid):
    """Create a backup of a VM

    Uses vzdump to create a backup
    """
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()
    manager, _ = get_connected_manager(cluster_id)
    if not manager:
        if cluster_id not in cluster_managers:
            return _cluster_not_found()
        return _cluster_not_connected()

    # Check pool permission for vm.backup
    # (perf) indexed single-row fetch — load_users() scanned/decrypted all users
    user = get_user_record(request.session["user"])
    user["username"] = request.session["user"]
    if not user_can_access_vm(user, cluster_id, vmid, "vm.backup", vm_type):
        # lgtm[py/reflected-xss]
        return jsonify({"error": "Permission denied: vm.backup"}), 403

    # populated by @validate above — schema-checked + defaults applied
    data = request.validated
    storage = data["storage"]
    mode = data["mode"]
    compress = data["compress"]
    notes = data["notes"]

    try:
        host, port = manager.host, manager.api_port
        session = manager._create_session()

        # vzdump endpoint
        url = f"https://{host}:{port}/api2/json/nodes/{node}/vzdump"

        backup_params = {"vmid": vmid, "storage": storage, "mode": mode, "compress": compress}

        if notes:
            backup_params["notes-template"] = notes

        response = session.post(url, data=backup_params, timeout=30)

        if response.status_code == 200:
            task = response.json().get("data", "")
            user = getattr(request, "session", {}).get("user", "system")
            log_audit(user, "backup.created", f"Started backup for {vm_type}/{vmid}", cluster=manager.config.name)
            # lgtm[py/reflected-xss]
            return jsonify({"success": True, "task": task})

        # lgtm[py/reflected-xss]
        return _pve_error(response)

    except Exception as e:
        logging.error(f"[BACKUP] Error creating backup: {e}")
        return _api_error("Failed to create backup", status=500)


@bp.route("/api/clusters/<cluster_id>/vms/<node>/<vm_type>/<int:vmid>/backups/restore", methods=["POST"])
@require_auth(perms=["backup.restore"])
def restore_vm_backup(cluster_id, node, vm_type, vmid):
    """Restore a VM from backup

    Can restore to same VMID (overwrite) or new VMID
    """
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()
    manager, _ = get_connected_manager(cluster_id)
    if not manager:
        if cluster_id not in cluster_managers:
            return _cluster_not_found()
        return _cluster_not_connected()

    # Check pool permission for vm.backup
    # (perf) indexed single-row fetch — load_users() scanned/decrypted all users
    user = get_user_record(request.session["user"])
    user["username"] = request.session["user"]
    if not user_can_access_vm(user, cluster_id, vmid, "vm.backup", vm_type):
        # lgtm[py/reflected-xss]
        return jsonify({"error": "Permission denied: vm.backup"}), 403

    data = request.json or {}
    volid = data.get("volid")
    target_vmid = data.get("target_vmid", vmid)  # default: restore to same vmid
    target_storage = data.get("storage", "")
    start_after = data.get("start", False)

    if not volid:
        # lgtm[py/reflected-xss]
        return jsonify({"error": "Backup volume ID required"}), 400

    try:
        host, port = manager.host, manager.api_port
        session = manager._create_session()

        # restore endpoint depends on vm type
        # Why does Proxmox have different endpoints for this?? annoying
        if vm_type == "qemu":
            url = f"https://{host}:{port}/api2/json/nodes/{node}/qemu"
        else:
            url = f"https://{host}:{port}/api2/json/nodes/{node}/lxc"

        restore_params = {
            "vmid": target_vmid,
            "archive": volid,
            "force": 1 if target_vmid == vmid else 0,  # force overwrite if same vmid
        }

        if target_storage:
            restore_params["storage"] = target_storage

        if start_after:
            restore_params["start"] = 1

        target_name = data.get("name") or data.get("hostname")
        if target_name:
            if vm_type == "qemu":
                restore_params["name"] = target_name
            else:
                restore_params["hostname"] = target_name

        logging.debug(f"restore params: {restore_params}")

        response = session.post(url, data=restore_params, timeout=30)

        if response.status_code == 200:
            task = response.json().get("data", "")
            user = getattr(request, "session", {}).get("user", "system")
            log_audit(user, "backup.restored", f"Restored {volid} to VMID {target_vmid}", cluster=manager.config.name)
            # lgtm[py/reflected-xss]
            return jsonify({"success": True, "task": task, "vmid": target_vmid})

        # Proxmox sometimes returns weird error messages, should probably parse them better
        # lgtm[py/reflected-xss]
        return _pve_error(response)

    except Exception as e:
        logging.error(f"[BACKUP] Error restoring backup: {e}")
        return _api_error("Failed to restore backup", status=500)


@bp.route("/api/clusters/<cluster_id>/vms/<node>/<vm_type>/<int:vmid>/backups/<path:volid>", methods=["DELETE"])
@require_auth(perms=["backup.delete"])
def delete_vm_backup(cluster_id, node, vm_type, vmid, volid):
    """Delete a specific backup

    Deletes from the storage where the backup is located
    """
    denied = require_stepup("backup.delete")
    if denied is not None:
        return denied
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()
    # Check VM-level backup permission
    # (perf) indexed single-row fetch — load_users() scanned/decrypted all users
    user = get_user_record(request.session["user"])
    user["username"] = request.session["user"]
    if not user_can_access_vm(user, cluster_id, vmid, "vm.backup", vm_type):
        # lgtm[py/reflected-xss]
        return jsonify({"error": "Permission denied: vm.backup"}), 403
    manager, _ = get_connected_manager(cluster_id)
    if not manager:
        if cluster_id not in cluster_managers:
            return _cluster_not_found()
        return _cluster_not_connected()

    try:
        host, port = manager.host, manager.api_port
        session = manager._create_session()

        # volid format is usually: storage:backup/vzdump-xxx.vma.zst
        # we need to extract storage name
        if ":" in volid:
            storage = volid.split(":")[0]
        else:
            # lgtm[py/reflected-xss]
            return jsonify({"error": "Invalid volume ID format"}), 400

        # URL encode the volid for the path
        encoded_volid = url_quote(volid, safe="")

        url = f"https://{host}:{port}/api2/json/nodes/{node}/storage/{storage}/content/{encoded_volid}"

        response = session.delete(url, timeout=30)

        if response.status_code == 200:
            user = getattr(request, "session", {}).get("user", "system")
            log_audit(user, "backup.deleted", f"Deleted backup {volid}", cluster=manager.config.name)
            # lgtm[py/reflected-xss]
            return jsonify({"success": True})

        # lgtm[py/reflected-xss]
        return _pve_error(response)

    except Exception as e:
        logging.error(f"[BACKUP] Error deleting backup: {e}")
        return _api_error("Failed to delete backup", status=500)
