# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/api/vms/devices.py
# Project:     ProxmoxVEx
# Version:     1.2.565
# Build:       2026.09.30
# Description: devices routes for the vms API (split from api/vms.py).
# Usage:       import ProxmoxVEx.api.vms.devices
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-30
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""devices routes for the vms API (split from api/vms.py)."""

import logging

from flask import jsonify

from ProxmoxVEx.api.helpers import check_cluster_access, register_task_user
from ProxmoxVEx.globals import cluster_managers
from ProxmoxVEx.utils.audit import log_audit
from ProxmoxVEx.utils.auth import require_auth
from ProxmoxVEx.utils.realtime import broadcast_sse

from .common import (
    _access_denied,
    _require_vm_access,
    bp,
    request,
)


@bp.route("/api/clusters/<cluster_id>/vms/<node>/<vm_type>/<int:vmid>/resize", methods=["PUT"])
@require_auth(perms=["vm.config"])
def resize_vm_disk_api(cluster_id, node, vm_type, vmid):
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()

    if cluster_id not in cluster_managers:
        # lgtm[py/reflected-xss]
        return jsonify({"error": "Cluster not found"}), 404

    denied = _require_vm_access(cluster_id, vmid, "vm.config", vm_type)
    if denied:
        # lgtm[py/reflected-xss]
        return denied

    manager = cluster_managers[cluster_id]
    data = request.json or {}
    disk = data.get("disk")
    size = data.get("size")

    if not disk or not size:
        # lgtm[py/reflected-xss]
        return jsonify({"error": "disk and size required"}), 400

    result = manager.resize_vm_disk(node, vmid, vm_type, disk, size)

    if result["success"]:
        # Audit log
        user = getattr(request, "session", {}).get("user", "system")
        log_audit(
            user,
            "vm.disk_resized",
            f"{vm_type.upper()} {vmid} disk {disk} resized to {size}",
            cluster=manager.config.name,
        )
        # lgtm[py/reflected-xss]
        return jsonify({"message": result["message"]})
    else:
        # lgtm[py/reflected-xss]
        return jsonify({
            "error": result["error"]
        }), 500  # snyk:ignore:Cross-site Scripting (XSS)  # snyk:ignore:Server Information Exposure


@bp.route("/api/clusters/<cluster_id>/vms/<node>/<vm_type>/<int:vmid>/disks/<disk_id>/tool", methods=["POST"])
@require_auth(perms=["vm.config"])
def run_disk_tool_api(cluster_id, node, vm_type, vmid, disk_id):
    """Run e2fsck or resize2fs on a powered-off VM/CT disk"""
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()

    if cluster_id not in cluster_managers:
        # lgtm[py/reflected-xss]
        return jsonify({"error": "Cluster not found"}), 404

    denied = _require_vm_access(cluster_id, vmid, "vm.config", vm_type)
    if denied:
        # lgtm[py/reflected-xss]
        return denied

    manager = cluster_managers[cluster_id]
    data = request.json or {}
    tool = data.get("tool")
    volid = data.get("volume")

    if not tool or not volid:
        # lgtm[py/reflected-xss]
        return jsonify({"error": "tool and volume required"}), 400

    result = manager.run_disk_tool(node, vmid, vm_type, disk_id, tool, volid)

    if result["success"]:
        user = getattr(request, "session", {}).get("user", "system")
        log_audit(
            user,
            "vm.disk_tool",
            f"{vm_type.upper()} {vmid} disk {disk_id}: {tool}",
            cluster=manager.config.name,
        )
        # lgtm[py/reflected-xss]
        return jsonify({
            "message": result.get("message", "Done"),
            "exit_code": result.get("exit_code", 0),
            "output": result.get("output", ""),
        })

    # lgtm[py/reflected-xss]
    return jsonify({"error": result["error"]}), 500


@bp.route("/api/clusters/<cluster_id>/nodes/<node>/storage", methods=["GET"])
@require_auth(perms=["storage.view"])
def get_storage_list_api(cluster_id, node):
    """Get available storage on a node"""
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()
    if cluster_id not in cluster_managers:
        # lgtm[py/reflected-xss]
        return jsonify({"error": "Cluster not found"}), 404

    manager = cluster_managers[cluster_id]
    storage = manager.get_storage_list(node)
    # lgtm[py/reflected-xss]
    return jsonify(storage)


@bp.route("/api/clusters/<cluster_id>/nodes/<node>/networks", methods=["GET"])
@require_auth(perms=["node.view"])
def get_network_list_api(cluster_id, node):
    """Get available networks on a node"""
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()
    if cluster_id not in cluster_managers:
        # lgtm[py/reflected-xss]
        return jsonify({"error": "Cluster not found"}), 404

    manager = cluster_managers[cluster_id]
    networks = manager.get_network_list(node)
    # lgtm[py/reflected-xss]
    return jsonify(networks)


@bp.route("/api/clusters/<cluster_id>/nodes/<node>/isos", methods=["GET"])
@require_auth(perms=["storage.view"])
def get_iso_list_api(cluster_id, node):
    """Get available ISO images on a node"""
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()
    if cluster_id not in cluster_managers:
        # lgtm[py/reflected-xss]
        return jsonify({"error": "Cluster not found"}), 404

    manager = cluster_managers[cluster_id]
    storage = request.args.get("storage")
    isos = manager.get_iso_list(node, storage)
    # lgtm[py/reflected-xss]
    return jsonify(isos)


@bp.route("/api/clusters/<cluster_id>/vms/<node>/<vm_type>/<int:vmid>/disks", methods=["POST"])
@require_auth(perms=["vm.config"])
def add_disk_api(cluster_id, node, vm_type, vmid):
    """Add a disk to VM or container"""
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()
    denied = _require_vm_access(cluster_id, vmid, "vm.config", vm_type)
    if denied:
        # lgtm[py/reflected-xss]
        return denied
    if cluster_id not in cluster_managers:
        # lgtm[py/reflected-xss]
        return jsonify({"error": "Cluster not found"}), 404

    manager = cluster_managers[cluster_id]
    disk_config = request.json or {}

    result = manager.add_disk(node, vmid, vm_type, disk_config)

    if result["success"]:
        # Broadcast VM config change via SSE for live UI updates
        try:
            updated_config = manager.get_vm_config(node, vmid, vm_type)
            if updated_config.get("success"):
                broadcast_sse(
                    "vm_config",
                    {"vmid": vmid, "node": node, "vm_type": vm_type, "config": updated_config.get("config", {})},
                    cluster_id,
                )
        except Exception as e:
            logging.debug(f"Failed to broadcast vm_config SSE: {e}")

        # Audit log
        user = getattr(request, "session", {}).get("user", "system")
        log_audit(
            user,
            "vm.disk_added",
            f"{vm_type.upper()} {vmid} - disk added: {disk_config.get('size', 'unknown')}GB on {disk_config.get('storage', 'default')}",
            cluster=manager.config.name,
        )
        # lgtm[py/reflected-xss]
        return jsonify({"message": result["message"]})
    else:
        # lgtm[py/reflected-xss]
        return jsonify({
            "error": result["error"]
        }), 500  # snyk:ignore:Cross-site Scripting (XSS)  # snyk:ignore:Server Information Exposure


@bp.route("/api/clusters/<cluster_id>/vms/<node>/<vm_type>/<int:vmid>/disks/<disk_id>", methods=["DELETE"])
@require_auth(perms=["vm.config"])
def remove_disk_api(cluster_id, node, vm_type, vmid, disk_id):
    """Remove disk from VM - boot order cleanup is now handled in remove_disk method"""
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()
    denied = _require_vm_access(cluster_id, vmid, "vm.config", vm_type)
    if denied:
        # lgtm[py/reflected-xss]
        return denied

    if cluster_id not in cluster_managers:
        # lgtm[py/reflected-xss]
        return jsonify({"error": "Cluster not found"}), 404

    manager = cluster_managers[cluster_id]
    delete_data = request.args.get("delete_data", "false").lower() == "true"

    result = manager.remove_disk(node, vmid, vm_type, disk_id, delete_data)

    if result["success"]:
        # Broadcast VM config change via SSE for live UI updates
        try:
            updated_config = manager.get_vm_config(node, vmid, vm_type)
            if updated_config.get("success"):
                broadcast_sse(
                    "vm_config",
                    {"vmid": vmid, "node": node, "vm_type": vm_type, "config": updated_config.get("config", {})},
                    cluster_id,
                )
        except Exception as e:
            logging.debug(f"Failed to broadcast vm_config SSE: {e}")

        # Audit log
        user = getattr(request, "session", {}).get("user", "system")
        log_audit(
            user,
            "vm.disk_removed",
            f"{vm_type.upper()} {vmid} - disk {disk_id} removed" + (" (data deleted)" if delete_data else ""),
            cluster=manager.config.name,
        )
        # lgtm[py/reflected-xss]
        return jsonify({"message": result["message"]})
    else:
        # lgtm[py/reflected-xss]
        return jsonify({
            "error": result["error"]
        }), 500  # snyk:ignore:Cross-site Scripting (XSS)  # snyk:ignore:Server Information Exposure


@bp.route("/api/clusters/<cluster_id>/vms/<node>/<vm_type>/<int:vmid>/disks/<disk_id>/move", methods=["POST"])
@require_auth(perms=["vm.config"])
def move_disk_api(cluster_id, node, vm_type, vmid, disk_id):
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()

    if cluster_id not in cluster_managers:
        # lgtm[py/reflected-xss]
        return jsonify({"error": "Cluster not found"}), 404

    denied = _require_vm_access(cluster_id, vmid, "vm.config", vm_type)
    if denied:
        # lgtm[py/reflected-xss]
        return denied

    manager = cluster_managers[cluster_id]
    data = request.json or {}
    target_storage = data.get("storage")
    delete_original = data.get("delete", True)

    if not target_storage:
        # lgtm[py/reflected-xss]
        return jsonify({"error": "Target storage required"}), 400

    result = manager.move_disk(node, vmid, vm_type, disk_id, target_storage, delete_original)

    if result["success"]:
        # Audit log
        user = getattr(request, "session", {}).get("user", "system")
        log_audit(
            user,
            "vm.disk_moved",
            f"{vm_type.upper()} {vmid} - disk {disk_id} moved to {target_storage}",
            cluster=manager.config.name,
        )

        # Register ProxmoxVEx user for this task
        upid = result.get("task") or result.get("upid")
        if upid:
            register_task_user(upid, user, cluster_id)

        # lgtm[py/reflected-xss]
        return jsonify({"message": result["message"], "task": result.get("task")})
    else:
        # lgtm[py/reflected-xss]
        return jsonify({
            "error": result["error"]
        }), 500  # snyk:ignore:Cross-site Scripting (XSS)  # snyk:ignore:Server Information Exposure


@bp.route("/api/clusters/<cluster_id>/vms/<node>/qemu/<int:vmid>/cdrom", methods=["PUT"])
@require_auth(perms=["vm.config"])
def set_cdrom_api(cluster_id, node, vmid):
    """Set or eject CD-ROM"""
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()
    denied = _require_vm_access(cluster_id, vmid, "vm.config", "qemu")
    if denied:
        # lgtm[py/reflected-xss]
        return denied
    if cluster_id not in cluster_managers:
        # lgtm[py/reflected-xss]
        return jsonify({"error": "Cluster not found"}), 404

    manager = cluster_managers[cluster_id]
    data = request.json or {}
    iso_path = data.get("iso")  # None to eject
    drive = data.get("drive", "ide2")

    result = manager.set_cdrom(node, vmid, iso_path, drive)

    if result["success"]:
        # Broadcast VM config change via SSE for live UI updates
        try:
            updated_config = manager.get_vm_config(node, vmid, "qemu")
            if updated_config.get("success"):
                broadcast_sse(
                    "vm_config",
                    {"vmid": vmid, "node": node, "vm_type": "qemu", "config": updated_config.get("config", {})},
                    cluster_id,
                )
        except Exception as e:
            logging.debug(f"Failed to broadcast vm_config SSE: {e}")

        # lgtm[py/reflected-xss]
        return jsonify({"message": result["message"]})
    else:
        # lgtm[py/reflected-xss]
        return jsonify({
            "error": result["error"]
        }), 500  # snyk:ignore:Cross-site Scripting (XSS)  # snyk:ignore:Server Information Exposure


@bp.route("/api/clusters/<cluster_id>/vms/<node>/<vm_type>/<int:vmid>/networks", methods=["POST"])
@require_auth(perms=["vm.config"])
def add_network_api(cluster_id, node, vm_type, vmid):
    """Add a network interface"""
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()
    denied = _require_vm_access(cluster_id, vmid, "vm.config", vm_type)
    if denied:
        # lgtm[py/reflected-xss]
        return denied
    if cluster_id not in cluster_managers:
        # lgtm[py/reflected-xss]
        return jsonify({"error": "Cluster not found"}), 404

    manager = cluster_managers[cluster_id]
    net_config = request.json or {}

    result = manager.add_network(node, vmid, vm_type, net_config)

    if result["success"]:
        # Audit log
        user = getattr(request, "session", {}).get("user", "system")
        log_audit(
            user,
            "vm.network_added",
            f"{vm_type.upper()} {vmid} - network added: bridge={net_config.get('bridge', 'default')}",
            cluster=manager.config.name,
        )
        # lgtm[py/reflected-xss]
        return jsonify({"message": result["message"]})
    else:
        # lgtm[py/reflected-xss]
        return jsonify({
            "error": result["error"]
        }), 500  # snyk:ignore:Cross-site Scripting (XSS)  # snyk:ignore:Server Information Exposure


@bp.route("/api/clusters/<cluster_id>/vms/<node>/<vm_type>/<int:vmid>/networks/<net_id>", methods=["PUT"])
@require_auth(perms=["vm.config"])
def update_network_api(cluster_id, node, vm_type, vmid, net_id):
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()
    denied = _require_vm_access(cluster_id, vmid, "vm.config", vm_type)
    if denied:
        # lgtm[py/reflected-xss]
        return denied

    if cluster_id not in cluster_managers:
        # lgtm[py/reflected-xss]
        return jsonify({"error": "Cluster not found"}), 404

    manager = cluster_managers[cluster_id]
    net_config = request.json or {}

    result = manager.update_network(node, vmid, vm_type, net_id, net_config)

    if result["success"]:
        # Audit log
        user = getattr(request, "session", {}).get("user", "system")
        log_audit(
            user,
            "vm.network_updated",
            f"{vm_type.upper()} {vmid} - network {net_id} updated",
            cluster=manager.config.name,
        )
        # lgtm[py/reflected-xss]
        return jsonify({"message": result["message"]})
    else:
        # lgtm[py/reflected-xss]
        return jsonify({
            "error": result["error"]
        }), 500  # snyk:ignore:Cross-site Scripting (XSS)  # snyk:ignore:Server Information Exposure


@bp.route("/api/clusters/<cluster_id>/vms/<node>/<vm_type>/<int:vmid>/networks/<net_id>", methods=["DELETE"])
@require_auth(perms=["vm.config"])
def remove_network_api(cluster_id, node, vm_type, vmid, net_id):
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()
    denied = _require_vm_access(cluster_id, vmid, "vm.config", vm_type)
    if denied:
        # lgtm[py/reflected-xss]
        return denied

    if cluster_id not in cluster_managers:
        # lgtm[py/reflected-xss]
        return jsonify({"error": "Cluster not found"}), 404

    manager = cluster_managers[cluster_id]

    result = manager.remove_network(node, vmid, vm_type, net_id)

    if result["success"]:
        # Audit log
        user = getattr(request, "session", {}).get("user", "system")
        log_audit(
            user,
            "vm.network_removed",
            f"{vm_type.upper()} {vmid} - network {net_id} removed",
            cluster=manager.config.name,
        )
        # lgtm[py/reflected-xss]
        return jsonify({"message": result["message"]})
    else:
        # lgtm[py/reflected-xss]
        return jsonify({
            "error": result["error"]
        }), 500  # snyk:ignore:Cross-site Scripting (XSS)  # snyk:ignore:Server Information Exposure


@bp.route("/api/clusters/<cluster_id>/vms/<node>/<vm_type>/<int:vmid>/networks/<net_id>/link", methods=["PUT"])
@require_auth(perms=["vm.config"])
def toggle_network_link_api(cluster_id, node, vm_type, vmid, net_id):
    """Toggle network link_down state - simulates cable unplug

    This is a hot-pluggable operation for QEMU VMs (no reboot needed)
    Very useful for testing network failover scenarios
    """
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()
    denied = _require_vm_access(cluster_id, vmid, "vm.config", vm_type)
    if denied:
        # lgtm[py/reflected-xss]
        return denied
    if cluster_id not in cluster_managers:
        # lgtm[py/reflected-xss]
        return jsonify({"error": "Cluster not found"}), 404

    # Only QEMU supports link_down toggle
    if vm_type != "qemu":
        # lgtm[py/reflected-xss]
        return jsonify({"error": "Network disconnect only supported for QEMU VMs"}), 400

    manager = cluster_managers[cluster_id]
    data = request.json or {}
    link_down = data.get("link_down", False)

    result = manager.toggle_network_link(node, vmid, net_id, link_down)

    if result["success"]:
        user = getattr(request, "session", {}).get("user", "system")
        action = "disconnected" if link_down else "connected"
        log_audit(
            user, "vm.network_link_toggle", f"QEMU {vmid} - network {net_id} {action}", cluster=manager.config.name
        )
        # lgtm[py/reflected-xss]
        return jsonify({"message": result["message"]})
    else:
        # lgtm[py/reflected-xss]
        return jsonify({
            "error": result["error"]
        }), 500  # snyk:ignore:Cross-site Scripting (XSS)  # snyk:ignore:Server Information Exposure
