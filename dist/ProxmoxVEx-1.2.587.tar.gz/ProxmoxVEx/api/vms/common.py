# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/api/vms/common.py
# Project:     ProxmoxVEx
# Version:     1.2.565
# Build:       2026.09.30
# Description: Shared helpers, state and blueprint for the vms API
#              package (split from api/vms.py).
# Usage:       import ProxmoxVEx.api.vms.common
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-30
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Shared helpers, state and blueprint for the vms API package (split from api/vms.py)."""

import html
import json
import logging
import os
import re
from typing import Any, cast
from urllib.parse import quote as url_quote

import requests
from flask import (
    Blueprint,
    Request,
    jsonify,
)
from flask import (
    request as _flask_request,
)
from requests.adapters import HTTPAdapter

from ProxmoxVEx.utils.auth import build_authz_user
from ProxmoxVEx.utils.rbac import user_can_access_vm


# The app-level auth guard (api/__init__.py::_require_auth_for_request) attaches
# the validated session dict onto `request` (request.session = session) before
# every API route runs. Flask's Request stub doesn't declare that attribute, so
# widen the type once here — cast() returns the same LocalProxy, nothing
# changes at runtime.
class _SessionRequest(Request):
    session: dict[str, Any]
    validated: dict[str, Any]  # set by @validate (api/helpers.py) via setattr


request: _SessionRequest = cast(_SessionRequest, _flask_request)


def _pve_url(url):
    return url_quote(url, safe=":/?=&")


def _require_vm_access(cluster_id, vmid, perm, vm_type=None):
    """Per-VM BOLA/IDOR guard.  : several VM-scoped detail and
    action routes only did check_cluster_access + a role permission and never honoured
    per-VM ACLs (the /resources LIST did) — a confused deputy that let a low-priv or
    tenant user read/act on a restricted VM. Returns None when the acting (token-scoped)
    user may access this VM for `perm`, else a jsonify(403) tuple the caller must return.
    build_authz_user applies effective_role so an admin-owned scoped token can't bypass."""
    user = build_authz_user(request.session.get("user", ""), request.session)
    if not user_can_access_vm(user, cluster_id, vmid, perm, vm_type):
        # Return a per-VM denial that distinguishes VM-level authz from cluster-level.
        # html.escape defangs the permission string for SAST taint tracking.
        return jsonify({"error": f"Access denied to this VM ({html.escape(perm)})"}), 403
    return None


bp = Blueprint("vms", __name__)


# 856-connection-pooling-for-bulk-operations: keep a shared session with a connection
# pool sized for high-volume bulk API traffic, avoiding repeated TCP setup/teardown.
BULK_OPERATIONS_SESSION = requests.Session()


BULK_OPERATIONS_SESSION.mount(
    "https://", HTTPAdapter(pool_connections=20, pool_maxsize=100)
)
BULK_OPERATIONS_SESSION.mount(
    "http://", HTTPAdapter(pool_connections=20, pool_maxsize=100)
)


def _access_denied():
    return jsonify({"error": "Access denied to this cluster"}), 403


def _cluster_not_found():
    return jsonify({"error": "Cluster not found"}), 404


def _cluster_not_connected():
    return jsonify({"error": "Cluster not connected", "offline": True}), 503


def _api_error(default_msg, status=500, success=None):
    logging.exception(default_msg)
    body = {"error": default_msg}
    if success is not None:
        body["success"] = success
    return jsonify(body), status


def _pve_error(response, status=None):
    text = (response.text or "").strip()[:500]
    msg = "Proxmox API error"
    if text:
        try:
            data = json.loads(text.replace("\\n", " "))
            _m = data.get("message") or data.get("errors") or data.get("error")
            if isinstance(_m, dict):
                _m = "; ".join(f"{k}: {v}" for k, v in _m.items())
            if _m:
                msg = _m
        except Exception:
            msg = text
    # spec 092/US068: coerce the upstream status to int — a pathological
    # response object (non-int status_code) would otherwise make werkzeug's
    # make_response raise AFTER the view returns, bypassing the route's own
    # try/except and the US040 structured-error path. Fall back to 502.
    code = status or getattr(response, "status_code", 502)
    try:
        code = int(code)
    except (TypeError, ValueError):
        code = 502
    return jsonify({"error": html.escape(str(msg))}), code


# VNC connection hardening helpers. We keep the proxy path through
# ProxmoxVEx (most customer browsers can't reach the PVE node directly), so the
# resilience has to come from the proxy code itself. These helpers apply OS-level
# keepalive and a shared connect timeout that's long enough for slow corporate
# inspection middleboxes (TLS DPI, Falcon-style EDR scoring) to finish their work.
VNC_PVE_CONNECT_TIMEOUT = int(os.environ.get("PROXMOXVEX_VNC_CONNECT_TIMEOUT", "15"))


_WS_FALLBACK_HOST = os.environ.get("PROXMOXVEX_WS_FALLBACK_HOST", "0.0.0.0")


# 2026-05-06: cluster-add / -join nehmen frei eingegebene node-targets
# entgegen. Semgrep flagt das als tainted-flask-input -> paramiko.connect.
# Paramiko's connect() ist zwar nicht shell-injectable, aber wir wollen auch
# nicht dass jemand der admin.cluster perm hat hier internal network scans
# triggert via 192.168.1.255 oder so. Strikte regex auf hostname/ipv4/ipv6.
_HOST_RE = re.compile(
    r"^(?:"
    r"(?:[a-zA-Z0-9](?:[a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?"
    r"(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?)*)"
    r"|"
    r"(?:\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})"
    r"|"
    r"(?:\[[0-9a-fA-F:]+\])"
    r")$"
)


def _validate_host(value):
    """Return value if it looks like a hostname/IPv4/IPv6, else None.
    Used at the boundary where flask request input flows into paramiko.connect."""
    v = (value or "").strip()
    if not v or len(v) > 253:
        return None
    return v if _HOST_RE.match(v) else None


def _apply_vnc_socket_options(sock):
    """Apply TCP_NODELAY + aggressive TCP keepalive to a VNC-forwarding socket.

    Stateful firewalls / EDR-network-filters often drop "established" TCP sessions
    that look idle. RFB has natural quiet periods (user reading, no mouse/key
    activity). Default Linux keepalive is 2h idle which doesn't help. 15s idle +
    5s probe interval + 3 misses survives most enterprise conntrack timeouts.
    Best-effort — failures are logged debug, not raised."""
    try:
        import socket as _s

        sock.setsockopt(_s.IPPROTO_TCP, _s.TCP_NODELAY, 1)
        sock.setsockopt(_s.SOL_SOCKET, _s.SO_KEEPALIVE, 1)
        if hasattr(_s, "TCP_KEEPIDLE"):
            sock.setsockopt(_s.IPPROTO_TCP, _s.TCP_KEEPIDLE, 15)
        if hasattr(_s, "TCP_KEEPINTVL"):
            sock.setsockopt(_s.IPPROTO_TCP, _s.TCP_KEEPINTVL, 5)
        if hasattr(_s, "TCP_KEEPCNT"):
            sock.setsockopt(_s.IPPROTO_TCP, _s.TCP_KEEPCNT, 3)
    except Exception as _e:
        logging.debug(f"[VNC] socket options not fully applied: {_e}")


# ==================== CROSS-CLUSTER REPLICATION ====================
# Same-cluster snapshot replication for non-ZFS storage
# Proxmox native replication needs ZFS, this works with any storage backend
# Flow: snapshot -> clone to target storage -> migrate clone to target node -> cleanup
def _safe_vnc_passthrough(port_raw, ticket_raw):
    """#352 single-vncproxy passthrough: the browser hands back the port+ticket of
    the vncproxy IT opened so noVNC's RFB password matches. Validate before those
    values steer a wss:// authority / Cookie (sec-review): port must be a plain
    1-65535 integer, ticket a single-line opaque token. (ok, int_port)."""
    try:
        p = int(str(port_raw).strip())
    except (TypeError, ValueError):
        # lgtm[py/reflected-xss]
        return (False, None)
    if not (1 <= p <= 65535):
        # lgtm[py/reflected-xss]
        return (False, None)
    t = str(ticket_raw or "")
    if not t or len(t) > 4096 or any(c in t for c in "\r\n\x00"):
        # lgtm[py/reflected-xss]
        return (False, None)
    # lgtm[py/reflected-xss]
    return (True, p)
