# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/api/vms/config.py
# Project:     ProxmoxVEx
# Version:     1.2.565
# Build:       2026.09.30
# Description: config routes for the vms API (split from api/vms.py).
# Usage:       import ProxmoxVEx.api.vms.config
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-30
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""config routes for the vms API (split from api/vms.py)."""

import html
import logging

import requests
from flask import jsonify

from ProxmoxVEx.api.helpers import check_cluster_access
from ProxmoxVEx.globals import cluster_managers
from ProxmoxVEx.utils.audit import log_audit
from ProxmoxVEx.utils.auth import get_user_record, require_auth
from ProxmoxVEx.utils.rbac import user_can_access_vm
from ProxmoxVEx.utils.realtime import broadcast_sse

from .common import (
    _access_denied,
    _api_error,
    _pve_error,
    _require_vm_access,
    bp,
    request,
)


def _get_vm_config_response(cluster_id, node, vm_type, vmid):
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()

    if cluster_id not in cluster_managers:
        # lgtm[py/reflected-xss]
        return jsonify({"error": "Cluster not found"}), 404

    denied = _require_vm_access(cluster_id, vmid, "vm.view", vm_type)
    if denied:
        # lgtm[py/reflected-xss]
        return denied

    mgr = cluster_managers[cluster_id]
    try:
        result = mgr.get_vm_config(node, vmid, vm_type)
    except (requests.exceptions.ConnectionError, requests.exceptions.Timeout) as e:
        logging.warning(f"[API] Cluster {cluster_id} unreachable for vm config: {e}")
        # lgtm[py/reflected-xss]
        return jsonify({"error": "Cluster temporarily unreachable", "offline": True}), 503

    if result["success"]:
        config = result["config"]
        if isinstance(config, dict) and not config.get("tags") and not config.get("tag"):
            # Bind the .get() results to names before isinstance() — narrowing a
            # call expression doesn't drop its None member, so raw/general would
            # stay `dict | None` to the type checker.
            _raw = config.get("raw")
            _general = config.get("general")
            raw = _raw if isinstance(_raw, dict) else {}
            general = _general if isinstance(_general, dict) else {}
            vm_tags = raw.get("tags") or general.get("tags")
            if vm_tags:
                config["tags"] = vm_tags
        # lgtm[py/reflected-xss]
        return jsonify(config)
    else:
        # lgtm[py/reflected-xss]
        return jsonify({
            "error": result["error"]
        }), 500  # snyk:ignore:Cross-site Scripting (XSS)  # snyk:ignore:Server Information Exposure


def _resolve_vm_location(mgr, vmid, requested_node=None, requested_type=None):
    """Find the current node/type for a VMID so shorthand VM routes can work."""
    requested_node = (requested_node or "").strip() or None
    requested_type = (requested_type or "").strip() or None
    if requested_type == "ct":
        requested_type = "lxc"

    try:
        resources = mgr.get_vm_resources() or []
    except Exception:
        logging.exception(f"[API] Failed to resolve VM {vmid} location")
        return None, None, jsonify({"error": "Failed to resolve VM location"}), 500

    matches = []
    for item in resources:
        if str(item.get("vmid")) != str(vmid):
            continue
        item_type = item.get("type") or "qemu"
        item_node = item.get("node") or requested_node
        if requested_type and item_type != requested_type:
            continue
        if requested_node and item_node != requested_node:
            continue
        matches.append((item_node, item_type))

    if not matches:
        # lgtm[py/reflected-xss]
        # snyk:ignore:Cross-site Scripting (XSS)
        return None, None, jsonify({"error": f"VM {vmid} not found"}), 404

    unique = []
    for match in matches:
        if match not in unique:
            unique.append(match)

    if len(unique) > 1:
        # lgtm[py/reflected-xss]
        return (
            None,
            None,
            jsonify({
                "error": f"VM {vmid} is ambiguous; use /vms/<node>/<type>/{vmid}/config",
                "matches": [{"node": node, "type": vm_type} for node, vm_type in unique],
            }),
            409,
        )

    node, vm_type = unique[0]
    if not node:
        node = requested_node or ""
    # lgtm[py/reflected-xss]
    return node, vm_type, None, None


# VM Config API Routes
@bp.route("/api/clusters/<cluster_id>/vms/<int:vmid>/config", methods=["GET"])
@require_auth(perms=["vm.view"])
def get_vm_config_by_id_api(cluster_id, vmid):
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()

    if cluster_id not in cluster_managers:
        # lgtm[py/reflected-xss]
        return jsonify({"error": "Cluster not found"}), 404

    mgr = cluster_managers[cluster_id]
    node, vm_type, error_body, status = _resolve_vm_location(
        mgr,
        vmid,
        requested_node=request.args.get("node"),
        requested_type=request.args.get("type") or request.args.get("vm_type"),
    )
    if error_body is not None:
        # lgtm[py/reflected-xss]
        # status is only None on the success path; default so the tuple is a
        # valid (body, code) response either way.
        return error_body, status or 500

    # lgtm[py/reflected-xss]
    return _get_vm_config_response(cluster_id, node, vm_type, vmid)


@bp.route("/api/clusters/<cluster_id>/vms/<node>/<vm_type>/<int:vmid>/config", methods=["GET"])
@require_auth(perms=["vm.view"])
def get_vm_config_api(cluster_id, node, vm_type, vmid):
    # lgtm[py/reflected-xss]
    return _get_vm_config_response(cluster_id, node, vm_type, vmid)


@bp.route("/api/clusters/<cluster_id>/vms/<node>/<vm_type>/<int:vmid>/lock", methods=["GET"])
@require_auth(perms=["vm.view"])
def get_vm_lock_status_api(cluster_id, node, vm_type, vmid):
    """Get lock status of a VM/CT"""
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()
    denied = _require_vm_access(cluster_id, vmid, "vm.view", vm_type)
    if denied:
        # lgtm[py/reflected-xss]
        return denied

    if cluster_id not in cluster_managers:
        # lgtm[py/reflected-xss]
        return jsonify({"error": "Cluster not found"}), 404

    mgr = cluster_managers[cluster_id]

    try:
        result = mgr.get_vm_lock_status(node, vmid, vm_type)

        if result.get("success"):
            # lgtm[py/reflected-xss]
            return jsonify({
                "locked": result.get("locked", False),
                "lock_reason": result.get("lock_reason"),
                "lock_description": result.get("lock_description"),
                "unlock_command": f"qm unlock {vmid}" if vm_type == "qemu" else f"pct unlock {vmid}",
            })
        else:
            # Return not-locked instead of error for better UX
            # The VM config might not be accessible but that doesn't mean it's locked
            logging.warning(f"Could not get lock status for {vm_type}/{vmid}: {result.get('error')}")
            # lgtm[py/reflected-xss]
            return jsonify({
                "locked": False,
                "lock_reason": None,
                "lock_description": None,
                "unlock_command": None,
                "note": "Could not determine lock status",
            })
    except Exception as e:
        logging.error(f"Error getting lock status for {vm_type}/{vmid}: {e}")
        # lgtm[py/reflected-xss]
        return jsonify({"locked": False, "lock_reason": None, "lock_description": None, "unlock_command": None})


@bp.route("/api/clusters/<cluster_id>/vms/<node>/<vm_type>/<int:vmid>/unlock", methods=["POST"])
@require_auth(perms=["vm.config"])
def unlock_vm_api(cluster_id, node, vm_type, vmid):
    """Unlock a VM/CT - use with caution!"""
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()
    denied = _require_vm_access(cluster_id, vmid, "vm.config", vm_type)
    if denied:
        # lgtm[py/reflected-xss]
        return denied

    if cluster_id not in cluster_managers:
        # lgtm[py/reflected-xss]
        return jsonify({"error": "Cluster not found"}), 404

    mgr = cluster_managers[cluster_id]
    result = mgr.unlock_vm(node, vmid, vm_type)

    if result["success"]:
        usr = getattr(request, "session", {}).get("user", "system")
        log_audit(
            usr,
            "vm.unlock",
            f"Unlocked {vm_type}/{vmid} on {node} (was: {result.get('lock_reason', 'unknown')})",
            cluster=mgr.config.name,
        )
        # lgtm[py/reflected-xss]
        return jsonify({
            "message": result["message"],
            "was_locked": result.get("was_locked", False),
            "lock_reason": result.get("lock_reason"),
        })
    else:
        # lgtm[py/reflected-xss]
        return jsonify({
            "error": result["error"]
        }), 500  # snyk:ignore:Cross-site Scripting (XSS)  # snyk:ignore:Server Information Exposure


# Issue #50 - Guest Agent info (hostname, OS, kernel)
# Additive enrichment for the monitoring panel: kernel_version,
# interfaces[] (with MAC + per-NIC IPs), filesystems[], users[], guest_time_ns.
# All existing fields stay unchanged — old UI consumers render exactly as before.
@bp.route("/api/clusters/<cluster_id>/vms/<node>/<vm_type>/<int:vmid>/guest-info", methods=["GET"])
@require_auth(perms=["vm.view"])
def get_vm_guest_info_api(cluster_id, node, vm_type, vmid):
    """Get QEMU Guest Agent info (hostname, OS, kernel, NICs, filesystems, users, clock)"""
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()
    denied = _require_vm_access(cluster_id, vmid, "vm.view", vm_type)
    if denied:
        # lgtm[py/reflected-xss]
        return denied

    if cluster_id not in cluster_managers:
        # lgtm[py/reflected-xss]
        return jsonify({"error": "Cluster not found"}), 404

    # (#560 @j0c00) - LXCs have no guest agent, but PVE still exposes the
    # container's live IPs via /lxc/<vmid>/interfaces (_fetch_lxc_ips, #300) and the OS
    # type + hostname via config. Surface them so the detail view shows OS + IP like the
    # PVE UI does, instead of a bare "LXC Container" with no address.
    if vm_type == "lxc":
        res = {
            "agent_running": False,
            "is_lxc": True,
            "hostname": None,
            "os_pretty_name": None,
            "os_id": None,
            "os_version": None,
            "os_kernel": None,
            "ip_addresses": [],
            "interfaces": [],
        }
        try:
            mgr = cluster_managers[cluster_id]
            seen = set()
            clean = []
            for ip in mgr._fetch_lxc_ips(node, vmid) or []:
                if not ip or ip in seen:
                    continue
                seen.add(ip)
                # skip loopback / link-local / the docker bridge noise
                if ip.startswith(("127.", "::1", "169.254.", "fe80", "172.17.")):
                    continue
                clean.append(ip)
            res["ip_addresses"] = clean
            cfg = mgr.get_vm_config(node, vmid, "lxc")
            if cfg.get("success"):
                gen = cfg["config"].get("general", {}) or {}
                res["hostname"] = gen.get("hostname")
                _ost = gen.get("ostype")
                if _ost:
                    res["os_pretty_name"] = str(_ost).capitalize()
        except Exception as e:
            logging.debug(f"[lxc-info] {vm_type}/{vmid}: {e}")
        # lgtm[py/reflected-xss]
        return jsonify(res)

    if vm_type != "qemu":
        # lgtm[py/reflected-xss]
        return jsonify({"agent_running": False}), 200

    mgr = cluster_managers[cluster_id]
    result = {
        "agent_running": False,
        "hostname": None,
        "os_pretty_name": None,
        "os_id": None,
        "os_version": None,
        "os_kernel": None,
        "os_machine": None,
        "ip_addresses": [],
        "kernel_version": None,
        "interfaces": [],
        "users": [],
        "filesystems": [],
        "guest_time_ns": None,
    }

    try:
        session = mgr._create_session()
        base = f"https://{mgr.host}:{mgr.api_port}/api2/json/nodes/{node}/qemu/{vmid}/agent"

        try:
            resp = session.get(f"{base}/get-host-name", timeout=8)
            logging.info(f"[guest-info:{vmid}] get-host-name status={resp.status_code} body={resp.text[:200]}")
            if resp.status_code == 200:
                data = resp.json().get("data", {}).get("result", {})
                result["hostname"] = data.get("host-name")
                result["agent_running"] = True
            elif resp.status_code == 500 and "not running" in (resp.text or "").lower():
                # short-circuit: agent down, skip the 5 follow-up calls
                # lgtm[py/reflected-xss]
                return jsonify(result)
        except Exception as _e:
            logging.info(f"[guest-info:{vmid}] get-host-name exception: {_e}")

        try:
            resp = session.get(f"{base}/get-osinfo", timeout=8)
            logging.info(f"[guest-info:{vmid}] get-osinfo status={resp.status_code} body={resp.text[:200]}")
            if resp.status_code == 200:
                data = resp.json().get("data", {}).get("result", {})
                result["os_pretty_name"] = data.get("pretty-name")
                result["os_id"] = data.get("id")
                result["os_version"] = data.get("version-id") or data.get("version")
                result["os_kernel"] = data.get("kernel-release")
                result["os_machine"] = data.get("machine")
                result["kernel_version"] = data.get("kernel-version")
                result["agent_running"] = True
        except Exception as _e:
            logging.info(f"[guest-info:{vmid}] get-osinfo exception: {_e}")

        # #159 - reuse centralized IP fetch method
        try:
            ips = mgr._fetch_qemu_ips(node, vmid)
            logging.info(f"[guest-info:{vmid}] _fetch_qemu_ips returned {len(ips) if ips else 0} ips")
            result["ip_addresses"] = ips
            if ips:
                result["agent_running"] = True
        except Exception as _e:
            logging.info(f"[guest-info:{vmid}] _fetch_qemu_ips exception: {_e}")

        # Per-NIC detail (name + MAC + IPs from inside the guest)
        try:
            resp = session.get(f"{base}/network-get-interfaces", timeout=8)
            if resp.status_code == 200:
                nics = resp.json().get("data", {}).get("result", []) or []
                ifaces = []
                for nic in nics:
                    nic_ips = [
                        {
                            "address": ip.get("ip-address"),
                            "family": ip.get("ip-address-type"),
                            "prefix": ip.get("prefix"),
                        }
                        for ip in (nic.get("ip-addresses") or [])
                    ]
                    ifaces.append({
                        "name": nic.get("name"),
                        "mac": nic.get("hardware-address"),
                        "ips": nic_ips,
                    })
                result["interfaces"] = ifaces
            elif resp.status_code == 500:
                # Agent not available — remember so background polls skip it.
                mgr.mark_no_agent(vmid)
        except Exception as _e:
            pass

        # Filesystems with real fill - same data as /guest-fsinfo, mirrored
        # here so the detail panel does one round-trip instead of two.
        try:
            resp = session.get(f"{base}/get-fsinfo", timeout=8)
            if resp.status_code == 200:
                fsraw = resp.json().get("data", {}).get("result", []) or []
                fslist = []
                for fs in fsraw:
                    total = fs.get("total-bytes")
                    used = fs.get("used-bytes")
                    mt = fs.get("mountpoint")
                    if not mt:
                        continue
                    pct = (
                        round((used / total) * 100, 1)
                        if (isinstance(total, (int, float)) and total > 0 and isinstance(used, (int, float)))
                        else None
                    )
                    fslist.append({
                        "name": fs.get("name"),
                        "mountpoint": mt,
                        "type": fs.get("type"),
                        "used_bytes": used,
                        "total_bytes": total,
                        "used_pct": pct,
                    })
                result["filesystems"] = fslist
            elif resp.status_code == 500:
                # Agent not available — remember so background polls skip it.
                mgr.mark_no_agent(vmid)
        except Exception as _e:
            pass

        # Logged-in users - "who's on this VM right now"
        try:
            resp = session.get(f"{base}/get-users", timeout=8)
            if resp.status_code == 200:
                ur = resp.json().get("data", {}).get("result", []) or []
                if isinstance(ur, list):
                    result["users"] = [
                        {"user": u.get("user"), "domain": u.get("domain"), "login_time": u.get("login-time")}
                        for u in ur
                    ]
        except Exception as _e:
            pass

        # Guest clock vs host (ns since epoch) - ntp sanity check
        try:
            resp = session.get(f"{base}/get-time", timeout=8)
            if resp.status_code == 200:
                t = resp.json().get("data", {}).get("result")
                if isinstance(t, (int, float)):
                    result["guest_time_ns"] = t
        except Exception as _e:
            pass

    except Exception as e:
        result["error"] = str(e)

    # lgtm[py/reflected-xss]
    return jsonify(result)


# #334 - surface the guest agent's fsinfo so scripts can monitor mountpoint
# usage without having to call both ProxmoxVEx + Proxmox. Returns [] + agent_running=False
# when the agent isn't installed / the VM isn't running — callers treat it as "no data".
@bp.route("/api/clusters/<cluster_id>/vms/<node>/<vm_type>/<int:vmid>/guest-fsinfo", methods=["GET"])
@require_auth(perms=["vm.view"])
def get_vm_guest_fsinfo_api(cluster_id, node, vm_type, vmid):
    """Proxy for qemu-agent get-fsinfo — list mounted filesystems with used/total bytes."""
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()
    denied = _require_vm_access(cluster_id, vmid, "vm.view", vm_type)
    if denied:
        # lgtm[py/reflected-xss]
        return denied

    if cluster_id not in cluster_managers:
        # lgtm[py/reflected-xss]
        return jsonify({"error": "Cluster not found"}), 404

    # LXC doesn't speak qemu-agent — no-op response keeps the frontend uniform
    if vm_type != "qemu":
        # lgtm[py/reflected-xss]
        return jsonify({"agent_running": False, "filesystems": [], "reason": "lxc_not_supported"}), 200

    mgr = cluster_managers[cluster_id]
    payload = {"agent_running": False, "filesystems": [], "reason": None}

    try:
        session = mgr._create_session()
        url = f"https://{mgr.host}:{mgr.api_port}/api2/json/nodes/{node}/qemu/{vmid}/agent/get-fsinfo"
        resp = session.get(url, timeout=10)
        if resp.status_code == 200:
            data = (resp.json().get("data") or {}).get("result") or []
            out = []
            for fs in data:
                total = fs.get("total-bytes")
                used = fs.get("used-bytes")
                mount = fs.get("mountpoint")
                if not mount:
                    continue
                pct = None
                if isinstance(total, (int, float)) and total > 0 and isinstance(used, (int, float)):
                    pct = round((used / total) * 100, 1)
                out.append({
                    "name": fs.get("name"),
                    "mountpoint": mount,
                    "type": fs.get("type"),
                    "used_bytes": used,
                    "total_bytes": total,
                    "used_pct": pct,
                })
            payload["agent_running"] = True
            payload["filesystems"] = out
        elif resp.status_code == 500:
            # Proxmox returns 500 with "QEMU guest agent is not running" in body
            # Remember this VM so the background refresh loop stops re-probing it.
            mgr.mark_no_agent(vmid)
            body = (resp.text or "").lower()
            if "not running" in body or "not installed" in body:
                payload["reason"] = "agent_not_running"
            else:
                payload["reason"] = f"proxmox_{resp.status_code}"
        else:
            payload["reason"] = f"proxmox_{resp.status_code}"
    except Exception as e:
        payload["reason"] = f"error: {e}"

    # lgtm[py/reflected-xss]
    return jsonify(payload)


# Read a file from a running VM via the qemu-guest-agent.
# PVE 9.2 added optional `count`, `offset`, `decode` (base64) params so you
# can stream large files in chunks without dragging the whole thing through
# memory. We pass them through; older PVE silently ignores extras.
@bp.route("/api/clusters/<cluster_id>/vms/<node>/<vm_type>/<int:vmid>/guest-file-read", methods=["POST"])
@require_auth(perms=["vm.view"])
def get_vm_guest_file_read_api(cluster_id, node, vm_type, vmid):
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()
    if cluster_id not in cluster_managers:
        # lgtm[py/reflected-xss]
        return jsonify({"error": "Cluster not found"}), 404
    denied = _require_vm_access(cluster_id, vmid, "vm.view", vm_type)
    if denied:
        # lgtm[py/reflected-xss]
        return denied
    if vm_type != "qemu":
        # lgtm[py/reflected-xss]
        return jsonify({"error": "Guest-agent file-read is QEMU-only"}), 400

    mgr = cluster_managers[cluster_id]
    body = request.json or {}
    file_path = body.get("file")
    if not file_path:
        # lgtm[py/reflected-xss]
        return jsonify({"error": "file path required"}), 400

    params = {"file": file_path}
    # 9.2 optional params — accept ints + a base64 toggle
    for k in ("count", "offset"):
        if k in body and body[k] not in (None, ""):
            try:
                params[k] = int(body[k])
            except (TypeError, ValueError):
                # lgtm[py/reflected-xss]
                return jsonify({"error": f"{html.escape(str(k))} must be an integer"}), 400
    if body.get("decode"):
        # PVE expects '1' / '0', accept boolean or string
        params["decode"] = 1 if body["decode"] in (True, 1, "1", "true") else 0

    try:
        url = f"https://{mgr.host}:{mgr.api_port}/api2/json/nodes/{node}/qemu/{vmid}/agent/file-read"
        resp = mgr._api_post(url, data=params)
        if resp.status_code == 200:
            data = resp.json().get("data") or {}
            # lgtm[py/reflected-xss]
            return jsonify({
                "content": data.get("content"),
                "truncated": bool(data.get("truncated", False)),
                "bytes_read": data.get("bytes-read") or data.get("content-size"),
            })
        # lgtm[py/reflected-xss]
        return _pve_error(resp)
    except Exception:
        return _api_error("Failed to read VM guest file", status=500)


@bp.route("/api/clusters/<cluster_id>/vms/<node>/<vm_type>/<int:vmid>/rrd/<timeframe>", methods=["GET"])
@require_auth(perms=["vm.view"])
def get_vm_rrd_api(cluster_id, node, vm_type, vmid, timeframe):
    """Get VM RRD metrics data for graphs

    Timeframes: hour, day, week, month, year
    """
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()
    denied = _require_vm_access(cluster_id, vmid, "vm.view", vm_type)
    if denied:
        # lgtm[py/reflected-xss]
        return denied

    if cluster_id not in cluster_managers:
        # lgtm[py/reflected-xss]
        return jsonify({"error": "Cluster not found"}), 404

    valid_timeframes = ["hour", "day", "week", "month", "year"]
    if timeframe not in valid_timeframes:
        # lgtm[py/reflected-xss]
        # snyk:ignore:Cross-site Scripting (XSS)
        return jsonify({
            "error": f"Invalid timeframe. Valid: {valid_timeframes}"
        }), 400  # snyk:ignore:Cross-site Scripting (XSS)

    mgr = cluster_managers[cluster_id]
    result = mgr.get_vm_rrd(node, vmid, vm_type, timeframe)

    if result["success"]:
        # lgtm[py/reflected-xss]
        return jsonify(result["data"])
    else:
        # lgtm[py/reflected-xss]
        return jsonify({
            "error": result["error"]
        }), 500  # snyk:ignore:Cross-site Scripting (XSS)  # snyk:ignore:Server Information Exposure


@bp.route("/api/clusters/<cluster_id>/vms/<node>/<vm_type>/<int:vmid>/config", methods=["PUT"])
@require_auth(perms=["vm.config"])
def update_vm_config_api(cluster_id, node, vm_type, vmid):
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()

    if cluster_id not in cluster_managers:
        # lgtm[py/reflected-xss]
        return jsonify({"error": "Cluster not found"}), 404

    manager = cluster_managers[cluster_id]

    # (perf) indexed single-row fetch — load_users() scanned/decrypted all users
    user = get_user_record(request.session["user"])
    user["username"] = request.session["user"]

    if not user_can_access_vm(user, cluster_id, vmid, "vm.config", vm_type):
        # lgtm[py/reflected-xss]
        return jsonify({"error": "Permission denied: vm.config"}), 403

    config_updates = request.json or {}

    result = manager.update_vm_config(node, vmid, vm_type, config_updates)

    if result["success"]:
        # Broadcast VM config change via SSE for live UI updates
        try:
            updated_config = manager.get_vm_config(node, vmid, vm_type)
            if isinstance(updated_config, dict):
                cfg = updated_config.get("config", updated_config)
                broadcast_sse("vm_config", {"vmid": vmid, "node": node, "vm_type": vm_type, "config": cfg}, cluster_id)
        except Exception as e:
            logging.debug(f"Failed to broadcast vm_config SSE: {e}")

        # Audit log
        user = getattr(request, "session", {}).get("user", "system")
        changes = ", ".join([f"{k}={v}" for k, v in config_updates.items()][:5])
        log_audit(
            user,
            "vm.config_changed",
            f"{vm_type.upper()} {vmid} config updated: {changes}",
            cluster=manager.config.name,
        )
        # lgtm[py/reflected-xss]
        return jsonify({"message": result["message"]})
    else:
        # lgtm[py/reflected-xss]
        return jsonify({
            "error": result["error"]
        }), 500  # snyk:ignore:Cross-site Scripting (XSS)  # snyk:ignore:Server Information Exposure


@bp.route("/api/clusters/<cluster_id>/vms/<node>/<vm_type>/<int:vmid>/sanitize-boot-order", methods=["POST"])
@require_auth(perms=["vm.config"])
def sanitize_boot_order_api(cluster_id, node, vm_type, vmid):
    """Sanitize boot order by removing non-existent devices.

    Fixes 'invalid bootorder: device does not exist' errors.
    """
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()
    if cluster_id not in cluster_managers:
        # lgtm[py/reflected-xss]
        return jsonify({"error": "Cluster not found"}), 404

    # (perf) indexed single-row fetch — load_users() scanned/decrypted all users
    user = get_user_record(request.session["user"])
    user["username"] = request.session["user"]
    if not user_can_access_vm(user, cluster_id, vmid, "vm.config", vm_type):
        # lgtm[py/reflected-xss]
        return jsonify({"error": "Permission denied: vm.config"}), 403

    manager = cluster_managers[cluster_id]
    result = manager.sanitize_boot_order(node, vmid, vm_type)

    if result["success"]:
        if result.get("changed"):
            user = getattr(request, "session", {}).get("user", "system")
            log_audit(
                user,
                "vm.boot_order_sanitized",
                f"{vm_type.upper()} {vmid} boot order sanitized",
                cluster=manager.config.name,
            )
        # lgtm[py/reflected-xss]
        return jsonify(result)
    else:
        # lgtm[py/reflected-xss]
        return jsonify({
            "error": result["error"]
        }), 500  # snyk:ignore:Cross-site Scripting (XSS)  # snyk:ignore:Server Information Exposure
