# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/utils/vnc_grab.py
# Project:     ProxmoxVEx
# Version:     1.2.565
# Build:       2026.09.30
# Description: Vnc Grab PY source
# Usage:       import ProxmoxVEx.utils.vnc_grab
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-30
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
import contextlib
import io
import struct
import time
import warnings
from typing import Any, cast

# RFB message / security constants
_SEC_NONE = 1
_SEC_VNC = 2

_MSG_SET_PIXEL_FORMAT = 0
_MSG_SET_ENCODINGS = 2
_MSG_FB_UPDATE_REQUEST = 3

_SRV_FB_UPDATE = 0
_SRV_SET_COLORMAP = 1
_SRV_BELL = 2
_SRV_CUT_TEXT = 3

_ENC_RAW = 0

# safety cap: a 4096x4096x4 raw frame is 64MB; refuse anything sillier so a bogus
# ServerInit can't make us allocate the box to death.
_MAX_DIM = 4096
_MAX_RAW_BYTES = 64 * 1024 * 1024


def _reverse_bits(b):
    # VNC's DES variant mirrors the bit order of every key byte. Yes, really.
    return int(f"{b:08b}"[::-1], 2)


def _vnc_auth_response(password, challenge):
    """16-byte DES response to a 16-byte challenge, keyed by the (≤8 byte) password.

    cryptography dropped a standalone DES years ago, but TripleDES with the same
    8-byte key three times collapses to single-DES — which is exactly classic VNC
    auth. We already lean on this trick elsewhere in the VNC stack.
    """
    from cryptography.hazmat.primitives.ciphers import Cipher, modes

    # cryptography 48 moved TripleDES into the 'decrepit' namespace and dropped it
    # from primitives — prefer the new path, fall back for <48 installs.
    try:
        from cryptography.hazmat.decrepit.ciphers.algorithms import TripleDES
    except ImportError:
        # The primitives import emits CryptographyDeprecationWarning on every
        # version that still ships it — that warning is the whole reason this
        # fallback exists, so keep it out of logs and test summaries.
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            from cryptography.hazmat.primitives.ciphers.algorithms import TripleDES
    key = bytearray(8)
    pw = password[:8]
    for i in range(len(pw)):
        key[i] = _reverse_bits(pw[i])
    des3_key = bytes(key) * 3
    cipher = TripleDES(des3_key)  # nosec: B304  # lgtm[py/weak-cryptographic-algorithm]  # snyk:ignore:Use of a Broken or Risky Cryptographic Algorithm - required by the RFB/VNC auth challenge protocol
    enc = Cipher(cipher, modes.ECB()).encryptor()  # nosec: B305  # lgtm[py/weak-cryptographic-algorithm]  # snyk:ignore:Use of a Broken or Risky Cryptographic Algorithm - required by the RFB/VNC auth challenge protocol
    return enc.update(challenge) + enc.finalize()


class _WsReader:
    """RFB is a byte stream; the PVE proxy chops it into arbitrary binary WS
    frames. Buffer them so we can read exact-length RFB fields."""

    def __init__(self, ws):
        self.ws = ws
        self.buf = b""

    def read(self, n):
        while len(self.buf) < n:
            chunk = self.ws.recv()
            if chunk is None or chunk == "":
                raise OSError("vnc websocket closed mid-stream")
            if isinstance(chunk, str):
                # binary frames come back as bytes; a str means a control/text
                # frame slipped through — treat its raw bytes as stream data
                chunk = chunk.encode("latin-1")
            self.buf += chunk
        out, self.buf = self.buf[:n], self.buf[n:]
        return out


# 32bpp, depth 24, little-endian, true-colour, shifts R=16/G=8/B=0 → on the wire
# each pixel is bytes [B, G, R, X]. PIL's 'BGRX' raw decoder reads exactly that.
def _our_pixel_format():
    return struct.pack(
        ">BBBBHHHBBB3x",
        32,  # bits-per-pixel
        24,  # depth
        0,  # big-endian flag (0 = little)
        1,  # true-colour
        255,
        255,
        255,  # r/g/b max
        16,
        8,
        0,  # r/g/b shift
    )


def grab_frame(ws, vnc_ticket, timeout=8.0):
    """Run the RFB handshake on an already-connected PVE vncwebsocket and return
    a PIL.Image of the current framebuffer. `vnc_ticket` is the vncproxy ticket
    (used as the RFB password)."""
    from PIL import Image

    with contextlib.suppress(Exception):
        ws.settimeout(timeout)

    r = _WsReader(ws)

    # 1) ProtocolVersion — server greets, we echo a version we can speak.
    server_ver = r.read(12)
    if not server_ver.startswith(b"RFB "):
        raise OSError(f"not an RFB stream: {server_ver[:12]!r}")
    try:
        major = int(server_ver[4:7])
        minor = int(server_ver[8:11])
    except Exception:
        major, minor = 3, 8
    ws.send(b"RFB 003.008\n")

    # 2) Security. 3.7+ → server lists types, we pick. 3.3 → server dictates one.
    if (major, minor) >= (3, 7):
        n_types = r.read(1)[0]
        if n_types == 0:
            reason_len = struct.unpack(">I", r.read(4))[0]
            raise OSError("vnc security failed: {}".format(r.read(reason_len).decode("latin-1", "replace")))
        types = set(r.read(n_types))
        chosen = _SEC_VNC if _SEC_VNC in types else (_SEC_NONE if _SEC_NONE in types else None)
        if chosen is None:
            raise OSError(f"no supported vnc security type offered: {sorted(types)!r}")
        ws.send(bytes([chosen]))
    else:
        chosen = struct.unpack(">I", r.read(4))[0]

    # 3) VNC auth (challenge/response) when required.
    if chosen == _SEC_VNC:
        challenge = r.read(16)
        ws.send(_vnc_auth_response(vnc_ticket.encode("latin-1", "replace"), challenge))
        sec_result = struct.unpack(">I", r.read(4))[0]
        if sec_result != 0:
            # 3.8 appends a reason; older versions just drop.
            try:
                rl = struct.unpack(">I", r.read(4))[0]
                why = r.read(rl).decode("latin-1", "replace")
            except Exception:
                why = "auth rejected"
            raise OSError(f"vnc auth failed: {why}")

    # 4) ClientInit — shared=1 so we don't boot an existing console session.
    ws.send(b"\x01")

    # 5) ServerInit: width, height, pixel-format(16), name.
    head = r.read(4)
    fb_w, fb_h = struct.unpack(">HH", head)
    r.read(16)  # server's native pixel format — we override it below
    name_len = struct.unpack(">I", r.read(4))[0]
    if name_len:
        r.read(name_len)
    if fb_w <= 0 or fb_h <= 0 or fb_w > _MAX_DIM or fb_h > _MAX_DIM:
        raise OSError(f"implausible framebuffer size {fb_w}x{fb_h}")

    # 6) Pin our pixel format + Raw-only, then ask for the whole screen (non-incremental).
    ws.send(struct.pack(">Bxxx", _MSG_SET_PIXEL_FORMAT) + _our_pixel_format())
    ws.send(struct.pack(">BxH", _MSG_SET_ENCODINGS, 1) + struct.pack(">i", _ENC_RAW))
    ws.send(struct.pack(">BBHHHH", _MSG_FB_UPDATE_REQUEST, 0, 0, 0, fb_w, fb_h))

    # 7) Read messages until we get a FramebufferUpdate; skip bell/colormap/cut-text.
    img = Image.new("RGB", (fb_w, fb_h), (0, 0, 0))
    deadline_guard = 0
    while True:
        deadline_guard += 1
        if deadline_guard > 64:
            raise OSError("no framebuffer update after 64 server messages")
        msg_type = r.read(1)[0]
        if msg_type == _SRV_FB_UPDATE:
            r.read(1)  # padding
            n_rects = struct.unpack(">H", r.read(2))[0]
            for _ in range(n_rects):
                x, y, w, h, enc = struct.unpack(">HHHHi", r.read(12))
                if enc != _ENC_RAW:
                    raise OSError(f"server used unexpected encoding {enc}")
                nbytes = w * h * 4
                if nbytes > _MAX_RAW_BYTES:
                    raise OSError(f"raw rect too large ({nbytes} bytes)")
                if nbytes == 0:
                    continue
                data = r.read(nbytes)
                rect = Image.frombytes("RGB", (w, h), data, "raw", "BGRX")
                img.paste(rect, (x, y))
            return img
        elif msg_type == _SRV_SET_COLORMAP:
            r.read(3)  # padding + first-colour
            ncolors = struct.unpack(">H", r.read(2))[0]
            r.read(ncolors * 6)
        elif msg_type == _SRV_BELL:
            pass
        elif msg_type == _SRV_CUT_TEXT:
            r.read(3)  # padding
            tlen = struct.unpack(">I", r.read(4))[0]
            r.read(tlen)
        else:
            raise OSError(f"unexpected server message type {msg_type}")


def to_png_thumbnail(img, max_width=480):
    """Downscale to a tile-sized PNG. Keeps aspect ratio."""
    from PIL import Image

    if img.width > max_width:
        ratio = max_width / float(img.width)
        # Pillow >=9.1 canonical location (top-level BILINEAR alias was removed)
        img = img.resize((max_width, max(1, int(img.height * ratio))), Image.Resampling.BILINEAR)
    out = io.BytesIO()
    img.save(out, format="PNG", optimize=True)
    return out.getvalue()


# Tiny, non-destructive mouse nudge sent via qm monitor to wake a sleeping
# virtual display (Windows lock screen / DPMS off) before we try to grab it.
# A relative mouse move is used instead of a key so we don't type into a
# password field if the guest is already at the login prompt.
def _wake_qemu_display(pve_mgr, node, vmid, timeout=5):
    from ProxmoxVEx.utils.ssh import _pve_node_exec

    vmid = int(vmid)
    # Two tiny relative moves: enough to turn the display back on, not enough
    # to accidentally click or drag anything (the cursor ends where it started).
    cmd = f"printf 'mouse_move 1 1\\nmouse_move -1 -1\\n' | qm monitor {vmid} >/dev/null 2>&1"
    _pve_node_exec(pve_mgr, node, cmd, timeout=timeout)


def _screendump_raw(pve_mgr, node, vmid, remote, timeout):
    """Run one qm monitor screendump and return a PIL Image (or raise)."""
    import base64 as _b64
    import gzip as _gz

    from PIL import Image

    from ProxmoxVEx.utils.ssh import _pve_node_exec

    cmd = (
        f"echo screendump {remote} | qm monitor {vmid} >/dev/null 2>&1; "
        f"gzip -c {remote} 2>/dev/null | base64 | tr -d '\\n'; "
        f"rm -f {remote}"
    )
    rc, out, err = _pve_node_exec(pve_mgr, node, cmd, timeout=timeout)
    b64 = (out or "").strip()
    if not b64:
        raise OSError(f"screendump produced no data (rc={rc}, err={str(err)[:120]})")
    try:
        ppm = _gz.decompress(_b64.b64decode(b64))
    except Exception as e:
        raise OSError(f"screendump decode failed: {e}") from None

    img = Image.open(io.BytesIO(ppm))
    img.load()
    if img.mode != "RGB":
        img = img.convert("RGB")
    return img


# Preferred grab for the console tile. QEMU 'screendump' over
# qm monitor does NOT open a vncproxy, so it never shows up as a "console
# opened" task in the PVE log (the whole reason we moved off the RFB path).
# The frame comes back as a PPM; gzip+base64 it over the same node-exec path
# v2p already uses, then PIL -> PNG. Needs node exec (API /execute or SSH) —
# on API-token-only clusters without SSH this just fails and the tile falls
# back to the icon.
def screendump_to_png(pve_mgr, node, vmid, max_width=480, timeout=20):
    vmid = int(vmid)  # route already coerces, but be explicit before shelling out
    remote = f"/tmp/pp_shot_{vmid}.ppm"  # nosec: B108 - VNC temp path on remote Proxmox node

    img = _screendump_raw(pve_mgr, node, vmid, remote, timeout=timeout)
    ex = cast(Any, img.getextrema())  # RGB images return per-band tuples; stub types the union
    if max(hi for _lo, hi in ex) <= 10:
        # A powered-off / DPMS-asleep display dumps as pure black. Sending a
        # harmless input wakes the virtual monitor so the lock/login screen
        # renders; then we grab again before giving up.
        _wake_qemu_display(pve_mgr, node, vmid, timeout=5)
        time.sleep(1.5)  # give the guest time to repaint the framebuffer
        img = _screendump_raw(pve_mgr, node, vmid, remote, timeout=max(5, timeout - 7))
        ex = cast(Any, img.getextrema())

    # A genuinely off display (no GPU output, guest halted, etc.) still looks
    # like a black tile — keep the icon fallback instead of showing that.
    if max(hi for _lo, hi in ex) <= 10:
        raise OSError("blank framebuffer (display likely off)")
    return to_png_thumbnail(img, max_width=max_width)
