# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/converter/runner.py
# Project:     ProxmoxVEx
# Version:     1.2.566
# Build:       2026.09.30
# Description: Execute commands on a Proxmox node through the existing
#              ProxmoxVEx cluster manager. This keeps credential
#              handling inside the audited cluster manager.
# Usage:       import ProxmoxVEx.converter.runner
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-30
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""
Execute commands on a Proxmox node through the existing ProxmoxVEx cluster manager.
This keeps credential handling inside the audited cluster manager.
"""

from __future__ import annotations

import re
from dataclasses import dataclass

from ProxmoxVEx.globals import cluster_managers


@dataclass
class RunResult:
    """Result of a command executed on a Proxmox node."""

    returncode: int
    stdout: str
    stderr: str
    command: str

    @property
    def ok(self) -> bool:
        return self.returncode == 0


class NodeRunner:
    """Run commands on a Proxmox node using the ProxmoxVEx cluster manager."""

    def __init__(self, cluster_id: str, node: str):
        self.cluster_id = cluster_id
        self.node = node
        manager = cluster_managers.get(cluster_id)
        if manager is None:
            raise RuntimeError(f"Cluster '{cluster_id}' is not connected")
        self.manager = manager

    def run(self, command: list[str] | str, timeout: int = 300) -> RunResult:
        """Execute a command on the node and return stdout/stderr/exit code.

        Args:
            command: Either a list of arguments (preferred) or a shell string.
            timeout: Maximum seconds to wait for the command.
        """
        import shlex

        command_str = " ".join(shlex.quote(str(arg)) for arg in command) if isinstance(command, list) else command

        if not (self.manager is not None):
            raise AssertionError("invariant failed")
        ssh_user = getattr(self.manager.config, "ssh_user", "root") or "root"
        ssh_key = getattr(self.manager.config, "ssh_key", "")
        ssh_password = getattr(self.manager.config, "pass_", "")
        ssh_port = getattr(self.manager.config, "ssh_port", 22) or 22
        node_ip = self._resolve_node_ip()

        # The SSH helpers return stdout only and None when the remote command
        # exits non-zero. Append a trailing EXIT:<rc> marker so the real remote
        # exit status survives; without it a failed remote command (e.g.
        # `qm config` on a missing VM) was indistinguishable from a dead SSH
        # transport — both surfaced as rc=-1, which made pre-flight blame
        # "source does not exist" / "tools missing" whenever the node was
        # simply unreachable over SSH.
        marker_cmd = f"{command_str}\n_vex_rc=$?\necho EXIT:$_vex_rc"
        # Only pass a non-default port so test doubles mirroring the helper
        # signature without a `port` kwarg keep working.
        port_kw = {"port": ssh_port} if ssh_port != 22 else {}

        output = None
        if ssh_key:
            output = self.manager._ssh_run_command_with_key_output(
                node_ip, ssh_user, marker_cmd, ssh_key, timeout=timeout, **port_kw
            )
        if output is None:
            output = self.manager._ssh_run_command_output(node_ip, ssh_user, marker_cmd, timeout=timeout, **port_kw)
        if output is None and ssh_password:
            output = self.manager._ssh_run_command_with_password_output(
                node_ip, ssh_user, marker_cmd, ssh_password, timeout=timeout, **port_kw
            )

        if output is None:
            return RunResult(
                returncode=-1,
                stdout="",
                stderr="Command could not be executed (SSH connection failed)",
                command=command_str,
            )

        # The SSH helpers return stdout only and log stderr. A non-string
        # return is a broken transport (or a test double) — treat it like the
        # None case rather than crashing on the EXIT-marker regex.
        if not isinstance(output, str):
            return RunResult(
                returncode=-1,
                stdout="",
                stderr="Command could not be executed (SSH connection failed)",
                command=command_str,
            )
        return self._parse_status(command_str, output)

    @staticmethod
    def _parse_status(command_str: str, stdout: str) -> RunResult:
        """Split the trailing ``EXIT:<rc>`` marker off captured stdout."""
        text = stdout.rstrip()
        match = re.search(r"EXIT:(\d+)\s*$", text)
        if match:
            return RunResult(
                returncode=int(match.group(1)),
                stdout=text[: match.start()].rstrip("\n"),
                stderr="",
                command=command_str,
            )
        # No marker (remote shell died mid-command, or a test double bypassed
        # the wrapper): SSH delivered output, so keep the rc=0 contract.
        return RunResult(returncode=0, stdout=stdout, stderr="", command=command_str)

    def run_with_status(self, command: list[str] | str, timeout: int = 300) -> RunResult:
        """Execute a command and capture both exit code and output.

        Retained for API compatibility: ``run()`` now always appends the
        ``EXIT:`` marker and propagates the remote exit status, so this is a
        thin alias.
        """
        return self.run(command, timeout=timeout)

    def _resolve_node_ip(self) -> str:
        """Resolve the node's management IP through the cluster manager."""
        if not (self.manager is not None):
            raise AssertionError("invariant failed")
        # Primary path: the manager's VLAN-aware discovery — it scores the
        # node's interfaces, filters corosync/storage IPs, and TCP-probes the
        # SSH port. The /api2/json/nodes listing that feeds `manager.nodes`
        # carries no ip/host fields, so consulting it alone always fell
        # through to the bare node name — which fails whenever the VEx host
        # cannot resolve e.g. "pve2" via DNS.
        get_ip = getattr(self.manager, "_get_node_ip", None)
        if callable(get_ip):
            try:
                ip = get_ip(self.node)
            except Exception:
                ip = None
            if ip:
                return str(ip)
        nodes = getattr(self.manager, "nodes", {})
        node_info = nodes.get(self.node, {})
        ip = node_info.get("ip") or node_info.get("host")
        if ip:
            return ip
        # Fallback: use the configured cluster host if node name matches.
        cluster_host = getattr(self.manager.config, "host", "")
        if cluster_host and self.node in (cluster_host, "localhost"):
            return cluster_host
        return self.node


def get_runner(cluster_id: str, node: str) -> NodeRunner:
    return NodeRunner(cluster_id, node)
