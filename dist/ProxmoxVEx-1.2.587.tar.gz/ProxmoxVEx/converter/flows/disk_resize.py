# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/converter/flows/disk_resize.py
# Project:     ProxmoxVEx
# Version:     1.2.582
# Build:       2026.10.01
# Description: Shrink/expand LXC and VM disks.
# Usage:       import ProxmoxVEx.converter.flows.disk_resize
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-10-01
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""
Shrink/expand LXC and VM disks.
"""

from __future__ import annotations

import contextlib
import json
import logging
import re

from ProxmoxVEx.converter import commands as cmd
from ProxmoxVEx.converter.constants import MIN_DISK_GB, JobOperation
from ProxmoxVEx.converter.models import ConversionJob
from ProxmoxVEx.converter.runner import NodeRunner


def run_disk_resize(job: ConversionJob, runner: NodeRunner, target_runner: NodeRunner, engine) -> None:
    """Execute disk shrink/expand for an LXC container or VM."""
    if job.source is None:
        raise RuntimeError("Disk resize requires a source workload")
    workload_id = job.source.id
    operation = job.operation

    # Validate before stopping anything — a job missing its target size can
    # never succeed, so it must not power off the workload first. Shrink
    # ops may leave it blank: the size is auto-calculated (used space +
    # headroom) once the filesystem/disk is readable.
    target_size_gb = job.target_disk_size_gb
    if not target_size_gb and operation in (
        JobOperation.EXPAND_LXC,
        JobOperation.EXPAND_VM,
    ):
        raise RuntimeError("Disk resize operation requires target_disk_size_gb")

    engine.set_phase(job, "stopping_workload", progress=5)
    if job.source.type.value == "lxc":
        stop_result = runner.run(cmd.pct_stop(workload_id), timeout=60)
        _require_stopped(runner, cmd.pct_status(workload_id), stop_result, workload_id)
    else:
        stop_result = runner.run(cmd.qm_stop(workload_id), timeout=60)
        _require_stopped(runner, cmd.qm_status(workload_id), stop_result, workload_id)

    try:
        if operation in (JobOperation.SHRINK_LXC, JobOperation.EXPAND_LXC):
            _resize_lxc_disk(job, runner, engine, target_size_gb)
        elif operation in (JobOperation.SHRINK_VM, JobOperation.EXPAND_VM):
            _resize_vm_disk(job, runner, engine, target_size_gb)
        else:
            raise RuntimeError(f"Unsupported resize operation: {operation}")

        engine.set_phase(job, "completed", progress=100)
        engine.mark_succeeded(job)
    except Exception:
        logging.exception("Disk resize failed for job %s", job.id)
        raise


def _require_stopped(runner: NodeRunner, status_cmd: list[str], stop_result, workload_id: int) -> None:
    """Ensure the workload is stopped before its disk is mutated.

    ``pct stop``/``qm stop`` exit non-zero when the workload was already
    stopped, so the status is only checked when the stop command failed;
    an unverifiable or still-running workload aborts the resize.
    """
    if stop_result.ok:
        return
    status = runner.run(status_cmd, timeout=15)
    if status.ok and "status: stopped" in status.stdout:
        return
    raise RuntimeError(
        f"Could not stop workload {workload_id} before disk resize: "
        f"{stop_result.stderr or 'stop command failed'}"
    )


def _resize_lxc_disk(
    job: ConversionJob, runner: NodeRunner, engine, target_size_gb: int | None
) -> None:
    if job.source is None:
        raise RuntimeError("Disk resize requires a source workload")
    ctid = job.source.id

    if job.operation == JobOperation.EXPAND_LXC:
        if not target_size_gb:
            raise RuntimeError("expand_lxc requires target_disk_size_gb")
        engine.set_phase(job, "expanding_container_disk", progress=50)
        result = runner.run(
            ["pct", "resize", str(ctid), "rootfs", f"{target_size_gb}G"],
            timeout=120,
        )
        if not result.ok:
            raise RuntimeError(f"Failed to expand LXC disk: {result.stderr}")
        return

    # Shrink path: resize filesystem first, then shrink the volume. When the
    # target is blank the filesystem shrink computes it (used + headroom)
    # and returns the effective size for the volume resize.
    engine.set_phase(job, "shrinking_filesystem", progress=35)
    effective_gb = _shrink_lxc_filesystem(runner, ctid, target_size_gb, job.headroom_gb)

    engine.set_phase(job, "shrinking_container_disk", progress=75)
    result = runner.run(
        ["pct", "resize", "--shrink", str(ctid), "rootfs", f"{effective_gb}G"],
        timeout=120,
    )
    if not result.ok:
        raise RuntimeError(f"Failed to shrink LXC disk: {result.stderr}")


def _shrink_lxc_filesystem(
    runner: NodeRunner, ctid: int, target_size_gb: int | None, headroom_gb: int
) -> int:
    """Mount LXC rootfs, check and resize ext4 filesystem offline.

    Returns the effective target size in GB — the requested size, or
    used-space + headroom when the request left it blank.
    """
    mount_result = runner.run(cmd.pct_mount(ctid), timeout=30)
    if not mount_result.ok:
        raise RuntimeError(f"Failed to mount container for filesystem shrink: {mount_result.stderr}")

    try:
        rootfs = f"/var/lib/lxc/{ctid}/rootfs"
        runner.run(["bash", "-c", f"umount {rootfs}/dev/null {rootfs}/proc {rootfs}/sys 2>/dev/null; true"], timeout=10)
        # Find the underlying block device for the container rootfs
        df_result = runner.run(["df", "-P", rootfs], timeout=10)
        device = None
        used_kb = 0
        if df_result.ok:
            lines = df_result.stdout.strip().splitlines()
            if len(lines) >= 2:
                fields = lines[1].split()
                device = fields[0]
                if len(fields) > 2 and fields[2].isdigit():
                    used_kb = int(fields[2])

        if not device:
            raise RuntimeError("Could not determine rootfs block device for shrink")

        effective_gb = target_size_gb
        if not effective_gb:
            # Auto-calculate: filesystem usage + headroom, mirroring the
            # lxc_to_vm convention (_calculate_target_disk_gb).
            used_gb = (used_kb + 1048575) // 1048576  # KiB → GiB, ceil
            effective_gb = max(MIN_DISK_GB, used_gb + headroom_gb)

        # Force check and resize. e2fsck exits 0 (clean) or 1 (errors
        # corrected) — resize2fs requires a consistent filesystem, so
        # anything above 1 must abort the shrink.
        fsck = runner.run(["e2fsck", "-f", "-y", device], timeout=120)
        if fsck.returncode > 1:
            raise RuntimeError(
                f"Filesystem check failed (exit {fsck.returncode}): {fsck.stderr}"
            )
        resize = runner.run(["resize2fs", device, f"{effective_gb}G"], timeout=120)
        if not resize.ok:
            raise RuntimeError(f"Failed to resize filesystem: {resize.stderr}")
        return effective_gb
    finally:
        runner.run(cmd.pct_unmount(ctid), timeout=30)


def _resize_vm_disk(
    job: ConversionJob, runner: NodeRunner, engine, target_size_gb: int | None
) -> None:
    if job.source is None:
        raise RuntimeError("Disk resize requires a source workload")
    vmid = job.source.id
    disk_name, volid = _get_primary_vm_disk(runner, vmid)
    if not disk_name or not volid:
        raise RuntimeError(f"Could not determine primary disk for VM {vmid}")

    disk_path = _resolve_volid_path(runner, volid)

    if job.operation == JobOperation.EXPAND_VM:
        if not target_size_gb:
            raise RuntimeError("expand_vm requires target_disk_size_gb")
        engine.set_phase(job, "expanding_vm_disk", progress=50)
        current_gb = _get_disk_size_gb(runner, disk_path)
        delta_gb = target_size_gb - current_gb
        if delta_gb <= 0:
            raise RuntimeError(f"Target size {target_size_gb}GB is not larger than current size {current_gb}GB")
        result = runner.run(cmd.qm_resize(vmid, disk_name, delta_gb), timeout=120)
        if not result.ok:
            raise RuntimeError(f"Failed to expand VM disk: {result.stderr}")
        return

    # Shrink VM disk offline via qemu-img resize --shrink. The detach must
    # succeed — resizing the image while the VM still owns it is unsafe.
    effective_gb = target_size_gb or _auto_vm_disk_gb(runner, disk_path, job.headroom_gb)
    engine.set_phase(job, "shrinking_vm_disk", progress=50)
    detach = runner.run(["qm", "set", str(vmid), f"--{disk_name}", "none,media=cdrom"], timeout=30)
    if not detach.ok:
        raise RuntimeError(f"Failed to detach VM disk for offline resize: {detach.stderr}")
    try:
        result = runner.run(cmd.qemu_img_resize(disk_path, effective_gb, shrink=True), timeout=300)
        if not result.ok:
            raise RuntimeError(f"Failed to shrink VM disk image: {result.stderr}")
    finally:
        runner.run(cmd.qm_set_disk(vmid, disk_name, volid), timeout=30)


def _auto_vm_disk_gb(runner: NodeRunner, disk_path: str, headroom_gb: int) -> int:
    """Smallest safe shrink target: end of the last guest partition + headroom.

    An image truncate must not cut inside a partition, so the floor is the
    guest partition-table boundary — not allocated extents (a thin volume
    can hold data at any guest offset) and not the virtual size.
    """
    device, cleanup = _guest_disk_device(runner, disk_path)
    try:
        end_bytes = _last_partition_end(runner, device)
    finally:
        cleanup()
    auto_gb = max(MIN_DISK_GB, -(-end_bytes // (1024**3)) + headroom_gb)
    current_gb = _get_disk_size_gb(runner, disk_path)
    if current_gb and auto_gb >= current_gb:
        raise RuntimeError(
            f"Cannot auto-shrink: guest partitions occupy the full "
            f"{current_gb}GB disk — shrink the filesystem and partition "
            "inside the guest first, or specify a target size."
        )
    return auto_gb


def _guest_disk_device(runner: NodeRunner, disk_path: str):
    """Return (device_path, cleanup) usable by sfdisk/fdisk.

    Block devices (LVM, ZFS zvol) and raw image files are readable
    directly; qcow2 images must be attached through qemu-nbd so the
    guest-visible bytes appear as a block device.
    """
    fmt = ""
    info = runner.run(cmd.qemu_img_info(disk_path), timeout=15)
    if info.ok:
        with contextlib.suppress(json.JSONDecodeError):
            fmt = json.loads(info.stdout).get("format") or ""
    if fmt != "qcow2":
        return disk_path, lambda: None

    runner.run(["modprobe", "nbd", "max_part=8"], timeout=15)
    for index in range(8):
        dev = f"/dev/nbd{index}"
        attach = runner.run(["qemu-nbd", "--connect", dev, disk_path], timeout=30)
        if attach.ok:
            # Best-effort kernel partition-table reload — sfdisk reads the
            # primary header itself, so partprobe failing is harmless.
            runner.run(["partprobe", dev], timeout=10)
            return dev, lambda d=dev: runner.run(["qemu-nbd", "--disconnect", d], timeout=15)
    raise RuntimeError(
        "Could not attach the qcow2 image via qemu-nbd (nbd module or "
        "devices unavailable); specify a target size."
    )


def _last_partition_end(runner: NodeRunner, device: str) -> int:
    """Byte offset just past the last guest partition.

    Includes a 1 MiB cushion so a GPT backup header survives the truncate.
    """
    result = runner.run(["sfdisk", "--json", device], timeout=15)
    if result.ok:
        try:
            table = json.loads(result.stdout).get("partitiontable") or {}
            sector = int(table.get("sectorsize") or 512)
            ends = [
                int(p["start"]) + int(p["size"])
                for p in table.get("partitions", [])
            ]
            if ends:
                return max(ends) * sector + (1 << 20)
        except (KeyError, TypeError, ValueError):
            pass

    # fdisk fallback for nodes without sfdisk JSON support.
    result = runner.run(["fdisk", "-l", device], timeout=15)
    if result.ok:
        sector = 512
        ends = []
        for line in result.stdout.splitlines():
            m = re.match(r"^Units: sectors of 1 \* (\d+)", line)
            if m:
                sector = int(m.group(1))
                continue
            fields = line.split()
            if (len(fields) >= 3 and fields[0].startswith(device)
                    and fields[1].isdigit() and fields[2].isdigit()):
                ends.append(int(fields[2]))
        if ends:
            return max(ends) * sector + (1 << 20)

    raise RuntimeError(
        f"Could not read the guest partition table on {device}; "
        "specify a target size."
    )


def _infer_lxc_storage(runner: NodeRunner, ctid: int) -> str:
    result = runner.run(cmd.pct_config(ctid), timeout=15)
    if result.ok:
        for line in result.stdout.splitlines():
            if line.startswith("rootfs:"):
                return line.split(":", 1)[1].strip().split(":")[0]
    return "local-lvm"


_VM_DISK_RE = re.compile(r"^(scsi|ide|sata|virtio)(\d+):\s*(.+)$")


def _get_primary_vm_disk(runner: NodeRunner, vmid: int) -> tuple[str | None, str | None]:
    """Return the VM's lowest-slotted attached disk as (disk_name, volid).

    PVE assigns disks to arbitrary slots (scsi1, virtio2, ...), so matching
    only slot 0 misses VMs whose first disk sits elsewhere. CD-ROM drives
    (media=cdrom) are not disks and are skipped.
    """
    result = runner.run(cmd.qm_config(vmid), timeout=15)
    if not result.ok:
        return None, None
    candidates: list[tuple[int, str, str]] = []
    for line in result.stdout.splitlines():
        m = _VM_DISK_RE.match(line.strip())
        if not m or "media=cdrom" in line:
            continue
        volid = m.group(3).split(",")[0].strip()
        candidates.append((int(m.group(2)), f"{m.group(1)}{m.group(2)}", volid))
    if not candidates:
        return None, None
    _, disk_name, volid = sorted(candidates)[0]
    return disk_name, volid


def _resolve_volid_path(runner: NodeRunner, volid: str) -> str:
    result = runner.run(cmd.pvesm_path(volid), timeout=15)
    if result.ok:
        return result.stdout.strip()
    return volid


def _get_disk_size_gb(runner: NodeRunner, disk_path: str) -> int:
    result = runner.run(cmd.qemu_img_info(disk_path), timeout=15)
    if result.ok:
        try:
            info = json.loads(result.stdout)
            return info.get("virtual-size", 0) // (1024**3)
        except json.JSONDecodeError:
            pass
    return 0
