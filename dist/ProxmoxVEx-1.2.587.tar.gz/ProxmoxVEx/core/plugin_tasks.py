# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/core/plugin_tasks.py
# Project:     ProxmoxVEx
# Version:     1.2.565
# Build:       2026.09.30
# Description: Plugin task registry.
# Usage:       import ProxmoxVEx.core.plugin_tasks
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-30
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""
Plugin task registry.

A plugin calls ``record_plugin_task`` whenever one of its background jobs
changes state. Rows land in a small ``plugin_tasks`` table keyed by a
synthetic upid ``PLUGIN:<plugin>:<job>``; the task-bar feed (SSE broadcast
+ cluster tasks API) turns them into task-shaped rows so plugin work shows
up in the same tray as Proxmox node tasks.

The ``_plugin`` marker lets the frontend route log clicks to the plugin's
own job-output endpoint instead of a node task log.
"""

import logging
import threading
import time

_ensure_lock = threading.Lock()
_ensured = False

# Task-bar lifecycle mapping: plugin job states → Proxmox-style status/exit
# pairs so the tray's running filter and status cells behave correctly.
_STATUS_MAP = {
    "pending": ("queued", ""),
    "running": ("running", ""),
    "awaiting_input": ("awaiting input", ""),
    "completed": ("stopped", "OK"),
    "failed": ("stopped", "FAILED"),
    "cancelled": ("stopped", "CANCELLED"),
}

# Display names for the tray's Node column — plugin tasks aren't node-bound,
# so the column carries the plugin's human name instead of a blank cell.
_PLUGIN_NAMES = {
    "vm-update-manager": "VM Update Manager",
}


def _ensure_table(db):
    """Idempotent CREATE — lazy so plugins can call it without caring about
    app init order; runs once per process."""
    global _ensured
    if _ensured:
        return
    with _ensure_lock:
        if _ensured:
            return
        db.execute("""
            CREATE TABLE IF NOT EXISTS plugin_tasks (
                upid TEXT PRIMARY KEY,
                plugin TEXT NOT NULL,
                cluster_id TEXT,
                type TEXT NOT NULL,
                detail TEXT,
                status TEXT NOT NULL,
                exitstatus TEXT,
                username TEXT,
                starttime INTEGER,
                endtime INTEGER
            )
        """)
        _ensured = True


def record_plugin_task(
    plugin,
    job_id,
    cluster_id,
    task_type,
    detail="",
    status="pending",
    user="",
    starttime=None,
    endtime=None,
):
    """Upsert a plugin job into the task registry.

    ``status`` is a plugin job state (pending/running/awaiting_input/
    completed/failed/cancelled) — mapped to tray semantics on read.
    """
    try:
        from ProxmoxVEx.core.db import get_db

        db = get_db()
        _ensure_table(db)
        upid = f"PLUGIN:{plugin}:{job_id}"
        db.execute(
            """INSERT INTO plugin_tasks
               (upid, plugin, cluster_id, type, detail, status, username, starttime, endtime)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
               ON CONFLICT(upid) DO UPDATE SET
                   status=excluded.status,
                   endtime=COALESCE(excluded.endtime, plugin_tasks.endtime),
                   detail=COALESCE(NULLIF(excluded.detail, ''), plugin_tasks.detail),
                   username=COALESCE(NULLIF(excluded.username, ''), plugin_tasks.username)
            """,
            (
                upid,
                plugin,
                cluster_id,
                task_type,
                detail or "",
                status,
                user or "",
                int(starttime or time.time()),
                int(endtime) if endtime else None,
            ),
        )
    except Exception as e:
        # The registry is best-effort UI plumbing — never let it break a job.
        logging.debug(f"[plugin_tasks] record failed for {plugin}:{job_id}: {e}")


def list_plugin_tasks(cluster_id=None, limit=50):
    """Task-bar shaped rows for a cluster, newest first.

    Mirrors _get_recent_audit_tasks output fields so the frontend treats them
    like regular tasks; ``_plugin`` marks rows whose logs come from the
    plugin's job endpoint rather than a node task log.
    """
    try:
        from ProxmoxVEx.core.db import get_db

        db = get_db()
        _ensure_table(db)
        if cluster_id:
            rows = db.query(
                "SELECT * FROM plugin_tasks WHERE cluster_id = ? ORDER BY starttime DESC LIMIT ?",
                (cluster_id, limit),
            )
        else:
            rows = db.query(
                "SELECT * FROM plugin_tasks ORDER BY starttime DESC LIMIT ?",
                (limit,),
            )
        out = []
        for r in rows:
            tray_status, exitstatus = _STATUS_MAP.get(r["status"], (r["status"], ""))
            out.append({
                "upid": r["upid"],
                "node": _PLUGIN_NAMES.get(r["plugin"], r["plugin"]),
                "type": r["type"],
                "status": tray_status,
                "exitstatus": exitstatus or r.get("exitstatus", ""),
                "starttime": r["starttime"],
                "endtime": r["endtime"],
                "user": "",
                "ProxmoxVEx_user": r["username"] or "",
                "id": r["detail"] or "",
                "cluster_id": r["cluster_id"],
                "_plugin": r["plugin"],  # frontend marker → plugin job log
                "_detail": r["detail"] or "",
            })
        return out
    except Exception as e:
        logging.debug(f"[plugin_tasks] list failed: {e}")
        return []


def prune_plugin_tasks(keep_per_plugin=200):
    """Bound the table — keep the newest N rows per plugin. Called lazily
    from record so it self-maintains without a scheduler."""
    try:
        from ProxmoxVEx.core.db import get_db

        db = get_db()
        db.execute(
            """DELETE FROM plugin_tasks WHERE upid NOT IN (
                   SELECT upid FROM (
                       SELECT upid, ROW_NUMBER() OVER (
                           PARTITION BY plugin ORDER BY starttime DESC
                       ) AS rn FROM plugin_tasks
                   ) WHERE rn <= ?
               )""",
            (keep_per_plugin,),
        )
    except Exception as e:
        logging.debug(f"[plugin_tasks] prune failed: {e}")
