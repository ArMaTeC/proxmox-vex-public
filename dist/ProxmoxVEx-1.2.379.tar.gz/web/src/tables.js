/* --- ProxmoxVEx auto-header start ---
 * -------------------------------------------------------------------
 * File:        web/src/tables.js
 * Project:     ProxmoxVEx
 * Version:     1.2.378
 * Build:       2026.09.04
 * Description: Tables JS source
 * Docs:        https://proxmoxvex.local/docs
 * Generated:   2026-09-04
 * -------------------------------------------------------------------
 * --- ProxmoxVEx auto-header end --- */
function getProxmoxNodeHost(target = {}, fallbackName = '') {
    const candidates = [
        target.node_ip,
        target.nodeIp,
        target.host,
        target.current_host,
        target.management_ip,
        target.managementIp,
        target.ip_address,
        target.ipAddress,
        target.ip,
        target.hostname,
        target.node_host,
        target.nodeHost,
        fallbackName
    ];
    const match = candidates.find(value => typeof value === 'string' && value.trim());
    return match ? match.trim() : null;
}

function getProxmoxObjectUrl(target = {}) {
    const kind = target.kind || target.type;
    const host = getProxmoxNodeHost(target, target.node || target.name);
    if (!host) return null;

    if (kind === 'node') {
        const nodeName = target.name || target.node;
        if (!nodeName) return null;
        return `https://${host}:8006/#v1:0:=${encodeURIComponent(`node/${nodeName}`)}:4:=aptrepositories:=contentIso:::9::`;
    }

    if (kind === 'qemu' || kind === 'lxc') {
        if (target.vmid == null || target.vmid === '') return null;
        return `https://${host}:8006/#v1:0:=${encodeURIComponent(`${kind}/${target.vmid}`)}:4:::::::`;
    }

    return null;
}

function openProxmoxObject(target) {
    const url = getProxmoxObjectUrl(target);
    if (!url) return;
    window.open(url, '_blank', 'noopener,noreferrer');
}

function isGuestTemplate(resource = {}) {
    return resource.template === 1 || resource.template === '1' || resource.template === true;
}

function getGuestTypeLabel(resource = {}) {
    return resource.type === 'qemu' ? 'VM' : 'LXC';
}

function getGuestTypeIcon(resource = {}) {
    return resource.type === 'qemu' ? <Icons.VM /> : <Icons.Container />;
}

function getTemplateLabel(t) {
    return t('template');
}

function getGuestTypeTitle(resource = {}, t) {
    const typeLabel = getGuestTypeLabel(resource);
    return isGuestTemplate(resource) ? `${typeLabel} (${getTemplateLabel(t)})` : typeLabel;
}

// Node Card Component
function NodeCard({ name, metrics, index, clusterId, onMaintenanceToggle, onStartUpdate, onOpenNodeConfig, onNodeAction, onRemoveNode, onMoveNode }) {
    const { isCorporate } = useLayout();
    const { t } = useTranslation();
    const { getAuthHeaders } = useAuth();
    // 20 data points = last ~40s of sparkline at 2s polling interval
    const historyRef = useRef({
        cpu: Array(20).fill(0),
        mem: Array(20).fill(0),
        disk: Array(20).fill(0),
        netin: Array(20).fill(0),
        netout: Array(20).fill(0)
    });
    const [, forceUpdate] = useState(0);
    const [showMaintenanceConfirm, setShowMaintenanceConfirm] = useState(false);
    const [showUpdateConfirm, setShowUpdateConfirm] = useState(false);
    const [updateWithReboot, setUpdateWithReboot] = useState(true);
    const [showUpdateLog, setShowUpdateLog] = useState(false);
    const [showRebootConfirm, setShowRebootConfirm] = useState(false);
    const [showShutdownConfirm, setShowShutdownConfirm] = useState(false);
    const [actionLoading, setActionLoading] = useState(null);
    const [expanded, setExpanded] = useState(false);
    const lastMetricsRef = useRef(null);

    // auto-dismiss update banner after 30s when completed (#183)
    useEffect(() => {
        if (!metrics?.is_updating || !metrics?.update_task) return;
        const st = metrics.update_task.status;
        if (st !== 'completed' && st !== 'failed') return;
        const timer = setTimeout(async () => {
            try {
                await fetch(`${API_URL}/clusters/${clusterId}/nodes/${name}/update`, {
                    method: 'DELETE', credentials: 'include', headers: getAuthHeaders()
                });
            } catch (e) { }
        }, st === 'completed' ? 30000 : 120000);  // 30s for success, 2min for failed
        return () => clearTimeout(timer);
    }, [metrics?.update_task?.status]);

    useEffect(() => {
        if (metrics && metrics !== lastMetricsRef.current) {
            lastMetricsRef.current = metrics;

            // #419 follow-up: backend netin/netout are already a rate (bytes/sec, rrddata AVERAGE),
            // not a cumulative counter — divide directly, no delta-over-time.
            historyRef.current = {
                cpu: [...historyRef.current.cpu.slice(1), metrics.cpu_percent || 0],
                mem: [...historyRef.current.mem.slice(1), metrics.mem_percent || 0],
                disk: [...historyRef.current.disk.slice(1), metrics.disk_percent || 0],
                netin: [...historyRef.current.netin.slice(1), (metrics.netin || 0) / 1048576], // MB/s
                netout: [...historyRef.current.netout.slice(1), (metrics.netout || 0) / 1048576]
            };
            forceUpdate(n => n + 1);
        }
    }, [metrics?.cpu_percent, metrics?.mem_percent, metrics?.disk_percent, metrics?.netin, metrics?.netout]);

    const history = historyRef.current;

    const formatBytes = (bytes) => {
        if (!bytes) return '0 B';
        const k = 1024, s = ['B', 'KB', 'MB', 'GB', 'TB', 'PB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return (bytes / Math.pow(k, i)).toFixed(1) + ' ' + s[i];
    };

    const formatUptime = (seconds) => {
        const days = Math.floor(seconds / 86400);
        const hours = Math.floor((seconds % 86400) / 3600);
        const mins = Math.floor((seconds % 3600) / 60);
        if (days > 0) return `${days}d ${hours}h`;
        if (hours > 0) return `${hours}h ${mins}m`;
        return `${mins}m`;
    };

    if (!metrics) return null;

    const isInMaintenance = metrics.maintenance_mode;
    const maintenanceTask = metrics.maintenance_task;
    const isUpdating = metrics.is_updating;
    const updateTask = metrics.update_task;
    const isOffline = metrics.offline || metrics.status === 'offline';
    const proxmoxTarget = { ...metrics, kind: 'node', name, node: name };
    const proxmoxUrl = getProxmoxObjectUrl(proxmoxTarget);

    // Can only update if in maintenance and evacuation complete
    const canUpdate = isInMaintenance &&
        maintenanceTask?.status &&
        ['completed', 'completed_with_errors'].includes(maintenanceTask.status) &&
        !isUpdating;

    // Show simplified card for offline nodes
    if (isOffline) {
        return (
            <div
                className="relative card-hover bg-proxmox-card border-2 border-red-500/50 rounded-xl p-5 animate-slide-up"
                style={{ animationDelay: `${index * 100}ms` }}
            >
                <div className="absolute top-2 right-2 flex items-center gap-2">
                    {proxmoxUrl && (
                        <button
                            onClick={() => openProxmoxObject(proxmoxTarget)}
                            className="p-1.5 rounded-lg bg-proxmox-dark/80 text-gray-300 hover:text-white hover:bg-proxmox-hover transition-colors"
                            title={t('openInProxmox')}
                        >
                            <Icons.ExternalLink className="w-4 h-4" />
                        </button>
                    )}
                    <span className="px-2 py-1 bg-red-500 text-white text-xs font-bold rounded animate-pulse">
                        OFFLINE
                    </span>
                </div>
                <div className="flex items-center gap-3 mb-4">
                    <div className="p-2 bg-red-500/20 rounded-lg">
                        <Icons.Server className="text-red-400" />
                    </div>
                    <div>
                        <h3 className="font-semibold text-white">{name}</h3>
                        <div className="flex items-center gap-2 mt-1">
                            <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />
                            <span className="text-xs text-red-400">offline</span>
                        </div>
                    </div>
                </div>
                <div className="space-y-3 opacity-50">
                    <div>
                        <div className="flex justify-between text-xs mb-1">
                            <span className="text-gray-500">CPU</span>
                            <span className="text-gray-500">--</span>
                        </div>
                        <div className="h-2 bg-proxmox-dark rounded-full" />
                    </div>
                    <div>
                        <div className="flex justify-between text-xs mb-1">
                            <span className="text-gray-500">RAM</span>
                            <span className="text-gray-500">--</span>
                        </div>
                        <div className="h-2 bg-proxmox-dark rounded-full" />
                    </div>
                </div>
                {metrics.last_seen && (
                    <div className="mt-4 pt-3 border-t border-red-500/30 text-xs text-red-400">
                        <Icons.AlertTriangle className="inline w-3 h-3 mr-1" />
                        {t('lastSeen')}: {fmtDate(metrics.last_seen)}
                    </div>
                )}
            </div>
        );
    }

    return (
        <div
            className={`card-hover bg-proxmox-card border rounded-xl p-5 animate-slide-up ${isUpdating ? 'border-blue-500/50 bg-blue-500/5' :
                isInMaintenance ? 'border-yellow-500/50 bg-yellow-500/5' : 'border-proxmox-border'
                }`}
            style={{ animationDelay: `${index * 100}ms` }}
        >
            {/* Update Banner */}
            {isUpdating && updateTask && (
                <div className="mb-4 -mt-1 -mx-1">
                    <div className={`${updateTask.status === 'failed' ? 'bg-red-500/10 border-red-500/30' :
                        updateTask.status === 'completed' ? 'bg-green-500/10 border-green-500/30' :
                            'bg-blue-500/10 border-blue-500/30'
                        } border rounded-lg p-3`}>
                        <div className="flex items-center justify-between mb-2">
                            <div className="flex items-center gap-2">
                                {updateTask.status === 'completed' ? (
                                    <Icons.CheckCircle className="text-green-400" />
                                ) : updateTask.status === 'failed' ? (
                                    <Icons.XCircle className="text-red-400" />
                                ) : (
                                    <Icons.RotateCw className="animate-spin" />
                                )}
                                <span className={`${updateTask.status === 'failed' ? 'text-red-400' :
                                    updateTask.status === 'completed' ? 'text-green-400' :
                                        'text-blue-400'
                                    } font-semibold text-sm`}>
                                    {updateTask.status === 'failed' ? t('updateFailed') :
                                        updateTask.status === 'completed' ? t('updateCompleted') :
                                            t('updateRunning')}
                                </span>
                            </div>
                            <div className="flex items-center gap-2">
                                <span className={`text-xs px-2 py-0.5 rounded ${updateTask.status === 'completed' ? 'bg-green-500/20 text-green-400' :
                                    updateTask.status === 'failed' ? 'bg-red-500/20 text-red-400' :
                                        'bg-blue-500/20 text-blue-400'
                                    }`}>
                                    {updateTask.phase === 'apt_update' ? 'apt update' :
                                        updateTask.phase === 'apt_upgrade' ? 'apt upgrade' :
                                            updateTask.phase === 'reboot' ? 'Reboot' :
                                                updateTask.phase === 'wait_online' ? t('waitingForNode') :
                                                    updateTask.phase === 'done' ? t('done') :
                                                        updateTask.status}
                                </span>
                                {/* Dismiss button for completed/failed */}
                                {(updateTask.status === 'completed' || updateTask.status === 'failed') && (
                                    <button
                                        onClick={async (e) => {
                                            e.stopPropagation();
                                            try {
                                                await fetch(`${API_URL}/clusters/${clusterId}/nodes/${name}/update`, {
                                                    method: 'DELETE',
                                                    credentials: 'include',
                                                    headers: getAuthHeaders()
                                                });
                                            } catch (e) { }
                                        }}
                                        className="text-xs text-gray-300 hover:text-white px-2 py-1 bg-proxmox-hover hover:bg-proxmox-border rounded transition-colors"
                                        title={t('dismissUpdate')}
                                    >
                                        ✕ {t('dismiss')}
                                    </button>
                                )}
                            </div>
                        </div>

                        {/* Log Output */}
                        <div
                            className="bg-proxmox-darker rounded p-2 font-mono text-xs max-h-32 overflow-y-auto cursor-pointer"
                            onClick={() => setShowUpdateLog(true)}
                        >
                            {updateTask.output_lines?.slice(-5).map((line, idx) => (
                                <div key={idx} className="text-gray-400 truncate">
                                    {line.text}
                                </div>
                            ))}
                        </div>

                        {updateTask.status === 'completed' && (
                            <div className="mt-2 text-xs text-green-400">
                                ✅ {t('updateCompleted')} {updateTask.packages_upgraded} {t('packagesUpdated')}
                            </div>
                        )}

                        {updateTask.status === 'failed' && (
                            <div className="mt-2 space-y-2">
                                <div className="text-xs text-red-400">
                                    ❌ {t('error')}: {updateTask.error}
                                </div>
                                <button
                                    onClick={async () => {
                                        // First clear the update status
                                        try {
                                            await fetch(`${API_URL}/clusters/${clusterId}/nodes/${name}/update`, {
                                                method: 'DELETE',
                                                credentials: 'include',
                                                headers: getAuthHeaders()
                                            });
                                        } catch (e) { }
                                        // Then exit maintenance mode
                                        if (onMaintenanceToggle) onMaintenanceToggle(name, false);
                                    }}
                                    className="w-full px-3 py-1.5 bg-red-500/20 hover:bg-red-500/30 border border-red-500/30 rounded-lg text-red-400 text-xs font-medium transition-colors"
                                >
                                    {t('cancelAndExitMaintenance')}
                                </button>
                            </div>
                        )}
                    </div>
                </div>
            )}

            {/* Maintenance Banner */}
            {isInMaintenance && !isUpdating && (
                <div className="mb-4 -mt-1 -mx-1">
                    <div className="bg-yellow-500/10 border border-yellow-500/30 rounded-lg p-3">
                        <div className="flex items-center justify-between mb-2">
                            <div className="flex items-center gap-2">
                                <Icons.Wrench />
                                <span className="text-yellow-400 font-semibold text-sm">{t('maintenanceMode')}</span>
                            </div>
                            <span className={`text-xs px-2 py-0.5 rounded ${maintenanceTask?.status === 'completed' ? 'bg-green-500/20 text-green-400' :
                                maintenanceTask?.status === 'completed_with_errors' ? 'bg-orange-500/20 text-orange-400' :
                                    maintenanceTask?.status === 'evacuating' ? 'bg-blue-500/20 text-blue-400' :
                                        maintenanceTask?.status === 'failed' ? 'bg-red-500/20 text-red-400' :
                                            'bg-yellow-500/20 text-yellow-400'
                                }`}>
                                {maintenanceTask?.status === 'completed' ? t('ready') :
                                    maintenanceTask?.status === 'completed_with_errors' ? t('completedWithErrors') :
                                        maintenanceTask?.status === 'evacuating' ? t('evacuating') :
                                            maintenanceTask?.status === 'failed' ? t('failed') :
                                                t('starting')}
                            </span>
                        </div>

                        {maintenanceTask && maintenanceTask.status === 'evacuating' && (
                            <>
                                <div className="mb-2">
                                    <div className="flex justify-between text-xs text-gray-400 mb-1">
                                        <span>{t('progress')}</span>
                                        <span>{maintenanceTask.migrated_vms} / {maintenanceTask.total_vms} VMs</span>
                                    </div>
                                    <div className="h-2 bg-proxmox-dark rounded-full overflow-hidden">
                                        <div
                                            className="h-full bg-gradient-to-r from-yellow-500 to-yellow-400 transition-all duration-500"
                                            style={{ width: `${maintenanceTask.progress_percent}%` }}
                                        />
                                    </div>
                                </div>
                                {maintenanceTask.current_vm && (
                                    <div className="text-xs text-gray-400">
                                        {t('migrating')}: <span className="text-white font-mono">{maintenanceTask.current_vm.name}</span>
                                    </div>
                                )}
                            </>
                        )}

                        {/* Completed with errors - some VMs could not migrate (e.g. local storage) */}
                        {maintenanceTask?.status === 'completed_with_errors' && !metrics.maintenance_acknowledged && (
                            <div className="space-y-3 mt-2">
                                {/* Warning banner about failed migrations */}
                                <div className="p-3 bg-orange-500/10 border border-orange-500/30 rounded-lg">
                                    <div className="flex items-start gap-2 text-orange-400 text-xs">
                                        <Icons.AlertTriangle className="w-4 h-4 mt-0.5 flex-shrink-0" />
                                        <div>
                                            <p className="font-medium">{t('migrationIncomplete')}</p>
                                            <p className="text-orange-300/80 mt-1">
                                                {t('someVmsOnLocalStorage2')}
                                            </p>
                                        </div>
                                    </div>
                                </div>

                                {/* Show which VMs failed */}
                                {maintenanceTask?.failed_vms?.length > 0 && (
                                    <div className="p-2 bg-proxmox-dark rounded-lg">
                                        <p className="text-xs text-gray-400 mb-1">{t('failedToMigrate')}:</p>
                                        <div className="flex flex-wrap gap-1">
                                            {maintenanceTask.failed_vms.slice(0, 5).map((vm, idx) => (
                                                <span key={idx} className="px-2 py-0.5 bg-red-500/20 text-red-400 text-xs rounded font-mono">
                                                    {vm.name || vm.vmid || `VM ${idx + 1}`}
                                                </span>
                                            ))}
                                            {maintenanceTask.failed_vms.length > 5 && (
                                                <span className="px-2 py-0.5 bg-gray-500/20 text-gray-400 text-xs rounded">
                                                    +{maintenanceTask.failed_vms.length - 5} {t('more')}
                                                </span>
                                            )}
                                        </div>
                                    </div>
                                )}

                                {/* Proceed or Exit buttons */}
                                <div className="flex gap-2">
                                    <button
                                        onClick={async () => {
                                            if (confirm(t('forceMaintenanceWarning2'))) {
                                                // Acknowledge the warning - unlock full menu
                                                try {
                                                    await fetch(`${API_URL}/clusters/${clusterId}/nodes/${name}/maintenance/acknowledge`, {
                                                        method: 'POST',
                                                        credentials: 'include',
                                                        headers: { 'Content-Type': 'application/json' }
                                                    });
                                                } catch (e) { console.error(e); }
                                            }
                                        }}
                                        className="flex-1 flex items-center justify-center gap-2 px-3 py-1.5 bg-orange-500/20 hover:bg-orange-500/30 border border-orange-500/30 rounded-lg text-orange-400 text-xs font-medium transition-colors"
                                    >
                                        <Icons.AlertTriangle />
                                        {t('proceedAnyway')}
                                    </button>
                                    <button
                                        onClick={() => onMaintenanceToggle(name, false)}
                                        className="flex-1 px-3 py-1.5 bg-gray-500/20 hover:bg-gray-500/30 border border-gray-500/30 rounded-lg text-gray-400 text-xs font-medium transition-colors"
                                    >
                                        {t('exitMaintenance')}
                                    </button>
                                </div>
                            </div>
                        )}

                        {/* After acknowledging completed_with_errors OR normal completed - show full menu */}
                        {(maintenanceTask?.status === 'completed' || (maintenanceTask?.status === 'completed_with_errors' && metrics.maintenance_acknowledged)) && (
                            <div className="space-y-2 mt-2">
                                {/* Show warning reminder if there were errors */}
                                {maintenanceTask?.status === 'completed_with_errors' && maintenanceTask?.failed_vms?.length > 0 && (
                                    <div className="p-2 bg-orange-500/10 border border-orange-500/20 rounded-lg text-xs text-orange-400 flex items-center gap-2">
                                        <Icons.AlertTriangle className="w-3 h-3" />
                                        {maintenanceTask.failed_vms.length} {t('vmsWillBeStopped')}
                                    </div>
                                )}
                                <div className="flex gap-2">
                                    <button
                                        onClick={() => setShowUpdateConfirm(true)}
                                        className="flex-1 flex items-center justify-center gap-2 px-3 py-1.5 bg-blue-500/20 hover:bg-blue-500/30 border border-blue-500/30 rounded-lg text-blue-400 text-xs font-medium transition-colors"
                                    >
                                        <Icons.Download />
                                        {t('updateAndReboot')}
                                    </button>
                                    <button
                                        onClick={() => onMaintenanceToggle(name, false)}
                                        className="flex-1 px-3 py-1.5 bg-green-500/20 hover:bg-green-500/30 border border-green-500/30 rounded-lg text-green-400 text-xs font-medium transition-colors"
                                    >
                                        {t('exitMaintenance')}
                                    </button>
                                </div>
                                <div className="flex gap-2">
                                    <button
                                        onClick={() => setShowRebootConfirm(true)}
                                        disabled={actionLoading}
                                        className="flex-1 flex items-center justify-center gap-2 px-3 py-1.5 bg-orange-500/20 hover:bg-orange-500/30 border border-orange-500/30 rounded-lg text-orange-400 text-xs font-medium transition-colors disabled:opacity-50"
                                    >
                                        <Icons.RefreshCw />
                                        {t('rebootNode')}
                                    </button>
                                    <button
                                        onClick={() => setShowShutdownConfirm(true)}
                                        disabled={actionLoading}
                                        className="flex-1 flex items-center justify-center gap-2 px-3 py-1.5 bg-red-500/20 hover:bg-red-500/30 border border-red-500/30 rounded-lg text-red-400 text-xs font-medium transition-colors disabled:opacity-50"
                                    >
                                        <Icons.Power />
                                        {t('shutdownNode')}
                                    </button>
                                </div>

                                {/* Remove / Move Node - Only available after maintenance */}
                                <div className="mt-3 pt-3 border-t border-proxmox-border/50 flex gap-2">
                                    <button
                                        onClick={() => onMoveNode && onMoveNode(name)}
                                        className="flex-1 flex items-center justify-center gap-1.5 px-3 py-1.5 bg-blue-500/10 hover:bg-blue-500/20 border border-blue-500/20 rounded-lg text-blue-400 text-xs font-medium transition-colors"
                                    >
                                        <Icons.ArrowRight className="w-3 h-3" />
                                        {t('moveNodeToCluster2')}
                                    </button>
                                    <button
                                        onClick={() => onRemoveNode && onRemoveNode(name)}
                                        className="flex-1 flex items-center justify-center gap-1.5 px-3 py-1.5 bg-red-500/10 hover:bg-red-500/20 border border-red-500/20 rounded-lg text-red-400 text-xs font-medium transition-colors"
                                    >
                                        <Icons.Trash className="w-3 h-3" />
                                        {t('removeNodeFromCluster2')}
                                    </button>
                                </div>
                            </div>
                        )}

                        {maintenanceTask?.failed_vms?.length > 0 && !['completed', 'completed_with_errors'].includes(maintenanceTask?.status) && (
                            <div className="mt-2 text-xs text-red-400">
                                ⚠️ {maintenanceTask.failed_vms.length} {t('vmsCouldNotMigrate')}
                            </div>
                        )}
                    </div>
                </div>
            )}

            <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-3">
                    <div className={`p-2 rounded-lg ${isUpdating ? 'bg-blue-500/10' :
                        isInMaintenance ? 'bg-yellow-500/10' : 'bg-proxmox-orange/10'
                        }`}>
                        {isUpdating ? <Icons.RotateCw className="w-4 h-4 animate-spin" /> : isInMaintenance ? <Icons.Wrench /> : <Icons.Server />}
                    </div>
                    <div>
                        <h3 className="font-semibold text-white">{name}</h3>
                        <div className="flex items-center gap-2 mt-0.5">
                            <span className={`w-2 h-2 rounded-full ${isUpdating ? 'bg-blue-500 animate-pulse' :
                                isInMaintenance ? 'bg-yellow-500' :
                                    metrics.status === 'online' ? 'bg-green-500 status-online' : 'bg-gray-500'
                                }`} />
                            <span className="text-xs text-gray-400">
                                {isUpdating ? t('updating') : isInMaintenance ? t('maintenance') : metrics.status}
                            </span>
                        </div>
                    </div>
                </div>
                <div className="flex items-center gap-2">
                    {!isInMaintenance && !isUpdating && (
                        <button
                            onClick={() => setShowMaintenanceConfirm(true)}
                            className="p-2 rounded-lg bg-proxmox-dark hover:bg-yellow-500/20 text-gray-400 hover:text-yellow-400 transition-all"
                            title={t('enterMaintenance')}
                        >
                            <Icons.Wrench />
                        </button>
                    )}
                    <button
                        onClick={() => onOpenNodeConfig && onOpenNodeConfig(name)}
                        className="p-2 rounded-lg bg-proxmox-dark hover:bg-proxmox-orange/20 text-gray-400 hover:text-proxmox-orange transition-all"
                        title={t('nodeConfiguration')}
                    >
                        <Icons.Cog />
                    </button>
                    <div className="text-right">
                        <div className="text-xs text-gray-500">Score</div>
                        <div className={`font-mono font-bold text-lg ${metrics.score < 100 ? 'text-green-400' : metrics.score < 150 ? 'text-yellow-400' : 'text-red-400'
                            }`}>
                            {metrics.score.toFixed(0)}
                        </div>
                    </div>
                </div>
            </div>

            <div className="grid grid-cols-2 gap-4 mb-4">
                <Gauge value={metrics.cpu_percent} label="CPU" />
                <Gauge value={metrics.mem_percent} label="RAM" />
            </div>

            <div className="space-y-3 pt-3 border-t border-proxmox-border">
                <div className="flex items-center justify-between">
                    <span className="text-xs text-gray-500 flex items-center gap-2">
                        <Icons.Cpu /> {t('cpuHistory')}
                    </span>
                    <Sparkline data={history.cpu} width={80} height={24} />
                </div>
                <div className="flex items-center justify-between">
                    <span className="text-xs text-gray-500 flex items-center gap-2">
                        <Icons.Memory /> {t('ramHistory')}
                    </span>
                    <Sparkline data={history.mem} width={80} height={24} />
                </div>
                <div className="flex items-center justify-between text-xs">
                    <span className="text-gray-500">{t('ramUsage')}</span>
                    <span className="text-gray-300 font-mono">
                        {formatBytes(metrics.mem_used)} / {formatBytes(metrics.mem_total)}
                    </span>
                </div>
                {metrics.ksm && metrics.ksm.shared > 0 && (
                    <div className="flex items-center justify-between text-xs">
                        <span className="text-gray-500">{t('ksmSharing')}</span>
                        <span className="text-purple-400 font-mono">{formatBytes(metrics.ksm.shared)}</span>
                    </div>
                )}

                {/* Expandable Details */}
                <button
                    onClick={() => setExpanded(!expanded)}
                    className="w-full flex items-center justify-center gap-1 text-xs text-gray-500 hover:text-gray-300 transition-colors pt-2"
                >
                    {expanded ? t('showLess') : t('showMore')}
                    <Icons.ChevronDown className={`w-3 h-3 transition-transform ${expanded ? 'rotate-180' : ''}`} />
                </button>

                {expanded && (
                    <div className="space-y-3 pt-2 border-t border-gray-700/50 animate-fade-in">
                        {/* Disk Usage */}
                        {metrics.disk_percent != null && <><div className="flex items-center justify-between text-xs">
                            <span className="text-gray-500 flex items-center gap-2">
                                <Icons.HardDrive /> {t('disk')}
                            </span>
                            <div className="flex items-center gap-2">
                                <div className="w-16 h-1.5 bg-proxmox-dark rounded-full overflow-hidden">
                                    <div
                                        className={`h-full rounded-full ${metrics.disk_percent > 90 ? 'bg-red-500' :
                                            metrics.disk_percent > 75 ? 'bg-yellow-500' : 'bg-green-500'
                                            }`}
                                        style={{ width: `${metrics.disk_percent || 0}%` }}
                                    />
                                </div>
                                <span className="text-gray-300 font-mono w-12 text-right">
                                    {(metrics.disk_percent || 0).toFixed(1)}%
                                </span>
                            </div>
                        </div>
                            <div className="flex items-center justify-between text-xs">
                                <span className="text-gray-500">{t('diskUsage')}</span>
                                <span className="text-gray-300 font-mono">
                                    {formatBytes(metrics.disk_used || 0)} / {formatBytes(metrics.disk_total || 0)}
                                </span>
                            </div></>}

                        {/* Network */}
                        <div className="flex items-center justify-between text-xs">
                            <span className="text-gray-500 flex items-center gap-2">
                                <Icons.Network /> Network In
                            </span>
                            <div className="flex items-center gap-2">
                                <Sparkline data={history.netin} width={50} height={16} color="#22c55e" />
                                <span className="text-green-400 font-mono w-16 text-right">
                                    {history.netin[history.netin.length - 1]?.toFixed(1) || '0.0'} MB/s
                                </span>
                            </div>
                        </div>
                        <div className="flex items-center justify-between text-xs">
                            <span className="text-gray-500 flex items-center gap-2">
                                <Icons.Network /> Network Out
                            </span>
                            <div className="flex items-center gap-2">
                                <Sparkline data={history.netout} width={50} height={16} color="#f97316" />
                                <span className="text-orange-400 font-mono w-16 text-right">
                                    {history.netout[history.netout.length - 1]?.toFixed(1) || '0.0'} MB/s
                                </span>
                            </div>
                        </div>

                        {/* Load Average */}
                        {metrics.loadavg && (
                            <div className="flex items-center justify-between text-xs">
                                <span className="text-gray-500 flex items-center gap-2">
                                    <Icons.Activity /> Load Avg
                                </span>
                                <span className="text-gray-300 font-mono">
                                    {Array.isArray(metrics.loadavg) ?
                                        metrics.loadavg.map(l => typeof l === 'number' ? l.toFixed(2) : l).join(' / ') :
                                        typeof metrics.loadavg === 'number' ? metrics.loadavg.toFixed(2) : '-'
                                    }
                                </span>
                            </div>
                        )}

                        {/* CPU Info */}
                        {metrics.cpuinfo && (
                            <div className="flex items-center justify-between text-xs">
                                <span className="text-gray-500">{t('cores')}</span>
                                <span className="text-gray-300">
                                    {metrics.cpuinfo.cores || metrics.cpuinfo.cpus || '-'} × {metrics.cpuinfo.sockets || 1} Socket
                                </span>
                            </div>
                        )}

                        {/* Kernel Version */}
                        {metrics.kversion && (
                            <div className="flex items-center justify-between text-xs">
                                <span className="text-gray-500">Kernel</span>
                                <span className="text-gray-400 font-mono text-[10px] truncate max-w-32">
                                    {metrics.kversion.split(' ')[0] || metrics.kversion}
                                </span>
                            </div>
                        )}

                        {/* Hypervisor Version */}
                        {metrics.pveversion && (
                            <div className="flex items-center justify-between text-xs">
                                <span className="text-gray-500">PVE</span>
                                <span className="text-gray-400 font-mono text-[10px]">
                                    {metrics.pveversion}
                                </span>
                            </div>
                        )}
                    </div>
                )}

                {metrics.uptime > 0 && (
                    <div className="flex items-center justify-between text-xs">
                        <span className="text-gray-500 flex items-center gap-1">
                            <Icons.Clock /> {t('uptime')}
                        </span>
                        <span className="text-gray-300 font-mono">{formatUptime(metrics.uptime)}</span>
                    </div>
                )}
            </div>

            {/* Maintenance Confirmation Modal */}
            {showMaintenanceConfirm && (
                <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/60" onClick={() => setShowMaintenanceConfirm(false)}>
                    <div
                        className={isCorporate ? 'w-full max-w-md overflow-hidden corp-settings-card' : "w-full max-w-md bg-proxmox-card border border-proxmox-border rounded-2xl shadow-2xl overflow-hidden"}
                        onClick={e => e.stopPropagation()}
                    >
                        <div className={isCorporate ? 'corp-card-header' : "p-6 border-b border-proxmox-border"}>
                            <div className="flex items-center gap-3">
                                <div className="p-3 bg-yellow-500/10 rounded-xl">
                                    <Icons.Wrench />
                                </div>
                                <div>
                                    <h2 className="text-lg font-bold text-white">{t('maintenanceModeTitle')}</h2>
                                    <p className="text-sm text-gray-400">{name}</p>
                                </div>
                            </div>
                        </div>
                        <div className="p-6">
                            <div className="bg-yellow-500/10 border border-yellow-500/30 rounded-lg p-4 mb-4">
                                <p className="text-sm text-yellow-200">
                                    <strong>{t('warning')}:</strong> {t('maintenanceWarning').replace('Warning: ', '')}
                                </p>
                            </div>
                            <p className="text-sm text-gray-400 mb-6">
                                {t('maintenanceDesc')}
                            </p>
                            <div className="flex gap-3">
                                <button
                                    onClick={() => setShowMaintenanceConfirm(false)}
                                    className="flex-1 px-4 py-2.5 bg-proxmox-dark border border-proxmox-border rounded-lg text-gray-300 font-medium hover:bg-proxmox-hover transition-colors"
                                >
                                    {t('cancel')}
                                </button>
                                <button
                                    onClick={() => {
                                        setShowMaintenanceConfirm(false);
                                        onMaintenanceToggle(name, true);
                                    }}
                                    className="flex-1 px-4 py-2.5 bg-yellow-500 hover:bg-yellow-600 rounded-lg text-black font-medium transition-colors"
                                >
                                    {t('startMaintenance')}
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            )}

            {/* Update Confirmation Modal */}
            {showUpdateConfirm && (
                <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/60" onClick={() => setShowUpdateConfirm(false)}>
                    <div
                        className={isCorporate ? 'w-full max-w-md overflow-hidden corp-settings-card' : "w-full max-w-md bg-proxmox-card border border-proxmox-border rounded-2xl shadow-2xl overflow-hidden"}
                        onClick={e => e.stopPropagation()}
                    >
                        <div className={isCorporate ? 'corp-card-header' : "p-6 border-b border-proxmox-border"}>
                            <div className="flex items-center gap-3">
                                <div className="p-3 bg-blue-500/10 rounded-xl">
                                    <Icons.Download />
                                </div>
                                <div>
                                    <h2 className="text-lg font-bold text-white">{t('updateNode')}</h2>
                                    <p className="text-sm text-gray-400">{name}</p>
                                </div>
                            </div>
                        </div>
                        <div className="p-6">
                            <div className="bg-blue-500/10 border border-blue-500/30 rounded-lg p-4 mb-4">
                                <p className="text-sm text-blue-200">
                                    {t('updateCommand')}
                                </p>
                            </div>

                            <label className="flex items-center gap-3 mb-6 cursor-pointer">
                                <input
                                    type="checkbox"
                                    checked={updateWithReboot}
                                    onChange={(e) => setUpdateWithReboot(e.target.checked)}
                                    className="w-5 h-5 rounded border-proxmox-border bg-proxmox-dark text-blue-500 focus:ring-blue-500"
                                />
                                <div>
                                    <span className="text-white font-medium">{t('rebootAfterUpdate')}</span>
                                    <p className="text-xs text-gray-500">{t('recommendedForKernel')}</p>
                                </div>
                            </label>

                            <div className="flex gap-3">
                                <button
                                    onClick={() => setShowUpdateConfirm(false)}
                                    className="flex-1 px-4 py-2.5 bg-proxmox-dark border border-proxmox-border rounded-lg text-gray-300 font-medium hover:bg-proxmox-hover transition-colors"
                                >
                                    {t('cancel')}
                                </button>
                                <button
                                    onClick={() => {
                                        setShowUpdateConfirm(false);
                                        onStartUpdate(name, updateWithReboot);
                                    }}
                                    className="flex-1 px-4 py-2.5 bg-blue-500 hover:bg-blue-600 rounded-lg text-white font-medium transition-colors"
                                >
                                    {t('startUpdate')}
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            )}

            {/* Update Log Modal */}
            {showUpdateLog && updateTask && (
                <div className="fixed inset-0 z-50 flex items-center justify-center p-4 modal-backdrop bg-black/60" onClick={() => setShowUpdateLog(false)}>
                    <div
                        className={isCorporate ? 'w-full max-w-2xl overflow-hidden corp-settings-card' : "w-full max-w-2xl bg-proxmox-card border border-proxmox-border rounded-2xl shadow-2xl animate-scale-in overflow-hidden"}
                        onClick={e => e.stopPropagation()}
                    >
                        <div className={isCorporate ? 'corp-card-header flex items-center justify-between' : "p-4 border-b border-proxmox-border flex items-center justify-between"}>
                            <div className="flex items-center gap-3">
                                <Icons.Terminal />
                                <h2 className="font-bold text-white">Update Log - {name}</h2>
                            </div>
                            <button
                                onClick={() => setShowUpdateLog(false)}
                                className="p-2 hover:bg-proxmox-hover rounded-lg transition-colors"
                            >
                                <Icons.X />
                            </button>
                        </div>
                        <div className="p-4 bg-proxmox-darker font-mono text-xs max-h-96 overflow-y-auto">
                            {updateTask.output_lines?.map((line, idx) => (
                                <div key={idx} className="py-0.5 text-gray-300 hover:bg-proxmox-card/50">
                                    <span className="text-gray-600 mr-2">{new Date(line.timestamp).toLocaleTimeString('de-DE')}</span>
                                    {line.text}
                                </div>
                            ))}
                        </div>
                    </div>
                </div>
            )}

            {/* Reboot Confirmation Modal */}
            {showRebootConfirm && (
                <div className="fixed inset-0 z-50 flex items-center justify-center p-4 modal-backdrop bg-black/60" onClick={() => setShowRebootConfirm(false)}>
                    <div
                        className={isCorporate ? 'w-full max-w-md overflow-hidden corp-settings-card' : "w-full max-w-md bg-proxmox-card border border-orange-500/30 rounded-2xl shadow-2xl animate-scale-in overflow-hidden"}
                        onClick={e => e.stopPropagation()}
                    >
                        <div className={isCorporate ? 'corp-card-header' : "p-6 border-b border-orange-500/30 bg-orange-500/10"}>
                            <div className="flex items-center gap-3">
                                <div className="p-3 bg-orange-500/20 rounded-xl">
                                    <Icons.RefreshCw />
                                </div>
                                <div>
                                    <h2 className="text-lg font-bold text-white">{t('rebootNode')}</h2>
                                    <p className="text-sm text-orange-400">{name}</p>
                                </div>
                            </div>
                        </div>
                        <div className="p-6">
                            <div className="bg-orange-500/10 border border-orange-500/30 rounded-lg p-4 mb-4">
                                <p className="text-sm text-orange-200">
                                    {t('rebootNodeWarning')}
                                </p>
                            </div>
                            <div className="flex gap-3">
                                <button
                                    onClick={() => setShowRebootConfirm(false)}
                                    className="flex-1 px-4 py-2.5 bg-proxmox-dark border border-proxmox-border rounded-lg text-gray-300 font-medium hover:bg-proxmox-hover transition-colors"
                                >
                                    {t('cancel')}
                                </button>
                                <button
                                    onClick={async () => {
                                        setActionLoading('reboot');
                                        setShowRebootConfirm(false);
                                        if (onNodeAction) await onNodeAction(name, 'reboot');
                                        setActionLoading(null);
                                    }}
                                    disabled={actionLoading}
                                    className="flex-1 flex items-center justify-center gap-2 px-4 py-2.5 bg-orange-500 hover:bg-orange-600 rounded-lg text-white font-medium transition-colors disabled:opacity-50"
                                >
                                    {actionLoading === 'reboot' ? <Icons.RotateCw className="w-4 h-4 animate-spin" /> : <Icons.RefreshCw />}
                                    {t('rebootNow')}
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            )}

            {/* Shutdown Confirmation Modal */}
            {showShutdownConfirm && (
                <div className="fixed inset-0 z-50 flex items-center justify-center p-4 modal-backdrop bg-black/60" onClick={() => setShowShutdownConfirm(false)}>
                    <div
                        className={isCorporate ? 'w-full max-w-md overflow-hidden corp-settings-card' : "w-full max-w-md bg-proxmox-card border border-red-500/30 rounded-2xl shadow-2xl animate-scale-in overflow-hidden"}
                        onClick={e => e.stopPropagation()}
                    >
                        <div className={isCorporate ? 'corp-card-header' : "p-6 border-b border-red-500/30 bg-red-500/10"}>
                            <div className="flex items-center gap-3">
                                <div className="p-3 bg-red-500/20 rounded-xl">
                                    <Icons.Power />
                                </div>
                                <div>
                                    <h2 className="text-lg font-bold text-white">{t('shutdownNode')}</h2>
                                    <p className="text-sm text-red-400">{name}</p>
                                </div>
                            </div>
                        </div>
                        <div className="p-6">
                            <div className="bg-red-500/10 border border-red-500/30 rounded-lg p-4 mb-4">
                                <p className="text-sm text-red-200">
                                    {t('shutdownNodeWarning')}
                                </p>
                            </div>
                            <div className="flex gap-3">
                                <button
                                    onClick={() => setShowShutdownConfirm(false)}
                                    className="flex-1 px-4 py-2.5 bg-proxmox-dark border border-proxmox-border rounded-lg text-gray-300 font-medium hover:bg-proxmox-hover transition-colors"
                                >
                                    {t('cancel')}
                                </button>
                                <button
                                    onClick={async () => {
                                        setActionLoading('shutdown');
                                        setShowShutdownConfirm(false);
                                        if (onNodeAction) await onNodeAction(name, 'shutdown');
                                        setActionLoading(null);
                                    }}
                                    disabled={actionLoading}
                                    className="flex-1 flex items-center justify-center gap-2 px-4 py-2.5 bg-red-500 hover:bg-red-600 rounded-lg text-white font-medium transition-colors disabled:opacity-50"
                                >
                                    {actionLoading === 'shutdown' ? <Icons.RotateCw className="w-4 h-4 animate-spin" /> : <Icons.Power />}
                                    {t('shutdownNow')}
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
}

// Compact node row for corporate overview
// Added sparkline history + detail cards
function NodeCompactRow({ name, metrics, clusterId, onOpenNodeConfig, onMaintenanceToggle, onStartUpdate, onNodeAction, onRemoveNode, onMoveNode }) {
    const { isCorporate } = useLayout();
    const { t } = useTranslation();
    const { getAuthHeaders } = useAuth();
    const [expanded, setExpanded] = useState(false);
    const [showMaintenanceConfirm, setShowMaintenanceConfirm] = useState(false);
    const [showRebootConfirm, setShowRebootConfirm] = useState(false);
    const [showShutdownConfirm, setShowShutdownConfirm] = useState(false);
    const [showUpdateConfirm, setShowUpdateConfirm] = useState(false);
    const [updateWithReboot, setUpdateWithReboot] = useState(true);
    const [actionLoading, setActionLoading] = useState(null);
    // sparkline history buffer - 20 pts like NodeCard
    const histRef = useRef({ cpu: Array(20).fill(0), mem: Array(20).fill(0) });
    const lastValRef = useRef(null);
    const [, bump] = useState(0);

    useEffect(() => {
        if (metrics && metrics !== lastValRef.current) {
            lastValRef.current = metrics;
            histRef.current = {
                cpu: [...histRef.current.cpu.slice(1), metrics.cpu_percent || 0],
                mem: [...histRef.current.mem.slice(1), metrics.mem_percent || (metrics.memory ? (metrics.memory.used / metrics.memory.total) * 100 : 0)]
            };
            bump(n => n + 1);
        }
    }, [metrics?.cpu_percent, metrics?.mem_percent]);

    const isOffline = !metrics || metrics.status === 'offline';
    const cpuPercent = metrics?.cpu_percent?.toFixed(1) || (metrics?.cpu ? (metrics.cpu * 100).toFixed(1) : '0');
    const ramPercent = metrics?.mem_percent?.toFixed(1) || (metrics?.memory ? ((metrics.memory.used / metrics.memory.total) * 100).toFixed(1) : '0');
    const isInMaintenance = metrics?.maintenance_mode;
    const maintenanceTask = metrics?.maintenance_task;
    const isUpdating = metrics?.is_updating;
    const updateTask = metrics?.update_task;
    const canUpdate = isInMaintenance && maintenanceTask?.status && (['completed', 'completed_with_errors'].includes(maintenanceTask.status) || metrics?.maintenance_acknowledged) && !isUpdating;
    const proxmoxTarget = { ...metrics, kind: 'node', name, node: name };
    const proxmoxUrl = getProxmoxObjectUrl(proxmoxTarget);

    const formatBytes = (bytes) => { if (!bytes) return '0 B'; const k = 1024, s = ['B', 'KB', 'MB', 'GB', 'TB', 'PB'], i = Math.floor(Math.log(bytes) / Math.log(k)); return (bytes / Math.pow(k, i)).toFixed(1) + ' ' + s[i]; };
    const formatUptime = (uptime) => {
        if (!uptime) return '-';
        const days = Math.floor(uptime / 86400);
        const hours = Math.floor((uptime % 86400) / 3600);
        const mins = Math.floor((uptime % 3600) / 60);
        if (days > 0) return `${days}d ${hours}h`;
        if (hours > 0) return `${hours}h ${mins}m`;
        return `${mins}m`;
    };

    // Status colors - Clarity dark theme
    const statusDotStyle = isOffline ? { background: '#f54f47' } : isInMaintenance ? { background: '#efc006' } : isUpdating ? { background: '#49afd9' } : { background: '#60b515' };
    const statusLabel = isOffline ? '' : isInMaintenance ? t('maintenance') : isUpdating ? (updateTask?.phase || t('updating')) : '';

    const nodeStatusCls = isOffline ? 'node-offline' : isInMaintenance ? 'node-maintenance' : 'node-online';
    return (
        <div className={`corp-node-row ${nodeStatusCls}`}>
            {/* Main Row */}
            <div className={`flex items-center gap-3 px-3 py-2 text-[13px] cursor-pointer ${isOffline ? 'opacity-50' : ''}`} onClick={() => !isOffline && setExpanded(!expanded)}>
                {!isOffline && <Icons.ChevronRight className="w-3 h-3 flex-shrink-0 transition-transform" style={{ color: '#728b9a', transform: expanded ? 'rotate(90deg)' : 'none' }} />}
                <span className="w-2 h-2 rounded-full flex-shrink-0" style={statusDotStyle}></span>
                <span className="font-medium w-32 truncate" style={{ color: '#e9ecef' }}>{name}</span>
                {!isOffline ? (
                    <>
                        {statusLabel && <span className={`corp-badge ${isInMaintenance ? 'corp-badge-locked' : 'corp-badge-ha'}`}>{statusLabel}</span>}
                        {isUpdating && updateTask && !isInMaintenance && (
                            <span className="corp-badge" style={{
                                background: updateTask.status === 'failed' ? 'rgba(245,79,71,0.15)' : updateTask.status === 'completed' ? 'rgba(96,181,21,0.15)' : 'rgba(73,175,217,0.15)',
                                color: updateTask.status === 'failed' ? '#f54f47' : updateTask.status === 'completed' ? '#60b515' : '#49afd9',
                                border: `1px solid ${updateTask.status === 'failed' ? 'rgba(245,79,71,0.3)' : updateTask.status === 'completed' ? 'rgba(96,181,21,0.3)' : 'rgba(73,175,217,0.3)'}`
                            }}>
                                {updateTask.status === 'completed' ? '✓ ' : updateTask.status === 'failed' ? '✕ ' : '⟳ '}
                                {updateTask.status === 'failed' ? t('updateFailed') : updateTask.status === 'completed' ? t('updateCompleted') : `${t('updating')}: ${updateTask.phase || '...'}`}
                            </span>
                        )}
                        <span className="w-8" style={{ color: '#728b9a' }}>CPU</span>
                        <div className="w-20 h-1.5 flex-shrink-0 overflow-hidden" style={{ background: 'var(--corp-bar-track)', borderRadius: '1px' }}>
                            <div className="h-full" style={{ width: `${Math.min(cpuPercent, 100)}%`, background: '#49afd9', borderRadius: '1px' }}></div>
                        </div>
                        <span className="w-12 text-right" style={{ color: '#adbbc4' }}>{cpuPercent}%</span>
                        {(() => { const d = histRef.current.cpu; const mx = Math.max(...d, 1); const pts = d.map((v, i) => `${(i / 19) * 40},${12 - ((v / mx) * 12)}`).join(' '); return <svg width="40" height="12" className="corp-sparkline-inline"><polyline fill="none" stroke="#49afd9" strokeWidth="1" points={pts} /><circle cx="40" cy={12 - ((d[19] / mx) * 12)} r="1.5" fill="#49afd9" /></svg>; })()}
                        <span className="w-8 ml-2" style={{ color: '#728b9a' }}>RAM</span>
                        <div className="w-20 h-1.5 flex-shrink-0 overflow-hidden" style={{ background: 'var(--corp-bar-track)', borderRadius: '1px' }}>
                            <div className="h-full" style={{ width: `${Math.min(ramPercent, 100)}%`, background: '#9b59b6', borderRadius: '1px' }}></div>
                        </div>
                        <span className="w-12 text-right" style={{ color: '#adbbc4' }}>{ramPercent}%</span>
                        {(() => { const d = histRef.current.mem; const mx = Math.max(...d, 1); const pts = d.map((v, i) => `${(i / 19) * 40},${12 - ((v / mx) * 12)}`).join(' '); return <svg width="40" height="12" className="corp-sparkline-inline"><polyline fill="none" stroke="#9b59b6" strokeWidth="1" points={pts} /><circle cx="40" cy={12 - ((d[19] / mx) * 12)} r="1.5" fill="#9b59b6" /></svg>; })()}
                        {metrics.score != null && <span className="ml-3 w-16" style={{ color: '#728b9a' }}>{t('score')}: <span style={{ color: '#adbbc4' }}>{Number(metrics.score).toFixed(1)}</span></span>}
                        <span className="ml-3" style={{ color: '#728b9a' }}>{formatUptime(metrics.uptime)}</span>
                        <span className="flex-1"></span>
                        {isInMaintenance && maintenanceTask && maintenanceTask.status === 'running' && (
                            <span className="text-[11px] mr-2" style={{ color: '#efc006' }}>{maintenanceTask.migrated_count || 0}/{maintenanceTask.total_vms || '?'} VMs</span>
                        )}
                        {proxmoxUrl && (
                            <button onClick={(e) => { e.stopPropagation(); openProxmoxObject(proxmoxTarget); }} className="p-0.5 hover:text-white" style={{ color: '#49afd9' }} title={t('openInProxmox')}>
                                <Icons.ExternalLink className="w-3.5 h-3.5" />
                            </button>
                        )}
                        <button onClick={(e) => { e.stopPropagation(); onOpenNodeConfig && onOpenNodeConfig(name); }} className="p-0.5 hover:text-white" style={{ color: '#728b9a' }} title={t('settings')}>
                            <Icons.Settings className="w-3.5 h-3.5" />
                        </button>
                    </>
                ) : (
                    <span className="text-[12px]" style={{ color: '#f54f47' }}>{t('nodeUnreachable')}</span>
                )}
            </div>

            {/* Expanded Detail Panel */}
            {expanded && !isOffline && metrics && (
                <div className="px-3 pb-3 pt-1 ml-5" style={{ borderTop: '1px solid var(--corp-divider)' }}>
                    {/* Update Banner */}
                    {isUpdating && updateTask && (
                        <div className="mb-2 p-2 text-[12px]" style={{
                            background: updateTask.status === 'failed' ? 'rgba(245,79,71,0.08)' : updateTask.status === 'completed' ? 'rgba(96,181,21,0.08)' : 'rgba(73,175,217,0.08)',
                            border: `1px solid ${updateTask.status === 'failed' ? 'rgba(245,79,71,0.2)' : updateTask.status === 'completed' ? 'rgba(96,181,21,0.2)' : 'rgba(73,175,217,0.2)'}`
                        }}>
                            <div className="flex items-center justify-between">
                                <div className="flex items-center gap-2" style={{ color: updateTask.status === 'failed' ? '#f54f47' : updateTask.status === 'completed' ? '#60b515' : '#49afd9' }}>
                                    {updateTask.status === 'completed' ? <Icons.CheckCircle className="w-3 h-3" /> : updateTask.status === 'failed' ? <Icons.XCircle className="w-3 h-3" /> : <Icons.Download className="w-3 h-3" />}
                                    <span className="font-medium">{
                                        updateTask.status === 'failed' ? t('updateFailed') :
                                            updateTask.status === 'completed' ? t('updateCompleted') :
                                                t('updateRunning')
                                    }: {updateTask.phase || '...'}</span>
                                </div>
                                {(updateTask.status === 'completed' || updateTask.status === 'failed') && (
                                    <button onClick={(e) => {
                                        e.stopPropagation();
                                        fetch(`${API_URL}/clusters/${clusterId}/nodes/${name}/update`, { method: 'DELETE', credentials: 'include', headers: getAuthHeaders() }).catch(() => { });
                                    }} className="text-[10px] px-1.5 py-0.5 hover:text-white" style={{ color: '#728b9a' }}>✕</button>
                                )}
                            </div>
                            {updateTask.output && updateTask.output.length > 0 && (
                                <pre className="mt-1 text-[10px] font-mono max-h-16 overflow-y-auto" style={{ color: '#728b9a' }}>{(updateTask.output_lines || updateTask.output).slice(-3).map(l => typeof l === 'object' ? l.text : l).join('\n')}</pre>
                            )}
                            {updateTask.status === 'completed' && updateTask.packages_upgraded && (
                                <div className="mt-1" style={{ color: '#60b515' }}>{t('updateCompleted')} - {updateTask.packages_upgraded} {t('packagesUpdated')}</div>
                            )}
                            {updateTask.status === 'failed' && updateTask.error && (
                                <div className="mt-1" style={{ color: '#f54f47' }}>{updateTask.error}</div>
                            )}
                        </div>
                    )}

                    {/* Maintenance Banner */}
                    {isInMaintenance && maintenanceTask && (
                        <div className="mb-2 p-2 text-[12px]" style={{ background: 'rgba(239, 192, 6, 0.08)', border: '1px solid rgba(239, 192, 6, 0.2)' }}>
                            <div className="flex items-center justify-between">
                                <div className="flex items-center gap-2" style={{ color: '#efc006' }}>
                                    <Icons.Wrench className="w-3 h-3" />
                                    <span className="font-medium">{t('maintenance')}</span>
                                    <span style={{ color: '#728b9a' }}>- {
                                        maintenanceTask.status === 'completed' ? t('ready') :
                                            maintenanceTask.status === 'completed_with_errors' ? t('completedWithErrors') :
                                                maintenanceTask.status === 'evacuating' ? t('evacuating') :
                                                    maintenanceTask.status === 'failed' ? t('failed') :
                                                        maintenanceTask.status === 'running' ? t('running') :
                                                            maintenanceTask.status
                                    }</span>
                                </div>
                                {(maintenanceTask.status === 'running' || maintenanceTask.status === 'evacuating') && maintenanceTask.total_vms > 0 && (
                                    <div className="flex items-center gap-2">
                                        <div className="w-16 h-1 overflow-hidden" style={{ background: 'var(--corp-bar-track)', borderRadius: '1px' }}>
                                            <div className="h-full" style={{ width: `${(((maintenanceTask.migrated_count || maintenanceTask.migrated_vms || 0)) / maintenanceTask.total_vms) * 100}%`, background: '#efc006', borderRadius: '1px' }}></div>
                                        </div>
                                        <span style={{ color: '#efc006' }}>{maintenanceTask.migrated_count || maintenanceTask.migrated_vms || 0}/{maintenanceTask.total_vms}</span>
                                    </div>
                                )}
                            </div>
                            {maintenanceTask.failed_vms && maintenanceTask.failed_vms.length > 0 && (
                                <div className="mt-1" style={{ color: '#f54f47' }}>
                                    {t('failedToMigrate')}: {maintenanceTask.failed_vms.map(v => v.name || v.vmid).join(', ')}
                                </div>
                            )}
                            {/* Force/exit buttons - only when NOT yet acknowledged */}
                            {!metrics.maintenance_acknowledged && (maintenanceTask.status === 'completed_with_errors' || (maintenanceTask.failed_vms && maintenanceTask.failed_vms.length > 0)) && (
                                <div className="mt-1.5 flex items-center gap-2">
                                    <button onClick={(e) => {
                                        e.stopPropagation();
                                        if (confirm(t('forceMaintenanceWarning3'))) {
                                            fetch(`${API_URL}/clusters/${clusterId}/nodes/${name}/maintenance/acknowledge`, { method: 'POST', credentials: 'include', headers: { ...getAuthHeaders(), 'Content-Type': 'application/json' } }).catch(() => { });
                                        }
                                    }} className="px-2 py-0.5 text-[11px] font-medium" style={{ background: 'rgba(239,192,6,0.15)', color: '#efc006', border: '1px solid rgba(239,192,6,0.3)' }}>
                                        <Icons.AlertTriangle className="w-2.5 h-2.5 inline mr-1" />{t('proceedAnyway')}
                                    </button>
                                    <button onClick={(e) => { e.stopPropagation(); onMaintenanceToggle && onMaintenanceToggle(name, false); }}
                                        className="px-2 py-0.5 text-[11px] font-medium" style={{ background: 'rgba(96,181,21,0.1)', color: '#60b515', border: '1px solid rgba(96,181,21,0.3)' }}>
                                        {t('exitMaintenance')}
                                    </button>
                                </div>
                            )}
                            {/* after acknowledge: show warning + unlocked actions like modern */}
                            {metrics.maintenance_acknowledged && maintenanceTask.failed_vms && maintenanceTask.failed_vms.length > 0 && (
                                <div className="mt-1.5 text-[11px]" style={{ color: '#efc006' }}>
                                    <Icons.AlertTriangle className="w-2.5 h-2.5 inline mr-1" />
                                    {maintenanceTask.failed_vms.length} {t('vmsWillBeStopped')}
                                </div>
                            )}
                        </div>
                    )}

                    {/* Property cards instead of flat text grid */}
                    <div className="corp-node-detail-grid">
                        <div className="corp-node-detail-card">
                            <div className="corp-node-detail-label">{t('disk')}</div>
                            <div className="corp-node-detail-value">{metrics.disk_percent?.toFixed(1) || '-'}%</div>
                            <div className="corp-node-detail-sub">{metrics.disk_total ? `${formatBytes(metrics.disk_used || 0)} / ${formatBytes(metrics.disk_total)}` : '-'}</div>
                        </div>
                        <div className="corp-node-detail-card">
                            <div className="corp-node-detail-label">Load</div>
                            <div className="corp-node-detail-value">{
                                Array.isArray(metrics.loadavg) ? metrics.loadavg.map(l => typeof l === 'number' ? l.toFixed(2) : l).join(' / ') :
                                    typeof metrics.loadavg === 'number' ? metrics.loadavg.toFixed(2) : (metrics.loadavg || '-')
                            }</div>
                            <div className="corp-node-detail-sub">{t('cpuCores')}: {metrics.cpus || metrics.cpu_count || (metrics.cpuinfo ? `${metrics.cpuinfo.cores || metrics.cpuinfo.cpus || '-'} × ${metrics.cpuinfo.sockets || 1}` : '-')}</div>
                        </div>
                        <div className="corp-node-detail-card">
                            <div className="corp-node-detail-label">{t('uptime')}</div>
                            <div className="corp-node-detail-value">{formatUptime(metrics.uptime)}</div>
                            <div className="corp-node-detail-sub">{(metrics.kernel_version || metrics.kversion) ? (metrics.kernel_version || metrics.kversion.split(' ')[0]) : ''}</div>
                        </div>
                        <div className="corp-node-detail-card">
                            <div className="corp-node-detail-label">PVE</div>
                            <div className="corp-node-detail-value" style={{ fontSize: 13 }}>{metrics.pve_version || metrics.pveversion || '-'}</div>
                            <div className="corp-node-detail-sub">{metrics.kernel_version || (metrics.kversion ? metrics.kversion.split(' ')[0] : '')}</div>
                        </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="corp-toolbar flex flex-wrap items-center gap-1 pt-1" style={{ borderTop: '1px solid var(--corp-divider)' }}>
                        {proxmoxUrl && (
                            <button onClick={() => openProxmoxObject(proxmoxTarget)}>
                                <Icons.ExternalLink className="w-3 h-3" style={{ color: '#49afd9' }} /> {t('openInProxmox')}
                            </button>
                        )}
                        {!isInMaintenance ? (
                            <button onClick={() => setShowMaintenanceConfirm(true)}>
                                <Icons.Wrench className="w-3 h-3" style={{ color: '#efc006' }} /> {t('enterMaintenance') || t('maintenance')}
                            </button>
                        ) : (
                            <>
                                <button onClick={() => onMaintenanceToggle && onMaintenanceToggle(name, false)}>
                                    <Icons.X className="w-3 h-3" style={{ color: '#60b515' }} /> {t('exitMaintenance')}
                                </button>
                                {canUpdate && (
                                    <button onClick={() => setShowUpdateConfirm(true)}>
                                        <Icons.Download className="w-3 h-3" style={{ color: '#49afd9' }} /> {t('startUpdate')}
                                    </button>
                                )}
                                {maintenanceTask?.status && (['completed', 'completed_with_errors'].includes(maintenanceTask.status) || metrics?.maintenance_acknowledged) && (
                                    <>
                                        {onRemoveNode && <button onClick={() => onRemoveNode(name)}><Icons.Trash className="w-3 h-3" style={{ color: '#f54f47' }} /> {t('removeNodeFromCluster')}</button>}
                                        {onMoveNode && <button onClick={() => onMoveNode(name)}><Icons.ArrowRight className="w-3 h-3" /> {t('moveNodeToCluster')}</button>}
                                    </>
                                )}
                            </>
                        )}
                        <button onClick={() => setShowRebootConfirm(true)}>
                            <Icons.RotateCw className="w-3 h-3" style={{ color: '#efc006' }} /> {t('reboot')}
                        </button>
                        <button onClick={() => setShowShutdownConfirm(true)}>
                            <Icons.Power className="w-3 h-3" style={{ color: '#f54f47' }} /> {t('shutdown')}
                        </button>
                    </div>
                </div>
            )}

            {/* Confirmation Modals */}
            {showMaintenanceConfirm && (
                <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-black/60">
                    <div className={isCorporate ? 'w-full max-w-sm corp-settings-card' : "w-full max-w-sm bg-proxmox-card border border-proxmox-border p-5"}>
                        <h3 className={isCorporate ? 'corp-label' : "text-[14px] font-semibold mb-2"} style={{ color: '#e9ecef' }}>{t('enterMaintenance')}</h3>
                        <p className="text-[13px] mb-4" style={{ color: '#adbbc4' }}>{t('maintenanceWarning') || `All VMs on ${name} will be migrated to other nodes.`}</p>
                        <div className="flex justify-end gap-2">
                            <button onClick={() => setShowMaintenanceConfirm(false)} className="px-3 py-1.5 text-[13px] border border-proxmox-border hover:text-white" style={{ color: '#adbbc4' }}>{t('cancel')}</button>
                            <button onClick={() => { onMaintenanceToggle && onMaintenanceToggle(name, true); setShowMaintenanceConfirm(false); }} className="px-3 py-1.5 text-[13px] text-white" style={{ background: '#efc006', border: '1px solid #d4a905' }}>{t('confirm')}</button>
                        </div>
                    </div>
                </div>
            )}
            {showUpdateConfirm && (
                <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-black/60">
                    <div className={isCorporate ? 'w-full max-w-sm corp-settings-card' : "w-full max-w-sm bg-proxmox-card border border-proxmox-border p-5"}>
                        <h3 className={isCorporate ? 'corp-label' : "text-[14px] font-semibold mb-2"} style={{ color: '#e9ecef' }}>{t('startUpdate')}</h3>
                        <label className="flex items-center gap-2 text-[13px] mb-4" style={{ color: '#adbbc4' }}>
                            <input type="checkbox" checked={updateWithReboot} onChange={(e) => setUpdateWithReboot(e.target.checked)} />
                            {t('rebootAfterUpdate')}
                        </label>
                        <div className="flex justify-end gap-2">
                            <button onClick={() => setShowUpdateConfirm(false)} className="px-3 py-1.5 text-[13px] border border-proxmox-border hover:text-white" style={{ color: '#adbbc4' }}>{t('cancel')}</button>
                            <button onClick={() => { onStartUpdate && onStartUpdate(name, updateWithReboot); setShowUpdateConfirm(false); }} className="px-3 py-1.5 text-[13px] text-white" style={{ background: '#49afd9', border: '1px solid #3d9bc2' }}>{t('startUpdate2')}</button>
                        </div>
                    </div>
                </div>
            )}
            {showRebootConfirm && (
                <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-black/60">
                    <div className={isCorporate ? 'w-full max-w-sm corp-settings-card' : "w-full max-w-sm bg-proxmox-card border border-proxmox-border p-5"}>
                        <h3 className={isCorporate ? 'corp-label' : "text-[14px] font-semibold mb-2"} style={{ color: '#e9ecef' }}>{t('rebootNode') || `Reboot ${name}`}</h3>
                        <p className="text-[13px] mb-4" style={{ color: '#adbbc4' }}>{t('rebootWarning')}</p>
                        <div className="flex justify-end gap-2">
                            <button onClick={() => setShowRebootConfirm(false)} className="px-3 py-1.5 text-[13px] border border-proxmox-border hover:text-white" style={{ color: '#adbbc4' }}>{t('cancel')}</button>
                            <button onClick={() => { onNodeAction && onNodeAction(name, 'reboot'); setShowRebootConfirm(false); }} className="px-3 py-1.5 text-[13px] text-white" style={{ background: '#efc006', border: '1px solid #d4a905' }}>{t('reboot')}</button>
                        </div>
                    </div>
                </div>
            )}
            {showShutdownConfirm && (
                <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-black/60">
                    <div className={isCorporate ? 'w-full max-w-sm corp-settings-card' : "w-full max-w-sm bg-proxmox-card border border-proxmox-border p-5"}>
                        <h3 className={isCorporate ? 'corp-label' : "text-[14px] font-semibold mb-2"} style={{ color: '#e9ecef' }}>{t('shutdownNode') || `Shutdown ${name}`}</h3>
                        <p className="text-[13px] mb-4" style={{ color: '#adbbc4' }}>{t('shutdownWarning')}</p>
                        <div className="flex justify-end gap-2">
                            <button onClick={() => setShowShutdownConfirm(false)} className="px-3 py-1.5 text-[13px] border border-proxmox-border hover:text-white" style={{ color: '#adbbc4' }}>{t('cancel')}</button>
                            <button onClick={() => { onNodeAction && onNodeAction(name, 'shutdown'); setShowShutdownConfirm(false); }} className="px-3 py-1.5 text-[13px] text-white" style={{ background: '#f54f47', border: '1px solid #d4433d' }}>{t('shutdown')}</button>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
}

// Resource Table Component
// The main VM/CT list - supports cards, table, and detail view
// Added bulk select for mass operations (migration, etc.)
// This component does a lot... might need to split it up eventually
// Filtering + sorting uses useMemo below (lines 1320+)
function ResourceTable({ resources, clusterId, clusters, sourceCluster, onVmAction, onBulkAction, onOpenConsole, onOpenConfig, onMigrate, onBulkMigrate, onDelete, onClone, onForceStop, onCrossClusterMigrate, nodes, onOpenTags, highlightedVm, addToast, pendingVmAction, onPendingActionConsumed, onVmNavigate, backupStatus }) {
    const { t } = useTranslation();
    const { getAuthHeaders, user } = useAuth();
    const { isCorporate } = useLayout(); // Corporate defaults to table view
    // Per-VM sparkline history for table view
    const vmHistRef = useRef({});
    useEffect(() => {
        if (!resources || !isCorporate) return;
        const buf = vmHistRef.current;
        resources.forEach(r => {
            if (r.status !== 'running') return;
            const id = r.vmid;
            if (!buf[id]) buf[id] = { cpu: Array(15).fill(0), mem: Array(15).fill(0) };
            buf[id].cpu = [...buf[id].cpu.slice(1), r.cpu_percent || 0];
            buf[id].mem = [...buf[id].mem.slice(1), r.mem_percent || 0];
        });
    }, [resources]);
    const [search, setSearch] = useState('');
    // #T018: remember table filter set per user.
    const _filtersKey = `ProxmoxVEx-vmfilters-${user?.username || '_'}`;
    const _savedFilters = (() => { try { return JSON.parse(localStorage.getItem(_filtersKey) || '{}'); } catch (e) { return {}; } })();
    const [filter, setFilter] = useState(_savedFilters.filter || 'all');
    const [nodeFilter, setNodeFilter] = useState(_savedFilters.nodeFilter || 'all');
    const [tagFilter, setTagFilter] = useState(_savedFilters.tagFilter || 'all');
    const [itemsPerPage, setItemsPerPage] = useState(_savedFilters.itemsPerPage || 50);
    // #431: remember the table sort per user (localStorage, keyed by
    // username so a shared browser keeps each operator's choice).
    const _sortKey = `ProxmoxVEx-vmsort-${user?.username || '_'}`;
    const _savedSort = (() => { try { return JSON.parse(localStorage.getItem(_sortKey) || '{}'); } catch (e) { return {}; } })();
    const [sortBy, setSortBy] = useState(_savedSort.by || 'vmid');
    const [sortDir, setSortDir] = useState(_savedSort.dir || 'asc');

    // #T018: persist the VM filter set whenever it changes
    useEffect(() => {
        try {
            localStorage.setItem(_filtersKey, JSON.stringify({
                filter,
                nodeFilter,
                tagFilter,
                itemsPerPage
            }));
        } catch (e) { }
    }, [filter, nodeFilter, tagFilter, itemsPerPage, _filtersKey]);

    const [viewMode, setViewMode] = useState(isCorporate ? 'table' : 'cards'); // Corporate defaults to table view
    const [actionLoading, setActionLoading] = useState({});
    const [selectedVms, setSelectedVms] = useState([]);
    const [bulkAction, setBulkAction] = useState('start');
    const [bulkWorking, setBulkWorking] = useState(false);
    const [showMigrateModal, setShowMigrateModal] = useState(null);
    const [showBulkMigrate, setShowBulkMigrate] = useState(false);
    const [showDeleteConfirm, setShowDeleteConfirm] = useState(null);
    const [showCloneModal, setShowCloneModal] = useState(null);
    const [selectedDetailVm, setSelectedDetailVm] = useState(null); // For detail view

    // Consume pending action from context menu
    useEffect(() => {
        if (!pendingVmAction) return;
        const { vm, action } = pendingVmAction;
        if (action === 'migrate') setShowMigrateModal(vm);
        else if (action === 'clone') setShowCloneModal(vm);
        else if (action === 'delete') setShowDeleteConfirm(vm);
        else if (action === 'crossCluster') setShowCrossClusterMigrate(vm);
        onPendingActionConsumed?.();
    }, [pendingVmAction]);
    const highlightedRowRef = useRef(null);

    // Pagination states
    // Moved up 25.01.2026 - must be declared before useEffect that uses them
    // This was breaking pre-compiled builds (GitHub Issue #4)
    // Browser-Babel was more forgiving but compiled JS enforces strict declaration order
    const [currentPage, setCurrentPage] = useState(1);
    // itemsPerPage is initialized earlier from persisted filters

    // Scroll to highlighted VM from global search
    useEffect(() => {
        if (highlightedVm) {
            // clear filters first
            setSearch('');
            setFilter('all');

            // jump to correct page
            const vmIndex = resources.findIndex(r => r.vmid === highlightedVm.vmid);
            if (vmIndex !== -1) {
                const targetPage = Math.floor(vmIndex / itemsPerPage) + 1;
                setCurrentPage(targetPage);
            }

            // wait for render then scroll
            setTimeout(() => {
                if (highlightedRowRef.current) {
                    highlightedRowRef.current.scrollIntoView({ behavior: 'smooth', block: 'center' });
                }
            }, 100);
        }
    }, [highlightedVm, resources, itemsPerPage]);

    // Update selectedDetailVm when resources change (via SSE)
    // This ensures the detail view shows the current status without re-selecting the VM
    useEffect(() => {
        if (selectedDetailVm && resources) {
            const updatedVm = resources.find(r =>
                r.vmid === selectedDetailVm.vmid
            );
            if (updatedVm) {
                // Check if any relevant field changed
                if (updatedVm.status !== selectedDetailVm.status ||
                    updatedVm.cpu !== selectedDetailVm.cpu ||
                    updatedVm.mem !== selectedDetailVm.mem ||
                    updatedVm.maxmem !== selectedDetailVm.maxmem ||
                    updatedVm.uptime !== selectedDetailVm.uptime ||
                    updatedVm.node !== selectedDetailVm.node ||
                    updatedVm.name !== selectedDetailVm.name ||
                    updatedVm.netin !== selectedDetailVm.netin ||
                    updatedVm.netout !== selectedDetailVm.netout ||
                    updatedVm.diskread !== selectedDetailVm.diskread ||
                    updatedVm.diskwrite !== selectedDetailVm.diskwrite
                ) {
                    setSelectedDetailVm(updatedVm);
                }
            } else {
                // VM was deleted or no longer in list
                setSelectedDetailVm(null);
            }
        }
    }, [resources]);

    const [showCrossClusterMigrate, setShowCrossClusterMigrate] = useState(null);
    const [showMetricsModal, setShowMetricsModal] = useState(null); // For VM metrics
    const [openDropdown, setOpenDropdown] = useState(null); // action dropdown menu
    const prevResources = useRef(resources);  // for comparison, not really used

    // #127 - lazy-load IPs from guest agent for running qemu VMs
    const ipCache = useRef({});
    const [ipTick, setIpTick] = useState(0);

    const filterLabels = {
        all: t('all'),
        running: t('active'),
        stopped: t('stopped'),
        vm: 'VM',
        lxc: 'LXC'
    };

    // #431: IP sorts by octet value, not as a string. Pull the IP from
    // the lazy guest-agent cache (qemu) or off the resource (lxc); blanks last.
    const getIp = (r) => {
        const c = ipCache.current[r.vmid];
        return (c && c !== 'loading') ? c : (r.ip || '');
    };
    const ipSortKey = (ip) => {
        const m = String(ip || '').match(/^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})/);
        if (!m) return Number.MAX_SAFE_INTEGER;  // no IPv4 (empty / IPv6 / loading) → bottom
        return (((+m[1] * 256) + +m[2]) * 256 + +m[3]) * 256 + +m[4];
    };

    // Filter + sort in one useMemo for perf
    // Added tag/node/ip search, people kept complaining they couldnt find stuff
    const filteredResources = useMemo(() => {
        let filtered = resources.filter(r => {
            // search by name, vmid, ip, node, or tags
            const s = search.toLowerCase();
            const matchesSearch = !search ||
                r.name?.toLowerCase().includes(s) ||
                r.vmid?.toString().includes(s) ||
                (r.node || '').toLowerCase().includes(s) ||
                (r.ip || '').toLowerCase().includes(s) ||
                (r.tags || '').toLowerCase().includes(s);
            const matchesFilter =
                filter === 'all' ||
                (filter === 'running' && r.status === 'running') ||
                (filter === 'stopped' && r.status === 'stopped') ||
                (filter === 'vm' && r.type === 'qemu') ||
                (filter === 'lxc' && r.type === 'lxc');
            const matchesNode = nodeFilter === 'all' || r.node === nodeFilter;
            const matchesTag = tagFilter === 'all' || (Array.isArray(r.tags) ? r.tags : (r.tags || '').split(';')).some(t => t.trim().toLowerCase() === tagFilter.toLowerCase());
            return matchesSearch && matchesFilter && matchesNode && matchesTag;
        });

        // sort
        filtered.sort((a, b) => {
            const dir = sortDir === 'asc' ? 1 : -1;
            if (sortBy === 'ip') {  // #431: per-octet numeric, not lexical
                return (ipSortKey(getIp(a)) - ipSortKey(getIp(b))) * dir;
            }
            const aVal = a[sortBy];
            const bVal = b[sortBy];
            if (typeof aVal === 'number') return (aVal - bVal) * dir;
            return String(aVal).localeCompare(String(bVal)) * dir;
        });

        return filtered;
    }, [resources, search, filter, nodeFilter, tagFilter, sortBy, sortDir, ipTick]);

    // Reset page when filters change
    // Also reset when cluster changes (via clusterId) to avoid showing empty page
    useEffect(() => {
        setCurrentPage(1);
    }, [search, filter, nodeFilter, tagFilter, sortBy, sortDir, itemsPerPage, clusterId]);

    // Paginated resources
    const totalPages = Math.max(1, Math.ceil(filteredResources.length / itemsPerPage));

    // Clamp currentPage to valid bounds - direct calculation, no effect loop
    const effectivePage = Math.max(1, Math.min(currentPage, totalPages));

    // Auto-correct if currentPage is out of bounds (e.g., after cluster switch)
    useEffect(() => {
        if (currentPage > totalPages && totalPages > 0) {
            setCurrentPage(1);  // Reset to first page
        }
    }, [filteredResources.length]);  // Only when data changes

    const paginatedResources = useMemo(() => {
        const startIndex = (effectivePage - 1) * itemsPerPage;
        return filteredResources.slice(startIndex, startIndex + itemsPerPage);
    }, [filteredResources, effectivePage, itemsPerPage]);

    // fetch IPs for visible running qemu VMs - #127
    useEffect(() => {
        if (!paginatedResources?.length) return;
        const toFetch = paginatedResources.filter(r =>
            r.type === 'qemu' && r.status === 'running' && !ipCache.current[r.vmid]
        );
        if (!toFetch.length) return;
        toFetch.forEach(vm => {
            ipCache.current[vm.vmid] = 'loading';
            const cid = vm._clusterId || clusterId;
            fetch(`/api/clusters/${cid}/vms/${vm.node}/qemu/${vm.vmid}/guest-info`, {
                credentials: 'include', headers: getAuthHeaders()
            })
                .then(r => r.ok ? r.json() : null)
                .then(data => {
                    ipCache.current[vm.vmid] = data?.ip_addresses?.length ? data.ip_addresses[0] : null;
                    setIpTick(t => t + 1);
                })
                .catch(() => { ipCache.current[vm.vmid] = null; });
        });
    }, [paginatedResources]);

    const handleSort = (col) => {
        let nextBy = col, nextDir = 'asc';
        if (sortBy === col) {
            nextDir = sortDir === 'asc' ? 'desc' : 'asc';
            setSortDir(nextDir);
        } else {
            setSortBy(col);
            setSortDir('asc');  // reset to asc on new column
        }
        // #431: persist the choice per user
        try { localStorage.setItem(_sortKey, JSON.stringify({ by: nextBy, dir: nextDir })); } catch (e) { }
    };

    // 1073741824 = 1024^3 (GB), 1048576 = 1024^2 (MB)
    const formatBytes = (bytes) => {
        const gb = bytes / 1073741824;
        return gb >= 1 ? `${gb.toFixed(1)} GB` : `${(bytes / 1048576).toFixed(0)} MB`;
    };

    const getVmProxmoxTarget = (resource) => ({
        ...resource,
        type: resource.type,
        node: resource.node,
        node_ip: resource.node_ip || resource.nodeIp || sourceCluster?.current_host || sourceCluster?.host
    });

    const handleAction = async (resource, action) => {
        const key = `${resource.vmid}-${action}`;
        setActionLoading(prev => ({ ...prev, [key]: true }));
        await onVmAction(resource, action);
        setActionLoading(prev => ({ ...prev, [key]: false }));
    };

    const toggleSelect = (resource) => {
        setSelectedVms(prev => {
            const exists = prev.find(v => v.vmid === resource.vmid);
            if (exists) {
                return prev.filter(v => v.vmid !== resource.vmid);
            }
            return [...prev, { vmid: resource.vmid, node: resource.node, type: resource.type, name: resource.name }];
        });
    };

    const toggleSelectAll = () => {
        if (selectedVms.length === filteredResources.length) {
            setSelectedVms([]);
        } else {
            setSelectedVms(filteredResources.map(r => ({ vmid: r.vmid, node: r.node, type: r.type, name: r.name })));
        }
    };

    const runBulkAction = async () => {
        if (!onBulkAction || !bulkAction || selectedVms.length === 0) return;
        const actionLabel = t(`bulkActions.${bulkAction}`, { defaultValue: bulkAction });
        const nameList = selectedVms.length === 1
            ? selectedVms[0].name || `VM ${selectedVms[0].vmid}`
            : `${selectedVms.length} ${t('items')}`;
        if (!window.confirm(`${t('bulkActions.confirm')} ${actionLabel} ${t('bulkActions.on')} ${nameList}?`)) return;

        setBulkWorking(true);
        try {
            await onBulkAction({ action: bulkAction, guests: selectedVms });
            setSelectedVms([]);
        } finally {
            setBulkWorking(false);
        }
    };

    const availableNodes = useMemo(() => {
        const nodeSet = new Set(resources.map(r => r.node).filter(Boolean));
        return Array.from(nodeSet).sort();
    }, [resources]);

    const availableTags = useMemo(() => {
        const tagSet = new Set();
        resources.forEach(r => {
            if (r.tags) {
                const tags = Array.isArray(r.tags) ? r.tags : r.tags.split(';');
                tags.filter(t => t.trim()).forEach(t => tagSet.add(t.trim()));
            }
        });
        return Array.from(tagSet).sort();
    }, [resources]);

    const groupedByNode = useMemo(() => {
        const groups = {};
        filteredResources.forEach(r => {
            if (!groups[r.node]) groups[r.node] = [];
            groups[r.node].push(r);
        });
        return groups;
    }, [filteredResources]);

    return (
        <div className={isCorporate ? 'space-y-0' : 'space-y-4'}>
            {/* Corporate flat toolbar vs modern rounded pills */}
            {isCorporate ? (
                <div className="corp-vm-toolbar">
                    <div className="relative">
                        <Icons.Search className="w-3.5 h-3.5 absolute left-2 top-1/2 -translate-y-1/2" style={{ color: '#728b9a' }} />
                        <input
                            type="text"
                            placeholder={t('searchByNameOrId')}
                            value={search}
                            onChange={(e) => setSearch(e.target.value)}
                            className="pr-3 py-1 text-[13px] bg-transparent border text-white placeholder-gray-600 focus:outline-none w-56"
                            style={{ paddingLeft: '28px', borderColor: 'var(--corp-border-medium)', borderRadius: '2px' }}
                        />
                    </div>
                    <span className="corp-toolbar-divider" />
                    {['all', 'running', 'stopped', 'vm', 'lxc'].map(f => (
                        <button key={f} onClick={() => setFilter(f)}
                            className={`corp-toolbar-filter ${filter === f ? 'active' : ''}`}>
                            {filterLabels[f]}
                        </button>
                    ))}
                    <span className="corp-toolbar-divider" />
                    <span className="text-[11px]" style={{ color: '#728b9a' }}>
                        {filteredResources.length} {t('items')}
                    </span>
                    <div style={{ flex: 1 }} />
                    {selectedVms.length > 0 && (
                        <span className="text-[11px]" style={{ color: '#49afd9' }}>
                            {selectedVms.length} {t('selectedItems')}
                        </span>
                    )}
                </div>
            ) : (
                <div className="flex flex-wrap items-center gap-3">
                    <div className="relative flex-1 min-w-[200px]">
                        <Icons.Search />
                        <input
                            type="text"
                            placeholder={t('searchByNameOrId')}
                            value={search}
                            onChange={(e) => setSearch(e.target.value)}
                            className={isCorporate ? 'pl-10 corp-input' : "w-full pl-10 pr-4 py-2 bg-proxmox-dark border border-proxmox-border rounded-lg text-sm text-white placeholder-gray-500 focus:outline-none focus:border-proxmox-orange transition-colors"}
                        />
                        <div className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500">
                            <Icons.Search />
                        </div>
                    </div>
                    <div className={`flex items-center gap-2 ${isCorporate ? 'corp-toolbar-filter-group' : ''}`}>
                        {['all', 'running', 'stopped', 'vm', 'lxc'].map(f => (
                            <button
                                key={f}
                                onClick={() => setFilter(f)}
                                className={isCorporate
                                    ? `corp-toolbar-filter ${filter === f ? 'active' : ''}`
                                    : `px-3 py-1.5 text-xs font-medium rounded-lg transition-all ${filter === f
                                        ? 'bg-proxmox-orange text-white'
                                        : 'bg-proxmox-dark text-gray-400 hover:text-white border border-proxmox-border'
                                    }`}
                            >
                                {filterLabels[f]}
                            </button>
                        ))}
                        {availableNodes.length > 1 && (
                            <select
                                value={nodeFilter}
                                onChange={e => setNodeFilter(e.target.value)}
                                className={isCorporate
                                    ? `corp-toolbar-filter ${nodeFilter !== 'all' ? 'active' : ''}`
                                    : `px-3 py-1.5 text-xs font-medium rounded-lg transition-all cursor-pointer ${nodeFilter !== 'all'
                                        ? 'bg-proxmox-orange text-white'
                                        : 'bg-proxmox-dark text-gray-400 border border-proxmox-border'
                                    }`}
                            >
                                <option value="all">{t('allNodes2')}</option>
                                {availableNodes.map(n => <option key={n} value={n}>{n}</option>)}
                            </select>
                        )}
                        {availableTags.length > 0 && (
                            <select
                                value={tagFilter}
                                onChange={e => setTagFilter(e.target.value)}
                                className={isCorporate
                                    ? `corp-toolbar-filter ${tagFilter !== 'all' ? 'active' : ''}`
                                    : `px-3 py-1.5 text-xs font-medium rounded-lg transition-all cursor-pointer ${tagFilter !== 'all'
                                        ? 'bg-proxmox-orange text-white'
                                        : 'bg-proxmox-dark text-gray-400 border border-proxmox-border'
                                    }`}
                            >
                                <option value="all">{t('allTags')}</option>
                                {availableTags.map(tag => <option key={tag} value={tag}>{tag}</option>)}
                            </select>
                        )}
                    </div>
                    {isCorporate ? (
                        <div className="corp-toolbar-group">
                            <button onClick={() => setViewMode('cards')} className={`p-1.5 ${viewMode === 'cards' ? 'bg-proxmox-orange text-white' : 'bg-proxmox-dark text-gray-400 hover:text-white'}`} title={t('gridView')}>
                                <Icons.Grid />
                            </button>
                            <button onClick={() => setViewMode('table')} className={`p-1.5 ${viewMode === 'table' ? 'bg-proxmox-orange text-white' : 'bg-proxmox-dark text-gray-400 hover:text-white'}`} title={t('listView')}>
                                <Icons.List />
                            </button>
                            <button onClick={() => setViewMode('detail')} className={`p-1.5 ${viewMode === 'detail' ? 'bg-proxmox-orange text-white' : 'bg-proxmox-dark text-gray-400 hover:text-white'}`} title={t('compactView')}>
                                <Icons.Eye />
                            </button>
                        </div>
                    ) : (
                        <div className="flex items-center gap-1 p-1 bg-proxmox-dark rounded-lg border border-proxmox-border">
                            <button
                                onClick={() => setViewMode('cards')}
                                className={`p-1.5 rounded transition-colors ${viewMode === 'cards' ? 'bg-proxmox-orange text-white' : 'text-gray-400 hover:text-white'}`}
                                title={t('gridView')}
                            >
                                <Icons.Grid />
                            </button>
                            <button
                                onClick={() => setViewMode('table')}
                                className={`p-1.5 rounded transition-colors ${viewMode === 'table' ? 'bg-proxmox-orange text-white' : 'text-gray-400 hover:text-white'}`}
                                title={t('listView')}
                            >
                                <Icons.List />
                            </button>
                            <button
                                onClick={() => setViewMode('detail')}
                                className={`p-1.5 rounded transition-colors ${viewMode === 'detail' ? 'bg-proxmox-orange text-white' : 'text-gray-400 hover:text-white'}`}
                                title={t('compactView')}
                            >
                                <Icons.Eye />
                            </button>
                        </div>
                    )}
                </div>
            )}

            {/* Bulk Actions Bar (hidden in corporate - integrated in toolbar) */}
            {!isCorporate && selectedVms.length > 0 && (
                <div className="flex flex-wrap items-center gap-3 p-3 bg-proxmox-orange/10 border border-proxmox-orange/30 rounded-lg">
                    <span className="text-sm text-proxmox-orange font-medium">
                        {selectedVms.length} {t('selectedItems')}
                    </span>
                    <select
                        value={bulkAction}
                        onChange={e => setBulkAction(e.target.value)}
                        disabled={bulkWorking}
                        className="px-2 py-1.5 text-sm bg-proxmox-dark border border-proxmox-border rounded-lg text-white focus:outline-none focus:border-proxmox-orange"
                    >
                        <option value="start">{t('bulkActions.start')}</option>
                        <option value="stop">{t('bulkActions.stop')}</option>
                        <option value="shutdown">{t('bulkActions.shutdown')}</option>
                        <option value="reboot">{t('bulkActions.reboot')}</option>
                        <option value="reset">{t('bulkActions.reset')}</option>
                        <option value="suspend">{t('bulkActions.suspend')}</option>
                        <option value="resume">{t('bulkActions.resume')}</option>
                    </select>
                    <button
                        onClick={runBulkAction}
                        disabled={bulkWorking}
                        className="flex items-center gap-2 px-3 py-1.5 bg-proxmox-orange rounded-lg text-white text-sm hover:bg-orange-600 disabled:opacity-50"
                    >
                        {bulkWorking && <Icons.RotateCw className="w-4 h-4 animate-spin" />}
                        {t('bulkActions.run')}
                    </button>
                    <button
                        onClick={() => setShowBulkMigrate(true)}
                        className="flex items-center gap-2 px-3 py-1.5 bg-blue-600 rounded-lg text-white text-sm hover:bg-blue-700"
                    >
                        <Icons.ArrowRight />
                        {t('migrate')}
                    </button>
                    <button
                        onClick={() => setSelectedVms([])}
                        className="px-3 py-1.5 text-gray-400 hover:text-white text-sm"
                    >
                        {t('deselectAll')}
                    </button>
                </div>
            )}

            {/* Cards View */}
            {viewMode === 'cards' && (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
                    {paginatedResources.length === 0 ? (
                        <div className="col-span-full text-center py-12 text-gray-500">
                            {t('noResults')}
                        </div>
                    ) : (
                        paginatedResources.map((resource, idx) => (
                            <div
                                key={resource.vmid}
                                ref={highlightedVm?.vmid === resource.vmid ? highlightedRowRef : null}
                                className={`bg-proxmox-card border rounded-xl overflow-hidden transition-all hover:border-proxmox-orange/50 animate-fade-in ${selectedVms.find(v => v.vmid === resource.vmid)
                                    ? 'border-proxmox-orange bg-proxmox-orange/5'
                                    : highlightedVm?.vmid === resource.vmid
                                        ? 'ring-2 ring-proxmox-orange border-proxmox-orange bg-proxmox-orange/20'
                                        : 'border-proxmox-border'
                                    }`}
                                style={{ animationDelay: `${idx * 30}ms` }}
                            >
                                {/* Card Header */}
                                <div className={isCorporate ? 'flex items-center justify-between corp-card-header' : "flex items-center justify-between p-4 border-b border-proxmox-border bg-proxmox-dark/50"}>
                                    <div className="flex items-center gap-3">
                                        <input
                                            type="checkbox"
                                            checked={!!selectedVms.find(v => v.vmid === resource.vmid)}
                                            onChange={() => toggleSelect(resource)}
                                            className="w-4 h-4 rounded border-proxmox-border bg-proxmox-dark text-proxmox-orange"
                                        />
                                        <div
                                            className={`p-2 rounded-lg ${isGuestTemplate(resource) ? 'bg-gray-200/60 text-gray-700 border border-gray-300/40' : resource.type === 'qemu' ? 'bg-blue-500/10' : 'bg-purple-500/10'}`}
                                            title={getGuestTypeTitle(resource, t)}
                                        >
                                            {getGuestTypeIcon(resource)}
                                        </div>
                                        <div>
                                            <div className={`font-medium truncate ${onVmNavigate ? 'text-blue-400 hover:text-blue-300 hover:underline cursor-pointer' : 'text-white'}`} style={{ maxWidth: 'min(200px, 20vw)' }} onClick={onVmNavigate ? (e) => { e.stopPropagation(); onVmNavigate(resource); } : undefined}>
                                                {resource.name || `${resource.type === 'qemu' ? 'VM' : 'CT'} ${resource.vmid}`}
                                            </div>
                                            <div className="text-xs text-gray-500">ID: {resource.vmid}</div>
                                        </div>
                                    </div>
                                    <span className={`w-2.5 h-2.5 rounded-full ${resource.status === 'running' ? 'bg-green-500 animate-pulse' : 'bg-red-500'
                                        }`} />
                                </div>

                                {/* Card Body */}
                                <div className="p-4 space-y-3">
                                    <div className="flex items-center justify-between text-sm">
                                        <span className="text-gray-500">{t('node')}</span>
                                        <span className="text-gray-300 font-mono">{resource.node}</span>
                                    </div>
                                    <div className="flex items-center justify-between text-sm">
                                        <span className="text-gray-500">{t('status')}</span>
                                        <span className={`px-2 py-0.5 rounded text-xs font-medium ${resource.status === 'running'
                                            ? 'bg-green-500/10 text-green-400'
                                            : 'bg-red-500/10 text-red-400'
                                            }`}>
                                            {resource.status === 'running' ? t('running') : t('stopped')}
                                        </span>
                                    </div>
                                    {/* IP Address - shown for running VMs with guest agent */}
                                    {resource.status === 'running' && resource.ip && (
                                        <div className="flex items-center justify-between text-sm">
                                            <span className="text-gray-500">IP</span>
                                            <span className="text-gray-300 font-mono text-xs">{resource.ip}</span>
                                        </div>
                                    )}
                                    {/* VM Tags */}
                                    {resource.tags && (
                                        <div className="flex flex-wrap gap-1">
                                            {(Array.isArray(resource.tags) ? resource.tags : resource.tags.split(';')).filter(t => t.trim()).map((tag, i) => (
                                                <span key={i} className="px-1.5 py-0.5 text-xs rounded bg-proxmox-orange/20 text-proxmox-orange">
                                                    {tag.trim()}
                                                </span>
                                            ))}
                                        </div>
                                    )}
                                    {/* Backup status pill */}
                                    {backupStatus && backupStatus[resource.vmid] && window.ProxmoxVExBackupStatusPill && (
                                        <div className="flex items-center justify-between text-sm">
                                            <span className="text-gray-500 text-xs">Backup</span>
                                            {React.createElement(window.ProxmoxVExBackupStatusPill, {
                                                status: backupStatus[resource.vmid].status,
                                                lastAgeHours: backupStatus[resource.vmid].last_backup_age_hours,
                                                encrypted: backupStatus[resource.vmid].encrypted,
                                                verifyAgeHours: backupStatus[resource.vmid].last_verify_age_hours,
                                                count30d: backupStatus[resource.vmid].count_30d,
                                            })}
                                        </div>
                                    )}
                                    <div>
                                        <div className="flex items-center justify-between text-xs mb-1">
                                            <span className="text-gray-500">{t('ram')}</span>
                                            <span className="text-gray-400 font-mono">
                                                {formatBytes(resource.mem)} / {formatBytes(resource.maxmem)}
                                            </span>
                                        </div>
                                        <div className="h-1.5 rounded-full bg-proxmox-border overflow-hidden">
                                            <div
                                                className="h-full rounded-full transition-all"
                                                style={{
                                                    width: `${resource.mem_percent || 0}%`,
                                                    background: resource.mem_percent < 50 ? '#22c55e' : resource.mem_percent < 80 ? '#eab308' : '#ef4444'
                                                }}
                                            />
                                        </div>
                                    </div>
                                    <div>
                                        <div className="flex items-center justify-between text-xs mb-1">
                                            <span className="text-gray-500">{t('cpu')}</span>
                                            <span className="text-gray-400 font-mono">
                                                {(resource.cpu_percent || 0).toFixed(1)}% {resource.maxcpu && `(${resource.maxcpu} ${t('cores')})`}
                                            </span>
                                        </div>
                                        <div className="h-1.5 rounded-full bg-proxmox-border overflow-hidden">
                                            <div
                                                className="h-full rounded-full transition-all"
                                                style={{
                                                    width: `${Math.min(resource.cpu_percent || 0, 100)}%`,
                                                    background: (resource.cpu_percent || 0) < 50 ? '#3b82f6' : (resource.cpu_percent || 0) < 80 ? '#eab308' : '#ef4444'
                                                }}
                                            />
                                        </div>
                                    </div>
                                    {resource.maxdisk > 0 && (
                                        <div>
                                            <div className="flex items-center justify-between text-xs mb-1">
                                                <span className="text-gray-500">{t('disk')}</span>
                                                <span className="text-gray-400 font-mono">
                                                    {resource.disk > 0 ? `${formatBytes(resource.disk)} / ${formatBytes(resource.maxdisk)}` : formatBytes(resource.maxdisk)}
                                                </span>
                                            </div>
                                            {resource.disk > 0 && (
                                                <div className="h-1.5 rounded-full bg-proxmox-border overflow-hidden">
                                                    <div
                                                        className="h-full rounded-full transition-all"
                                                        style={{
                                                            width: `${resource.disk_percent || 0}%`,
                                                            background: (resource.disk_percent || 0) < 75 ? '#22c55e' : (resource.disk_percent || 0) < 90 ? '#eab308' : '#ef4444'
                                                        }}
                                                    />
                                                </div>
                                            )}
                                        </div>
                                    )}
                                </div>

                                {/* Card Actions */}
                                <div className="flex items-center justify-between p-3 border-t border-proxmox-border bg-proxmox-dark/30">
                                    {/* Primary Actions - Always visible */}
                                    <div className="flex items-center gap-1">
                                        {getProxmoxObjectUrl(getVmProxmoxTarget(resource)) && (
                                            <button
                                                onClick={() => openProxmoxObject(getVmProxmoxTarget(resource))}
                                                className="p-1.5 rounded-lg hover:bg-cyan-500/20 text-gray-400 hover:text-cyan-400 transition-all"
                                                title={t('openInProxmox')}
                                            >
                                                <Icons.ExternalLink />
                                            </button>
                                        )}
                                        {resource.status === 'stopped' ? (
                                            <button
                                                onClick={() => handleAction(resource, 'start')}
                                                disabled={actionLoading[`${resource.vmid}-start`]}
                                                className="p-1.5 rounded-lg hover:bg-green-500/20 text-gray-400 hover:text-green-400 transition-all disabled:opacity-50"
                                                title={t('start')}
                                            >
                                                {actionLoading[`${resource.vmid}-start`] ? <Icons.RotateCw className="animate-spin" /> : <Icons.PlayCircle />}
                                            </button>
                                        ) : (
                                            <>
                                                <button
                                                    onClick={() => handleAction(resource, 'shutdown')}
                                                    disabled={actionLoading[`${resource.vmid}-shutdown`]}
                                                    className="p-1.5 rounded-lg hover:bg-yellow-500/20 text-gray-400 hover:text-yellow-400 transition-all disabled:opacity-50"
                                                    title={t('shutdown')}
                                                >
                                                    {actionLoading[`${resource.vmid}-shutdown`] ? <Icons.RotateCw className="animate-spin" /> : <Icons.Power />}
                                                </button>
                                                <button
                                                    onClick={() => handleAction(resource, 'reboot')}
                                                    disabled={actionLoading[`${resource.vmid}-reboot`]}
                                                    className="p-1.5 rounded-lg hover:bg-orange-500/20 text-gray-400 hover:text-orange-400 transition-all disabled:opacity-50"
                                                    title={t('reboot')}
                                                >
                                                    {actionLoading[`${resource.vmid}-reboot`] ? <Icons.RotateCw className="animate-spin" /> : <Icons.RefreshCw />}
                                                </button>
                                            </>
                                        )}
                                        {resource.status === 'running' && (
                                            <button
                                                onClick={() => onOpenConsole(resource)}
                                                className="p-1.5 rounded-lg hover:bg-blue-500/20 text-gray-400 hover:text-blue-400 transition-all"
                                                title={t('console')}
                                            >
                                                <Icons.Monitor />
                                            </button>
                                        )}
                                        <button
                                            onClick={() => onOpenConfig(resource)}
                                            className="p-1.5 rounded-lg hover:bg-purple-500/20 text-gray-400 hover:text-purple-400 transition-all"
                                            title={t('configuration')}
                                        >
                                            <Icons.Cog />
                                        </button>
                                        <button
                                            onClick={() => setShowMigrateModal(resource)}
                                            className="p-1.5 rounded-lg hover:bg-cyan-500/20 text-gray-400 hover:text-cyan-400 transition-all"
                                            title={t('migrate')}
                                        >
                                            <Icons.ArrowRight />
                                        </button>
                                    </div>

                                    {/* More Actions Dropdown */}
                                    <div className="relative">
                                        <button
                                            onClick={(e) => {
                                                e.stopPropagation();
                                                setOpenDropdown(openDropdown === resource.vmid ? null : resource.vmid);
                                            }}
                                            className="p-1.5 rounded-lg hover:bg-proxmox-hover text-gray-400 hover:text-white transition-all"
                                            title={t('moreActions')}
                                        >
                                            <Icons.MoreVertical />
                                        </button>

                                        {openDropdown === resource.vmid && (
                                            <>
                                                <div className="fixed inset-0 z-40" onClick={() => setOpenDropdown(null)} />
                                                <div className="absolute right-0 bottom-full mb-1 w-48 bg-proxmox-card border border-proxmox-border rounded-lg shadow-xl z-50 py-1 animate-fade-in">
                                                    <button
                                                        onClick={() => { setShowMigrateModal(resource); setOpenDropdown(null); }}
                                                        className="w-full px-3 py-2 text-left text-sm text-gray-300 hover:bg-proxmox-hover flex items-center gap-2"
                                                    >
                                                        <Icons.ArrowRight className="w-4 h-4" />
                                                        {t('migrate')}
                                                    </button>
                                                    {clusters && clusters.length > 1 && (
                                                        <button
                                                            onClick={() => { setShowCrossClusterMigrate(resource); setOpenDropdown(null); }}
                                                            className="w-full px-3 py-2 text-left text-sm text-gray-300 hover:bg-proxmox-hover flex items-center gap-2"
                                                        >
                                                            <Icons.Globe className="w-4 h-4" />
                                                            {t('crossClusterMigrate')}
                                                        </button>
                                                    )}
                                                    <button
                                                        onClick={() => { setShowMetricsModal(resource); setOpenDropdown(null); }}
                                                        className="w-full px-3 py-2 text-left text-sm text-gray-300 hover:bg-proxmox-hover flex items-center gap-2"
                                                    >
                                                        <Icons.BarChart className="w-4 h-4" />
                                                        {t('performance')}
                                                    </button>
                                                    <button
                                                        onClick={() => { setShowCloneModal(resource); setOpenDropdown(null); }}
                                                        className="w-full px-3 py-2 text-left text-sm text-gray-300 hover:bg-proxmox-hover flex items-center gap-2"
                                                    >
                                                        <Icons.Copy className="w-4 h-4" />
                                                        {t('clone')}
                                                    </button>
                                                    {resource.status === 'running' && (
                                                        <>
                                                            {/* Force Reset - QEMU only */}
                                                            {resource.type === 'qemu' && (
                                                                <button
                                                                    onClick={() => { onVmAction(resource, 'reset'); setOpenDropdown(null); }}
                                                                    className="w-full px-3 py-2 text-left text-sm text-yellow-400 hover:bg-yellow-500/10 flex items-center gap-2"
                                                                >
                                                                    <Icons.Zap className="w-4 h-4" />
                                                                    {t('forceReset')}
                                                                </button>
                                                            )}
                                                            <button
                                                                onClick={() => { onForceStop(resource); setOpenDropdown(null); }}
                                                                className="w-full px-3 py-2 text-left text-sm text-yellow-400 hover:bg-yellow-500/10 flex items-center gap-2"
                                                            >
                                                                <Icons.XCircle className="w-4 h-4" />
                                                                {t('forceStop')}
                                                            </button>
                                                        </>
                                                    )}
                                                    <div className="border-t border-proxmox-border my-1" />
                                                    <button
                                                        onClick={() => { setShowDeleteConfirm(resource); setOpenDropdown(null); }}
                                                        className="w-full px-3 py-2 text-left text-sm text-red-400 hover:bg-red-500/10 flex items-center gap-2"
                                                    >
                                                        <Icons.Trash className="w-4 h-4" />
                                                        {t('delete')}
                                                    </button>
                                                </div>
                                            </>
                                        )}
                                    </div>
                                </div>
                            </div>
                        ))
                    )}
                </div>
            )}

            {/* Table view, corporate data-grid */}
            {viewMode === 'table' && (
                <div className={isCorporate ? 'overflow-hidden border border-proxmox-border' : 'overflow-hidden rounded-xl border border-proxmox-border'}>
                    <table className={`w-full ${isCorporate ? 'corp-datagrid corp-datagrid-striped' : ''}`}>
                        <thead>
                            <tr className={isCorporate ? 'text-left' : 'bg-proxmox-dark text-left'} style={isCorporate ? { background: 'var(--corp-header-bg)' } : undefined}>
                                <th className={isCorporate ? 'px-2 py-1.5 w-8' : 'px-4 py-3 w-10'}>
                                    <input
                                        type="checkbox"
                                        checked={selectedVms.length === filteredResources.length && filteredResources.length > 0}
                                        onChange={toggleSelectAll}
                                        className="w-4 h-4 rounded border-proxmox-border bg-proxmox-dark text-proxmox-orange focus:ring-proxmox-orange"
                                    />
                                </th>
                                {[
                                    { key: 'vmid', label: 'ID' },
                                    { key: 'name', label: t('name') },
                                    { key: 'type', label: t('type') },
                                    { key: 'node', label: 'Node' },
                                    { key: 'ip', label: 'IP' },
                                    { key: 'cpu_percent', label: 'CPU' },
                                    { key: 'mem', label: 'RAM' },
                                    { key: 'disk', label: t('disk') },
                                    { key: 'status', label: 'Status' },
                                    { key: 'actions', label: t('actions') },
                                ].map(col => (
                                    <th
                                        key={col.key}
                                        onClick={() => col.key !== 'actions' && !col.noSort && handleSort(col.key)}
                                        className={isCorporate
                                            ? `text-xs font-semibold uppercase tracking-wider ${col.key !== 'actions' && !col.noSort ? 'cursor-pointer hover:text-white' : ''}`
                                            : `px-4 py-3 text-xs font-semibold text-gray-400 uppercase tracking-wider ${col.key !== 'actions' && !col.noSort ? 'cursor-pointer hover:text-white' : ''} transition-colors`
                                        }
                                        style={isCorporate ? { color: '#adbbc4', padding: '6px 8px', fontSize: '12px' } : undefined}
                                    >
                                        <div className="flex items-center gap-1">
                                            {col.label}
                                            {isCorporate ? (
                                                sortBy === col.key ? (
                                                    <svg className="corp-sort-icon" viewBox="0 0 8 8"><path d={sortDir === 'asc' ? 'M4 1L7 6H1z' : 'M4 7L1 2h6z'} /></svg>
                                                ) : col.key !== 'actions' && !col.noSort ? (
                                                    <svg className="corp-sort-icon corp-sort-hint" viewBox="0 0 8 8"><path d="M4 1L7 6H1z" /></svg>
                                                ) : null
                                            ) : (
                                                sortBy === col.key && (
                                                    <span className="text-proxmox-orange">{sortDir === 'asc' ? '↑' : '↓'}</span>
                                                )
                                            )}
                                        </div>
                                    </th>
                                ))}
                            </tr>
                        </thead>
                        <tbody className={isCorporate ? '' : 'divide-y divide-proxmox-border'}>
                            {paginatedResources.length === 0 ? (
                                <tr>
                                    <td colSpan={10} className={isCorporate ? 'px-2 py-4 text-center text-gray-500' : 'px-4 py-8 text-center text-gray-500'}>
                                        {t('noResults')}
                                    </td>
                                </tr>
                            ) : (
                                paginatedResources.map((resource, idx) => (
                                    <tr
                                        key={resource.vmid}
                                        ref={highlightedVm?.vmid === resource.vmid ? highlightedRowRef : null}
                                        className={isCorporate
                                            ? `table-row-hover ${selectedVms.find(v => v.vmid === resource.vmid) ? 'corp-row-selected' : ''} ${highlightedVm?.vmid === resource.vmid ? 'corp-row-selected' : ''}`
                                            : `table-row-hover bg-proxmox-card animate-fade-in ${selectedVms.find(v => v.vmid === resource.vmid) ? 'bg-proxmox-orange/5' : ''} ${highlightedVm?.vmid === resource.vmid ? 'ring-2 ring-proxmox-orange bg-proxmox-orange/20' : ''}`
                                        }
                                        style={isCorporate ? undefined : { animationDelay: `${idx * 30}ms` }}
                                    >
                                        <td className="px-4 py-3">
                                            <input
                                                type="checkbox"
                                                checked={!!selectedVms.find(v => v.vmid === resource.vmid)}
                                                onChange={() => toggleSelect(resource)}
                                                className="w-4 h-4 rounded border-proxmox-border bg-proxmox-dark text-proxmox-orange focus:ring-proxmox-orange"
                                            />
                                        </td>
                                        <td className="px-4 py-3">
                                            <span className="font-mono text-sm text-gray-300">{resource.vmid}</span>
                                        </td>
                                        <td className="px-4 py-3">
                                            <div>
                                                <div className="flex items-center gap-1.5">
                                                    <span className={`font-medium truncate block ${onVmNavigate ? 'text-blue-400 hover:text-blue-300 hover:underline cursor-pointer' : 'text-white'}`} style={{ maxWidth: 'min(220px, 18vw)' }} onClick={onVmNavigate ? (e) => { e.stopPropagation(); onVmNavigate(resource); } : undefined} title={resource.name}>{resource.name || '-'}</span>
                                                    {/* Backup status pill (table-row layout) */}
                                                    {backupStatus && backupStatus[resource.vmid] && window.ProxmoxVExBackupStatusPill && React.createElement(window.ProxmoxVExBackupStatusPill, {
                                                        status: backupStatus[resource.vmid].status,
                                                        lastAgeHours: backupStatus[resource.vmid].last_backup_age_hours,
                                                        encrypted: backupStatus[resource.vmid].encrypted,
                                                        verifyAgeHours: backupStatus[resource.vmid].last_verify_age_hours,
                                                        count30d: backupStatus[resource.vmid].count_30d,
                                                    })}
                                                </div>
                                                {resource.tags && (
                                                    <div className="flex flex-wrap gap-1 mt-1">
                                                        {(Array.isArray(resource.tags) ? resource.tags : resource.tags.split(';')).filter(t => t.trim()).slice(0, 3).map((tag, i) => (
                                                            <span key={i} className="px-1.5 py-0.5 text-xs rounded bg-proxmox-orange/20 text-proxmox-orange">
                                                                {tag.trim()}
                                                            </span>
                                                        ))}
                                                        {(Array.isArray(resource.tags) ? resource.tags : resource.tags.split(';')).filter(t => t.trim()).length > 3 && (
                                                            <span className="px-1.5 py-0.5 text-xs rounded bg-gray-500/20 text-gray-400">
                                                                +{(Array.isArray(resource.tags) ? resource.tags : resource.tags.split(';')).filter(t => t.trim()).length - 3}
                                                            </span>
                                                        )}
                                                    </div>
                                                )}
                                            </div>
                                        </td>
                                        <td className="px-4 py-3">
                                            <span className={`inline-flex items-center gap-1.5 px-2 py-1 rounded-md text-xs font-medium ${isGuestTemplate(resource)
                                                ? 'bg-gray-200/60 text-gray-700 border border-gray-300/40'
                                                : resource.type === 'qemu'
                                                    ? 'bg-blue-500/10 text-blue-400 border border-blue-500/20'
                                                    : 'bg-purple-500/10 text-purple-400 border border-purple-500/20'
                                                }`} title={getGuestTypeTitle(resource, t)}>
                                                {getGuestTypeIcon(resource)}
                                                {getGuestTypeLabel(resource)}
                                                {isGuestTemplate(resource) && (
                                                    <span className="text-amber-300">({getTemplateLabel(t)})</span>
                                                )}
                                            </span>
                                        </td>
                                        <td className="px-4 py-3">
                                            <span className="text-sm text-gray-300 truncate block" style={{ maxWidth: 'min(140px, 12vw)' }} title={resource.node}>{resource.node}</span>
                                        </td>
                                        <td className="px-4 py-3">
                                            <span className="text-xs font-mono text-gray-400">{ipCache.current[resource.vmid] && ipCache.current[resource.vmid] !== 'loading' ? ipCache.current[resource.vmid] : '-'}</span>
                                        </td>
                                        <td className="px-4 py-3">
                                            <div className="flex items-center gap-2">
                                                <div className="flex-1 max-w-[60px]">
                                                    <div className="h-1.5 rounded-full bg-proxmox-border overflow-hidden">
                                                        <div className="h-full rounded-full transition-all"
                                                            style={{
                                                                width: `${Math.min(resource.cpu_percent || 0, 100)}%`,
                                                                background: (resource.cpu_percent || 0) < 50 ? '#3b82f6' : (resource.cpu_percent || 0) < 80 ? '#eab308' : '#ef4444'
                                                            }}
                                                        />
                                                    </div>
                                                </div>
                                                <span className="text-xs text-gray-400 font-mono">{(resource.cpu_percent || 0).toFixed(0)}%</span>
                                                {isCorporate && resource.status === 'running' && (() => {
                                                    const h = (vmHistRef.current[resource.vmid] || {}).cpu;
                                                    if (!h || h.length < 2) return null;
                                                    const mx = Math.max(...h, 1);
                                                    const pts = h.map((v, i) => `${(i / 14) * 30},${10 - ((v / mx) * 10)}`).join(' ');
                                                    return <svg width="30" height="10" className="corp-vm-sparkline"><polyline fill="none" stroke="#49afd9" strokeWidth="1" points={pts} /></svg>;
                                                })()}
                                            </div>
                                        </td>
                                        <td className="px-4 py-3">
                                            <div className="flex items-center gap-2">
                                                <div className="flex-1 max-w-[60px]">
                                                    <div className="h-1.5 rounded-full bg-proxmox-border overflow-hidden">
                                                        <div
                                                            className="h-full rounded-full transition-all"
                                                            style={{
                                                                width: `${resource.mem_percent || 0}%`,
                                                                background: resource.mem_percent < 50 ? '#22c55e' : resource.mem_percent < 80 ? '#eab308' : '#ef4444'
                                                            }}
                                                        />
                                                    </div>
                                                </div>
                                                <span className="text-xs text-gray-400 font-mono whitespace-nowrap">
                                                    {formatBytes(resource.mem)} / {formatBytes(resource.maxmem)}
                                                </span>
                                                {isCorporate && resource.status === 'running' && (() => {
                                                    const h = (vmHistRef.current[resource.vmid] || {}).mem;
                                                    if (!h || h.length < 2) return null;
                                                    const mx = Math.max(...h, 1);
                                                    const pts = h.map((v, i) => `${(i / 14) * 30},${10 - ((v / mx) * 10)}`).join(' ');
                                                    return <svg width="30" height="10" className="corp-vm-sparkline"><polyline fill="none" stroke="#9b59b6" strokeWidth="1" points={pts} /></svg>;
                                                })()}
                                            </div>
                                        </td>
                                        <td className="px-4 py-3">
                                            <div className="flex items-center gap-2">
                                                {resource.disk > 0 && (
                                                    <div className="flex-1 max-w-[60px]">
                                                        <div className="h-1.5 rounded-full bg-proxmox-border overflow-hidden">
                                                            <div
                                                                className="h-full rounded-full transition-all"
                                                                style={{
                                                                    width: `${resource.disk_percent || 0}%`,
                                                                    background: (resource.disk_percent || 0) < 75 ? '#22c55e' : (resource.disk_percent || 0) < 90 ? '#eab308' : '#ef4444'
                                                                }}
                                                            />
                                                        </div>
                                                    </div>
                                                )}
                                                <span className="text-xs text-gray-400 font-mono whitespace-nowrap">
                                                    {resource.disk > 0 ? `${formatBytes(resource.disk)} / ${formatBytes(resource.maxdisk || 0)}` : formatBytes(resource.maxdisk || 0)}
                                                </span>
                                            </div>
                                        </td>
                                        <td className="px-4 py-3">
                                            <span className={`inline-flex items-center gap-1.5 px-2 py-1 rounded-md text-xs font-medium ${resource.status === 'running'
                                                ? 'bg-green-500/10 text-green-400 border border-green-500/20'
                                                : resource.status === 'stopped'
                                                    ? 'bg-red-500/10 text-red-400 border border-red-500/20'
                                                    : 'bg-gray-500/10 text-gray-400 border border-gray-500/20'
                                                }`}>
                                                <span className={`w-1.5 h-1.5 rounded-full ${resource.status === 'running' ? 'bg-green-400' : 'bg-red-400'
                                                    }`} />
                                                {resource.status}
                                            </span>
                                        </td>
                                        <td className="px-4 py-3" style={{ whiteSpace: 'nowrap' }}>
                                            {isCorporate ? (
                                                <div className="flex items-center gap-0">
                                                    {getProxmoxObjectUrl(getVmProxmoxTarget(resource)) && (
                                                        <>
                                                            <button onClick={() => openProxmoxObject(getVmProxmoxTarget(resource))} className="corp-action-btn" title={t('openInProxmox')}><Icons.ExternalLink className="w-3.5 h-3.5" /></button>
                                                            <span className="corp-toolbar-divider" style={{ margin: '0 3px' }} />
                                                        </>
                                                    )}
                                                    {/* power group */}
                                                    <div className="corp-action-group">
                                                        {resource.status === 'stopped' ? (
                                                            <button onClick={() => handleAction(resource, 'start')} disabled={actionLoading[`${resource.vmid}-start`]} className="corp-action-btn" title={t('start')}>
                                                                {actionLoading[`${resource.vmid}-start`] ? <Icons.RotateCw className="w-3.5 h-3.5 animate-spin" /> : <Icons.PlayCircle className="w-3.5 h-3.5" />}
                                                            </button>
                                                        ) : (
                                                            <>
                                                                <button onClick={() => handleAction(resource, 'shutdown')} disabled={actionLoading[`${resource.vmid}-shutdown`]} className="corp-action-btn" title={t('shutdown')}>
                                                                    {actionLoading[`${resource.vmid}-shutdown`] ? <Icons.RotateCw className="w-3.5 h-3.5 animate-spin" /> : <Icons.Power className="w-3.5 h-3.5" />}
                                                                </button>
                                                                <button onClick={() => handleAction(resource, 'reboot')} disabled={actionLoading[`${resource.vmid}-reboot`]} className="corp-action-btn" title={t('reboot')}>
                                                                    {actionLoading[`${resource.vmid}-reboot`] ? <Icons.RotateCw className="w-3.5 h-3.5 animate-spin" /> : <Icons.RefreshCw className="w-3.5 h-3.5" />}
                                                                </button>
                                                            </>
                                                        )}
                                                    </div>
                                                    <span className="corp-toolbar-divider" style={{ margin: '0 3px' }} />
                                                    {/* management group */}
                                                    <div className="corp-action-group">
                                                        {resource.status === 'running' && (
                                                            <button onClick={() => onOpenConsole(resource)} className="corp-action-btn" title={t('openConsole')}><Icons.Monitor className="w-3.5 h-3.5" /></button>
                                                        )}
                                                        <button onClick={() => onOpenConfig(resource)} className="corp-action-btn" title={t('configuration')}><Icons.Cog className="w-3.5 h-3.5" /></button>
                                                        <button onClick={() => setShowMigrateModal(resource)} className="corp-action-btn" title={t('migrate')}><Icons.ArrowRight className="w-3.5 h-3.5" /></button>
                                                        <button onClick={() => setShowCloneModal(resource)} className="corp-action-btn" title={t('clone')}><Icons.Copy className="w-3.5 h-3.5" /></button>
                                                    </div>
                                                    <span className="corp-toolbar-divider" style={{ margin: '0 3px' }} />
                                                    <button onClick={() => setShowDeleteConfirm(resource)} className="corp-action-btn danger" title={t('delete')}><Icons.Trash className="w-3.5 h-3.5" /></button>
                                                </div>
                                            ) : (
                                                <div className="flex items-center gap-1">
                                                    {getProxmoxObjectUrl(getVmProxmoxTarget(resource)) && (
                                                        <button
                                                            onClick={() => openProxmoxObject(getVmProxmoxTarget(resource))}
                                                            className="p-1.5 rounded-lg bg-proxmox-dark hover:bg-cyan-500/20 text-gray-400 hover:text-cyan-400 transition-all"
                                                            title={t('openInProxmox')}
                                                        >
                                                            <Icons.ExternalLink />
                                                        </button>
                                                    )}
                                                    <button
                                                        onClick={() => onOpenConfig(resource)}
                                                        className="p-1.5 rounded-lg bg-proxmox-dark hover:bg-purple-500/20 text-gray-400 hover:text-purple-400 transition-all"
                                                        title={t('configuration')}
                                                    >
                                                        <Icons.Cog />
                                                    </button>
                                                    <button
                                                        onClick={() => onOpenTags && onOpenTags(resource)}
                                                        className="p-1.5 rounded-lg bg-proxmox-dark hover:bg-yellow-500/20 text-gray-400 hover:text-yellow-400 transition-all"
                                                        title={t('tags')}
                                                    >
                                                        <Icons.Tag />
                                                    </button>
                                                    <button
                                                        onClick={() => setShowMetricsModal(resource)}
                                                        className="p-1.5 rounded-lg bg-proxmox-dark hover:bg-blue-500/20 text-gray-400 hover:text-blue-400 transition-all"
                                                        title={t('metrics')}
                                                    >
                                                        <Icons.BarChart />
                                                    </button>
                                                    <button
                                                        onClick={() => setShowMigrateModal(resource)}
                                                        className="p-1.5 rounded-lg bg-proxmox-dark hover:bg-cyan-500/20 text-gray-400 hover:text-cyan-400 transition-all"
                                                        title={t('migrate')}
                                                    >
                                                        <Icons.ArrowRight />
                                                    </button>
                                                    {clusters && clusters.length > 1 && (
                                                        <button
                                                            onClick={() => setShowCrossClusterMigrate(resource)}
                                                            className="p-1.5 rounded-lg bg-proxmox-dark hover:bg-emerald-500/20 text-gray-400 hover:text-emerald-400 transition-all"
                                                            title={t('crossClusterMigrate')}
                                                        >
                                                            <Icons.Globe />
                                                        </button>
                                                    )}
                                                    {resource.status === 'running' && (
                                                        <button
                                                            onClick={() => onOpenConsole(resource)}
                                                            className="p-1.5 rounded-lg bg-proxmox-dark hover:bg-blue-500/20 text-gray-400 hover:text-blue-400 transition-all"
                                                            title={t('openConsole')}
                                                        >
                                                            <Icons.Monitor />
                                                        </button>
                                                    )}
                                                    {resource.status === 'stopped' ? (
                                                        <button
                                                            onClick={() => handleAction(resource, 'start')}
                                                            disabled={actionLoading[`${resource.vmid}-start`]}
                                                            className="p-1.5 rounded-lg bg-proxmox-dark hover:bg-green-500/20 text-gray-400 hover:text-green-400 transition-all disabled:opacity-50"
                                                            title={t('start')}
                                                        >
                                                            {actionLoading[`${resource.vmid}-start`] ? <Icons.RotateCw className="w-4 h-4 animate-spin" /> : <Icons.PlayCircle />}
                                                        </button>
                                                    ) : (
                                                        <>
                                                            <button
                                                                onClick={() => handleAction(resource, 'shutdown')}
                                                                disabled={actionLoading[`${resource.vmid}-shutdown`]}
                                                                className="p-1.5 rounded-lg bg-proxmox-dark hover:bg-yellow-500/20 text-gray-400 hover:text-yellow-400 transition-all disabled:opacity-50"
                                                                title={t('shutdown')}
                                                            >
                                                                {actionLoading[`${resource.vmid}-shutdown`] ? <Icons.RotateCw className="w-4 h-4 animate-spin" /> : <Icons.Power />}
                                                            </button>
                                                            <button
                                                                onClick={() => onForceStop(resource)}
                                                                disabled={actionLoading[`${resource.vmid}-stop`]}
                                                                className="p-1.5 rounded-lg bg-proxmox-dark hover:bg-red-500/20 text-gray-400 hover:text-red-400 transition-all disabled:opacity-50"
                                                                title={t('forceStop')}
                                                            >
                                                                {actionLoading[`${resource.vmid}-stop`] ? <Icons.RotateCw className="w-4 h-4 animate-spin" /> : <Icons.XCircle />}
                                                            </button>
                                                            <button
                                                                onClick={() => handleAction(resource, 'reboot')}
                                                                disabled={actionLoading[`${resource.vmid}-reboot`]}
                                                                className="p-1.5 rounded-lg bg-proxmox-dark hover:bg-orange-500/20 text-gray-400 hover:text-orange-400 transition-all disabled:opacity-50"
                                                                title={t('reboot')}
                                                            >
                                                                {actionLoading[`${resource.vmid}-reboot`] ? <Icons.RotateCw className="w-4 h-4 animate-spin" /> : <Icons.RefreshCw />}
                                                            </button>
                                                            {resource.type === 'qemu' && (
                                                                <button
                                                                    onClick={() => handleAction(resource, 'reset')}
                                                                    disabled={actionLoading[`${resource.vmid}-reset`]}
                                                                    className="p-1.5 rounded-lg bg-proxmox-dark hover:bg-orange-500/20 text-gray-400 hover:text-orange-400 transition-all disabled:opacity-50"
                                                                    title={t('forceReset')}
                                                                >
                                                                    {actionLoading[`${resource.vmid}-reset`] ? <Icons.RotateCw className="w-4 h-4 animate-spin" /> : <Icons.Zap />}
                                                                </button>
                                                            )}
                                                        </>
                                                    )}
                                                    <button
                                                        onClick={() => setShowCloneModal(resource)}
                                                        className="p-1.5 rounded-lg bg-proxmox-dark hover:bg-blue-500/20 text-gray-400 hover:text-blue-400 transition-all"
                                                        title={t('clone')}
                                                    >
                                                        <Icons.Copy />
                                                    </button>
                                                    <button
                                                        onClick={() => setShowDeleteConfirm(resource)}
                                                        className="p-1.5 rounded-lg bg-proxmox-dark hover:bg-red-500/20 text-gray-400 hover:text-red-400 transition-all"
                                                        title={t('delete')}
                                                    >
                                                        <Icons.Trash />
                                                    </button>
                                                </div>
                                            )}
                                        </td>
                                    </tr>
                                ))
                            )}
                        </tbody>
                    </table>
                </div>
            )}

            {/* Detail View - Split Panel */}
            {viewMode === 'detail' && (
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
                    {/* VM List — 2026-04-24: viewport-proportional height so it
                                matches the detail panel on the right and never exceeds the
                                visible area. Header + list scroll independently. */}
                    <div className="lg:col-span-1 bg-proxmox-card border border-proxmox-border rounded-xl overflow-hidden flex flex-col"
                        style={{ maxHeight: 'calc(100vh - 260px)', minHeight: '400px' }}>
                        <div className={isCorporate ? 'corp-card-header flex-shrink-0' : "p-3 border-b border-proxmox-border bg-proxmox-dark/50 flex-shrink-0"}>
                            <h3 className="text-sm font-medium text-gray-300">VMs & Container ({filteredResources.length})</h3>
                        </div>
                        <div className="flex-1 overflow-y-auto" style={{ scrollbarWidth: 'thin' }}>
                            {paginatedResources.map(resource => (
                                <div
                                    key={resource.vmid}
                                    onClick={() => setSelectedDetailVm(resource)}
                                    className={`flex items-center gap-3 p-3 cursor-pointer transition-all border-b border-gray-700/50 ${selectedDetailVm?.vmid === resource.vmid
                                        ? 'bg-proxmox-orange/10 border-l-2 border-l-proxmox-orange'
                                        : 'hover:bg-proxmox-dark/50'
                                        }`}
                                >
                                    <div
                                        className={`p-1.5 rounded ${isGuestTemplate(resource) ? 'bg-gray-300/50 text-gray-800 border border-gray-400/50' : resource.type === 'qemu' ? 'bg-blue-500/10' : 'bg-purple-500/10'}`}
                                        title={getGuestTypeTitle(resource, t)}
                                    >
                                        {getGuestTypeIcon(resource)}
                                    </div>
                                    <div className="flex-1 min-w-0">
                                        <div className="font-medium text-white text-sm truncate">
                                            {resource.name || `${resource.type === 'qemu' ? 'VM' : 'CT'} ${resource.vmid}`}
                                        </div>
                                        <div className="text-xs text-gray-500">ID: {resource.vmid} · {resource.node}</div>
                                        <div className="flex flex-wrap gap-1 mt-1 items-center">
                                            {/* Backup status pill (mobile stack layout) */}
                                            {backupStatus && backupStatus[resource.vmid] && window.ProxmoxVExBackupStatusPill && React.createElement(window.ProxmoxVExBackupStatusPill, {
                                                status: backupStatus[resource.vmid].status,
                                                lastAgeHours: backupStatus[resource.vmid].last_backup_age_hours,
                                                encrypted: backupStatus[resource.vmid].encrypted,
                                                verifyAgeHours: backupStatus[resource.vmid].last_verify_age_hours,
                                                count30d: backupStatus[resource.vmid].count_30d,
                                            })}
                                            {resource.tags && (Array.isArray(resource.tags) ? resource.tags : resource.tags.split(';')).filter(t => t.trim()).slice(0, 2).map((tag, i) => (
                                                <span key={i} className="px-1 py-0.5 text-xs rounded bg-proxmox-orange/20 text-proxmox-orange">
                                                    {tag.trim()}
                                                </span>
                                            ))}
                                            {resource.tags && (Array.isArray(resource.tags) ? resource.tags : resource.tags.split(';')).filter(t => t.trim()).length > 2 && (
                                                <span className="px-1 py-0.5 text-xs rounded bg-gray-500/20 text-gray-400">
                                                    +{(Array.isArray(resource.tags) ? resource.tags : resource.tags.split(';')).filter(t => t.trim()).length - 2}
                                                </span>
                                            )}
                                        </div>
                                    </div>
                                    {getProxmoxObjectUrl(getVmProxmoxTarget(resource)) && (
                                        <button
                                            onClick={(e) => {
                                                e.stopPropagation();
                                                openProxmoxObject(getVmProxmoxTarget(resource));
                                            }}
                                            className="p-1.5 rounded-lg text-gray-500 hover:text-cyan-400 hover:bg-cyan-500/10 transition-all"
                                            title={t('openInProxmox')}
                                        >
                                            <Icons.ExternalLink className="w-4 h-4" />
                                        </button>
                                    )}
                                    <span className={`w-2 h-2 rounded-full ${resource.status === 'running' ? 'bg-green-500' : 'bg-red-500'
                                        }`} />
                                </div>
                            ))}
                        </div>
                    </div>

                    {/* Detail Panel */}
                    <div className="lg:col-span-2">
                        {selectedDetailVm ? (
                            <VmDetailPanel
                                vm={selectedDetailVm}
                                clusterId={clusterId}
                                onAction={handleAction}
                                onOpenConsole={onOpenConsole}
                                onOpenConfig={onOpenConfig}
                                onMigrate={() => setShowMigrateModal(selectedDetailVm)}
                                onClone={() => setShowCloneModal(selectedDetailVm)}
                                onForceStop={onForceStop}
                                onDelete={() => setShowDeleteConfirm(selectedDetailVm)}
                                onCrossClusterMigrate={(vm) => setShowCrossClusterMigrate(vm)}
                                showCrossCluster={clusters && clusters.length > 1}
                                actionLoading={actionLoading}
                                onShowMetrics={(vm) => setShowMetricsModal(vm)}
                                addToast={addToast}
                            />
                        ) : (
                            <div className="h-full flex items-center justify-center bg-proxmox-card border border-proxmox-border rounded-xl p-12">
                                <div className="text-center text-gray-500">
                                    <Icons.Eye />
                                    <p className="mt-2">{t('selectVmFromList')}</p>
                                </div>
                            </div>
                        )}
                    </div>
                </div>
            )}

            {/* Pagination Controls - */}
            <div className="flex flex-wrap items-center justify-between gap-4 text-sm text-gray-400 py-2">
                <div className="flex items-center gap-4">
                    <span>
                        {t('showing')} {((effectivePage - 1) * itemsPerPage) + 1}-{Math.min(effectivePage * itemsPerPage, filteredResources.length)} {t('of')} {filteredResources.length} {t('resources')}
                        {filteredResources.length !== resources.length && ` (${resources.length} ${t('total')})`}
                    </span>
                    <div className="flex items-center gap-2">
                        <span className="text-gray-500">{t('perPage')}:</span>
                        <select
                            value={itemsPerPage}
                            onChange={(e) => setItemsPerPage(Number(e.target.value))}
                            className={isCorporate ? 'corp-input' : "bg-proxmox-dark border border-proxmox-border rounded px-2 py-1 text-sm"}
                        >
                            <option value={50}>50</option>
                            <option value={100}>100</option>
                            <option value={200}>200</option>
                            <option value={500}>500</option>
                        </select>
                    </div>
                </div>

                {totalPages > 1 && (
                    <div className="flex items-center gap-1">
                        <button
                            onClick={() => setCurrentPage(1)}
                            disabled={effectivePage === 1}
                            className="px-2 py-1 rounded bg-proxmox-dark border border-proxmox-border disabled:opacity-30 hover:bg-proxmox-hover disabled:hover:bg-proxmox-dark"
                            title="First page"
                        >
                            ««
                        </button>
                        <button
                            onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
                            disabled={effectivePage === 1}
                            className="px-2 py-1 rounded bg-proxmox-dark border border-proxmox-border disabled:opacity-30 hover:bg-proxmox-hover disabled:hover:bg-proxmox-dark"
                        >
                            «
                        </button>

                        {/* Page numbers */}
                        {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
                            let pageNum;
                            if (totalPages <= 5) {
                                pageNum = i + 1;
                            } else if (effectivePage <= 3) {
                                pageNum = i + 1;
                            } else if (effectivePage >= totalPages - 2) {
                                pageNum = totalPages - 4 + i;
                            } else {
                                pageNum = effectivePage - 2 + i;
                            }
                            return (
                                <button
                                    key={pageNum}
                                    onClick={() => setCurrentPage(pageNum)}
                                    className={`px-3 py-1 rounded border ${effectivePage === pageNum
                                        ? 'bg-proxmox-orange text-white border-proxmox-orange'
                                        : 'bg-proxmox-dark border-proxmox-border hover:bg-proxmox-hover'
                                        }`}
                                >
                                    {pageNum}
                                </button>
                            );
                        })}

                        <button
                            onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
                            disabled={effectivePage === totalPages}
                            className="px-2 py-1 rounded bg-proxmox-dark border border-proxmox-border disabled:opacity-30 hover:bg-proxmox-hover disabled:hover:bg-proxmox-dark"
                        >
                            »
                        </button>
                        <button
                            onClick={() => setCurrentPage(totalPages)}
                            disabled={effectivePage === totalPages}
                            className="px-2 py-1 rounded bg-proxmox-dark border border-proxmox-border disabled:opacity-30 hover:bg-proxmox-hover disabled:hover:bg-proxmox-dark"
                            title="Last page"
                        >
                            »»
                        </button>
                    </div>
                )}

                <span className="text-gray-500">{Object.keys(groupedByNode).length} Nodes</span>
            </div>

            {/* Delete Confirmation Modal */}
            {showDeleteConfirm && (
                <DeleteVmModal
                    vm={showDeleteConfirm}
                    clusterId={clusterId}
                    onDelete={onDelete}
                    onClose={() => setShowDeleteConfirm(null)}
                />
            )}

            {/* Clone VM Modal */}
            {showCloneModal && (
                <CloneVmModal
                    vm={showCloneModal}
                    nodes={nodes}
                    clusterId={clusterId}
                    onClone={onClone}
                    onClose={() => setShowCloneModal(null)}
                />
            )}

            {/* Single VM Migrate Modal */}
            {showMigrateModal && (
                <MigrateModal
                    vm={showMigrateModal}
                    nodes={nodes}
                    clusterId={clusterId}
                    onMigrate={onMigrate}
                    onClose={() => setShowMigrateModal(null)}
                />
            )}

            {/* Bulk Migrate Modal */}
            {showBulkMigrate && (
                <BulkMigrateModal
                    vms={selectedVms}
                    nodes={nodes}
                    clusterId={clusterId}
                    onMigrate={onBulkMigrate}
                    onClose={() => {
                        setShowBulkMigrate(false);
                        setSelectedVms([]);
                    }}
                />
            )}

            {/* Cross-Cluster Migrate Modal */}
            {showCrossClusterMigrate && clusters && clusters.length > 1 && (
                <CrossClusterMigrateModal
                    vm={showCrossClusterMigrate}
                    sourceCluster={sourceCluster}
                    clusters={clusters}
                    onMigrate={onCrossClusterMigrate}
                    onClose={() => setShowCrossClusterMigrate(null)}
                />
            )}

            {/* VM Metrics Modal */}
            {showMetricsModal && (
                <VmMetricsModal
                    vm={showMetricsModal}
                    clusterId={clusterId}
                    onClose={() => setShowMetricsModal(null)}
                />
            )}
        </div>
    );
}

// 014-color-coded-status-for-dashboard: shared status badge color helper
function getStatusColor(status) {
    const map = {
        ok: 'bg-green-500/15 text-green-400',
        success: 'bg-green-500/15 text-green-400',
        running: 'bg-green-500/15 text-green-400',
        active: 'bg-green-500/15 text-green-400',
        failed: 'bg-red-500/15 text-red-400',
        error: 'bg-red-500/15 text-red-400',
        stopped: 'bg-red-500/15 text-red-400',
        never: 'bg-gray-500/15 text-gray-400',
        unknown: 'bg-gray-500/15 text-gray-400',
        warning: 'bg-yellow-500/15 text-yellow-400',
        pending: 'bg-yellow-500/15 text-yellow-400',
    };
    return map[status] || map['unknown'];
}

// TaskLogColorTheme: dark-mode wrapper for the Task Log page.
function TaskLogColorTheme({ children, dark }) {
    return (
        <div className={dark ? 'dark bg-proxmox-dark text-proxmox-text' : 'bg-white text-gray-900'}>
            {children}
        </div>
    );
}

// TaskLogCompactGrid: compact density table wrapper for the Task Log page.
function TaskLogCompactGrid({ children, compact }) {
    return (
        <div className={compact ? 'text-xs leading-tight' : 'text-sm leading-normal'}>
            {children}
        </div>
    );
}

// TaskLogResizablePanels: resizable layout wrapper for the Task Log page.
function TaskLogResizablePanels({ children, resizable }) {
    return (
        <div className={resizable ? 'w-1/3 overflow-auto resize-x' : 'w-full'}>
            {children}
        </div>
    );
}

// TaskLogColorCodedStatus: status badge wrapper for the Task Log page.
function TaskLogColorCodedStatus({ children, status }) {
    const colorClass = status === 'error' ? 'text-red-400' : status === 'success' ? 'text-green-400' : 'text-yellow-400';
    return (
        <span className={`inline-flex items-center px-2 py-1 rounded text-xs font-medium ${colorClass}`}>
            {children}
        </span>
    );
}

// TaskLogHoverCards: hover card wrapper for the Task Log page.
function TaskLogHoverCards({ children, hover }) {
    return (
        <div className={hover ? 'group relative p-3 bg-proxmox-card border border-proxmox-border rounded-lg shadow-lg' : 'p-3'}>
            {children}
            {hover && (
                <div className="absolute z-10 hidden group-hover:block p-2 mt-1 text-sm text-white bg-proxmox-dark border border-proxmox-border rounded-lg">
                    {children}
                </div>
            )}
        </div>
    );
}

// TaskLogBreadcrumbBar: breadcrumb navigation for the Task Log page.
function TaskLogBreadcrumbBar({ items }) {
    return (
        <nav className="flex items-center space-x-2 text-sm text-proxmox-textMuted py-2">
            {items.map((item, index) => (
                <React.Fragment key={index}>
                    <span className={index === items.length - 1 ? 'text-white font-medium' : 'hover:text-white'}>
                        {item}
                    </span>
                    {index < items.length - 1 && <span>/</span>}
                </React.Fragment>
            ))}
        </nav>
    );
}

// TaskLogCustomizableColumns: column picker for the Task Log page.
function TaskLogCustomizableColumns({ columns, visible, onToggle }) {
    return (
        <div className="p-2 bg-proxmox-card border border-proxmox-border rounded-lg">
            {columns.map((col) => (
                <label key={col} className="flex items-center space-x-2 p-1 text-sm text-white cursor-pointer hover:bg-proxmox-hover rounded">
                    <input type="checkbox" checked={visible.includes(col)} onChange={() => onToggle(col)} className="form-checkbox" />
                    <span>{col}</span>
                </label>
            ))}
        </div>
    );
}

// TaskLogDragAndDrop: drag handle for reordering the Task Log page.
function TaskLogDragAndDrop({ children, onDragEnd }) {
    return (
        <div className="cursor-move p-1 text-gray-400 hover:text-white" draggable onDragEnd={onDragEnd}>
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 8h16M4 16h16" />
            </svg>
            {children}
        </div>
    );
}

// TaskLogFilterSidebar: filter sidebar for the Task Log page.
function TaskLogFilterSidebar({ filters, onChange }) {
    return (
        <aside className="w-64 p-4 bg-proxmox-card border-r border-proxmox-border">
            <h3 className="text-sm font-medium text-white mb-3">Filters</h3>
            {filters.map((filter) => (
                <div key={filter.key} className="mb-2">
                    <label className="text-xs text-proxmox-textMuted">{filter.label}</label>
                    <input type="text" value={filter.value} onChange={(e) => onChange(filter.key, e.target.value)} className="w-full mt-1 px-2 py-1 text-sm text-white bg-proxmox-dark border border-proxmox-border rounded" />
                </div>
            ))}
        </aside>
    );
}

// TaskLogKeyboardShortcuts: keyboard shortcut hints for the Task Log page.
function TaskLogKeyboardShortcuts({ shortcuts }) {
    return (
        <div className="p-2 bg-proxmox-card border border-proxmox-border rounded-lg text-sm text-white">
            <h4 className="font-medium mb-2">Keyboard Shortcuts</h4>
            <ul className="space-y-1">
                {shortcuts.map((shortcut) => (
                    <li key={shortcut.key} className="flex justify-between">
                        <span className="text-proxmox-textMuted">{shortcut.action}</span>
                        <kbd className="px-1 bg-proxmox-dark border border-proxmox-border rounded font-mono text-xs">{shortcut.key}</kbd>
                    </li>
                ))}
            </ul>
        </div>
    );
}

// BackupJobsStatusBadge: color-coded status badge for backup job rows.
// 923-color-coded-status-for-backup-jobs: maps a status value to a semantic Tailwind badge.
function BackupJobsStatusBadge({ status }) {
    const { t } = useTranslation();
    const s = (status || 'idle').toLowerCase();
    const variants = {
        idle: 'bg-gray-500/20 text-gray-400 border-gray-500/20',
        success: 'bg-green-500/20 text-green-400 border-green-500/20',
        warning: 'bg-yellow-500/20 text-yellow-400 border-yellow-500/20',
        error: 'bg-red-500/20 text-red-400 border-red-500/20',
    };
    const cls = variants[s] || variants.idle;
    const label = t(s, { defaultValue: s });
    return (
        <span className={`inline-flex items-center px-2 py-0.5 rounded text-xs font-medium border ${cls}`} data-testid="backup-jobs-status-badge">
            {label}
        </span>
    );
}

// BackupJobsCompactGrid: shared compact/expanded table-density wrapper for the Backup Jobs page.
// 921-compact-grid-for-backup-jobs: toggles the `.compact` class on child tables to reduce cell padding and font size.
function BackupJobsCompactGrid({ compact, onToggle, children }) {
    const { t } = useTranslation();
    return (
        <div className={`backup-jobs-grid ${compact ? 'compact' : ''}`} data-testid="backup-jobs-compact-grid">
            {children}
        </div>
    );
}

// BackupJobsColumnPicker: column visibility picker for the Backup Jobs page.
// 926-customizable-columns-for-backup-jobs: lets operators show/hide backup job table columns.
function BackupJobsColumnPicker({ columns = [], visible = [], onChange }) {
    const { t } = useTranslation();
    const toggle = (key) => {
        const next = visible.includes(key)
            ? visible.filter(k => k !== key)
            : [...visible, key];
        onChange?.(next);
    };
    return (
        <div className="p-2 border border-proxmox-border rounded bg-proxmox-card mb-4" data-testid="backup-jobs-column-picker">
            <div className="text-sm font-medium mb-2 text-white">{t('columns')}</div>
            <div className="flex flex-wrap gap-3">
                {columns.map((col) => (
                    <label key={col.key} className="flex items-center gap-2 text-sm text-proxmox-textMuted cursor-pointer">
                        <input
                            type="checkbox"
                            checked={visible.includes(col.key)}
                            onChange={() => toggle(col.key)}
                            className="rounded"
                        />
                        {col.label}
                    </label>
                ))}
            </div>
        </div>
    );
}

// BackupJobsDragHandle: visual drag handle for reordering backup job rows.
// 927-drag-and-drop-reordering-for-backup-jobs: lets operators reorder backup jobs.
function BackupJobsDragHandle() {
    return (
        <span className="backup-jobs-drag-handle" data-testid="backup-jobs-drag-handle" aria-hidden="true">
            ⋮⋮
        </span>
    );
}
