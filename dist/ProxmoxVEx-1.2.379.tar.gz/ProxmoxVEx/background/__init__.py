# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/background/__init__.py
# Project:     ProxmoxVEx
# Version:     1.2.378
# Build:       2026.09.04
# Description: Package initializer for background
# Docs:        https://proxmoxvex.local/docs
# Generated:   2026-09-04
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
