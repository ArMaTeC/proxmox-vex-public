# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/plugins/__init__.py
# Project:     ProxmoxVEx
# Version:     1.2.437
# Build:       2026.09.12
# Description: Plugin loading helpers with license tier enforcement.
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-12
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Plugin loading helpers with license tier enforcement."""

from ProxmoxVEx.core.db import get_db
from ProxmoxVEx.services.licensing import LicensingService


def can_use_plugin(plugin_slug: str) -> bool:
    """Return whether the active license allows this plugin."""
    return LicensingService().can_use_plugin(get_db(), plugin_slug)
