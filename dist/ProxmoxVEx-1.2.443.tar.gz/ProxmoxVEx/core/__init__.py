# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/core/__init__.py
# Project:     ProxmoxVEx
# Version:     1.2.437
# Build:       2026.09.12
# Description: Package initializer for core
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-12
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
