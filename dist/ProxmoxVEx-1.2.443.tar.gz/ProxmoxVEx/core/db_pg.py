# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/core/db_pg.py
# Project:     ProxmoxVEx
# Version:     1.2.437
# Build:       2026.09.12
# Description: PostgreSQL backend connection and SQLite -> Postgres...
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-12
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""PostgreSQL backend connection and SQLite -> Postgres SQL translator.

This module provides a psycopg2-based connection with a cursor that
heuristically translates the raw SQLite SQL emitted by `ProxmoxVExDB`
so the same method body can run against a migrated PostgreSQL database.
"""

import contextlib
import logging
import os
import re
from typing import Any, Dict, List, Optional, Tuple, cast

import psycopg2
import psycopg2.extras


def _pg_dsn() -> str:
    """Return the PostgreSQL DSN from env or the local default."""
    return os.environ.get(
        "PROXMOXVEX_DATABASE_URL",
        f"postgresql://{os.environ.get('PGUSER', 'proxmoxvex')}:{os.environ.get('PGPASSWORD', 'proxmoxvex')}"
        f"@{os.environ.get('PGHOST', 'localhost')}:{os.environ.get('PGPORT', '5432')}"
        f"/{os.environ.get('PGDATABASE', 'proxmoxvex')}",
    )


def _quote(name: str) -> str:
    q = '"'
    return q + name.replace(q, q + q) + q


def _find_balanced_paren(text: str, open_idx: int) -> int:
    """Return the index of the closing parenthesis matching the one at open_idx."""
    depth = 0
    i = open_idx
    while i < len(text):
        if text[i] == "(":
            depth += 1
        elif text[i] == ")":
            depth -= 1
            if depth == 0:
                return i
        i += 1
    return -1


def _sqlite_placeholders_to_pg(sql: str) -> str:
    """ISS-072: convert SQLite ``?`` placeholders to ``%s`` without corrupting
    literals. The previous blanket ``sql.replace("?", "%s")`` also rewrote ``?``
    inside single-quoted strings ('%?%'), line/block comments, and
    double-quoted identifiers, producing invalid PostgreSQL or silently
    changing stored values."""
    out = []
    i, n = 0, len(sql)
    in_squote = in_dquote = False
    in_line_comment = in_block_comment = False
    while i < n:
        ch = sql[i]
        nxt = sql[i + 1] if i + 1 < n else ""
        if in_line_comment:
            out.append(ch)
            if ch == "\n":
                in_line_comment = False
            i += 1
            continue
        if in_block_comment:
            out.append(ch)
            if ch == "*" and nxt == "/":
                out.append("/")
                i += 2
                in_block_comment = False
                continue
            i += 1
            continue
        if in_squote:
            out.append(ch)
            if ch == "'":
                if nxt == "'":  # '' escape stays inside the literal
                    out.append("'")
                    i += 2
                    continue
                in_squote = False
            i += 1
            continue
        if in_dquote:
            out.append(ch)
            if ch == '"':
                in_dquote = False
            i += 1
            continue
        if ch == "'":
            in_squote = True
        elif ch == '"':
            in_dquote = True
        elif ch == "-" and nxt == "-":
            in_line_comment = True
        elif ch == "/" and nxt == "*":
            out.append(ch)
            out.append("*")
            in_block_comment = True
            i += 2
            continue
        elif ch == "?":
            out.append("%s")
            i += 1
            continue
        out.append(ch)
        i += 1
    return "".join(out)


class _Cursor(psycopg2.extras.DictCursor):
    """Inner cursor factory used by the PG connection."""


class PGConnection:
    """Lightweight psycopg2 wrapper that exposes a custom translation cursor."""

    def __init__(self, dsn: str):
        self._dsn = dsn
        self._raw = psycopg2.connect(dsn)
        self._raw.set_session(autocommit=False)
        self._schema_cache: Dict[str, Dict[str, Any]] = {}

    @property
    def dsn(self) -> str:
        return self._dsn

    def _get_table_constraints(self, table: str) -> List[List[str]]:
        """Return a list of unique/PK constraints, each as an ordered list of column names."""
        if "constraints" not in self._schema_cache:
            self._schema_cache["constraints"] = {}
        if table in self._schema_cache["constraints"]:
            return self._schema_cache["constraints"][table]

        constraints: Dict[str, List[str]] = {}
        try:
            with self._raw.cursor() as cur:
                cur.execute(
                    """
                    SELECT c.relname, i.indexrelid, i.indisprimary, a.attname,
                           array_position(i.indkey, a.attnum) AS pos
                    FROM pg_index i
                    JOIN pg_class c ON c.oid = i.indrelid
                    JOIN pg_namespace n ON n.oid = c.relnamespace
                    JOIN pg_attribute a ON a.attrelid = i.indrelid AND a.attnum = ANY(i.indkey)
                    WHERE n.nspname = 'public' AND c.relname = %s AND (i.indisprimary OR i.indisunique)
                    ORDER BY i.indexrelid, array_position(i.indkey, a.attnum)
                    """,
                    (table,),
                )
                for row in cur.fetchall():
                    _table, idx, _is_pk, col, _pos = row
                    constraints.setdefault(idx, []).append(col)
        except psycopg2.Error as e:
            logging.warning(f"[PGConnection] constraints lookup for {table} failed: {e}")

        result = list(constraints.values())
        self._schema_cache["constraints"][table] = result
        return result

    def _get_table_info(self, table: str) -> List[Tuple[Any, ...]]:
        """Return rows that mimic SQLite's `PRAGMA table_info(table)`."""
        try:
            with self._raw.cursor(cursor_factory=_Cursor) as cur:
                cur.execute(
                    """
                    SELECT
                        c.ordinal_position - 1,
                        c.column_name AS name,
                        c.data_type AS type,
                        CASE WHEN c.is_nullable = 'NO' THEN 1 ELSE 0 END AS notnull,
                        c.column_default AS dflt_value,
                        CASE WHEN kcu.column_name IS NOT NULL AND tc.constraint_type = 'PRIMARY KEY' THEN 1 ELSE 0 END AS pk
                    FROM information_schema.columns c
                    LEFT JOIN information_schema.key_column_usage kcu
                        ON c.table_name = kcu.table_name
                        AND c.column_name = kcu.column_name
                        AND c.table_schema = kcu.table_schema
                    LEFT JOIN information_schema.table_constraints tc
                        ON kcu.constraint_name = tc.constraint_name
                        AND kcu.table_schema = tc.table_schema
                    WHERE c.table_schema = 'public' AND c.table_name = %s
                    ORDER BY c.ordinal_position
                    """,
                    (table,),
                )
                return cur.fetchall()
        except psycopg2.Error as e:
            logging.warning(f"[PGConnection] table_info for {table} failed: {e}")
            return []

    def cursor(self) -> "PGCursor":
        return PGCursor(self)

    def execute(self, sql: str, params=None):
        """Convenience cursor executor matching sqlite3.Connection.execute()."""
        cur = self.cursor()
        cur.execute(sql, params)
        return cur

    def executemany(self, sql: str, params_list):
        """Convenience executemany matching sqlite3.Connection.executemany()."""
        cur = self.cursor()
        cur.executemany(sql, params_list)
        return cur

    def commit(self):
        self._raw.commit()

    def rollback(self):
        self._raw.rollback()

    def close(self):
        self._raw.close()


class PGCursor:
    """Cursor that translates SQLite-flavoured SQL to PostgreSQL on the fly."""

    def __init__(self, connection: PGConnection):
        self._connection = connection
        self._inner = connection._raw.cursor(cursor_factory=_Cursor)
        self._lastrowid = 0
        self._pending_table_info: Optional[List[Tuple[Any, ...]]] = None
        self.row_factory = None

    # ------------------------------------------------------------------
    # SQL translation helpers
    # ------------------------------------------------------------------
    def _translate(self, sql: str) -> str:
        # Remove full-line SQL comments so statement detectors (e.g. CREATE TABLE)
        # can see the real first keyword even when schema files prepend -- comments.
        sql = re.sub(r"^\s*--[^\n]*$", "", sql, flags=re.MULTILINE)
        sql = re.sub(r"/\*.*?\*/", "", sql, flags=re.DOTALL)
        sql = sql.strip()

        # 1. PRAGMA table_info -> information_schema emulation
        m = re.match(r"PRAGMA\s+table_info\s*\(\s*([^)]+)\s*\)", sql, re.IGNORECASE)
        if m:
            self._pending_table_info = self._connection._get_table_info(m.group(1).strip().strip('"'))
            # Return a dummy SELECT that fetchall will intercept
            return "SELECT 1 WHERE FALSE"

        # 2. last_insert_rowid -> lastval
        sql = re.sub(
            r"\bSELECT\s+last_insert_rowid\s*\(\s*\)",
            "SELECT lastval()",
            sql,
            flags=re.IGNORECASE,
        )

        # 3. sqlite_master -> information_schema emulation
        sql = re.sub(
            r"\bsqlite_master\b",
            "(SELECT table_name AS name, 'table' AS type, table_name AS sql FROM information_schema.tables "
            "WHERE table_schema = 'public' AND table_type = 'BASE TABLE') AS _sqlite_master",
            sql,
            flags=re.IGNORECASE,
        )

        # 3a. SQLite DDL -> Postgres DDL for CREATE TABLE
        #     Convert INTEGER PRIMARY KEY [AUTOINCREMENT] to a Postgres identity primary key.
        sql = re.sub(
            r"\b(\w+)\s+INTEGER\s+PRIMARY\s+KEY(?:\s+AUTOINCREMENT)?",
            lambda m: f"{_quote(m.group(1))} BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY",
            sql,
            flags=re.IGNORECASE,
        )

        # 3a1. SQLite BLOB -> Postgres BYTEA for CREATE TABLE bodies.
        if re.match(r"^CREATE\s+TABLE", sql, re.IGNORECASE):
            first = sql.find("(")
            last = sql.rfind(")")
            if first != -1 and last != -1 and last > first:
                before = sql[: first + 1]
                body = sql[first + 1 : last]
                after = sql[last:]
                body = re.sub(r"\bBLOB\b", "BYTEA", body, flags=re.IGNORECASE)
                sql = before + body + after

        # Quote column names in CREATE TABLE bodies to avoid reserved words such as "user".
        if re.match(r"^CREATE\s+TABLE", sql, re.IGNORECASE):
            first = sql.find("(")
            last = sql.rfind(")")
            if first != -1 and last != -1 and last > first:
                before = sql[: first + 1]
                body = sql[first + 1 : last]
                after = sql[last:]
                body = re.sub(
                    r"(?m)^\s*(\w+)(?=\s+(?:TEXT|INTEGER|REAL|BLOB|NUMERIC|DOUBLE|FLOAT|VARCHAR|CHAR|INT|BIGINT|SMALLINT|BOOLEAN|DECIMAL|DATE|TIME|TIMESTAMP|INTERVAL|JSONB?|XML|UUID|CIDR|INET|MACADDR|VARBIT|MONEY|BYTEA|TSQUERY|TSVECTOR|BOX|CIRCLE|LINE|LSEG|PATH|POINT|POLYGON|SERIAL|BIGSERIAL|SMALLSERIAL))",
                    lambda m: _quote(m.group(1)),
                    body,
                )
                sql = before + body + after

        # 3b. Quote column names in CREATE INDEX to avoid reserved words (e.g. user, timestamp).
        if re.match(r"^CREATE(?:\s+UNIQUE)?\s+INDEX", sql, re.IGNORECASE):
            sql = re.sub(
                r"ON\s+(\w+)\s*\(([^)]+)\)",
                lambda m: (
                    f"ON {_quote(m.group(1))} ("
                    + re.sub(
                        r"\b(?!ASC\b|DESC\b)\w+",
                        # Keep the regex callback explicitly text-typed for mypy's overload resolution.
                        lambda n: _quote(cast(str, n.group(0))),
                        m.group(2),
                        flags=re.IGNORECASE,
                    )
                    + ")"
                ),
                sql,
                flags=re.IGNORECASE,
            )

        # 3c. INSERT OR REPLACE -> UPSERT
        # Plain INSERT with column list. Skip plain-INSERT rewriting for UPSERTs
        # (INSERT ... VALUES ... ON CONFLICT) so the trailing DO UPDATE clause is
        # not truncated and the generic ? -> %s pass handles the whole statement.
        m = re.search(
            r"INSERT\s+INTO\s+([\"']?)([^\"'\s]+)\1\s*\(\s*([^)]+?)\s*\)\s*VALUES\s*\(([^)]+?)\)",
            sql,
            re.IGNORECASE | re.DOTALL,
        )
        if m and "ON CONFLICT" not in sql.upper():
            table = m.group(2)
            cols = [c.strip().strip('"') for c in m.group(3).split(",")]
            vals = [v.strip() for v in m.group(4).split(",")]
            # Only `?` markers become %s — literal VALUES entries (e.g.
            # `'open'` in the drift_events insert) must be kept verbatim,
            # otherwise the emitted statement has more placeholders than
            # params and psycopg2 dies with "tuple index out of range".
            placeholders = ", ".join("%s" if v == "?" else v for v in vals)
            col_q = ", ".join(_quote(c) for c in cols)
            return f"INSERT INTO {_quote(table)} ({col_q}) VALUES ({placeholders})"  # nosec: B608 - identifiers are double-quoted and values are %s placeholders

        # INSERT OR REPLACE/IGNORE -> UPSERT
        # Preserves nested expressions such as COALESCE((SELECT ...), ?) in the VALUES clause.
        m = re.search(
            r"INSERT\s+OR\s+(REPLACE|IGNORE)\s+INTO\s+([\"']?)([^\"'\s]+)\2\s*\(\s*([^)]+?)\s*\)\s*VALUES\s*\(",
            sql,
            re.IGNORECASE | re.DOTALL,
        )
        if m:
            keyword = m.group(1).upper()
            table = m.group(3)
            cols = [c.strip().strip('"') for c in m.group(4).split(",")]
            values_open = m.end() - 1
            values_close = _find_balanced_paren(sql, values_open)
            if values_close != -1:
                values_sql = sql[values_open + 1 : values_close].strip()
                trailing = sql[values_close + 1 :].strip()
                # Convert SQLite ? placeholders now because this branch returns early.
                values_sql = _sqlite_placeholders_to_pg(values_sql)
                col_q = ", ".join(_quote(c) for c in cols)
                table_q = _quote(table)
                upsert = f"INSERT INTO {table_q} ({col_q}) VALUES ({values_sql})"  # nosec: B608 - identifiers are double-quoted and values are %s placeholders

                target = self._find_conflict_target(table, cols)
                if target:
                    conflict_cols = ", ".join(_quote(c) for c in target)
                    set_cols = [c for c in cols if c not in target]
                    if keyword == "IGNORE":
                        set_cols = []
                    if set_cols:
                        updates = ", ".join(f"{_quote(c)} = EXCLUDED.{_quote(c)}" for c in set_cols)
                        upsert += f" ON CONFLICT ({conflict_cols}) DO UPDATE SET {updates}"  # nosec: B608 - conflict/update columns are double-quoted identifiers
                    else:
                        upsert += f" ON CONFLICT ({conflict_cols}) DO NOTHING"
                else:
                    upsert += " ON CONFLICT DO NOTHING"
                if trailing:
                    upsert += " " + trailing
                return upsert

        # 4. datetime('now', '-24 hours') style
        sql = re.sub(
            r"datetime\s*\(\s*['\"]now['\"]\s*,\s*['\"]([^'\"]+)['\"]\s*\)",
            r"NOW() - INTERVAL '\1'",
            sql,
            flags=re.IGNORECASE,
        )

        # 5. datetime('now')
        sql = re.sub(
            r"datetime\s*\(\s*['\"]now['\"]\s*\)",
            "NOW()",
            sql,
            flags=re.IGNORECASE,
        )

        # 6. datetime(col) -> col::TIMESTAMPTZ
        sql = re.sub(
            r"datetime\s*\(\s*([^)]+)\s*\)",
            r"\1::TIMESTAMPTZ",
            sql,
            flags=re.IGNORECASE,
        )

        # 7. placeholders
        sql = _sqlite_placeholders_to_pg(sql)
        return sql

    def _find_conflict_target(self, table: str, insert_cols: List[str]) -> Optional[List[str]]:
        """Return the PK or unique constraint columns to use for an UPSERT."""
        constraints = self._connection._get_table_constraints(table)
        # Prefer primary key, then first unique whose columns are a subset of the insert columns.
        for _pk_first in (True, False):
            for constraint in constraints:
                # Heuristic: the constraint with just the PK in inserts is the first one listed;
                # we do not know which is PK from the list alone, so treat PK as likely first.
                if all(c in insert_cols for c in constraint):
                    return constraint
        return None

    # ------------------------------------------------------------------
    # Cursor API
    # ------------------------------------------------------------------
    def execute(self, sql: str, params=None):
        if self._pending_table_info is not None:
            self._pending_table_info = None

        sql = self._translate(sql)

        if sql == "SELECT 1 WHERE FALSE":
            # Intercepted PRAGMA table_info: fetchall returns the cached rows
            self._inner.execute("SELECT 1 WHERE FALSE")
            return self

        try:
            self._inner.execute(sql, params)
        except psycopg2.Error:
            # Rollback so the connection is not left in a failed transaction;
            # this mirrors sqlite3 behaviour where the next statement can still run.
            with contextlib.suppress(psycopg2.Error):
                self._connection._raw.rollback()
            raise

        # Capture lastrowid for identity inserts (no explicit id column).
        # Skip lastval() for ON CONFLICT upserts: they may not touch a sequence
        # and calling lastval() on a text-PK/no-insert transaction aborts it.
        self._lastrowid = 0
        if re.match(r"^\s*INSERT\s+", sql, re.IGNORECASE) and not re.search(r"\bON\s+CONFLICT\b", sql, re.IGNORECASE):
            try:
                with self._connection._raw.cursor() as cur:
                    cur.execute("SAVEPOINT _pg_cursor_lastval")
                    cur.execute("SELECT lastval()")
                    row = cur.fetchone()
                    if row and row[0] is not None:
                        self._lastrowid = row[0]
                    cur.execute("RELEASE SAVEPOINT _pg_cursor_lastval")
            except psycopg2.Error:
                # lastval() is only meaningful for SERIAL/identity inserts.
                # If it failed (e.g. no sequence was used) roll the savepoint
                # back so the outer transaction is not left in an aborted state.
                try:
                    with self._connection._raw.cursor() as cur:
                        cur.execute("ROLLBACK TO SAVEPOINT _pg_cursor_lastval")
                except psycopg2.Error:
                    pass
        return self

    def executemany(self, sql: str, params_list: List[Tuple]):
        if self._pending_table_info is not None:
            self._pending_table_info = None
        sql = self._translate(sql)
        self._inner.executemany(sql, params_list)
        self._lastrowid = 0
        return self

    @property
    def lastrowid(self) -> int:
        return self._lastrowid

    @property
    def rowcount(self) -> int:
        return self._inner.rowcount

    @property
    def description(self):
        return self._inner.description

    def fetchone(self):
        return self._inner.fetchone()

    def fetchall(self):
        if self._pending_table_info is not None:
            rows = self._pending_table_info
            self._pending_table_info = None
            return rows
        return self._inner.fetchall()

    def fetchmany(self, size=0):
        return self._inner.fetchmany(size)

    def __iter__(self):
        return iter(self._inner)

    def close(self):
        self._inner.close()
