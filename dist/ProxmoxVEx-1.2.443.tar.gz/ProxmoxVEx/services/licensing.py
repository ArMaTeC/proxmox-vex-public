# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/services/licensing.py
# Project:     ProxmoxVEx
# Version:     1.2.437
# Build:       2026.09.12
# Description: Licensing integration client and guard for ProxmoxVEx.
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-12
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Licensing integration client and guard for ProxmoxVEx."""

import logging
import os
import uuid
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Optional

import requests

from ProxmoxVEx.constants import CONFIG_DIR
from ProxmoxVEx.models.license_context import LicenseContext
from ProxmoxVEx.models.license_log import add_license_log_entry, get_license_log
from ProxmoxVEx.models.plugins import (
    TIER_RANK,
    get_native_tier_requirement,
    get_plugin_tier_requirement,
)
from ProxmoxVEx.models.tier_plugins import get_tier_plugins, set_tier_plugins

# LICENCE_SERVICE_URL is read lazily in LicensingService.__init__ so the
# project .env (loaded by ProxmoxVEx/core/db.py) is in effect before the
# default is chosen. The default is the public production endpoint; set
# LICENCE_SERVICE_URL in .env to override, e.g. for local dev:
#   https://licensing.proxmoxvex.com  # default (production)
#   http://localhost:8001                    # local dev override

# FR-005: re-validate the active license at most every 15 minutes.
REVALIDATION_INTERVAL = timedelta(minutes=15)
# Spec clarification: keep honouring the cached context for up to 24h if the
# license service is unreachable, then downgrade to the lowest tier.
GRACE_PERIOD = timedelta(hours=24)

# Fallback tier catalog shown when the remote licence service cannot be
# reached, so the licence page tier dropdown is never empty.
# Annotated as dict[str, dict[str, Any]] so price fields are usable in
# comparisons without mypy treating them as opaque `object`.
DEFAULT_TIER_CATALOG: dict[str, dict[str, Any]] = {
    "community": {
        "name": "Community",
        "description": "Free for home labs and open-source contributors",
        "monthly_price_cents": 0,
        "yearly_price_cents": 0,
        "features": ["Core cluster management", "Community support", "Free forever"],
    },
    "basic": {
        "name": "Basic",
        "description": "Core cluster management for single admins and small labs",
        "monthly_price_cents": 1900,
        "yearly_price_cents": 19000,
        "features": ["Core cluster management", "Single-site support", "Community support"],
    },
    "advanced": {
        "name": "Advanced",
        "description": "For growing teams with multiple clusters",
        "monthly_price_cents": 4900,
        "yearly_price_cents": 49000,
        "features": [
            "Everything in Basic",
            "Backup and restore plugins",
            "Monitoring dashboard",
            "Email support",
        ],
    },
    "corporate": {
        "name": "Corporate",
        "description": "Large organizations with compliance needs",
        "monthly_price_cents": 19900,
        "yearly_price_cents": 199000,
        "features": [
            "Everything in Advanced",
            "High availability plugins",
            "Multi-site orchestration",
            "Custom plugins",
            "Priority support",
        ],
    },
}


def _default_tiers(currency: str) -> list[dict[str, Any]]:
    """Return a formatted tier catalog when the remote service is unavailable."""
    # currency is accepted to match the remote API signature but prices are
    # currently fixed in the same base units regardless of currency.
    del currency  # placeholder for future per-currency formatting

    def _fmt(amount: Any) -> str:
        if amount is None:
            return "0.00"
        return f"{int(amount) / 100:.2f}"

    return [
        {
            "slug": slug,
            "name": data["name"],
            "monthly_price": _fmt(data["monthly_price_cents"]),
            "yearly_price": _fmt(data["yearly_price_cents"]),
            "description": data["description"],
            "features": data["features"],
        }
        for slug, data in DEFAULT_TIER_CATALOG.items()
    ]


logger = logging.getLogger(__name__)

# Persisted node identifier.  Once generated it is written to the config
# directory and reused on every process restart, so LXC/VM deployments that
# change MAC or machine-id across reboots do not keep creating new license
# activations and hitting ACTIVATION_LIMIT_REACHED.
_PERSISTED_NODE_ID_FILE = Path(CONFIG_DIR) / ".proxmoxvex_node_id"


def _persisted_node_id() -> Optional[str]:
    """Return a previously persisted node id, or None if unavailable."""
    try:
        if _PERSISTED_NODE_ID_FILE.exists():
            return _PERSISTED_NODE_ID_FILE.read_text().strip()
    except Exception as exc:
        logger.warning("Cannot read persisted node id from %s: %s", _PERSISTED_NODE_ID_FILE, exc)
    return None


def _write_persisted_node_id(value: str) -> None:
    """Persist the computed node id to the config directory."""
    try:
        _PERSISTED_NODE_ID_FILE.parent.mkdir(mode=0o700, exist_ok=True)
        _PERSISTED_NODE_ID_FILE.write_text(value)
        os.chmod(_PERSISTED_NODE_ID_FILE, 0o600)
    except Exception as exc:
        logger.warning("Cannot persist node id to %s: %s", _PERSISTED_NODE_ID_FILE, exc)


def _machine_id() -> Optional[str]:
    """Return a stable OS machine-id if one is available."""
    for path in ("/etc/machine-id", "/var/lib/dbus/machine-id"):
        try:
            return Path(path).read_text().strip()
        except Exception:
            continue
    return None


def _node_fingerprint() -> str:
    """Return a stable node-level fingerprint.

    Prefers an explicit env override, then a previously persisted id, then
    /etc/machine-id, then the primary network MAC.  The persisted id is
    written the first time it is computed so LXC/VM deployments that change
    MAC or machine-id across reboots do not keep creating new activations.
    """
    env = os.environ.get("PROXMOXVEX_NODE_FINGERPRINT", "").strip()
    if env:
        return env
    persisted = _persisted_node_id()
    if persisted:
        return persisted
    machine_id = _machine_id()
    value = f"mid:{machine_id}" if machine_id else f"mac:{uuid.getnode():x}"
    _write_persisted_node_id(value)
    return value


def _hardware_id() -> str:
    """Return the hardware ID used for hardware-locked licenses.

    Defaults to the node fingerprint, but can be overridden via
    PROXMOXVEX_HARDWARE_ID for systems where the license is locked to a
    specific value. Empty env values fall back to the node fingerprint.
    """
    env = os.environ.get("PROXMOXVEX_HARDWARE_ID", "").strip()
    return env if env else _node_fingerprint()


def _parse_ts(value: Optional[str]) -> Optional[datetime]:
    if not value:
        return None
    try:
        return datetime.fromisoformat(value.replace("Z", "+00:00"))
    except Exception:
        return None


def _log_license_event(
    db,
    event: str,
    tier_from: Optional[str] = None,
    tier_to: Optional[str] = None,
    reason: Optional[str] = None,
    node_id: str = "default",
) -> None:
    """Persist a license lifecycle event to the local log."""
    try:
        add_license_log_entry(db.conn, event, tier_from, tier_to, reason, node_id)
    except Exception as exc:
        logger.warning("Failed to write license log entry for %s: %s", event, exc)


def _classify_tier_change(old_slug: str, new_slug: str) -> str:
    """Return 'upgraded', 'downgraded' or 'checked' for a tier transition."""
    if old_slug == new_slug:
        return "checked"
    old_rank = TIER_RANK.get(old_slug, 0)
    new_rank = TIER_RANK.get(new_slug, 0)
    if new_rank > old_rank:
        return "upgraded"
    if new_rank < old_rank:
        return "downgraded"
    # Same rank (e.g. basic <-> community) - compare catalogue price.
    # monthly_price_cents is typed `object` in the untyped catalog dict, so
    # coerce to int before comparing (mypy rejects `object > object`).
    old_price = int(DEFAULT_TIER_CATALOG.get(old_slug, {}).get("monthly_price_cents") or 0)
    new_price = int(DEFAULT_TIER_CATALOG.get(new_slug, {}).get("monthly_price_cents") or 0)
    return "upgraded" if new_price > old_price else "downgraded"


class LicensingService:
    """Thin client for the proxmoxvex-licensing service."""

    def __init__(self, base_url: str | None = None, timeout: int = 10) -> None:
        # Read at construction time so .env values are resolved at first use.
        default = os.environ.get("LICENCE_SERVICE_URL", "https://licensing.proxmoxvex.com")
        self.base_url = (base_url or default).rstrip("/")
        self.timeout = timeout
        self.api_key = os.environ.get("LICENCE_SERVICE_API_KEY", "").strip()

    def _auth_headers(self) -> dict:
        """Return the headers required by the license service.

        LICENCE_SERVICE_API_KEY (set in .env) is sent as a Bearer token so the
        license server can authenticate this ProxmoxVEx instance. The license
        key itself is still sent in the request body for validation endpoints.
        """
        headers = {}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        return headers

    def _post(self, path: str, payload: dict) -> Optional[dict]:
        try:
            response = requests.post(
                f"{self.base_url}{path}",
                json=payload,
                headers=self._auth_headers(),
                timeout=self.timeout,
            )
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as exc:
            logger.error("License service request failed for %s: %s", path, exc)
            return None

    def _get(self, path: str, params: Optional[dict] = None) -> Optional[dict]:
        try:
            response = requests.get(
                f"{self.base_url}{path}",
                params=params,
                headers=self._auth_headers(),
                timeout=self.timeout,
            )
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as exc:
            logger.error("License service request failed for %s: %s", path, exc)
            return None

    def validate(
        self,
        license_key: str,
        email: Optional[str] = None,
        currency: str = "USD",
    ) -> dict[str, Any]:
        """Validate a license key with the licensing service."""
        payload = {
            "license_key": license_key,
            "node_fingerprint": _node_fingerprint(),
            "hardware_id": _hardware_id(),
            "currency": currency,
        }
        if email:
            payload["email"] = email
        data = self._post("/v1/licenses/validate", payload)
        if data is None:
            return {
                "ok": False,
                "error": {"code": "SERVICE_ERROR", "message": "Unable to reach license service"},
            }
        return data

    def get_tiers(self, currency: str = "USD") -> dict[str, Any]:
        """Return subscription tiers from the licensing service."""
        data = self._get("/v1/tiers", {"currency": currency})
        if data is None or not data.get("ok"):
            # If the remote licence service is unreachable, serve a local
            # fallback so the licence page tier dropdown is never empty.
            return {
                "ok": True,
                "data": {"tiers": _default_tiers(currency)},
            }
        return data

    def get_tier(self, tier_slug: str, currency: str = "USD") -> dict[str, Any]:
        """Return a single tier from the licensing service."""
        data = self._get(f"/v1/tiers/{tier_slug}", {"currency": currency})
        if data is None:
            return {
                "ok": False,
                "error": {"code": "SERVICE_ERROR", "message": "Unable to reach license service"},
            }
        return data

    def get_context(self, db, node_id: str = "default") -> Optional[LicenseContext]:
        """Load the cached license context for this node."""
        row = db.conn.execute(
            "SELECT license_key_encrypted, tier_slug, tier_name, valid_until, "
            "purchased_at, billing_period, customer_email, last_validated_at, next_check_at FROM license_context WHERE node_id = ?",
            (node_id,),
        ).fetchone()
        if not row:
            return None
        try:
            license_key = db._decrypt(row[0])
        except RuntimeError:
            logging.warning(
                "Cached license context for node %s is corrupt or cannot be decrypted; treating as inactive",
                node_id,
            )
            return None
        return LicenseContext(
            node_id=node_id,
            license_key=license_key,
            tier_slug=row[1],
            tier_name=row[2],
            valid_until=_parse_ts(row[3]),
            purchased_at=_parse_ts(row[4]),
            billing_period=row[5] or "monthly",
            customer_email=row[6] or None,
            last_validated_at=_parse_ts(row[7]) or datetime.now(timezone.utc),
            next_check_at=_parse_ts(row[8]) or datetime.now(timezone.utc),
        )

    def save_context(
        self,
        db,
        license_key: str,
        tier_slug: str,
        tier_name: str,
        valid_until: Optional[datetime],
        node_id: str = "default",
        purchased_at: Optional[datetime] = None,
        billing_period: str = "monthly",
        customer_email: Optional[str] = None,
    ) -> None:
        """Persist an encrypted license context to the local database."""
        now = datetime.now(timezone.utc)
        next_check = now + timedelta(minutes=15)
        # Preserve the original purchase/activation timestamp if the row
        # already exists, so re-activations do not reset the purchase date.
        if purchased_at is None:
            existing = db.conn.execute(
                "SELECT purchased_at FROM license_context WHERE node_id = ?",
                (node_id,),
            ).fetchone()
            purchased_at = _parse_ts(existing[0]) if existing and existing[0] else now
        db.conn.execute(
            "INSERT OR REPLACE INTO license_context "
            "(node_id, license_key_encrypted, tier_slug, tier_name, valid_until, "
            "purchased_at, billing_period, customer_email, last_validated_at, next_check_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (
                node_id,
                db._encrypt(license_key),
                tier_slug,
                tier_name,
                valid_until.isoformat() if valid_until else None,
                purchased_at.isoformat() if purchased_at else now.isoformat(),
                billing_period,
                customer_email,
                now.isoformat(),
                next_check.isoformat(),
            ),
        )
        db.conn.commit()

    def _touch_next_check(self, db, node_id: str = "default") -> None:
        """Push next_check_at forward without disturbing last_validated_at.

        Used when a re-validation attempt fails because the license service
        is unreachable, so we don't hammer it on every request while still
        honouring the cached tier during the grace period.
        """
        next_check = datetime.now(timezone.utc) + REVALIDATION_INTERVAL
        db.conn.execute(
            "UPDATE license_context SET next_check_at = ? WHERE node_id = ?",
            (next_check.isoformat(), node_id),
        )
        db.conn.commit()

    def _revalidate_if_due(self, db, ctx: LicenseContext, node_id: str = "default") -> LicenseContext:
        """Re-check the license with the service if the 15-minute window has elapsed.

        - Service confirms valid: refresh tier/expiry/timestamps.
        - Service confirms invalid/expired/revoked: downgrade to community now
          (this is a definitive answer, not a grace-period case).
        - Service unreachable: leave the cached tier in place but throttle
          further attempts; the 24h grace period is enforced separately.
        """
        now = datetime.now(timezone.utc)
        if now < ctx.next_check_at:
            return ctx

        resp = self.validate(ctx.license_key, email=ctx.customer_email)
        if resp.get("ok"):
            data = resp.get("data", {})
            if data.get("valid"):
                tier = data.get("tier", {})
                new_slug = tier.get("slug", "community")
                new_name = tier.get("name", "Community")
                event = _classify_tier_change(ctx.tier_slug, new_slug)
                _log_license_event(
                    db,
                    event,
                    ctx.tier_slug,
                    new_slug,
                    f"periodic re-validation ({node_id})",
                    node_id,
                )
                valid_until = _parse_ts(data.get("valid_until"))
                billing_period = data.get("billing_period", ctx.billing_period or "monthly")
                self.save_context(
                    db,
                    ctx.license_key,
                    new_slug,
                    new_name,
                    valid_until,
                    node_id,
                    billing_period=billing_period,
                    customer_email=ctx.customer_email,
                )
                return self.get_context(db, node_id) or ctx
            # Definitive "not valid" (expired/revoked/not found) - downgrade now.
            # Never log the license key itself, only the reason code returned by
            # the license service.
            reason_code = data.get("reason_code") or resp.get("error", {}).get("code", "UNKNOWN")
            reason = data.get("reason") or "no details"
            if ctx.tier_slug == "community":
                # Already at the free tier; do not keep re-saving and re-logging
                # the same downgrade (e.g. ACTIVATION_LIMIT_REACHED on every
                # re-validation cycle). Still throttle the next check.
                logger.warning(
                    "License check still failing (%s - %s); node %s is already community, skipping redundant downgrade",
                    reason_code,
                    reason,
                    node_id,
                )
                self._touch_next_check(db, node_id)
                return ctx
            logger.warning(
                "Active license is no longer valid (%s - %s); downgrading node %s to community",
                reason_code,
                reason,
                node_id,
            )
            _log_license_event(
                db,
                "downgraded",
                ctx.tier_slug,
                "community",
                f"{reason_code}: {reason}",
                node_id,
            )
            self.save_context(
                db,
                ctx.license_key,
                "community",
                "Community",
                None,
                node_id,
                customer_email=ctx.customer_email,
            )
            return self.get_context(db, node_id) or ctx

        # Service unreachable - throttle retries, keep serving cached tier
        # until the grace period (checked by the caller) expires.
        self._touch_next_check(db, node_id)
        return ctx

    def get_active_tier(self, db, node_id: str = "default") -> str:
        """Return the active tier slug, falling back to community if none.

        Performs a lazy re-validation (at most every 15 minutes) and applies
        the 24h grace period when the license service is unreachable.
        """
        # Demo sandbox: every feature is unlocked so prospects can evaluate
        # the full product surface without a license key.
        if os.environ.get("PROXMOXVEX_DEMO_MODE", "").lower() in ("1", "true", "yes"):
            return "corporate"
        if db is None:
            return "community"
        ctx = self.get_context(db, node_id)
        if ctx is None:
            return "community"

        try:
            ctx = self._revalidate_if_due(db, ctx, node_id)
        except Exception as e:
            logger.warning("License re-validation skipped for node %s: %s", node_id, e)

        if datetime.now(timezone.utc) - ctx.last_validated_at > GRACE_PERIOD:
            # Service has been unreachable for longer than the grace period.
            return "community"
        return ctx.tier_slug

    def get_allowed_plugins(self, db, tier_slug: str) -> Optional[list]:
        """Return explicitly allowed plugin slugs for a tier (None if not set)."""
        return get_tier_plugins(db.conn, tier_slug)

    def set_allowed_plugins(self, db, tier_slug: str, plugin_slugs: list) -> None:
        """Replace the allowed plugin list for a tier."""
        set_tier_plugins(db.conn, tier_slug, plugin_slugs)

    def can_use_plugin(self, db, plugin_slug: str, node_id: str = "default") -> bool:
        """Return True if the active license tier allows this plugin.

        A plugin in the explicit allow-list is allowed immediately.
        Otherwise fall back to the manifest's min_license_tier rank so new
        plugins with a matching or lower tier are not silently blocked by a
        stale allow-list.
        """
        active = self.get_active_tier(db, node_id)
        allowed = get_tier_plugins(db.conn, active)
        if allowed is not None and plugin_slug in allowed:
            return True
        active_rank = TIER_RANK.get(active, 0)
        required_rank = TIER_RANK.get(get_plugin_tier_requirement(plugin_slug), 0)
        return active_rank >= required_rank

    def can_use_native(self, db, module_id: str, node_id: str = "default") -> bool:
        """Return True if the active license tier allows this native integration."""
        active = self.get_active_tier(db, node_id)
        active_rank = TIER_RANK.get(active, 0)
        required_rank = TIER_RANK.get(get_native_tier_requirement(module_id), 0)
        return active_rank >= required_rank

    def create_paypal_order(
        self,
        tier_slug: str,
        billing_period: str,
        currency: str,
        email: str,
    ) -> dict[str, Any] | None:
        """Create a PayPal order through the licensing service and return the approval URL."""
        return self._post(
            "/v1/payments/paypal/create-order",
            {
                "tier_slug": tier_slug,
                "billing_period": billing_period,
                "currency": currency,
                "email": email,
            },
        )

    def plugin_lock_info(self, db, plugin_slug: str, node_id: str = "default") -> dict[str, Any]:
        """Return licensing/lock metadata for a plugin, for UI display."""
        required_tier = get_plugin_tier_requirement(plugin_slug)
        return {
            "required_tier": required_tier,
            "licensed": self.can_use_plugin(db, plugin_slug, node_id),
        }

    def activate(
        self,
        db,
        license_key: str,
        email: str,
        node_id: str = "default",
    ) -> dict[str, Any]:
        """Activate a license and cache the resulting context."""
        service_resp = self.validate(license_key, email=email)
        prev_ctx = self.get_context(db, node_id)
        if not service_resp.get("ok"):
            reason = (service_resp.get("error") or {}).get("code", "SERVICE_ERROR")
            _log_license_event(
                db,
                "activation_failed",
                prev_ctx.tier_slug if prev_ctx else None,
                "community",
                reason,
                node_id,
            )
            return service_resp
        data = service_resp.get("data", {})
        if not data.get("valid"):
            reason = data.get("reason_code") or data.get("reason") or "INVALID_KEY"
            _log_license_event(
                db,
                "activation_failed",
                prev_ctx.tier_slug if prev_ctx else None,
                "community",
                reason,
                node_id,
            )
            return service_resp

        tier = data.get("tier", {})
        new_slug = tier.get("slug", "community")
        new_name = tier.get("name", "Community")
        old_slug = prev_ctx.tier_slug if prev_ctx else None
        event = (
            "installed"
            if old_slug is None
            else _classify_tier_change(old_slug, new_slug)
        )
        _log_license_event(db, event, old_slug, new_slug, f"activated by {email}", node_id)
        valid_until = _parse_ts(data.get("valid_until"))
        purchased_at = _parse_ts(data.get("purchased_at"))
        billing_period = data.get("billing_period", "monthly")
        self.save_context(
            db,
            license_key,
            new_slug,
            new_name,
            valid_until,
            node_id,
            purchased_at,
            billing_period,
            customer_email=email,
        )
        return {
            "ok": True,
            "data": {
                "valid": True,
                "tier": tier,
                "billing_period": billing_period,
                "permitted_plugins": data.get("permitted_plugins", []),
            },
        }

    def get_license_log(self, db, node_id: str = "default", limit: int = 50) -> list[dict[str, Any]]:
        """Return the recent license lifecycle log for this node."""
        try:
            return get_license_log(db.conn, node_id, limit)
        except Exception as exc:
            logger.warning("Failed to read license log for node %s: %s", node_id, exc)
            return []
