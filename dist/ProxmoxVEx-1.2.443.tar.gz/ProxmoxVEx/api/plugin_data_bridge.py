# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/api/plugin_data_bridge.py
# Project:     ProxmoxVEx
# Version:     1.2.437
# Build:       2026.09.12
# Description: Shared live data bridge for plugin backends and UIs.
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-12
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""
Shared live data bridge for plugin backends and UIs.

Exposes real Proxmox cluster data (nodes, VMs, storage, etc.) in a simple,
plugin-friendly format so plugin front-ends stop relying on hard-coded values.
"""

import logging
from datetime import datetime, timedelta, timezone

from ProxmoxVEx.api.helpers import check_cluster_access, get_connected_manager, load_metrics_window
from ProxmoxVEx.globals import cluster_managers

log = logging.getLogger("plugin_data_bridge")


def _now():
    return datetime.now(timezone.utc)


def _manager_or_error(cluster_id):
    """Return (manager, error_dict) for a cluster or an error placeholder."""
    allowed, err = check_cluster_access(cluster_id)
    if not allowed:
        return None, err
    return get_connected_manager(cluster_id)


def _cluster_resources(manager, resource_type=None):
    """Fetch /cluster/resources and optionally filter by PVE resource type."""
    try:
        resources = manager.api_request("GET", "/cluster/resources") or []
    except Exception as e:
        log.warning("cluster/resources failed: %s", e)
        return []
    if resource_type:
        if not isinstance(resource_type, (tuple, list)):
            resource_type = (resource_type,)
        return [r for r in resources if r.get("type") in resource_type]
    return resources


def get_clusters():
    """Return the list of configured clusters."""
    clusters = []
    for cid, mgr in (cluster_managers or {}).items():
        clusters.append({
            "id": cid,
            "name": getattr(mgr.config, "name", cid) if getattr(mgr, "config", None) else cid,
            "connected": getattr(mgr, "is_connected", False),
        })
    return {"clusters": clusters}


def get_nodes(cluster_id):
    """Return live PVE node list for a cluster."""
    manager, err = _manager_or_error(cluster_id)
    if err:
        return {"error": err[0].get("error") if isinstance(err, tuple) else str(err)}
    try:
        nodes = manager.api_request("GET", "/nodes") or []
    except Exception as e:
        log.warning("nodes failed for %s: %s", cluster_id, e)
        return {"nodes": []}
    out = []
    for n in nodes:
        out.append({
            "name": n.get("node") or n.get("name"),
            "status": n.get("status"),
            "cpu": n.get("cpu"),
            "maxcpu": n.get("maxcpu"),
            "mem": n.get("mem"),
            "maxmem": n.get("maxmem"),
        })
    return {"nodes": out}


def _to_resource_list(resources):
    out = []
    for r in resources:
        out.append({
            "vmid": r.get("vmid") or r.get("id"),
            "name": r.get("name"),
            "node": r.get("node"),
            "status": r.get("status"),
            "cpu": r.get("cpu"),
            "maxcpu": r.get("maxcpu"),
            "mem": r.get("mem"),
            "maxmem": r.get("maxmem"),
        })
    return out


def get_vms(cluster_id):
    """Return live PVE QEMU VM list for a cluster."""
    manager, err = _manager_or_error(cluster_id)
    if err:
        return {"error": err[0].get("error") if isinstance(err, tuple) else str(err)}
    return {"vms": _to_resource_list(_cluster_resources(manager, ("qemu",)))}


def get_lxc(cluster_id):
    """Return live PVE LXC container list for a cluster."""
    manager, err = _manager_or_error(cluster_id)
    if err:
        return {"error": err[0].get("error") if isinstance(err, tuple) else str(err)}
    return {"lxc": _to_resource_list(_cluster_resources(manager, ("lxc",)))}


def get_storage(cluster_id):
    """Return live PVE storage list for a cluster."""
    manager, err = _manager_or_error(cluster_id)
    if err:
        return {"error": err[0].get("error") if isinstance(err, tuple) else str(err)}
    try:
        storage = manager.api_request("GET", "/storage") or []
    except Exception as e:
        log.warning("storage failed for %s: %s", cluster_id, e)
        return {"storage": []}
    out = []
    for s in storage:
        out.append({
            "id": s.get("storage") or s.get("id"),
            "name": s.get("storage") or s.get("name"),
            "type": s.get("type"),
            "content": s.get("content"),
            "total": s.get("total"),
            "used": s.get("used"),
            "available": s.get("avail"),
        })
    return {"storage": out}


def get_pools(cluster_id):
    """Return live PVE pool list for a cluster."""
    manager, err = _manager_or_error(cluster_id)
    if err:
        return {"error": err[0].get("error") if isinstance(err, tuple) else str(err)}
    try:
        pools = manager.api_request("GET", "/pools") or []
    except Exception as e:
        log.warning("pools failed for %s: %s", cluster_id, e)
        return {"pools": []}
    out = []
    for p in pools:
        out.append({
            "id": p.get("poolid") or p.get("id"),
            "name": p.get("poolid") or p.get("name") or p.get("comment") or p.get("id"),
        })
    return {"pools": out}


def get_templates(cluster_id):
    """Return live PVE templates (qemu + lxc marked as template)."""
    manager, err = _manager_or_error(cluster_id)
    if err:
        return {"error": err[0].get("error") if isinstance(err, tuple) else str(err)}
    resources = _cluster_resources(manager, ("qemu", "lxc"))
    out = []
    for r in resources:
        if not r.get("template"):
            continue
        out.append({
            "vmid": r.get("vmid"),
            "name": r.get("name"),
            "node": r.get("node"),
            "type": r.get("type"),
        })
    return {"templates": out}


def get_tasks(cluster_id):
    """Return live PVE cluster task list."""
    manager, err = _manager_or_error(cluster_id)
    if err:
        return {"error": err[0].get("error") if isinstance(err, tuple) else str(err)}
    try:
        tasks = manager.api_request("GET", "/cluster/tasks") or []
    except Exception as e:
        log.warning("tasks failed for %s: %s", cluster_id, e)
        return {"tasks": []}
    return {
        "tasks": [
            {
                "upid": t.get("upid"),
                "node": t.get("node"),
                "user": t.get("user"),
                "type": t.get("type"),
                "starttime": t.get("starttime"),
                "endtime": t.get("endtime"),
                "status": t.get("status"),
            }
            for t in tasks
        ]
    }


def get_prometheus_sample(cluster_id, prefix=None):
    """Build a real Prometheus-compatible sample from live cluster data."""
    lines = []
    if not cluster_id:
        lines.append("# HELP pve_info Plugin metrics preview (select a cluster)")
        lines.append("# TYPE pve_info gauge")
        lines.append("pve_info 1")
        sample = "\n".join(lines) + "\n"
    else:
        nodes = get_nodes(cluster_id).get("nodes", [])
        vms = get_vms(cluster_id).get("vms", []) if nodes else []
        storage = get_storage(cluster_id).get("storage", []) if nodes else []

        lines.append("# HELP pve_up node up")
        lines.append("# TYPE pve_up gauge")
        for n in nodes:
            name = (n.get("name") or "unknown").replace('"', '\\"')
            lines.append(f'pve_up{{node="{name}"}} 1')

        lines.append("# HELP pve_node_info node info")
        lines.append("# TYPE pve_node_info gauge")
        for n in nodes:
            name = (n.get("name") or "unknown").replace('"', '\\"')
            status = (n.get("status") or "").replace('"', '\\"')
            lines.append(f'pve_node_info{{node="{name}",status="{status}"}} 1')

        if vms:
            lines.append("# HELP pve_vm_info vm info")
            lines.append("# TYPE pve_vm_info gauge")
            for v in vms:
                name = (v.get("name") or "unknown").replace('"', '\\"')
                node = (v.get("node") or "unknown").replace('"', '\\"')
                lines.append(f'pve_vm_info{{vmid="{v.get("vmid")}",name="{name}",node="{node}"}} 1')

        if storage:
            lines.append("# HELP pve_storage_info storage info")
            lines.append("# TYPE pve_storage_info gauge")
            for s in storage:
                sid = (s.get("id") or "unknown").replace('"', '\\"')
                lines.append(f'pve_storage_info{{id="{sid}",type="{s.get("type")}"}} 1')

        sample = "\n".join(lines) + "\n"

    if prefix:
        filtered = [line for line in sample.splitlines() if line.startswith("#") or prefix in line]
        sample = "\n".join(filtered) + "\n"
    return sample


def _pct(value, maximum):
    try:
        return round((float(value) / float(maximum)) * 100, 2) if maximum else 0.0
    except Exception:
        return 0.0


def _cluster_pct(resource, cluster_id):
    """Return a coarse cluster-wide utilisation percent for a resource."""
    if not cluster_id:
        return 0.0
    total_pct = 0.0
    count = 0
    if resource == "cpu":
        for n in get_nodes(cluster_id).get("nodes", []):
            if n.get("maxcpu"):
                total_pct += _pct(n.get("cpu"), n.get("maxcpu"))
                count += 1
    elif resource in ("memory", "ram"):
        for n in get_nodes(cluster_id).get("nodes", []):
            if n.get("maxmem"):
                total_pct += _pct(n.get("mem"), n.get("maxmem"))
                count += 1
    elif resource == "storage":
        for s in get_storage(cluster_id).get("storage", []):
            if s.get("total"):
                total_pct += _pct(s.get("used"), s.get("total"))
                count += 1
    return round(total_pct / count, 2) if count else 0.0


def _cluster_pct_from_data(cd, resource):
    """Extract a resource utilisation percent from a metrics snapshot's cluster data."""
    totals = cd.get("totals") or {}
    if resource == "cpu":
        total = totals.get("cpu_total", 0)
        used = totals.get("cpu_used", 0)
        if total:
            return round(used / total * 100, 2)
    elif resource in ("memory", "ram"):
        total = totals.get("mem_total", 0)
        used = totals.get("mem_used", 0)
        if total:
            return round(used / total * 100, 2)
    nodes = cd.get("nodes") or {}
    vals = []
    for n in nodes.values():
        if resource == "cpu" and "cpu" in n:
            vals.append(n["cpu"])
        elif resource in ("memory", "ram") and "mem_percent" in n:
            vals.append(n["mem_percent"])
    return round(sum(vals) / len(vals), 2) if vals else None


def _extract_history_pct(clusters, cluster_id, resource):
    """Pick a single percent for a cluster (or average all clusters for global)."""
    if cluster_id:
        cd = clusters.get(cluster_id)
        if not cd:
            return None
        return _cluster_pct_from_data(cd, resource)
    vals = [
        _cluster_pct_from_data(cd, resource)
        for cd in clusters.values()
        if _cluster_pct_from_data(cd, resource) is not None
    ]
    return round(sum(vals) / len(vals), 2) if vals else None


def _linear_regression(xs, ys):
    """Return slope, intercept and r_squared for a simple linear fit."""
    n = len(xs)
    if n < 2:
        return None, None, 0.0
    mx = sum(xs) / n
    my = sum(ys) / n
    num = sum((x - mx) * (y - my) for x, y in zip(xs, ys))
    den_x = sum((x - mx) ** 2 for x in xs)
    den_y = sum((y - my) ** 2 for y in ys)
    if den_x == 0:
        return None, my, 1.0 if den_y == 0 else 0.0
    slope = num / den_x
    intercept = my - slope * mx
    if den_y == 0:
        return slope, intercept, 1.0
    ss_res = sum((y - (slope * x + intercept)) ** 2 for x, y in zip(xs, ys))
    r2 = max(0.0, 1.0 - ss_res / den_y)
    return slope, intercept, r2


def get_forecast_series(resource, window_days, cluster_id=None):
    """Return a forecast based on actual historical metrics, not synthetic drift."""
    current = _cluster_pct(resource, cluster_id)
    now = _now()
    now_ts = int(now.timestamp())
    try:
        history_days = max(7, min(90, window_days * 3))
        xs, ys = [], []
        for ts_unix, clusters in load_metrics_window(history_days):
            pct = _extract_history_pct(clusters, cluster_id, resource)
            if pct is not None:
                xs.append(ts_unix)
                ys.append(pct)
        if len(xs) >= 6:
            slope, intercept, _ = _linear_regression(xs, ys)
            if slope is not None:
                out = []
                for i in range(window_days):
                    future_ts = now_ts + i * 86400
                    value = slope * future_ts + intercept
                    # Dampen runaway regression by blending toward the current baseline over time.
                    weight = 0.1 * i / max(window_days, 1)
                    value = value * (1 - weight) + current * weight
                    out.append({
                        "timestamp": (now + timedelta(days=i)).isoformat(),
                        "value": round(max(0.0, min(100.0, value)), 2),
                    })
                return out
    except Exception as e:
        log.warning("forecast from history failed: %s", e)
    # No usable history yet: flat forecast at the current value.
    out = []
    for i in range(window_days):
        out.append({
            "timestamp": (now + timedelta(days=i)).isoformat(),
            "value": current,
        })
    return out


def get_live_data(resource, cluster_id=None):
    """Dispatch a generic live resource request used by plugin UI/API."""
    resource = (resource or "").strip().lower()
    if not resource:
        return {"error": "resource required"}

    dispatch = {
        "clusters": get_clusters,
        "nodes": get_nodes,
        "vms": get_vms,
        "lxc": get_lxc,
        "storage": get_storage,
        "pools": get_pools,
        "templates": get_templates,
        "tasks": get_tasks,
    }
    if resource not in dispatch:
        return {"error": f"unknown resource: {resource}"}
    return dispatch[resource](cluster_id)
