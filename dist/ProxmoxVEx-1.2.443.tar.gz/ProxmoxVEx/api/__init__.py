# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/api/__init__.py
# Project:     ProxmoxVEx
# Version:     1.2.437
# Build:       2026.09.12
# Description: ProxmoxVEx API Blueprint Registration
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-12
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""
ProxmoxVEx API Blueprint Registration
"""

import contextlib
import gzip
import json as _json
import logging
import time

from flask import jsonify, request

from ProxmoxVEx.utils.auth import validate_api_token, validate_session

# In-memory cache for API call responses.
_API_CALL_CACHE = {}
_API_CALL_CACHE_TTL = 30


def _api_cache_key(path, query=None):
    """Build a cache key from the request path and optional query."""
    return f"{path}:{hash(str(query))}"


def _get_cached_api_response(path, query=None):
    """Return a cached API response if it has not expired."""
    key = _api_cache_key(path, query)
    entry = _API_CALL_CACHE.get(key)
    if entry is None or time.time() - entry["ts"] > _API_CALL_CACHE_TTL:
        return None
    return entry["data"]


def _cache_api_response(path, query=None, data=None):
    """Store an API response in the in-memory cache."""
    _API_CALL_CACHE[_api_cache_key(path, query)] = {"ts": time.time(), "data": data}


# Lazy loading: fields that are expensive to compute and can be deferred for API calls.
_LAZY_API_FIELDS = {
    "detail",
    "history",
    "extended",
}


def _prune_lazy_api_fields(payload):
    """Remove lazy/deferred fields from an API payload to reduce initial response size."""
    if not isinstance(payload, dict):
        return payload
    return {k: v for k, v in payload.items() if k not in _LAZY_API_FIELDS}


def _paginate_api_data(data, page=1, limit=0):
    """Apply optional pagination to API response data."""
    if not data or limit <= 0:
        return data
    page = max(1, page)
    start = (page - 1) * limit
    end = start + limit
    return data[start:end]


def _batch_api_calls(items, batch_size=10):
    """Split a list of API calls/items into fixed-size batches."""
    if not items or batch_size <= 0:
        return [items] if items else []
    return [items[i : i + batch_size] for i in range(0, len(items), batch_size)]


def _index_api_results(items, key=None):
    """Build a lookup index for API call results keyed by the provided field."""
    if not items or not key:
        return {}
    index = {}
    for item in items:
        if not isinstance(item, dict):
            continue
        k = item.get(key)
        if k is not None:
            index.setdefault(k, []).append(item)
    return index


def _compress_api_response(payload, accept_encoding=""):
    """Compress an API payload with gzip when accepted by the client."""
    if not accept_encoding or "gzip" not in accept_encoding.lower():
        return payload, None
    try:
        raw = _json.dumps(payload).encode("utf-8") if not isinstance(payload, bytes) else payload
        return gzip.compress(raw), "gzip"
    except (TypeError, ValueError):
        return payload, None


# Connection pool for API calls to reduce connection setup overhead.
_API_CONNECTION_POOL = {}


def _get_api_connection(conn_id):
    """Return a cached connection for the given API call target."""
    return _API_CONNECTION_POOL.get(conn_id)


# Async worker registry for API call background tasks.
_ASYNC_API_WORKERS = set()


def _start_async_api_worker(worker_id):
    """Register a new async worker for API call background tasks."""
    _ASYNC_API_WORKERS.add(worker_id)
    return worker_id


# Memory-optimised API response field whitelist.
_API_RESPONSE_ESSENTIAL_FIELDS = (
    "id",
    "name",
    "status",
    "type",
    "ctime",
    "vm_name",
)


def _memory_optimise_api_payload(payload):
    """Drop heavy unused fields from an API payload to reduce memory."""
    if not isinstance(payload, list):
        return payload
    return [
        {k: v for k, v in item.items() if k in _API_RESPONSE_ESSENTIAL_FIELDS}
        for item in payload
        if isinstance(item, dict)
    ]


def _incremental_api_updates(items, since=None, timestamp_key="mtime"):
    """Filter API call results to only include items updated since a given timestamp."""
    if not since:
        return items
    return [item for item in items if isinstance(item, dict) and item.get(timestamp_key, 0) > since]


# Spec 038 (US1): endpoints an unenrolled user may still reach while the
# force-MFA hard block is active — enrollment itself plus session teardown.
_MFA_ENROLL_ALLOWLIST = (
    "/api/auth/2fa/",
    "/api/webauthn/register/",
    "/api/auth/stepup/",
)


def _mfa_enrollment_block(session):
    """Return a 403 confinement response when the session's user must enroll MFA.

    Applies to session AND API-token auth alike: an unenrolled account should not
    operate at all while force_2fa is on (a pre-existing token is a bypass
    otherwise). Evaluation failure fails open to the normal decorators — a broken
    settings store already degrades requests downstream via require_auth.
    """
    try:
        from ProxmoxVEx.api.helpers import load_server_settings
        from ProxmoxVEx.utils.auth import TOTP_AVAILABLE

        settings = load_server_settings() or {}
        if not settings.get("force_2fa") or not TOTP_AVAILABLE:
            return None
        if request.path.startswith(_MFA_ENROLL_ALLOWLIST):
            return None

        username = session.get("user", "")
        try:
            from ProxmoxVEx.core.db import get_db

            user = get_db().get_user(username)
        except Exception:
            user = None
        if not user:
            from ProxmoxVEx.utils.auth import load_users

            user = (load_users() or {}).get(username)
        if not user:
            return None

        # OIDC/Entra users satisfy MFA at their IdP — no local factor exists.
        if user.get("auth_source", "local") in ("oidc", "entra"):
            return None
        from ProxmoxVEx.models.permissions import ROLE_ADMIN

        if user.get("role") == ROLE_ADMIN and settings.get("force_2fa_exclude_admins"):
            return None
        if user.get("totp_enabled") and user.get("totp_secret"):
            return None
        try:
            from ProxmoxVEx.core.db import get_db

            row = get_db().query_one(
                "SELECT COUNT(*) AS n FROM webauthn_credentials WHERE username = ?",
                (username,),
            )
            if row and row["n"] > 0:
                return None
        except Exception as e:
            logging.debug(f"mfa-block: webauthn credential count failed for {username}: {e}")

        logging.info(f"mfa-block: confining unenrolled user {username} to enrollment (path={request.path})")
        return jsonify({
            "error": "MFA enrollment required",
            "code": "REQUIRES_2FA_SETUP",
            "requires_2fa_setup": True,
        }), 403
    except Exception as e:
        logging.error(f"mfa-block: evaluation failed ({e}); deferring to route auth")
        return None


def register_blueprints(app):
    """Register all API blueprints with the Flask app."""
    from ProxmoxVEx.api.alerts import bp as alerts_bp
    from ProxmoxVEx.api.audit_search import bp as audit_search_bp
    from ProxmoxVEx.api.auth import bp as auth_bp
    from ProxmoxVEx.api.ceph import bp as ceph_bp
    from ProxmoxVEx.api.clusters import bp as clusters_bp
    from ProxmoxVEx.api.converter import bp as converter_bp
    from ProxmoxVEx.api.costs import bp as costs_bp
    from ProxmoxVEx.api.datacenter import bp as datacenter_bp
    from ProxmoxVEx.api.demo import bp as demo_bp
    from ProxmoxVEx.api.disaster_recovery import bp as disaster_recovery_bp
    from ProxmoxVEx.api.drift import bp as drift_bp
    from ProxmoxVEx.api.drift import start_scanner as start_drift_scanner
    from ProxmoxVEx.api.groups import bp as groups_bp
    from ProxmoxVEx.api.history import bp as history_bp
    from ProxmoxVEx.api.ids import bp as ids_bp
    from ProxmoxVEx.api.insights import bp as insights_bp
    from ProxmoxVEx.api.licence import bp as licence_bp
    from ProxmoxVEx.api.metrics_exporter import bp as metrics_exporter_bp
    from ProxmoxVEx.api.mirror import bp as mirror_bp
    from ProxmoxVEx.api.nodes import bp as nodes_bp
    from ProxmoxVEx.api.pbs import bp as pbs_bp
    from ProxmoxVEx.api.plugins import bp as plugins_bp
    from ProxmoxVEx.api.power import bp as power_bp
    from ProxmoxVEx.api.push import bp as push_bp
    from ProxmoxVEx.api.push import register_alert_handler
    from ProxmoxVEx.api.realtime import bp as realtime_bp
    from ProxmoxVEx.api.reports import bp as reports_bp
    from ProxmoxVEx.api.schedules import bp as schedules_bp
    from ProxmoxVEx.api.search import bp as search_bp
    from ProxmoxVEx.api.server_access import bp as server_access_bp
    from ProxmoxVEx.api.settings import bp as settings_bp
    from ProxmoxVEx.api.siem import bp as siem_bp
    from ProxmoxVEx.api.siem import start_worker as start_siem_worker
    from ProxmoxVEx.api.site_recovery import bp as site_recovery_bp
    from ProxmoxVEx.api.snapshots import bp as snapshots_bp
    from ProxmoxVEx.api.snapshots import start_scheduler as start_snap_scheduler
    from ProxmoxVEx.api.static_files import bp as static_files_bp
    from ProxmoxVEx.api.stepup import bp as stepup_bp
    from ProxmoxVEx.api.storage import bp as storage_bp
    from ProxmoxVEx.api.templates_lib import bp as templates_lib_bp
    from ProxmoxVEx.api.topology import bp as topology_bp
    from ProxmoxVEx.api.users import bp as users_bp
    from ProxmoxVEx.api.vms import bp as vms_bp
    from ProxmoxVEx.api.vmware import bp as vmware_bp
    from ProxmoxVEx.api.webauthn import bp as webauthn_bp
    from ProxmoxVEx.integrations.active_directory import bp as active_directory_bp
    from ProxmoxVEx.integrations.api_tokens import bp as api_tokens_bp
    from ProxmoxVEx.integrations.authentik import bp as authentik_bp

    # Specs 018-034: vendor integration blueprints (connector + read surfaces).
    from ProxmoxVEx.integrations.ceph_external import bp as ceph_external_bp
    from ProxmoxVEx.integrations.cisco import bp as cisco_bp
    from ProxmoxVEx.integrations.docker import bp as docker_bp
    from ProxmoxVEx.integrations.eos import bp as eos_bp
    from ProxmoxVEx.integrations.freeipa import bp as freeipa_bp
    from ProxmoxVEx.integrations.git import bp as git_bp
    from ProxmoxVEx.integrations.grafana import bp as grafana_bp
    from ProxmoxVEx.integrations.junos import bp as junos_bp
    from ProxmoxVEx.integrations.keycloak import bp as keycloak_bp
    from ProxmoxVEx.integrations.kubernetes import bp as kubernetes_bp
    from ProxmoxVEx.integrations.ldap import bp as ldap_integration_bp

    # Spec 016: the NetBox blueprint existed but was never registered, so its
    # /api/clusters/<id>/netbox/* endpoints 404'd despite tests covering the module.
    from ProxmoxVEx.integrations.netbox import bp as netbox_bp

    # Spec 032: OpenLDAP profile surface (posixAccount/inetOrgPerson presets,
    # ppolicy, replication, directory browser) alongside generic ldap auth.
    from ProxmoxVEx.integrations.openldap import bp as openldap_bp
    from ProxmoxVEx.integrations.packer import bp as packer_bp
    from ProxmoxVEx.integrations.pbs import bp as pbs_integration_bp
    from ProxmoxVEx.integrations.phpipam import bp as phpipam_bp
    from ProxmoxVEx.integrations.prometheus import bp as prometheus_bp
    from ProxmoxVEx.integrations.routeros import bp as routeros_bp
    from ProxmoxVEx.integrations.s3 import bp as s3_bp
    from ProxmoxVEx.integrations.synology import bp as synology_bp
    from ProxmoxVEx.integrations.tailscale import bp as tailscale_bp
    from ProxmoxVEx.integrations.terraform import bp as terraform_bp
    from ProxmoxVEx.integrations.uptimekuma import bp as uptimekuma_bp
    from ProxmoxVEx.integrations.vault import bp as vault_bp
    from ProxmoxVEx.integrations.victoriametrics import bp as victoriametrics_bp
    from ProxmoxVEx.integrations.vmware import bp as vmware_integration_bp
    from ProxmoxVEx.integrations.webhooks import bp as webhooks_bp
    from ProxmoxVEx.integrations.wireguard import bp as wireguard_integration_bp
    from ProxmoxVEx.native.registry import bp as native_bp

    _blueprints = [
        ("auth", auth_bp),
        ("demo", demo_bp),
        ("users", users_bp),
        ("converter", converter_bp),
        ("clusters", clusters_bp),
        ("vms", vms_bp),
        ("nodes", nodes_bp),
        ("pbs", pbs_bp),
        ("storage", storage_bp),
        ("datacenter", datacenter_bp),
        ("vmware", vmware_bp),
        ("schedules", schedules_bp),
        ("reports", reports_bp),
        ("settings", settings_bp),
        ("alerts", alerts_bp),
        ("realtime", realtime_bp),
        ("search", search_bp),
        ("server_access", server_access_bp),
        ("static_files", static_files_bp),
        ("stepup", stepup_bp),
        ("history", history_bp),
        ("ids", ids_bp),
        ("groups", groups_bp),
        ("ceph", ceph_bp),
        ("site_recovery", site_recovery_bp),
        # disaster-recovery routes live under /api/site-recovery/plans/<plan_id>/...
        # and must be registered before the native catch-all /api/<module_id>/<path:subpath>
        # to avoid being shadowed by the native proxy.
        ("disaster_recovery", disaster_recovery_bp),
        ("plugins", plugins_bp),
        ("native", native_bp),
        ("webauthn", webauthn_bp),
        ("metrics_exporter", metrics_exporter_bp),
        ("mirror", mirror_bp),
        ("insights", insights_bp),
        ("licence", licence_bp),
        ("templates_lib", templates_lib_bp),
        ("push", push_bp),
        ("costs", costs_bp),
        ("drift", drift_bp),
        ("audit_search", audit_search_bp),
        ("siem", siem_bp),
        ("snapshots", snapshots_bp),
        ("topology", topology_bp),
        ("terraform", terraform_bp),
        ("vmware_integration", vmware_integration_bp),
        ("active_directory", active_directory_bp),
        ("kubernetes", kubernetes_bp),
        ("packer", packer_bp),
        ("prometheus", prometheus_bp),
        ("phpipam", phpipam_bp),
        ("netbox", netbox_bp),
        ("openldap", openldap_bp),
        ("ceph_external", ceph_external_bp),
        ("synology", synology_bp),
        ("routeros", routeros_bp),
        ("cisco", cisco_bp),
        ("eos", eos_bp),
        ("junos", junos_bp),
        ("tailscale", tailscale_bp),
        ("wireguard_integration", wireguard_integration_bp),
        ("victoriametrics", victoriametrics_bp),
        ("uptimekuma", uptimekuma_bp),
        ("freeipa", freeipa_bp),
        ("authentik", authentik_bp),
        ("keycloak", keycloak_bp),
        ("pbs_integration", pbs_integration_bp),
        ("grafana", grafana_bp),
        ("ldap", ldap_integration_bp),
        ("s3", s3_bp),
        ("docker", docker_bp),
        ("git", git_bp),
        ("power", power_bp),
        ("vault", vault_bp),
        ("api_tokens", api_tokens_bp),
        ("webhooks", webhooks_bp),
    ]

    # ISS-080: the previous blueprint-level whitelist meant ANY new route added
    # to a "public" blueprint was silently reachable without auth. The guard now
    # attaches to every blueprint, and only the explicitly listed path prefixes
    # below bypass it — everything else under /api/ defaults to authenticated.
    _public_api_prefixes = (
        # health + login flow
        "/api/health",
        "/api/auth/login",
        "/api/auth/setup",
        "/api/auth/check",
        "/api/auth/validate",
        "/api/auth/logout",
        "/api/auth/oidc/",
        # demo entry
        "/api/demo/token",
        "/api/demo/login",
        "/api/demo/auto-login",
        "/api/config",
        # WebAuthn login ceremony (registration/credentials self-guard)
        "/api/webauthn/auth/",
        "/api/webauthn/available",
        # realtime: SSE/WS endpoints do their own token auth
        "/api/sse/updates",
        "/api/ws/updates",
        "/api/ws/token/validate",
        # metrics endpoint self-authenticates via Bearer token / metrics_public
        "/api/metrics",
        # mirror blueprint public docs/version endpoints
        "/api/version.json",
        "/api/trees/",
    )

    _guarded_bp_names = {name for name, _ in _blueprints}

    def _require_auth_for_request():
        """App-level before_request guard: require a valid session or API token."""
        # Only applies to routes owned by the API blueprints below — attaching at
        # app level (instead of bp.before_request) keeps the guard from leaking
        # into test apps that register a shared blueprint object directly.
        if request.blueprint not in _guarded_bp_names:
            return None
        # Non-API routes (/, /static, /favicon.ico, /app.bundle.js, etc.) are public SPA assets.
        if not request.path.startswith("/api/"):
            return None
        if request.path.startswith(_public_api_prefixes):
            return None
        auth_header = request.headers.get("Authorization", "")
        session = None
        if auth_header.startswith("Bearer pgx_"):
            session = validate_api_token(auth_header[7:])
        if not session:
            session_id = request.headers.get("X-Session-ID") or request.cookies.get("session_id")
            session = validate_session(session_id)
        if not session:
            return jsonify({"error": "Unauthorized", "code": "AUTH_REQUIRED"}), 401
        request.session = session

        # Spec 038 (US1): force-MFA hard block — when `force_2fa` is on, a user
        # with no enrolled factor is confined to the enrollment endpoints.
        # Server-side enforcement; the frontend flag alone is bypassable.
        denied = _mfa_enrollment_block(session)
        if denied is not None:
            return denied

    for name, bp in _blueprints:
        # Pass an explicit registration name so blueprints whose internal name
        # clashes with a core API blueprint (e.g. vmware vs vmware_integration)
        # can still be mounted without a Flask "name already registered" error.
        app.register_blueprint(bp, name=name)

    if not getattr(app, "_ProxmoxVEx_auth_guard", False):
        app._ProxmoxVEx_auth_guard = True
        app.before_request(_require_auth_for_request)

    # Initialize WebSocket support for realtime blueprint
    from ProxmoxVEx.api.realtime import sock

    sock.init_app(app)

    # Wire push handler into the alerts pipeline
    with contextlib.suppress(Exception):
        register_alert_handler()

    # Drift scanner thread (6h cadence; harmless if mgrs not yet up)
    try:
        start_drift_scanner()
    except Exception as e:
        logging.warning(f"drift scanner start failed: {e}")

    # SIEM forwarder worker
    try:
        start_siem_worker()
    except Exception as e:
        logging.warning(f"siem worker start failed: {e}")

    # Snapshot scheduler (60s tick, idempotent)
    try:
        start_snap_scheduler()
    except Exception as e:
        logging.warning(f"snapshot scheduler start failed: {e}")

    # Native built-in integrations (Docker, NetApp, OPNsense, TrueNAS)
    try:
        from ProxmoxVEx.native import register_native

        register_native(app)
    except Exception as e:
        logging.warning(f"native integrations registration failed: {e}")
