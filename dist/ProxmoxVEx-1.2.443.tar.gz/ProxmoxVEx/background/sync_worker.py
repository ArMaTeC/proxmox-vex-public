# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/background/sync_worker.py
# Project:     ProxmoxVEx
# Version:     1.2.437
# Build:       2026.09.12
# Description: Sync worker with lightweight time-based result caching.
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-12
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Sync worker with lightweight time-based result caching.

860-caching-for-sync-worker: caches the output of expensive sync fetches so
repeated worker runs do not hammer the Proxmox API between sync intervals.
"""

import gzip
import json
import time
from concurrent.futures import ThreadPoolExecutor, as_completed

import requests
from requests.adapters import HTTPAdapter

# 860-caching-for-sync-worker: seconds to keep a sync result set valid.
SYNC_CACHE_TTL = 30.0

# 862-pagination-for-sync-worker: maximum page size allowed for sync worker pagination.
SYNC_PAGINATION_MAX = 100

# 863-batching-for-sync-worker: default number of items to process in one sync batch.
SYNC_BATCH_SIZE = 50

# 866-connection-pooling-for-sync-worker: keep a shared session with a connection
# pool sized for repeated sync worker API calls, avoiding repeated TCP setup/teardown.
SYNC_OPERATIONS_SESSION = requests.Session()

# 867-async-workers-for-sync-worker: number of concurrent sync fetches per run.
SYNC_WORKER_THREADS = 10

# 868-memory-optimisation-for-sync-worker: cap the in-memory sync cache size to
# avoid unbounded memory growth for long-running workers.
SYNC_OPS_CACHE_MAX_SIZE = 100

SYNC_OPERATIONS_SESSION.mount(
    "https://", HTTPAdapter(pool_connections=20, pool_maxsize=100)
)
SYNC_OPERATIONS_SESSION.mount(
    "http://", HTTPAdapter(pool_connections=20, pool_maxsize=100)
)

# Keyed cache for sync worker output: { key: {"data": ..., "time": ...} }
_sync_cache = {}


def _prune_sync_cache_if_needed():
    """Trim the sync cache to keep it under the configured max size."""
    if len(_sync_cache) <= SYNC_OPS_CACHE_MAX_SIZE:
        return
    # Drop the oldest half of the cache by insertion/refresh time.
    keys_by_time = sorted(_sync_cache, key=lambda k: _sync_cache[k]["time"])
    to_remove = keys_by_time[: max(1, len(keys_by_time) // 2)]
    for k in to_remove:
        _sync_cache.pop(k, None)


def get_synced_items(key, fetch_func):
    """Return a cached sync result for `key` or run `fetch_func` and cache it.

    `fetch_func` is a no-argument callable that returns the fresh sync data.
    """
    now = time.monotonic()
    cached = _sync_cache.get(key)
    if cached is not None and (now - cached["time"]) < SYNC_CACHE_TTL:
        return cached["data"]
    _prune_sync_cache_if_needed()
    data = fetch_func()
    _sync_cache[key] = {"data": data, "time": now}
    return data


def get_synced_items_lazy(key, page, per_page, fetch_func):
    """Return a paginated slice of the cached sync result for `key`.

    861-lazy-loading-for-sync-worker: avoids loading the entire dataset into a
    consumer at once by returning a bounded `page`/`per_page` window.
    """
    all_items = get_synced_items(key, fetch_func)
    if not isinstance(all_items, list):
        return {"page": page, "per_page": per_page, "total": 0, "items": []}

    per_page = max(1, min(int(per_page), SYNC_PAGINATION_MAX))
    page = max(1, int(page))
    total = len(all_items)
    start = (page - 1) * per_page
    end = start + per_page
    return {
        "page": page,
        "per_page": per_page,
        "total": total,
        "items": all_items[start:end],
    }


def get_synced_items_batches(key, fetch_func, batch_size=SYNC_BATCH_SIZE):
    """Yield bounded batches of the cached sync result for `key`.

    863-batching-for-sync-worker: splits a large sync result set into batches
    so downstream consumers can process them incrementally.
    """
    all_items = get_synced_items(key, fetch_func)
    if not isinstance(all_items, list):
        return
    batch_size = max(1, int(batch_size))
    for i in range(0, len(all_items), batch_size):
        yield all_items[i : i + batch_size]


def get_synced_items_index(key, fetch_func, id_field="id"):
    """Return the cached sync result for `key` indexed by `id_field`.

    864-indexing-for-sync-worker: build an O(1) lookup table of sync items by
    the configured id field for fast direct access.
    """
    all_items = get_synced_items(key, fetch_func)
    if not isinstance(all_items, list):
        return {}
    return {str(item.get(id_field)): item for item in all_items if item.get(id_field) is not None}


def get_synced_items_compressed(key, fetch_func):
    """Return a gzip-compressed JSON payload of the cached sync result for `key`.

    865-compression-for-sync-worker: reduce payload size for large sync result
    sets when transferring them over the network or storing in a cache.
    """
    all_items = get_synced_items(key, fetch_func)
    payload = json.dumps({"ok": True, "data": all_items}, default=str).encode("utf-8")
    return gzip.compress(payload)


def run_synced_fetches(fetch_jobs):
    """Run multiple sync fetches concurrently and return results by key.

    867-async-workers-for-sync-worker: `fetch_jobs` is a list of tuples
    (key, fetch_func); this function warms the cache in parallel and returns
    a dict mapping each key to its cached value.
    """
    results = {}
    with ThreadPoolExecutor(max_workers=SYNC_WORKER_THREADS) as executor:
        futures = {executor.submit(get_synced_items, key, func): key for key, func in fetch_jobs}
        for future in as_completed(futures):
            key = futures[future]
            try:
                results[key] = future.result()
            except Exception as exc:  # pragma: no cover
                results[key] = {"error": str(exc)}
    return results


def get_synced_items_since(key, fetch_func, since, time_field="last_update"):
    """Return sync results for `key` with `time_field` newer than `since`.

    869-incremental-updates-for-sync-worker: supports sync clients that only
    need items changed after a previously seen timestamp.
    """
    all_items = get_synced_items(key, fetch_func)
    if not isinstance(all_items, list):
        return []
    return [item for item in all_items if item.get(time_field, 0) >= since]


def invalidate_sync_cache(key=None):
    """Invalidate the sync cache for one key or for all keys."""
    if key is None:
        _sync_cache.clear()
    else:
        _sync_cache.pop(key, None)
