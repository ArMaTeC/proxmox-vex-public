# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/background/broadcast.py
# Project:     ProxmoxVEx
# Version:     1.2.437
# Build:       2026.09.12
# Description: ProxmoxVEx Broadcast Thread - Layer 7
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-12
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""
ProxmoxVEx Broadcast Thread - Layer 7
SSE/WebSocket resource broadcast loop.
"""

import contextlib
import logging
import os
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime

from ProxmoxVEx.globals import (
    cluster_managers,
    sse_clients,
    vmware_managers,
)
from ProxmoxVEx.utils.realtime import broadcast_sse


def _watched_clusters():
    """Cluster IDs at least one live SSE/WS client is subscribed to (None = an
    all-access client → poll everything). Single source of truth now lives in
    utils.realtime so the per-cluster background refreshers share it. #528 / H4."""
    from ProxmoxVEx.utils.realtime import watched_clusters

    return watched_clusters()


# 2026-06-05 (#528 scaling): per-cluster "broadcast greenlet in flight" flags.
# The loop spawns one greenlet per cluster every ~1s; a slow-but-not-erroring
# cluster (the cooldown only catches erroring ones) would otherwise stack a fresh
# greenlet every second behind the stuck one. We skip re-spawning a cluster whose
# previous greenlet hasn't finished yet.
_broadcast_inflight = {}

# Map portal audit actions to task-like type strings
_AUDIT_ACTION_MAP = {
    "portal.vm.start": "portalstart",
    "portal.vm.stop": "portalstop",
    "portal.vm.shutdown": "portalshutdown",
    "portal.vm.reboot": "portalreboot",
    "portal.snapshot_created": "portalsnapshot",
    "portal.snapshot_rollback": "portalrollback",
    "portal.snapshot_deleted": "portalsnapshotdel",
    "portal.password_changed": "portalpassword",
}


def _get_recent_audit_tasks(cluster_id, cluster_name):
    """Convert recent audit log entries into task-like objects for the task bar"""
    try:
        from ProxmoxVEx.core.db import get_db

        db = get_db()
        cursor = db.conn.cursor()
        # only last 2 minutes of portal + console events
        cutoff = (datetime.now() - __import__("datetime").timedelta(minutes=2)).isoformat()
        cursor.execute(
            """
            SELECT id, timestamp, user, action, details FROM audit_log
            WHERE action LIKE 'portal.%'
            AND timestamp > ?
            ORDER BY timestamp DESC LIMIT 10
        """,
            (cutoff,),
        )
        rows = cursor.fetchall()
        if not rows:
            return []
        results = []
        for row in rows:
            aid, ts, user, action, details = row
            task_type = _AUDIT_ACTION_MAP.get(action, action)
            # extract vmid from details if present
            vmid = ""
            import re

            m = re.search(r"VM (\d+)", details or "")
            if m:
                vmid = m.group(1)
            results.append({
                "upid": f"audit-{aid}",
                "node": "",
                "type": task_type,
                "status": "stopped",  # completed
                "starttime": int(datetime.fromisoformat(ts).timestamp()) if ts else 0,
                "endtime": int(datetime.fromisoformat(ts).timestamp()) if ts else 0,
                "user": "",
                "ProxmoxVEx_user": user,
                "id": vmid,
                "vmid": int(vmid) if vmid else 0,
                "exitstatus": "OK",
                "cluster_id": cluster_id,
                "_portal": True,  # marker so frontend can style differently
            })
        return results
    except Exception:
        return []


def broadcast_resources_loop():
    """Periodically broadcast resource updates to all connected SSE clients"""
    print("=" * 50)
    print("SSE BROADCAST LOOP STARTED")
    print("=" * 50)
    logging.info("SSE broadcast loop started")

    loop_count = 0
    while True:
        try:
            client_count = len(sse_clients)
            if not sse_clients:
                time.sleep(2)
                continue

            loop_count += 1

            if loop_count % 10 == 1:  # Log every 10th loop
                logging.debug(f"[SSE] Broadcasting to {client_count} clients (loop {loop_count})")

            # Periodic ticket refresh (Proxmox tickets expire after 2h)
            # Re-authenticate every 90 minutes to prevent stale tickets
            if loop_count % 5400 == 0:  # 5400 loops × 1s = 90 minutes
                for cid, mgr in list(cluster_managers.items()):
                    if mgr.is_connected and not getattr(mgr, "_using_api_token", False):
                        try:
                            logging.info(f"[SSE] Refreshing Proxmox ticket for cluster '{cid}'")
                            mgr.connect_to_proxmox()
                        except Exception as e:
                            logging.warning(f"[SSE] Ticket refresh failed for '{cid}': {e}")

            # VMware keepalive. Customers reported ProxmoxVEx losing
            # the ESXi connection over time; ESXi defaults to a 30-min idle session
            # timeout. Run ensure_connected() (which now includes a cheap session
            # ping) every ~4 min on a worker thread so a slow vCenter can't stall
            # the broadcast loop.
            if vmware_managers and loop_count % 240 == 0:

                def _vmware_keepalive_tick():
                    for vmw_id, vmw_mgr in list(vmware_managers.items()):
                        try:
                            ok = vmw_mgr.ensure_connected()
                            if not ok:
                                logging.debug(f"[VMware:{vmw_id}] keepalive: not connected")
                        except Exception as e:
                            logging.debug(f"[VMware:{vmw_id}] keepalive error: {e}")

                threading.Thread(target=_vmware_keepalive_tick, daemon=True).start()

            def broadcast_for_cluster(cid, mgr, loop_count=loop_count):
                """Broadcast updates for a single cluster - runs in own thread"""
                try:
                    # When a cluster's API calls have been timing out,
                    # back off so we don't spawn 1 thread per second waiting on the
                    # same dead TCP connection. Cooldown is per-mgr.
                    now = time.time()
                    cooldown_until = getattr(mgr, "_sse_cooldown_until", 0)
                    if now < cooldown_until:
                        # still in cooldown — don't poke, but tell client we're alive
                        broadcast_sse("tasks", [], cid)
                        return
                    # AUTO-RECONNECT disconnected clusters
                    # Without this, a network reload (ifreload) permanently kills the connection
                    # until ProxmoxVEx is restarted. Now we retry every 10 seconds.
                    # 2026-05-31 - log backoff. Previously the "is disconnected,
                    # attempting reconnect..." INFO line fired every 10s while a
                    # cluster stayed down → ~360 INFO entries per hour per dead
                    # cluster filling up the log file. Now: INFO on the first
                    # attempt + once every 50 attempts (~8min) for ongoing
                    # visibility, DEBUG in between. Reconnect cadence itself is
                    # unchanged.
                    if not mgr.is_connected:
                        if now - mgr._last_reconnect_attempt >= 10:
                            mgr._last_reconnect_attempt = now
                            attempt_count = getattr(mgr, "_reconnect_attempt_count", 0) + 1
                            mgr._reconnect_attempt_count = attempt_count
                            _attempt_log = (
                                logging.info if attempt_count == 1 or attempt_count % 50 == 0 else logging.debug
                            )
                            _attempt_log(
                                f"[SSE] Cluster '{cid}' is disconnected, attempting reconnect (try #{attempt_count})..."
                            )
                            try:
                                if mgr.connect_to_proxmox():
                                    logging.info(
                                        f"[SSE] Cluster '{cid}' reconnected successfully "
                                        f"after {attempt_count} attempt(s)!"
                                    )
                                    mgr._reconnect_attempt_count = 0
                                    mgr._sse_cooldown_until = 0  # clear any pending cooldown
                                    # only notify if last broadcast was >60s ago (avoid toast spam on WAN)
                                    last_notified = getattr(mgr, "_last_reconnect_broadcast", 0)
                                    if now - last_notified >= 60:
                                        mgr._last_reconnect_broadcast = now
                                        broadcast_sse(
                                            "node_status",
                                            {
                                                "event": "cluster_reconnected",
                                                "cluster_id": cid,
                                                "message": "Connection to cluster restored",
                                            },
                                            cid,
                                        )
                                    # 2026-05-31 - push a fresh metrics
                                    # snapshot immediately so the UI flips
                                    # to "online" without waiting one full
                                    # loop tick. Worst case the next-loop
                                    # broadcast just re-confirms.
                                    try:
                                        _fresh = mgr.get_node_status()
                                        if _fresh:
                                            broadcast_sse("metrics", _fresh, cid)
                                    except Exception:
                                        pass
                                else:
                                    logging.debug(f"[SSE] Cluster '{cid}' reconnect failed, will retry in 10s")
                            except Exception as e:
                                logging.debug(f"[SSE] Cluster '{cid}' reconnect error: {e}")

                        if not mgr.is_connected:
                            # Still disconnected - send empty data so UI knows
                            broadcast_sse("tasks", [], cid)
                            return

                    # Get tasks every loop - but only broadcast if changed
                    # Wrap in try/except so a single hung call
                    # doesn't kill the whole broadcast for this cluster.
                    try:
                        tasks = mgr.get_tasks(limit=50)
                    except Exception as e:
                        logging.debug(f"[SSE] {cid} get_tasks failed: {e}")
                        # cooldown so we don't hammer a hung host
                        mgr._sse_cooldown_until = time.time() + 10
                        broadcast_sse("tasks", [], cid)
                        return
                    task_list = tasks or []

                    # Inject recent portal/audit actions as virtual tasks
                    # so admins can see what customers are doing in their task bar
                    try:
                        audit_tasks = _get_recent_audit_tasks(cid, mgr.config.name)
                        if audit_tasks:
                            task_list = task_list + audit_tasks
                    except Exception:
                        pass

                    # Deduplicate: only broadcast if tasks actually changed
                    task_hash = hash(tuple((t.get("upid", ""), t.get("status", "")) for t in task_list[:20]))
                    prev_hash = getattr(mgr, "_last_task_hash", None)
                    if task_hash != prev_hash or loop_count % 10 == 0:
                        mgr._last_task_hash = task_hash
                        broadcast_sse("tasks", task_list, cid)

                    # Get metrics every loop
                    metrics_ok = False
                    try:
                        metrics = mgr.get_node_status()
                        if metrics:
                            metrics_ok = True
                            # Dedup like tasks (SSE-perf): node cpu/mem
                            # jitter every fetch, so bucket coarsely (status / 5% cpu /
                            # 2% mem) and only push when a node's bucketed state moved,
                            # or every 10th loop as a keepalive (slow fields + new clients).
                            try:
                                m_hash = hash(
                                    tuple(
                                        (
                                            name,
                                            (d or {}).get("status", ""),
                                            int((d or {}).get("cpu_percent") or 0) // 5,
                                            int((d or {}).get("mem_percent") or 0) // 2,
                                        )
                                        for name, d in sorted(metrics.items())
                                    )
                                )
                            except Exception:
                                m_hash = None
                            if (
                                m_hash is None
                                or m_hash != getattr(mgr, "_last_metrics_hash", None)
                                or loop_count % 10 == 0
                            ):
                                mgr._last_metrics_hash = m_hash
                                broadcast_sse("metrics", metrics, cid)
                    except Exception as e:
                        # Surface this in debug; cooldown if frequent
                        logging.debug(f"[SSE] {cid} get_node_status failed: {e}")
                        mgr._sse_cooldown_until = time.time() + 10

                    # Resources every loop now (was every 2nd loop)
                    # This makes VM status update much faster in the UI
                    # 2s short-cache so the ~1s broadcast loop doesn't re-walk
                    # the whole cluster for every tick; push_immediate_update
                    # still calls without max_age to keep action feedback instant.
                    # Fixed - was calling get_all_resources() which doesn't exist!
                    try:
                        resources = mgr.get_vm_resources(max_age=2.0)
                        if resources:
                            # Dedup like tasks (SSE-perf). At 10k VMs the
                            # full list is a ~3MB json.dumps every second; bucket the noisy
                            # cpu/mem and only broadcast when a guest's status/node/name or
                            # bucketed load changed, or every 10th loop (keepalive for
                            # ip/tags + newly-connected clients). Cuts steady-state hub
                            # serialize + SSE bandwidth ~90% on a quiet estate. The
                            # after-action push_immediate_update() bypasses this gate
                            # (calls broadcast_sse directly) so action feedback stays instant.
                            try:
                                r_hash = hash(
                                    tuple(
                                        (
                                            r.get("vmid"),
                                            r.get("status", ""),
                                            r.get("node", ""),
                                            r.get("name", ""),
                                            int(r.get("cpu_percent") or 0) // 5,
                                            int(r.get("mem_percent") or 0) // 2,
                                        )
                                        for r in resources
                                    )
                                )
                            except Exception:
                                r_hash = None
                            if (
                                r_hash is None
                                or r_hash != getattr(mgr, "_last_resource_hash", None)
                                or loop_count % 10 == 0
                            ):
                                mgr._last_resource_hash = r_hash
                                broadcast_sse("resources", resources, cid)
                            # Reset stale counter on success
                            mgr._consecutive_empty_responses = 0
                        elif metrics_ok:
                            # (#554 Thermal-spearhead): get_vm_resources()
                            # also returns [] for a node that simply has no VMs/CTs — not
                            # only for a stale ticket. If node-status came back this same
                            # loop the ticket is clearly valid, so an empty guest list is
                            # legitimate. Don't churn an endless ~33s re-auth loop on an
                            # idle/empty node; only treat empty as stale when metrics are
                            # ALSO empty (the real 401-without-exception case).
                            mgr._consecutive_empty_responses = 0
                        else:
                            # Track empty responses while "connected"
                            # This catches stale tickets (Proxmox returns 401 but no exception)
                            mgr._consecutive_empty_responses = getattr(mgr, "_consecutive_empty_responses", 0) + 1
                            if mgr._consecutive_empty_responses >= 30:  # ~30s of empty data, WAN needs more tolerance
                                logging.warning(
                                    f"[SSE] Cluster '{cid}' returning empty data despite being 'connected' - forcing re-auth"
                                )
                                mgr._consecutive_empty_responses = 0
                                mgr.is_connected = False  # Force reconnect on next loop
                    except Exception:
                        pass

                except Exception as e:
                    logging.debug(f"Error broadcasting updates for {cid}: {e}")
                finally:
                    _broadcast_inflight[cid] = False

            # Run each cluster broadcast in its own thread with 8s max
            # Prevents one slow/timing-out cluster from blocking all SSE updates
            # 2026-06-05 (#528 scaling): only poll clusters someone is actually
            # viewing. None = a client has all-access subscription → poll all.
            watched = _watched_clusters()
            threads = []
            for cluster_id, manager in list(cluster_managers.items()):
                # nobody is subscribed to this cluster — its events would reach
                # no client, so skip the per-node fan-out + serialize entirely
                if watched is not None and cluster_id not in watched:
                    continue
                # skip if this cluster's previous broadcast greenlet is still
                # running (slow cluster) — avoids piling up one per second (#528)
                if _broadcast_inflight.get(cluster_id):
                    continue
                _broadcast_inflight[cluster_id] = True
                t = threading.Thread(target=broadcast_for_cluster, args=(cluster_id, manager), daemon=True)
                t.start()
                threads.append(t)

            # Wait for all threads, but max 8 seconds
            for t in threads:
                t.join(timeout=8)

            # ============================================================
            # VMware SSE: Push VMware data in background threads
            # to avoid blocking Proxmox metrics broadcasts
            # ============================================================
            vmware_sse_counter = getattr(broadcast_resources_loop, "_vmw_counter", 0) + 1
            broadcast_resources_loop._vmw_counter = vmware_sse_counter

            if vmware_sse_counter % 10 == 0 and vmware_managers:

                def _vmware_sse_push(loop_count=loop_count):
                    try:
                        vmw_list = []
                        for vmw_id, vmw_mgr in list(vmware_managers.items()):
                            with contextlib.suppress(Exception):
                                vmw_list.append({
                                    "id": vmw_id,
                                    "name": getattr(vmw_mgr, "name", vmw_id),
                                    "host": getattr(vmw_mgr, "host", ""),
                                    "connected": getattr(vmw_mgr, "connected", False),
                                    "type": getattr(vmw_mgr, "server_type", "vcenter"),
                                })
                        if vmw_list:
                            broadcast_sse("vmware_servers", vmw_list)
                        for vmw_id, vmw_mgr in list(vmware_managers.items()):
                            try:
                                if not getattr(vmw_mgr, "connected", False):
                                    # Auto-reconnect mirrors Proxmox path.
                                    # Otherwise a transient ESXi blip leaves us "disconnected"
                                    # forever until the user restarts ProxmoxVEx.
                                    try:
                                        if not vmw_mgr.ensure_connected():
                                            continue
                                    except Exception:
                                        continue
                                result = vmw_mgr.get_vms()
                                if "error" not in result:
                                    broadcast_sse("vmware_vms", {"vmware_id": vmw_id, "vms": result.get("data", [])})
                            except Exception as e:
                                logging.debug(f"[SSE] VMware VMs broadcast failed for {vmw_id}: {e}")
                    except Exception as e:
                        logging.debug(f"[SSE] VMware broadcast error: {e}")

                threading.Thread(target=_vmware_sse_push, daemon=True).start()

            if vmware_sse_counter % 5 == 0:

                def _vmware_detail_push(loop_count=loop_count):
                    # ISS-069: skip this cycle entirely if a previous detail push is
                    # still in flight — otherwise detached threads pile up when a
                    # vCenter call stalls, and N sequential calls per watched VM
                    # multiplied the in-flight count without bound.
                    inflight = getattr(broadcast_resources_loop, "_vmw_detail_inflight", None)
                    if inflight is None:
                        inflight = threading.Event()
                        broadcast_resources_loop._vmw_detail_inflight = inflight
                    if inflight.is_set():
                        return
                    inflight.set()
                    try:
                        max_detail = int(os.environ.get("PROXMOXVEX_VMW_DETAIL_MAX", 20))
                        watched = getattr(broadcast_resources_loop, "_vmw_watched", {})
                        now = time.time()
                        items = []
                        for (vmw_id, vm_id), last_time in list(watched.items()):
                            if now - last_time > 120:
                                del watched[vmw_id, vm_id]
                                continue
                            items.append((vmw_id, vm_id))
                        for vmw_id, vm_id in items[:max_detail]:
                            if vmw_id not in vmware_managers:
                                continue
                            vmw_mgr = vmware_managers[vmw_id]
                            if not getattr(vmw_mgr, "connected", False):
                                continue
                            try:
                                result = vmw_mgr.get_vm(vm_id)
                                if "error" not in result:
                                    data = result.get("data", {})
                                    # ISS-069: the three vCenter calls per VM ran
                                    # sequentially; run guest-info and perf in
                                    # parallel so one slow call doesn't triple the
                                    # per-VM latency.
                                    with ThreadPoolExecutor(max_workers=2) as ex:
                                        f_guest = ex.submit(vmw_mgr.get_vm_guest_info, vm_id)
                                        f_perf = ex.submit(vmw_mgr.get_vm_performance, vm_id)
                                        guest = f_guest.result(timeout=15)
                                        perf = f_perf.result(timeout=15)
                                    if "error" not in guest:
                                        data["guest_info"] = guest.get("data", {})
                                    if "error" not in perf:
                                        data["performance"] = perf.get("data", {})
                                    broadcast_sse(
                                        "vmware_vm_detail", {"vmware_id": vmw_id, "vm_id": vm_id, "data": data}
                                    )
                            except Exception as e:
                                logging.debug(f"[SSE] VMware detail fetch failed for vm {vm_id}: {e}")
                        broadcast_resources_loop._vmw_watched = watched
                    except Exception as e:
                        logging.debug(f"[SSE] VMware detail broadcast error: {e}")
                    finally:
                        inflight.clear()

                threading.Thread(target=_vmware_detail_push, daemon=True).start()

            # Periodic heartbeat. Lets the frontend distinguish
            # "server still ticking, just no data" from "server dead". Frontend
            # watchdog force-reconnects if no message for >30s.
            # (#484) - was `loop_count % 5 == 0`. With a dead node
            # in the cluster the per-cluster fan-out can wall on the join(8s)
            # timeout for every cycle, so heartbeat-every-5-loops drifts out
            # to ~40s between beats and the frontend's 30s wedge fires. Cost
            # of one tiny SSE message per second is negligible, just send it.
            with contextlib.suppress(Exception):
                broadcast_sse("heartbeat", {"ts": time.time(), "loop": loop_count})

            # Reduced to 1 second for faster task updates
            # Proxmox API can handle this - it's just GET requests
            time.sleep(1)

        except Exception as e:
            logging.error(f"Broadcast loop error: {e}")
            time.sleep(5)


# Start broadcast thread when module loads
_broadcast_thread = None


def start_broadcast_thread():
    global _broadcast_thread
    if _broadcast_thread is None or not _broadcast_thread.is_alive():
        _broadcast_thread = threading.Thread(target=broadcast_resources_loop, daemon=True)
        _broadcast_thread.start()
