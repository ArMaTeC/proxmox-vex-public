# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/utils/stepup.py
# Project:     ProxmoxVEx
# Version:     1.2.437
# Build:       2026.09.12
# Description: Step-up MFA for destructive actions (spec 038).
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-12
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Step-up MFA for destructive actions (spec 038).

When ``mfa_stepup_enabled`` is set in server settings, endpoints tagged with a
destructive category must be re-authorized with a fresh second factor. A
successful check stamps a session-bound elevation (``elevated_until``) so
follow-up destructive calls inside the configured window don't re-prompt.

Elevation deliberately lives on the in-memory session dict: it dies with the
session and consults the live setting, so disabling the feature revokes all
outstanding elevations immediately.
"""

import logging
import time

from flask import jsonify, request

# Session keys (see data-model.md)
ELEVATED_UNTIL = "elevated_until"
ELEVATED_METHOD = "elevated_method"
ELEVATED_AT = "elevated_at"

# Hard cap on the admin-configurable window; 0 = challenge every action.
MAX_WINDOW_MINUTES = 15

_EXTERNAL_AUTH_SOURCES = ("oidc", "entra")


def _load_settings():
    from ProxmoxVEx.api.helpers import load_server_settings

    return load_server_settings() or {}


def stepup_window_seconds() -> int:
    """Effective elevation window in seconds, clamped to [0, MAX_WINDOW_MINUTES]."""
    try:
        minutes = int(_load_settings().get("mfa_stepup_window_minutes", 5))
    except (TypeError, ValueError):
        minutes = 5
    return max(0, min(MAX_WINDOW_MINUTES, minutes)) * 60


def category_enabled(category: str, settings=None) -> bool:
    """True when step-up is globally on AND the category toggle is on.

    Unknown/missing category keys default to enabled so newly added categories
    start protected rather than silently uncovered.
    """
    settings = settings if settings is not None else _load_settings()
    if not settings.get("mfa_stepup_enabled"):
        return False
    cats = settings.get("mfa_stepup_categories") or {}
    return bool(cats.get(category, True))


def is_elevated(session: dict) -> bool:
    """Session holds a live elevation. Consults the live setting — if the
    feature or all categories were switched off after elevation was granted,
    this returns False (immediate revocation on disable)."""
    until = session.get(ELEVATED_UNTIL, 0) or 0
    return until > time.time()


def grant_elevation(session: dict, method: str) -> float:
    """Stamp the session with an elevation for the configured window."""
    now = time.time()
    session[ELEVATED_AT] = now
    session[ELEVATED_UNTIL] = now + stepup_window_seconds()
    session[ELEVATED_METHOD] = method
    return session[ELEVATED_UNTIL]


def revoke_elevation(session: dict) -> None:
    for key in (ELEVATED_UNTIL, ELEVATED_METHOD, ELEVATED_AT):
        session.pop(key, None)


def _user_has_factor(username: str, user: dict) -> bool:
    if user.get("totp_enabled") and user.get("totp_secret"):
        return True
    try:
        from ProxmoxVEx.core.db import get_db

        row = get_db().query_one(
            "SELECT COUNT(*) AS n FROM webauthn_credentials WHERE username = ?",
            (username,),
        )
        return bool(row and row["n"] > 0)
    except Exception as e:
        logging.debug(f"stepup: webauthn credential count failed for {username}: {e}")
        return False


def enrolled_methods(username: str, user: dict) -> list:
    methods = []
    if user.get("totp_enabled") and user.get("totp_secret"):
        methods.append("totp")
    try:
        from ProxmoxVEx.core.db import get_db

        row = get_db().query_one(
            "SELECT COUNT(*) AS n FROM webauthn_credentials WHERE username = ?",
            (username,),
        )
        if row and row["n"] > 0:
            methods.append("webauthn")
    except Exception as e:
        logging.debug(f"stepup: webauthn credential count failed for {username}: {e}")
    return methods


def _acting_user(session: dict) -> dict:
    """Resolve the session's user record (same lookup style as require_auth)."""
    username = session.get("user", "")
    try:
        from ProxmoxVEx.core.db import get_db

        user = get_db().get_user(username)
        if user:
            return user
    except Exception as e:
        logging.debug(f"stepup: get_user({username}) failed: {e}")
    try:
        from ProxmoxVEx.utils.auth import load_users

        return load_users().get(username) or {}
    except Exception as e:
        logging.debug(f"stepup: load_users fallback failed: {e}")
        return {}


def require_stepup(category: str):
    """Guard for destructive endpoints. Call after @require_auth checks.

    Returns None when the request may proceed, else a Flask response the
    caller must return immediately. Denials never reach the action — the
    guard runs before any manager call.
    """
    if not category_enabled(category):
        return None

    session = getattr(request, "session", None) or {}
    username = session.get("user", "")
    user = _acting_user(session)

    # External IdP users can't satisfy a local factor — exempt per spec.
    if user.get("auth_source", "local") in _EXTERNAL_AUTH_SOURCES:
        return None

    if is_elevated(session):
        return None

    methods = enrolled_methods(username, user)
    if not methods:
        logging.warning(f"stepup: {username} attempted '{category}' action with no enrolled factor")
        try:
            from ProxmoxVEx.utils.audit import log_audit

            log_audit(username, "mfa.stepup.denied", f"'{category}' blocked - no enrolled MFA factor")
        except Exception as e:
            logging.debug(f"stepup: audit log failed: {e}")
        return jsonify({
            "requires_stepup": True,
            "enrollment_required": True,
            "category": category,
            "methods": [],
            "error": "MFA enrollment required before destructive actions",
        }), 403

    logging.info(f"stepup: {username} requires MFA for '{category}' action")
    try:
        from ProxmoxVEx.utils.audit import log_audit

        log_audit(username, "mfa.stepup.denied", f"'{category}' blocked pending step-up verification")
    except Exception as e:
        logging.debug(f"stepup: audit log failed: {e}")
    return jsonify({
        "requires_stepup": True,
        "category": category,
        "methods": methods,
        "window_minutes": stepup_window_seconds() // 60,
    }), 403
