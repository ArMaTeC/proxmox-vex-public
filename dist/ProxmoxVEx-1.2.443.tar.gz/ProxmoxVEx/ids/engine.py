# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/ids/engine.py
# Project:     ProxmoxVEx
# Version:     1.2.437
# Build:       2026.09.12
# Description: Signature and anomaly analysis engine for the IDS/IPS...
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-12
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Signature and anomaly analysis engine for the IDS/IPS module."""

import json
import logging
from collections import Counter, defaultdict
from typing import Any, Dict, List

from ProxmoxVEx.ids import models

logger = logging.getLogger(__name__)


def _match_signature(packet: Dict[str, Any], rule: Dict[str, Any]) -> bool:
    """Evaluate a simple signature rule against a packet dict.

    Signatures are a list of conditions separated by ',' or ';'. Supported keys:
    - dport, sport, source, destination, payload_size: exact match
    - content: substring search in packet.get('payload') or packet.get('data')
    - flow: exact match on packet direction (to_server / to_client / any)
    """
    signature = rule.get("signature") or ""
    if not signature:
        return False
    separator = ";" if ";" in signature else ","
    for part in signature.split(separator):
        part = part.strip()
        if not part or "=" not in part:
            continue
        key, value = part.split("=", 1)
        key = key.strip()
        value = value.strip()

        if key == "content":
            haystack = str(packet.get("payload") or packet.get("data") or "")
            if value not in haystack:
                return False
            continue

        if key == "flow":
            actual = str(packet.get("flow") or packet.get("direction") or "")
            if value != "any" and actual != value:
                return False
            continue

        actual = str(packet.get(key, ""))
        allowed = [v.strip() for v in value.split(",")]
        try:
            if int(actual) not in [int(v) for v in allowed]:
                return False
        except (ValueError, TypeError):
            if actual not in allowed:
                return False
    return True


def _detect_baseline_anomalies(
    packets: List[Dict[str, Any]], threshold_overrides: Dict[str, Any] = None
) -> List[Dict[str, Any]]:
    """Detect port scan, DoS, brute force and large payload patterns."""
    thresholds = threshold_overrides or {}
    alerts = []
    by_source = defaultdict(list)
    by_src_dst = defaultdict(list)
    for pkt in packets:
        src = pkt.get("source")
        if src:
            by_source[src].append(pkt)
        dst = pkt.get("destination")
        if src and dst:
            by_src_dst[(src, dst)].append(pkt)

    scan_threshold = int(thresholds.get("scan_threshold", 20))
    dos_threshold = int(thresholds.get("dos_threshold", 50))
    brute_threshold = int(thresholds.get("brute_threshold", 15))
    payload_threshold = int(thresholds.get("payload_threshold", 1500))

    for src, pkts in by_source.items():
        unique_ports = {p.get("dport") for p in pkts if p.get("dport") is not None}
        if len(unique_ports) >= scan_threshold:
            alerts.append({
                "threat_type": "port_scan",
                "severity": "high",
                "source": src,
                "destination": pkts[0].get("destination", ""),
                "context": {"unique_ports": len(unique_ports)},
            })
        total = len(pkts)
        if total >= dos_threshold:
            alerts.append({
                "threat_type": "dos",
                "severity": "critical",
                "source": src,
                "destination": pkts[0].get("destination", ""),
                "context": {"packet_count": total},
            })

    for (src, dst), pkts in by_src_dst.items():
        ports = [p.get("dport") for p in pkts if p.get("dport") is not None]
        port_counts = Counter(ports)
        for dport, count in port_counts.items():
            if dport == 22 and count >= brute_threshold:
                alerts.append({
                    "threat_type": "brute_force",
                    "severity": "high",
                    "source": src,
                    "destination": dst,
                    "context": {"dport": dport, "attempts": count},
                })

    for pkt in packets:
        if pkt.get("payload_size", 0) > payload_threshold:
            alerts.append({
                "threat_type": "suspicious_payload",
                "severity": "medium",
                "source": pkt.get("source", ""),
                "destination": pkt.get("destination", ""),
                "context": {"payload_size": pkt.get("payload_size", 0)},
            })

    return alerts


def _rule_threshold(rule: Dict[str, Any]) -> int:
    """Return the signature threshold for a rule, defaulting to 1."""
    raw = rule.get("anomaly_config") or {}
    if isinstance(raw, str):
        try:
            raw = json.loads(raw) or {}
        except (json.JSONDecodeError, TypeError):
            raw = {}
    return int(raw.get("threshold", 1)) if raw else 1


def _prepare_packets(packets: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Normalise packet fields for consistent signature matching."""
    for pkt in packets:
        for key in ("dport", "sport"):
            try:
                if pkt.get(key) is not None:
                    pkt[key] = int(pkt[key])
            except (ValueError, TypeError):
                pass
    return packets


def analyze_traffic(
    segment_id: int, packets: List[Dict[str, Any]], threshold_overrides: Dict[str, Any] = None
) -> List[Dict[str, Any]]:
    """Analyze a batch of packets/flows and return detected alerts."""
    logger.debug("Analyzing %s packets for segment %s", len(packets), segment_id)
    if not packets:
        return []

    packets = _prepare_packets(packets)
    # Drop packets from source IPs the operator has manually blocked.
    packets = [p for p in packets if not models.is_blocked(p.get("source"))]
    rules = models.list_rules()
    alerts: List[Dict[str, Any]] = []

    # Count signature matches per rule per source so threshold rules don't
    # fire for every single packet.
    rule_hits: Dict[int, Dict[str, int]] = {}
    for rule in rules:
        if rule.get("rule_type") != "signature":
            continue
        rule_id = rule["id"]
        rule_hits[rule_id] = {}
        for pkt in packets:
            if _match_signature(pkt, rule):
                src = pkt.get("source", "")
                rule_hits[rule_id][src] = rule_hits[rule_id].get(src, 0) + 1

    for rule in rules:
        if rule.get("rule_type") != "signature":
            continue
        threshold = _rule_threshold(rule)
        for src, count in rule_hits.get(rule["id"], {}).items():
            if count >= threshold:
                alerts.append({
                    "rule_id": rule["id"],
                    "threat_type": rule.get("threat_type", "unknown"),
                    "severity": rule.get("severity", "medium"),
                    "source": src,
                    "destination": "",
                    "context": {"matches": count, "threshold": threshold},
                })

    alerts.extend(_detect_baseline_anomalies(packets, threshold_overrides))
    return alerts
