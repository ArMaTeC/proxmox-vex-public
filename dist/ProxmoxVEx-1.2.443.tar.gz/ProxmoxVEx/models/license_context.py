# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/models/license_context.py
# Project:     ProxmoxVEx
# Version:     1.2.437
# Build:       2026.09.12
# Description: License context model for the main ProxmoxVEx application.
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-12
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""License context model for the main ProxmoxVEx application."""

import contextlib
from dataclasses import dataclass
from datetime import datetime
from typing import Optional


@dataclass
class LicenseContext:
    node_id: str
    license_key: str
    tier_slug: str
    tier_name: str
    valid_until: Optional[datetime]
    purchased_at: Optional[datetime]
    billing_period: str
    customer_email: Optional[str]
    last_validated_at: datetime
    next_check_at: datetime


def ensure_license_context_table(conn) -> None:
    """Create the license_context table if it does not yet exist."""
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS license_context (
            node_id TEXT PRIMARY KEY,
            license_key_encrypted TEXT NOT NULL,
            tier_slug TEXT NOT NULL,
            tier_name TEXT NOT NULL,
            valid_until TEXT,
            purchased_at TEXT,
            billing_period TEXT,
            customer_email TEXT,
            last_validated_at TEXT NOT NULL,
            next_check_at TEXT NOT NULL
        )
        """
    )
    # Migration: add purchased_at, billing_period, and customer_email columns to
    # older tables.  Inspect the column list first instead of blindly running
    # ALTER: on Postgres a failed statement aborts the transaction, so the
    # suppressed errors were rolling back the CREATE TABLE above (this is why
    # fresh Postgres DBs — e.g. the demo sandbox — never got the table).
    with contextlib.suppress(Exception):
        cur = conn.execute("PRAGMA table_info(license_context)")
        existing = {row[1] for row in cur.fetchall()}
        for col in ("purchased_at", "billing_period", "customer_email"):
            if col not in existing:
                conn.execute(f"ALTER TABLE license_context ADD COLUMN {col} TEXT")  # nosec: B608 - column names are hardcoded above
