#!/usr/bin/env python3
# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/integrations/tailscale.py
# Project:     ProxmoxVEx
# Version:     1.2.437
# Build:       2026.09.12
# Description: Tailscale tailnet visibility: connector, device...
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-12
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Tailscale tailnet visibility: connector, device inventory/posture, subnet routers/exit nodes, policy drift, workload links (spec 025)."""

import html

from flask import Blueprint, jsonify, request

from ProxmoxVEx.api.auth import require_auth
from ProxmoxVEx.api.clusters import check_cluster_access, cluster_managers
from ProxmoxVEx.utils.audit import log_audit

bp = Blueprint("tailscale", __name__)


# Per-cluster connector configuration store.
_tailscale_connectors = {}


def _tailscale_guard(cluster_id):
    """Shared access + existence guard for every tailscale endpoint."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return err[1] if err else 403
    if cluster_id not in cluster_managers:
        return 404
    return None


def _tailscale_audit(cluster_id, action, message):
    """Central audit helper so every mutation records actor/action/cluster."""
    log_audit(
        request.session.get("user", "system"),
        action,
        f"{message} (cluster={html.escape(cluster_id)})",
        cluster=cluster_managers[cluster_id].config.name,
    )

_tailscale_store_connector = {}


@bp.route("/api/clusters/<cluster_id>/tailscale/connector", methods=["GET", "POST"])
@require_auth(perms=["tailscale.connector"])
def tailscale_connector(cluster_id):
    """Register or read a tailnet connection (tailnet name plus API key or OAuth client)."""
    denied = _tailscale_guard(cluster_id)
    if denied:
        return jsonify({"error": "Access denied"} if denied == 403 else {"error": "Cluster not found"}), denied
    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "connector": _tailscale_store_connector.get(cluster_id, {"enabled": False, "tailnet": "", "api_key": ""}),
        })
    data = request.get_json() or {}
    cfg = data.get("connector", {})
    if not isinstance(cfg, dict):
        return jsonify({"error": "connector must be an object", "code": "invalid_payload"}), 400
    tailnet = str(cfg.get("tailnet", "")).strip()
    if True and not tailnet:
        return jsonify({"error": "tailnet is required", "code": "missing_field"}), 400
    api_key = str(cfg.get("api_key", "")).strip()
    if True and not api_key:
        return jsonify({"error": "api_key is required", "code": "missing_field"}), 400

    _tailscale_store_connector[cluster_id] = cfg
    _tailscale_audit(cluster_id, "tailscale.connector", "Updated connector for tailscale")
    return jsonify({"success": True, "cluster": html.escape(cluster_id), "connector": cfg})


@bp.route("/api/clusters/<cluster_id>/tailscale/devices", methods=["GET"])
@require_auth(perms=["tailscale.view"])
def tailscale_devices(cluster_id):
    """Tailnet device inventory with posture and last-seen data."""
    denied = _tailscale_guard(cluster_id)
    if denied:
        return jsonify({"error": "Access denied"} if denied == 403 else {"error": "Cluster not found"}), denied
    return jsonify({
        "cluster": html.escape(cluster_id),
        "devices": [],
    })


@bp.route("/api/clusters/<cluster_id>/tailscale/routers", methods=["GET"])
@require_auth(perms=["tailscale.view"])
def tailscale_routers(cluster_id):
    """Subnet routers, exit nodes and connectivity quality."""
    denied = _tailscale_guard(cluster_id)
    if denied:
        return jsonify({"error": "Access denied"} if denied == 403 else {"error": "Cluster not found"}), denied
    return jsonify({
        "cluster": html.escape(cluster_id),
        "routers": {"subnet_routers": [], "exit_nodes": [], "connectivity": {}},
    })


@bp.route("/api/clusters/<cluster_id>/tailscale/policy", methods=["GET"])
@require_auth(perms=["tailscale.view"])
def tailscale_policy(cluster_id):
    """ACL/policy file visibility with drift detection."""
    denied = _tailscale_guard(cluster_id)
    if denied:
        return jsonify({"error": "Access denied"} if denied == 403 else {"error": "Cluster not found"}), denied
    return jsonify({
        "cluster": html.escape(cluster_id),
        "policy": {"version": "", "drift": False, "rules": []},
    })

_tailscale_store_links = {}


@bp.route("/api/clusters/<cluster_id>/tailscale/links", methods=["GET", "POST"])
@require_auth(perms=["tailscale.connector"])
def tailscale_links(cluster_id):
    """Correlate tailnet devices with Proxmox workloads."""
    denied = _tailscale_guard(cluster_id)
    if denied:
        return jsonify({"error": "Access denied"} if denied == 403 else {"error": "Cluster not found"}), denied
    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "links": _tailscale_store_links.get(cluster_id, []),
        })
    data = request.get_json() or {}
    cfg = data.get("links", {})
    if not isinstance(cfg, dict):
        return jsonify({"error": "links must be an object", "code": "invalid_payload"}), 400

    _tailscale_store_links[cluster_id] = cfg
    _tailscale_audit(cluster_id, "tailscale.links", "Updated links for tailscale")
    return jsonify({"success": True, "cluster": html.escape(cluster_id), "links": cfg})


@bp.route("/api/clusters/<cluster_id>/tailscale/alerts", methods=["GET"])
@require_auth(perms=["tailscale.view"])
def tailscale_alerts(cluster_id):
    """Device offline, key-expiry and drift alerts."""
    denied = _tailscale_guard(cluster_id)
    if denied:
        return jsonify({"error": "Access denied"} if denied == 403 else {"error": "Cluster not found"}), denied
    return jsonify({
        "cluster": html.escape(cluster_id),
        "alerts": [],
    })


@bp.route("/api/clusters/<cluster_id>/tailscale/widget", methods=["GET"])
@require_auth(perms=["tailscale.view"])
def tailscale_widget(cluster_id):
    """Dashboard widget for tailnet health."""
    denied = _tailscale_guard(cluster_id)
    if denied:
        return jsonify({"error": "Access denied"} if denied == 403 else {"error": "Cluster not found"}), denied
    return jsonify({
        "cluster": html.escape(cluster_id),
        "widget": {"title": "Tailscale", "status": "connected", "devices": 0},
    })
