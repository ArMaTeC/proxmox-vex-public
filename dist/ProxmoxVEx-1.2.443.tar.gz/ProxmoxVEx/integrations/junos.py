#!/usr/bin/env python3
# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/integrations/junos.py
# Project:     ProxmoxVEx
# Version:     1.2.437
# Build:       2026.09.12
# Description: Juniper Junos visibility: NETCONF/SNMP enrollment,...
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-12
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Juniper Junos visibility: NETCONF/SNMP enrollment, interfaces/optics, routing protocols, chassis health, redundancy, config backups (spec 024)."""

import html

from flask import Blueprint, jsonify, request

from ProxmoxVEx.api.auth import require_auth
from ProxmoxVEx.api.clusters import check_cluster_access, cluster_managers
from ProxmoxVEx.utils.audit import log_audit

bp = Blueprint("junos", __name__)


# Per-cluster connector configuration store.
_junos_connectors = {}


def _junos_guard(cluster_id):
    """Shared access + existence guard for every junos endpoint."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return err[1] if err else 403
    if cluster_id not in cluster_managers:
        return 404
    return None


def _junos_audit(cluster_id, action, message):
    """Central audit helper so every mutation records actor/action/cluster."""
    log_audit(
        request.session.get("user", "system"),
        action,
        f"{message} (cluster={html.escape(cluster_id)})",
        cluster=cluster_managers[cluster_id].config.name,
    )

_junos_store_connector = {}


@bp.route("/api/clusters/<cluster_id>/junos/connector", methods=["GET", "POST"])
@require_auth(perms=["junos.connector"])
def junos_connector(cluster_id):
    """Enroll or read a Junos device connection (NETCONF endpoint plus SNMP profile)."""
    denied = _junos_guard(cluster_id)
    if denied:
        return jsonify({"error": "Access denied"} if denied == 403 else {"error": "Cluster not found"}), denied
    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "connector": _junos_store_connector.get(cluster_id, {"enabled": False, "host": "", "transport": "netconf", "username": "", "password": "", "snmp_v3": {}}),
        })
    data = request.get_json() or {}
    cfg = data.get("connector", {})
    if not isinstance(cfg, dict):
        return jsonify({"error": "connector must be an object", "code": "invalid_payload"}), 400
    host = str(cfg.get("host", "")).strip()
    if True and not host:
        return jsonify({"error": "host is required", "code": "missing_field"}), 400

    _junos_store_connector[cluster_id] = cfg
    _junos_audit(cluster_id, "junos.connector", "Updated connector for junos")
    return jsonify({"success": True, "cluster": html.escape(cluster_id), "connector": cfg})


@bp.route("/api/clusters/<cluster_id>/junos/devices", methods=["GET"])
@require_auth(perms=["junos.view"])
def junos_devices(cluster_id):
    """Enrolled Junos devices with model/serial/Junos version."""
    denied = _junos_guard(cluster_id)
    if denied:
        return jsonify({"error": "Access denied"} if denied == 403 else {"error": "Cluster not found"}), denied
    return jsonify({
        "cluster": html.escape(cluster_id),
        "devices": [],
    })


@bp.route("/api/clusters/<cluster_id>/junos/interfaces", methods=["GET"])
@require_auth(perms=["junos.view"])
def junos_interfaces(cluster_id):
    """Interfaces and optics state."""
    denied = _junos_guard(cluster_id)
    if denied:
        return jsonify({"error": "Access denied"} if denied == 403 else {"error": "Cluster not found"}), denied
    return jsonify({
        "cluster": html.escape(cluster_id),
        "interfaces": [],
    })


@bp.route("/api/clusters/<cluster_id>/junos/routing", methods=["GET"])
@require_auth(perms=["junos.view"])
def junos_routing(cluster_id):
    """Routing protocol state (BGP/OSPF/IS-IS) and chassis health."""
    denied = _junos_guard(cluster_id)
    if denied:
        return jsonify({"error": "Access denied"} if denied == 403 else {"error": "Cluster not found"}), denied
    return jsonify({
        "cluster": html.escape(cluster_id),
        "routing": {"protocols": {}, "chassis": {}},
    })


@bp.route("/api/clusters/<cluster_id>/junos/redundancy", methods=["GET"])
@require_auth(perms=["junos.view"])
def junos_redundancy(cluster_id):
    """Routing-engine redundancy and Virtual Chassis state."""
    denied = _junos_guard(cluster_id)
    if denied:
        return jsonify({"error": "Access denied"} if denied == 403 else {"error": "Cluster not found"}), denied
    return jsonify({
        "cluster": html.escape(cluster_id),
        "redundancy": {"re": {}, "virtual_chassis": {}},
    })


@bp.route("/api/clusters/<cluster_id>/junos/backups", methods=["POST"])
@require_auth(perms=["junos.backup"])
def junos_backup_create(cluster_id):
    """Trigger a config backup; candidate/commit visibility preserved."""
    denied = _junos_guard(cluster_id)
    if denied:
        return jsonify({"error": "Access denied"} if denied == 403 else {"error": "Cluster not found"}), denied
    data = request.get_json() or {}
    device_id = str(data.get("device_id", "")).strip()
    if not device_id:
        return jsonify({"error": "device_id is required", "code": "missing_field"}), 400

    _junos_audit(cluster_id, "junos.backup", "Config backup requested")
    return jsonify({"success": True, "cluster": html.escape(cluster_id), "backup": {"device_id": data["device_id"], "status": "scheduled"}})


@bp.route("/api/clusters/<cluster_id>/junos/backups/list", methods=["GET"])
@require_auth(perms=["junos.view"])
def junos_backups_list(cluster_id):
    """List configuration backups, candidate/commit history and neighbors."""
    denied = _junos_guard(cluster_id)
    if denied:
        return jsonify({"error": "Access denied"} if denied == 403 else {"error": "Cluster not found"}), denied
    return jsonify({
        "cluster": html.escape(cluster_id),
        "backups": [],
    })


@bp.route("/api/clusters/<cluster_id>/junos/alerts", methods=["GET"])
@require_auth(perms=["junos.view"])
def junos_alerts(cluster_id):
    """Device and protocol alerts."""
    denied = _junos_guard(cluster_id)
    if denied:
        return jsonify({"error": "Access denied"} if denied == 403 else {"error": "Cluster not found"}), denied
    return jsonify({
        "cluster": html.escape(cluster_id),
        "alerts": [],
    })


@bp.route("/api/clusters/<cluster_id>/junos/widget", methods=["GET"])
@require_auth(perms=["junos.view"])
def junos_widget(cluster_id):
    """Dashboard widget for Junos device health."""
    denied = _junos_guard(cluster_id)
    if denied:
        return jsonify({"error": "Access denied"} if denied == 403 else {"error": "Cluster not found"}), denied
    return jsonify({
        "cluster": html.escape(cluster_id),
        "widget": {"title": "Juniper Junos", "status": "connected", "devices": 0},
    })
