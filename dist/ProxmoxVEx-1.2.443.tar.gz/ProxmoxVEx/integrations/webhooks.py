#!/usr/bin/env python3
# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/integrations/webhooks.py
# Project:     ProxmoxVEx
# Version:     1.2.437
# Build:       2026.09.12
# Description: Webhooks integration: export endpoints.
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-12
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Webhooks integration: export endpoints."""

import html

from flask import Blueprint, jsonify, request

from ProxmoxVEx.api.auth import require_auth
from ProxmoxVEx.api.clusters import check_cluster_access, cluster_managers
from ProxmoxVEx.utils.audit import log_audit

bp = Blueprint("webhooks", __name__)


# In-memory Webhooks export target store.
_webhooks_export_targets = {}


@bp.route("/api/clusters/<cluster_id>/webhooks/export", methods=["GET", "POST"])
@require_auth(perms=["webhooks.export"])
def webhooks_export(cluster_id):
    """Return or update the Webhooks export configuration.

    890-webhooks-export: per-cluster Webhooks export target settings.
    """
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "export": _webhooks_export_targets.get(
                cluster_id,
                {"enabled": False, "url": "", "events": []},
            ),
        })

    data = request.get_json() or {}
    export = data.get("export", {})
    enabled = bool(export.get("enabled", False))
    url = str(export.get("url", ""))
    events = export.get("events", [])
    if not isinstance(events, list):
        events = []

    config = {
        "enabled": enabled,
        "url": html.escape(url),
        "events": [html.escape(str(event)) for event in events],
    }
    _webhooks_export_targets[cluster_id] = config
    log_audit(
        request.session.get("user", "system"),
        "webhooks.export",
        f"Updated Webhooks export for {html.escape(cluster_id)}: enabled={enabled}, url={config['url']}",
        cluster=cluster_managers[cluster_id].config.name,
    )

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "export": config,
    })


# In-memory Webhooks connector store.
_webhooks_connector = {}


@bp.route("/api/clusters/<cluster_id>/webhooks/connector", methods=["GET", "POST"])
@require_auth(perms=["webhooks.connector"])
def webhooks_connector(cluster_id):
    """Return or update the Webhooks connector configuration.

    891-webhooks-connector: per-cluster Webhooks server credentials and
    connection settings.
    """
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "connector": _webhooks_connector.get(
                cluster_id,
                {"enabled": False, "server": "", "secret": "", "verify_ssl": True},
            ),
        })

    data = request.get_json() or {}
    connector = data.get("connector", {})

    config = {
        "enabled": bool(connector.get("enabled", False)),
        "server": html.escape(str(connector.get("server", ""))),
        "secret": html.escape(str(connector.get("secret", ""))),
        "verify_ssl": bool(connector.get("verify_ssl", True)),
    }
    _webhooks_connector[cluster_id] = config
    log_audit(
        request.session.get("user", "system"),
        "webhooks.connector",
        f"Updated Webhooks connector for {html.escape(cluster_id)}: enabled={config['enabled']}, server={config['server']}",
        cluster=cluster_managers[cluster_id].config.name,
    )

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "connector": config,
    })


# In-memory Webhooks sync state.
_webhooks_sync = {}


@bp.route("/api/clusters/<cluster_id>/webhooks/sync", methods=["GET", "POST"])
@require_auth(perms=["webhooks.sync"])
def webhooks_sync(cluster_id):
    """Return or trigger the Webhooks sync state.

    966-webhooks-sync: per-cluster Webhooks synchronization status and controls.
    """
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "sync": _webhooks_sync.get(
                cluster_id,
                {"enabled": False, "status": "idle", "last_sync": None},
            ),
        })

    data = request.get_json() or {}
    sync = data.get("sync", {})

    config = {
        "enabled": bool(sync.get("enabled", False)),
        "status": html.escape(str(sync.get("status", "idle"))),
        "last_sync": html.escape(str(sync.get("last_sync", ""))),
    }
    _webhooks_sync[cluster_id] = config
    log_audit(
        request.session.get("user", "system"),
        "webhooks.sync",
        f"Updated Webhooks sync for {html.escape(cluster_id)}: enabled={config['enabled']}, status={config['status']}",
        cluster=cluster_managers[cluster_id].config.name,
    )

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "sync": config,
    })


# In-memory Webhooks import state.
_webhooks_import = {}


@bp.route("/api/clusters/<cluster_id>/webhooks/import", methods=["GET", "POST"])
@require_auth(perms=["webhooks.import"])
def webhooks_import(cluster_id):
    """Return or update the Webhooks import configuration.

    967-webhooks-import: per-cluster Webhooks import status and settings.
    """
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "import": _webhooks_import.get(
                cluster_id,
                {"enabled": False, "source_url": "", "events": []},
            ),
        })

    data = request.get_json() or {}
    imp = data.get("import", {})

    config = {
        "enabled": bool(imp.get("enabled", False)),
        "source_url": html.escape(str(imp.get("source_url", ""))),
        "events": [html.escape(str(event)) for event in (imp.get("events", []) if isinstance(imp.get("events", []), list) else [])],
    }
    _webhooks_import[cluster_id] = config
    log_audit(
        request.session.get("user", "system"),
        "webhooks.import",
        f"Updated Webhooks import for {html.escape(cluster_id)}: enabled={config['enabled']}, source_url={config['source_url']}",
        cluster=cluster_managers[cluster_id].config.name,
    )

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "import": config,
    })


# In-memory Webhooks template library.
_webhooks_template_library = {}


@bp.route("/api/clusters/<cluster_id>/webhooks/template-library", methods=["GET", "POST"])
@require_auth(perms=["webhooks.template_library"])
def webhooks_template_library(cluster_id):
    """Return or update the Webhooks template library.

    968-webhooks-template-library: per-cluster Webhooks template presets.
    """
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "templates": _webhooks_template_library.get(cluster_id, []),
        })

    data = request.get_json() or {}
    templates = data.get("templates", [])
    if not isinstance(templates, list):
        templates = []

    cleaned = []
    for template in templates:
        if not isinstance(template, dict):
            continue
        cleaned.append({
            "id": html.escape(str(template.get("id", ""))),
            "name": html.escape(str(template.get("name", ""))),
            "description": html.escape(str(template.get("description", ""))),
            "payload": template.get("payload", {}),
            "headers": template.get("headers", {}),
        })
    _webhooks_template_library[cluster_id] = cleaned
    log_audit(
        request.session.get("user", "system"),
        "webhooks.template_library",
        f"Updated Webhooks template library for {html.escape(cluster_id)}: {len(cleaned)} templates",
        cluster=cluster_managers[cluster_id].config.name,
    )

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "templates": cleaned,
    })


# In-memory Webhooks dashboard widget state.
_webhooks_dashboard_widget = {}


@bp.route("/api/clusters/<cluster_id>/webhooks/dashboard-widget", methods=["GET", "POST"])
@require_auth(perms=["webhooks.dashboard_widget"])
def webhooks_dashboard_widget(cluster_id):
    """Return or update the Webhooks dashboard widget configuration.

    969-webhooks-dashboard-widget: per-cluster dashboard widget settings.
    """
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "widget": _webhooks_dashboard_widget.get(
                cluster_id,
                {"enabled": False, "position": "dashboard", "metrics": []},
            ),
        })

    data = request.get_json() or {}
    widget = data.get("widget", {})

    config = {
        "enabled": bool(widget.get("enabled", False)),
        "position": html.escape(str(widget.get("position", "dashboard"))),
        "metrics": [html.escape(str(metric)) for metric in (widget.get("metrics", []) if isinstance(widget.get("metrics", []), list) else [])],
    }
    _webhooks_dashboard_widget[cluster_id] = config
    log_audit(
        request.session.get("user", "system"),
        "webhooks.dashboard_widget",
        f"Updated Webhooks dashboard widget for {html.escape(cluster_id)}: enabled={config['enabled']}, position={config['position']}",
        cluster=cluster_managers[cluster_id].config.name,
    )

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "widget": config,
    })


# In-memory Webhooks alert channel state.
_webhooks_alert_channel = {}


@bp.route("/api/clusters/<cluster_id>/webhooks/alert-channel", methods=["GET", "POST"])
@require_auth(perms=["webhooks.alert_channel"])
def webhooks_alert_channel(cluster_id):
    """Return or update the Webhooks alert channel configuration.

    970-webhooks-alert-channel: per-cluster Webhooks alert channel settings.
    """
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "alert_channel": _webhooks_alert_channel.get(
                cluster_id,
                {"enabled": False, "severity": "warning", "events": []},
            ),
        })

    data = request.get_json() or {}
    channel = data.get("alert_channel", {})

    config = {
        "enabled": bool(channel.get("enabled", False)),
        "severity": html.escape(str(channel.get("severity", "warning"))),
        "events": [html.escape(str(event)) for event in (channel.get("events", []) if isinstance(channel.get("events", []), list) else [])],
    }
    _webhooks_alert_channel[cluster_id] = config
    log_audit(
        request.session.get("user", "system"),
        "webhooks.alert_channel",
        f"Updated Webhooks alert channel for {html.escape(cluster_id)}: enabled={config['enabled']}, severity={config['severity']}",
        cluster=cluster_managers[cluster_id].config.name,
    )

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "alert_channel": config,
    })


# In-memory Webhooks policy adapter state.
_webhooks_policy_adapter = {}


@bp.route("/api/clusters/<cluster_id>/webhooks/policy-adapter", methods=["GET", "POST"])
@require_auth(perms=["webhooks.policy_adapter"])
def webhooks_policy_adapter(cluster_id):
    """Return or update the Webhooks policy adapter configuration.

    971-webhooks-policy-adapter: per-cluster Webhooks policy adapter rules.
    """
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "policy_adapter": _webhooks_policy_adapter.get(
                cluster_id,
                {"enabled": False, "allow": [], "deny": []},
            ),
        })

    data = request.get_json() or {}
    adapter = data.get("policy_adapter", {})

    def _clean(items):
        return [html.escape(str(item)) for item in (items if isinstance(items, list) else [])]

    config = {
        "enabled": bool(adapter.get("enabled", False)),
        "allow": _clean(adapter.get("allow", [])),
        "deny": _clean(adapter.get("deny", [])),
    }
    _webhooks_policy_adapter[cluster_id] = config
    log_audit(
        request.session.get("user", "system"),
        "webhooks.policy_adapter",
        f"Updated Webhooks policy adapter for {html.escape(cluster_id)}: enabled={config['enabled']}, allow={len(config['allow'])}, deny={len(config['deny'])}",
        cluster=cluster_managers[cluster_id].config.name,
    )

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "policy_adapter": config,
    })


# In-memory Webhooks role mapping state.
_webhooks_role_mapping = {}


@bp.route("/api/clusters/<cluster_id>/webhooks/role-mapping", methods=["GET", "POST"])
@require_auth(perms=["webhooks.role_mapping"])
def webhooks_role_mapping(cluster_id):
    """Return or update the Webhooks role mapping configuration.

    972-webhooks-role-mapping: per-cluster Webhooks role mapping rules.
    """
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "role_mapping": _webhooks_role_mapping.get(
                cluster_id,
                {"enabled": False, "rules": []},
            ),
        })

    data = request.get_json() or {}
    mapping = data.get("role_mapping", {})

    def _clean_rule(rule):
        if not isinstance(rule, dict):
            return None
        return {
            "claim": html.escape(str(rule.get("claim", ""))),
            "value": html.escape(str(rule.get("value", ""))),
            "role": html.escape(str(rule.get("role", ""))),
        }

    rules = mapping.get("rules", [])
    if not isinstance(rules, list):
        rules = []
    cleaned = [r for r in (_clean_rule(rule) for rule in rules) if r is not None]

    config = {
        "enabled": bool(mapping.get("enabled", False)),
        "rules": cleaned,
    }
    _webhooks_role_mapping[cluster_id] = config
    log_audit(
        request.session.get("user", "system"),
        "webhooks.role_mapping",
        f"Updated Webhooks role mapping for {html.escape(cluster_id)}: enabled={config['enabled']}, rules={len(config['rules'])}",
        cluster=cluster_managers[cluster_id].config.name,
    )

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "role_mapping": config,
    })


# In-memory Webhooks automation workflow state.
_webhooks_automation_workflow = {}


@bp.route("/api/clusters/<cluster_id>/webhooks/automation-workflow", methods=["GET", "POST"])
@require_auth(perms=["webhooks.automation_workflow"])
def webhooks_automation_workflow(cluster_id):
    """Return or update the Webhooks automation workflow configuration.

    973-webhooks-automation-workflow: per-cluster Webhooks automation workflow rules.
    """
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "automation_workflow": _webhooks_automation_workflow.get(
                cluster_id,
                {"enabled": False, "trigger": "alert", "actions": []},
            ),
        })

    data = request.get_json() or {}
    workflow = data.get("automation_workflow", {})

    def _clean_action(action):
        if not isinstance(action, dict):
            return None
        return {
            "type": html.escape(str(action.get("type", ""))),
            "target": html.escape(str(action.get("target", ""))),
            "payload": action.get("payload", {}),
        }

    actions = workflow.get("actions", [])
    if not isinstance(actions, list):
        actions = []
    cleaned = [a for a in (_clean_action(action) for action in actions) if a is not None]

    config = {
        "enabled": bool(workflow.get("enabled", False)),
        "trigger": html.escape(str(workflow.get("trigger", "alert"))),
        "actions": cleaned,
    }
    _webhooks_automation_workflow[cluster_id] = config
    log_audit(
        request.session.get("user", "system"),
        "webhooks.automation_workflow",
        f"Updated Webhooks automation workflow for {html.escape(cluster_id)}: enabled={config['enabled']}, trigger={config['trigger']}, actions={len(config['actions'])}",
        cluster=cluster_managers[cluster_id].config.name,
    )

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "automation_workflow": config,
    })
