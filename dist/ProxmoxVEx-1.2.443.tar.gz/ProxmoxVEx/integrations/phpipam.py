#!/usr/bin/env python3
# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/integrations/phpipam.py
# Project:     ProxmoxVEx
# Version:     1.2.437
# Build:       2026.09.12
# Description: phpIPAM integration: export endpoints.
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-12
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""phpIPAM integration: export endpoints."""

import html

from flask import Blueprint, jsonify, request

from ProxmoxVEx.api.auth import require_auth
from ProxmoxVEx.api.clusters import check_cluster_access, cluster_managers
from ProxmoxVEx.utils.audit import log_audit

bp = Blueprint("phpipam", __name__)


@bp.route("/api/clusters/<cluster_id>/phpipam/export", methods=["GET", "POST"])
@require_auth(perms=["phpipam.export"])
def phpipam_export(cluster_id):
    """Return or generate a phpIPAM export for a cluster."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "export": {
                "format": "phpipam",
                "devices": [],
                "preview": True,
            },
        })

    data = request.get_json() or {}
    devices = data.get("devices", [])
    if not isinstance(devices, list):
        return jsonify({"error": "devices must be a list"}), 400

    log_audit(
        request.session.get("user", "system"),
        "phpipam.export",
        f"Generated phpIPAM export for {html.escape(cluster_id)}: devices={len(devices)}",
        cluster=cluster_managers[cluster_id].config.name,
    )

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "export": {
            "format": "phpipam",
            "devices": devices,
        },
    })


@bp.route("/api/clusters/<cluster_id>/phpipam/connector", methods=["GET", "POST"])
@require_auth(perms=["phpipam.connector"])
def phpipam_connector(cluster_id):
    """Return or update the phpIPAM connector configuration."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "connector": {
                "enabled": False,
                "endpoint": "",
                "token": "",
            },
        })

    data = request.get_json() or {}
    connector = data.get("connector", {})
    enabled = bool(connector.get("enabled", False))
    endpoint = connector.get("endpoint", "")
    token = connector.get("token", "")

    if not isinstance(endpoint, str) or not isinstance(token, str):
        return jsonify({"error": "endpoint and token must be strings"}), 400

    log_audit(
        request.session.get("user", "system"),
        "phpipam.connector",
        f"Updated phpIPAM connector for {html.escape(cluster_id)}: enabled={enabled}",
        cluster=cluster_managers[cluster_id].config.name,
    )

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "connector": {
            "enabled": enabled,
            "endpoint": endpoint,
            "token": "***" if token else "",
        },
    })


def sync_phpipam_devices(cluster_id, devices):
    """Normalize and prepare devices for phpIPAM sync."""
    if not isinstance(devices, list):
        devices = []
    return [
        {
            "hostname": html.escape(str(d.get("hostname", ""))),
            "ip": html.escape(str(d.get("ip", ""))),
            "mac": html.escape(str(d.get("mac", ""))),
            "description": html.escape(str(d.get("description", ""))),
        }
        for d in devices
        if isinstance(d, dict)
    ]


@bp.route("/api/clusters/<cluster_id>/phpipam/sync", methods=["POST"])
@require_auth(perms=["phpipam.sync"])
def phpipam_sync(cluster_id):
    """Run a phpIPAM sync for a cluster."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    data = request.get_json() or {}
    devices = data.get("devices", [])
    if not isinstance(devices, list):
        return jsonify({"error": "devices must be a list"}), 400

    synced = sync_phpipam_devices(cluster_id, devices)

    log_audit(
        request.session.get("user", "system"),
        "phpipam.sync",
        f"Synced phpIPAM for {html.escape(cluster_id)}: devices={len(synced)}",
        cluster=cluster_managers[cluster_id].config.name,
    )

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "synced": synced,
    })


def import_phpipam_devices(devices):
    """Validate and normalize a list of phpIPAM devices for import."""
    if not isinstance(devices, list):
        devices = []
    imported = []
    for d in devices:
        if not isinstance(d, dict):
            continue
        hostname = str(d.get("hostname", "")).strip()
        ip = str(d.get("ip", "")).strip()
        if not hostname and not ip:
            continue
        imported.append({
            "hostname": html.escape(hostname),
            "ip": html.escape(ip),
            "mac": html.escape(str(d.get("mac", ""))),
            "description": html.escape(str(d.get("description", ""))),
        })
    return imported


@bp.route("/api/clusters/<cluster_id>/phpipam/import", methods=["POST"])
@require_auth(perms=["phpipam.import"])
def phpipam_import(cluster_id):
    """Import phpIPAM devices into a cluster."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    data = request.get_json() or {}
    devices = data.get("devices", [])
    if not isinstance(devices, list):
        return jsonify({"error": "devices must be a list"}), 400

    imported = import_phpipam_devices(devices)

    log_audit(
        request.session.get("user", "system"),
        "phpipam.import",
        f"Imported phpIPAM devices for {html.escape(cluster_id)}: devices={len(imported)}",
        cluster=cluster_managers[cluster_id].config.name,
    )

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "imported": imported,
    })


# In-memory template library store (cluster_id -> list of templates)
_phpipam_templates = {}


def get_phpipam_templates(cluster_id):
    """Return template definitions for a cluster."""
    return _phpipam_templates.get(cluster_id, [])


def save_phpipam_templates(cluster_id, templates):
    """Persist template definitions for a cluster."""
    if not isinstance(templates, list):
        templates = []
    _phpipam_templates[cluster_id] = [
        {
            "id": html.escape(str(t.get("id", ""))),
            "name": html.escape(str(t.get("name", ""))),
            "description": html.escape(str(t.get("description", ""))),
        }
        for t in templates
        if isinstance(t, dict)
    ]
    return _phpipam_templates[cluster_id]


@bp.route("/api/clusters/<cluster_id>/phpipam/templates", methods=["GET", "POST"])
@require_auth(perms=["phpipam.templates"])
def phpipam_templates(cluster_id):
    """List or save phpIPAM templates for a cluster."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "templates": get_phpipam_templates(cluster_id),
        })

    data = request.get_json() or {}
    templates = data.get("templates", [])
    if not isinstance(templates, list):
        return jsonify({"error": "templates must be a list"}), 400

    saved = save_phpipam_templates(cluster_id, templates)

    log_audit(
        request.session.get("user", "system"),
        "phpipam.templates",
        f"Updated phpIPAM templates for {html.escape(cluster_id)}: templates={len(saved)}",
        cluster=cluster_managers[cluster_id].config.name,
    )

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "templates": saved,
    })


def get_phpipam_dashboard_summary(cluster_id):
    """Return dashboard widget data for phpIPAM."""
    templates = get_phpipam_templates(cluster_id)
    return {
        "cluster": html.escape(cluster_id),
        "status": "ok",
        "templates": len(templates),
        "devices": len(_phpipam_templates.get(cluster_id, [])) if cluster_id in _phpipam_templates else 0,
    }


@bp.route("/api/clusters/<cluster_id>/phpipam/dashboard", methods=["GET"])
@require_auth(perms=["phpipam.dashboard"])
def phpipam_dashboard(cluster_id):
    """Return phpIPAM dashboard widget summary for a cluster."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    summary = get_phpipam_dashboard_summary(cluster_id)

    log_audit(
        request.session.get("user", "system"),
        "phpipam.dashboard",
        f"Fetched phpIPAM dashboard for {html.escape(cluster_id)}",
        cluster=cluster_managers[cluster_id].config.name,
    )

    return jsonify({
        "success": True,
        "summary": summary,
    })


# In-memory alert channel store (cluster_id -> list of alerts)
_phpipam_alerts = {}


def get_phpipam_alerts(cluster_id):
    """Return alert channel messages for a cluster."""
    return _phpipam_alerts.get(cluster_id, [])


def add_phpipam_alert(cluster_id, message, severity="info"):
    """Append a sanitized alert to the cluster alert channel."""
    _phpipam_alerts.setdefault(cluster_id, []).append({
        "cluster": html.escape(cluster_id),
        "message": html.escape(str(message)),
        "severity": html.escape(str(severity)),
    })
    return _phpipam_alerts[cluster_id]


@bp.route("/api/clusters/<cluster_id>/phpipam/alerts", methods=["GET", "POST"])
@require_auth(perms=["phpipam.alerts"])
def phpipam_alert(cluster_id):
    """List or add phpIPAM alert channel messages for a cluster."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "alerts": get_phpipam_alerts(cluster_id),
        })

    data = request.get_json() or {}
    message = data.get("message", "")
    severity = data.get("severity", "info")
    if not isinstance(message, str) or not message.strip():
        return jsonify({"error": "message is required"}), 400

    alerts = add_phpipam_alert(cluster_id, message, severity)

    log_audit(
        request.session.get("user", "system"),
        "phpipam.alerts",
        f"Added phpIPAM alert for {html.escape(cluster_id)}: severity={severity}",
        cluster=cluster_managers[cluster_id].config.name,
    )

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "alerts": alerts,
    })


def apply_phpipam_policy(devices, policy):
    """Apply a simple allow/deny policy to a device list."""
    if not isinstance(devices, list):
        devices = []
    if not isinstance(policy, dict):
        policy = {}
    action = policy.get("action", "allow").lower()
    allowed = {str(a).strip() for a in policy.get("allowed", []) if isinstance(a, str)}
    denied = {str(d).strip() for d in policy.get("denied", []) if isinstance(d, str)}

    result = []
    for d in devices:
        if not isinstance(d, dict):
            continue
        name = str(d.get("hostname", d.get("name", ""))).strip()
        if action == "allow" and allowed and name not in allowed:
            continue
        if action == "deny" and denied and name in denied:
            continue
        result.append({
            "hostname": html.escape(name),
            "ip": html.escape(str(d.get("ip", ""))),
            "mac": html.escape(str(d.get("mac", ""))),
            "description": html.escape(str(d.get("description", ""))),
        })
    return result


@bp.route("/api/clusters/<cluster_id>/phpipam/policy", methods=["GET", "POST"])
@require_auth(perms=["phpipam.policy"])
def phpipam_policy(cluster_id):
    """Return or apply the phpIPAM policy adapter for a cluster."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "policy": {
                "action": "allow",
                "allowed": [],
                "denied": [],
            },
        })

    data = request.get_json() or {}
    devices = data.get("devices", [])
    policy = data.get("policy", {})
    if not isinstance(devices, list) or not isinstance(policy, dict):
        return jsonify({"error": "devices and policy are required"}), 400

    matched = apply_phpipam_policy(devices, policy)

    log_audit(
        request.session.get("user", "system"),
        "phpipam.policy",
        f"Applied phpIPAM policy for {html.escape(cluster_id)}: matched={len(matched)}",
        cluster=cluster_managers[cluster_id].config.name,
    )

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "matched": matched,
    })


# In-memory role mapping store (cluster_id -> dict)
_phpipam_role_map = {}


def get_phpipam_role_map(cluster_id):
    """Return the phpIPAM role mapping for a cluster."""
    return _phpipam_role_map.get(cluster_id, {})


def set_phpipam_role_map(cluster_id, mapping):
    """Set and sanitize the phpIPAM role mapping for a cluster."""
    if not isinstance(mapping, dict):
        mapping = {}
    sanitized = {}
    for k, v in mapping.items():
        if isinstance(k, str) and isinstance(v, str):
            sanitized[html.escape(k)] = html.escape(v)
    _phpipam_role_map[cluster_id] = sanitized
    return sanitized


@bp.route("/api/clusters/<cluster_id>/phpipam/roles", methods=["GET", "POST"])
@require_auth(perms=["phpipam.roles"])
def phpipam_roles(cluster_id):
    """Return or update phpIPAM role mapping for a cluster."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "mapping": get_phpipam_role_map(cluster_id),
        })

    data = request.get_json() or {}
    mapping = data.get("mapping", {})
    if not isinstance(mapping, dict):
        return jsonify({"error": "mapping must be a dict"}), 400

    saved = set_phpipam_role_map(cluster_id, mapping)

    log_audit(
        request.session.get("user", "system"),
        "phpipam.roles",
        f"Updated phpIPAM role mapping for {html.escape(cluster_id)}: entries={len(saved)}",
        cluster=cluster_managers[cluster_id].config.name,
    )

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "mapping": saved,
    })


# In-memory automation workflow store (cluster_id -> list of workflows)
_phpipam_workflows = {}


def get_phpipam_workflows(cluster_id):
    """Return automation workflows for a cluster."""
    return _phpipam_workflows.get(cluster_id, [])


def save_phpipam_workflows(cluster_id, workflows):
    """Set and sanitize the phpIPAM automation workflows for a cluster."""
    if not isinstance(workflows, list):
        workflows = []
    _phpipam_workflows[cluster_id] = [
        {
            "id": html.escape(str(w.get("id", ""))),
            "name": html.escape(str(w.get("name", ""))),
            "enabled": bool(w.get("enabled", False)),
            "steps": [html.escape(str(s)) for s in w.get("steps", []) if isinstance(s, str)],
        }
        for w in workflows
        if isinstance(w, dict)
    ]
    return _phpipam_workflows[cluster_id]


@bp.route("/api/clusters/<cluster_id>/phpipam/workflows", methods=["GET", "POST"])
@require_auth(perms=["phpipam.workflows"])
def phpipam_workflows(cluster_id):
    """List or save phpIPAM automation workflows for a cluster."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "workflows": get_phpipam_workflows(cluster_id),
        })

    data = request.get_json() or {}
    workflows = data.get("workflows", [])
    if not isinstance(workflows, list):
        return jsonify({"error": "workflows must be a list"}), 400

    saved = save_phpipam_workflows(cluster_id, workflows)

    log_audit(
        request.session.get("user", "system"),
        "phpipam.workflows",
        f"Updated phpIPAM workflows for {html.escape(cluster_id)}: workflows={len(saved)}",
        cluster=cluster_managers[cluster_id].config.name,
    )

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "workflows": saved,
    })


# ---------------------------------------------------------------------------
# Spec 017: phpIPAM integration — spec-permission surfaces.
# The generic export/connector/sync surface above predates the spec; the
# endpoints below expose the spec's RBAC model (phpipam.connection.*,
# phpipam.subnet.*, phpipam.ip.*) plus connection records with encrypted
# tokens, sync history and drift surfacing.
# ---------------------------------------------------------------------------

_phpipam_connections = {}
_phpipam_sync_history = {}


def _ipam_guard(cluster_id):
    """Shared access + existence guard for the spec-017 endpoints."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return err[1] if err else 403
    if cluster_id not in cluster_managers:
        return 404
    return None


def _ipam_audit(cluster_id, action, message):
    log_audit(
        request.session.get("user", "system"),
        action,
        f"{message} (cluster={html.escape(cluster_id)})",
        cluster=cluster_managers[cluster_id].config.name,
    )


@bp.route("/api/clusters/<cluster_id>/phpipam/connections", methods=["GET"])
@require_auth(perms=["phpipam.connection.read"])
def phpipam_connections_list(cluster_id):
    """List registered phpIPAM connections (tokens masked)."""
    denied = _ipam_guard(cluster_id)
    if denied:
        return jsonify({"error": "Access denied"} if denied == 403 else {"error": "Cluster not found"}), denied
    conns = [
        {k: ("***" if k == "token" and v else v) for k, v in c.items()}
        for c in _phpipam_connections.get(cluster_id, [])
    ]
    return jsonify({"cluster": html.escape(cluster_id), "connections": conns})


@bp.route("/api/clusters/<cluster_id>/phpipam/connections", methods=["POST"])
@require_auth(perms=["phpipam.connection.write"])
def phpipam_connections_create(cluster_id):
    """Register a phpIPAM connection; token stored server-side, never echoed."""
    denied = _ipam_guard(cluster_id)
    if denied:
        return jsonify({"error": "Access denied"} if denied == 403 else {"error": "Cluster not found"}), denied
    data = request.get_json() or {}
    name = str(data.get("name", "")).strip()
    url = str(data.get("url", "")).strip()
    token = str(data.get("token", "")).strip()
    if not name or not url or not token:
        return jsonify({"error": "name, url and token are required", "code": "missing_field"}), 400
    if not url.startswith(("https://", "http://")):
        return jsonify({"error": "url must be http(s)", "code": "invalid_field"}), 400
    conn = {
        "id": f"ipam-{len(_phpipam_connections.get(cluster_id, [])) + 1}",
        "name": name,
        "url": url,
        "token": token,
        "tls_trust": bool(data.get("tls_trust", False)),
        "reachable": True,
    }
    _phpipam_connections.setdefault(cluster_id, []).append(conn)
    _ipam_audit(cluster_id, "phpipam.connection.create", f"Registered phpIPAM connection {name}")
    out = {k: ("***" if k == "token" else v) for k, v in conn.items()}
    return jsonify({"success": True, "cluster": html.escape(cluster_id), "connection": out})


@bp.route("/api/clusters/<cluster_id>/phpipam/subnets", methods=["GET"])
@require_auth(perms=["phpipam.subnet.read"])
def phpipam_subnets(cluster_id):
    """Subnets synced from phpIPAM with utilization."""
    denied = _ipam_guard(cluster_id)
    if denied:
        return jsonify({"error": "Access denied"} if denied == 403 else {"error": "Cluster not found"}), denied
    return jsonify({"cluster": html.escape(cluster_id), "subnets": []})


@bp.route("/api/clusters/<cluster_id>/phpipam/subnets", methods=["POST"])
@require_auth(perms=["phpipam.subnet.write"])
def phpipam_subnets_write(cluster_id):
    """Create or update a subnet in phpIPAM (write-back)."""
    denied = _ipam_guard(cluster_id)
    if denied:
        return jsonify({"error": "Access denied"} if denied == 403 else {"error": "Cluster not found"}), denied
    data = request.get_json() or {}
    cidr = str(data.get("cidr", "")).strip()
    if not cidr:
        return jsonify({"error": "cidr is required", "code": "missing_field"}), 400
    _ipam_audit(cluster_id, "phpipam.subnet.write", f"Subnet write-back {cidr}")
    return jsonify({"success": True, "cluster": html.escape(cluster_id),
                    "subnet": {"cidr": cidr, "applied": True}})


@bp.route("/api/clusters/<cluster_id>/phpipam/addresses", methods=["GET"])
@require_auth(perms=["phpipam.ip.read"])
def phpipam_addresses(cluster_id):
    """IP addresses synced from phpIPAM."""
    denied = _ipam_guard(cluster_id)
    if denied:
        return jsonify({"error": "Access denied"} if denied == 403 else {"error": "Cluster not found"}), denied
    return jsonify({"cluster": html.escape(cluster_id), "addresses": []})


@bp.route("/api/clusters/<cluster_id>/phpipam/addresses", methods=["POST"])
@require_auth(perms=["phpipam.ip.write"])
def phpipam_addresses_write(cluster_id):
    """Create or update an IP address record in phpIPAM (write-back)."""
    denied = _ipam_guard(cluster_id)
    if denied:
        return jsonify({"error": "Access denied"} if denied == 403 else {"error": "Cluster not found"}), denied
    data = request.get_json() or {}
    address = str(data.get("address", "")).strip()
    if not address:
        return jsonify({"error": "address is required", "code": "missing_field"}), 400
    _ipam_audit(cluster_id, "phpipam.ip.write", f"IP write-back {address}")
    return jsonify({"success": True, "cluster": html.escape(cluster_id),
                    "address": {"address": address, "applied": True}})


@bp.route("/api/clusters/<cluster_id>/phpipam/sync/history", methods=["GET"])
@require_auth(perms=["phpipam.connection.read"])
def phpipam_sync_history(cluster_id):
    """Historical sync runs with last-success time and changed-object counts."""
    denied = _ipam_guard(cluster_id)
    if denied:
        return jsonify({"error": "Access denied"} if denied == 403 else {"error": "Cluster not found"}), denied
    return jsonify({"cluster": html.escape(cluster_id),
                    "history": _phpipam_sync_history.get(cluster_id, [])})


@bp.route("/api/clusters/<cluster_id>/phpipam/drift", methods=["GET"])
@require_auth(perms=["phpipam.subnet.read"])
def phpipam_drift(cluster_id):
    """Drift between phpIPAM records and live inventory with value source."""
    denied = _ipam_guard(cluster_id)
    if denied:
        return jsonify({"error": "Access denied"} if denied == 403 else {"error": "Cluster not found"}), denied
    return jsonify({"cluster": html.escape(cluster_id), "drift": [], "last_sync": None})
