#!/usr/bin/env python3
# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/integrations/ldap.py
# Project:     ProxmoxVEx
# Version:     1.2.437
# Build:       2026.09.12
# Description: LDAP integration: export endpoints.
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-12
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""LDAP integration: export endpoints."""

import html

from flask import Blueprint, jsonify, request

from ProxmoxVEx.api.auth import require_auth
from ProxmoxVEx.api.clusters import check_cluster_access, cluster_managers
from ProxmoxVEx.utils.audit import log_audit

bp = Blueprint("ldap", __name__)


# In-memory LDAP export target store.
_ldap_export_targets = {}


@bp.route("/api/clusters/<cluster_id>/ldap/export", methods=["GET", "POST"])
@require_auth(perms=["ldap.export"])
def ldap_export(cluster_id):
    """Return or update the LDAP export configuration."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "export": _ldap_export_targets.get(
                cluster_id,
                {"enabled": False, "base_dn": ""},
            ),
        })

    data = request.get_json() or {}
    export = data.get("export", {})
    enabled = bool(export.get("enabled", False))
    base_dn = str(export.get("base_dn", ""))

    config = {"enabled": enabled, "base_dn": base_dn}
    _ldap_export_targets[cluster_id] = config
    log_audit(
        request.session.get("user", "system"),
        "ldap.export",
        f"Updated LDAP export for {html.escape(cluster_id)}: enabled={enabled}",
        cluster=cluster_managers[cluster_id].config.name,
    )

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "export": config,
    })


# In-memory LDAP connector store.
_ldap_connector = {}


@bp.route("/api/clusters/<cluster_id>/ldap/connector", methods=["GET", "POST"])
@require_auth(perms=["ldap.connector"])
def ldap_connector(cluster_id):
    """Return or update the LDAP connector configuration."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "connector": _ldap_connector.get(
                cluster_id,
                {"enabled": False, "url": "", "bind_dn": ""},
            ),
        })

    data = request.get_json() or {}
    connector = data.get("connector", {})
    enabled = bool(connector.get("enabled", False))
    url = str(connector.get("url", ""))
    bind_dn = str(connector.get("bind_dn", ""))

    config = {"enabled": enabled, "url": url, "bind_dn": bind_dn}
    _ldap_connector[cluster_id] = config
    log_audit(
        request.session.get("user", "system"),
        "ldap.connector",
        f"Updated LDAP connector for {html.escape(cluster_id)}: enabled={enabled}",
        cluster=cluster_managers[cluster_id].config.name,
    )

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "connector": config,
    })


# In-memory LDAP sync log.
_ldap_sync_log = []


def _sync_ldap_users(cluster_id, connector):
    """Simulate syncing users from LDAP for the given cluster."""
    import time as _t

    synced = {
        "cluster_id": html.escape(cluster_id),
        "connector": connector,
        "users": [{"uid": f"user-{i}", "name": f"LDAP User {i}"} for i in range(5)],
        "synced_at": _t.monotonic(),
    }
    _ldap_sync_log.append(synced)
    return synced


@bp.route("/api/clusters/<cluster_id>/ldap/sync", methods=["POST"])
@require_auth(perms=["ldap.sync"])
def ldap_sync(cluster_id):
    """Trigger an LDAP user sync for the cluster."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    connector = _ldap_connector.get(cluster_id, {"enabled": False, "url": "", "bind_dn": ""})
    if not connector.get("enabled"):
        return jsonify({"ok": False, "error": "LDAP connector is not enabled"}), 400

    result = _sync_ldap_users(cluster_id, connector)
    log_audit(
        request.session.get("user", "system"),
        "ldap.sync",
        f"Synced LDAP users for {html.escape(cluster_id)}",
        cluster=cluster_managers[cluster_id].config.name,
    )

    return jsonify({"ok": True, "data": result})


def _import_ldap_users(users):
    """Import a list of LDAP users into the local user store."""
    imported = []
    for user in users:
        imported.append({"uid": user.get("uid"), "name": user.get("name"), "source": "ldap"})
    return imported


@bp.route("/api/clusters/<cluster_id>/ldap/import", methods=["POST"])
@require_auth(perms=["ldap.import"])
def ldap_import(cluster_id):
    """Import users from a synced LDAP result into the cluster."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    data = request.get_json() or {}
    users = data.get("users", [])
    if not isinstance(users, list):
        return jsonify({"ok": False, "error": "users must be a list"}), 400

    result = _import_ldap_users(users)
    log_audit(
        request.session.get("user", "system"),
        "ldap.import",
        f"Imported {len(result)} LDAP users for {html.escape(cluster_id)}",
        cluster=cluster_managers[cluster_id].config.name,
    )

    return jsonify({"ok": True, "data": {"imported": result, "total": len(result)}})


# In-memory LDAP template library.
_ldap_templates = {}
_ldap_template_counter = 0


def _create_ldap_template(cluster_id, name, filters):
    """Create a reusable LDAP search template for the given cluster."""
    global _ldap_template_counter
    _ldap_template_counter += 1
    template_id = f"ldap-template-{_ldap_template_counter}"
    _ldap_templates[template_id] = {
        "id": template_id,
        "cluster_id": html.escape(cluster_id),
        "name": html.escape(str(name)),
        "filters": filters or {},
    }
    return _ldap_templates[template_id]


def _get_ldap_templates(cluster_id):
    """Return the LDAP templates associated with a cluster."""
    return [t for t in _ldap_templates.values() if t["cluster_id"] == html.escape(cluster_id)]


@bp.route("/api/clusters/<cluster_id>/ldap/templates", methods=["GET", "POST"])
@require_auth(perms=["ldap.templates"])
def ldap_templates(cluster_id):
    """List or create LDAP search templates for the cluster."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    if request.method == "GET":
        return jsonify({"ok": True, "data": _get_ldap_templates(cluster_id)})

    data = request.get_json() or {}
    name = data.get("name")
    if not name:
        return jsonify({"ok": False, "error": "name is required"}), 400
    template = _create_ldap_template(cluster_id, name, data.get("filters", {}))
    log_audit(
        request.session.get("user", "system"),
        "ldap.templates",
        f"Created LDAP template {template['id']} for {html.escape(cluster_id)}",
        cluster=cluster_managers[cluster_id].config.name,
    )
    return jsonify({"ok": True, "data": template})


@bp.route("/api/clusters/<cluster_id>/ldap/widget", methods=["GET"])
@require_auth(perms=["ldap.widget"])
def ldap_widget(cluster_id):
    """Return a dashboard widget summary of LDAP state for the cluster."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    connector = _ldap_connector.get(cluster_id, {"enabled": False})
    syncs = [s for s in _ldap_sync_log if s["cluster_id"] == html.escape(cluster_id)]
    templates = _get_ldap_templates(cluster_id)
    return jsonify({
        "ok": True,
        "data": {
            "enabled": connector.get("enabled", False),
            "last_syncs": syncs[-5:],
            "template_count": len(templates),
        },
    })


# In-memory LDAP alert channel store.
_ldap_alert_channels = {}


@bp.route("/api/clusters/<cluster_id>/ldap/alert", methods=["GET", "POST"])
@require_auth(perms=["ldap.alert"])
def ldap_alert_channel(cluster_id):
    """Return or update the LDAP alert channel configuration."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "alert": _ldap_alert_channels.get(
                cluster_id,
                {"enabled": False, "recipients": []},
            ),
        })

    data = request.get_json() or {}
    alert = data.get("alert", {})
    enabled = bool(alert.get("enabled", False))
    recipients = list(alert.get("recipients", []))

    config = {"enabled": enabled, "recipients": recipients}
    _ldap_alert_channels[cluster_id] = config
    log_audit(
        request.session.get("user", "system"),
        "ldap.alert",
        f"Updated LDAP alert channel for {html.escape(cluster_id)}: enabled={enabled}",
        cluster=cluster_managers[cluster_id].config.name,
    )

    return jsonify({
        "ok": True,
        "cluster": html.escape(cluster_id),
        "alert": config,
    })


# In-memory LDAP policy adapter store.
_ldap_policy_adapter = {}


@bp.route("/api/clusters/<cluster_id>/ldap/policy", methods=["GET", "POST"])
@require_auth(perms=["ldap.policy"])
def ldap_policy_adapter(cluster_id):
    """Return or update the LDAP policy adapter configuration."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "policy": _ldap_policy_adapter.get(
                cluster_id,
                {"enabled": False, "rules": []},
            ),
        })

    data = request.get_json() or {}
    policy = data.get("policy", {})
    enabled = bool(policy.get("enabled", False))
    rules = list(policy.get("rules", []))

    config = {"enabled": enabled, "rules": rules}
    _ldap_policy_adapter[cluster_id] = config
    log_audit(
        request.session.get("user", "system"),
        "ldap.policy",
        f"Updated LDAP policy for {html.escape(cluster_id)}: enabled={enabled}",
        cluster=cluster_managers[cluster_id].config.name,
    )

    return jsonify({
        "ok": True,
        "cluster": html.escape(cluster_id),
        "policy": config,
    })


# In-memory LDAP role mapping store.
_ldap_role_mappings = {}


@bp.route("/api/clusters/<cluster_id>/ldap/role-mapping", methods=["GET", "POST"])
@require_auth(perms=["ldap.role_mapping"])
def ldap_role_mapping(cluster_id):
    """Return or update the LDAP role mapping configuration."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "role_mapping": _ldap_role_mappings.get(
                cluster_id,
                {"enabled": False, "groups": []},
            ),
        })

    data = request.get_json() or {}
    mapping = data.get("role_mapping", {})
    enabled = bool(mapping.get("enabled", False))
    groups = list(mapping.get("groups", []))

    config = {"enabled": enabled, "groups": groups}
    _ldap_role_mappings[cluster_id] = config
    log_audit(
        request.session.get("user", "system"),
        "ldap.role_mapping",
        f"Updated LDAP role mapping for {html.escape(cluster_id)}: enabled={enabled}",
        cluster=cluster_managers[cluster_id].config.name,
    )

    return jsonify({
        "ok": True,
        "cluster": html.escape(cluster_id),
        "role_mapping": config,
    })


# In-memory LDAP automation workflow store.
_ldap_workflows = {}
_ldap_workflow_counter = 0


def _create_ldap_workflow(cluster_id, name, steps):
    """Create a reusable LDAP automation workflow for the cluster."""
    global _ldap_workflow_counter
    _ldap_workflow_counter += 1
    workflow_id = f"ldap-workflow-{_ldap_workflow_counter}"
    _ldap_workflows[workflow_id] = {
        "id": workflow_id,
        "cluster_id": html.escape(cluster_id),
        "name": html.escape(str(name)),
        "steps": steps or [],
    }
    return _ldap_workflows[workflow_id]


@bp.route("/api/clusters/<cluster_id>/ldap/workflow", methods=["POST"])
@require_auth(perms=["ldap.workflow"])
def ldap_workflow(cluster_id):
    """Create an LDAP automation workflow for the cluster."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    data = request.get_json() or {}
    name = data.get("name")
    if not name:
        return jsonify({"ok": False, "error": "name is required"}), 400
    workflow = _create_ldap_workflow(cluster_id, name, data.get("steps", []))
    log_audit(
        request.session.get("user", "system"),
        "ldap.workflow",
        f"Created LDAP workflow {workflow['id']} for {html.escape(cluster_id)}",
        cluster=cluster_managers[cluster_id].config.name,
    )
    return jsonify({"ok": True, "data": workflow})
