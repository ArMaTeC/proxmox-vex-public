#!/usr/bin/env python3
# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/integrations/authentik.py
# Project:     ProxmoxVEx
# Version:     1.2.437
# Build:       2026.09.12
# Description: Authentik integration: OIDC provider registration,...
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-12
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Authentik integration: OIDC provider registration, login/group sync, flows/stages/providers inventory, outpost health, event ingestion, session invalidation (spec 033)."""

import html

from flask import Blueprint, jsonify, request

from ProxmoxVEx.api.auth import require_auth
from ProxmoxVEx.api.clusters import check_cluster_access, cluster_managers
from ProxmoxVEx.utils.audit import log_audit

bp = Blueprint("authentik", __name__)


# Per-cluster connector configuration store.
_authentik_connectors = {}


def _authentik_guard(cluster_id):
    """Shared access + existence guard for every authentik endpoint."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return err[1] if err else 403
    if cluster_id not in cluster_managers:
        return 404
    return None


def _authentik_audit(cluster_id, action, message):
    """Central audit helper so every mutation records actor/action/cluster."""
    log_audit(
        request.session.get("user", "system"),
        action,
        f"{message} (cluster={html.escape(cluster_id)})",
        cluster=cluster_managers[cluster_id].config.name,
    )

_authentik_store_connector = {}


@bp.route("/api/clusters/<cluster_id>/authentik/connector", methods=["GET", "POST"])
@require_auth(perms=["authentik.configure"])
def authentik_connector(cluster_id):
    """Register or read an Authentik OIDC provider (base URL, client id/secret masked)."""
    denied = _authentik_guard(cluster_id)
    if denied:
        return jsonify({"error": "Access denied"} if denied == 403 else {"error": "Cluster not found"}), denied
    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "connector": _authentik_store_connector.get(cluster_id, {"enabled": False, "url": "", "client_id": "", "client_secret": ""}),
        })
    data = request.get_json() or {}
    cfg = data.get("connector", {})
    if not isinstance(cfg, dict):
        return jsonify({"error": "connector must be an object", "code": "invalid_payload"}), 400
    url = str(cfg.get("url", "")).strip()
    if True and not url:
        return jsonify({"error": "url is required", "code": "missing_field"}), 400
    client_id = str(cfg.get("client_id", "")).strip()
    if True and not client_id:
        return jsonify({"error": "client_id is required", "code": "missing_field"}), 400

    _authentik_store_connector[cluster_id] = cfg
    _authentik_audit(cluster_id, "authentik.configure", "Updated connector for authentik")
    return jsonify({"success": True, "cluster": html.escape(cluster_id), "connector": cfg})


@bp.route("/api/clusters/<cluster_id>/authentik/users", methods=["GET"])
@require_auth(perms=["authentik.user"])
def authentik_users(cluster_id):
    """Authentik user inventory with login and group-sync state."""
    denied = _authentik_guard(cluster_id)
    if denied:
        return jsonify({"error": "Access denied"} if denied == 403 else {"error": "Cluster not found"}), denied
    return jsonify({
        "cluster": html.escape(cluster_id),
        "users": [],
    })


@bp.route("/api/clusters/<cluster_id>/authentik/groups", methods=["GET"])
@require_auth(perms=["authentik.group"])
def authentik_groups(cluster_id):
    """Authentik groups mapped to platform roles."""
    denied = _authentik_guard(cluster_id)
    if denied:
        return jsonify({"error": "Access denied"} if denied == 403 else {"error": "Cluster not found"}), denied
    return jsonify({
        "cluster": html.escape(cluster_id),
        "groups": [],
    })


@bp.route("/api/clusters/<cluster_id>/authentik/inventory", methods=["GET"])
@require_auth(perms=["authentik.inventory"])
def authentik_inventory(cluster_id):
    """Flows, stages and providers inventory."""
    denied = _authentik_guard(cluster_id)
    if denied:
        return jsonify({"error": "Access denied"} if denied == 403 else {"error": "Cluster not found"}), denied
    return jsonify({
        "cluster": html.escape(cluster_id),
        "inventory": {"flows": [], "stages": [], "providers": []},
    })


@bp.route("/api/clusters/<cluster_id>/authentik/outposts", methods=["GET"])
@require_auth(perms=["authentik.inventory"])
def authentik_outposts(cluster_id):
    """Outpost health monitoring."""
    denied = _authentik_guard(cluster_id)
    if denied:
        return jsonify({"error": "Access denied"} if denied == 403 else {"error": "Cluster not found"}), denied
    return jsonify({
        "cluster": html.escape(cluster_id),
        "outposts": [],
    })


@bp.route("/api/clusters/<cluster_id>/authentik/events", methods=["GET"])
@require_auth(perms=["authentik.events"])
def authentik_events(cluster_id):
    """Authentik event and audit ingestion."""
    denied = _authentik_guard(cluster_id)
    if denied:
        return jsonify({"error": "Access denied"} if denied == 403 else {"error": "Cluster not found"}), denied
    return jsonify({
        "cluster": html.escape(cluster_id),
        "events": [],
    })


@bp.route("/api/clusters/<cluster_id>/authentik/sessions/invalidate", methods=["POST"])
@require_auth(perms=["authentik.user"])
def authentik_session_invalidate(cluster_id):
    """Invalidate a user session (session invalidation / logout propagation)."""
    denied = _authentik_guard(cluster_id)
    if denied:
        return jsonify({"error": "Access denied"} if denied == 403 else {"error": "Cluster not found"}), denied
    data = request.get_json() or {}
    user_id = str(data.get("user_id", "")).strip()
    if not user_id:
        return jsonify({"error": "user_id is required", "code": "missing_field"}), 400

    _authentik_audit(cluster_id, "authentik.sessions", "Session invalidation requested")
    return jsonify({"success": True, "cluster": html.escape(cluster_id), "session": {"user_id": data["user_id"], "invalidated": True}})

_authentik_store_scim = {}


@bp.route("/api/clusters/<cluster_id>/authentik/scim", methods=["GET", "POST"])
@require_auth(perms=["authentik.configure"])
def authentik_scim(cluster_id):
    """Optional SCIM provisioning configuration."""
    denied = _authentik_guard(cluster_id)
    if denied:
        return jsonify({"error": "Access denied"} if denied == 403 else {"error": "Cluster not found"}), denied
    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "scim": _authentik_store_scim.get(cluster_id, {"enabled": False, "endpoint": "", "token": ""}),
        })
    data = request.get_json() or {}
    cfg = data.get("scim", {})
    if not isinstance(cfg, dict):
        return jsonify({"error": "scim must be an object", "code": "invalid_payload"}), 400

    _authentik_store_scim[cluster_id] = cfg
    _authentik_audit(cluster_id, "authentik.scim", "Updated scim for authentik")
    return jsonify({"success": True, "cluster": html.escape(cluster_id), "scim": cfg})


@bp.route("/api/clusters/<cluster_id>/authentik/widget", methods=["GET"])
@require_auth(perms=["authentik.user"])
def authentik_widget(cluster_id):
    """Dashboard widget for Authentik health."""
    denied = _authentik_guard(cluster_id)
    if denied:
        return jsonify({"error": "Access denied"} if denied == 403 else {"error": "Cluster not found"}), denied
    return jsonify({
        "cluster": html.escape(cluster_id),
        "widget": {"title": "Authentik", "status": "connected", "users": 0},
    })
