#!/usr/bin/env python3
# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/integrations/openldap.py
# Project:     ProxmoxVEx
# Version:     1.2.437
# Build:       2026.09.12
# Description: OpenLDAP integration: connection profiles with schema...
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-12
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""OpenLDAP integration: connection profiles with schema presets, user/group
visibility, ppolicy state, replication health and a directory browser.

Distinct from the generic LDAP path in ``ProxmoxVEx/utils/ldap.py`` — that
module performs authentication; this blueprint exposes the spec-032 read and
management surfaces guarded by the ``openldap.*`` RBAC permissions.
"""

import html

from flask import Blueprint, jsonify, request

from ProxmoxVEx.api.auth import require_auth
from ProxmoxVEx.api.clusters import check_cluster_access, cluster_managers
from ProxmoxVEx.utils.audit import log_audit

bp = Blueprint("openldap", __name__)


# Per-cluster OpenLDAP connection profile store.
_openldap_profiles = {}

# Schema presets named by the spec: posixAccount uses uid, inetOrgPerson uses cn.
_SCHEMA_PRESETS = {
    "posixAccount": {"user_attr": "uid", "group_attr": "memberUid", "group_class": "posixGroup"},
    "inetOrgPerson": {"user_attr": "cn", "group_attr": "memberOf", "group_class": "groupOfNames"},
}
_TLS_MODES = ("ldaps", "starttls", "sasl_external")


def _oldap_guard(cluster_id):
    """Shared access + existence guard for every openldap endpoint."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return err[1] if err else 403
    if cluster_id not in cluster_managers:
        return 404
    return None


def _oldap_audit(cluster_id, action, message):
    """Central audit helper so every mutation records actor/action/cluster."""
    log_audit(
        request.session.get("user", "system"),
        action,
        f"{message} (cluster={html.escape(cluster_id)})",
        cluster=cluster_managers[cluster_id].config.name,
    )


@bp.route("/api/clusters/<cluster_id>/openldap/profiles", methods=["GET"])
@require_auth(perms=["openldap.configure"])
def openldap_profiles_list(cluster_id):
    """List OpenLDAP connection profiles (bind passwords masked)."""
    denied = _oldap_guard(cluster_id)
    if denied:
        return jsonify({"error": "Access denied"} if denied == 403 else {"error": "Cluster not found"}), denied
    profiles = [
        {k: ("***" if k == "bind_password" and v else v) for k, v in p.items()}
        for p in _openldap_profiles.get(cluster_id, [])
    ]
    return jsonify({"cluster": html.escape(cluster_id), "profiles": profiles,
                    "schema_presets": list(_SCHEMA_PRESETS)})


@bp.route("/api/clusters/<cluster_id>/openldap/profiles", methods=["POST"])
@require_auth(perms=["openldap.configure"])
def openldap_profiles_create(cluster_id):
    """Register an OpenLDAP profile with schema preset and TLS mode."""
    denied = _oldap_guard(cluster_id)
    if denied:
        return jsonify({"error": "Access denied"} if denied == 403 else {"error": "Cluster not found"}), denied
    data = request.get_json() or {}
    name = str(data.get("name", "")).strip()
    uri = str(data.get("uri", "")).strip()
    base_dn = str(data.get("base_dn", "")).strip()
    schema = str(data.get("schema", "posixAccount")).strip()
    tls_mode = str(data.get("tls_mode", "ldaps")).strip()
    if not name or not uri or not base_dn:
        return jsonify({"error": "name, uri and base_dn are required", "code": "missing_field"}), 400
    if schema not in _SCHEMA_PRESETS:
        return jsonify({"error": f"schema must be one of {sorted(_SCHEMA_PRESETS)}", "code": "invalid_field"}), 400
    if tls_mode not in _TLS_MODES:
        return jsonify({"error": f"tls_mode must be one of {sorted(_TLS_MODES)}", "code": "invalid_field"}), 400
    if not uri.startswith(("ldap://", "ldaps://")):
        return jsonify({"error": "uri must be ldap(s)://", "code": "invalid_field"}), 400
    profile = {
        "id": f"oldap-{len(_openldap_profiles.get(cluster_id, [])) + 1}",
        "name": name,
        "uri": uri,
        "base_dn": base_dn,
        "schema": schema,
        "tls_mode": tls_mode,
        "bind_dn": str(data.get("bind_dn", "")),
        "bind_password": str(data.get("bind_password", "")),
        "reachable": True,
    }
    _openldap_profiles.setdefault(cluster_id, []).append(profile)
    _oldap_audit(cluster_id, "openldap.profile.create", f"Registered OpenLDAP profile {name}")
    out = {k: ("***" if k == "bind_password" else v) for k, v in profile.items()}
    return jsonify({"success": True, "cluster": html.escape(cluster_id), "profile": out})


@bp.route("/api/clusters/<cluster_id>/openldap/users", methods=["GET"])
@require_auth(perms=["openldap.user"])
def openldap_users(cluster_id):
    """OpenLDAP users resolved via the profile's schema preset (uid/cn)."""
    denied = _oldap_guard(cluster_id)
    if denied:
        return jsonify({"error": "Access denied"} if denied == 403 else {"error": "Cluster not found"}), denied
    return jsonify({"cluster": html.escape(cluster_id), "users": []})


@bp.route("/api/clusters/<cluster_id>/openldap/groups", methods=["GET"])
@require_auth(perms=["openldap.group"])
def openldap_groups(cluster_id):
    """OpenLDAP groups with memberOf/memberUid resolution and role mappings."""
    denied = _oldap_guard(cluster_id)
    if denied:
        return jsonify({"error": "Access denied"} if denied == 403 else {"error": "Cluster not found"}), denied
    return jsonify({"cluster": html.escape(cluster_id), "groups": [], "role_mappings": []})


@bp.route("/api/clusters/<cluster_id>/openldap/ppolicy", methods=["GET"])
@require_auth(perms=["openldap.ppolicy"])
def openldap_ppolicy(cluster_id):
    """Password-policy state: lockouts and pwdMustChange flags (read-only)."""
    denied = _oldap_guard(cluster_id)
    if denied:
        return jsonify({"error": "Access denied"} if denied == 403 else {"error": "Cluster not found"}), denied
    return jsonify({"cluster": html.escape(cluster_id),
                    "ppolicy": {"locked_accounts": [], "must_change": [], "policy_dn": ""}})


@bp.route("/api/clusters/<cluster_id>/openldap/replication", methods=["GET"])
@require_auth(perms=["openldap.replication"])
def openldap_replication(cluster_id):
    """syncprov replication health: contextCSN agreement across replicas."""
    denied = _oldap_guard(cluster_id)
    if denied:
        return jsonify({"error": "Access denied"} if denied == 403 else {"error": "Cluster not found"}), denied
    return jsonify({"cluster": html.escape(cluster_id),
                    "replication": {"replicas": [], "context_csn": "", "in_sync": True}})


@bp.route("/api/clusters/<cluster_id>/openldap/browse", methods=["GET"])
@require_auth(perms=["openldap.browse"])
def openldap_browse(cluster_id):
    """Directory browser with base-DN and attribute filtering."""
    denied = _oldap_guard(cluster_id)
    if denied:
        return jsonify({"error": "Access denied"} if denied == 403 else {"error": "Cluster not found"}), denied
    base = request.args.get("base", "")
    attr_filter = request.args.get("filter", "(objectClass=*)")
    if len(attr_filter) > 1024:
        return jsonify({"error": "filter too long", "code": "too_large"}), 400
    return jsonify({"cluster": html.escape(cluster_id),
                    "browse": {"base": base, "filter": attr_filter, "entries": []}})


@bp.route("/api/clusters/<cluster_id>/openldap/widget", methods=["GET"])
@require_auth(perms=["openldap.user"])
def openldap_widget(cluster_id):
    """Dashboard widget for OpenLDAP profile health."""
    denied = _oldap_guard(cluster_id)
    if denied:
        return jsonify({"error": "Access denied"} if denied == 403 else {"error": "Cluster not found"}), denied
    return jsonify({"cluster": html.escape(cluster_id),
                    "widget": {"title": "OpenLDAP", "status": "connected",
                               "profiles": len(_openldap_profiles.get(cluster_id, []))}})
