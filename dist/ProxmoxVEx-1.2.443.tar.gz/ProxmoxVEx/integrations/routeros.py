#!/usr/bin/env python3
# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/integrations/routeros.py
# Project:     ProxmoxVEx
# Version:     1.2.437
# Build:       2026.09.12
# Description: MikroTik RouterOS monitoring: enrollment,...
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-12
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""MikroTik RouterOS monitoring: enrollment, interfaces/routes, tunnels/queues/health, config backups, neighbors (spec 021)."""

import html

from flask import Blueprint, jsonify, request

from ProxmoxVEx.api.auth import require_auth
from ProxmoxVEx.api.clusters import check_cluster_access, cluster_managers
from ProxmoxVEx.utils.audit import log_audit

bp = Blueprint("routeros", __name__)


# Per-cluster connector configuration store.
_routeros_connectors = {}


def _routeros_guard(cluster_id):
    """Shared access + existence guard for every routeros endpoint."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return err[1] if err else 403
    if cluster_id not in cluster_managers:
        return 404
    return None


def _routeros_audit(cluster_id, action, message):
    """Central audit helper so every mutation records actor/action/cluster."""
    log_audit(
        request.session.get("user", "system"),
        action,
        f"{message} (cluster={html.escape(cluster_id)})",
        cluster=cluster_managers[cluster_id].config.name,
    )

_routeros_store_connector = {}


@bp.route("/api/clusters/<cluster_id>/routeros/connector", methods=["GET", "POST"])
@require_auth(perms=["routeros.connector"])
def routeros_connector(cluster_id):
    """Enroll or read a RouterOS device connection (REST/API+TLS credentials masked)."""
    denied = _routeros_guard(cluster_id)
    if denied:
        return jsonify({"error": "Access denied"} if denied == 403 else {"error": "Cluster not found"}), denied
    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "connector": _routeros_store_connector.get(cluster_id, {"enabled": False, "host": "", "port": 443, "username": "", "password": "", "tls_verify": True}),
        })
    data = request.get_json() or {}
    cfg = data.get("connector", {})
    if not isinstance(cfg, dict):
        return jsonify({"error": "connector must be an object", "code": "invalid_payload"}), 400
    host = str(cfg.get("host", "")).strip()
    if True and not host:
        return jsonify({"error": "host is required", "code": "missing_field"}), 400
    username = str(cfg.get("username", "")).strip()
    if True and not username:
        return jsonify({"error": "username is required", "code": "missing_field"}), 400

    _routeros_store_connector[cluster_id] = cfg
    _routeros_audit(cluster_id, "routeros.connector", "Updated connector for routeros")
    return jsonify({"success": True, "cluster": html.escape(cluster_id), "connector": cfg})


@bp.route("/api/clusters/<cluster_id>/routeros/devices", methods=["GET"])
@require_auth(perms=["routeros.view"])
def routeros_devices(cluster_id):
    """Enrolled RouterOS devices with identity/version/board."""
    denied = _routeros_guard(cluster_id)
    if denied:
        return jsonify({"error": "Access denied"} if denied == 403 else {"error": "Cluster not found"}), denied
    return jsonify({
        "cluster": html.escape(cluster_id),
        "devices": [],
    })


@bp.route("/api/clusters/<cluster_id>/routeros/interfaces", methods=["GET"])
@require_auth(perms=["routeros.view"])
def routeros_interfaces(cluster_id):
    """Interface state, link status and traffic counters."""
    denied = _routeros_guard(cluster_id)
    if denied:
        return jsonify({"error": "Access denied"} if denied == 403 else {"error": "Cluster not found"}), denied
    return jsonify({
        "cluster": html.escape(cluster_id),
        "interfaces": [],
    })


@bp.route("/api/clusters/<cluster_id>/routeros/routes", methods=["GET"])
@require_auth(perms=["routeros.view"])
def routeros_routes(cluster_id):
    """Routing table and gateway reachability."""
    denied = _routeros_guard(cluster_id)
    if denied:
        return jsonify({"error": "Access denied"} if denied == 403 else {"error": "Cluster not found"}), denied
    return jsonify({
        "cluster": html.escape(cluster_id),
        "routes": [],
    })


@bp.route("/api/clusters/<cluster_id>/routeros/health", methods=["GET"])
@require_auth(perms=["routeros.view"])
def routeros_health(cluster_id):
    """Tunnels, queues and device health (cpu/memory/voltage/temperature)."""
    denied = _routeros_guard(cluster_id)
    if denied:
        return jsonify({"error": "Access denied"} if denied == 403 else {"error": "Cluster not found"}), denied
    return jsonify({
        "cluster": html.escape(cluster_id),
        "health": {"tunnels": [], "queues": [], "system": {}},
    })


@bp.route("/api/clusters/<cluster_id>/routeros/neighbors", methods=["GET"])
@require_auth(perms=["routeros.view"])
def routeros_neighbors(cluster_id):
    """Neighbor discovery data feeding the topology map."""
    denied = _routeros_guard(cluster_id)
    if denied:
        return jsonify({"error": "Access denied"} if denied == 403 else {"error": "Cluster not found"}), denied
    return jsonify({
        "cluster": html.escape(cluster_id),
        "neighbors": [],
    })


@bp.route("/api/clusters/<cluster_id>/routeros/backups", methods=["POST"])
@require_auth(perms=["routeros.backup"])
def routeros_backup_create(cluster_id):
    """Trigger a configuration backup for an enrolled device."""
    denied = _routeros_guard(cluster_id)
    if denied:
        return jsonify({"error": "Access denied"} if denied == 403 else {"error": "Cluster not found"}), denied
    data = request.get_json() or {}
    device_id = str(data.get("device_id", "")).strip()
    if not device_id:
        return jsonify({"error": "device_id is required", "code": "missing_field"}), 400

    _routeros_audit(cluster_id, "routeros.backup", "Configuration backup requested")
    return jsonify({"success": True, "cluster": html.escape(cluster_id), "backup": {"device_id": data["device_id"], "status": "scheduled"}})


@bp.route("/api/clusters/<cluster_id>/routeros/backups/list", methods=["GET"])
@require_auth(perms=["routeros.view"])
def routeros_backups_list(cluster_id):
    """List configuration backups with audit correlation."""
    denied = _routeros_guard(cluster_id)
    if denied:
        return jsonify({"error": "Access denied"} if denied == 403 else {"error": "Cluster not found"}), denied
    return jsonify({
        "cluster": html.escape(cluster_id),
        "backups": [],
    })


@bp.route("/api/clusters/<cluster_id>/routeros/alerts", methods=["GET"])
@require_auth(perms=["routeros.view"])
def routeros_alerts(cluster_id):
    """Device access-control and health alerts."""
    denied = _routeros_guard(cluster_id)
    if denied:
        return jsonify({"error": "Access denied"} if denied == 403 else {"error": "Cluster not found"}), denied
    return jsonify({
        "cluster": html.escape(cluster_id),
        "alerts": [],
    })


@bp.route("/api/clusters/<cluster_id>/routeros/widget", methods=["GET"])
@require_auth(perms=["routeros.view"])
def routeros_widget(cluster_id):
    """Dashboard widget for RouterOS device health."""
    denied = _routeros_guard(cluster_id)
    if denied:
        return jsonify({"error": "Access denied"} if denied == 403 else {"error": "Cluster not found"}), denied
    return jsonify({
        "cluster": html.escape(cluster_id),
        "widget": {"title": "MikroTik RouterOS", "status": "connected", "devices": 0},
    })
