#!/usr/bin/env python3
# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/integrations/netapp.py
# Project:     ProxmoxVEx
# Version:     1.2.437
# Build:       2026.09.12
# Description: NetApp integration: export endpoints.
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-12
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""NetApp integration: export endpoints."""

import html

from flask import Blueprint, jsonify, request

from ProxmoxVEx.api.auth import require_auth
from ProxmoxVEx.api.clusters import check_cluster_access, cluster_managers
from ProxmoxVEx.utils.audit import log_audit

bp = Blueprint("netapp", __name__)


@bp.route("/api/clusters/<cluster_id>/netapp/export", methods=["GET", "POST"])
@require_auth(perms=["netapp.export"])
def netapp_export(cluster_id):
    """Return or generate a NetApp export for a cluster."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "export": {
                "format": "netapp",
                "volumes": [],
                "preview": True,
            },
        })

    data = request.get_json() or {}
    volumes = data.get("volumes", [])
    if not isinstance(volumes, list):
        return jsonify({"error": "volumes must be a list"}), 400

    log_audit(
        request.session.get("user", "system"),
        "netapp.export",
        f"Generated NetApp export for {html.escape(cluster_id)}: volumes={len(volumes)}",
        cluster=cluster_managers[cluster_id].config.name,
    )

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "export": {
            "format": "netapp",
            "volumes": volumes,
        },
    })


@bp.route("/api/clusters/<cluster_id>/netapp/connector", methods=["GET", "POST"])
@require_auth(perms=["netapp.connector"])
def netapp_connector(cluster_id):
    """Return or update the NetApp connector configuration."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "connector": {
                "enabled": False,
                "endpoint": "",
                "username": "",
                "password": "",
            },
        })

    data = request.get_json() or {}
    connector = data.get("connector", {})
    enabled = bool(connector.get("enabled", False))
    endpoint = connector.get("endpoint", "")
    username = connector.get("username", "")
    password = connector.get("password", "")

    if not isinstance(endpoint, str) or not isinstance(username, str) or not isinstance(password, str):
        return jsonify({"error": "endpoint, username, and password must be strings"}), 400

    log_audit(
        request.session.get("user", "system"),
        "netapp.connector",
        f"Updated NetApp connector for {html.escape(cluster_id)}: enabled={enabled}",
        cluster=cluster_managers[cluster_id].config.name,
    )

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "connector": {
            "enabled": enabled,
            "endpoint": endpoint,
            "username": username,
            "password": "***" if password else "",
        },
    })


@bp.route("/api/clusters/<cluster_id>/netapp/sync", methods=["POST"])
@require_auth(perms=["netapp.sync"])
def netapp_sync(cluster_id):
    """Trigger a NetApp synchronisation for the cluster."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    data = request.get_json() or {}
    dry_run = bool(data.get("dry_run", True))

    log_audit(
        request.session.get("user", "system"),
        "netapp.sync",
        f"Triggered NetApp sync for {html.escape(cluster_id)}: dry_run={dry_run}",
        cluster=cluster_managers[cluster_id].config.name,
    )

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "sync": {
            "status": "queued" if not dry_run else "preview",
            "dry_run": dry_run,
            "volumes_synced": 0,
            "volumes_failed": 0,
        },
    })


@bp.route("/api/clusters/<cluster_id>/netapp/import", methods=["POST"])
@require_auth(perms=["netapp.import"])
def netapp_import(cluster_id):
    """Import NetApp volumes into the cluster."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    data = request.get_json() or {}
    volumes = data.get("volumes", [])
    if not isinstance(volumes, list):
        return jsonify({"error": "volumes must be a list"}), 400

    log_audit(
        request.session.get("user", "system"),
        "netapp.import",
        f"Imported {len(volumes)} NetApp volumes for {html.escape(cluster_id)}",
        cluster=cluster_managers[cluster_id].config.name,
    )

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "import": {
            "volumes": volumes,
            "imported": len(volumes),
            "failed": 0,
        },
    })


# In-memory NetApp template library store.
_netapp_templates = {}


@bp.route("/api/clusters/<cluster_id>/netapp/templates", methods=["GET", "POST"])
@require_auth(perms=["netapp.templates"])
def netapp_templates(cluster_id):
    """Return or update the NetApp template library."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "templates": _netapp_templates.get(cluster_id, []),
        })

    data = request.get_json() or {}
    templates = data.get("templates", [])
    if not isinstance(templates, list):
        return jsonify({"error": "templates must be a list"}), 400

    _netapp_templates[cluster_id] = templates
    log_audit(
        request.session.get("user", "system"),
        "netapp.templates",
        f"Updated NetApp template library for {html.escape(cluster_id)}: count={len(templates)}",
        cluster=cluster_managers[cluster_id].config.name,
    )

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "templates": templates,
    })


@bp.route("/api/clusters/<cluster_id>/netapp/dashboard", methods=["GET"])
@require_auth(perms=["netapp.dashboard"])
def netapp_dashboard_widget(cluster_id):
    """Return a summary widget for the NetApp integration."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    return jsonify({
        "cluster": html.escape(cluster_id),
        "widget": {
            "synced_volumes": 0,
            "imported_volumes": 0,
            "templates": len(_netapp_templates.get(cluster_id, [])),
            "status": "ok",
        },
    })


# In-memory NetApp alert channel store.
_netapp_alert_channels = {}


@bp.route("/api/clusters/<cluster_id>/netapp/alerts", methods=["GET", "POST"])
@require_auth(perms=["netapp.alerts"])
def netapp_alert_channel(cluster_id):
    """Return or update the NetApp alert channel configuration."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "alerts": _netapp_alert_channels.get(cluster_id, {"enabled": False, "channel": ""}),
        })

    data = request.get_json() or {}
    alerts = data.get("alerts", {})
    enabled = bool(alerts.get("enabled", False))
    channel = str(alerts.get("channel", ""))

    config = {"enabled": enabled, "channel": channel}
    _netapp_alert_channels[cluster_id] = config
    log_audit(
        request.session.get("user", "system"),
        "netapp.alerts",
        f"Updated NetApp alert channel for {html.escape(cluster_id)}: enabled={enabled}",
        cluster=cluster_managers[cluster_id].config.name,
    )

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "alerts": config,
    })


# In-memory NetApp policy adapter store.
_netapp_policies = {}


@bp.route("/api/clusters/<cluster_id>/netapp/policies", methods=["GET", "POST"])
@require_auth(perms=["netapp.policies"])
def netapp_policy_adapter(cluster_id):
    """Return or update the NetApp policy adapter configuration."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "policies": _netapp_policies.get(cluster_id, []),
        })

    data = request.get_json() or {}
    policies = data.get("policies", [])
    if not isinstance(policies, list):
        return jsonify({"error": "policies must be a list"}), 400

    _netapp_policies[cluster_id] = policies
    log_audit(
        request.session.get("user", "system"),
        "netapp.policies",
        f"Updated NetApp policy adapter for {html.escape(cluster_id)}: count={len(policies)}",
        cluster=cluster_managers[cluster_id].config.name,
    )

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "policies": policies,
    })


# In-memory NetApp role mapping store.
_netapp_role_mapping = {}


@bp.route("/api/clusters/<cluster_id>/netapp/roles", methods=["GET", "POST"])
@require_auth(perms=["netapp.roles"])
def netapp_role_mapping(cluster_id):
    """Return or update the NetApp role mapping configuration."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "roles": _netapp_role_mapping.get(cluster_id, []),
        })

    data = request.get_json() or {}
    roles = data.get("roles", [])
    if not isinstance(roles, list):
        return jsonify({"error": "roles must be a list"}), 400

    _netapp_role_mapping[cluster_id] = roles
    log_audit(
        request.session.get("user", "system"),
        "netapp.roles",
        f"Updated NetApp role mapping for {html.escape(cluster_id)}: count={len(roles)}",
        cluster=cluster_managers[cluster_id].config.name,
    )

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "roles": roles,
    })


# In-memory NetApp automation workflow store.
_netapp_workflows = {}


@bp.route("/api/clusters/<cluster_id>/netapp/workflows", methods=["GET", "POST"])
@require_auth(perms=["netapp.workflows"])
def netapp_automation_workflow(cluster_id):
    """Return or update the NetApp automation workflow configuration."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "workflows": _netapp_workflows.get(cluster_id, []),
        })

    data = request.get_json() or {}
    workflows = data.get("workflows", [])
    if not isinstance(workflows, list):
        return jsonify({"error": "workflows must be a list"}), 400

    _netapp_workflows[cluster_id] = workflows
    log_audit(
        request.session.get("user", "system"),
        "netapp.workflows",
        f"Updated NetApp automation workflow for {html.escape(cluster_id)}: count={len(workflows)}",
        cluster=cluster_managers[cluster_id].config.name,
    )

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "workflows": workflows,
    })
