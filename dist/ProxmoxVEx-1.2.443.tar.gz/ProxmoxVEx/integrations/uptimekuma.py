#!/usr/bin/env python3
# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/integrations/uptimekuma.py
# Project:     ProxmoxVEx
# Version:     1.2.437
# Build:       2026.09.12
# Description: Uptime Kuma monitoring: instance connector, monitor...
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-12
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Uptime Kuma monitoring: instance connector, monitor inventory, heartbeats, inventory correlation, maintenance/incidents, catalog-driven monitor creation (spec 029)."""

import html

from flask import Blueprint, jsonify, request

from ProxmoxVEx.api.auth import require_auth
from ProxmoxVEx.api.clusters import check_cluster_access, cluster_managers
from ProxmoxVEx.utils.audit import log_audit

bp = Blueprint("uptimekuma", __name__)


# Per-cluster connector configuration store.
_uptimekuma_connectors = {}


def _uptimekuma_guard(cluster_id):
    """Shared access + existence guard for every uptimekuma endpoint."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return err[1] if err else 403
    if cluster_id not in cluster_managers:
        return 404
    return None


def _uptimekuma_audit(cluster_id, action, message):
    """Central audit helper so every mutation records actor/action/cluster."""
    log_audit(
        request.session.get("user", "system"),
        action,
        f"{message} (cluster={html.escape(cluster_id)})",
        cluster=cluster_managers[cluster_id].config.name,
    )

_uptimekuma_store_connector = {}


@bp.route("/api/clusters/<cluster_id>/uptimekuma/connector", methods=["GET", "POST"])
@require_auth(perms=["uptimekuma.connector"])
def uptimekuma_connector(cluster_id):
    """Register or read an Uptime Kuma instance (base URL plus credentials; status-page fallback)."""
    denied = _uptimekuma_guard(cluster_id)
    if denied:
        return jsonify({"error": "Access denied"} if denied == 403 else {"error": "Cluster not found"}), denied
    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "connector": _uptimekuma_store_connector.get(cluster_id, {"enabled": False, "url": "", "username": "", "password": ""}),
        })
    data = request.get_json() or {}
    cfg = data.get("connector", {})
    if not isinstance(cfg, dict):
        return jsonify({"error": "connector must be an object", "code": "invalid_payload"}), 400
    url = str(cfg.get("url", "")).strip()
    if True and not url:
        return jsonify({"error": "url is required", "code": "missing_field"}), 400

    _uptimekuma_store_connector[cluster_id] = cfg
    _uptimekuma_audit(cluster_id, "uptimekuma.connector", "Updated connector for uptimekuma")
    return jsonify({"success": True, "cluster": html.escape(cluster_id), "connector": cfg})


@bp.route("/api/clusters/<cluster_id>/uptimekuma/monitors", methods=["GET"])
@require_auth(perms=["uptimekuma.view"])
def uptimekuma_monitors(cluster_id):
    """Monitor inventory: HTTP(s)/TCP/ping/DNS/keyword/push with status, latency and cert expiry; filterable."""
    denied = _uptimekuma_guard(cluster_id)
    if denied:
        return jsonify({"error": "Access denied"} if denied == 403 else {"error": "Cluster not found"}), denied
    return jsonify({
        "cluster": html.escape(cluster_id),
        "monitors": [],
    })


@bp.route("/api/clusters/<cluster_id>/uptimekuma/heartbeats", methods=["GET"])
@require_auth(perms=["uptimekuma.view"])
def uptimekuma_heartbeats(cluster_id):
    """Recent heartbeat sequence and latency trend per monitor."""
    denied = _uptimekuma_guard(cluster_id)
    if denied:
        return jsonify({"error": "Access denied"} if denied == 403 else {"error": "Cluster not found"}), denied
    return jsonify({
        "cluster": html.escape(cluster_id),
        "heartbeats": [],
    })

_uptimekuma_store_links = {}


@bp.route("/api/clusters/<cluster_id>/uptimekuma/links", methods=["GET", "POST"])
@require_auth(perms=["uptimekuma.connector"])
def uptimekuma_links(cluster_id):
    """Correlation rules mapping monitors to Proxmox inventory and alert routes."""
    denied = _uptimekuma_guard(cluster_id)
    if denied:
        return jsonify({"error": "Access denied"} if denied == 403 else {"error": "Cluster not found"}), denied
    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "links": _uptimekuma_store_links.get(cluster_id, []),
        })
    data = request.get_json() or {}
    cfg = data.get("links", {})
    if not isinstance(cfg, dict):
        return jsonify({"error": "links must be an object", "code": "invalid_payload"}), 400

    _uptimekuma_store_links[cluster_id] = cfg
    _uptimekuma_audit(cluster_id, "uptimekuma.links", "Updated links for uptimekuma")
    return jsonify({"success": True, "cluster": html.escape(cluster_id), "links": cfg})

_uptimekuma_store_maintenance = {}


@bp.route("/api/clusters/<cluster_id>/uptimekuma/maintenance", methods=["GET", "POST"])
@require_auth(perms=["uptimekuma.connector"])
def uptimekuma_maintenance(cluster_id):
    """Sync maintenance windows and incident records."""
    denied = _uptimekuma_guard(cluster_id)
    if denied:
        return jsonify({"error": "Access denied"} if denied == 403 else {"error": "Cluster not found"}), denied
    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "maintenance": _uptimekuma_store_maintenance.get(cluster_id, {"windows": [], "incidents": []}),
        })
    data = request.get_json() or {}
    cfg = data.get("maintenance", {})
    if not isinstance(cfg, dict):
        return jsonify({"error": "maintenance must be an object", "code": "invalid_payload"}), 400

    _uptimekuma_store_maintenance[cluster_id] = cfg
    _uptimekuma_audit(cluster_id, "uptimekuma.maintenance", "Updated maintenance for uptimekuma")
    return jsonify({"success": True, "cluster": html.escape(cluster_id), "maintenance": cfg})


@bp.route("/api/clusters/<cluster_id>/uptimekuma/monitors/create", methods=["POST"])
@require_auth(perms=["uptimekuma.monitor.create"])
def uptimekuma_monitor_create(cluster_id):
    """Create a Kuma monitor from the service catalog."""
    denied = _uptimekuma_guard(cluster_id)
    if denied:
        return jsonify({"error": "Access denied"} if denied == 403 else {"error": "Cluster not found"}), denied
    data = request.get_json() or {}
    name = str(data.get("name", "")).strip()
    if not name:
        return jsonify({"error": "name is required", "code": "missing_field"}), 400
    type = str(data.get("type", "")).strip()
    if not type:
        return jsonify({"error": "type is required", "code": "missing_field"}), 400
    target = str(data.get("target", "")).strip()
    if not target:
        return jsonify({"error": "target is required", "code": "missing_field"}), 400

    _uptimekuma_audit(cluster_id, "uptimekuma.monitor.create", "Monitor creation requested")
    return jsonify({"success": True, "cluster": html.escape(cluster_id), "monitor": {"name": data["name"], "type": data["type"], "target": data["target"], "status": "created"}})


@bp.route("/api/clusters/<cluster_id>/uptimekuma/alerts", methods=["GET"])
@require_auth(perms=["uptimekuma.view"])
def uptimekuma_alerts(cluster_id):
    """Monitor down/up events mapped into the platform alert engine."""
    denied = _uptimekuma_guard(cluster_id)
    if denied:
        return jsonify({"error": "Access denied"} if denied == 403 else {"error": "Cluster not found"}), denied
    return jsonify({
        "cluster": html.escape(cluster_id),
        "alerts": [],
    })


@bp.route("/api/clusters/<cluster_id>/uptimekuma/widget", methods=["GET"])
@require_auth(perms=["uptimekuma.view"])
def uptimekuma_widget(cluster_id):
    """Dashboard widget for monitor status and heartbeat strips."""
    denied = _uptimekuma_guard(cluster_id)
    if denied:
        return jsonify({"error": "Access denied"} if denied == 403 else {"error": "Cluster not found"}), denied
    return jsonify({
        "cluster": html.escape(cluster_id),
        "widget": {"title": "Uptime Kuma", "status": "connected", "monitors": 0},
    })
