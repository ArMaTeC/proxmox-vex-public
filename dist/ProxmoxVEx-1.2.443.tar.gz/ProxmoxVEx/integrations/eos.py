#!/usr/bin/env python3
# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/integrations/eos.py
# Project:     ProxmoxVEx
# Version:     1.2.437
# Build:       2026.09.12
# Description: Arista EOS visibility: eAPI/SNMP enrollment,...
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-12
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Arista EOS visibility: eAPI/SNMP enrollment, interfaces/optics/port-channels, MLAG/BGP-EVPN/VXLAN fabric, environment, config backups (spec 023)."""

import html

from flask import Blueprint, jsonify, request

from ProxmoxVEx.api.auth import require_auth
from ProxmoxVEx.api.clusters import check_cluster_access, cluster_managers
from ProxmoxVEx.utils.audit import log_audit

bp = Blueprint("eos", __name__)


# Per-cluster connector configuration store.
_eos_connectors = {}


def _eos_guard(cluster_id):
    """Shared access + existence guard for every arista-eos endpoint."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return err[1] if err else 403
    if cluster_id not in cluster_managers:
        return 404
    return None


def _eos_audit(cluster_id, action, message):
    """Central audit helper so every mutation records actor/action/cluster."""
    log_audit(
        request.session.get("user", "system"),
        action,
        f"{message} (cluster={html.escape(cluster_id)})",
        cluster=cluster_managers[cluster_id].config.name,
    )

_eos_store_connector = {}


@bp.route("/api/clusters/<cluster_id>/arista-eos/connector", methods=["GET", "POST"])
@require_auth(perms=["eos.connector"])
def eos_connector(cluster_id):
    """Enroll or read an Arista EOS device connection (eAPI endpoint plus SNMP profile)."""
    denied = _eos_guard(cluster_id)
    if denied:
        return jsonify({"error": "Access denied"} if denied == 403 else {"error": "Cluster not found"}), denied
    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "connector": _eos_store_connector.get(cluster_id, {"enabled": False, "host": "", "transport": "eapi", "username": "", "password": "", "snmp_v3": {}}),
        })
    data = request.get_json() or {}
    cfg = data.get("connector", {})
    if not isinstance(cfg, dict):
        return jsonify({"error": "connector must be an object", "code": "invalid_payload"}), 400
    host = str(cfg.get("host", "")).strip()
    if True and not host:
        return jsonify({"error": "host is required", "code": "missing_field"}), 400

    _eos_store_connector[cluster_id] = cfg
    _eos_audit(cluster_id, "eos.connector", "Updated connector for arista-eos")
    return jsonify({"success": True, "cluster": html.escape(cluster_id), "connector": cfg})


@bp.route("/api/clusters/<cluster_id>/arista-eos/devices", methods=["GET"])
@require_auth(perms=["eos.view"])
def eos_devices(cluster_id):
    """Enrolled EOS devices with model/serial/EOS version."""
    denied = _eos_guard(cluster_id)
    if denied:
        return jsonify({"error": "Access denied"} if denied == 403 else {"error": "Cluster not found"}), denied
    return jsonify({
        "cluster": html.escape(cluster_id),
        "devices": [],
    })


@bp.route("/api/clusters/<cluster_id>/arista-eos/interfaces", methods=["GET"])
@require_auth(perms=["eos.view"])
def eos_interfaces(cluster_id):
    """Interfaces, optics and Port-Channel state."""
    denied = _eos_guard(cluster_id)
    if denied:
        return jsonify({"error": "Access denied"} if denied == 403 else {"error": "Cluster not found"}), denied
    return jsonify({
        "cluster": html.escape(cluster_id),
        "interfaces": [],
    })


@bp.route("/api/clusters/<cluster_id>/arista-eos/fabric", methods=["GET"])
@require_auth(perms=["eos.view"])
def eos_fabric(cluster_id):
    """MLAG, BGP/EVPN and VXLAN fabric state."""
    denied = _eos_guard(cluster_id)
    if denied:
        return jsonify({"error": "Access denied"} if denied == 403 else {"error": "Cluster not found"}), denied
    return jsonify({
        "cluster": html.escape(cluster_id),
        "fabric": {"mlag": {}, "bgp_evpn": [], "vxlan": {}},
    })


@bp.route("/api/clusters/<cluster_id>/arista-eos/environment", methods=["GET"])
@require_auth(perms=["eos.view"])
def eos_environment(cluster_id):
    """Environment sensors, SysDB counters and LLDP neighbors."""
    denied = _eos_guard(cluster_id)
    if denied:
        return jsonify({"error": "Access denied"} if denied == 403 else {"error": "Cluster not found"}), denied
    return jsonify({
        "cluster": html.escape(cluster_id),
        "environment": {"sensors": [], "sysdb": {}, "neighbors": []},
    })


@bp.route("/api/clusters/<cluster_id>/arista-eos/backups", methods=["POST"])
@require_auth(perms=["eos.backup"])
def eos_backup_create(cluster_id):
    """Trigger a config backup via eAPI sessions with diff history."""
    denied = _eos_guard(cluster_id)
    if denied:
        return jsonify({"error": "Access denied"} if denied == 403 else {"error": "Cluster not found"}), denied
    data = request.get_json() or {}
    device_id = str(data.get("device_id", "")).strip()
    if not device_id:
        return jsonify({"error": "device_id is required", "code": "missing_field"}), 400

    _eos_audit(cluster_id, "eos.backup", "Config backup requested")
    return jsonify({"success": True, "cluster": html.escape(cluster_id), "backup": {"device_id": data["device_id"], "status": "scheduled"}})


@bp.route("/api/clusters/<cluster_id>/arista-eos/backups/list", methods=["GET"])
@require_auth(perms=["eos.view"])
def eos_backups_list(cluster_id):
    """List configuration backups, sessions and diffs."""
    denied = _eos_guard(cluster_id)
    if denied:
        return jsonify({"error": "Access denied"} if denied == 403 else {"error": "Cluster not found"}), denied
    return jsonify({
        "cluster": html.escape(cluster_id),
        "backups": [],
    })


@bp.route("/api/clusters/<cluster_id>/arista-eos/alerts", methods=["GET"])
@require_auth(perms=["eos.view"])
def eos_alerts(cluster_id):
    """Fabric and environment alerts."""
    denied = _eos_guard(cluster_id)
    if denied:
        return jsonify({"error": "Access denied"} if denied == 403 else {"error": "Cluster not found"}), denied
    return jsonify({
        "cluster": html.escape(cluster_id),
        "alerts": [],
    })


@bp.route("/api/clusters/<cluster_id>/arista-eos/widget", methods=["GET"])
@require_auth(perms=["eos.view"])
def eos_widget(cluster_id):
    """Dashboard widget for Arista fabric health."""
    denied = _eos_guard(cluster_id)
    if denied:
        return jsonify({"error": "Access denied"} if denied == 403 else {"error": "Cluster not found"}), denied
    return jsonify({
        "cluster": html.escape(cluster_id),
        "widget": {"title": "Arista EOS", "status": "connected", "devices": 0},
    })
