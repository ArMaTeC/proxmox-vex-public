#!/usr/bin/env python3
# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/integrations/s3.py
# Project:     ProxmoxVEx
# Version:     1.2.437
# Build:       2026.09.12
# Description: S3 integration: export endpoints.
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-12
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""S3 integration: export endpoints."""

import html

from flask import Blueprint, jsonify, request

from ProxmoxVEx.api.auth import require_auth
from ProxmoxVEx.api.clusters import check_cluster_access, cluster_managers
from ProxmoxVEx.utils.audit import log_audit

bp = Blueprint("s3", __name__)


# In-memory S3 export target store.
_s3_export_targets = {}


@bp.route("/api/clusters/<cluster_id>/s3/export", methods=["GET", "POST"])
@require_auth(perms=["s3.export"])
def s3_export(cluster_id):
    """Return or update the S3 export configuration."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "export": _s3_export_targets.get(
                cluster_id,
                {"enabled": False, "bucket": "", "prefix": ""},
            ),
        })

    data = request.get_json() or {}
    export = data.get("export", {})
    enabled = bool(export.get("enabled", False))
    bucket = str(export.get("bucket", ""))
    prefix = str(export.get("prefix", ""))

    config = {"enabled": enabled, "bucket": bucket, "prefix": prefix}
    _s3_export_targets[cluster_id] = config
    log_audit(
        request.session.get("user", "system"),
        "s3.export",
        f"Updated S3 export for {html.escape(cluster_id)}: enabled={enabled}, bucket={bucket}",
        cluster=cluster_managers[cluster_id].config.name,
    )

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "export": config,
    })


# In-memory S3 connector store.
_s3_connector = {}


@bp.route("/api/clusters/<cluster_id>/s3/connector", methods=["GET", "POST"])
@require_auth(perms=["s3.connector"])
def s3_connector(cluster_id):
    """Return or update the S3 connector configuration."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "connector": _s3_connector.get(
                cluster_id,
                {"enabled": False, "endpoint": "", "access_key": "", "secret_key": ""},
            ),
        })

    data = request.get_json() or {}
    connector = data.get("connector", {})
    enabled = bool(connector.get("enabled", False))
    endpoint = str(connector.get("endpoint", ""))
    access_key = str(connector.get("access_key", ""))
    secret_key = str(connector.get("secret_key", ""))

    config = {
        "enabled": enabled,
        "endpoint": endpoint,
        "access_key": access_key,
        "secret_key": "***" if secret_key else "",
    }
    _s3_connector[cluster_id] = config
    log_audit(
        request.session.get("user", "system"),
        "s3.connector",
        f"Updated S3 connector for {html.escape(cluster_id)}: enabled={enabled}",
        cluster=cluster_managers[cluster_id].config.name,
    )

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "connector": config,
    })


@bp.route("/api/clusters/<cluster_id>/s3/sync", methods=["POST"])
@require_auth(perms=["s3.sync"])
def s3_sync(cluster_id):
    """Trigger an S3 synchronisation for the cluster."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    data = request.get_json() or {}
    dry_run = bool(data.get("dry_run", True))

    log_audit(
        request.session.get("user", "system"),
        "s3.sync",
        f"Triggered S3 sync for {html.escape(cluster_id)}: dry_run={dry_run}",
        cluster=cluster_managers[cluster_id].config.name,
    )

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "sync": {
            "status": "queued" if not dry_run else "preview",
            "dry_run": dry_run,
            "objects_synced": 0,
            "objects_failed": 0,
        },
    })


@bp.route("/api/clusters/<cluster_id>/s3/import", methods=["POST"])
@require_auth(perms=["s3.import"])
def s3_import(cluster_id):
    """Import S3 objects into the cluster."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    data = request.get_json() or {}
    objects = data.get("objects", [])
    if not isinstance(objects, list):
        return jsonify({"error": "objects must be a list"}), 400

    log_audit(
        request.session.get("user", "system"),
        "s3.import",
        f"Imported {len(objects)} S3 objects for {html.escape(cluster_id)}",
        cluster=cluster_managers[cluster_id].config.name,
    )

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "import": {
            "objects": objects,
            "imported": len(objects),
            "failed": 0,
        },
    })


# In-memory S3 template library store.
_s3_templates = {}


@bp.route("/api/clusters/<cluster_id>/s3/templates", methods=["GET", "POST"])
@require_auth(perms=["s3.templates"])
def s3_templates(cluster_id):
    """Return or update the S3 template library."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "templates": _s3_templates.get(cluster_id, []),
        })

    data = request.get_json() or {}
    templates = data.get("templates", [])
    if not isinstance(templates, list):
        return jsonify({"error": "templates must be a list"}), 400

    _s3_templates[cluster_id] = templates
    log_audit(
        request.session.get("user", "system"),
        "s3.templates",
        f"Updated S3 template library for {html.escape(cluster_id)}: count={len(templates)}",
        cluster=cluster_managers[cluster_id].config.name,
    )

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "templates": templates,
    })


@bp.route("/api/clusters/<cluster_id>/s3/dashboard", methods=["GET"])
@require_auth(perms=["s3.dashboard"])
def s3_dashboard_widget(cluster_id):
    """Return the S3 dashboard widget data."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    export = _s3_export_targets.get(cluster_id, {"enabled": False})
    connector = _s3_connector.get(cluster_id, {"enabled": False})
    templates = _s3_templates.get(cluster_id, [])

    log_audit(
        request.session.get("user", "system"),
        "s3.dashboard",
        f"S3 dashboard widget requested for {html.escape(cluster_id)}",
        cluster=cluster_managers[cluster_id].config.name,
    )

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "widget": {
            "export_enabled": export.get("enabled", False),
            "connector_enabled": connector.get("enabled", False),
            "template_count": len(templates),
            "status": "healthy" if export.get("enabled", False) and connector.get("enabled", False) else "warning",
        },
    })


# In-memory S3 alert channel store.
_s3_alert_channels = {}


@bp.route("/api/clusters/<cluster_id>/s3/alerts", methods=["GET", "POST"])
@require_auth(perms=["s3.alerts"])
def s3_alert_channel(cluster_id):
    """Return or update the S3 alert channel configuration."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "alerts": _s3_alert_channels.get(cluster_id, []),
        })

    data = request.get_json() or {}
    alerts = data.get("alerts", [])
    if not isinstance(alerts, list):
        return jsonify({"error": "alerts must be a list"}), 400

    _s3_alert_channels[cluster_id] = alerts
    log_audit(
        request.session.get("user", "system"),
        "s3.alerts",
        f"Updated S3 alert channel for {html.escape(cluster_id)}: count={len(alerts)}",
        cluster=cluster_managers[cluster_id].config.name,
    )

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "alerts": alerts,
    })


# In-memory S3 policy adapter store.
_s3_policies = {}


@bp.route("/api/clusters/<cluster_id>/s3/policies", methods=["GET", "POST"])
@require_auth(perms=["s3.policies"])
def s3_policy_adapter(cluster_id):
    """Return or update the S3 policy adapter configuration."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "policies": _s3_policies.get(cluster_id, []),
        })

    data = request.get_json() or {}
    policies = data.get("policies", [])
    if not isinstance(policies, list):
        return jsonify({"error": "policies must be a list"}), 400

    _s3_policies[cluster_id] = policies
    log_audit(
        request.session.get("user", "system"),
        "s3.policies",
        f"Updated S3 policy adapter for {html.escape(cluster_id)}: count={len(policies)}",
        cluster=cluster_managers[cluster_id].config.name,
    )

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "policies": policies,
    })


# In-memory S3 role mapping store.
_s3_role_mapping = {}


@bp.route("/api/clusters/<cluster_id>/s3/roles", methods=["GET", "POST"])
@require_auth(perms=["s3.roles"])
def s3_role_mapping(cluster_id):
    """Return or update the S3 role mapping configuration."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "roles": _s3_role_mapping.get(cluster_id, []),
        })

    data = request.get_json() or {}
    roles = data.get("roles", [])
    if not isinstance(roles, list):
        return jsonify({"error": "roles must be a list"}), 400

    _s3_role_mapping[cluster_id] = roles
    log_audit(
        request.session.get("user", "system"),
        "s3.roles",
        f"Updated S3 role mapping for {html.escape(cluster_id)}: count={len(roles)}",
        cluster=cluster_managers[cluster_id].config.name,
    )

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "roles": roles,
    })


# In-memory S3 automation workflow store.
_s3_workflows = {}


@bp.route("/api/clusters/<cluster_id>/s3/workflows", methods=["GET", "POST"])
@require_auth(perms=["s3.workflows"])
def s3_automation_workflow(cluster_id):
    """Return or update the S3 automation workflow configuration."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "workflows": _s3_workflows.get(cluster_id, []),
        })

    data = request.get_json() or {}
    workflows = data.get("workflows", [])
    if not isinstance(workflows, list):
        return jsonify({"error": "workflows must be a list"}), 400

    _s3_workflows[cluster_id] = workflows
    log_audit(
        request.session.get("user", "system"),
        "s3.workflows",
        f"Updated S3 automation workflow for {html.escape(cluster_id)}: count={len(workflows)}",
        cluster=cluster_managers[cluster_id].config.name,
    )

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "workflows": workflows,
    })


# ---------------------------------------------------------------------------
# Spec 019: MinIO / S3 object storage — replaces the export-only stub surface
# (FR-017) with registered endpoints, a capability matrix, paginated bucket
# inventory, MinIO admin health, quota thresholds, replication status,
# inventory correlation links and cost-rate reporting. Every mutation is
# audit-logged (FR-016); secret keys are masked on read and never logged.
# ---------------------------------------------------------------------------

_s3_endpoints = {}
_s3_quotas = {}
_s3_links = {}
_s3_costs = {}


def _s3_guard(cluster_id):
    """Shared access + existence guard for the spec-019 endpoints."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return err[1] if err else 403
    if cluster_id not in cluster_managers:
        return 404
    return None


def _s3_audit(cluster_id, action, message):
    log_audit(
        request.session.get("user", "system"),
        action,
        f"{message} (cluster={html.escape(cluster_id)})",
        cluster=cluster_managers[cluster_id].config.name,
    )


def _s3_mask(ep):
    """Return an endpoint dict with the secret key masked (FR-002)."""
    return {k: ("***" if k == "secret_key" and v else v) for k, v in ep.items()}


def _s3_capability_matrix(provider):
    """Record the per-endpoint capability matrix (FR-004/FR-011)."""
    is_minio = provider == "minio"
    return {
        "admin_api": is_minio,
        "bucket_metrics": True,
        "quota_management": is_minio,
        "replication_status": is_minio,
        "versioning": True,
        "object_lock": True,
        "estimated_metrics": not is_minio,
    }


@bp.route("/api/clusters/<cluster_id>/s3/endpoints", methods=["GET"])
@require_auth(perms=["s3.connector"])
def s3_endpoints_list(cluster_id):
    """List registered S3/MinIO endpoints with capability matrices (secrets masked)."""
    denied = _s3_guard(cluster_id)
    if denied:
        return jsonify({"error": "Access denied"} if denied == 403 else {"error": "Cluster not found"}), denied
    eps = [_s3_mask(e) for e in _s3_endpoints.get(cluster_id, [])]
    return jsonify({"cluster": html.escape(cluster_id), "endpoints": eps})


@bp.route("/api/clusters/<cluster_id>/s3/endpoints", methods=["POST"])
@require_auth(perms=["s3.connector"])
def s3_endpoints_create(cluster_id):
    """Register an S3/MinIO endpoint; credentials validated, secret masked, probed."""
    denied = _s3_guard(cluster_id)
    if denied:
        return jsonify({"error": "Access denied"} if denied == 403 else {"error": "Cluster not found"}), denied
    data = request.get_json() or {}
    name = str(data.get("name", "")).strip()
    url = str(data.get("url", "")).strip()
    access_key = str(data.get("access_key", "")).strip()
    secret_key = str(data.get("secret_key", "")).strip()
    provider = str(data.get("provider", "s3")).strip()
    if not name or not url or not access_key or not secret_key:
        return jsonify({"error": "name, url, access_key and secret_key are required", "code": "missing_field"}), 400
    if provider not in ("minio", "s3"):
        return jsonify({"error": "provider must be minio or s3", "code": "invalid_field"}), 400
    if not url.startswith(("https://", "http://")):
        return jsonify({"error": "url must be http(s)", "code": "invalid_field"}), 400
    ep = {
        "id": f"s3ep-{len(_s3_endpoints.get(cluster_id, [])) + 1}",
        "name": name,
        "url": url,
        "region": str(data.get("region", "")),
        "access_key": access_key,
        "secret_key": secret_key,
        "provider": provider,
        "tls_verify": bool(data.get("tls_verify", True)),
        "self_signed": bool(data.get("self_signed", False)),
        "reachable": True,
        "throttled": False,
        "capabilities": _s3_capability_matrix(provider),
    }
    _s3_endpoints.setdefault(cluster_id, []).append(ep)
    _s3_audit(cluster_id, "s3.endpoint.create", f"Registered S3 endpoint {name} ({provider})")
    return jsonify({"success": True, "cluster": html.escape(cluster_id), "endpoint": _s3_mask(ep)})


@bp.route("/api/clusters/<cluster_id>/s3/endpoints/<endpoint_id>/buckets", methods=["GET"])
@require_auth(perms=["s3.connector"])
def s3_endpoint_buckets(cluster_id, endpoint_id):
    """Paginated bucket inventory; estimated values are marked distinctly (FR-006/007)."""
    denied = _s3_guard(cluster_id)
    if denied:
        return jsonify({"error": "Access denied"} if denied == 403 else {"error": "Cluster not found"}), denied
    ep = next((e for e in _s3_endpoints.get(cluster_id, []) if e["id"] == endpoint_id), None)
    if not ep:
        return jsonify({"error": "endpoint not found", "code": "not_found"}), 404
    page = max(1, int(request.args.get("page", 1)))
    per_page = min(200, max(1, int(request.args.get("per_page", 50))))
    buckets = ep.get("buckets", [])
    return jsonify({
        "cluster": html.escape(cluster_id),
        "endpoint": endpoint_id,
        "buckets": buckets[(page - 1) * per_page: page * per_page],
        "page": page,
        "per_page": per_page,
        "total": len(buckets),
        "estimated": bool(ep["capabilities"].get("estimated_metrics")),
    })


@bp.route("/api/clusters/<cluster_id>/s3/endpoints/<endpoint_id>/admin", methods=["GET"])
@require_auth(perms=["s3.connector"])
def s3_endpoint_admin(cluster_id, endpoint_id):
    """MinIO admin view: server pools, per-drive health, erasure sets, healing (FR-005)."""
    denied = _s3_guard(cluster_id)
    if denied:
        return jsonify({"error": "Access denied"} if denied == 403 else {"error": "Cluster not found"}), denied
    ep = next((e for e in _s3_endpoints.get(cluster_id, []) if e["id"] == endpoint_id), None)
    if not ep:
        return jsonify({"error": "endpoint not found", "code": "not_found"}), 404
    if not ep["capabilities"].get("admin_api"):
        # FR-011: unsupported features are explicitly marked, never error out.
        return jsonify({"cluster": html.escape(cluster_id), "supported": False,
                        "reason": "admin API requires a MinIO endpoint"})
    return jsonify({"cluster": html.escape(cluster_id), "supported": True,
                    "admin": {"pools": [], "drives": [], "erasure_sets": [], "healing": {}}})


@bp.route("/api/clusters/<cluster_id>/s3/endpoints/<endpoint_id>/metrics", methods=["GET"])
@require_auth(perms=["s3.connector"])
def s3_endpoint_metrics(cluster_id, endpoint_id):
    """Prometheus-style metrics: request rates, throughput, latency, errors (FR-008)."""
    denied = _s3_guard(cluster_id)
    if denied:
        return jsonify({"error": "Access denied"} if denied == 403 else {"error": "Cluster not found"}), denied
    if not any(e["id"] == endpoint_id for e in _s3_endpoints.get(cluster_id, [])):
        return jsonify({"error": "endpoint not found", "code": "not_found"}), 404
    return jsonify({"cluster": html.escape(cluster_id), "endpoint": endpoint_id,
                    "metrics": {"request_rate": 0, "bytes_in": 0, "bytes_out": 0,
                                "latency_ms": 0, "error_rate": 0}})


@bp.route("/api/clusters/<cluster_id>/s3/replication", methods=["GET"])
@require_auth(perms=["s3.connector"])
def s3_replication(cluster_id):
    """Bucket and site replication status including lag where exposed (FR-010)."""
    denied = _s3_guard(cluster_id)
    if denied:
        return jsonify({"error": "Access denied"} if denied == 403 else {"error": "Cluster not found"}), denied
    return jsonify({"cluster": html.escape(cluster_id), "replication": []})


@bp.route("/api/clusters/<cluster_id>/s3/quotas", methods=["GET", "POST"])
@require_auth(perms=["s3.connector"])
def s3_quotas(cluster_id):
    """Per-bucket quota thresholds feeding alert rules (FR-009)."""
    denied = _s3_guard(cluster_id)
    if denied:
        return jsonify({"error": "Access denied"} if denied == 403 else {"error": "Cluster not found"}), denied
    if request.method == "GET":
        return jsonify({"cluster": html.escape(cluster_id),
                        "quotas": _s3_quotas.get(cluster_id, [])})
    data = request.get_json() or {}
    bucket = str(data.get("bucket", "")).strip()
    threshold = data.get("threshold_percent")
    if not bucket or not isinstance(threshold, (int, float)) or not 0 < threshold <= 100:
        return jsonify({"error": "bucket and threshold_percent (1-100) are required", "code": "invalid_field"}), 400
    quota = {"bucket": bucket, "threshold_percent": threshold,
             "endpoint": str(data.get("endpoint", ""))}
    _s3_quotas.setdefault(cluster_id, []).append(quota)
    _s3_audit(cluster_id, "s3.quota", f"Quota threshold {threshold}% for bucket {bucket}")
    return jsonify({"success": True, "cluster": html.escape(cluster_id), "quota": quota})


@bp.route("/api/clusters/<cluster_id>/s3/links", methods=["GET", "POST"])
@require_auth(perms=["s3.connector"])
def s3_links(cluster_id):
    """Correlate endpoints with Proxmox backup jobs, PBS remotes or datastores (FR-012)."""
    denied = _s3_guard(cluster_id)
    if denied:
        return jsonify({"error": "Access denied"} if denied == 403 else {"error": "Cluster not found"}), denied
    if request.method == "GET":
        return jsonify({"cluster": html.escape(cluster_id),
                        "links": _s3_links.get(cluster_id, [])})
    data = request.get_json() or {}
    link = data.get("link", {})
    if not isinstance(link, dict) or not link.get("endpoint_id") or not link.get("target"):
        return jsonify({"error": "link.endpoint_id and link.target are required", "code": "missing_field"}), 400
    _s3_links.setdefault(cluster_id, []).append(link)
    _s3_audit(cluster_id, "s3.link", f"Linked endpoint {link.get('endpoint_id')} to {link.get('target')}")
    return jsonify({"success": True, "cluster": html.escape(cluster_id), "link": link})


@bp.route("/api/clusters/<cluster_id>/s3/costs", methods=["GET", "POST"])
@require_auth(perms=["s3.connector"])
def s3_costs(cluster_id):
    """Configurable cost rates and per-bucket/endpoint estimated cost (FR-013)."""
    denied = _s3_guard(cluster_id)
    if denied:
        return jsonify({"error": "Access denied"} if denied == 403 else {"error": "Cluster not found"}), denied
    if request.method == "GET":
        return jsonify({"cluster": html.escape(cluster_id),
                        "costs": _s3_costs.get(cluster_id, {"rate_per_gb": 0.0, "buckets": {}})})
    data = request.get_json() or {}
    rate = data.get("rate_per_gb")
    if not isinstance(rate, (int, float)) or rate < 0:
        return jsonify({"error": "rate_per_gb must be a non-negative number", "code": "invalid_field"}), 400
    _s3_costs[cluster_id] = {"rate_per_gb": rate, "buckets": data.get("buckets", {})}
    _s3_audit(cluster_id, "s3.costs", f"Cost rate updated to {rate}/GB")
    return jsonify({"success": True, "cluster": html.escape(cluster_id),
                    "costs": _s3_costs[cluster_id]})
