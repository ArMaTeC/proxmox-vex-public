# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/demo/__init__.py
# Project:     ProxmoxVEx
# Version:     1.2.437
# Build:       2026.09.12
# Description: Demo mode configuration helpers.
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-12
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Demo mode configuration helpers.

Demo mode is enabled by setting the environment variable
``PROXMOXVEX_DEMO_MODE=true``.  When enabled the application seeds a
low-privilege demo user, a synthetic cluster and restricts destructive
operations at the API layer.
"""

import os

DEMO_ENV_VAR = "PROXMOXVEX_DEMO_MODE"
DEMO_USERNAME = "demo"
DEMO_PASSWORD = "demo"
# Admin role so every page renders in the sandbox; the demo guard blocks all
# mutating requests before they reach a handler, so role ≠ write access.
DEMO_ROLE = "admin"
DEMO_TENANT = "demo"
DEMO_CLUSTER_ID = "demo"
DEMO_CLUSTER_HOST = "demo"
DEMO_RESET_INTERVAL = int(os.environ.get("PROXMOXVEX_DEMO_RESET_INTERVAL", "900"))
DEMO_TOKEN_SECRET = os.environ.get(
    "PROXMOXVEX_DEMO_TOKEN_SECRET", "demo-secret-change-in-production"
)
DEMO_ALLOWED_ORIGINS = [o.strip() for o in os.environ.get("PROXMOXVEX_DEMO_ALLOWED_ORIGINS", "").split(",") if o.strip()]
DEMO_CAPACITY = "available"
# Bump whenever the synthetic fixture set (fixtures/demo/*.json or the
# seed.py seed data) changes so stale demo volumes can be detected and
# re-seeded after a reset.
DEMO_SEED_VERSION = "2026.09.11-1"


def is_demo_mode() -> bool:
    """Return True when the application is running in demo/sandbox mode."""
    return os.environ.get(DEMO_ENV_VAR, "").lower() in ("1", "true", "yes")
