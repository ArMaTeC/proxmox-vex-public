# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/demo/seed.py
# Project:     ProxmoxVEx
# Version:     1.2.437
# Build:       2026.09.12
# Description: Seed synthetic demo fixtures when demo mode is enabled.
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-12
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Seed synthetic demo fixtures when demo mode is enabled.

This module creates the demo user and a synthetic cluster record.  It is
idempotent so it can safely be run on every startup.
"""

import logging
from datetime import datetime, timezone

from ProxmoxVEx.core.db import get_db
from ProxmoxVEx.demo import (
    DEMO_CLUSTER_HOST,
    DEMO_CLUSTER_ID,
    DEMO_PASSWORD,
    DEMO_ROLE,
    DEMO_USERNAME,
    is_demo_mode,
)
from ProxmoxVEx.utils.auth import hash_password


def _ensure_demo_user():
    """Create or reset the low-privilege demo user."""
    db = get_db()
    users = db.get_all_users()
    if DEMO_USERNAME in users:
        # Keep the seeded user's role in sync with DEMO_ROLE (upgrades from
        # viewer → admin for full read-only coverage of the demo UI).
        existing = users.get(DEMO_USERNAME) or {}
        if existing.get("role") != DEMO_ROLE:
            db.save_user(DEMO_USERNAME, dict(existing, role=DEMO_ROLE))
        return

    salt, password_hash = hash_password(DEMO_PASSWORD)
    demo_user = {
        "password_salt": salt,
        "password_hash": password_hash,
        "role": DEMO_ROLE,
        "permissions": [],
        "tenant": "",
        "auth_source": "demo",
        "is_demo": True,
        "display_name": "Demo User",
        "email": "",
        "enabled": True,
        "theme": "",
        "language": "",
        "ui_layout": "modern",
        "created_at": datetime.now(timezone.utc).isoformat(),
    }
    db.save_user(DEMO_USERNAME, demo_user)
    logging.info(f"[DEMO_SEED] Created demo user '{DEMO_USERNAME}'")


def _ensure_demo_cluster():
    """Create the synthetic demo cluster record.

    The cluster uses ``host='demo'`` which the manager mock intercepts so
    no real hypervisor connection is attempted.
    """
    db = get_db()
    clusters = db.get_all_clusters()
    if DEMO_CLUSTER_ID in clusters:
        return

    now = datetime.now(timezone.utc).isoformat()
    demo_cluster = {
        "name": "Demo Cluster",
        "host": DEMO_CLUSTER_HOST,
        "user": "demo",
        "pass": "",
        "ssl_verification": False,
        "migration_threshold": 30,
        "check_interval": 300,
        "auto_migrate": False,
        "balance_containers": False,
        "balance_local_disks": False,
        "dry_run": True,
        "enabled": True,
        "ha_enabled": False,
        "fallback_hosts": [],
        "ssh_user": "",
        "ssh_key": "",
        "ssh_port": 22,
        "api_port": 8006,
        "ha_settings": {},
        "created_at": now,
        "updated_at": now,
    }
    db.save_cluster(DEMO_CLUSTER_ID, demo_cluster)
    logging.info(f"[DEMO_SEED] Created demo cluster '{DEMO_CLUSTER_ID}'")


def _ensure_demo_migration_history():
    """Seed a few migration rows so the Migrations view isn't empty."""
    db = get_db()
    cursor = db.conn.cursor()
    cursor.execute("SELECT COUNT(*) AS c FROM migration_history WHERE cluster_id = ?", (DEMO_CLUSTER_ID,))
    row = cursor.fetchone()
    if row and (row["c"] if isinstance(row, dict) else row[0]):
        return

    now = datetime.now(timezone.utc)
    demo_migrations = [
        ("demo", 105, "k8s-w-01", "pve-demo-01", "pve-demo-02", "manual by demo@pve", "completed", 19.4, (now.timestamp() - 259200)),
        ("demo", 106, "k8s-w-02", "pve-demo-02", "pve-demo-03", "manual by demo@pve", "completed", 23.1, (now.timestamp() - 172800)),
        ("demo", 100, "web-01", "pve-demo-02", "pve-demo-01", "rebalance by ProxmoxVEx", "completed", 14.8, (now.timestamp() - 345600)),
    ]
    for cluster_id, vmid, vm_name, src, dst, reason, status, duration, ts in demo_migrations:
        cursor.execute(
            """
            INSERT INTO migration_history
            (cluster_id, vmid, vm_name, source_node, target_node,
             reason, status, duration_seconds, timestamp)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (cluster_id, vmid, vm_name, src, dst, reason, status, duration, datetime.fromtimestamp(ts, timezone.utc).isoformat()),
        )
    db.conn.commit()
    logging.info("[DEMO_SEED] Seeded demo migration history")


def _ensure_demo_alerts():
    """Seed alert rules so the Alerts view shows a configured instance."""
    db = get_db()
    existing = db.get_all_alerts()
    if any(a.get("cluster_id") == DEMO_CLUSTER_ID for a in existing.values()):
        return

    demo_alerts = [
        ("demo-node-cpu", {"cluster_id": DEMO_CLUSTER_ID, "node": None, "vmid": None, "type": "node_cpu", "threshold": 85, "enabled": True, "notify_methods": ["email"], "cooldown": 900}),
        ("demo-node-mem", {"cluster_id": DEMO_CLUSTER_ID, "node": None, "vmid": None, "type": "node_memory", "threshold": 90, "enabled": True, "notify_methods": ["email"], "cooldown": 900}),
        ("demo-storage", {"cluster_id": DEMO_CLUSTER_ID, "node": None, "vmid": None, "type": "storage", "threshold": 80, "enabled": True, "notify_methods": ["email"], "cooldown": 3600}),
        ("demo-vm-down", {"cluster_id": DEMO_CLUSTER_ID, "node": None, "vmid": None, "type": "vm_down", "threshold": 0, "enabled": True, "notify_methods": ["email"], "cooldown": 300}),
    ]
    for alert_id, data in demo_alerts:
        db.save_alert(alert_id, data)
    logging.info("[DEMO_SEED] Seeded demo alert rules")


def _ensure_demo_pbs_server():
    """Seed a synthetic PBS server so the backup-server surfaces show data.

    host='demo' port 8007 is intercepted by the cluster mock, which serves
    the PBS API from the ``pbs`` inventory fixture section — no real PBS
    is ever contacted.
    """
    db = get_db()
    cursor = db.conn.cursor()
    cursor.execute("SELECT COUNT(*) AS c FROM pbs_servers")
    row = cursor.fetchone()
    if row and (row["c"] if isinstance(row, dict) else row[0]):
        return

    now = datetime.now(timezone.utc).isoformat()
    cursor.execute(
        """
        INSERT INTO pbs_servers
        (id, name, host, port, user, pass_encrypted, api_token_id,
         api_token_secret_encrypted, fingerprint, ssl_verify, enabled,
         linked_clusters, notes, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (
            "pbs-demo", "pbs-demo-01", DEMO_CLUSTER_HOST, 8007, "demo@pam",
            "", "demo@pam!demo", "", "", 0, 1,
            '["demo"]', "Synthetic demo backup server", now, now,
        ),
    )
    db.conn.commit()
    logging.info("[DEMO_SEED] Seeded demo PBS server")


def _ensure_demo_vmware_server():
    """Seed a synthetic vCenter so the VMware surface shows data.

    host='vcenter.demo.lab' is intercepted by the demo request mock and
    answered from the ``vcenter`` section of integrations.json.
    """
    db = get_db()
    cursor = db.conn.cursor()
    cursor.execute("SELECT COUNT(*) AS c FROM vmware_servers")
    row = cursor.fetchone()
    if row and (row["c"] if isinstance(row, dict) else row[0]):
        return

    now = datetime.now(timezone.utc).isoformat()
    cursor.execute(
        """
        INSERT INTO vmware_servers
        (id, name, host, port, username, pass_encrypted, server_type,
         ssl_verify, enabled, linked_clusters, notes, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (
            "vmware-demo", "vcenter-01", "vcenter.demo.lab", 443,
            "demo@vsphere.local", db._encrypt("demo"), "vcenter",
            0, 1, '[]', "Synthetic demo vCenter", now, now,
        ),
    )
    db.conn.commit()
    logging.info("[DEMO_SEED] Seeded demo vCenter server")


def _ensure_demo_netapp_endpoint():
    """Seed a synthetic ONTAP endpoint for the NetApp plugin."""
    db = get_db()
    cursor = db.conn.cursor()
    try:
        cursor.execute("SELECT COUNT(*) AS c FROM netapp_endpoints")
    except Exception:
        return  # plugin tables not created yet
    row = cursor.fetchone()
    if row and (row["c"] if isinstance(row, dict) else row[0]):
        return

    now = datetime.now(timezone.utc).isoformat()
    cursor.execute(
        """
        INSERT INTO netapp_endpoints
        (id, name, host, username, password_encrypted, ssl_verify, skip_nfs, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        ("ntap-demo", "ntap-01", "netapp.demo.lab", "demo", db._encrypt("demo"), 0, 0, now, now),
    )
    db.conn.commit()
    logging.info("[DEMO_SEED] Seeded demo NetApp endpoint")


def seed_demo():
    """Seed demo fixtures if demo mode is active."""
    if not is_demo_mode():
        return
    from ProxmoxVEx.demo import DEMO_SEED_VERSION

    logging.info(f"[DEMO_SEED] Seeding demo fixtures version {DEMO_SEED_VERSION}")
    try:
        _ensure_demo_user()
    except Exception as e:
        logging.error(f"[DEMO_SEED] Failed to seed demo user: {e}")
    try:
        _ensure_demo_cluster()
    except Exception as e:
        logging.error(f"[DEMO_SEED] Failed to seed demo cluster: {e}")
    try:
        _ensure_demo_migration_history()
    except Exception as e:
        logging.error(f"[DEMO_SEED] Failed to seed migration history: {e}")
    try:
        _ensure_demo_alerts()
    except Exception as e:
        logging.error(f"[DEMO_SEED] Failed to seed alert rules: {e}")
    try:
        _ensure_demo_pbs_server()
    except Exception as e:
        logging.error(f"[DEMO_SEED] Failed to seed demo PBS server: {e}")
    try:
        _ensure_demo_vmware_server()
    except Exception as e:
        logging.error(f"[DEMO_SEED] Failed to seed demo vCenter server: {e}")
    try:
        _ensure_demo_netapp_endpoint()
    except Exception as e:
        logging.error(f"[DEMO_SEED] Failed to seed demo NetApp endpoint: {e}")
