/* --- ProxmoxVEx auto-header start ---
 * -------------------------------------------------------------------
 * File:        ProxmoxVEx/native/opnsense/opnsense.js
 * Project:     ProxmoxVEx
 * Version:     1.2.437
 * Build:       2026.09.12
 * Description: OPNsense Manager boot — delegates to the shared manager UI.
 * Docs:        https://proxmoxvex.com/docs
 * Generated:   2026-09-12
 * -------------------------------------------------------------------
 * --- ProxmoxVEx auto-header end --- */
/* OPNsense boot: the entire UI is the shared firewall-manager (spec 003 —
   both appliances render identical tabs/actions from the same module).
   Replaces the bespoke ui.js shell. */
(function () {
    'use strict';

    window.FirewallManager.boot({
        pluginId: 'opnsense',
        apiBase: '/api/opnsense',
        i18nBase: '/api/native/opnsense/i18n',
        title: 'OPNsense Manager'
    });
})();
