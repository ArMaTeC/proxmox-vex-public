# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/native/opnsense/opnsense_src/routes/ops.py
# Project:     ProxmoxVEx
# Version:     1.2.437
# Build:       2026.09.12
# Description: Platform ops endpoint — backup/restore/reboot/firmware.
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-12
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Platform operations route payloads (spec 003 US7).

GET  → system status + firmware info + backup list.
POST → apply | backup | restore | reboot | halt | firmware_update |
       firmware_upgrade — the route layer enforces `opnsense.ops` plus
       step-up + hostname confirm token for the destructive verbs.
"""

from __future__ import annotations

import logging
from typing import Any

from opnsense_src._fwkit import ensure_fwkit_importable
from opnsense_src.client import OPNsenseClient, OPNsenseError, OPNsenseHost
from opnsense_src.routes._domain import dispatch_action
from opnsense_src.writers import AuditLog
from opnsense_src.writers.ops import OpsWriter

ensure_fwkit_importable()

from ProxmoxVEx.native.fwkit.payloads import (  # noqa: E402
    audit_log_path,
    client_error_envelope,
    confirm_token_ok,
    err,
    ok,
)

log = logging.getLogger(__name__)

#: Ops that require the hostname confirm token — mirrors pfSense.
_DESTRUCTIVE = {"restore", "reboot", "halt", "firmware_update", "firmware_upgrade"}


def _get_or_none(client: OPNsenseClient, path: str) -> Any:
    try:
        return client.get(path)
    except OPNsenseError as e:
        log.warning("%s failed: %s", path, e)
        return None


def build_ops_list_payload(host: OPNsenseHost) -> tuple[int, dict[str, Any]]:
    client = OPNsenseClient(host)
    try:
        backups = _get_or_none(client, "/api/core/backup/backups") or {}
        return ok({
            "hostname": host.name,
            "system": _get_or_none(client, "/api/core/system/status"),
            "firmware": _get_or_none(client, "/api/core/firmware/info"),
            "backups": backups.get("backups", backups.get("rows", [])) if isinstance(backups, dict) else backups,
        })
    except Exception as e:
        return client_error_envelope(e, log_label="opnsense ops list")


def build_ops_payload(
    host: OPNsenseHost,
    plugin_dir: str,
    body: dict[str, Any],
    *,
    actor: str = "plugin",
) -> tuple[int, dict[str, Any]]:
    action = str(body.get("action", "")).lower()
    if action in _DESTRUCTIVE and not confirm_token_ok(body, host.name):
        # 400 like the pfSense twin — the spec's quickstart pins
        # `confirm_required` to 400 on both platforms (parity contract).
        return err("confirm_required", f"send confirm: \"{host.name}\" to run {action}", 400)

    writer = OpsWriter(OPNsenseClient(host), AuditLog(audit_log_path(plugin_dir)), actor=actor)
    return dispatch_action(writer, body, {
        "apply": lambda b: writer.apply(),
        "backup": lambda b: writer.backup(),
        "restore": lambda b: writer.restore(str(b.get("backup_id") or b.get("id") or "")),
        "reboot": lambda b: writer.reboot(),
        "halt": lambda b: writer.halt(),
        "firmware_check": lambda b: writer.firmware_check(),
        "firmware_update": lambda b: writer.firmware_update(),
        "firmware_upgrade": lambda b: writer.firmware_upgrade(),
    })
