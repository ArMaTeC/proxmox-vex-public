# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/native/opnsense/opnsense_src/routes/services.py
# Project:     ProxmoxVEx
# Version:     1.2.437
# Build:       2026.09.12
# Description: Services endpoint — list + control.
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-12
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Service route payloads — GET lists `/api/core/service/search` in the
canonical shape; POST runs start/stop/restart/reconfigure via
ServiceWriter (spec 003 US7)."""

from __future__ import annotations

import logging
from typing import Any

from opnsense_src._fwkit import ensure_fwkit_importable
from opnsense_src.client import OPNsenseClient, OPNsenseHost
from opnsense_src.routes._domain import dispatch_action
from opnsense_src.writers import AuditLog
from opnsense_src.writers.services import ServiceWriter

ensure_fwkit_importable()

from ProxmoxVEx.native.fwkit.normalize import normalize_service  # noqa: E402
from ProxmoxVEx.native.fwkit.payloads import (  # noqa: E402
    audit_log_path,
    client_error_envelope,
    ok,
)

log = logging.getLogger(__name__)


def build_services_list_payload(host: OPNsenseHost) -> tuple[int, dict[str, Any]]:
    client = OPNsenseClient(host)
    try:
        out = client.get("/api/core/service/search")
        rows = out.get("rows", []) if isinstance(out, dict) else []
        services = [normalize_service(r, "opnsense", i) for i, r in enumerate(rows)]
        return ok({"services": services, "total": len(services)})
    except Exception as e:
        return client_error_envelope(e, log_label="opnsense services list")


def build_services_action_payload(
    host: OPNsenseHost,
    plugin_dir: str,
    body: dict[str, Any],
    *,
    actor: str = "plugin",
) -> tuple[int, dict[str, Any]]:
    writer = ServiceWriter(OPNsenseClient(host), AuditLog(audit_log_path(plugin_dir)), actor=actor)

    def _control(b: dict[str, Any]) -> Any:
        service = str(b.get("service") or b.get("name") or "")
        if not service:
            raise ValueError("service is required")
        return writer.control(service, str(b.get("action", "")))

    return dispatch_action(writer, body, {
        "start": _control,
        "stop": _control,
        "restart": _control,
        "reconfigure": _control,
    })
