# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/native/opnsense/opnsense_src/routes/rules.py
# Project:     ProxmoxVEx
# Version:     1.2.437
# Build:       2026.09.12
# Description: Firewall rules endpoint — list + CRUD.
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-12
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Firewall filter rules route payloads — GET lists `/api/firewall/filter`
rules in the canonical shape; POST dispatches create/update/delete/toggle
on the RuleWriter (spec 003 US2 — the writer existed but had no route)."""

from __future__ import annotations

import logging
from typing import Any

from opnsense_src._fwkit import ensure_fwkit_importable
from opnsense_src.client import OPNsenseClient, OPNsenseHost
from opnsense_src.routes._domain import dispatch_action, make_writer
from opnsense_src.writers import RuleInput, RuleWriter

ensure_fwkit_importable()

from ProxmoxVEx.native.fwkit.normalize import normalize_rule  # noqa: E402
from ProxmoxVEx.native.fwkit.payloads import client_error_envelope, ok  # noqa: E402

log = logging.getLogger(__name__)


def build_rules_list_payload(host: OPNsenseHost) -> tuple[int, dict[str, Any]]:
    client = OPNsenseClient(host)
    try:
        out = client.get("/api/firewall/filter/searchRule")
        rows = out.get("rows", []) if isinstance(out, dict) else []
        # Present rules in evaluation order (ascending `sequence`) so the UI
        # matches pfSense, whose config list is already ordered.
        rows.sort(key=lambda r: int(str(r.get("sequence", 0)) or 0))
        rules = [normalize_rule(r, "opnsense", i) for i, r in enumerate(rows)]
        return ok({"rules": rules, "total": len(rules)})
    except Exception as e:
        return client_error_envelope(e, log_label="opnsense rules list")


def _rule_input(body: dict[str, Any]) -> RuleInput:
    rule = body.get("rule") or {}
    if not isinstance(rule, dict):
        raise ValueError("rule must be an object")
    return RuleInput(
        interface=str(rule.get("interface", "")),
        action=str(rule.get("action", "pass")),
        direction=str(rule.get("direction", "in")),
        ipprotocol=str(rule.get("ipprotocol", "inet")),
        protocol=str(rule.get("protocol", "any")),
        source_net=str(rule.get("source_net", "any")) or "any",
        source_port=str(rule.get("source_port", "")),
        destination_net=str(rule.get("destination_net", "any")) or "any",
        destination_port=str(rule.get("destination_port", "")),
        description=str(rule.get("description", "")),
        enabled=bool(rule.get("enabled", True)),
        sequence=int(rule.get("sequence", 1) or 1),
    )


def _uuid(body: dict[str, Any]) -> str:
    uid = str(body.get("uuid", ""))
    if not uid:
        raise ValueError("uuid is required")
    return uid


def build_rules_action_payload(
    host: OPNsenseHost,
    plugin_dir: str,
    body: dict[str, Any],
    *,
    peer_host: OPNsenseHost | None = None,
    actor: str = "plugin",
) -> tuple[int, dict[str, Any]]:
    writer = make_writer(RuleWriter, host, peer_host, plugin_dir, actor)

    def _toggle(b: dict[str, Any]) -> Any:
        # OPNsense filter rules toggle via setRule — fetch, flip, write back.
        uid = _uuid(b)
        current = writer.get(uid)
        rule_row = (current.get("rule") or current.get("rows") or {})
        if isinstance(rule_row, dict) and rule_row:
            enabled_now = str(rule_row.get("enabled", "1")) == "1"
            inp = RuleInput(
                interface=str(rule_row.get("interface", "lan")),
                action=str(rule_row.get("action", "pass")),
                direction=str(rule_row.get("direction", "in")),
                ipprotocol=str(rule_row.get("ipprotocol", "inet")),
                protocol=str(rule_row.get("protocol", "any")),
                source_net=str(rule_row.get("source_net", "any")) or "any",
                source_port=str(rule_row.get("source_port", "")),
                destination_net=str(rule_row.get("destination_net", "any")) or "any",
                destination_port=str(rule_row.get("destination_port", "")),
                description=str(rule_row.get("description", "")),
                enabled=not enabled_now,
                sequence=int(rule_row.get("sequence", 1) or 1),
            )
            return writer.update(uid, inp)
        raise ValueError(f"rule {uid} not found")

    return dispatch_action(writer, body, {
        "create": lambda b: writer.create(_rule_input(b)),
        "update": lambda b: writer.update(_uuid(b), _rule_input(b)),
        "delete": lambda b: writer.delete(_uuid(b)),
        "toggle": _toggle,
        "move": lambda b: writer.move(_uuid(b), str(b.get("before", ""))),
    })
