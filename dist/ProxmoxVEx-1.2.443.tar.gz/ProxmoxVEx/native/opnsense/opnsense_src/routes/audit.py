# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/native/opnsense/opnsense_src/routes/audit.py
# Project:     ProxmoxVEx
# Version:     1.2.437
# Build:       2026.09.12
# Description: Audit endpoint — tail the plugin audit log.
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-12
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Audit route — GET returns the most recent audit entries (`*.audit`
permission enforced by the route layer)."""

from __future__ import annotations

from dataclasses import asdict
from typing import Any

from opnsense_src._fwkit import ensure_fwkit_importable

ensure_fwkit_importable()

from ProxmoxVEx.native.fwkit.audit import AuditLog  # noqa: E402
from ProxmoxVEx.native.fwkit.payloads import audit_log_path, ok  # noqa: E402


def build_audit_payload(plugin_dir: str, limit: int = 50) -> tuple[int, dict[str, Any]]:
    log = AuditLog(audit_log_path(plugin_dir))
    entries = [asdict(e) for e in log.tail(limit)]
    return ok({"entries": entries, "total": len(entries)})
