# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/native/opnsense/opnsense_src/routes/__init__.py
# Project:     ProxmoxVEx
# Version:     1.2.437
# Build:       2026.09.12
# Description: REST routes exposed by the plugin to the ProxmoxVEx...
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-12
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""REST routes exposed by the plugin to the ProxmoxVEx dashboard."""

from .aliases import build_aliases_action_payload, build_aliases_list_payload  # noqa: F401
from .audit import build_audit_payload  # noqa: F401
from .dhcp import build_dhcp_action_payload, build_dhcp_list_payload  # noqa: F401
from .dhcp_subnet import (  # noqa: F401
    build_dhcp_subnet_action_payload,
    build_dhcp_subnet_list_payload,
)
from .logs import build_logs_payload  # noqa: F401
from .nat import (  # noqa: F401
    build_nat_action_payload,
    build_nat_legacy_payload,
    build_nat_list_payload,
)
from .network import build_network, build_network_payload  # noqa: F401
from .one_to_one import (  # noqa: F401
    build_one_to_one_action_payload,
    build_one_to_one_list_payload,
)
from .ops import build_ops_list_payload, build_ops_payload  # noqa: F401
from .overview import build_overview, build_overview_payload  # noqa: F401
from .rules import build_rules_action_payload, build_rules_list_payload  # noqa: F401
from .services import (  # noqa: F401
    build_services_action_payload,
    build_services_list_payload,
)
from .unbound import (  # noqa: F401
    build_unbound_action_payload,
    build_unbound_domain_action_payload,
    build_unbound_domain_list_payload,
    build_unbound_dot_action_payload,
    build_unbound_dot_list_payload,
    build_unbound_list_payload,
)
from .vpn import build_vpn_action_payload, build_vpn_list_payload  # noqa: F401
from .wg import build_wg_action_payload, build_wg_list_payload  # noqa: F401
