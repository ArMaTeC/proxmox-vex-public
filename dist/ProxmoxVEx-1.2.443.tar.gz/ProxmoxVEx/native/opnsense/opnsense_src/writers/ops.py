# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/native/opnsense/opnsense_src/writers/ops.py
# Project:     ProxmoxVEx
# Version:     1.2.439
# Build:       2026.09.12
# Description: Platform operations for OPNsense — full lifecycle (spec...
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-12
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Platform operations for OPNsense — full lifecycle (spec 003 US7):

- apply/reconfigure     → `/api/core/system/resync`-style + per-module
- config backup         → `/api/core/backup/backups` + `download`
- config restore        → `/api/core/backup/restoreBackup`
- reboot / halt         → `/api/core/system/{reboot,halt}`
- firmware check/update → `/api/core/firmware/{check,update,info}`

Every call is audited; reboot/halt/restore/update are destructive — the
route layer enforces the hostname confirm token + step-up before dispatch.
"""

from __future__ import annotations

import logging
from dataclasses import asdict
from typing import Any

from opnsense_src.client import OPNsenseClient, OPNsenseError

from .audit import AuditEntry, AuditLog, TimedAction, hash_payload

log = logging.getLogger(__name__)


class OpsWriter:
    def __init__(self, client: OPNsenseClient, audit: AuditLog, actor: str = "plugin", host_name: str = "") -> None:
        self.client = client
        self.audit = audit
        self.actor = actor
        self.host_name = host_name or client.host.name

    # -- reads ---------------------------------------------------------------

    def list_backups(self) -> list[dict[str, Any]]:
        out = self.client.get("/api/core/backup/backups")
        rows = out.get("backups", out.get("rows", [])) if isinstance(out, dict) else out
        return rows if isinstance(rows, list) else []

    def firmware_info(self) -> dict[str, Any]:
        try:
            return self.client.get("/api/core/firmware/info")
        except OPNsenseError as e:
            return {"ok": False, "detail": str(e)}

    def firmware_check(self) -> dict[str, Any]:
        try:
            return self.client.get("/api/core/firmware/check")
        except OPNsenseError:
            # check is POST-only on some versions
            try:
                return self.client.post("/api/core/firmware/check", {})
            except OPNsenseError as e:
                return {"ok": False, "detail": str(e)}

    def system_status(self) -> dict[str, Any]:
        try:
            return self.client.get("/api/core/system/status")
        except OPNsenseError as e:
            return {"ok": False, "detail": str(e)}

    # -- writes ----------------------------------------------------------------

    def _run(self, action: str, target: str, fn, payload: Any = None) -> dict[str, Any]:
        with TimedAction() as t:
            try:
                resp = fn()
                ok, detail = True, ""
            except OPNsenseError as e:
                ok, detail, resp = False, str(e), None
        entry = AuditEntry.now(
            user=self.actor, action=action, target=target,
            host=self.host_name, result="ok" if ok else "error",
            duration_ms=t.elapsed_ms, detail=detail[:200],
            payload_sha256=hash_payload(payload) if payload is not None else "",
        )
        try:
            self.audit.append(entry)
        except OSError as e:
            log.warning("audit write failed: %s", e)
        return {"ok": ok, "detail": detail, "response": resp, "audit": asdict(entry)}

    def apply(self) -> dict[str, Any]:
        """Apply pending config — filter reconfigure covers rule/alias/NAT
        changes made through the writers."""
        return self._run("apply", "opnsense/filter", lambda: self.client.post("/api/firewall/filter/apply", {}))

    def backup(self) -> dict[str, Any]:
        return self._run("backup", "opnsense/config", lambda: self.client.post("/api/core/backup/backup", {}))

    def restore(self, backup_id: str) -> dict[str, Any]:
        if not backup_id or "/" in backup_id or ".." in backup_id:
            return {"ok": False, "detail": "validation: invalid backup id"}
        return self._run(
            "restore", "opnsense/config",
            lambda: self.client.post(f"/api/core/backup/restoreBackup/{backup_id}", {}),
            {"backup_id": backup_id},
        )

    def reboot(self) -> dict[str, Any]:
        return self._run("reboot", "opnsense/system", lambda: self.client.post("/api/core/system/reboot", {}))

    def halt(self) -> dict[str, Any]:
        return self._run("halt", "opnsense/system", lambda: self.client.post("/api/core/system/halt", {}))

    def firmware_update(self) -> dict[str, Any]:
        return self._run("firmware_update", "opnsense/firmware", lambda: self.client.post("/api/core/firmware/update", {}))

    def firmware_upgrade(self) -> dict[str, Any]:
        return self._run("firmware_upgrade", "opnsense/firmware", lambda: self.client.post("/api/core/firmware/upgrade", {}))
