# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/native/opnsense/opnsense_src/writers/audit.py
# Project:     ProxmoxVEx
# Version:     1.2.437
# Build:       2026.09.12
# Description: Compat shim — audit log moved to fwkit.audit (parity feature).
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-12
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Compat shim — the audit recorder moved to `ProxmoxVEx.native.fwkit.audit`
so the pfSense plugin shares it. Keep this module so existing
`opnsense_src.writers.audit` imports (routes, writers, tests) keep working.
"""

from opnsense_src._fwkit import ensure_fwkit_importable

ensure_fwkit_importable()

from ProxmoxVEx.native.fwkit.audit import (  # noqa: E402,F401
    AuditEntry,
    AuditLog,
    TimedAction,
    hash_payload,
)
