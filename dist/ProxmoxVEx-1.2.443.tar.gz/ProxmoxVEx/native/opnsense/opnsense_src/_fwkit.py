# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/native/opnsense/opnsense_src/_fwkit.py
# Project:     ProxmoxVEx
# Version:     1.2.437
# Build:       2026.09.12
# Description: Import shim — resolves ProxmoxVEx.native.fwkit in every context.
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-12
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Resolve `ProxmoxVEx.native.fwkit` for the compat shims.

Inside the app `ProxmoxVEx` is already importable; in unit-test/lint
contexts only the plugin dir is on sys.path, so we add the repo project
root (the dir that contains the `ProxmoxVEx` package) ourselves.
"""

import os
import sys


def ensure_fwkit_importable() -> None:
    try:
        import ProxmoxVEx.native.fwkit  # noqa: F401

        return
    except ImportError:
        pass
    # file: native/opnsense/opnsense_src/_fwkit.py → project root is 5 levels up
    root = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", "..", ".."))
    if root not in sys.path:
        sys.path.insert(0, root)
