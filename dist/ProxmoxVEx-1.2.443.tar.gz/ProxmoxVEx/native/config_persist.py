# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/native/config_persist.py
# Project:     ProxmoxVEx
# Version:     1.2.437
# Build:       2026.09.12
# Description: Redirect native-integration config.json files to the...
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-12
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Redirect native-integration config.json files to the config volume.

Real integration credentials used to live in the git-tracked, image-baked
ProxmoxVEx/native/<plugin>/config.json — which leaked live hostnames and
secrets into the release tarball and the public demo. The image now ships
sanitized defaults; the real runtime config lives on the persistent config
volume at <CONFIG_DIR>/native/<plugin>/config.json.

On startup each plugin's config.json is replaced with a symlink into the
volume (migrating the bundled file's content on first boot), so plugin
writes land on the volume and survive image rebuilds.

In demo mode nothing is restored: the bundled config is forcibly sanitized
so a mislabeled volume or image can never surface real infrastructure.
"""

import json
import logging
import os
import shutil

log = logging.getLogger(__name__)

# Top-level key each plugin uses for its host list. Used to force-empty
# credentials in demo mode even if a real config was baked in by mistake.
_HOSTS_KEYS = {
    "active_directory": "ad_hosts",
    "docker_swarm": "clusters",
    "opnsense": "opnsense_hosts",
    "pfsense": "pfsense_hosts",
    "proxmox_backup_server": "pbs_hosts",
    "truenas": "instances",
    "vmware_vcenter": "vcenter_hosts",
    "vyos": "vyos_hosts",
    "zabbix": "zabbix_hosts",
}

# Demo configs: synthetic hosts on *.demo.lab. Requests-based integrations are
# served by the demo mock (hostname interception); the rest are answered by the
# client patches in ProxmoxVEx.demo.integration_mocks. Host lists must stay
# non-empty so the demo shows a configured integration, never a real target.
_DEMO_CONFIGS = {
    "proxmox_backup_server": {
        "pbs_hosts": [{"name": "pbs-01", "url": "https://pbs.demo.lab:8007", "api_token_id": "demo@pam!demo", "api_token_secret": "demo-token", "verify_tls": False}],
        "poll_interval": 30, "read_only": True,
    },
    "vmware_vcenter": {
        "vcenter_hosts": [{"name": "vcenter-01", "host": "vcenter.demo.lab", "port": 443, "username": "demo@vsphere.local", "password": "demo", "verify_ssl": False}],
        "poll_interval": 60, "read_only": True,
    },
    "zabbix": {
        "zabbix_hosts": [{"name": "zabbix-01", "url": "https://zabbix.demo.lab", "api_token": "demo-token", "verify_tls": False}],
        "poll_interval": 30, "read_only": True,
    },
    "opnsense": {
        "opnsense_hosts": [{"name": "fw-01", "url": "https://opnsense.demo.lab", "api_key": "demo-key", "api_secret": "demo-secret", "verify_tls": True, "ca_bundle_path": ""}],
        "ha_active_url": "https://opnsense.demo.lab", "poll_interval": 30, "read_only": True, "monitor_both_nodes": False, "cluster_mode": "off",
    },
    "pfsense": {
        "pfsense_hosts": [{"name": "edge-01", "url": "https://pfsense.demo.lab", "api_key": "demo-key", "api_secret": "demo-secret", "verify_tls": True, "ca_bundle_path": ""}],
        "poll_interval": 30, "read_only": True,
    },
    "vyos": {
        "vyos_hosts": [{"name": "edge-01", "url": "https://vyos.demo.lab", "api_key": "demo-key", "verify_tls": False}],
        "poll_interval": 30, "read_only": True,
    },
    "truenas": {
        "instances": [{"id": "nas-01", "name": "nas-01", "host": "truenas.demo.lab", "port": 443, "api_key_ro": "demo-key", "api_key_rw": "", "verify_tls": False, "readonly": True}],
        "poll": {"fast_s": 10, "slow_s": 60, "cold_s": 900},
        "thresholds": {"warn_pct": 80, "crit_pct": 90},
        "notify": {"webhook_url": None, "whatsapp_gateway_url": None, "whatsapp_instance": None, "whatsapp_target": None, "whatsapp_api_key": None},
    },
    "active_directory": {
        "ad_hosts": [{"name": "ad-01", "server": "ldaps://ad.demo.lab", "port": 636, "use_ssl": True, "bind_dn": "cn=demo,dc=demo,dc=lab", "bind_password": "demo", "base_dn": "dc=demo,dc=lab", "verify_tls": False}],
        "poll_interval": 300, "read_only": True,
    },
    "docker_swarm": {
        "clusters": [{"id": "demo-swarm", "name": "Demo Swarm", "hosts": [{"name": "swarm-mgr-1", "host": "swarm.demo.lab", "user": "demo", "password": "demo"}]}],
        "poll_interval": 30,
    },
}


def _native_dir():
    return os.path.dirname(os.path.abspath(__file__))


def _is_demo() -> bool:
    return os.environ.get("PROXMOXVEX_DEMO_MODE", "").strip().lower() in ("1", "true", "yes")


def _sanitize_in_place(path: str, plugin: str) -> None:
    """Strip host entries (and any credentials they carry) from a config."""
    try:
        with open(path, encoding="utf-8") as f:
            cfg = json.load(f)
    except Exception:
        return
    key = _HOSTS_KEYS.get(plugin)
    if key and isinstance(cfg.get(key), list) and cfg[key]:
        cfg[key] = []
        try:
            with open(path, "w", encoding="utf-8") as f:
                json.dump(cfg, f, indent=2)
            log.info("[NATIVE] Demo mode: emptied %s hosts", plugin)
        except Exception as e:
            log.warning("[NATIVE] Demo mode: could not sanitize %s: %s", plugin, e)


def persist_native_configs() -> None:
    """Link each native plugin's config.json to the config volume.

    Called once at startup, before load_enabled_plugins(), so plugin
    _load_config() reads the volume-backed file.
    """
    from ProxmoxVEx.constants import CONFIG_DIR

    native_dir = _native_dir()
    persist_root = os.path.join(CONFIG_DIR, "native")
    demo = _is_demo()
    try:
        os.makedirs(persist_root, exist_ok=True)
    except Exception as e:
        log.warning("[NATIVE] Cannot create %s: %s", persist_root, e)
        return

    for entry in sorted(os.listdir(native_dir)):
        plugin_dir = os.path.join(native_dir, entry)
        if not os.path.isdir(plugin_dir):
            continue
        src = os.path.join(plugin_dir, "config.json")
        if not os.path.exists(src) and not os.path.islink(src):
            continue

        if demo:
            # Never restore real configs in the demo — break any symlink and
            # write the synthetic demo config so integrations look configured
            # but point only at mock hostnames (*.demo.lab / the mock).
            try:
                if os.path.islink(src):
                    os.unlink(src)
                demo_cfg = _DEMO_CONFIGS.get(entry)
                if demo_cfg is not None:
                    with open(src, "w", encoding="utf-8") as f:
                        json.dump(demo_cfg, f, indent=2)
                        f.write("\n")
                elif os.path.isfile(src):
                    _sanitize_in_place(src, entry)
            except Exception as e:
                log.warning("[NATIVE] Demo mode: could not scrub %s: %s", entry, e)
            continue

        dst = os.path.join(persist_root, entry, "config.json")
        try:
            # "Already linked" must mean linked to THIS dst — not just any
            # symlink. Dev checkouts and test runs leave config.json pointing
            # at absolute paths from another CONFIG_DIR (e.g. /root/... on the
            # host or a pytest tmpdir); those links get baked into images or
            # left behind and dangle here, making every config read look
            # "unconfigured" and every write fail with EACCES/ENOENT
            # (POST /api/native/<m>/config -> 500). Compare real targets.
            if (
                os.path.islink(src)
                and os.path.exists(dst)
                and os.path.realpath(src) == os.path.realpath(dst)
            ):
                continue  # already linked
            os.makedirs(os.path.dirname(dst), exist_ok=True)
            if not os.path.exists(dst):
                # First boot: migrate the image's config to the volume so the
                # operator's existing setup survives the upgrade that
                # introduced this mechanism. If src is a dangling symlink
                # (e.g. image built from a dev tree), seed from the example.
                if os.path.isfile(src):
                    shutil.copy2(src, dst)
                else:
                    example = os.path.join(plugin_dir, "config.example.json")
                    if os.path.exists(example):
                        shutil.copy2(example, dst)
                    else:
                        continue  # plugin handles missing config
            if os.path.islink(src) or os.path.exists(src):
                os.unlink(src)
            os.symlink(dst, src)
            log.debug("[NATIVE] %s config.json -> %s", entry, dst)
        except Exception as e:
            # Non-fatal: the plugin falls back to the bundled (sanitized)
            # config, which is safe even if empty.
            log.warning("[NATIVE] Could not persist config for %s: %s", entry, e)
