/* --- ProxmoxVEx auto-header start ---
 * -------------------------------------------------------------------
 * File:        ProxmoxVEx/native/zabbix/zabbix.js
 * Project:     ProxmoxVEx
 * Version:     1.2.437
 * Build:       2026.09.12
 * Description: Zabbix JS source
 * Docs:        https://proxmoxvex.com/docs
 * Generated:   2026-09-12
 * -------------------------------------------------------------------
 * --- ProxmoxVEx auto-header end --- */
/* Zabbix view: declarative tabs rendered by the shared NativeDataView shell
   (replaces the previous raw JSON <pre> dump). */
(function () {
  'use strict';

  var V = window.NativeDataView;

  // Zabbix severities 0..5 → label + badge tone.
  var SEVERITIES = [
    ['Not classified', 'muted'],
    ['Information', 'info'],
    ['Warning', 'warn'],
    ['Average', 'warn'],
    ['High', 'err'],
    ['Disaster', 'err']
  ];

  function severityBadge(v) {
    var i = Number(v);
    var sev = SEVERITIES[i] || [String(v == null ? '—' : v), 'muted'];
    return V.badge(sev[0], sev[1]);
  }

  NativeDataView.boot({
    ns: 'zabbix',
    apiBase: '/api/zabbix',
    i18nBase: '/api/native/zabbix/i18n',
    tabs: [
      {
        id: 'overview', label: 'overview', endpoint: 'overview',
        render: function (h, data) {
          var row = (data && data[0]) || {};
          h.root.appendChild(h.kpis([
            { label: h.t('monitored_hosts'), value: row.hosts_count },
            { label: h.t('active_problems'), value: row.problems_count }
          ]));
          h.section(h.t('server'), h.kv([
            [h.t('host'), row.host],
            [h.t('url'), row.url],
            [h.t('api_version'), row.api_version],
            [h.t('hosts'), row.hosts_ok ? h.badge('OK', 'ok') : h.badge('Error', 'err')],
            [h.t('problems'), row.problems_ok ? h.badge('OK', 'ok') : h.badge('Error', 'err')]
          ]));
        }
      },
      {
        id: 'hosts', label: 'hosts', endpoint: 'hosts',
        render: function (h, data) {
          h.root.appendChild(h.table(data || [], [
            { key: 'hostid', label: 'ID' },
            { key: 'name', label: h.t('name') },
            { key: 'host', label: h.t('host') },
            {
              key: 'status', label: h.t('status'),
              render: function (v) { return h.badge(String(v) === '0' ? h.t('enabled') : h.t('disabled'), String(v) === '0' ? 'ok' : 'muted'); }
            }
          ]));
        }
      },
      {
        id: 'problems', label: 'problems', endpoint: 'problems',
        render: function (h, data) {
          h.root.appendChild(h.table(data || [], [
            { key: 'severity', label: h.t('severity'), render: severityBadge },
            { key: 'name', label: h.t('problem') },
            {
              key: 'hosts', label: h.t('host'),
              render: function (v) { return (v && v[0] && v[0].name) || null; }
            },
            { key: 'clock', label: h.t('time'), render: function (v) { return h.fmtAgo(v); } },
            {
              key: 'acknowledged', label: h.t('acknowledged'),
              render: function (v) { return h.badge(String(v) === '1' ? h.t('yes') : h.t('no'), String(v) === '1' ? 'ok' : 'muted'); }
            }
          ]));
        }
      }
    ]
  });
})();
