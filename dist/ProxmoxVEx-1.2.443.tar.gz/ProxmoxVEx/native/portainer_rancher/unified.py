# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/native/portainer_rancher/unified.py
# Project:     ProxmoxVEx
# Version:     1.2.437
# Build:       2026.09.12
# Description: Unified container/workload inventory across all sources...
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-12
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Unified container/workload inventory across all sources (US3 / FR-007).

Rebuilds ``unified_workloads`` from the per-manager caches:

- ``portainer`` rows come from ``portainer_containers`` (containers on
  Portainer-managed Docker/Swarm/K8s endpoints).
- ``rancher`` rows come from ``rancher_workloads``.
- ``direct`` rows merge existing Docker/Swarm and native Kubernetes sources
  when their tables are present (best-effort; those integrations remain
  authoritative for their own data).

``global_id`` is deterministic and unique per source so refresh cycles never
double-count (data-model persistence note).
"""

import logging
from typing import Any, Dict, List, Optional

from . import models

log = logging.getLogger("native.portainer_rancher.unified")

_CONTAINER_STATE_MAP = {
    "running": "running",
    "exited": "stopped",
    "stopped": "stopped",
    "created": "stopped",
    "paused": "paused",
    "restarting": "error",
    "dead": "error",
    "removing": "stopped",
}


def _portainer_row(c: Dict[str, Any], endpoint: Dict[str, Any]) -> Dict[str, Any]:
    global_id = (
        f"portainer:{c['connection_id']}:{endpoint.get('endpoint_id')}:"
        f"{c['container_id']}"
    )
    platform = {
        "docker": "docker",
        "swarm": "swarm",
        "kubernetes": "kubernetes",
        "edge_agent": "docker",
    }.get(endpoint.get("endpoint_type", ""), "docker")
    linked = bool(
        models.find_resource_link(
            "portainer_endpoint",
            f"portainer:{c['connection_id']}:{endpoint.get('endpoint_id')}",
        )
    )
    return {
        "global_id": global_id,
        "name": c.get("name", ""),
        "kind": "container",
        "state": _CONTAINER_STATE_MAP.get(c.get("state", ""), c.get("state") or "unknown"),
        "image": c.get("image", ""),
        "source_platform": platform,
        "source_manager": "portainer",
        "connection_id": c.get("connection_id"),
        "endpoint_id": c.get("endpoint_pk"),
        "cluster_id": None,
        "namespace": c.get("stack_name") or "",
        "health": c.get("health", "unknown"),
        "restart_count": int(c.get("restart_count", 0)),
        "linked": linked,
    }


def _rancher_row(w: Dict[str, Any], cluster: Dict[str, Any]) -> Dict[str, Any]:
    global_id = (
        f"rancher:{w['connection_id']}:{cluster.get('cluster_id')}:"
        f"{w.get('namespace') or ''}:{w['workload_id']}"
    )
    linked = bool(
        cluster.get("direct_k8s_connection_id")
        or models.find_resource_link(
            "rancher_cluster",
            f"rancher:{w['connection_id']}:{cluster.get('cluster_id')}",
        )
    )
    return {
        "global_id": global_id,
        "name": w.get("name", ""),
        "kind": w.get("kind", "unknown"),
        "state": w.get("state", "unknown"),
        "image": w.get("image", ""),
        "source_platform": "kubernetes",
        "source_manager": "rancher",
        "connection_id": w.get("connection_id"),
        "endpoint_id": None,
        "cluster_id": w.get("cluster_pk"),
        "namespace": w.get("namespace", ""),
        "health": w.get("health", "unknown"),
        "restart_count": int(w.get("restart_count", 0)),
        "linked": linked,
    }


def _merge_direct_sources() -> List[Dict[str, Any]]:
    """Best-effort merge of existing direct Docker/Swarm and Kubernetes sources.

    Only runs when the corresponding tables exist; the native integrations
    stay authoritative — these rows are attributed with source_manager
    ``direct`` so operators can tell them apart from manager-reported data.
    """
    out: List[Dict[str, Any]] = []
    db = models.get_db()
    # Direct Kubernetes connections (spec 001) — k8s_clusters registry.
    if models.table_exists("k8s_clusters"):
        try:
            for row in db.query("SELECT id, name FROM k8s_clusters"):
                row = dict(row)
                out.append({
                    "global_id": f"direct:kubernetes:{row['id']}",
                    "name": row.get("name", ""),
                    "kind": "unknown",
                    "state": "unknown",
                    "image": "",
                    "source_platform": "kubernetes",
                    "source_manager": "direct",
                    "connection_id": None,
                    "endpoint_id": None,
                    "cluster_id": None,
                    "namespace": "",
                    "health": "unknown",
                    "restart_count": 0,
                    "linked": bool(
                        models.find_resource_link(
                            "kubernetes_cluster", str(row["id"])
                        )
                    ),
                })
        except Exception as e:
            log.debug("[unified] k8s direct merge failed: %s", e)
    return out


def rebuild(
    source_manager: Optional[str] = None,
    connection_id: Optional[int] = None,
) -> Dict[str, int]:
    """Rebuild unified workload rows for one manager (or all).

    Stale rows are removed because the whole per-manager partition is
    rewritten each refresh (data-model: rebuilt from source caches).
    """
    counts = {"portainer": 0, "rancher": 0, "direct": 0}

    if source_manager in (None, "portainer"):
        if connection_id is None:
            models.get_db().execute(
                "DELETE FROM unified_workloads WHERE source_manager = 'portainer'"
            )
        else:
            models.get_db().execute(
                "DELETE FROM unified_workloads WHERE source_manager = 'portainer' "
                "AND connection_id = ?",
                (connection_id,),
            )
        endpoints = {
            e["id"]: e for e in models.list_rows(
                "portainer_endpoints", connection_id=connection_id
            )
        }
        for c in models.list_rows("portainer_containers", connection_id=connection_id):
            ep = endpoints.get(c.get("endpoint_pk"), {})
            models.upsert_unified(_portainer_row(c, ep))
            counts["portainer"] += 1

    if source_manager in (None, "rancher"):
        if connection_id is None:
            models.get_db().execute(
                "DELETE FROM unified_workloads WHERE source_manager = 'rancher'"
            )
        else:
            models.get_db().execute(
                "DELETE FROM unified_workloads WHERE source_manager = 'rancher' "
                "AND connection_id = ?",
                (connection_id,),
            )
        clusters = {
            cl["id"]: cl for cl in models.list_rows(
                "rancher_clusters", connection_id=connection_id
            )
        }
        for w in models.list_rows("rancher_workloads", connection_id=connection_id):
            cl = clusters.get(w.get("cluster_pk"), {})
            models.upsert_unified(_rancher_row(w, cl))
            counts["rancher"] += 1

    if source_manager in (None, "direct"):
        models.get_db().execute(
            "DELETE FROM unified_workloads WHERE source_manager = 'direct'"
        )
        for row in _merge_direct_sources():
            models.upsert_unified(row)
            counts["direct"] += 1

    return counts


def list_workloads(filters: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
    return models.list_unified(filters)


def detect_duplicate_environments() -> List[Dict[str, Any]]:
    """Report environments reachable through more than one path (FR-008).

    A duplicate is surfaced when a Portainer endpoint or Rancher cluster has
    an automatic resource link to another managed source.
    """
    dupes: List[Dict[str, Any]] = []
    for link in models.list_resource_links():
        if link.get("link_type") == "automatic" and float(link.get("match_confidence") or 0) >= 0.7:
            dupes.append(link)
    return dupes
