# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/native/portainer_rancher/inventory.py
# Project:     ProxmoxVEx
# Version:     1.2.437
# Build:       2026.09.12
# Description: Inventory discovery for Portainer...
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-12
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Inventory discovery for Portainer endpoints/stacks/containers/images and
Rancher clusters/projects/namespaces/workloads/catalog apps.

Per FR-014 / edge cases: failures are isolated per connection and per
endpoint/cluster — one dead endpoint never drops the rest of the inventory.
Scope-limited tokens (Portainer endpoint groups, Rancher project roles) are
surfaced via the connection's ``scope_limited`` flag rather than failing.
"""

import logging
from typing import Any, Dict, List, Optional
from urllib.parse import urlparse

from . import models, portainer, rancher

log = logging.getLogger("native.portainer_rancher.inventory")


def _marker() -> str:
    return models._now_iso()


# ---------------------------------------------------------------------------
# Duplicate / cross-reference detection (FR-008)
# ---------------------------------------------------------------------------


def _host_of(url: str) -> str:
    try:
        return (urlparse(url or "").hostname or "").lower()
    except Exception:
        return ""


def _find_direct_k8s_connection(api_endpoint: str, name: str) -> str:
    """Look for a directly-registered Kubernetes cluster matching this
    Rancher-managed cluster (same API endpoint host or same name)."""
    if not models.table_exists("k8s_clusters"):
        return ""
    host = _host_of(api_endpoint)
    try:
        rows = models.get_db().query(
            "SELECT id, name, api_url FROM k8s_clusters"
        )
    except Exception:
        return ""
    for row in rows:
        row = dict(row)
        if host and host == _host_of(row.get("api_url", "")):
            return str(row.get("id"))
        if name and name.lower() == (row.get("name") or "").lower():
            return str(row.get("id"))
    return ""


def _crossref_portainer_endpoint(connection_id: int, ep_row: Dict[str, Any]) -> None:
    """Cross-reference a Portainer endpoint against other known sources.

    Links are recorded in ``portainer_rancher_resource_links`` so the unified
    inventory can attribute rather than double-count (FR-008).
    """
    engine_id = ep_row.get("engine_id") or ""
    if not engine_id:
        return
    local_id = f"portainer:{connection_id}:{ep_row.get('endpoint_id')}"
    # Match a Rancher cluster reporting the same engine/API endpoint.
    for cl in models.list_rows("rancher_clusters"):
        if engine_id and cl.get("api_endpoint") and \
                _host_of(cl["api_endpoint"]) == _host_of(ep_row.get("url", "")):
            models.create_resource_link(
                "portainer_endpoint", local_id,
                "kubernetes_cluster", f"rancher:{cl['connection_id']}:{cl['cluster_id']}",
                link_type="automatic", confidence=0.8,
            )
    # Match a directly-registered k8s cluster by endpoint URL.
    if models.table_exists("k8s_clusters") and ep_row.get("url"):
        try:
            rows = models.get_db().query("SELECT id, api_url FROM k8s_clusters")
            for row in rows:
                row = dict(row)
                if _host_of(row.get("api_url", "")) == _host_of(ep_row["url"]):
                    models.create_resource_link(
                        "portainer_endpoint", local_id,
                        "kubernetes_cluster", str(row["id"]),
                        link_type="automatic", confidence=0.9,
                    )
        except Exception as e:
            log.debug("[portainer_rancher] k8s cross-ref failed: %s", e)


def correlate_nodes_to_vms(connection_id: int) -> int:
    """Link Rancher cluster nodes / Portainer endpoints to ProxmoxVEx VMs by
    hostname where a VM inventory table exists. Best-effort correlation."""
    if not models.table_exists("vms"):
        return 0
    linked = 0
    try:
        vms = models.get_db().query("SELECT vmid, name, node FROM vms")
    except Exception:
        return 0
    names = {str(dict(v).get("name") or "").lower(): dict(v) for v in vms}
    for c in models.list_rows("portainer_containers", connection_id=connection_id):
        node = (c.get("node_name") or "").lower()
        if node and node in names:
            vm = names[node]
            models.create_resource_link(
                "workload", f"portainer:{c['id']}",
                "physical_node", str(vm.get("node") or vm.get("vmid")),
                link_type="automatic", confidence=0.7,
            )
            linked += 1
    return linked


# ---------------------------------------------------------------------------
# Portainer refresh
# ---------------------------------------------------------------------------


def refresh_portainer_connection(conn_id: int) -> Dict[str, Any]:
    """Pull live inventory for one Portainer connection into the cache."""
    conn = models.get_portainer_connection(conn_id)
    if not conn:
        raise portainer.PortainerError("notfound", f"connection {conn_id}")
    client = portainer.build_connector(conn)
    marker = _marker()
    counts: Dict[str, Any] = {
        "endpoints": 0, "stacks": 0, "containers": 0, "images": 0,
        "scope_limited": False,
    }

    try:
        info = client.test_connection()
    except portainer.PortainerError as e:
        models.update_portainer_status(
            conn_id, "unreachable", models._now_iso(), error=e.message
        )
        models.raise_alert(
            "portainer", "manager_unreachable", conn_id,
            f"Portainer '{conn.display_name}' unreachable: {e.message}",
            severity="critical", entity_type="manager", entity_id=str(conn_id),
        )
        raise
    models.update_portainer_status(
        conn_id, "reachable", models._now_iso(),
        version=info.get("version", ""), edition=info.get("edition", ""), error="",
    )
    models.resolve_alert("portainer", "manager_unreachable", conn_id, str(conn_id))

    # --- endpoints -----------------------------------------------------------
    try:
        endpoints = client.list_endpoints()
    except portainer.PortainerError as e:
        if e.code == "auth.forbidden":
            counts["scope_limited"] = True
            endpoints = []
        else:
            raise

    ep_pk_by_remote: Dict[int, int] = {}
    for ep in endpoints:
        ep["last_seen"] = marker
        pk = models.upsert_endpoint(conn_id, ep)
        ep_pk_by_remote[ep["endpoint_id"]] = pk
        row = dict(ep)
        row["endpoint_id"] = ep["endpoint_id"]
        _crossref_portainer_endpoint(conn_id, row)
    counts["endpoints"] = len(endpoints)
    models.prune_stale("portainer_endpoints", marker, connection_id=conn_id)

    # --- stacks (global list, grouped by endpoint) ----------------------------
    try:
        stacks = client.list_stacks()
    except portainer.PortainerError as e:
        if e.code == "auth.forbidden":
            counts["scope_limited"] = True
            stacks = []
        else:
            log.warning("[portainer] stack discovery failed for conn %s: %s", conn_id, e)
            stacks = []
    for s in stacks:
        ep_pk = ep_pk_by_remote.get(int(s.get("endpoint_id") or 0))
        if not ep_pk:
            continue
        s["last_seen"] = marker
        models.upsert_stack(conn_id, ep_pk, s)
        counts["stacks"] += 1
    models.prune_stale("portainer_stacks", marker, connection_id=conn_id)

    # --- per-endpoint containers + images ------------------------------------
    for ep in endpoints:
        ep_pk = ep_pk_by_remote[ep["endpoint_id"]]
        # Edge-agent endpoints may not be directly reachable; Portainer proxies
        # the docker API, but a down endpoint reports no live containers.
        if ep.get("status") == "down":
            continue
        try:
            for c in client.list_containers(ep["endpoint_id"]):
                c["last_seen"] = marker
                models.upsert_container(conn_id, ep_pk, c)
                counts["containers"] += 1
        except portainer.PortainerError as e:
            if e.code == "auth.forbidden":
                counts["scope_limited"] = True
            else:
                log.debug(
                    "[portainer] containers on endpoint %s failed: %s",
                    ep["endpoint_id"], e,
                )
        try:
            for img in client.list_images(ep["endpoint_id"]):
                img["last_seen"] = marker
                models.upsert_image(conn_id, ep_pk, img)
                counts["images"] += 1
        except portainer.PortainerError as e:
            if e.code == "auth.forbidden":
                counts["scope_limited"] = True
            else:
                log.debug(
                    "[portainer] images on endpoint %s failed: %s",
                    ep["endpoint_id"], e,
                )
    models.prune_stale("portainer_containers", marker, connection_id=conn_id)
    models.prune_stale("portainer_images", marker, connection_id=conn_id)

    if counts["scope_limited"]:
        models.update_portainer_status(
            conn_id, "degraded", models._now_iso(), scope_limited=True
        )
    else:
        models.update_portainer_status(conn_id, "reachable", scope_limited=False)

    correlate_nodes_to_vms(conn_id)

    # Rebuild unified rows for this manager.
    from . import unified

    unified.rebuild(source_manager="portainer", connection_id=conn_id)
    return counts


# ---------------------------------------------------------------------------
# Rancher refresh
# ---------------------------------------------------------------------------


def refresh_rancher_connection(conn_id: int) -> Dict[str, Any]:
    """Pull live inventory for one Rancher connection into the cache."""
    conn = models.get_rancher_connection(conn_id)
    if not conn:
        raise rancher.RancherError("notfound", f"connection {conn_id}")
    client = rancher.build_connector(conn)
    marker = _marker()
    counts: Dict[str, Any] = {
        "clusters": 0, "projects": 0, "workloads": 0, "catalog_apps": 0,
        "scope_limited": False,
    }

    try:
        info = client.test_connection()
    except rancher.RancherError as e:
        models.update_rancher_status(
            conn_id, "unreachable", models._now_iso(), error=e.message
        )
        models.raise_alert(
            "rancher", "manager_unreachable", conn_id,
            f"Rancher '{conn.display_name}' unreachable: {e.message}",
            severity="critical", entity_type="manager", entity_id=str(conn_id),
        )
        raise
    models.update_rancher_status(
        conn_id, "reachable", models._now_iso(),
        version=info.get("version", ""), error="",
    )
    models.resolve_alert("rancher", "manager_unreachable", conn_id, str(conn_id))

    try:
        clusters = client.list_clusters()
    except rancher.RancherError as e:
        if e.code == "auth.forbidden":
            counts["scope_limited"] = True
            clusters = []
        else:
            raise

    cluster_pk_by_remote: Dict[str, int] = {}
    for cl in clusters:
        cl["last_seen"] = marker
        # US2.2: detect clusters also registered directly via the K8s
        # integration and cross-reference instead of duplicating.
        direct = _find_direct_k8s_connection(cl.get("api_endpoint", ""), cl.get("name", ""))
        cl["direct_k8s_connection_id"] = direct
        pk = models.upsert_cluster(conn_id, cl)
        cluster_pk_by_remote[cl["cluster_id"]] = pk
        if direct:
            models.create_resource_link(
                "rancher_cluster", f"rancher:{conn_id}:{cl['cluster_id']}",
                "kubernetes_cluster", direct,
                link_type="automatic", confidence=0.95,
            )
    counts["clusters"] = len(clusters)
    models.prune_stale("rancher_clusters", marker, connection_id=conn_id)

    for cl in clusters:
        cluster_pk = cluster_pk_by_remote[cl["cluster_id"]]
        # Degraded/unreachable downstream clusters are reported independently;
        # skip deep discovery but keep the cluster row (US2.3).
        if cl.get("state") not in ("active", "running"):
            continue
        try:
            projects = client.list_projects(cl["cluster_id"])
        except rancher.RancherError as e:
            if e.code == "auth.forbidden":
                counts["scope_limited"] = True
                projects = []
            else:
                log.debug(
                    "[rancher] projects for cluster %s failed: %s",
                    cl["cluster_id"], e,
                )
                projects = []

        proj_pk_by_remote: Dict[str, int] = {}
        for p in projects:
            try:
                p["namespaces"] = client.list_namespaces(p["project_id"])
            except rancher.RancherError as e:
                if e.code == "auth.forbidden":
                    counts["scope_limited"] = True
                p["namespaces"] = []
            p["last_seen"] = marker
            pk = models.upsert_project(conn_id, cluster_pk, p)
            proj_pk_by_remote[p["project_id"]] = pk
            counts["projects"] += 1
        models.prune_stale(
            "rancher_projects", marker, connection_id=conn_id, cluster_pk=cluster_pk
        )

        for p in projects:
            proj_pk = proj_pk_by_remote[p["project_id"]]
            try:
                for w in client.list_workloads(p["project_id"]):
                    w["project_pk"] = proj_pk
                    w["last_seen"] = marker
                    models.upsert_workload(conn_id, cluster_pk, w)
                    counts["workloads"] += 1
            except rancher.RancherError as e:
                if e.code == "auth.forbidden":
                    counts["scope_limited"] = True
                else:
                    log.debug(
                        "[rancher] workloads for project %s failed: %s",
                        p["project_id"], e,
                    )
            try:
                for a in client.list_catalog_apps(p["project_id"]):
                    a["last_seen"] = marker
                    models.upsert_catalog_app(conn_id, cluster_pk, a)
                    counts["catalog_apps"] += 1
            except rancher.RancherError as e:
                if e.code == "auth.forbidden":
                    counts["scope_limited"] = True
                else:
                    log.debug(
                        "[rancher] catalog apps for project %s failed: %s",
                        p["project_id"], e,
                    )
        models.prune_stale(
            "rancher_workloads", marker, connection_id=conn_id, cluster_pk=cluster_pk
        )
        models.prune_stale(
            "rancher_catalog_apps", marker, connection_id=conn_id, cluster_pk=cluster_pk
        )

    if counts["scope_limited"]:
        models.update_rancher_status(
            conn_id, "degraded", models._now_iso(), scope_limited=True
        )
    else:
        models.update_rancher_status(conn_id, "reachable", scope_limited=False)

    from . import unified

    unified.rebuild(source_manager="rancher", connection_id=conn_id)
    return counts


def refresh_all() -> Dict[str, Any]:
    """Refresh every configured manager connection; per-connection failures
    are isolated so one dead manager cannot affect the others."""
    results: Dict[str, Any] = {"portainer": {}, "rancher": {}}
    for conn in models.list_portainer_connections():
        try:
            results["portainer"][conn.id] = refresh_portainer_connection(conn.id or 0)
        except Exception as e:
            results["portainer"][conn.id] = {"error": str(e)}
    for rconn in models.list_rancher_connections():
        try:
            results["rancher"][rconn.id] = refresh_rancher_connection(rconn.id or 0)
        except Exception as e:
            results["rancher"][rconn.id] = {"error": str(e)}
    return results


def get_endpoint(endpoint_pk: int) -> Optional[Dict[str, Any]]:
    return models.get_row("portainer_endpoints", endpoint_pk)


def list_endpoint_stacks(endpoint_pk: int) -> List[Dict[str, Any]]:
    return models.list_rows("portainer_stacks", endpoint_pk=endpoint_pk)


def list_endpoint_containers(endpoint_pk: int) -> List[Dict[str, Any]]:
    return models.list_rows("portainer_containers", endpoint_pk=endpoint_pk)


def list_endpoint_images(endpoint_pk: int) -> List[Dict[str, Any]]:
    return models.list_rows("portainer_images", endpoint_pk=endpoint_pk)


def get_cluster(cluster_pk: int) -> Optional[Dict[str, Any]]:
    return models.get_row("rancher_clusters", cluster_pk)


def list_cluster_projects(cluster_pk: int) -> List[Dict[str, Any]]:
    return models.list_rows("rancher_projects", cluster_pk=cluster_pk)


def list_cluster_workloads(
    cluster_pk: int, namespace: Optional[str] = None, kind: Optional[str] = None
) -> List[Dict[str, Any]]:
    filters: Dict[str, Any] = {"cluster_pk": cluster_pk}
    if namespace:
        filters["namespace"] = namespace
    if kind:
        filters["kind"] = kind
    return models.list_rows("rancher_workloads", **filters)


def list_cluster_catalog_apps(cluster_pk: int) -> List[Dict[str, Any]]:
    return models.list_rows("rancher_catalog_apps", cluster_pk=cluster_pk)
