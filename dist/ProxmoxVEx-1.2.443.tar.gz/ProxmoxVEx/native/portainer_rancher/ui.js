/* --- ProxmoxVEx auto-header start ---
 * -------------------------------------------------------------------
 * File:        ProxmoxVEx/native/portainer_rancher/ui.js
 * Project:     ProxmoxVEx
 * Version:     1.2.437
 * Build:       2026.09.12
 * Description: Ui JS source
 * Docs:        https://proxmoxvex.com/docs
 * Generated:   2026-09-12
 * -------------------------------------------------------------------
 * --- ProxmoxVEx auto-header end --- */
(function () {
    'use strict';

    const API = '/api/native/portainer_rancher';
    const content = document.getElementById('content');
    const dashboard = document.getElementById('dashboard');
    const connSection = document.getElementById('connections');
    const connForm = document.getElementById('conn-form');

    function esc(s) {
        return String(s == null ? '' : s).replace(/[&<>"']/g, c => ({
            '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
        }[c]));
    }

    async function get(path) {
        const res = await fetch(API + path);
        if (!res.ok) return { error: res.statusText };
        return res.json();
    }

    async function post(path, body) {
        const res = await fetch(API + path, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: body ? JSON.stringify(body) : undefined,
        });
        return { ok: res.ok, status: res.status, data: await res.json().catch(() => ({})) };
    }

    async function del(path) {
        const res = await fetch(API + path, { method: 'DELETE' });
        return res.ok;
    }

    function badge(v) {
        const val = String(v || 'unknown');
        return `<span class="badge ${esc(val.toLowerCase())}">${esc(val)}</span>`;
    }

    function fmtBytes(n) {
        n = Number(n) || 0;
        const units = ['B', 'KB', 'MB', 'GB', 'TB'];
        let i = 0;
        while (n >= 1024 && i < units.length - 1) { n /= 1024; i++; }
        return `${n.toFixed(1)} ${units[i]}`;
    }

    // --- connections ---------------------------------------------------------

    async function loadConnections() {
        const [pc, rc] = await Promise.all([
            get('/portainer-connections'),
            get('/rancher-connections'),
        ]);
        let html = '<h2>Connections</h2>';
        const pConns = pc.connections || [];
        const rConns = rc.connections || [];
        for (const c of pConns) {
            html += `<div class="card">
                <div><strong>${esc(c.display_name)}</strong> <span class="muted">Portainer · ${esc(c.base_url)}</span><br>
                <span class="muted">${esc(c.edition || '')} ${esc(c.version || '')}${c.scope_limited ? ' · scope limited' : ''}</span></div>
                <div>${badge(c.connectivity_status)}
                    <button class="secondary" data-ptest="${c.id}">Test</button>
                    <button class="secondary" data-prefresh="${c.id}">Refresh</button>
                    <button class="secondary" data-pdel="${c.id}">Delete</button></div>
            </div>`;
        }
        for (const c of rConns) {
            html += `<div class="card">
                <div><strong>${esc(c.display_name)}</strong> <span class="muted">Rancher · ${esc(c.server_url)}</span><br>
                <span class="muted">${esc(c.version || '')}${c.scope_limited ? ' · scope limited' : ''}</span></div>
                <div>${badge(c.connectivity_status)}
                    <button class="secondary" data-rtest="${c.id}">Test</button>
                    <button class="secondary" data-rrefresh="${c.id}">Refresh</button>
                    <button class="secondary" data-rdel="${c.id}">Delete</button></div>
            </div>`;
        }
        if (!pConns.length && !rConns.length) {
            html += '<p class="muted">No connections configured.</p>';
        } else {
            dashboard.classList.remove('hidden');
        }
        html += '<button id="add-conn">Add Connection</button>';
        connSection.innerHTML = html;
        document.getElementById('add-conn').addEventListener('click', () => connForm.classList.toggle('hidden'));
        connSection.querySelectorAll('[data-ptest]').forEach(b => b.addEventListener('click', async () => {
            await post(`/portainer-connections/${b.dataset.ptest}/test`);
            loadConnections();
        }));
        connSection.querySelectorAll('[data-rtest]').forEach(b => b.addEventListener('click', async () => {
            await post(`/rancher-connections/${b.dataset.rtest}/test`);
            loadConnections();
        }));
        connSection.querySelectorAll('[data-prefresh]').forEach(b => b.addEventListener('click', async () => {
            await post(`/portainer-connections/${b.dataset.prefresh}/refresh`);
            loadConnections(); loadTab(currentTab);
        }));
        connSection.querySelectorAll('[data-rrefresh]').forEach(b => b.addEventListener('click', async () => {
            await post(`/rancher-connections/${b.dataset.rrefresh}/refresh`);
            loadConnections(); loadTab(currentTab);
        }));
        connSection.querySelectorAll('[data-pdel]').forEach(b => b.addEventListener('click', async () => {
            if (!confirm('Delete this Portainer connection?')) return;
            await del(`/portainer-connections/${b.dataset.pdel}`);
            loadConnections();
        }));
        connSection.querySelectorAll('[data-rdel]').forEach(b => b.addEventListener('click', async () => {
            if (!confirm('Delete this Rancher connection?')) return;
            await del(`/rancher-connections/${b.dataset.rdel}`);
            loadConnections();
        }));
    }

    // --- connection form ------------------------------------------------------

    const form = document.getElementById('new-connection');
    const tlsBox = form.querySelector('[name=tls_verify]');
    const tlsAck = form.querySelector('.tls-ack');
    tlsBox.addEventListener('change', () => tlsAck.classList.toggle('hidden', tlsBox.checked));
    document.getElementById('cancel-conn').addEventListener('click', () => connForm.classList.add('hidden'));

    form.addEventListener('submit', async e => {
        e.preventDefault();
        const fd = new FormData(form);
        const manager = fd.get('manager');
        const body = {
            display_name: fd.get('display_name'),
            tls_verify: !!fd.get('tls_verify'),
            tls_insecure_ack: !!fd.get('tls_insecure_ack'),
            auth_type: 'api_token',
            credential: { token: fd.get('token') },
            proxmox_cluster_id: fd.get('proxmox_cluster_id') || '',
        };
        if (manager === 'portainer') body.base_url = fd.get('url');
        else body.server_url = fd.get('url');
        const res = await post(`/${manager}-connections`, body);
        const errEl = document.getElementById('conn-error');
        if (!res.ok) {
            errEl.textContent = res.data.reason || res.data.error || 'Failed to create connection';
            return;
        }
        errEl.textContent = '';
        connForm.classList.add('hidden');
        form.reset();
        loadConnections();
    });

    // --- tabs ------------------------------------------------------------------

    let currentTab = 'unified';
    document.getElementById('tabs').addEventListener('click', e => {
        if (!e.target.dataset.tab) return;
        document.querySelectorAll('#tabs button').forEach(b => b.classList.remove('active'));
        e.target.classList.add('active');
        loadTab(e.target.dataset.tab);
    });

    async function loadTab(tab) {
        currentTab = tab;
        if (tab === 'unified') return loadUnified();
        if (tab === 'endpoints') return loadEndpoints();
        if (tab === 'clusters') return loadClusters();
        if (tab === 'stacks') return loadStacksApps();
        if (tab === 'alerts') return loadAlerts();
    }

    async function loadUnified(params) {
        const qs = params ? '?' + new URLSearchParams(params).toString() : '';
        const data = await get('/unified/workloads' + qs);
        const items = data.items || [];
        let html = `<div class="filters">
            <input id="f-name" placeholder="Filter name" value="${esc((params || {}).name || '')}">
            <input id="f-image" placeholder="Filter image" value="${esc((params || {}).image || '')}">
            <select id="f-source"><option value="">All sources</option>
                <option>portainer</option><option>rancher</option><option>direct</option></select>
            <select id="f-state"><option value="">All states</option>
                <option>running</option><option>stopped</option><option>paused</option><option>error</option></select>
            <button id="f-apply" class="secondary">Filter</button>
        </div>
        <table><tr><th>Name</th><th>Kind</th><th>State</th><th>Image</th><th>Source</th><th>Health</th><th>Restarts</th><th>Actions</th></tr>`;
        for (const w of items) {
            html += `<tr><td>${esc(w.name)}</td><td>${esc(w.kind)}</td><td>${badge(w.state)}</td>
                <td class="muted">${esc(w.image)}</td>
                <td>${esc(w.source_manager)}${w.linked ? ' <span class="muted">(linked)</span>' : ''}</td>
                <td>${badge(w.health)}</td><td>${esc(w.restart_count)}</td><td></td></tr>`;
        }
        html += `</table><p class="muted">${data.total || 0} workload(s)</p>`;
        content.innerHTML = html;
        document.getElementById('f-source').value = (params || {}).source || '';
        document.getElementById('f-state').value = (params || {}).state || '';
        document.getElementById('f-apply').addEventListener('click', () => {
            loadUnified({
                name: document.getElementById('f-name').value,
                image: document.getElementById('f-image').value,
                source: document.getElementById('f-source').value,
                state: document.getElementById('f-state').value,
            });
        });
    }

    async function loadEndpoints() {
        const data = await get('/portainer/endpoints');
        const items = data.items || [];
        let html = '<table><tr><th>Name</th><th>Type</th><th>Status</th><th>Heartbeat</th><th>Containers</th></tr>';
        for (const e of items) {
            html += `<tr><td><a href="#" data-ep="${e.id}">${esc(e.name)}</a></td><td>${esc(e.endpoint_type)}</td>
                <td>${badge(e.status)}</td><td class="muted">${esc(e.last_heartbeat || '—')}</td>
                <td>${esc(e.container_count)}</td></tr>`;
        }
        html += '</table><div id="ep-detail"></div>';
        content.innerHTML = html;
        content.querySelectorAll('[data-ep]').forEach(a => a.addEventListener('click', async ev => {
            ev.preventDefault();
            const epId = a.dataset.ep;
            const cdata = await get(`/portainer/endpoints/${epId}/containers`);
            const containers = cdata.items || [];
            let d = `<h3>Containers</h3><table><tr><th>Name</th><th>Image</th><th>State</th><th>Health</th><th>Restarts</th><th>Actions</th></tr>`;
            for (const c of containers) {
                d += `<tr><td>${esc(c.name)}</td><td class="muted">${esc(c.image)}</td>
                    <td>${badge(c.state)}</td><td>${badge(c.health)}</td><td>${esc(c.restart_count)}</td>
                    <td>${['start', 'stop', 'restart', 'pause', 'unpause'].map(a2 =>
                        `<button class="secondary" data-cid="${c.id}" data-act="${a2}">${a2}</button>`).join('')}
                    </td></tr>`;
            }
            d += '</table>';
            document.getElementById('ep-detail').innerHTML = d;
            document.querySelectorAll('[data-act]').forEach(b => b.addEventListener('click', async () => {
                await post(`/portainer/containers/${b.dataset.cid}/power`, { action: b.dataset.act });
                loadTab('endpoints');
            }));
        }));
    }

    async function loadClusters() {
        const data = await get('/rancher/clusters');
        const items = data.items || [];
        let html = '<table><tr><th>Name</th><th>K8s</th><th>Provider</th><th>State</th><th>Nodes</th><th>Direct K8s</th></tr>';
        for (const c of items) {
            html += `<tr><td><a href="#" data-cl="${c.id}">${esc(c.name)}</a></td><td>${esc(c.kubernetes_version)}</td>
                <td>${esc(c.provider)}</td><td>${badge(c.state)}<br><span class="muted">${esc(c.state_message || '')}</span></td>
                <td>${esc(c.node_count)}</td><td>${c.direct_k8s_connection_id ? 'linked' : '—'}</td></tr>`;
        }
        html += '</table><div id="cl-detail"></div>';
        content.innerHTML = html;
        content.querySelectorAll('[data-cl]').forEach(a => a.addEventListener('click', async ev => {
            ev.preventDefault();
            const cid = a.dataset.cl;
            const [proj, wl] = await Promise.all([
                get(`/rancher/clusters/${cid}/projects`),
                get(`/rancher/clusters/${cid}/workloads`),
            ]);
            let d = '<h3>Projects</h3><ul>' + (proj.projects || []).map(p =>
                `<li>${esc(p.name)} <span class="muted">${esc((JSON.parse(p.namespaces || '[]')).join(', '))}</span></li>`).join('') + '</ul>';
            d += '<h3>Workloads</h3><table><tr><th>Name</th><th>Kind</th><th>Namespace</th><th>State</th><th>Replicas</th><th>Actions</th></tr>';
            for (const w of (wl.items || [])) {
                d += `<tr><td>${esc(w.name)}</td><td>${esc(w.kind)}</td><td>${esc(w.namespace)}</td>
                    <td>${badge(w.state)}</td><td>${esc(w.ready_replicas)}/${esc(w.replicas)}</td>
                    <td><button class="secondary" data-wre="${w.id}">redeploy</button>
                        <button class="secondary" data-wsc="${w.id}">scale</button>
                        ${w.kind === 'pod' ? `<button class="secondary" data-wpd="${w.id}">delete pod</button>` : ''}</td></tr>`;
            }
            d += '</table>';
            document.getElementById('cl-detail').innerHTML = d;
            document.querySelectorAll('[data-wre]').forEach(b => b.addEventListener('click', async () => {
                await post(`/rancher/workloads/${b.dataset.wre}/redeploy`);
            }));
            document.querySelectorAll('[data-wsc]').forEach(b => b.addEventListener('click', async () => {
                const n = prompt('Replica count?', '2');
                if (n === null) return;
                await post(`/rancher/workloads/${b.dataset.wsc}/scale`, { replicas: parseInt(n, 10) });
            }));
            document.querySelectorAll('[data-wpd]').forEach(b => b.addEventListener('click', async () => {
                await post(`/rancher/workloads/${b.dataset.wpd}/pod-delete`);
            }));
        }));
    }

    async function loadStacksApps() {
        const eps = await get('/portainer/endpoints');
        let html = '<h3>Portainer Stacks</h3>';
        for (const e of (eps.items || [])) {
            const st = await get(`/portainer/endpoints/${e.id}/stacks`);
            for (const s of (st.stacks || [])) {
                html += `<div class="card"><div><strong>${esc(s.name)}</strong>
                    <span class="muted">on ${esc(e.name)} · ${esc(s.source)}</span></div>
                    <div>${badge(s.status)}
                    <button class="secondary" data-stk="${s.id}" data-sact="start">start</button>
                    <button class="secondary" data-stk="${s.id}" data-sact="stop">stop</button></div></div>`;
            }
        }
        const cls = await get('/rancher/clusters');
        html += '<h3>Rancher Catalog Apps</h3>';
        for (const c of (cls.items || [])) {
            const apps = await get(`/rancher/clusters/${c.id}/catalog-apps`);
            for (const a2 of (apps.apps || [])) {
                html += `<div class="card"><div><strong>${esc(a2.name)}</strong>
                    <span class="muted">${esc(c.name)} · ${esc(a2.namespace)} · chart ${esc(a2.chart_version)}</span></div>
                    <div>${badge(a2.status)}</div></div>`;
            }
        }
        content.innerHTML = html;
        content.querySelectorAll('[data-stk]').forEach(b => b.addEventListener('click', async () => {
            await post(`/portainer/stacks/${b.dataset.stk}/power`, { action: b.dataset.sact });
            loadTab('stacks');
        }));
    }

    async function loadAlerts() {
        const data = await get('/alerts');
        let html = '<table><tr><th>Manager</th><th>Category</th><th>Severity</th><th>Message</th><th>Raised</th><th>Resolved</th></tr>';
        for (const a of (data.items || [])) {
            html += `<tr><td>${esc(a.manager_type)}</td><td>${esc(a.category)}</td><td>${badge(a.severity)}</td>
                <td>${esc(a.message)}</td><td class="muted">${esc(a.raised_time || '')}</td>
                <td class="muted">${esc(a.resolved_time || '—')}</td></tr>`;
        }
        html += '</table>';
        content.innerHTML = html;
    }

    loadConnections().then(() => {
        if (!dashboard.classList.contains('hidden')) loadTab('unified');
    });
})();
