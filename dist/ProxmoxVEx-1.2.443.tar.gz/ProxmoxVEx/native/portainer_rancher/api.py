# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/native/portainer_rancher/api.py
# Project:     ProxmoxVEx
# Version:     1.2.437
# Build:       2026.09.12
# Description: Portainer + Rancher native integration REST API.
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-12
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Portainer + Rancher native integration REST API.

Mounted under ``/api/native/portainer_rancher`` (the contract's
``/native/portainer_rancher/`` prefix relative to the ``/api`` root).
All routes require authentication and the listed RBAC permission.
"""

import logging
from typing import Any, Dict, Tuple

from flask import Blueprint, g, jsonify, request

from ProxmoxVEx.utils.audit import log_audit
from ProxmoxVEx.utils.auth import require_auth

from . import alerts, inventory, models, operations, portainer, rancher, unified

log = logging.getLogger("native.portainer_rancher.api")

bp = Blueprint(
    "portainer_rancher", __name__, url_prefix="/api/native/portainer_rancher"
)


def _current_user() -> str:
    return getattr(g, "current_user", {}).get("username", "unknown")


def _paginate(rows: list, page: int, page_size: int) -> Dict[str, Any]:
    page = max(1, page)
    page_size = max(1, min(page_size, 500))
    total = len(rows)
    start = (page - 1) * page_size
    return {
        "page": page,
        "page_size": page_size,
        "total": total,
        "items": rows[start:start + page_size],
    }


def _page_args() -> Tuple[int, int]:
    return (
        request.args.get("page", 1, type=int),
        request.args.get("page_size", 50, type=int),
    )


def _error(e: Exception) -> Tuple[Any, int]:
    code = getattr(e, "code", "operation.failed")
    status = 401 if code == "auth.forbidden" else (404 if code == "notfound" else 422)
    return jsonify({"error": code, "reason": getattr(e, "message", str(e))}), status


# --- status ------------------------------------------------------------------


@bp.route("/status", methods=["GET"])
@require_auth(perms=["plugins.view"])
def get_status() -> Tuple[Any, int]:
    try:
        pc = models.list_portainer_connections()
        rc = models.list_rancher_connections()
        return jsonify({
            "module": "portainer_rancher",
            "status": "running",
            "portainer_connections": len(pc),
            "rancher_connections": len(rc),
        }), 200
    except Exception as e:
        log.error("[portainer_rancher] status error: %s", e)
        return jsonify({"module": "portainer_rancher", "status": "degraded", "error": str(e)}), 500


# --- Portainer connections -----------------------------------------------------


@bp.route("/portainer-connections", methods=["GET"])
@require_auth(perms=["portainer.connector"])
def list_portainer_connections() -> Tuple[Any, int]:
    conns = models.list_portainer_connections(request.args.get("cluster_id"))
    return jsonify({"connections": [c.to_dict() for c in conns]}), 200


@bp.route("/portainer-connections", methods=["POST"])
@require_auth(perms=["portainer.connector"])
def create_portainer_connection() -> Tuple[Any, int]:
    body = request.get_json(silent=True) or {}
    errors = models.validate_portainer_input(body)
    if errors:
        return jsonify({"error": "validation_failed", "details": errors}), 400
    try:
        c = portainer.PortainerConnector(
            base_url=body["base_url"].strip(),
            auth_type=body.get("auth_type", "api_token"),
            credential=body.get("credential") or {},
            tls_verify=bool(body.get("tls_verify", True)),
        )
        test = c.test_connection()
        conn = models.create_portainer_connection(body)
        models.update_portainer_status(
            conn.id or 0, "reachable", models._now_iso(),
            version=test.get("version", ""), edition=test.get("edition", ""),
        )
        try:
            inventory.refresh_portainer_connection(conn.id or 0)
        except portainer.PortainerError as e:
            log.warning("[portainer] initial inventory refresh failed: %s", e)
        try:
            alerts.evaluate_portainer_connection(conn.id or 0)
        except Exception as e:
            log.warning("[portainer] initial alert evaluation failed: %s", e)
        log_audit(
            _current_user(), "portainer.connection.create",
            f"Created Portainer connection {conn.id} ({conn.base_url})",
        )
        return jsonify({"id": conn.id, "status": "created"}), 201
    except portainer.PortainerError as e:
        return _error(e)


@bp.route("/portainer-connections/<int:conn_id>/test", methods=["POST"])
@require_auth(perms=["portainer.connector"])
def test_portainer_connection(conn_id: int) -> Tuple[Any, int]:
    conn = models.get_portainer_connection(conn_id)
    if not conn:
        return jsonify({"error": "notfound"}), 404
    try:
        client = portainer.build_connector(conn)
        info = client.test_connection()
        models.update_portainer_status(
            conn_id, "reachable", models._now_iso(),
            version=info.get("version", ""), edition=info.get("edition", ""), error="",
        )
        log_audit(
            _current_user(), "portainer.connection.test",
            f"Tested Portainer connection {conn_id}",
        )
        return jsonify({
            "status": "reachable",
            "version": info.get("version", ""),
            "edition": info.get("edition", ""),
        }), 200
    except portainer.PortainerError as e:
        models.update_portainer_status(
            conn_id, "unreachable", models._now_iso(), error=e.message
        )
        return _error(e)


@bp.route("/portainer-connections/<int:conn_id>/refresh", methods=["POST"])
@require_auth(perms=["portainer.connector"])
def refresh_portainer_connection(conn_id: int) -> Tuple[Any, int]:
    try:
        counts = inventory.refresh_portainer_connection(conn_id)
        alerts.evaluate_portainer_connection(conn_id)
        return jsonify({"status": "refreshed", "counts": counts}), 200
    except portainer.PortainerError as e:
        return _error(e)


@bp.route("/portainer-connections/<int:conn_id>", methods=["DELETE"])
@require_auth(perms=["portainer.connector"])
def delete_portainer_connection(conn_id: int) -> Tuple[Any, int]:
    if not models.get_portainer_connection(conn_id):
        return jsonify({"error": "notfound"}), 404
    models.delete_portainer_connection(conn_id)
    log_audit(
        _current_user(), "portainer.connection.delete",
        f"Deleted Portainer connection {conn_id}",
    )
    return jsonify({"status": "deleted"}), 200


# --- Rancher connections -------------------------------------------------------


@bp.route("/rancher-connections", methods=["GET"])
@require_auth(perms=["rancher.connector"])
def list_rancher_connections() -> Tuple[Any, int]:
    conns = models.list_rancher_connections(request.args.get("cluster_id"))
    return jsonify({"connections": [c.to_dict() for c in conns]}), 200


@bp.route("/rancher-connections", methods=["POST"])
@require_auth(perms=["rancher.connector"])
def create_rancher_connection() -> Tuple[Any, int]:
    body = request.get_json(silent=True) or {}
    errors = models.validate_rancher_input(body)
    if errors:
        return jsonify({"error": "validation_failed", "details": errors}), 400
    try:
        c = rancher.RancherConnector(
            server_url=body["server_url"].strip(),
            auth_type=body.get("auth_type", "api_token"),
            credential=body.get("credential") or {},
            tls_verify=bool(body.get("tls_verify", True)),
        )
        test = c.test_connection()
        conn = models.create_rancher_connection(body)
        models.update_rancher_status(
            conn.id or 0, "reachable", models._now_iso(),
            version=test.get("version", ""),
        )
        try:
            inventory.refresh_rancher_connection(conn.id or 0)
        except rancher.RancherError as e:
            log.warning("[rancher] initial inventory refresh failed: %s", e)
        try:
            alerts.evaluate_rancher_connection(conn.id or 0)
        except Exception as e:
            log.warning("[rancher] initial alert evaluation failed: %s", e)
        log_audit(
            _current_user(), "rancher.connection.create",
            f"Created Rancher connection {conn.id} ({conn.server_url})",
        )
        return jsonify({"id": conn.id, "status": "created"}), 201
    except rancher.RancherError as e:
        return _error(e)


@bp.route("/rancher-connections/<int:conn_id>/test", methods=["POST"])
@require_auth(perms=["rancher.connector"])
def test_rancher_connection(conn_id: int) -> Tuple[Any, int]:
    conn = models.get_rancher_connection(conn_id)
    if not conn:
        return jsonify({"error": "notfound"}), 404
    try:
        client = rancher.build_connector(conn)
        info = client.test_connection()
        models.update_rancher_status(
            conn_id, "reachable", models._now_iso(),
            version=info.get("version", ""), error="",
        )
        log_audit(
            _current_user(), "rancher.connection.test",
            f"Tested Rancher connection {conn_id}",
        )
        return jsonify({"status": "reachable", "version": info.get("version", "")}), 200
    except rancher.RancherError as e:
        models.update_rancher_status(
            conn_id, "unreachable", models._now_iso(), error=e.message
        )
        return _error(e)


@bp.route("/rancher-connections/<int:conn_id>/refresh", methods=["POST"])
@require_auth(perms=["rancher.connector"])
def refresh_rancher_connection(conn_id: int) -> Tuple[Any, int]:
    try:
        counts = inventory.refresh_rancher_connection(conn_id)
        alerts.evaluate_rancher_connection(conn_id)
        return jsonify({"status": "refreshed", "counts": counts}), 200
    except rancher.RancherError as e:
        return _error(e)


@bp.route("/rancher-connections/<int:conn_id>", methods=["DELETE"])
@require_auth(perms=["rancher.connector"])
def delete_rancher_connection(conn_id: int) -> Tuple[Any, int]:
    if not models.get_rancher_connection(conn_id):
        return jsonify({"error": "notfound"}), 404
    models.delete_rancher_connection(conn_id)
    log_audit(
        _current_user(), "rancher.connection.delete",
        f"Deleted Rancher connection {conn_id}",
    )
    return jsonify({"status": "deleted"}), 200


# --- Portainer inventory --------------------------------------------------------


@bp.route("/portainer/endpoints", methods=["GET"])
@require_auth(perms=["portainer.viewer"])
def list_portainer_endpoints() -> Tuple[Any, int]:
    conn_id = request.args.get("connection_id", type=int)
    filters: Dict[str, Any] = {}
    if request.args.get("type"):
        filters["endpoint_type"] = request.args["type"]
    rows = models.list_rows("portainer_endpoints", connection_id=conn_id, **filters)
    page, page_size = _page_args()
    return jsonify(_paginate(rows, page, page_size)), 200


@bp.route("/portainer/endpoints/<int:ep_id>/stacks", methods=["GET"])
@require_auth(perms=["portainer.viewer"])
def list_endpoint_stacks(ep_id: int) -> Tuple[Any, int]:
    if not inventory.get_endpoint(ep_id):
        return jsonify({"error": "notfound"}), 404
    return jsonify({"stacks": inventory.list_endpoint_stacks(ep_id)}), 200


@bp.route("/portainer/endpoints/<int:ep_id>/containers", methods=["GET"])
@require_auth(perms=["portainer.viewer"])
def list_endpoint_containers(ep_id: int) -> Tuple[Any, int]:
    if not inventory.get_endpoint(ep_id):
        return jsonify({"error": "notfound"}), 404
    page, page_size = _page_args()
    return jsonify(
        _paginate(inventory.list_endpoint_containers(ep_id), page, page_size)
    ), 200


@bp.route("/portainer/endpoints/<int:ep_id>/images", methods=["GET"])
@require_auth(perms=["portainer.viewer"])
def list_endpoint_images(ep_id: int) -> Tuple[Any, int]:
    if not inventory.get_endpoint(ep_id):
        return jsonify({"error": "notfound"}), 404
    return jsonify({"images": inventory.list_endpoint_images(ep_id)}), 200


# --- Rancher inventory -----------------------------------------------------------


@bp.route("/rancher/clusters", methods=["GET"])
@require_auth(perms=["rancher.viewer"])
def list_rancher_clusters() -> Tuple[Any, int]:
    conn_id = request.args.get("connection_id", type=int)
    rows = models.list_rows("rancher_clusters", connection_id=conn_id)
    page, page_size = _page_args()
    return jsonify(_paginate(rows, page, page_size)), 200


@bp.route("/rancher/clusters/<int:cluster_pk>/projects", methods=["GET"])
@require_auth(perms=["rancher.viewer"])
def list_cluster_projects(cluster_pk: int) -> Tuple[Any, int]:
    if not inventory.get_cluster(cluster_pk):
        return jsonify({"error": "notfound"}), 404
    return jsonify({"projects": inventory.list_cluster_projects(cluster_pk)}), 200


@bp.route("/rancher/clusters/<int:cluster_pk>/workloads", methods=["GET"])
@require_auth(perms=["rancher.viewer"])
def list_cluster_workloads(cluster_pk: int) -> Tuple[Any, int]:
    if not inventory.get_cluster(cluster_pk):
        return jsonify({"error": "notfound"}), 404
    rows = inventory.list_cluster_workloads(
        cluster_pk,
        namespace=request.args.get("namespace"),
        kind=request.args.get("kind"),
    )
    page, page_size = _page_args()
    return jsonify(_paginate(rows, page, page_size)), 200


@bp.route("/rancher/clusters/<int:cluster_pk>/catalog-apps", methods=["GET"])
@require_auth(perms=["rancher.viewer"])
def list_cluster_catalog_apps(cluster_pk: int) -> Tuple[Any, int]:
    if not inventory.get_cluster(cluster_pk):
        return jsonify({"error": "notfound"}), 404
    return jsonify({"apps": inventory.list_cluster_catalog_apps(cluster_pk)}), 200


# --- Unified inventory -------------------------------------------------------------


@bp.route("/unified/workloads", methods=["GET"])
@require_auth(perms=["portainer.viewer"])
def list_unified_workloads() -> Tuple[Any, int]:
    filters = {
        "source": request.args.get("source"),
        "state": request.args.get("state"),
        "kind": request.args.get("kind"),
        "name": request.args.get("name"),
        "image": request.args.get("image"),
    }
    rows = unified.list_workloads(filters)
    page, page_size = _page_args()
    return jsonify(_paginate(rows, page, page_size)), 200


@bp.route("/unified/duplicates", methods=["GET"])
@require_auth(perms=["portainer.viewer"])
def list_duplicates() -> Tuple[Any, int]:
    return jsonify({"duplicates": unified.detect_duplicate_environments()}), 200


# --- Operations --------------------------------------------------------------------


@bp.route("/portainer/containers/<int:container_pk>/power", methods=["POST"])
@require_auth(perms=["portainer.container.power"])
def container_power(container_pk: int) -> Tuple[Any, int]:
    body = request.get_json(silent=True) or {}
    action = body.get("action", "")
    if action not in models.CONTAINER_ACTIONS:
        return jsonify({
            "error": "validation_failed",
            "details": {"action": f"Must be one of {sorted(models.CONTAINER_ACTIONS)}"},
        }), 400
    try:
        result = operations.portainer_container_power(
            container_pk, action, actor=_current_user()
        )
        log_audit(
            _current_user(), "portainer.container.power",
            f"{action} on Portainer container {container_pk}",
        )
        return jsonify(result), 202
    except portainer.PortainerError as e:
        return _error(e)


@bp.route("/portainer/stacks/<int:stack_pk>/power", methods=["POST"])
@require_auth(perms=["portainer.container.power"])
def stack_power(stack_pk: int) -> Tuple[Any, int]:
    body = request.get_json(silent=True) or {}
    action = body.get("action", "")
    if action not in models.STACK_ACTIONS:
        return jsonify({
            "error": "validation_failed",
            "details": {"action": f"Must be one of {sorted(models.STACK_ACTIONS)}"},
        }), 400
    try:
        result = operations.portainer_stack_power(
            stack_pk, action, actor=_current_user()
        )
        log_audit(
            _current_user(), "portainer.stack.power",
            f"{action} on Portainer stack {stack_pk}",
        )
        return jsonify(result), 202
    except portainer.PortainerError as e:
        return _error(e)


@bp.route("/rancher/workloads/<int:workload_pk>/redeploy", methods=["POST"])
@require_auth(perms=["rancher.workload.manage"])
def workload_redeploy(workload_pk: int) -> Tuple[Any, int]:
    try:
        result = operations.rancher_workload_redeploy(
            workload_pk, actor=_current_user()
        )
        log_audit(
            _current_user(), "rancher.workload.redeploy",
            f"Redeployed Rancher workload {workload_pk}",
        )
        return jsonify(result), 202
    except rancher.RancherError as e:
        return _error(e)


@bp.route("/rancher/workloads/<int:workload_pk>/scale", methods=["POST"])
@require_auth(perms=["rancher.workload.manage"])
def workload_scale(workload_pk: int) -> Tuple[Any, int]:
    body = request.get_json(silent=True) or {}
    replicas = body.get("replicas")
    if not isinstance(replicas, int) or replicas < 0:
        return jsonify({
            "error": "validation_failed",
            "details": {"replicas": "Must be a non-negative integer"},
        }), 400
    try:
        result = operations.rancher_workload_scale(
            workload_pk, replicas, actor=_current_user()
        )
        log_audit(
            _current_user(), "rancher.workload.scale",
            f"Scaled Rancher workload {workload_pk} to {replicas}",
        )
        return jsonify(result), 202
    except rancher.RancherError as e:
        return _error(e)


@bp.route("/rancher/workloads/<int:workload_pk>/pod-delete", methods=["POST"])
@require_auth(perms=["rancher.workload.manage"])
def workload_pod_delete(workload_pk: int) -> Tuple[Any, int]:
    try:
        result = operations.rancher_pod_delete(workload_pk, actor=_current_user())
        log_audit(
            _current_user(), "rancher.pod.delete",
            f"Deleted pod for Rancher workload {workload_pk}",
        )
        return jsonify(result), 202
    except rancher.RancherError as e:
        return _error(e)


# --- Alerts -------------------------------------------------------------------------


@bp.route("/alerts", methods=["GET"])
@require_auth(perms=["portainer.viewer"])
def list_alerts() -> Tuple[Any, int]:
    resolved = request.args.get("resolved")
    rows = models.list_alerts(
        manager_type=request.args.get("manager_type"),
        category=request.args.get("category"),
        resolved=None if resolved is None else resolved.lower() in ("1", "true", "yes"),
    )
    page, page_size = _page_args()
    return jsonify(_paginate(rows, page, page_size)), 200


@bp.route("/alerts/evaluate", methods=["POST"])
@require_auth(perms=["portainer.connector"])
def evaluate_alerts() -> Tuple[Any, int]:
    return jsonify(alerts.evaluate_all()), 200


# --- Metrics --------------------------------------------------------------------------


@bp.route("/metrics", methods=["GET"])
@require_auth(perms=["portainer.viewer"])
def get_metrics() -> Tuple[Any, int]:
    db = models.get_db()
    def _count(table: str) -> int:
        row = db.query_one(f"SELECT COUNT(*) AS n FROM {table}")  # nosec: B608
        return int(row["n"]) if row else 0
    return jsonify({
        "portainer_endpoints": _count("portainer_endpoints"),
        "portainer_containers": _count("portainer_containers"),
        "portainer_stacks": _count("portainer_stacks"),
        "rancher_clusters": _count("rancher_clusters"),
        "rancher_workloads": _count("rancher_workloads"),
        "unified_workloads": _count("unified_workloads"),
        "open_alerts": int(
            (db.query_one(
                "SELECT COUNT(*) AS n FROM portainer_rancher_alerts "
                "WHERE resolved_time IS NULL"
            ) or {"n": 0})["n"]
        ),
    }), 200


# --- Resource links ---------------------------------------------------------------------


@bp.route("/resource-links", methods=["GET"])
@require_auth(perms=["portainer.viewer"])
def list_resource_links() -> Tuple[Any, int]:
    return jsonify({
        "links": models.list_resource_links(request.args.get("local_type"))
    }), 200


@bp.route("/resource-links", methods=["POST"])
@require_auth(perms=["portainer.connector"])
def create_resource_link() -> Tuple[Any, int]:
    body = request.get_json(silent=True) or {}
    required = ("local_type", "local_id", "remote_type", "remote_id")
    missing = [k for k in required if not body.get(k)]
    if missing:
        return jsonify({
            "error": "validation_failed",
            "details": dict.fromkeys(missing, "Required"),
        }), 400
    link_id = models.create_resource_link(
        body["local_type"], str(body["local_id"]),
        body["remote_type"], str(body["remote_id"]),
        link_type="manual",
        confidence=float(body.get("match_confidence", 1.0)),
    )
    log_audit(
        _current_user(), "portainer_rancher.link.create",
        f"Linked {body['local_type']}:{body['local_id']} → "
        f"{body['remote_type']}:{body['remote_id']}",
    )
    return jsonify({"id": link_id, "status": "created"}), 201


@bp.route("/resource-links/<int:link_id>", methods=["DELETE"])
@require_auth(perms=["portainer.connector"])
def delete_resource_link(link_id: int) -> Tuple[Any, int]:
    models.delete_resource_link(link_id)
    return jsonify({"status": "deleted"}), 200


@bp.route("/operations", methods=["GET"])
@require_auth(perms=["portainer.viewer"])
def list_operations() -> Tuple[Any, int]:
    return jsonify({
        "operations": models.list_operations(
            request.args.get("limit", 50, type=int)
        )
    }), 200
