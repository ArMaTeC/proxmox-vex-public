# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/native/portainer_rancher/rancher.py
# Project:     ProxmoxVEx
# Version:     1.2.437
# Build:       2026.09.12
# Description: Rancher v2.x/v3 REST API client.
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-12
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Rancher v2.x/v3 REST API client.

Auth: ``Authorization: Bearer <api_token>`` (API key / bearer token).
Base URL: ``https://<host>/v3``.

A ``mock://`` server URL activates the deterministic in-memory
:class:`MockRancherSession` used by unit/contract tests.
"""

import logging
from typing import Any, Dict, List, Optional
from urllib.parse import urlparse

import requests

from . import models

log = logging.getLogger("native.portainer_rancher.rancher")

MOCK_SCHEME = "mock://"
DEFAULT_TIMEOUT = 20

ERROR_CODES = {
    "connection.unreachable": "Rancher server unreachable",
    "connection.timeout": "Rancher API unreachable (timeout)",
    "auth.forbidden": "Invalid token or insufficient scope",
    "tls.verify": "TLS verification failed",
    "notfound": "Object not found on Rancher",
    "cluster.error": "Cluster is in error state",
    "operation.failed": "Remote operation failed",
}


def _map_request_error(e: Exception) -> "RancherError":
    if isinstance(e, requests.exceptions.SSLError):
        return RancherError("tls.verify", str(e))
    if isinstance(e, requests.exceptions.ConnectTimeout):
        return RancherError("connection.timeout", str(e))
    if isinstance(e, requests.exceptions.ConnectionError):
        return RancherError("connection.unreachable", str(e))
    if isinstance(e, requests.exceptions.Timeout):
        return RancherError("connection.timeout", str(e))
    return RancherError("operation.failed", str(e))


class RancherError(Exception):
    """Connector error with a stable machine-readable code."""

    def __init__(self, code: str, message: str = ""):
        self.code = code
        self.message = message or ERROR_CODES.get(code, code)
        super().__init__(self.message)


def _collection(raw: Any) -> List[Dict[str, Any]]:
    """Rancher v3 list responses wrap items in ``data``."""
    if isinstance(raw, dict):
        return raw.get("data") or []
    return raw or []


class RancherConnector:
    """Rancher REST client with bearer-token auth and ``mock://`` transport."""

    def __init__(
        self,
        server_url: str,
        auth_type: str = "api_token",
        credential: Optional[Dict[str, Any]] = None,
        tls_verify: bool = True,
        timeout: int = DEFAULT_TIMEOUT,
    ):
        self.raw_base_url = (server_url or "").rstrip("/")
        self.auth_type = auth_type
        self.credential = credential or {}
        self.tls_verify = tls_verify
        self.timeout = timeout
        self._session = requests.Session()

    def _use_mock(self) -> bool:
        return self.raw_base_url.startswith(MOCK_SCHEME)

    def _api_base(self) -> str:
        return f"{self.raw_base_url}/v3"

    def _headers(self) -> Dict[str, str]:
        token = self.credential.get("token", "")
        return {"Authorization": f"Bearer {token}"} if token else {}

    def _request(self, method: str, path: str, **kwargs) -> Any:
        if self._use_mock():
            return MockRancherSession.request(self, method, path, **kwargs)
        url = f"{self._api_base()}{path}"
        try:
            resp = self._session.request(
                method,
                url,
                headers={**self._headers(), **kwargs.pop("headers", {})},
                verify=self.tls_verify,
                timeout=self.timeout,
                **kwargs,
            )
        except Exception as e:
            raise _map_request_error(e) from e
        if resp.status_code in (401, 403):
            raise RancherError("auth.forbidden")
        if resp.status_code == 404:
            raise RancherError("notfound", path)
        if resp.status_code >= 400:
            raise RancherError(
                "operation.failed", f"HTTP {resp.status_code}: {resp.text[:200]}"
            )
        if resp.status_code == 204 or not resp.content:
            return {}
        try:
            return resp.json()
        except ValueError:
            return {"raw": resp.text}

    def _get(self, path: str, params: Optional[Dict[str, Any]] = None) -> Any:
        return self._request("GET", path, params=params)

    def _post(self, path: str, body: Optional[Dict[str, Any]] = None,
              params: Optional[Dict[str, Any]] = None) -> Any:
        return self._request("POST", path, json=body or {}, params=params)

    def _put(self, path: str, body: Dict[str, Any]) -> Any:
        return self._request("PUT", path, json=body)

    # -- server --------------------------------------------------------------

    def test_connection(self) -> Dict[str, Any]:
        """Validate token with an authenticated read; report server version."""
        version = ""
        try:
            setting = self._get("/settings/server-version")
            if isinstance(setting, dict):
                version = setting.get("value", "")
        except RancherError as e:
            if e.code == "auth.forbidden":
                raise
            log.debug("[rancher] server-version setting read failed: %s", e)
        # Authenticated read proving the token works.
        clusters = _collection(self._get("/clusters", params={"limit": 1}))
        return {"version": version, "cluster_count_sample": len(clusters)}

    # -- inventory -----------------------------------------------------------

    def list_clusters(self) -> List[Dict[str, Any]]:
        """GET /v3/clusters → normalized cluster dicts."""
        out = []
        for c in _collection(self._get("/clusters")):
            version = c.get("version") or {}
            out.append({
                "cluster_id": c.get("id", ""),
                "name": c.get("name", ""),
                "kubernetes_version": version.get("gitVersion", "")
                if isinstance(version, dict) else str(version or ""),
                "provider": c.get("provider") or c.get("driver", ""),
                "state": (c.get("state") or "unknown").lower(),
                "state_message": c.get("transitioningMessage", ""),
                "api_endpoint": c.get("apiEndpoint", ""),
                "node_count": int(c.get("nodeCount") or 0),
            })
        return out

    def get_cluster(self, cluster_id: str) -> Dict[str, Any]:
        c = self._get(f"/clusters/{cluster_id}")
        version = c.get("version") or {}
        return {
            "cluster_id": c.get("id", cluster_id),
            "name": c.get("name", ""),
            "kubernetes_version": version.get("gitVersion", "")
            if isinstance(version, dict) else str(version or ""),
            "provider": c.get("provider") or c.get("driver", ""),
            "state": (c.get("state") or "unknown").lower(),
            "state_message": c.get("transitioningMessage", ""),
            "api_endpoint": c.get("apiEndpoint", ""),
            "node_count": int(c.get("nodeCount") or 0),
        }

    def list_projects(self, cluster_id: Optional[str] = None) -> List[Dict[str, Any]]:
        params = {"clusterId": cluster_id} if cluster_id else None
        out = []
        for p in _collection(self._get("/projects", params=params)):
            out.append({
                "project_id": p.get("id", ""),
                "cluster_id": p.get("clusterId", ""),
                "name": p.get("name", ""),
            })
        return out

    def list_namespaces(self, project_id: str) -> List[str]:
        """GET /v3/project/{project_id}/namespaces → list of namespace names."""
        return [
            n.get("name") or n.get("id", "")
            for n in _collection(self._get(f"/project/{project_id}/namespaces"))
        ]

    def list_workloads(self, project_id: str) -> List[Dict[str, Any]]:
        """GET /v3/project/{project_id}/workloads → normalized workloads."""
        out = []
        for w in _collection(self._get(f"/project/{project_id}/workloads")):
            out.append(self._parse_workload(w))
        return out

    @staticmethod
    def _parse_workload(w: Dict[str, Any]) -> Dict[str, Any]:
        kind = (w.get("type") or w.get("workloadType") or "unknown").lower()
        containers = w.get("containers") or []
        image = containers[0].get("image", "") if containers else w.get("image", "")
        state = (w.get("state") or "unknown").lower()
        scale = int(w.get("scale") or w.get("replicas") or 0)
        ready = 0
        for key in ("availableReplicas", "readyReplicas", "numberReady"):
            if w.get(key) is not None:
                ready = int(w.get(key) or 0)
                break
        restarts = int(w.get("restartCount") or 0)
        health = "healthy" if state in ("active", "running") else (
            "unhealthy" if state in ("error", "unavailable", "updating") else "unknown"
        )
        return {
            "workload_id": w.get("id", ""),
            "project_id": w.get("projectId", ""),
            "name": w.get("name", ""),
            "kind": kind if kind in models.WORKLOAD_KINDS else kind or "unknown",
            "namespace": w.get("namespaceId") or w.get("namespace", ""),
            "state": "running" if state == "active" else state,
            "image": image,
            "replicas": scale,
            "ready_replicas": ready,
            "restart_count": restarts,
            "health": health,
        }

    def list_catalog_apps(self, project_id: str) -> List[Dict[str, Any]]:
        """GET /v3/project/{project_id}/apps → installed catalog/helm apps."""
        out = []
        for a in _collection(self._get(f"/project/{project_id}/apps")):
            out.append({
                "app_id": a.get("id", ""),
                "name": a.get("name", ""),
                "namespace": a.get("targetNamespace", ""),
                "chart_version": a.get("externalId", "").split("version=")[-1]
                if a.get("externalId") else a.get("chartVersion", ""),
                "app_version": a.get("appVersion", ""),
                "status": (a.get("state") or "unknown").lower(),
            })
        return out

    # -- operations ----------------------------------------------------------

    def redeploy_workload(self, project_id: str, workload_id: str) -> Dict[str, Any]:
        """POST …/workloads/{id}?action=redeploy."""
        self._post(
            f"/project/{project_id}/workloads/{workload_id}",
            params={"action": "redeploy"},
        )
        return {"workload_id": workload_id, "action": "redeploy", "done": True}

    def scale_workload(
        self, project_id: str, workload_id: str, replicas: int
    ) -> Dict[str, Any]:
        """PUT …/workloads/{id} with the new scale."""
        self._put(
            f"/project/{project_id}/workloads/{workload_id}",
            {"scale": int(replicas)},
        )
        return {
            "workload_id": workload_id,
            "action": "scale",
            "replicas": int(replicas),
            "done": True,
        }

    def delete_pod(self, cluster_id: str, namespace: str, pod_id: str) -> Dict[str, Any]:
        """DELETE /v3/cluster/{cluster_id}/pods/{namespace}:{pod}."""
        self._request(
            "DELETE", f"/cluster/{cluster_id}/pods/{namespace}:{pod_id}"
        )
        return {"pod_id": pod_id, "action": "delete", "done": True}


def build_connector(conn: models.RancherConnection) -> RancherConnector:
    return RancherConnector(
        server_url=conn.server_url,
        auth_type=conn.auth_type,
        credential=models.get_rancher_credential(conn.id or 0),
        tls_verify=conn.tls_verify,
    )


# ---------------------------------------------------------------------------
# Deterministic mock transport
# ---------------------------------------------------------------------------


class MockRancherSession:
    """In-memory Rancher server used when server_url is ``mock://``.

    ``mock://bad`` simulates an invalid/revoked token (401 on every call).
    """

    _CLUSTERS = [
        {
            "id": "c-mock1",
            "name": "prod-k8s",
            "state": "active",
            "transitioningMessage": "",
            "version": {"gitVersion": "v1.28.4"},
            "provider": "rke2",
            "apiEndpoint": "https://10.0.0.50:6443/k8s/clusters/c-mock1",
            "nodeCount": 3,
        },
        {
            "id": "c-mock2",
            "name": "edge-k8s",
            "state": "error",
            "transitioningMessage": "waiting on node registration",
            "version": {"gitVersion": "v1.27.9"},
            "provider": "k3s",
            "apiEndpoint": "https://10.0.0.60:6443",
            "nodeCount": 1,
        },
    ]

    _PROJECTS = [
        {"id": "c-mock1:p-mock1", "clusterId": "c-mock1", "name": "Default"},
        {"id": "c-mock2:p-mock2", "clusterId": "c-mock2", "name": "System"},
    ]

    _WORKLOADS = {
        "c-mock1:p-mock1": [
            {
                "id": "deployment:default:web",
                "projectId": "c-mock1:p-mock1",
                "name": "web",
                "type": "deployment",
                "namespaceId": "default",
                "state": "active",
                "scale": 2,
                "availableReplicas": 2,
                "containers": [{"image": "nginx:1.25"}],
            },
            {
                "id": "pod:default:flaky-0",
                "projectId": "c-mock1:p-mock1",
                "name": "flaky-0",
                "type": "pod",
                "namespaceId": "default",
                "state": "error",
                "scale": 1,
                "restartCount": 15,
                "containers": [{"image": "app:latest"}],
            },
        ],
        "c-mock2:p-mock2": [
            {
                "id": "daemonset:kube-system:agent",
                "projectId": "c-mock2:p-mock2",
                "name": "agent",
                "type": "daemonset",
                "namespaceId": "kube-system",
                "state": "active",
                "scale": 1,
                "numberReady": 1,
                "containers": [{"image": "agent:v1"}],
            },
        ],
    }

    _APPS = {
        "c-mock1:p-mock1": [
            {
                "id": "c-mock1.monitoring",
                "name": "monitoring",
                "targetNamespace": "monitoring",
                "externalId": "catalog://?chart=monitoring&version=102.0.0",
                "appVersion": "9.4.0",
                "state": "active",
            }
        ],
    }

    @staticmethod
    def _check_auth(connector: "RancherConnector") -> None:
        host = urlparse(connector.raw_base_url).hostname or ""
        if "bad" in host or connector.credential.get("token") == "bad":
            raise RancherError("auth.forbidden", "mock invalid token")

    @staticmethod
    def request(connector: "RancherConnector", method: str, path: str, **kwargs) -> Any:
        MockRancherSession._check_auth(connector)

        if path == "/settings/server-version":
            return {"value": "v2.8.3"}

        if path == "/clusters":
            return {"data": list(MockRancherSession._CLUSTERS)}

        if path.startswith("/clusters/"):
            cid = path.split("/", 2)[2]
            for c in MockRancherSession._CLUSTERS:
                if c["id"] == cid:
                    return c
            raise RancherError("notfound", path)

        if path == "/projects":
            params = kwargs.get("params") or {}
            filter_cid = params.get("clusterId")
            data = MockRancherSession._PROJECTS
            if filter_cid:
                data = [p for p in data if p["clusterId"] == filter_cid]
            return {"data": list(data)}

        if path.startswith("/project/"):
            parts = path.split("/")
            project_id = parts[2]
            tail = "/".join(parts[3:])
            if tail == "namespaces":
                return {"data": [{"name": "default"}, {"name": "kube-system"}]}
            if tail == "workloads":
                return {
                    "data": list(
                        MockRancherSession._WORKLOADS.get(project_id, [])
                    )
                }
            if tail == "apps":
                return {
                    "data": list(MockRancherSession._APPS.get(project_id, []))
                }
            if tail.startswith("workloads/"):
                params = kwargs.get("params") or {}
                if method == "POST" and params.get("action") == "redeploy":
                    return {}
                if method == "PUT":
                    return {}
                raise RancherError("notfound", path)

        if path.startswith("/cluster/") and "/pods/" in path and method == "DELETE":
            return {}

        raise RancherError("notfound", path)
