# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/native/portainer_rancher/alerts.py
# Project:     ProxmoxVEx
# Version:     1.2.437
# Build:       2026.09.12
# Description: Manager alert evaluation (US6 / FR-012).
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-12
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Manager alert evaluation (US6 / FR-012).

Conditions: crash-looping/unhealthy containers, down endpoints, missed
edge-agent heartbeats, Rancher cluster error / stuck-provisioning states and
unreachable managers. Conditions that clear resolve their alerts
automatically.
"""

import logging
from datetime import datetime, timezone
from typing import Any, Dict

from . import models

log = logging.getLogger("native.portainer_rancher.alerts")

# A container is considered crash-looping once it restarts this often.
RESTART_COUNT_THRESHOLD = 5
# Edge agent heartbeat staleness before we flag it (seconds).
HEARTBEAT_STALE_SECONDS = 600


def _set_alert(
    manager: str,
    conn_id: int,
    active: bool,
    category: str,
    message: str,
    severity: str = "warning",
    entity_type: str = "",
    entity_id: str = "",
) -> bool:
    if active:
        models.raise_alert(
            manager, category, conn_id, message, severity, entity_type, entity_id
        )
        return True
    models.resolve_alert(manager, category, conn_id, entity_id)
    return False


def _heartbeat_stale(last_heartbeat: str) -> bool:
    if not last_heartbeat:
        return True
    try:
        hb = datetime.fromisoformat(str(last_heartbeat).replace("Z", "+00:00"))
    except ValueError:
        return True
    return (datetime.now(timezone.utc) - hb).total_seconds() > HEARTBEAT_STALE_SECONDS


def evaluate_portainer_connection(conn_id: int) -> Dict[str, int]:
    """Evaluate all Portainer alert conditions for one connection."""
    raised = 0
    conn = models.get_portainer_connection(conn_id)
    if not conn:
        return {"raised": 0}

    # Manager unreachable.
    raised += _set_alert(
        "portainer", conn_id,
        conn.connectivity_status == "unreachable",
        "manager_unreachable",
        f"Portainer '{conn.display_name}' unreachable: {conn.last_error}",
        severity="critical", entity_type="manager", entity_id=str(conn_id),
    )

    # Endpoint down / missed edge heartbeats.
    for ep in models.list_rows("portainer_endpoints", connection_id=conn_id):
        down = ep.get("status") == "down"
        raised += _set_alert(
            "portainer", conn_id, down,
            "endpoint_down",
            f"Portainer endpoint '{ep['name']}' is down",
            severity="critical", entity_type="endpoint", entity_id=str(ep["id"]),
        )
        if ep.get("endpoint_type") == "edge_agent":
            stale = _heartbeat_stale(ep.get("last_heartbeat") or "")
            raised += _set_alert(
                "portainer", conn_id, stale,
                "heartbeat_missed",
                f"Edge agent '{ep['name']}' missed heartbeats "
                f"(last: {ep.get('last_heartbeat') or 'never'})",
                severity="warning", entity_type="endpoint", entity_id=str(ep["id"]),
            )

    # Crash-looping / unhealthy containers.
    for c in models.list_rows("portainer_containers", connection_id=conn_id):
        crash = int(c.get("restart_count") or 0) >= RESTART_COUNT_THRESHOLD
        unhealthy = c.get("health") == "unhealthy" or c.get("state") == "dead"
        active = crash or unhealthy
        reason = "crash-looping" if crash else "unhealthy"
        raised += _set_alert(
            "portainer", conn_id, active,
            "container_health",
            f"Container '{c['name']}' is {reason} "
            f"(restarts={c.get('restart_count', 0)})",
            severity="warning" if crash else "critical",
            entity_type="container", entity_id=str(c["id"]),
        )
    return {"raised": int(raised)}


def evaluate_rancher_connection(conn_id: int) -> Dict[str, int]:
    """Evaluate all Rancher alert conditions for one connection."""
    raised = 0
    conn = models.get_rancher_connection(conn_id)
    if not conn:
        return {"raised": 0}

    raised += _set_alert(
        "rancher", conn_id,
        conn.connectivity_status == "unreachable",
        "manager_unreachable",
        f"Rancher '{conn.display_name}' unreachable: {conn.last_error}",
        severity="critical", entity_type="manager", entity_id=str(conn_id),
    )

    for cl in models.list_rows("rancher_clusters", connection_id=conn_id):
        state = cl.get("state") or "unknown"
        err = state == "error"
        raised += _set_alert(
            "rancher", conn_id, err,
            "cluster_error",
            f"Rancher cluster '{cl['name']}' error: {cl.get('state_message') or 'no message'}",
            severity="critical", entity_type="cluster", entity_id=str(cl["id"]),
        )
        # "provisioning" with a non-empty transitioning message is treated as
        # potentially stuck so operators see it instead of a silent pending.
        stuck = state == "provisioning" and bool(cl.get("state_message"))
        raised += _set_alert(
            "rancher", conn_id, stuck,
            "cluster_provisioning_stuck",
            f"Rancher cluster '{cl['name']}' stuck provisioning: "
            f"{cl.get('state_message')}",
            severity="warning", entity_type="cluster", entity_id=str(cl["id"]),
        )

    # Crash-looping workloads (e.g. pods repeatedly restarting).
    for w in models.list_rows("rancher_workloads", connection_id=conn_id):
        crash = int(w.get("restart_count") or 0) >= RESTART_COUNT_THRESHOLD
        unhealthy = w.get("health") == "unhealthy"
        active = crash or unhealthy
        raised += _set_alert(
            "rancher", conn_id, active,
            "container_health",
            f"Workload '{w['namespace']}/{w['name']}' is "
            f"{'crash-looping' if crash else 'unhealthy'} "
            f"(restarts={w.get('restart_count', 0)})",
            severity="warning" if crash else "critical",
            entity_type="workload", entity_id=str(w["id"]),
        )
    return {"raised": int(raised)}


def evaluate_all() -> Dict[str, Any]:
    results: Dict[str, Any] = {"portainer": {}, "rancher": {}}
    for conn in models.list_portainer_connections():
        try:
            results["portainer"][conn.id] = evaluate_portainer_connection(conn.id or 0)
        except Exception as e:
            log.warning("[portainer] alert evaluation failed for %s: %s", conn.id, e)
    for rconn in models.list_rancher_connections():
        try:
            results["rancher"][rconn.id] = evaluate_rancher_connection(rconn.id or 0)
        except Exception as e:
            log.warning("[rancher] alert evaluation failed for %s: %s", rconn.id, e)
    return results
