# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/native/pfsense/__init__.py
# Project:     ProxmoxVEx
# Version:     1.2.437
# Build:       2026.09.12
# Description: pfSense Manager — ProxmoxVEx Plugin
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-12
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""
pfSense Manager — ProxmoxVEx Plugin
Monitor and configure pfSense firewalls from ProxmoxVEx.

Talks to pfSense FauxAPI (/fauxapi/v1/?action=<action>) using the
``fauxapi-auth`` header over HTTPS. HA-aware: can target both peer nodes
and routes writes to the CARP master; every route is gated by the
``pfsense.<domain>`` permission family via fwkit.authz.

Feature scope (spec 003 — pfSense/OPNsense parity):
  - Overview: HA role, gateways, VPN peers, certs, services, divergence
  - Interfaces / routes / neighbors, firewall logs
  - Rules / Aliases / NAT (port-forward, outbound, 1:1) CRUD + reorder
  - DHCP scopes + static mappings, Unbound host/domain overrides
  - VPN provisioning: WireGuard peers, IPsec p1/p2, OpenVPN instances
  - Platform ops: apply, config backup/restore, reboot, firmware check
  - Audit log of every write + denied attempt
  - Prometheus /metrics exporter
"""

import json
import logging
import os
import sys
from typing import Any, Callable

PLUGIN_ID = "pfsense"
PLUGIN_NAME = "pfSense Manager"
PLUGIN_DIR = os.path.dirname(os.path.abspath(__file__))
STATE_DIR = os.path.join(PLUGIN_DIR, "state")
CONFIG_PATH = os.path.join(PLUGIN_DIR, "config.json")
HOSTS_KEY = "pfsense_hosts"
SECRET_KEYS = ["api_secret"]

if PLUGIN_DIR not in sys.path:
    sys.path.insert(0, PLUGIN_DIR)

from pfsense_src._fwkit import ensure_fwkit_importable  # noqa: E402
from pfsense_src.client import PFsenseHost  # noqa: E402

ensure_fwkit_importable()

register_native_route: Callable[[Any, Any, Any], Any] | None = None
try:  # pragma: no cover - optional framework deps
    from flask import Response, send_file

    from ProxmoxVEx.native.registry import register_native_route as _register_native_route

    register_native_route = _register_native_route
except ImportError:  # pragma: no cover
    pass

from ProxmoxVEx.native.fwkit.audit import AuditLog  # noqa: E402
from ProxmoxVEx.native.fwkit.authz import (  # noqa: E402
    current_actor,
    effective_permissions,
    require_ops_stepup,
    require_perm,
)
from ProxmoxVEx.native.fwkit.payloads import audit_log_path  # noqa: E402

log = logging.getLogger(f"native.{PLUGIN_ID}")


def _load_config():
    """Load plugin config from CONFIG_PATH (JSON). Returns dict with defaults."""
    os.makedirs(STATE_DIR, exist_ok=True)
    if not os.path.exists(CONFIG_PATH):
        return {HOSTS_KEY: [], "poll_interval": 30, "read_only": False}
    try:
        with open(CONFIG_PATH, encoding="utf-8") as f:
            return json.load(f)
    except Exception as e:
        log.error("Failed to load config: %s", e)
        return {HOSTS_KEY: [], "poll_interval": 30, "read_only": False}


def _audit() -> AuditLog:
    return AuditLog(audit_log_path(PLUGIN_DIR))


def _require(domain: str, host: str = ""):
    """RBAC gate — returns the (status, payload) denial or None."""
    return require_perm(PLUGIN_ID, domain, audit=_audit(), host=host)


def _host_lookup_key(h):
    return str(h.get("url", h.get("name", ""))).rstrip("/")


def _host_from_dict(h: dict):
    return PFsenseHost(
        name=str(h.get("name", "pfsense")),
        url=str(h.get("url", "")),
        api_key=str(h.get("api_key", "")),
        api_secret=str(h.get("api_secret", "")),
        verify_tls=bool(h.get("verify_tls", True)),
        ca_bundle_path=h.get("ca_bundle_path") or None,
    )


def _is_cluster_mode(cfg: dict) -> bool:
    """Cluster mode: ≥2 hosts AND cluster_mode != off (auto default)."""
    hosts = cfg.get(HOSTS_KEY) or []
    if len(hosts) < 2:
        return False
    mode = str(cfg.get("cluster_mode", "auto")).lower()
    if mode == "off":
        return False
    return mode in ("auto", "cluster", "ha") or bool(cfg.get("monitor_both_nodes", False))


# Master-resolution cache (10s TTL — same policy as the OPNsense plugin).
_master_cache: dict = {"side": None, "ts": 0.0}
_MASTER_TTL_S = 10


def _resolved_master_side(host_a, host_b, name_a: str, name_b: str):
    import time

    from pfsense_src.client import PFsenseClient, PFsenseClusterClient

    now = time.monotonic()
    if _master_cache["side"] is not None and (now - _master_cache["ts"]) < _MASTER_TTL_S:
        return _master_cache["side"]
    cluster = PFsenseClusterClient(
        PFsenseClient(host_a),
        PFsenseClient(host_b),
        name_a=name_a,
        name_b=name_b,
    )
    try:
        side = cluster.master_side()
    except Exception as e:  # noqa: BLE001
        log.warning("master resolution failed (%s); defaulting to A", e)
        side = "a"
    _master_cache["side"] = side
    _master_cache["ts"] = now
    return side


def _first_host_from_config():
    """Target host for reads — the CARP master in cluster mode."""
    cfg = _load_config()
    hosts = cfg.get(HOSTS_KEY) or []
    if not hosts:
        return None
    if not _is_cluster_mode(cfg):
        return _host_from_dict(hosts[0])
    h_a, h_b = _host_from_dict(hosts[0]), _host_from_dict(hosts[1])
    side = _resolved_master_side(h_a, h_b, str(hosts[0].get("name", "NODOA")), str(hosts[1].get("name", "NODOB")))
    return h_a if side == "a" else h_b


def _write_targets() -> tuple[Any, Any | None] | None:
    """(write_host, peer_host) — writes always go to the CARP master and the
    peer client is the backup (for post-write verify). Never the standby."""
    cfg = _load_config()
    hosts = cfg.get(HOSTS_KEY) or []
    if not hosts:
        return None
    if not _is_cluster_mode(cfg):
        return _host_from_dict(hosts[0]), None
    h_a, h_b = _host_from_dict(hosts[0]), _host_from_dict(hosts[1])
    side = _resolved_master_side(h_a, h_b, str(hosts[0].get("name", "NODOA")), str(hosts[1].get("name", "NODOB")))
    return (h_a, h_b) if side == "a" else (h_b, h_a)


def _cluster_hosts_from_config():
    cfg = _load_config()
    if not _is_cluster_mode(cfg):
        return None
    hosts = cfg[HOSTS_KEY]
    return (
        _host_from_dict(hosts[0]),
        _host_from_dict(hosts[1]),
        str(hosts[0].get("name", "NODOA")),
        str(hosts[1].get("name", "NODOB")),
    )


def _unconfigured_response():
    from flask import jsonify

    return jsonify({"ok": False, "error": "unconfigured", "detail": f"No {HOSTS_KEY} in config.json"}), 400


def _respond(result):
    """(status, payload) tuple → Flask response."""
    from flask import jsonify

    status, payload = result
    return jsonify(payload), status


def _read_only_blocked() -> tuple[int, dict] | None:
    if _load_config().get("read_only", False):
        return 403, {"ok": False, "error": "read_only", "detail": "plugin config has read_only=true"}
    return None


# ---------------------------------------------------------------------------
# Handlers
# ---------------------------------------------------------------------------


def _h_health():
    cfg = _load_config()
    return {
        "plugin": PLUGIN_ID,
        "version": "1.0.0",
        "configured": bool(cfg.get(HOSTS_KEY)),
        "read_only": cfg.get("read_only", False),
        "cluster_mode": _is_cluster_mode(cfg),
        "hosts_configured": len(cfg.get(HOSTS_KEY) or []),
        "permissions": effective_permissions(PLUGIN_ID),
    }


def _h_ui():
    return send_file(os.path.join(PLUGIN_DIR, "pfsense.html"), mimetype="text/html")


def _h_overview():
    denied = _require("view")
    if denied:
        return _respond(denied)
    from pfsense_src.routes.overview import build_overview_payload, build_overview_payload_cluster

    cluster = _cluster_hosts_from_config()
    if cluster is not None:
        host_a, host_b, name_a, name_b = cluster
        return _respond(build_overview_payload_cluster(host_a, host_b, name_a, name_b))
    host = _first_host_from_config()
    if host is None:
        return _unconfigured_response()
    return _respond(build_overview_payload(host))


def _h_cluster():
    denied = _require("view")
    if denied:
        return _respond(denied)
    from flask import jsonify
    from pfsense_src.routes.overview import build_overview_payload_cluster

    cfg = _load_config()
    hosts = cfg.get(HOSTS_KEY) or []
    if len(hosts) < 2:
        return jsonify({
            "ok": False, "cluster": False, "error": "single_host",
            "detail": "Cluster endpoint requires ≥2 pfsense_hosts.",
        }), 400
    host_a, host_b = _host_from_dict(hosts[0]), _host_from_dict(hosts[1])
    return _respond(build_overview_payload_cluster(
        host_a, host_b, str(hosts[0].get("name", "NODOA")), str(hosts[1].get("name", "NODOB")),
    ))


def _h_network():
    denied = _require("view")
    if denied:
        return _respond(denied)
    from pfsense_src.routes.network import build_network_payload

    host = _first_host_from_config()
    if host is None:
        return _unconfigured_response()
    return _respond(build_network_payload(host))


def _h_logs():
    denied = _require("view")
    if denied:
        return _respond(denied)
    from flask import request
    from pfsense_src.routes.logs import build_logs_payload

    host = _first_host_from_config()
    if host is None:
        return _unconfigured_response()
    return _respond(build_logs_payload(host, limit=request.args.get("limit", 100)))


def _domain_list(builder, domain: str = "view"):
    """Shared GET path for domain routes."""
    denied = _require(domain)
    if denied:
        return _respond(denied)
    host = _first_host_from_config()
    if host is None:
        return _unconfigured_response()
    return _respond(builder(host))


def _domain_action(builder, domain: str):
    """Shared POST path: RBAC → read_only → host → builder(host, dir, body, peer, actor)."""
    denied = _require(domain)
    if denied:
        return _respond(denied)
    blocked = _read_only_blocked()
    if blocked:
        return _respond(blocked)
    targets = _write_targets()
    if targets is None:
        return _unconfigured_response()
    host, peer = targets
    from flask import request

    body = request.get_json(silent=True) or {}
    return _respond(builder(host, PLUGIN_DIR, body, peer_host=peer, actor=current_actor()))


def _h_rules():
    from flask import request
    from pfsense_src.routes.rules import build_rules_action_payload, build_rules_list_payload

    if request.method == "GET":
        return _domain_list(build_rules_list_payload)
    return _domain_action(build_rules_action_payload, "rules")


def _h_aliases():
    from flask import request
    from pfsense_src.routes.aliases import build_aliases_action_payload, build_aliases_list_payload

    if request.method == "GET":
        return _domain_list(build_aliases_list_payload)
    return _domain_action(build_aliases_action_payload, "aliases")


def _h_nat():
    from flask import request
    from pfsense_src.routes.nat import build_nat_action_payload, build_nat_list_payload

    if request.method == "GET":
        return _domain_list(build_nat_list_payload)
    return _domain_action(build_nat_action_payload, "nat")


def _h_dhcp():
    from flask import request
    from pfsense_src.routes.dhcp import build_dhcp_action_payload, build_dhcp_list_payload

    if request.method == "GET":
        return _domain_list(build_dhcp_list_payload)
    return _domain_action(build_dhcp_action_payload, "dhcp")


def _h_dns():
    from flask import request
    from pfsense_src.routes.dns import build_dns_action_payload, build_dns_list_payload

    if request.method == "GET":
        return _domain_list(build_dns_list_payload)
    return _domain_action(build_dns_action_payload, "dns")


def _h_vpn():
    from flask import request
    from pfsense_src.routes.vpn import build_vpn_action_payload, build_vpn_list_payload

    if request.method == "GET":
        return _domain_list(build_vpn_list_payload)
    return _domain_action(build_vpn_action_payload, "vpn")


def _h_services():
    from flask import request
    from pfsense_src.routes.services import build_services_action_payload, build_services_list_payload

    if request.method == "GET":
        return _domain_list(build_services_list_payload)
    denied = _require("services")
    if denied:
        return _respond(denied)
    blocked = _read_only_blocked()
    if blocked:
        return _respond(blocked)
    host = _first_host_from_config()
    if host is None:
        return _unconfigured_response()
    body = request.get_json(silent=True) or {}
    return _respond(build_services_action_payload(host, PLUGIN_DIR, body, actor=current_actor()))


def _h_ops():
    """Platform ops — `*.ops` permission; destructive actions also require
    step-up MFA (firewall.ops category) and a hostname confirm token."""
    denied = _require("ops")
    if denied:
        return _respond(denied)
    blocked = _read_only_blocked()
    if blocked:
        return _respond(blocked)
    from flask import request

    body = request.get_json(silent=True) or {}
    destructive = str(body.get("action", "")).lower() in ("restore", "reboot", "halt", "firmware_update")
    if destructive:
        stepup = require_ops_stepup()
        if stepup:
            return _respond(stepup)
    host = _first_host_from_config()
    if host is None:
        return _unconfigured_response()
    from pfsense_src.routes.ops import build_ops_payload

    return _respond(build_ops_payload(host, PLUGIN_DIR, body, actor=current_actor()))


def _h_audit():
    denied = _require("audit")
    if denied:
        return _respond(denied)
    from flask import request
    from pfsense_src.routes.audit import build_audit_payload

    try:
        limit = int(request.args.get("limit", 50))
    except (TypeError, ValueError):
        limit = 50
    return _respond(build_audit_payload(PLUGIN_DIR, limit))


def _h_metrics():
    host = _first_host_from_config()
    if host is None:
        return Response(
            f'# {PLUGIN_ID} plugin: no {HOSTS_KEY} configured\n{PLUGIN_ID}_up{{host="unknown"}} 0\n',
            mimetype="text/plain; version=0.0.4",
        )
    from pfsense_src.client import PFsenseClient
    from pfsense_src.metrics import render_metrics

    try:
        body = render_metrics(PFsenseClient(host), host_label=host.name)
    except Exception as e:
        body = f'# {PLUGIN_ID} plugin: render_metrics failed: {e}\n{PLUGIN_ID}_up{{host="{host.name}"}} 0\n'
    return Response(body, mimetype="text/plain; version=0.0.4")


def _h_config():
    """GET — plugin config (connector perm required, secrets masked)."""
    denied = _require("connector")
    if denied:
        return _respond(denied)
    cfg = _load_config()
    masked_hosts = []
    for h in cfg.get(HOSTS_KEY, []):
        masked = dict(h)
        for k in SECRET_KEYS:
            if masked.get(k):
                masked[k] = "***"
        masked_hosts.append(masked)
    return {
        HOSTS_KEY: masked_hosts,
        "poll_interval": cfg.get("poll_interval", 30),
        "read_only": cfg.get("read_only", False),
        "cluster_mode": cfg.get("cluster_mode", "auto"),
    }


def _h_save_config():
    """POST — save plugin config; masked secrets round-trip by host URL."""
    denied = _require("connector")
    if denied:
        return _respond(denied)
    from flask import request

    data = request.get_json(silent=True) or {}
    cfg = _load_config()

    old_secrets = {_host_lookup_key(h): h for h in cfg.get(HOSTS_KEY, [])}

    new_hosts = []
    for h in data.get(HOSTS_KEY, []):
        if not isinstance(h, dict):
            continue
        key = _host_lookup_key(h)
        merged = dict(h)
        for k in SECRET_KEYS:
            if merged.get(k) == "***":
                merged[k] = old_secrets.get(key, {}).get(k, "")
        merged["name"] = str(merged.get("name", "pfsense")).strip() or "pfsense"
        merged["url"] = str(merged.get("url", "")).rstrip("/")
        merged["verify_tls"] = bool(merged.get("verify_tls", True))
        merged["ca_bundle_path"] = merged.get("ca_bundle_path") or None
        new_hosts.append(merged)

    cfg[HOSTS_KEY] = new_hosts
    cfg["poll_interval"] = max(5, min(3600, int(data.get("poll_interval", cfg.get("poll_interval", 30)))))
    cfg["read_only"] = bool(data.get("read_only", cfg.get("read_only", False)))
    cfg["cluster_mode"] = str(data.get("cluster_mode", cfg.get("cluster_mode", "auto"))).lower()

    try:
        with open(CONFIG_PATH, "w", encoding="utf-8") as f:
            json.dump(cfg, f, indent=2)
    except Exception as e:
        log.error("Failed to save config: %s", e)
        return {"error": "Failed to save config"}, 500

    _master_cache["side"] = None
    _master_cache["ts"] = 0.0
    return {"success": True}


# Route → required `pfsense.<domain>` permission for mutations (GETs ride
# the `view` floor). The RBAC contract test iterates this map to guarantee
# every route is gated — keep it in sync with `ROUTES`.
ROUTE_PERMISSIONS = {
    "health": "view",
    "ui": "view",
    "metrics": "view",
    "config": "connector",
    "config/save": "connector",
    "overview": "view",
    "cluster": "view",
    "network": "view",
    "logs": "view",
    "rules": "rules",
    "aliases": "aliases",
    "nat": "nat",
    "dhcp": "dhcp",
    "dns": "dns",
    "vpn": "vpn",
    "services": "services",
    "ops": "ops",
    "audit": "audit",
}

ROUTES = {
    "health": _h_health,
    "ui": _h_ui,
    "config": _h_config,
    "config/save": _h_save_config,
    "overview": _h_overview,
    "cluster": _h_cluster,
    "network": _h_network,
    "logs": _h_logs,
    "rules": _h_rules,
    "aliases": _h_aliases,
    "nat": _h_nat,
    "dhcp": _h_dhcp,
    "dns": _h_dns,
    "vpn": _h_vpn,
    "services": _h_services,
    "ops": _h_ops,
    "audit": _h_audit,
    "metrics": _h_metrics,
}


def register(app=None):  # noqa: ARG001
    """Called by ProxmoxVEx when the plugin is enabled."""
    if register_native_route is None:
        raise RuntimeError("ProxmoxVEx framework not available - register() must run inside a ProxmoxVEx host")
    log.info("%s loading", PLUGIN_NAME)
    os.makedirs(STATE_DIR, exist_ok=True)
    for path, handler in ROUTES.items():
        register_native_route(PLUGIN_ID, path, handler)
    log.info("%s registered %d routes", PLUGIN_NAME, len(ROUTES))
