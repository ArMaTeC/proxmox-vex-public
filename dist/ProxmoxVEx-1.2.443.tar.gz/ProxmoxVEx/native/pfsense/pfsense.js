/* --- ProxmoxVEx auto-header start ---
 * -------------------------------------------------------------------
 * File:        ProxmoxVEx/native/pfsense/pfsense.js
 * Project:     ProxmoxVEx
 * Version:     1.2.437
 * Build:       2026.09.12
 * Description: pfSense Manager boot — delegates to the shared manager UI.
 * Docs:        https://proxmoxvex.com/docs
 * Generated:   2026-09-12
 * -------------------------------------------------------------------
 * --- ProxmoxVEx auto-header end --- */
/* pfSense boot: the entire UI is the shared firewall-manager (spec 003 —
   both appliances render identical tabs/actions from the same module). */
(function () {
    'use strict';

    window.FirewallManager.boot({
        pluginId: 'pfsense',
        apiBase: '/api/pfsense',
        i18nBase: '/api/native/pfsense/i18n',
        title: 'pfSense Manager'
    });
})();
