# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/native/pfsense/pfsense_src/collectors/__init__.py
# Project:     ProxmoxVEx
# Version:     1.2.437
# Build:       2026.09.12
# Description: Read-only collectors against a pfSense host.
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-12
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Read-only collectors against a pfSense host.

Each collector takes a ``PFsenseClient`` and returns normalized rows/snapshots
matching the OPNsense collector shapes, propagating API failures as
exceptions.
"""

from .carp import CarpStatus, collect_carp_status  # noqa: F401
from .certificates import CertSummary, collect_certificates  # noqa: F401
from .firewall_log import collect_firewall_log  # noqa: F401
from .gateways import collect_gateways  # noqa: F401
from .hasync import HASyncSnapshot, collect_hasync  # noqa: F401
from .interfaces import collect_interfaces  # noqa: F401
from .routes import collect_neighbors, collect_routes  # noqa: F401
from .rules import collect_rules  # noqa: F401
from .services import collect_services  # noqa: F401
from .system import SystemSnapshot, collect_system  # noqa: F401
from .vpn import (  # noqa: F401
    collect_ipsec,
    collect_openvpn,
    collect_vpn,
    collect_wireguard,
)
