# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/native/pfsense/pfsense_src/client/pfsense_client.py
# Project:     ProxmoxVEx
# Version:     1.2.437
# Build:       2026.09.12
# Description: pfSense FauxAPI HTTP client.
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-12
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""pfSense FauxAPI HTTP client.

Talks to ``https://<host>/fauxapi/v1/?action=<action>`` using the
``fauxapi-auth: <api_key>:<api_secret>`` header.

Full action surface for the parity feature (see specs/003 research.md):

- reads   — system_info, system_stats, interface_list, interface_stats,
            gateway_status, rule_get, config_get, config_backup_list
- writes  — config_patch, config_set, config_reload, config_restore,
            config_backup, send_event, function_call, system_reboot

Retry policy mirrors the OPNsense client: idempotent GET-style actions are
retried once on transient failures; mutating actions (POST) are never
retried — a retried write could apply twice.

The client also exposes `.get(path)` / `.post(path, payload)` duck-typed
shims so `fwkit.hasync.HAVerifier` works unchanged:

- ``get("config/<dot.path>")``  → ``config_get`` + dotted-section extract,
  returned as ``{"rows": [...]}`` so fingerprint/row checks work.
- ``post("config/<dot.path>", payload)`` → ``config_patch``
- ``post("action/<name>", payload)``     → raw action POST

The ``requests`` import is guarded so this module can be imported in
linting / unit-test contexts where the dependency may not be present.
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass
from typing import Any

# requests is a runtime dependency; keep the module importable without it.
try:  # pragma: no cover - optional runtime dependency
    import requests
    from requests.exceptions import RequestException
except ImportError:  # pragma: no cover
    requests = None  # type: ignore[assignment]
    RequestException = Exception  # type: ignore[misc,assignment]

log = logging.getLogger(__name__)


class PFsenseError(Exception):
    """Raised when the pfSense FauxAPI returns an unexpected response."""


class PFsenseAuthError(PFsenseError):
    """401/403 from pfSense — bad credentials or insufficient privileges."""


class PFsenseTimeoutError(PFsenseError):
    """Network or read timeout talking to pfSense."""


class PFsenseUnavailableError(PFsenseError):
    """Appliance unreachable / connection refused (e.g. mid-reboot)."""


# Actions that only read state — safe to retry once on transient failure.
_READ_ACTIONS = frozenset({
    "system_info", "system_stats", "interface_list", "interface_stats",
    "gateway_status", "rule_get", "config_get", "config_backup_list",
    "alias_update_urltables",
})

_RETRY_BACKOFF_S = 0.5


@dataclass(frozen=True)
class PFsenseHost:
    name: str
    url: str
    api_key: str
    api_secret: str
    verify_tls: bool = True
    ca_bundle_path: str | None = None
    connect_timeout: float = 5.0
    read_timeout: float = 15.0


class PFsenseClient:
    """FauxAPI client covering the full pfSense management surface."""

    def __init__(
        self,
        host: PFsenseHost,
        session: requests.Session | None = None,
    ) -> None:
        if requests is None:  # pragma: no cover - requests missing
            raise RuntimeError(
                "requests is required to use PFsenseClient; install requests or skip HTTP tests in this context"
            )
        if not host.url.startswith("https://"):
            raise ValueError("pfSense FauxAPI requires HTTPS")
        self.host = host
        self._session = session or requests.Session()
        self._verify: bool | str = host.ca_bundle_path or host.verify_tls

    # ------------------------------------------------------- read actions

    def system_info(self) -> dict[str, Any]:
        """Raw FauxAPI ``system_info`` response."""
        return self._action("system_info")

    def system_stats(self) -> dict[str, Any]:
        """CPU/memory/state-table stats."""
        return self._action("system_stats")

    def interface_list(self) -> dict[str, Any]:
        return self._action("interface_list")

    def interface_stats(self) -> dict[str, Any]:
        return self._action("interface_stats")

    def gateway_status(self) -> dict[str, Any]:
        return self._action("gateway_status")

    def rule_get(self, rule_number: int | None = None) -> dict[str, Any]:
        params = {"rule_number": rule_number} if rule_number is not None else None
        return self._action("rule_get", params=params)

    def rules(self) -> dict[str, Any]:
        """Raw ``rules`` listing (kept for the legacy rules endpoint)."""
        return self._action("rules")

    def config_get(self, section: str | None = None) -> dict[str, Any]:
        """Full config (or one section, '/'- or '.'-separated)."""
        params = {"section": section} if section else None
        return self._action("config_get", params=params)

    def config_backup_list(self) -> dict[str, Any]:
        return self._action("config_backup_list")

    # ------------------------------------------------------ write actions

    def config_patch(self, patch: dict[str, Any]) -> dict[str, Any]:
        """Merge `patch` into config.xml. The caller MUST follow with
        `config_reload` (or a `send_event`/`function_call` apply) — FauxAPI
        writes the file but does not apply it."""
        return self._action("config_patch", payload=patch, method="POST")

    def config_set(self, section: str, value: Any) -> dict[str, Any]:
        """Replace one config section wholesale."""
        return self._action("config_set", payload={section: value}, method="POST")

    def config_reload(self) -> dict[str, Any]:
        """Apply pending config.xml changes (filter reload)."""
        return self._action("config_reload", method="POST")

    def config_backup(self) -> dict[str, Any]:
        """Snapshot current config into pfSense's backup history."""
        return self._action("config_backup", method="POST")

    def config_restore(self, backup_file: str) -> dict[str, Any]:
        """Restore a named backup — appliance reboots/reloads; callers must
        surface the transitional unreachable state honestly."""
        return self._action("config_restore", payload={"backup_file": backup_file}, method="POST")

    def send_event(self, command: str) -> dict[str, Any]:
        """Run a pfSense event command, e.g. ``filter reload``, ``filter sync``."""
        return self._action("send_event", payload={"command": command}, method="POST")

    def function_call(self, payload: dict[str, Any]) -> dict[str, Any]:
        """Call an arbitrary pfSense PHP function via FauxAPI
        (``function_call``) — used for service control and VPN apply paths
        (e.g. ``services_dhcpd_configure``, ``ipsec_configure``)."""
        return self._action("function_call", payload=payload, method="POST")

    def system_reboot(self) -> dict[str, Any]:
        return self._action("system_reboot", method="POST")

    # -------------------------------------------------- duck-typed shims

    def get(self, path: str, **_params: Any) -> Any:
        """`fwkit.HAVerifier`/`divergence` compat: ``config/<dot.path>`` reads
        a config section and returns ``{"rows": [...]}``; ``action/<name>``
        runs a raw read action."""
        if path.startswith("config/"):
            section = path[len("config/"):].replace("/", ".")
            return {"rows": self.config_section(section)}
        if path.startswith("action/"):
            return self._action(path[len("action/"):])
        raise PFsenseError(f"unsupported get path {path!r}")

    def post(self, path: str, payload: Any = None) -> Any:
        """Compat shim: ``config/<dot.path>`` → config_patch; ``action/<name>``
        → raw POST action."""
        if path.startswith("config/"):
            section = path[len("config/"):].replace("/", ".")
            return self.config_patch({section: payload})
        if path.startswith("action/"):
            return self._action(path[len("action/"):], payload=payload, method="POST")
        raise PFsenseError(f"unsupported post path {path!r}")

    # ----------------------------------------------------- config helpers

    def config_section(self, section: str) -> list[dict[str, Any]] | dict[str, Any] | Any:
        """Extract a dotted config section (``filter.rule``, ``dhcpd.lan``)
        from `config_get`. pfSense's XML→JSON collapses single-child lists
        into dicts — callers get the raw node and list-wrap themselves.
        """
        data = self.config_get()
        node: Any = data.get("data", {}).get("config", data.get("config", data))
        for part in section.split("."):
            if not isinstance(node, dict):
                return []
            node = node.get(part)
        return node if node is not None else []

    # ----------------------------------------------------------------- internal

    def _action(
        self,
        action: str,
        *,
        params: dict[str, Any] | None = None,
        payload: dict[str, Any] | None = None,
        method: str = "GET",
    ) -> dict[str, Any]:
        """Call a FauxAPI action. GET-style read actions retry once on
        transient 5xx/timeout; POST writes never retry."""
        attempts = 2 if (method == "GET" and action in _READ_ACTIONS) else 1
        last_exc: Exception | None = None
        for attempt in range(1, attempts + 1):
            try:
                return self._action_once(action, params=params, payload=payload, method=method)
            except (PFsenseTimeoutError, PFsenseUnavailableError) as e:
                last_exc = e
                if attempt < attempts:
                    time.sleep(_RETRY_BACKOFF_S)
                    continue
                raise
            except PFsenseError as e:
                # Transient 5xx on a read is worth one retry.
                if attempt < attempts and "HTTP 5" in str(e):
                    last_exc = e
                    time.sleep(_RETRY_BACKOFF_S)
                    continue
                raise
        raise last_exc or PFsenseError(f"{action} failed")

    def _action_once(
        self,
        action: str,
        *,
        params: dict[str, Any] | None,
        payload: dict[str, Any] | None,
        method: str,
    ) -> dict[str, Any]:
        url = self._action_url(action)
        headers = {
            "fauxapi-auth": f"{self.host.api_key}:{self.host.api_secret}",
            "accept": "application/json",
        }
        log.debug("%s %s %s", self.host.name, method, action)
        try:
            resp = self._session.request(
                method,
                url,
                headers=headers,
                params=params,
                json=payload,
                timeout=(self.host.connect_timeout, self.host.read_timeout),
                verify=self._verify,
            )
        except RequestException as e:
            if requests is not None and isinstance(e, requests.exceptions.ConnectionError):
                raise PFsenseUnavailableError(
                    f"{method} {action} for {self.host.name}: {e}"
                ) from e
            raise PFsenseTimeoutError(f"{method} {action} failed for {self.host.name}: {e}") from e

        if resp.status_code in (401, 403):
            raise PFsenseAuthError(
                f"{method} {action} for {self.host.name} -> {resp.status_code} "
                "(check api_key/api_secret and user privileges)"
            )

        if not resp.ok:
            raise PFsenseError(
                f"{method} {action} for {self.host.name} -> HTTP {resp.status_code}: {resp.text[:200]}"
            )

        try:
            out = resp.json()
        except ValueError as e:
            raise PFsenseError(f"{method} {action} for {self.host.name} -> non-JSON response") from e

        # FauxAPI wraps results as {"callid":..., "action":..., "message":"ok",
        # "data": {...}}; a non-ok message is an upstream error.
        if isinstance(out, dict) and out.get("message") not in (None, "ok"):
            raise PFsenseError(
                f"{method} {action} for {self.host.name} -> {out.get('message')}"
            )
        return out

    def _action_url(self, action: str) -> str:
        base = self.host.url.rstrip("/")
        return f"{base}/fauxapi/v1/?action={action}"
