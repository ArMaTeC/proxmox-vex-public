# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/native/pfsense/pfsense_src/client/cluster.py
# Project:     ProxmoxVEx
# Version:     1.2.437
# Build:       2026.09.12
# Description: Cluster-aware wrapper over two `PFsenseClient`s.
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-12
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Cluster-aware wrapper over two `PFsenseClient`s — mirrors
`OPNsenseClusterClient` so both plugins resolve the CARP master the same
way and never route writes to the backup node.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Literal

from .pfsense_client import PFsenseClient, PFsenseError

if TYPE_CHECKING:
    from pfsense_src.collectors.carp import CarpStatus

Side = Literal["a", "b"]


@dataclass
class _CarpProbe:
    role: str = "unknown"
    enabled: bool = False


class PFsenseClusterClient:
    def __init__(
        self, client_a: PFsenseClient, client_b: PFsenseClient, name_a: str = "NODOA", name_b: str = "NODOB"
    ) -> None:
        self.a = client_a
        self.b = client_b
        self.name_a = name_a
        self.name_b = name_b
        self._probe_a: _CarpProbe | None = None
        self._probe_b: _CarpProbe | None = None

    def both(self) -> tuple[PFsenseClient, PFsenseClient]:
        return self.a, self.b

    def names(self) -> tuple[str, str]:
        return self.name_a, self.name_b

    def set_carp_cache(self, status_a: CarpStatus | None, status_b: CarpStatus | None) -> None:
        """Populate the master-resolution cache from already-collected CARP snapshots."""
        if status_a is not None:
            self._probe_a = _CarpProbe(role=status_a.get("role", "unknown"), enabled=status_a.get("enabled", False))
        if status_b is not None:
            self._probe_b = _CarpProbe(role=status_b.get("role", "unknown"), enabled=status_b.get("enabled", False))

    def _ensure_probes(self) -> None:
        if self._probe_a is not None and self._probe_b is not None:
            return
        from pfsense_src.collectors.carp import collect_carp_status

        if self._probe_a is None:
            s = collect_carp_status(self.a)
            self._probe_a = _CarpProbe(role=s["role"], enabled=s["enabled"])
        if self._probe_b is None:
            s = collect_carp_status(self.b)
            self._probe_b = _CarpProbe(role=s["role"], enabled=s["enabled"])

    def master_side(self) -> Side:
        """'a' or 'b' — the CARP master. Defaults to 'a' on ambiguity; callers
        verify via `health()` first so writes never hit a backup."""
        self._ensure_probes()
        if self._probe_a is None or self._probe_b is None:
            raise AssertionError("invariant failed")
        if self._probe_a.role == "master" and self._probe_b.role != "master":
            return "a"
        if self._probe_b.role == "master" and self._probe_a.role != "master":
            return "b"
        return "a"

    def master(self) -> PFsenseClient:
        return self.a if self.master_side() == "a" else self.b

    def backup(self) -> PFsenseClient:
        return self.b if self.master_side() == "a" else self.a

    def master_name(self) -> str:
        return self.name_a if self.master_side() == "a" else self.name_b

    def backup_name(self) -> str:
        return self.name_b if self.master_side() == "a" else self.name_a

    def health(self) -> dict:
        reachable_a = reachable_b = True
        err_a = err_b = ""
        try:
            self.a.system_info()
        except PFsenseError as e:
            reachable_a = False
            err_a = str(e)
        try:
            self.b.system_info()
        except PFsenseError as e:
            reachable_b = False
            err_b = str(e)

        try:
            master = (
                self.master_name()
                if reachable_a and reachable_b
                else (self.name_a if reachable_a else self.name_b if reachable_b else "")
            )
        except PFsenseError:
            master = ""

        return {
            "a": {"name": self.name_a, "reachable": reachable_a, "error": err_a},
            "b": {"name": self.name_b, "reachable": reachable_b, "error": err_b},
            "master": master,
        }
