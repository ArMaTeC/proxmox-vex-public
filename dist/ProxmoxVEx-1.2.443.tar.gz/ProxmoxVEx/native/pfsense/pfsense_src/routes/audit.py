# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/native/pfsense/pfsense_src/routes/audit.py
# Project:     ProxmoxVEx
# Version:     1.2.437
# Build:       2026.09.12
# Description: Audit log tail endpoint for pfSense.
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-12
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Audit tail payload — reads the plugin JSONL audit log (newest last)."""

from __future__ import annotations

import logging
from typing import Any

from pfsense_src._fwkit import ensure_fwkit_importable

ensure_fwkit_importable()

from ProxmoxVEx.native.fwkit.audit import AuditLog  # noqa: E402
from ProxmoxVEx.native.fwkit.payloads import audit_log_path, ok  # noqa: E402

log = logging.getLogger(__name__)


def build_audit_payload(plugin_dir: str, limit: int = 50) -> tuple[int, dict[str, Any]]:
    try:
        n = max(1, min(500, int(limit)))
    except (TypeError, ValueError):
        n = 50
    from dataclasses import asdict

    entries = [asdict(e) for e in AuditLog(audit_log_path(plugin_dir)).tail(n)]
    return ok({"entries": entries, "total": len(entries)})
