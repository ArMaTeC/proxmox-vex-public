# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/native/pfsense/pfsense_src/routes/dns.py
# Project:     ProxmoxVEx
# Version:     1.2.437
# Build:       2026.09.12
# Description: DNS override payload — host/domain overrides, list + actions.
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-12
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""DNS route payloads for pfSense (Unbound overrides)."""

from __future__ import annotations

import logging
from typing import Any

from pfsense_src._fwkit import ensure_fwkit_importable
from pfsense_src.client import PFsenseClient, PFsenseHost
from pfsense_src.configmap import read_section
from pfsense_src.routes._domain import dispatch_action, make_writer
from pfsense_src.writers import DnsWriter

ensure_fwkit_importable()

from ProxmoxVEx.native.fwkit.normalize import (  # noqa: E402
    normalize_dns_domain,
    normalize_dns_host,
)
from ProxmoxVEx.native.fwkit.payloads import client_error_envelope, ok  # noqa: E402

log = logging.getLogger(__name__)


def build_dns_list_payload(host: PFsenseHost) -> tuple[int, dict[str, Any]]:
    client = PFsenseClient(host)
    try:
        hosts = [
            normalize_dns_host(r, "pfsense", i)
            for i, r in enumerate(read_section(client, "dns_hosts"))
        ]
        domains = [
            normalize_dns_domain(r, "pfsense", i)
            for i, r in enumerate(read_section(client, "dns_domains"))
        ]
        return ok({"hosts": hosts, "domains": domains})
    except Exception as e:
        return client_error_envelope(e, log_label="pfsense dns list")


def build_dns_action_payload(
    host: PFsenseHost,
    plugin_dir: str,
    body: dict[str, Any],
    *,
    peer_host: PFsenseHost | None = None,
    actor: str = "plugin",
) -> tuple[int, dict[str, Any]]:
    writer = make_writer(DnsWriter, host, peer_host, plugin_dir, actor)

    def _host(b: dict[str, Any]) -> dict[str, Any]:
        row = b.get("host") or {}
        if not isinstance(row, dict):
            raise ValueError("host must be an object")
        return row

    def _domain(b: dict[str, Any]) -> dict[str, Any]:
        row = b.get("domain") or {}
        if not isinstance(row, dict):
            raise ValueError("domain must be an object")
        return row

    return dispatch_action(writer, body, {
        "host_set": lambda b: writer.set_host(_host(b)),
        "host_delete": lambda b: writer.delete_host(str(b.get("uuid") or "")),
        "domain_set": lambda b: writer.set_domain(_domain(b)),
        "domain_delete": lambda b: writer.delete_domain(str(b.get("uuid") or "")),
    })
