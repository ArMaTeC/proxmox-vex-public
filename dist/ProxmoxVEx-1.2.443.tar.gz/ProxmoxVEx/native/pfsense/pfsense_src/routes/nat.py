# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/native/pfsense/pfsense_src/routes/nat.py
# Project:     ProxmoxVEx
# Version:     1.2.437
# Build:       2026.09.12
# Description: NAT payload — list all kinds + CRUD per kind.
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-12
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""NAT route payloads for pfSense — all three kinds under one route."""

from __future__ import annotations

import logging
from typing import Any

from pfsense_src._fwkit import ensure_fwkit_importable
from pfsense_src.client import PFsenseClient, PFsenseHost
from pfsense_src.configmap import read_section
from pfsense_src.routes._domain import dispatch_action, make_writer
from pfsense_src.writers import NatWriter

ensure_fwkit_importable()

from ProxmoxVEx.native.fwkit.normalize import normalize_nat  # noqa: E402
from ProxmoxVEx.native.fwkit.payloads import client_error_envelope, ok  # noqa: E402

log = logging.getLogger(__name__)

_KINDS = {
    "port_forward": "nat_forward",
    "outbound": "nat_outbound",
    "one_to_one": "nat_one_to_one",
}


def build_nat_list_payload(host: PFsenseHost) -> tuple[int, dict[str, Any]]:
    client = PFsenseClient(host)
    try:
        rules: list[dict[str, Any]] = []
        for kind, entity in _KINDS.items():
            for i, row in enumerate(read_section(client, entity)):
                rules.append(normalize_nat(row, "pfsense", kind, i))
        return ok({"rules": rules, "total": len(rules)})
    except Exception as e:
        return client_error_envelope(e, log_label="pfsense nat list")


def build_nat_action_payload(
    host: PFsenseHost,
    plugin_dir: str,
    body: dict[str, Any],
    *,
    peer_host: PFsenseHost | None = None,
    actor: str = "plugin",
) -> tuple[int, dict[str, Any]]:
    kind = str(body.get("kind") or (body.get("rule") or {}).get("kind") or "port_forward")
    if kind not in _KINDS:
        return 400, {"ok": False, "error": "bad_request", "detail": f"kind must be one of {sorted(_KINDS)}"}
    writer = make_writer(NatWriter, host, peer_host, plugin_dir, actor, kind=kind)

    def _rule(b: dict[str, Any]) -> dict[str, Any]:
        rule = b.get("rule") or {}
        if not isinstance(rule, dict):
            raise ValueError("rule must be an object")
        return {**rule, "kind": kind}

    def _uuid(b: dict[str, Any]) -> str:
        uid = str(b.get("uuid", ""))
        if not uid:
            raise ValueError("uuid is required")
        return uid

    return dispatch_action(writer, body, {
        "create": lambda b: writer.create(_rule(b)),
        "update": lambda b: writer.update(_uuid(b), _rule(b)),
        "delete": lambda b: writer.delete(_uuid(b)),
        "toggle": lambda b: writer.run("toggle", {"uuid": _uuid(b)}),
    })
