# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/native/pfsense/pfsense_src/routes/vpn.py
# Project:     ProxmoxVEx
# Version:     1.2.437
# Build:       2026.09.12
# Description: VPN payload — status + full tunnel provisioning actions.
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-12
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""VPN route payloads for pfSense — status listing plus full provisioning
for WireGuard peers, IPsec phase1/2 and OpenVPN server/client instances."""

from __future__ import annotations

import logging
from typing import Any

from pfsense_src._fwkit import ensure_fwkit_importable
from pfsense_src.client import PFsenseClient, PFsenseHost
from pfsense_src.collectors import collect_vpn
from pfsense_src.configmap import listify, read_section
from pfsense_src.routes._domain import dispatch_action, make_writer
from pfsense_src.writers import VpnWriter

ensure_fwkit_importable()

from ProxmoxVEx.native.fwkit.normalize import (  # noqa: E402
    normalize_ipsec_p1,
    normalize_openvpn,
    normalize_wg_peer,
)
from ProxmoxVEx.native.fwkit.payloads import client_error_envelope, ok  # noqa: E402

log = logging.getLogger(__name__)


def build_vpn_list_payload(host: PFsenseHost) -> tuple[int, dict[str, Any]]:
    client = PFsenseClient(host)
    try:
        status = collect_vpn(client)
        wg_rows = []
        try:
            wg_cfg = client.config_section("wireguard")
            if isinstance(wg_cfg, dict):
                wg_rows = [
                    normalize_wg_peer(r, "pfsense", i)
                    for i, r in enumerate(listify(wg_cfg.get("peers") or wg_cfg.get("peer")))
                ]
        except Exception:
            pass
        p1 = [normalize_ipsec_p1(r, "pfsense", i) for i, r in enumerate(read_section(client, "ipsec_p1"))]
        p2_rows = read_section(client, "ipsec_p2")
        ovpn_srv = [normalize_openvpn(r, "pfsense", "server", i) for i, r in enumerate(read_section(client, "openvpn_server"))]
        ovpn_cli = [normalize_openvpn(r, "pfsense", "client", i) for i, r in enumerate(read_section(client, "openvpn_client"))]
        return ok({
            "status": status,
            "wireguard": wg_rows,
            "ipsec": {"phase1": p1, "phase2": p2_rows},
            "openvpn": {"servers": ovpn_srv, "clients": ovpn_cli},
        })
    except Exception as e:
        return client_error_envelope(e, log_label="pfsense vpn list")


def build_vpn_action_payload(
    host: PFsenseHost,
    plugin_dir: str,
    body: dict[str, Any],
    *,
    peer_host: PFsenseHost | None = None,
    actor: str = "plugin",
) -> tuple[int, dict[str, Any]]:
    writer = make_writer(VpnWriter, host, peer_host, plugin_dir, actor)

    def _uuid(b: dict[str, Any]) -> str:
        uid = str(b.get("uuid", ""))
        if not uid:
            raise ValueError("uuid is required")
        return uid

    return dispatch_action(writer, body, {
        # WireGuard peers
        "wg_set": lambda b: writer.wg.run("update" if b.get("uuid") else "create", b.get("peer") or b),
        "wg_delete": lambda b: writer.wg.run("delete", {"uuid": _uuid(b)}),
        # IPsec
        "ipsec_p1_set": lambda b: writer.ipsec_p1.run("update" if b.get("uuid") else "create", b.get("tunnel") or b),
        "ipsec_p1_delete": lambda b: writer.ipsec_p1.run("delete", {"uuid": _uuid(b)}),
        "ipsec_p2_set": lambda b: writer.ipsec_p2.run("update" if b.get("uuid") else "create", b.get("child") or b),
        "ipsec_p2_delete": lambda b: writer.ipsec_p2.run("delete", {"uuid": _uuid(b)}),
        # OpenVPN
        "openvpn_server_set": lambda b: writer.ovpn_server.run("update" if b.get("uuid") else "create", b.get("instance") or b),
        "openvpn_server_delete": lambda b: writer.ovpn_server.run("delete", {"uuid": _uuid(b)}),
        "openvpn_client_set": lambda b: writer.ovpn_client.run("update" if b.get("uuid") else "create", b.get("instance") or b),
        "openvpn_client_delete": lambda b: writer.ovpn_client.run("delete", {"uuid": _uuid(b)}),
    })
