# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/native/pfsense/pfsense_src/writers/dhcp.py
# Project:     ProxmoxVEx
# Version:     1.2.437
# Build:       2026.09.12
# Description: DHCP scope + static-mapping writer for pfSense.
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-12
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""DHCP writer — `dhcpd` is a per-interface map, so this writer runs the
patch/apply/rollback lifecycle directly (the generic row-list mutator
doesn't fit a dict-shaped section).

- scopes:  `dhcpd.<if>` → {enable, range.from/to, descr}
- maps:    `dhcpd.<if>.staticmap[]` → {mac, ipaddr, hostname, descr}
"""

from __future__ import annotations

import ipaddress
import logging
import re
from dataclasses import asdict
from typing import Any

from pfsense_src._fwkit import ensure_fwkit_importable
from pfsense_src.client import PFsenseClient
from pfsense_src.configmap import apply_for, listify, read_dhcp_interfaces, write_dhcp_interfaces

ensure_fwkit_importable()

from ProxmoxVEx.native.fwkit.audit import AuditEntry, AuditLog, TimedAction, hash_payload  # noqa: E402
from ProxmoxVEx.native.fwkit.hasync import (  # noqa: E402
    HAVerifier,
    pfsense_revision_getter,
    pfsense_sync_trigger,
)
from ProxmoxVEx.native.fwkit.results import WriteResult  # noqa: E402

log = logging.getLogger(__name__)

_MAC_RE = re.compile(r"^([0-9A-Fa-f]{2}:){5}[0-9A-Fa-f]{2}$")
_IFACE_RE = re.compile(r"^[a-z][a-z0-9_]{0,15}$")


class DhcpWriter:
    """Scope + static-mapping CRUD with the same lifecycle as SectionWriter."""

    def __init__(
        self,
        client: PFsenseClient,
        audit: AuditLog,
        actor: str = "plugin",
        peer: PFsenseClient | None = None,
    ) -> None:
        self.client = client
        self.audit = audit
        self.actor = actor
        self.verifier = HAVerifier(
            client, peer,
            sync_trigger=pfsense_sync_trigger,
            revision_getter=pfsense_revision_getter,
        )

    # -- helpers -------------------------------------------------------------

    def _apply(self) -> None:
        apply_for(self.client, "dhcp")

    def _commit(self, dhcpd: dict[str, Any]) -> None:
        write_dhcp_interfaces(self.client, dhcpd)

    def _finish(
        self,
        action: str,
        target: str,
        payload: Any,
        ok: bool,
        t: TimedAction,
        detail: str = "",
        uuid: str = "",
        rolled_back: bool = False,
        sync: dict[str, Any] | None = None,
    ) -> WriteResult:
        entry = AuditEntry.now(
            user=self.actor,
            action=action,
            target=target,
            host=self.client.host.name,
            result="ok" if ok else "error",
            duration_ms=t.elapsed_ms,
            detail=detail[:200],
            payload_sha256=hash_payload(payload),
        )
        try:
            self.audit.append(entry)
        except OSError as e:
            log.warning("audit write failed: %s", e)
        return WriteResult(ok=ok, uuid=uuid, detail=detail, rolled_back=rolled_back, audit=asdict(entry), sync=sync)

    def _commit_apply(self, dhcpd: dict[str, Any], original: dict[str, Any]) -> tuple[bool, str]:
        """Commit + apply with rollback. Returns (ok, error_detail)."""
        try:
            self._commit(dhcpd)
            self._apply()
            return True, ""
        except Exception as e:
            log.warning("dhcp apply failed (%s); rolling back", e)
            try:
                self._commit(original)
                self._apply()
                return False, str(e)
            except Exception as rb:
                log.error("dhcp rollback failed: %s", rb)
                raise WriteRollbackError(str(e)) from rb

    # -- scopes ----------------------------------------------------------------

    def set_scope(self, scope: dict[str, Any]) -> WriteResult:
        iface = str(scope.get("interface", ""))
        target = f"pfsense/dhcp.{iface}"
        with TimedAction() as t:
            if not _IFACE_RE.match(iface):
                return self._finish("dhcp.scope_set", target, scope, False, t, "validation: interface name invalid")
            rng = scope.get("range") or {}
            try:
                if rng.get("from"):
                    ipaddress.ip_address(str(rng["from"]))
                if rng.get("to"):
                    ipaddress.ip_address(str(rng["to"]))
            except ValueError as e:
                return self._finish("dhcp.scope_set", target, scope, False, t, f"validation: {e}")

            dhcpd = read_dhcp_interfaces(self.client)
            original = dict(dhcpd)
            node = dict(dhcpd.get(iface) or {})
            if scope.get("range") is not None:
                node["range"] = {"from": str(rng.get("from", "")), "to": str(rng.get("to", ""))}
            if scope.get("enabled", True):
                node["enable"] = ""
            else:
                node.pop("enable", None)
            if scope.get("description") is not None:
                node["descr"] = str(scope["description"])
            dhcpd[iface] = node
            try:
                committed, err = self._commit_apply(dhcpd, original)
            except WriteRollbackError as e:
                return self._finish("dhcp.scope_set", target, scope, False, t, str(e), uuid=iface, rolled_back=False)
            if not committed:
                return self._finish("dhcp.scope_set", target, scope, False, t, err, uuid=iface, rolled_back=True)

        sr = self.verifier.verify_item("config/dhcpd", "if", iface)
        return self._finish("dhcp.scope_set", target, scope, True, t, uuid=iface, sync=sr.__dict__)

    def delete_scope(self, iface: str) -> WriteResult:
        target = f"pfsense/dhcp.{iface}"
        with TimedAction() as t:
            dhcpd = read_dhcp_interfaces(self.client)
            original = dict(dhcpd)
            if iface not in dhcpd:
                return self._finish("dhcp.scope_delete", target, {"interface": iface}, False, t, "validation: scope not found")
            dhcpd.pop(iface)
            try:
                committed, err = self._commit_apply(dhcpd, original)
            except WriteRollbackError as e:
                return self._finish("dhcp.scope_delete", target, {"interface": iface}, False, t, str(e), rolled_back=False)
            if not committed:
                return self._finish("dhcp.scope_delete", target, {"interface": iface}, False, t, err, rolled_back=True)
        return self._finish("dhcp.scope_delete", target, {"interface": iface}, True, t, uuid=iface)

    # -- static mappings -------------------------------------------------------

    def set_mapping(self, mapping: dict[str, Any]) -> WriteResult:
        iface = str(mapping.get("interface", ""))
        mac = str(mapping.get("mac", ""))
        ip = str(mapping.get("ip") or mapping.get("ipaddr") or "")
        target = f"pfsense/dhcp.{iface}"
        with TimedAction() as t:
            if not _MAC_RE.match(mac):
                return self._finish("dhcp.map_set", target, mapping, False, t, "validation: mac must be aa:bb:cc:dd:ee:ff")
            try:
                ipaddress.ip_address(ip)
            except ValueError:
                return self._finish("dhcp.map_set", target, mapping, False, t, "validation: ip must be a valid address")

            dhcpd = read_dhcp_interfaces(self.client)
            original = dict(dhcpd)
            node = dict(dhcpd.get(iface) or {})
            maps = listify(node.get("staticmap"))
            row = {
                "mac": mac,
                "ipaddr": ip,
                "hostname": str(mapping.get("hostname", "")),
                "descr": str(mapping.get("description") or mapping.get("descr") or ""),
            }
            uid = str(mapping.get("uuid") or mac)
            for i, m in enumerate(maps):
                if str(m.get("mac", "")).lower() == uid.lower() or str(m.get("cid", "")) == uid:
                    maps[i] = {**m, **row}
                    break
            else:
                maps.append(row)
            node["staticmap"] = maps
            dhcpd[iface] = node
            try:
                committed, err = self._commit_apply(dhcpd, original)
            except WriteRollbackError as e:
                return self._finish("dhcp.map_set", target, mapping, False, t, str(e), rolled_back=False)
            if not committed:
                return self._finish("dhcp.map_set", target, mapping, False, t, err, rolled_back=True)
        return self._finish("dhcp.map_set", target, mapping, True, t, uuid=uid)

    def delete_mapping(self, iface: str, uid: str) -> WriteResult:
        target = f"pfsense/dhcp.{iface}"
        with TimedAction() as t:
            dhcpd = read_dhcp_interfaces(self.client)
            original = dict(dhcpd)
            node = dict(dhcpd.get(iface) or {})
            maps = listify(node.get("staticmap"))
            kept = [m for m in maps if str(m.get("mac", "")).lower() != uid.lower() and str(m.get("cid", "")) != uid]
            if len(kept) == len(maps):
                return self._finish("dhcp.map_delete", target, {"interface": iface, "uuid": uid}, False, t, "validation: mapping not found")
            node["staticmap"] = kept
            dhcpd[iface] = node
            try:
                committed, err = self._commit_apply(dhcpd, original)
            except WriteRollbackError as e:
                return self._finish("dhcp.map_delete", target, {"interface": iface, "uuid": uid}, False, t, str(e), rolled_back=False)
            if not committed:
                return self._finish("dhcp.map_delete", target, {"interface": iface, "uuid": uid}, False, t, err, rolled_back=True)
        return self._finish("dhcp.map_delete", target, {"interface": iface, "uuid": uid}, True, t, uuid=uid)


class WriteRollbackError(Exception):
    """The write failed AND the rollback failed — appliance state unknown."""
