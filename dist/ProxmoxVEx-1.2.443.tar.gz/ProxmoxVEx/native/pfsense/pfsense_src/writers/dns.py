# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/native/pfsense/pfsense_src/writers/dns.py
# Project:     ProxmoxVEx
# Version:     1.2.437
# Build:       2026.09.12
# Description: DNS override writer for pfSense (unbound hosts/domains).
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-12
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""DNS writer — Unbound host overrides (`unbound.hosts`) and domain
overrides (`unbound.domainoverrides`)."""

from __future__ import annotations

import ipaddress
from typing import Any

from .base import SectionWriter, make_section_mutator


def _to_host_row(row: dict[str, Any]) -> dict[str, Any]:
    try:
        ipaddress.ip_address(str(row.get("ip", "")))
    except ValueError:
        raise ValueError("ip must be a valid address") from None
    if not str(row.get("domain", "")):
        raise ValueError("domain is required")
    return {
        "host": str(row.get("hostname") or row.get("host") or ""),
        "domain": str(row.get("domain", "")),
        "ip": str(row.get("ip", "")),
        "descr": str(row.get("description") or row.get("descr") or ""),
    }


def _to_domain_row(row: dict[str, Any]) -> dict[str, Any]:
    if not str(row.get("domain", "")):
        raise ValueError("domain is required")
    try:
        ipaddress.ip_address(str(row.get("ip", "")))
    except ValueError:
        raise ValueError("ip must be a valid forwarder address") from None
    return {
        "domain": str(row.get("domain", "")),
        "ip": str(row.get("ip", "")),
        "descr": str(row.get("description") or row.get("descr") or ""),
    }


class _HostWriter(SectionWriter):
    entity = "dns_hosts"
    uuid_field = "host"

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)
        self._mutate = make_section_mutator(self.entity, self.uuid_field, _to_host_row)

    def mutate(self, rows, action, payload):
        return self._mutate(rows, action, payload)


class _DomainWriter(SectionWriter):
    entity = "dns_domains"
    uuid_field = "domain"

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)
        self._mutate = make_section_mutator(self.entity, self.uuid_field, _to_domain_row)

    def mutate(self, rows, action, payload):
        return self._mutate(rows, action, payload)


class DnsWriter:
    """Facade exposing host + domain override writers under one class."""

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        self.hosts = _HostWriter(*args, **kwargs)
        self.domains = _DomainWriter(*args, **kwargs)

    def set_host(self, row: dict[str, Any]):
        return self.hosts.run("create" if not row.get("uuid") else "update", row)

    def delete_host(self, uid: str):
        return self.hosts.run("delete", {"uuid": uid})

    def set_domain(self, row: dict[str, Any]):
        return self.domains.run("create" if not row.get("uuid") else "update", row)

    def delete_domain(self, uid: str):
        return self.domains.run("delete", {"uuid": uid})
