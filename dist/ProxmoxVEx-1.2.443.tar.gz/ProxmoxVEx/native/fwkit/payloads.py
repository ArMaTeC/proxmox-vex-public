# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/native/fwkit/payloads.py
# Project:     ProxmoxVEx
# Version:     1.2.437
# Build:       2026.09.12
# Description: Shared response-envelope helpers for the firewall plugins.
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-12
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Shared response-envelope helpers for the appliance integrations.

Both plugins return the same wire shapes:

- success: `{"ok": True, "data": {...}}`
- failure: `{"ok": False, "error": "<code>", "detail": "..."}` where `error`
  is a stable machine-readable code: `unconfigured`, `auth`, `timeout`,
  `unavailable`, `validation`, `bad_request`, `read_only`, `forbidden`,
  `confirm_required`, `upstream`.

Route payload builders return `(status, dict)` tuples; the plugin
`__init__` jsonify's them. Helpers here are transport-agnostic — error
classification works off exception class *names* so it covers both
`OPNsense*` and `PFsense*` client error families without importing either.
"""

from __future__ import annotations

import logging
import os
from typing import Any

log = logging.getLogger(__name__)


def audit_log_path(plugin_dir: str) -> str:
    """Standard audit JSONL path for a plugin: `<plugin_dir>/state/audit.jsonl`."""
    state = os.path.join(plugin_dir, "state")
    os.makedirs(state, exist_ok=True)
    return os.path.join(state, "audit.jsonl")


def unconfigured_payload(plugin_id: str) -> tuple[int, dict[str, Any]]:
    return 400, {
        "ok": False,
        "error": "unconfigured",
        "detail": (
            f"No {plugin_id}_hosts in config.json — edit the plugin config "
            f"(plugins/{plugin_id}/config.json)"
        ),
    }


def ok(data: dict[str, Any] | list | None = None) -> tuple[int, dict[str, Any]]:
    return 200, {"ok": True, "data": data if data is not None else {}}


def err(code: str, detail: str, status: int = 400) -> tuple[int, dict[str, Any]]:
    return status, {"ok": False, "error": code, "detail": detail}


def client_error_envelope(exc: Exception, *, log_label: str = "request") -> tuple[int, dict[str, Any]]:
    """Map an appliance-client exception to the standard error envelope.

    Classification is by class-name suffix so both `OPNsenseAuthError` and
    `PFsenseAuthError` (etc.) map correctly without importing either client.
    """
    name = type(exc).__name__
    if "Auth" in name:
        return err("auth", str(exc), 401)
    if "Timeout" in name:
        return err("timeout", str(exc), 504)
    if "Unavailable" in name or "Connection" in name:
        return err("unavailable", str(exc), 502)
    log.exception("%s failed", log_label)
    return err("upstream", str(exc), 502)


def read_only_blocked(cfg: dict[str, Any]) -> tuple[int, dict[str, Any]] | None:
    """Return a 403 payload when the plugin is in read-only mode, else None."""
    if bool(cfg.get("read_only", False)):
        return err("read_only", "plugin config has read_only=true", 403)
    return None


def confirm_token_ok(body: dict[str, Any], hostname: str) -> bool:
    """Destructive ops must carry `confirm: "<hostname>"` (FR-017).

    Comparison is strict and case-sensitive — a mistyped name must fail.
    """
    return str(body.get("confirm", "")) == str(hostname)


def bad_request(detail: str) -> tuple[int, dict[str, Any]]:
    return err("bad_request", detail, 400)


def validation_error(detail: str) -> tuple[int, dict[str, Any]]:
    return err("validation", detail, 400)
