# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/native/fwkit/results.py
# Project:     ProxmoxVEx
# Version:     1.2.437
# Build:       2026.09.12
# Description: Normalized write-result shape shared by all firewall writers.
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-12
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Normalized write-result shape returned by every firewall writer.

OPNsense writers historically returned ad-hoc `*Result` dataclasses with
`ok`/`uuid`/`sync`/`audit` fields. `WriteResult` standardizes that contract
so pfSense writers and new OPNsense writers (IPsec/OpenVPN/platform ops)
all return the same envelope, and routes serialize it identically.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class WriteResult:
    """Outcome of a single mutation against the appliance.

    - `ok`      — the appliance accepted the write (and any apply/reload).
    - `uuid`    — identifier of the affected object (uuid/tracker/row id).
    - `sync`    — HA sync-verification dict (`SyncResult.__dict__`-shaped)
                  or None in single-node mode / when not verified.
    - `audit`   — the audit entry dict appended for this write, or None.
    - `detail`  — human-readable error/detail string when `ok` is False.
    - `rolled_back` — True when the write was undone after a failed apply.
    """

    ok: bool
    uuid: str = ""
    sync: dict[str, Any] | None = None
    audit: dict[str, Any] | None = None
    detail: str = ""
    rolled_back: bool = False
    extra: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        out: dict[str, Any] = {
            "ok": self.ok,
            "uuid": self.uuid,
            "detail": self.detail,
            "rolled_back": self.rolled_back,
        }
        if self.sync is not None:
            out["sync"] = self.sync
        if self.audit is not None:
            out["audit"] = self.audit
        out.update(self.extra)
        return out
