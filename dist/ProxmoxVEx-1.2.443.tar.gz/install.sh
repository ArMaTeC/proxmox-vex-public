#!/bin/bash
# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        install.sh
# Project:     ProxmoxVEx
# Version:     1.2.443
# Build:       2026.09.13
# Description: One-command installer for a fresh server (curl-pipeable)
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-13
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
#
# One-command install for ProxmoxVEx on a fresh Linux server:
#
#   curl -fsSL https://proxmoxvex.com/downloads/install.sh | sudo bash
#
# With options:
#   curl -fsSL .../install.sh | sudo bash -s -- --port=443 --no-interactive
#
# Supported hosts: Debian 12/13, Ubuntu 22.04/24.04, RHEL 9 / Rocky / Alma /
# Fedora, Arch Linux, Proxmox VE hosts — x86_64 and aarch64.
#
# What it does:
#   1. Installs OS packages (Python 3, PostgreSQL, sshpass, curl, ...)
#   2. Initializes PostgreSQL and creates the proxmoxvex role + database
#      (skipped when PROXMOXVEX_DATABASE_URL is already set for a remote DB)
#   3. Downloads the release archive to /opt/ProxmoxVEx
#   4. Creates the venv and installs requirements.txt
#   5. Writes /etc/ProxmoxVEx/ProxmoxVEx.env (DSN, port, bind mode)
#   6. Creates the systemd unit (boot persistence), sudoers rules, master key
#   7. Opens firewall ports (ufw/firewalld when active)
#   8. Starts the service and prints access URLs
#
# Re-running is safe: it upgrades in place and preserves config + env file.
set -euo pipefail

# ============================================================================
# Configuration — overridable via environment or flags
# ============================================================================
INSTALL_DIR="${PROXMOXVEX_INSTALL_DIR:-/opt/ProxmoxVEx}"
SERVICE_USER="ProxmoxVEx"
ENV_DIR="/etc/ProxmoxVEx"
ENV_FILE="$ENV_DIR/ProxmoxVEx.env"
ACCESS_PORT="${PROXMOXVEX_PORT:-5000}"
ARCHIVE_BASE="https://proxmoxvex.com/downloads"
RELEASE_ARCHIVE="${PROXMOXVEX_ARCHIVE:-$ARCHIVE_BASE/ProxmoxVEx-latest.tar.gz}"
DB_NAME="proxmoxvex"
DB_USER="proxmoxvex"
INTERACTIVE=true
DOWNLOAD_OFFLINE=true
CONFIGURE_FIREWALL=true
BIND_ALL=true   # management UI: bind all interfaces by default; env file documents it

for arg in "$@"; do
    case "$arg" in
        --port=*)            ACCESS_PORT="${arg#*=}" ;;
        --no-interactive)    INTERACTIVE=false ;;
        --no-offline)        DOWNLOAD_OFFLINE=false ;;
        --no-firewall)       CONFIGURE_FIREWALL=false ;;
        --loopback-only)     BIND_ALL=false ;;
        --help|-h)
            cat <<'HELP'
ProxmoxVEx one-command installer

Usage: sudo bash install.sh [options]
       curl -fsSL https://proxmoxvex.com/downloads/install.sh | sudo bash -s -- [options]

Options:
  --port=PORT        Web UI port (default 5000; use 443 for clean HTTPS)
  --no-interactive   Never prompt; accept all defaults
  --no-offline       Skip downloading static assets for offline mode
  --no-firewall      Do not touch ufw/firewalld rules
  --loopback-only    Bind to 127.0.0.1 only (behind a reverse proxy)

Environment:
  PROXMOXVEX_DATABASE_URL   Use an existing PostgreSQL instead of installing one
  PROXMOXVEX_ARCHIVE        Override the release archive URL
  PROXMOXVEX_INSTALL_DIR    Install location (default /opt/ProxmoxVEx)
HELP
            exit 0
            ;;
    esac
done

# ============================================================================
# Output helpers
# ============================================================================
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; BLUE='\033[0;34m'; CYAN='\033[0;36m'; BOLD='\033[1m'; NC='\033[0m'
step()  { echo -e "\n${BLUE}════════════════════════════════════════════════════════════${NC}\n${BOLD}$1${NC}\n${BLUE}════════════════════════════════════════════════════════════${NC}\n"; }
ok()    { echo -e "${GREEN}✓${NC} $1"; }
info()  { echo -e "${CYAN}ℹ${NC} $1"; }
warn()  { echo -e "${YELLOW}⚠${NC} $1"; }
die()   { echo -e "${RED}✗ $1${NC}" >&2; exit 1; }

[ "$EUID" -eq 0 ] || die "Run as root: curl -fsSL https://proxmoxvex.com/downloads/install.sh | sudo bash"

case "$(uname -m)" in
    x86_64|aarch64) ;;
    *) die "Unsupported architecture $(uname -m) — ProxmoxVEx ships wheels for x86_64/aarch64 only" ;;
esac

# ============================================================================
# Step 1: Detect distro + install OS packages
# ============================================================================
step "Step 1/7: System dependencies"

[ -f /etc/os-release ] || die "Cannot detect OS — /etc/os-release missing"
. /etc/os-release
DISTRO_ID="${ID:-}"
DISTRO_LIKE="${ID_LIKE:-}"
info "Detected: ${PRETTY_NAME:-$DISTRO_ID}"

PKG_MGR=""
case "$DISTRO_ID $DISTRO_LIKE" in
    *debian*|*ubuntu*) PKG_MGR="apt" ;;
    *rhel*|*fedora*|*rocky*|*almalinux*|*centos*) PKG_MGR="dnf" ;;
    *arch*) PKG_MGR="pacman" ;;
esac
[ -n "$PKG_MGR" ] || die "Unsupported distro '$DISTRO_ID'. Supported: Debian/Ubuntu, RHEL/Rocky/Alma/Fedora, Arch — or use Docker."

export DEBIAN_FRONTEND=noninteractive
case "$PKG_MGR" in
    apt)
        apt-get update -qq
        apt-get install -y -qq python3 python3-venv python3-pip curl wget openssl \
            ca-certificates openssh-client sshpass sudo postgresql >/dev/null
        ;;
    dnf)
        dnf install -y -q python3 python3-pip curl wget openssl ca-certificates \
            openssh-clients sudo postgresql-server postgresql || true
        # sshpass lives in EPEL on RHEL-family; enable it if the first try missed it
        if ! rpm -q sshpass >/dev/null 2>&1; then
            dnf install -y -q epel-release 2>/dev/null || true
            dnf install -y -q sshpass || warn "sshpass unavailable — password-based SSH to nodes will not work"
        fi
        ;;
    pacman)
        pacman -Sy --noconfirm --needed python python-pip curl wget openssl \
            ca-certificates openssh sshpass sudo postgresql >/dev/null
        ;;
esac
ok "OS packages installed"

python3 -c 'import sys; v=sys.version_info; sys.exit(0 if (v.major==3 and 10<=v.minor<14) else 1)' \
    || die "Python 3.10–3.13 required (found $(python3 -V 2>&1))"

# ============================================================================
# Step 2: PostgreSQL — local install unless an external DSN was provided
# ============================================================================
step "Step 2/7: PostgreSQL database"

DB_DSN="${PROXMOXVEX_DATABASE_URL:-}"
if [ -n "$DB_DSN" ]; then
    info "Using provided PROXMOXVEX_DATABASE_URL — skipping local PostgreSQL setup"
else
    case "$PKG_MGR" in
        dnf)
            # RHEL-family needs an explicit initdb before the service can start.
            if [ ! -s /var/lib/pgsql/data/PG_VERSION ]; then
                postgresql-setup --initdb >/dev/null 2>&1 || /usr/bin/postgresql-setup --initdb >/dev/null
            fi
            ;;
        pacman)
            # Arch ships no pre-initialized cluster either.
            if [ ! -s /var/lib/postgres/data/PG_VERSION ]; then
                su - postgres -c "initdb -D /var/lib/postgres/data --locale=C.UTF-8 --encoding=UTF8" >/dev/null
            fi
            ;;
    esac
    systemctl enable --now postgresql >/dev/null 2>&1 || die "PostgreSQL failed to start — check: journalctl -u postgresql"

    # Generate a per-install password and (re)create role + database idempotently.
    DB_PASS="$(openssl rand -base64 24 | tr -d '/+=' | cut -c1-32)"
    su - postgres -c "psql -tAc \"SELECT 1 FROM pg_roles WHERE rolname='$DB_USER'\"" | grep -q 1 \
        && su - postgres -c "psql -c \"ALTER ROLE $DB_USER WITH LOGIN PASSWORD '$DB_PASS'\"" >/dev/null \
        || su - postgres -c "psql -c \"CREATE ROLE $DB_USER LOGIN PASSWORD '$DB_PASS'\"" >/dev/null
    su - postgres -c "psql -tAc \"SELECT 1 FROM pg_database WHERE datname='$DB_NAME'\"" | grep -q 1 \
        || su - postgres -c "createdb -O $DB_USER $DB_NAME" >/dev/null
    DB_DSN="postgresql://$DB_USER:$DB_PASS@127.0.0.1:5432/$DB_NAME"
    ok "PostgreSQL running; role '$DB_USER' and database '$DB_NAME' ready"
fi

# ============================================================================
# Step 3: Service user + directories + release archive
# ============================================================================
step "Step 3/7: Installing ProxmoxVEx to $INSTALL_DIR"

id "$SERVICE_USER" &>/dev/null || useradd --system --no-create-home --shell /bin/false "$SERVICE_USER"
mkdir -p "$INSTALL_DIR"/{config,logs,ssl,static,web,images,backups}

TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
info "Downloading $RELEASE_ARCHIVE"
curl -fsSL "$RELEASE_ARCHIVE" -o "$TMP/release.tar.gz" || die "Download failed — check connectivity to proxmoxvex.com"
# Verify against the published checksum when one is served alongside.
if curl -fsSL "$RELEASE_ARCHIVE.sha256" -o "$TMP/release.sha256" 2>/dev/null; then
    (cd "$TMP" && sha256sum -c release.sha256 --status 2>/dev/null) \
        || (cd "$TMP" && echo "$(cut -d' ' -f1 release.sha256)  release.tar.gz" | sha256sum -c --status) \
        || die "Checksum verification failed for $RELEASE_ARCHIVE"
    ok "Checksum verified"
fi
tar -xzf "$TMP/release.tar.gz" -C "$INSTALL_DIR" || die "Failed to extract release archive"
[ -f "$INSTALL_DIR/ProxmoxVEx_multi_cluster.py" ] || die "Archive missing entry point — corrupt download?"
rm -rf "$INSTALL_DIR/.git" 2>/dev/null || true
chmod +x "$INSTALL_DIR/deploy.sh" "$INSTALL_DIR/update.sh" "$INSTALL_DIR/install.sh" 2>/dev/null || true
ok "Release extracted to $INSTALL_DIR"

# ============================================================================
# Step 4: Python environment
# ============================================================================
step "Step 4/7: Python environment"

python3 -m venv "$INSTALL_DIR/venv"
"$INSTALL_DIR/venv/bin/pip" install --upgrade pip -q
"$INSTALL_DIR/venv/bin/pip" install -q -r "$INSTALL_DIR/requirements.txt" \
    || die "pip install failed — see output above"
ok "Virtualenv ready ($("$INSTALL_DIR/venv/bin/python" --version | awk '{print $2}'))"

# ============================================================================
# Step 5: Environment file + port selection
# ============================================================================
step "Step 5/7: Configuration"

if [ "$INTERACTIVE" = true ] && [ -t 0 ]; then
    echo -e "${YELLOW}Web UI port:${NC} [1] 5000 (default)  [2] 443  [3] custom"
    read -r -p "Choice [1-3, default=1]: " CHOICE < /dev/tty || CHOICE=1
    case "${CHOICE:-1}" in
        2) ACCESS_PORT=443 ;;
        3) read -r -p "Port: " ACCESS_PORT < /dev/tty ;;
    esac
fi
[[ "$ACCESS_PORT" =~ ^[0-9]+$ ]] && [ "$ACCESS_PORT" -ge 1 ] && [ "$ACCESS_PORT" -le 65535 ] || die "Invalid port '$ACCESS_PORT'"

mkdir -p "$ENV_DIR"
chmod 750 "$ENV_DIR"
chown "root:$SERVICE_USER" "$ENV_DIR" 2>/dev/null || true

# Preserve an existing env file on upgrade; only (re)write the DSN when we own
# the local PostgreSQL role (external DSNs are left untouched).
if [ -f "$ENV_FILE" ]; then
    if [ -z "${PROXMOXVEX_DATABASE_URL:-}" ]; then
        sed -i "s|^PROXMOXVEX_DATABASE_URL=.*|PROXMOXVEX_DATABASE_URL=$DB_DSN|" "$ENV_FILE"
    fi
    grep -q '^PROXMOXVEX_PORT=' "$ENV_FILE" \
        && sed -i "s|^PROXMOXVEX_PORT=.*|PROXMOXVEX_PORT=$ACCESS_PORT|" "$ENV_FILE" \
        || echo "PROXMOXVEX_PORT=$ACCESS_PORT" >> "$ENV_FILE"
    info "Updated existing $ENV_FILE"
else
    cat > "$ENV_FILE" <<EOF
# ProxmoxVEx environment — consumed by ProxmoxVEx.service via EnvironmentFile=
PROXMOXVEX_DATABASE_URL=$DB_DSN
PROXMOXVEX_PORT=$ACCESS_PORT
# Bind all interfaces so the UI is reachable from the LAN. Comment out or set 0
# and place the app behind a reverse proxy to keep it on loopback.
PROXMOXVEX_BIND_ALL=$([ "$BIND_ALL" = true ] && echo 1 || echo 0)
EOF
    ok "Wrote $ENV_FILE"
fi
chmod 640 "$ENV_FILE"
chown "root:$SERVICE_USER" "$ENV_FILE" 2>/dev/null || true

# ============================================================================
# Step 6: systemd unit, sudoers, master key
# ============================================================================
step "Step 6/7: Service"

cat > /etc/systemd/system/ProxmoxVEx.service <<EOF
[Unit]
Description=ProxmoxVEx - Multi-cluster virtualization management
After=network-online.target postgresql.service
Wants=network-online.target postgresql.service

[Service]
Type=simple
User=$SERVICE_USER
Group=$SERVICE_USER
WorkingDirectory=$INSTALL_DIR
EnvironmentFile=-$ENV_FILE
Environment=PATH=$INSTALL_DIR/bin:/usr/local/bin:/usr/bin:/bin
ExecStart=$INSTALL_DIR/venv/bin/python $INSTALL_DIR/ProxmoxVEx_multi_cluster.py
Restart=always
RestartSec=5
AmbientCapabilities=CAP_NET_BIND_SERVICE
PrivateTmp=true
StandardOutput=journal
StandardError=journal
SyslogIdentifier=ProxmoxVEx

[Install]
WantedBy=multi-user.target
EOF

# Auto-update needs to restart its own unit — scope sudoers to exactly that.
cat > /etc/sudoers.d/ProxmoxVEx <<'EOF'
ProxmoxVEx ALL=(ALL) NOPASSWD: /usr/bin/systemctl restart ProxmoxVEx, /usr/bin/systemctl restart ProxmoxVEx.service, /usr/bin/systemctl stop ProxmoxVEx, /usr/bin/systemctl stop ProxmoxVEx.service, /usr/bin/systemctl start ProxmoxVEx, /usr/bin/systemctl start ProxmoxVEx.service, /usr/bin/systemctl status ProxmoxVEx, /usr/bin/systemctl status ProxmoxVEx.service, /usr/bin/systemctl is-active ProxmoxVEx, /usr/bin/systemctl is-active ProxmoxVEx.service
EOF
chmod 440 /etc/sudoers.d/ProxmoxVEx

# Master encryption key lives outside the install dir so config backups do not
# carry the decryption key (0640 root:ProxmoxVEx — the service group reads it).
SYS_KEY="$ENV_DIR/secret.key"
if [ ! -f "$SYS_KEY" ]; then
    python3 -c "
import base64, os, secrets
key = base64.urlsafe_b64encode(secrets.token_bytes(32))
fd = os.open('$SYS_KEY', os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o640)
try: os.write(fd, key)
finally: os.close(fd)
"
    chown "root:$SERVICE_USER" "$SYS_KEY" 2>/dev/null || true
    ok "Generated master key at $SYS_KEY"
else
    info "Master key already present at $SYS_KEY"
fi

chown -R "$SERVICE_USER:$SERVICE_USER" "$INSTALL_DIR"
chmod 700 "$INSTALL_DIR/config" "$INSTALL_DIR/ssl" 2>/dev/null || true

systemctl daemon-reload
systemctl enable ProxmoxVEx >/dev/null 2>&1
ok "ProxmoxVEx.service installed and enabled (port $ACCESS_PORT)"

# ============================================================================
# Step 7: Firewall + offline assets + start
# ============================================================================
step "Step 7/7: Firewall & start"

if [ "$CONFIGURE_FIREWALL" = true ]; then
    if command -v ufw >/dev/null 2>&1 && ufw status 2>/dev/null | grep -q 'Status: active'; then
        for p in "$ACCESS_PORT" "$((ACCESS_PORT+1))" "$((ACCESS_PORT+2))"; do
            ufw allow "$p/tcp" >/dev/null
        done
        ok "ufw: allowed $ACCESS_PORT-$((ACCESS_PORT+2))/tcp"
    elif command -v firewall-cmd >/dev/null 2>&1 && systemctl is-active --quiet firewalld; then
        for p in "$ACCESS_PORT" "$((ACCESS_PORT+1))" "$((ACCESS_PORT+2))"; do
            firewall-cmd --permanent --add-port="$p/tcp" >/dev/null
        done
        firewall-cmd --reload >/dev/null
        ok "firewalld: allowed $ACCESS_PORT-$((ACCESS_PORT+2))/tcp"
    else
        info "No active firewall detected — no rules added (ports $ACCESS_PORT-$((ACCESS_PORT+2))/tcp)"
    fi
fi

if [ "$DOWNLOAD_OFFLINE" = true ]; then
    info "Downloading static assets for offline mode (this takes a moment)..."
    if (cd "$INSTALL_DIR" && "$INSTALL_DIR/venv/bin/python" ProxmoxVEx_multi_cluster.py --download-static >/dev/null 2>&1); then
        ok "Offline assets cached"
    else
        warn "Some assets failed to download (non-critical)"
    fi
    # download-static ran as root — re-assert ownership so the service user can
    # refresh these files later via the in-app update mechanism.
    chown -R "$SERVICE_USER:$SERVICE_USER" "$INSTALL_DIR"
fi

if ! systemctl restart ProxmoxVEx; then
    warn "systemctl restart failed — check: journalctl -u ProxmoxVEx -n 50"
fi
sleep 5
systemctl is-active --quiet ProxmoxVEx \
    && ok "ProxmoxVEx is running" \
    || warn "Service not active yet — check: journalctl -u ProxmoxVEx -f"

# ============================================================================
# Done
# ============================================================================
IP="$(hostname -I 2>/dev/null | awk '{print $1}')"; IP="${IP:-<server-ip>}"
[ "$ACCESS_PORT" = 443 ] && URL="https://$IP" || URL="https://$IP:$ACCESS_PORT"

echo ""
echo -e "${GREEN}╔════════════════════════════════════════════════════════════╗${NC}"
echo -e "${GREEN}║              ProxmoxVEx installation complete              ║${NC}"
echo -e "${GREEN}╚════════════════════════════════════════════════════════════╝${NC}"
echo ""
echo -e "  Web UI:      ${CYAN}${BOLD}$URL${NC}  (self-signed cert on first run)"
echo -e "  Console WS:  $((ACCESS_PORT+1)) (VNC), $((ACCESS_PORT+2)) (SSH)"
echo ""
echo -e "  ${YELLOW}First login:${NC} create the admin account in the UI, then"
echo -e "  add a cluster: Settings → Clusters → Add Proxmox VE."
echo ""
echo -e "  Config:  $ENV_FILE"
echo -e "  Logs:    ${CYAN}journalctl -u ProxmoxVEx -f${NC}"
echo -e "  Service: ${CYAN}systemctl restart ProxmoxVEx${NC}"
echo ""
