# ProxmoxVEx Wiki

**Version:** 1.2.143  
**Build:** 2026.08.17  
**License:** ProxmoxVEx Source-Available License (proprietary — see LICENSE)  
**Homepage:** [proxmoxvex.com](https://proxmoxvex.com)  
**Source:** [github.com/ArMaTeC/proxmox-vex-public](https://github.com/ArMaTeC/proxmox-vex-public)

---

## Table of Contents

1. [What is ProxmoxVEx?](#what-is-proxmoxvex)
2. [Why Use ProxmoxVEx?](#why-use-proxmoxvex)
3. [Key Capabilities](#key-capabilities)
4. [Architecture and Tech Stack](#architecture-and-tech-stack)
5. [Project Layout](#project-layout)
6. [Installation and Deployment](#installation-and-deployment)
7. [Initial Configuration](#initial-configuration)
8. [Environment Variables](#environment-variables)
9. [REST API and Monitoring](#rest-api-and-monitoring)
10. [Security](#security)
11. [Plugins and Extensibility](#plugins-and-extensibility)
12. [Updating and Maintenance](#updating-and-maintenance)
13. [Troubleshooting](#troubleshooting)
14. [Support and Resources](#support-and-resources)

---

## What is ProxmoxVEx?

ProxmoxVEx is a web-based management layer for one or more Proxmox VE and ESXi clusters. It gives operators a single dashboard to monitor, operate, and automate virtual machines, LXC containers, storage, backups, and users across all of their clusters from one place, without logging into each cluster individually.

The project is aimed at homelabs, small service providers, and operations teams that need multi-tenant access control, scheduled automation, centralized observability, and compliance reporting.

At its core, ProxmoxVEx is a Python/Flask backend with a single-page React frontend, a PostgreSQL database, noVNC and xterm.js consoles, and an in-process plugin architecture for extensibility.

## Why Use ProxmoxVEx?

- **One dashboard for many clusters** - health, resource usage, and alerts across all sites in real time.
- **Built for teams** - role-based access, multi-tenancy, LDAP/OIDC, and audit logging.
- **Automation out of the box** - schedule snapshots, rolling updates, backups, and cross-cluster replication.
- **Compliance and cost visibility** - cost chargeback, carbon estimates, right-sizing recommendations, and BSI/ISO/NIS2/SOC 2 mapping.
- **Air-gap ready** - all static assets are bundled locally; offline mode disables external lookups for classified networks.

## Key Capabilities

### Multi-Cluster Operations

- Unified dashboard for Proxmox VE and ESXi resources.
- Live CPU, RAM, storage, and network metrics via Server-Sent Events and WebSockets.
- One-click VM power actions and live migration.
- Cross-cluster load balancing and storage-agnostic snapshot replication.
- Cross-hypervisor migration from ESXi, including near-zero-downtime and offline options.

### Lifecycle and Scheduling

- VM and LXC configuration editing, snapshots, and backups.
- Tag-based or per-VMID snapshot schedules with retention pruning.
- Backup verification: restore, boot, health-check, and cleanup.
- Cloud-Init template library for fast provisioning.
- Rolling node updates with automatic evacuation.

### Access and Security

- Role-based access control with built-in and custom roles.
- Multi-tenancy, IP allow/block lists, and VM-level ACLs.
- TOTP and WebAuthn / FIDO2 two-factor authentication.
- LDAP and OIDC support for Active Directory, Entra ID, Keycloak, Authentik, and others.
- API tokens with bearer authentication.
- PostgreSQL with field-level Fernet encryption for sensitive columns; database volume encryption is provided by the PostgreSQL host.
- HMAC-signed, tamper-evident audit log.
- CVE scanning and CIS hardening baseline checks.

### Monitoring, Reporting, and Automation

- Prometheus-compatible `/api/metrics` endpoint.
- Cost and chargeback reporting, power and carbon estimates.
- Right-sizing recommendations and capacity forecasts.
- Network topology visualization.
- Compliance dashboards for BSI Grundschutz, ISO 27001, NIS2, and SOC 2.
- Integrated syslog receiver and SIEM forwarding.
- Config drift detection with alerting.

### Storage, Networking and Security

- Ceph, ZFS, TrueNAS, NetApp and Proxmox Backup Server management.
- Software-defined networking, VLANs, bridges and firewall rules.
- IPAM, DNS sync and certificate lifecycle management.
- VPN access portal, IDS/IPS and network topology visualization.

### Automation and Alerting

- Scheduled snapshots, backups, rolling updates and maintenance windows.
- Backup verification, restore boot and cleanup workflows.
- Ansible runner and Terraform sync for infrastructure as code.
- Multi-channel notifications (Slack, Teams, Discord, webhooks, ntfy, PagerDuty).
- Alert correlation, incident timelines and syslog/SIEM forwarding.

### Plugin Ecosystem

Plugins are loaded from `plugins/` and published through the plugin directory. Installed examples include Docker Manager, NetApp Storage, OPNsense, TrueNAS, and Storage Rebalancer. They run alongside the plugin API so the tool can be extended with third-party modules.

## Architecture and Tech Stack

ProxmoxVEx is a Python web application with a single-page React frontend. It uses gevent for high-concurrency I/O, PostgreSQL for persistence, and Paramiko-based SSH for cluster operations.

```mermaid
flowchart LR
    Browser -->|HTTPS / WebSocket| Server[Flask / gevent WSGI]
    Server --> API[REST API blueprints]
    Server --> WS[WebSocket / SSE realtime]
    API --> Core[Core services & PostgreSQL DB]
    Core --> SSH[Paramiko SSH to PVE/ESXi nodes]
    Core --> VNC[noVNC / xterm.js consoles]
    Core --> BG[Background workers]
    Core --> Plugins[Plugin registry]
```

### Backend

- **Python 3.8+** with **Flask 3** and **Werkzeug 3**.
- **gevent** for asynchronous, high-concurrency request handling.
- **PostgreSQL** with field-level Fernet encryption for sensitive columns.
- **Paramiko** for SSH and **websockets** for console tunnels.
- **cryptography**, **argon2-cffi**, **pyotp**, **fido2** for security primitives.
- **ldap3**, **PyJWT** for LDAP and OIDC authentication.

### Frontend

- **React** single-page application.
- **Tailwind CSS** and **Chart.js** for UI and metrics.
- **noVNC** for QEMU graphical console.
- **xterm.js** for LXC and SSH terminal sessions.

### Protocols and Ports

| Port | Description                             |
| ---- | --------------------------------------- |
| 5000 | Main web UI and REST API                |
| 5001 | noVNC WebSocket for QEMU console        |
| 5002 | xterm.js WebSocket for LXC/SSH terminal |

## Project Layout

```text
ProxmoxVEx/
├── ProxmoxVEx_multi_cluster.py   # Entry point
├── ProxmoxVEx/                   # Backend application package
│   ├── app.py                    # Flask app factory
│   ├── constants.py              # Configuration constants
│   ├── globals.py                # Shared runtime state
│   ├── api/                      # REST API blueprints
│   ├── core/                     # Business logic, DB, cache
│   ├── background/               # Background workers
│   ├── cli/                      # Maintenance utilities
│   ├── models/                   # Data models
│   └── native/                   # Built-in plugin packages
├── web/                          # Frontend build
│   ├── index.html                # Compiled UI
│   └── src/                      # Frontend source
├── config/                       # Runtime configuration and database
├── static/                       # Offline JS/CSS libraries
├── logs/                         # Application logs
├── plugins/                      # Plugin packages
├── docs/                         # Internal and user documentation
├── tests/                        # Test suite
├── Dockerfile                    # Container image
├── docker-compose.yml            # Docker Compose stack
└── deploy.sh / update.sh         # Install and update scripts
```

## Installation and Deployment

### Requirements

- A 64-bit Linux host (x86_64 or aarch64); Windows and macOS are not supported.
- Python 3.8 or newer (not needed for Docker installs).
- PostgreSQL 13 or newer — the only supported database backend (not needed for Docker installs; the compose stack bundles it).
- Proxmox VE 8.0+ or 9.0+, and/or ESXi, and/or XCP-ng.
- A modern web browser.

### Quick Start with Docker

The fastest way to try ProxmoxVEx is with the included `docker-compose.yml`:

```bash
docker compose up -d
```

Then open `https://<host>:5000` and complete the first-run setup.

### Option 1: Automated Install Script

The `deploy.sh` script installs ProxmoxVEx to `/opt/ProxmoxVEx`:

```bash
# replace the host with your ProxmoxVEx instance or project mirror
curl -O https://<your-proxmoxvex-host>/deploy.sh
chmod +x deploy.sh
sudo ./deploy.sh
```

For a non-interactive install on a specific port:

```bash
sudo ./deploy.sh --port=443 --no-interactive
```

### Option 2: Debian Package

```bash
curl -fsSL https://git.gyptazy.com/api/packages/gyptazy/debian/repository.key -o /etc/apt/keyrings/gyptazy.asc
echo "deb [signed-by=/etc/apt/keyrings/gyptazy.asc] https://packages.gyptazy.com/api/packages/gyptazy/debian trixie main" | sudo tee /etc/apt/sources.list.d/gyptazy.list
sudo apt-get update
sudo apt-get install -y ProxmoxVEx
```

### Option 3: Docker

Use the pre-built image:

```bash
docker run -d --name ProxmoxVEx -p 5000:5000 -p 5001:5001 -p 5002:5002 -v ProxmoxVEx-config:/app/config -v ProxmoxVEx-logs:/app/logs --restart unless-stopped ghcr.io/armatec/proxmoxvex:latest
```

### Option 4: Release Archive

Download the latest release archive — it ships the prebuilt frontend bundle, so no Node.js or build step is needed. A running PostgreSQL instance is required; set `PROXMOXVEX_DATABASE_URL` or the standard `PG*` variables before first start:

```bash
curl -fSL -o ProxmoxVEx-latest.tar.gz https://proxmoxvex.com/downloads/ProxmoxVEx-latest.tar.gz
mkdir -p ProxmoxVEx
tar -xzf ProxmoxVEx-latest.tar.gz -C ProxmoxVEx
cd ProxmoxVEx
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
export PROXMOXVEX_DATABASE_URL=postgresql://user:pass@localhost:5432/proxmoxvex
python3 ProxmoxVEx_multi_cluster.py
```

### Systemd Service

After installing from the deploy script or `.deb`, ProxmoxVEx is managed by systemd:

```bash
sudo systemctl start ProxmoxVEx
sudo systemctl enable ProxmoxVEx
sudo systemctl status ProxmoxVEx
```

Logs are written to `logs/` and to the systemd journal:

```bash
sudo journalctl -u ProxmoxVEx -f
```

### Reverse Proxy

To run behind nginx, enable reverse-proxy mode:

```bash
PROXMOXVEX_BEHIND_PROXY=true PROXMOXVEX_TRUSTED_PROXIES="10.0.0.0/8,127.0.0.1" python3 ProxmoxVEx_multi_cluster.py
```

A sample nginx snippet is available in [README.md](../README.md#reverse-proxy).

### Cloudflare Tunnel

ProxmoxVEx runs three separate listeners:

- Main web/API server on `127.0.0.1:5000`
- VNC console WebSocket server on `127.0.0.1:5001`
- SSH/LXC terminal WebSocket server on `127.0.0.1:5002`

When `PROXMOXVEX_BEHIND_PROXY=true` is set, the frontend connects to the same public port (e.g. `443`) for all three. A Cloudflare Tunnel **must** route the WebSocket paths to the correct origin ports, and this only works reliably with a **locally-managed** `cloudflared` tunnel. Remotely-managed/token tunnels can duplicate the `101 Switching Protocols` handshake, causing the browser to fail with `Invalid frame header`.

Create a local tunnel:

```bash
cloudflared tunnel login
cloudflared tunnel create proxmoxvex-local
cloudflared tunnel route dns proxmoxvex-local proxmoxvex.example.com
```

This writes a `credentials.json` file, for example `/root/.cloudflared/<tunnel-uuid>.json`.

Edit `/etc/cloudflared/config.yml`:

```yaml
tunnel: <tunnel-uuid>
credentials-file: /root/.cloudflared/<tunnel-uuid>.json

ingress:
  - hostname: proxmoxvex.example.com
    path: "^/api/clusters/.*/(shellws|termwebsocket)"
    service: http://127.0.0.1:5002
    originRequest:
      noTLSVerify: true

  - hostname: proxmoxvex.example.com
    path: "^/api/clusters/.*/vms/.*/vncwebsocket"
    service: http://127.0.0.1:5001
    originRequest:
      noTLSVerify: true

  - hostname: proxmoxvex.example.com
    service: http://127.0.0.1:5000
    originRequest:
      noTLSVerify: true

  - service: http_status:404
```

Then point the systemd `ExecStart` at the config file:

```ini
ExecStart=/usr/bin/cloudflared --no-autoupdate --config /etc/cloudflared/config.yml tunnel run
```

Reload and restart:

```bash
systemctl daemon-reload
systemctl restart cloudflared
```

Set `PROXMOXVEX_BEHIND_PROXY=true` and `PROXMOXVEX_TRUSTED_PROXIES="127.0.0.1"` so the app trusts `X-Forwarded-*` headers from `cloudflared`.

## Initial Configuration

After starting ProxmoxVEx, open the web interface:

```text
https://<server-ip>:5000
```

1. Complete the first-run setup wizard to create the administrator account.
2. Go to **Settings > Clusters** and add your Proxmox VE or ESXi credentials.
3. Start managing your clusters.

### First-Run Security Notes

- A self-signed certificate is generated automatically if no custom certificate is provided. Replace it with a trusted certificate for production.
- The database is encrypted automatically on first boot on Linux x86_64 when a master key is available. Back up the key separately from the `config/` directory.

## Environment Variables

ProxmoxVEx behavior is tuned through `PROXMOXVEX_*` environment variables. Legacy mixed-case aliases are accepted as compatibility shims.

### Networking

| Variable                     | Default                                                      | Description                                                          |
| ---------------------------- | ------------------------------------------------------------ | -------------------------------------------------------------------- |
| `PROXMOXVEX_HOST`            | `127.0.0.1` (or `0.0.0.0` / `::` with `PROXMOXVEX_BIND_ALL`) | IP address to bind the main web server.                              |
| `PROXMOXVEX_BIND_ALL`        | unset                                                        | Set to `1`, `true`, or `yes` to bind all interfaces.                 |
| `PROXMOXVEX_BEHIND_PROXY`    | unset                                                        | Set to `1`, `true`, or `yes` to disable SSL and trust proxy headers. |
| `PROXMOXVEX_TRUSTED_PROXIES` | unset                                                        | Comma-separated list of trusted proxy IPs or CIDRs.                  |
| `PROXMOXVEX_ALLOWED_ORIGINS` | unset                                                        | Comma-separated list of allowed CORS origins.                        |
| `PROXMOXVEX_HTTP_PORT`       | `80` (root) or `-1` (non-root)                               | HTTP redirect port. Use `-1` to disable.                             |
| `PROXMOXVEX_SSL_CERT_FILE`   | `config/ssl/cert.pem`                                        | Path to the SSL certificate used for the health check.               |

### Concurrency and Performance

| Variable                        | Default                   | Description                                        |
| ------------------------------- | ------------------------- | -------------------------------------------------- |
| `PROXMOXVEX_SERVER`             | `auto`                    | WSGI mode: `gevent`, `flask`, or `auto`.           |
| `PROXMOXVEX_WORKERS`            | `max(32, cpu_count * 16)` | Number of gevent greenlets for request handling.   |
| `PROXMOXVEX_NO_GEVENT`          | unset                     | Set to `1`, `true`, or `yes` to disable gevent.    |
| `PROXMOXVEX_NOFILE`             | system hard limit         | Target `RLIMIT_NOFILE` for the process.            |
| `PROXMOXVEX_THREADPOOL_SIZE`    | `50`                      | Size of the gevent threadpool.                     |
| `PROXMOXVEX_NODE_POOL_SIZE`     | `100`                     | Gevent pool for node status calls.                 |
| `PROXMOXVEX_NODE_STATUS_TTL`    | `5` (seconds)             | Cache TTL for node status; set `0` to disable.     |
| `PROXMOXVEX_TASKS_TTL`          | `3` (seconds)             | Cache TTL for task resolution; set `0` to disable. |
| `PROXMOXVEX_SSH_MAX_CONCURRENT` | `25`                      | Maximum concurrent SSH connections.                |
| `PROXMOXVEX_MAX_REQUEST_SIZE`   | `10 MB`                   | Maximum API request body size.                     |
| `PROXMOXVEX_MAX_UPLOAD_SIZE`    | `100 GB`                  | Maximum upload body size.                          |

### Security and Encryption

| Variable                          | Default | Description                                                      |
| --------------------------------- | ------- | ---------------------------------------------------------------- |
| `PROXMOXVEX_DB_KEY`               | unset   | Base64- or hex-encoded 32-byte master key.                       |
| `PROXMOXVEX_KEY_FILE`             | unset   | Filesystem path to the master key.                               |
| `PROXMOXVEX_DISABLE_AUTO_ENCRYPT` | unset   | Set to `1` to skip automatic DB encryption on first boot.        |
| `PROXMOXVEX_VERIFY_SSL`           | `1`     | Set to `0` to disable outbound TLS verification to cluster APIs. |

### Logging and Auditing

| Variable                      | Default | Description                                                  |
| ----------------------------- | ------- | ------------------------------------------------------------ |
| `PROXMOXVEX_LOG_LEVEL`        | unset   | Console logging level (`DEBUG`, `INFO`, `WARNING`, `ERROR`). |
| `PROXMOXVEX_FILE_LOG_LEVEL`   | `DEBUG` | File logging level.                                          |
| `PROXMOXVEX_DISABLE_FILE_LOG` | unset   | Set to `1` to disable file logging.                          |

### Rate Limiting

| Variable                     | Default | Description                       |
| ---------------------------- | ------- | --------------------------------- |
| `PROXMOXVEX_API_RATE_LIMIT`  | `1200`  | Maximum requests per rate window. |
| `PROXMOXVEX_API_RATE_WINDOW` | `60`    | Rate-limit window in seconds.     |

### Consoles

| Variable                         | Default                 | Description                                       |
| -------------------------------- | ----------------------- | ------------------------------------------------- |
| `PROXMOXVEX_VNC_CONNECT_TIMEOUT` | `15` (seconds)          | VNC connect timeout.                              |
| `PROXMOXVEX_SSH_WS_PORT`         | `5002`                  | SSH WebSocket port.                               |
| `PROXMOXVEX_SSH_WS_HOST`         | `127.0.0.1`             | SSH WebSocket bind host.                          |
| `PROXMOXVEX_SSH_WS_SSL_CERT`     | unset                   | SSH WebSocket SSL certificate.                    |
| `PROXMOXVEX_SSH_WS_SSL_KEY`      | unset                   | SSH WebSocket SSL key.                            |
| `PROXMOXVEX_URL`                 | `http://127.0.0.1:5000` | ProxmoxVEx URL used by the SSH WebSocket backend. |

### Internal / Advanced

| Variable                        | Default     | Description                                               |
| ------------------------------- | ----------- | --------------------------------------------------------- |
| `PROXMOXVEX_REMOTE_TMP`         | `/tmp`      | Temporary directory for remote operations.                |
| `PROXMOXVEX_SYSLOG_BIND`        | `127.0.0.1` | Syslog receiver bind address.                             |
| `PROXMOXVEX_SYSLOG_BIND_ALL`    | unset       | Set to `1` to bind the syslog receiver on all interfaces. |
| `PROXMOXVEX_SYSLOG_TCP_MAX`     | `1024`      | Maximum concurrent TCP syslog clients.                    |
| `PROXMOXVEX_HEALTHCHECK_UNSAFE` | unset       | Set to `1` to skip health-check certificate verification. |
| `PROXMOXVEX_PKG_BASE`           | auto        | Custom package base path for plugin loading.              |

## REST API and Monitoring

### REST API

All API routes live under `/api/` and are protected by session cookie or `Authorization: Bearer pgx_<token>` header, except for the public blueprints listed below. API tokens are created in **Settings > API Tokens** and can be scoped to a role.

| Area               | Blueprint prefix                      | Purpose                                          |
| ------------------ | ------------------------------------- | ------------------------------------------------ |
| `auth`             | `/api/auth`                           | Login, logout, 2FA, WebAuthn, password reset     |
| `users`            | `/api/users`                          | User and role management                         |
| `clusters`         | `/api/clusters`                       | Cluster CRUD and credentials                     |
| `vms`              | `/api/vms`                            | VM and container operations, consoles, migration |
| `nodes`            | `/api/nodes`                          | Node status, metrics, and commands               |
| `storage`          | `/api/storage`                        | Storage and Ceph management                      |
| `snapshots`        | `/api/snapshots`                      | Snapshot schedules and retention                 |
| `schedules`        | `/api/schedules`                      | Scheduled tasks                                  |
| `alerts`           | `/api/alerts`                         | Alert rules and channels                         |
| `reports`          | `/api/reports`                        | Cost, power, compliance, CVE reporting           |
| `metrics_exporter` | `/api/metrics`                        | Prometheus OpenMetrics endpoint                  |
| `realtime`         | `/api/sse/updates`, `/api/ws/updates` | SSE and WebSocket live data                      |
| `settings`         | `/api/settings`                       | Server, CORS, and branding settings              |
| `plugins`          | `/api/plugins`                        | Plugin registry and configuration                |

### Public Endpoints

The following blueprints can be accessed without authentication, depending on server settings:

- `/api/auth` (login challenge, WebAuthn attestation)
- `/api/static_files` (frontend assets)
- `/api/sse/updates` (public status page data, when enabled)
- `/api/webauthn` (public attestation options)
- `/api/push` (web push subscription)
- `/api/metrics` (Prometheus; can be toggled public)

### Live Data

- **Server-Sent Events**: `GET /api/sse/updates?token=<sse_token>` for cluster and node metrics.
- **WebSocket**: `GET /api/ws/updates` for low-latency live updates; authenticate with a `session_id` JSON message after connect.

### Prometheus Metrics

Scrape `https://<host>:5000/api/metrics` with an API token:

```bash
curl -H "Authorization: Bearer pgx_<token>" https://proxmoxvex.example.com:5000/api/metrics
```

The endpoint can also be made public in **Settings > Server** if ProxmoxVEx is placed behind a mutual-TLS reverse proxy.

### Health Check

```bash
curl -k https://<host>:5000/api/health
```

## Security

Security is documented in detail in [SECURITY.md](../SECURITY.md) and [docs/SECURITY.md](SECURITY.md). Highlights include:

- **Database encryption at rest**: PostgreSQL volume encryption is the operator's responsibility; field-level Fernet encryption is used for sensitive columns.
- **Master key custody**: Multi-tier key loader supporting `PROXMOXVEX_DB_KEY`, systemd `LoadCredentialEncrypted`, `PROXMOXVEX_KEY_FILE`, and filesystem paths. The key should be backed up separately from `config/`.
- **Password storage**: Argon2id.
- **API token storage**: SHA-256 with constant-time comparison.
- **Transport**: HTTPS for production use; self-signed certificates are generated automatically if no certificate is provided.
- **Session management**: Time-limited sessions, optional IP binding, and per-endpoint rate limiting.
- **Input and access control**: server-side RBAC on every route, origin validation, and input sanitization.

For the full threat model, see [docs/security/threat-model.md](security/threat-model.md).

## Plugins and Extensibility

Plugins are Python packages dropped into `plugins/`. A valid plugin exports a `register(app)` function and a `manifest.json` file that declares routes, frontend iframes, and compatibility. Plugins run in-process and are trusted by default.

Layout:

```text
plugins/{plugin-name}/
├── manifest.json       # Required. Contract metadata.
├── __init__.py         # Required. Must export `register(app)`.
├── ui.html             # Optional. Frontend iframe markup (receives shared plugin-ui.css).
└── config.json         # Optional. Default configuration.
```

`manifest.json` fields include `id`, `name`, `version`, `author`, `description`, `min_ProxmoxVEx`, `has_frontend`, `frontend_route`, `category`, and `min_license_tier`. See [docs/architecture/plugin-contract.md](architecture/plugin-contract.md) for the full contract, sample `register(app)` implementation, and UI rendering rules.

Native integrations include Active Directory, Docker Swarm, NetApp ONTAP, OPNsense, pfSense, Portainer/Rancher, Proxmox Backup Server, TrueNAS, VMware vCenter, VyOS, Zabbix and 60+ plugin extensions covering storage, networking, security, billing and automation.

## Updating and Maintenance

The recommended update path is the `update.sh` script:

```bash
cd /opt/ProxmoxVEx
# replace the host with your ProxmoxVEx instance or project mirror
curl -O https://<your-proxmoxvex-host>/update.sh
chmod +x update.sh
sudo ./update.sh
```

You can also check for updates from the web UI at **Settings > Updates**.

## Troubleshooting

### Cannot reach the web UI

1. Verify the process is running: `sudo systemctl status ProxmoxVEx` or `docker ps`.
2. Check the bind address: by default the server binds `127.0.0.1` unless `PROXMOXVEX_BIND_ALL=true` or `PROXMOXVEX_HOST` is set.
3. Confirm the firewall allows TCP 5000, 5001, and 5002.

### Self-signed certificate warning

A self-signed certificate is generated on first start if no certificate is provided. Replace `config/ssl/cert.pem` and `config/ssl/key.pem` with a trusted certificate, or place ProxmoxVEx behind a reverse proxy that terminates TLS.

### Consoles (noVNC / xterm.js) do not work

- noVNC and the SSH terminal require a valid certificate on the WebSocket ports 5001 and 5002, or a reverse proxy that terminates TLS.
- Ensure ports 5001 and 5002 are reachable from the client.
- Set `PROXMOXVEX_BEHIND_PROXY=true` when running behind nginx and add WebSocket `Upgrade` headers.

### Database encryption

- If the master key is lost, the encrypted database is unreadable. Back up the key separately from `config/`.
- To check the active keystore tier: `python3 ProxmoxVEx_multi_cluster.py --keystore-status`.
- To migrate a plain database manually: `python3 ProxmoxVEx_multi_cluster.py --migrate-db --dry-run`.

### Rate limiting or session issues

- `PROXMOXVEX_API_RATE_LIMIT` and `PROXMOXVEX_API_RATE_WINDOW` control request throttling.
- Sessions expire after inactivity. Enable strict-IP binding in **Settings > Server** if required.

### Low file-descriptor limit

For 20+ clusters, increase the process limit:

```bash
# In the systemd unit override

[Service]
LimitNOFILE=65536
```

or set `PROXMOXVEX_NOFILE=65536`.

## Support and Resources

- **Documentation site:** [proxmoxvex.com](https://proxmoxvex.com/docs)
- **Website:** [proxmoxvex.com](https://proxmoxvex.com)
- **Plugins:** [plugins.proxmoxvex.com](https://plugins.proxmoxvex.com)
- **Support:** [proxmoxvex.com/support](https://proxmoxvex.com/support/)
- **Discord:** [Community Server](https://discord.gg/AJPf3H62QW)
- **Email:** [contact@proxmoxvex.com](mailto:contact@proxmoxvex.com)
