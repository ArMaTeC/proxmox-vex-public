# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        plugins/ipam-manager/__init__.py
# Project:     ProxmoxVEx
# Version:     1.2.437
# Build:       2026.09.12
# Description: IPAM Manager - full UI management backend.
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-12
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""
IPAM Manager - full UI management backend.
Manage subnets and IP reservations.
"""

import ipaddress
import json
import logging
import re
import uuid
from datetime import datetime, timezone
from pathlib import Path

from flask import g, jsonify, request, send_file

from ProxmoxVEx.api.plugins import register_plugin_route

PLUGIN_ID = "ipam-manager"
log = logging.getLogger(f"plugin.{PLUGIN_ID}")

PLUGIN_DIR = Path(__file__).parent
SUBNETS_FILE = PLUGIN_DIR / "subnets.json"
AUDIT_FILE = PLUGIN_DIR / "audit.json"


def _err(code, message, status=400):
    """Stable machine-readable error envelope so clients can branch on `code`."""
    return jsonify({"error": message, "code": code}), status


def _require_manage():
    """Mutations require plugins.manage on top of the proxy's plugins.view gate.

    API tokens are capped at their bound role so a token never outranks the
    role floor it was minted under.
    """
    from ProxmoxVEx.models.permissions import ROLE_ADMIN, ROLE_USER, ROLE_VIEWER
    from ProxmoxVEx.utils.rbac import has_permission

    try:
        user = getattr(g, "current_user", None)
        session = getattr(request, "session", None) or {}
    except RuntimeError:
        user = None
        session = {}
    if user and session.get("api_token"):
        hierarchy = {ROLE_ADMIN: 3, ROLE_USER: 2, ROLE_VIEWER: 1}
        eff = min(hierarchy.get(session.get("role"), 1), hierarchy.get(user.get("role"), 1))
        role = next((r for r, lvl in hierarchy.items() if lvl == eff), ROLE_VIEWER)
        user = {**user, "role": role, "permissions": []}
    if not has_permission(user, "plugins.manage"):
        return _err("forbidden", "Permission denied", 403)
    return None


def _audit(action, target, details=None):
    """Bounded audit ring for subnet/IP mutations (never stores secrets)."""
    try:
        user = getattr(g, "current_user", None) or {}
        actor = user.get("username") or user.get("id") or "system"
    except RuntimeError:
        actor = "system"
    events = []
    try:
        if AUDIT_FILE.exists():
            with open(AUDIT_FILE, encoding="utf-8") as f:
                events = json.load(f)
    except (json.JSONDecodeError, OSError):
        events = []
    events.append({
        "id": uuid.uuid4().hex,
        "ts": datetime.now(timezone.utc).isoformat(),
        "actor": actor,
        "action": action,
        "target": str(target)[:128],
        "details": details or {},
    })
    try:
        with open(AUDIT_FILE, "w", encoding="utf-8") as f:
            json.dump(events[-500:], f, indent=2)
    except OSError as e:
        log.warning("Failed to write audit: %s", e)


_MAC_RE = re.compile(r"^([0-9A-Fa-f]{2}[:-]){5}[0-9A-Fa-f]{2}$")


def _load_state():
    if not SUBNETS_FILE.exists():
        return []
    try:
        with open(SUBNETS_FILE, encoding="utf-8") as f:
            return json.load(f)
    except (json.JSONDecodeError, OSError) as e:
        log.warning("Failed to load state: %s", e)
        return []


def _save_state(data):
    SUBNETS_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(SUBNETS_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)


def _next_ip(network, reservations, specific=None):
    used = {r.get("ip") for r in reservations}
    if specific:
        ip = str(ipaddress.ip_address(specific))
        if ip in used:
            return None
        if ipaddress.ip_address(ip) in network:
            return ip
        return None
    for host in network.hosts():
        ip = str(host)
        if ip not in used:
            return ip
    return None


def _subnet_overlaps(cidr, exclude_id=None):
    try:
        network = ipaddress.ip_network(cidr, strict=False)
    except ValueError:
        return False
    for s in _load_state():
        if exclude_id and s.get("id") == exclude_id:
            continue
        try:
            other = ipaddress.ip_network(s["cidr"], strict=False)
        except ValueError:
            continue
        if network.overlaps(other):
            return True
    return False


def _utilization(subnet):
    try:
        network = ipaddress.ip_network(subnet["cidr"], strict=False)
        total = sum(1 for _ in network.hosts())
        used = len(subnet.get("reservations", []))
        return {
            "total": total,
            "used": used,
            "free": max(0, total - used),
            "pct": round((used / total) * 100, 1) if total else 0,
        }
    except ValueError:
        return {"total": 0, "used": 0, "free": 0, "pct": 0}


def _get_status():
    subnets = _load_state()
    total_ips = sum(len(s.get("reservations", [])) for s in subnets)
    return {
        "plugin": PLUGIN_ID,
        "status": "running",
        "subnets_count": len(subnets),
        "reservations_count": total_ips,
    }


def _subnets_handler():
    method = request.method
    subnets = _load_state()

    if method == "GET":
        subnet_id = request.args.get("id")
        if subnet_id:
            for s in subnets:
                if s.get("id") == subnet_id:
                    s["utilization"] = _utilization(s)
                    return {"data": s}
            return _err("not_found", "Subnet not found", 404)
        family = request.args.get("family")
        for s in subnets:
            s["utilization"] = _utilization(s)
        data = subnets
        if family in ("4", "6"):
            data = [s for s in data if ipaddress.ip_network(s["cidr"], strict=False).version == int(family)]
        sort = request.args.get("sort") or "name"
        order = (request.args.get("order") or "asc").strip()
        rev = order == "desc"
        data.sort(key=lambda s: str(s.get(sort, "")).lower(), reverse=rev)
        return {"data": data}

    if method == "POST":
        denied = _require_manage()
        if denied:
            return denied
        body = request.get_json(silent=True) or {}
        cidr = (body.get("cidr") or "").strip()
        name = (body.get("name") or "").strip()
        if not cidr or not name:
            return _err("missing_field", "'cidr' and 'name' are required")
        if len(name) > 128:
            return _err("invalid_field", "name may not exceed 128 characters")
        try:
            network = ipaddress.ip_network(cidr, strict=False)
        except ValueError as e:
            return _err("invalid_cidr", f"Invalid CIDR: {e}")
        gateway = (body.get("gateway") or "").strip()
        if gateway:
            try:
                if ipaddress.ip_address(gateway) not in network:
                    return _err("invalid_field", "'gateway' must be within the subnet")
            except ValueError:
                return _err("invalid_field", "'gateway' is not a valid IP address")
        if _subnet_overlaps(cidr):
            return _err("conflict", "Subnet overlaps an existing subnet", 409)
        subnet = {
            "id": str(uuid.uuid4()),
            "name": name,
            "cidr": cidr,
            "gateway": gateway,
            "network": str(network),
            "reservations": [],
        }
        subnets.append(subnet)
        _save_state(subnets)
        _audit("subnet.create", subnet["id"], {"cidr": cidr, "name": name})
        subnet["utilization"] = _utilization(subnet)
        return {"data": subnet}

    if method == "PUT":
        denied = _require_manage()
        if denied:
            return denied
        body = request.get_json(silent=True) or {}
        subnet_id = body.get("id")
        if not subnet_id:
            return _err("missing_id", "'id' is required")
        for s in subnets:
            if s.get("id") == subnet_id:
                name = (body.get("name") or s.get("name")).strip()
                gateway = (body.get("gateway") or s.get("gateway")).strip()
                cidr = (body.get("cidr") or s.get("cidr")).strip()
                try:
                    network = ipaddress.ip_network(cidr, strict=False)
                except ValueError as e:
                    return _err("invalid_cidr", f"Invalid CIDR: {e}")
                if gateway:
                    try:
                        if ipaddress.ip_address(gateway) not in network:
                            return _err("invalid_field", "'gateway' must be within the subnet")
                    except ValueError:
                        return _err("invalid_field", "'gateway' is not a valid IP address")
                if cidr != s.get("cidr") and _subnet_overlaps(cidr, exclude_id=subnet_id):
                    return _err("conflict", "Subnet overlaps an existing subnet", 409)
                s["name"] = name
                s["gateway"] = gateway
                s["cidr"] = cidr
                s["network"] = str(network)
                _save_state(subnets)
                _audit("subnet.update", subnet_id, {"cidr": cidr})
                s["utilization"] = _utilization(s)
                return {"data": s}
        return _err("not_found", "Subnet not found", 404)

    if method == "DELETE":
        denied = _require_manage()
        if denied:
            return denied
        subnet_id = request.args.get("id") or (request.get_json(silent=True) or {}).get("id")
        if not subnet_id:
            return _err("missing_id", "'id' is required")
        for idx, s in enumerate(subnets):
            if s.get("id") == subnet_id:
                if s.get("reservations"):
                    return _err("conflict", "Subnet has reservations", 409)
                subnets.pop(idx)
                _save_state(subnets)
                _audit("subnet.delete", subnet_id, {"cidr": s.get("cidr")})
                return {"deleted": subnet_id}
        return _err("not_found", "Subnet not found", 404)

    return _err("method_not_allowed", "Method not allowed", 405)


def _ips_handler():
    method = request.method
    if method == "GET":
        subnet_id = request.args.get("subnet_id")
        subnets = _load_state()
        result = []
        for s in subnets:
            if not subnet_id or s.get("id") == subnet_id:
                result.extend([{"subnet_id": s["id"], **r} for r in s.get("reservations", [])])
        return {"data": result}

    if method == "POST":
        denied = _require_manage()
        if denied:
            return denied
        body = request.get_json(silent=True) or {}
        action = (body.get("action") or "").strip().lower()
        if action not in ("reserve", "release"):
            return _err("invalid_action", "'action' must be 'reserve' or 'release'")

        subnets = _load_state()

        if action == "reserve":
            subnet_id = body.get("subnet_id")
            if not subnet_id:
                return _err("missing_field", "'subnet_id' is required")
            mac = (body.get("mac") or "").strip()
            if mac and not _MAC_RE.match(mac):
                return _err("invalid_field", "'mac' must be a valid MAC address")
            specific = (body.get("ip") or "").strip()
            if specific:
                try:
                    ipaddress.ip_address(specific)
                except ValueError:
                    return _err("invalid_field", "'ip' is not a valid IP address")
            for s in subnets:
                if s.get("id") == subnet_id:
                    try:
                        network = ipaddress.ip_network(s["cidr"], strict=False)
                    except ValueError:
                        return _err("invalid_state", "Subnet CIDR is invalid", 500)
                    ip = _next_ip(network, s.get("reservations", []), specific or None)
                    if not ip:
                        return _err("conflict", "No free IPs in subnet", 409)
                    reservation = {
                        "id": str(uuid.uuid4()),
                        "ip": ip,
                        "label": (body.get("label") or "").strip()[:128],
                        "mac": mac,
                        "status": "reserved",
                    }
                    s.setdefault("reservations", []).append(reservation)
                    _save_state(subnets)
                    _audit("ip.reserve", reservation["id"], {"ip": ip, "subnet_id": subnet_id})
                    return {"data": reservation}
            return _err("not_found", "Subnet not found", 404)

        # release
        ip_id = body.get("ip_id") or body.get("id")
        ip = body.get("ip")
        if not ip_id and not ip:
            return _err("missing_field", "'ip_id' or 'ip' is required")
        for s in subnets:
            for idx, r in enumerate(s.get("reservations", [])):
                if (ip_id and r.get("id") == ip_id) or (ip and r.get("ip") == ip):
                    s["reservations"].pop(idx)
                    _save_state(subnets)
                    _audit("ip.release", r.get("id"), {"ip": r.get("ip")})
                    return {"released": r}
        return _err("not_found", "Reservation not found", 404)

    return _err("method_not_allowed", "Method not allowed", 405)


def _get_ui():
    """Serve the IPAM Manager HTML interface"""
    return send_file(PLUGIN_DIR / "ui.html", mimetype="text/html")


def register(app):
    register_plugin_route(PLUGIN_ID, "status", _get_status)
    register_plugin_route(PLUGIN_ID, "subnets", _subnets_handler)
    register_plugin_route(PLUGIN_ID, "ips", _ips_handler)
    register_plugin_route(PLUGIN_ID, "ui", _get_ui)
    log.info("[%s] Plugin registered", PLUGIN_ID)
