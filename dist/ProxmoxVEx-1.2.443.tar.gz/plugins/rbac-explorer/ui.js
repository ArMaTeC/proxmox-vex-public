/* --- ProxmoxVEx auto-header start ---
 * -------------------------------------------------------------------
 * File:        plugins/rbac-explorer/ui.js
 * Project:     ProxmoxVEx
 * Version:     1.2.437
 * Build:       2026.09.12
 * Description: Ui JS source
 * Docs:        https://proxmoxvex.com/docs
 * Generated:   2026-09-12
 * -------------------------------------------------------------------
 * --- ProxmoxVEx auto-header end --- */
const base = '/api/plugins/rbac-explorer';
const $ = (id) => document.getElementById(id);

const i18n = window.parent && window.parent.ProxmoxVExI18n;
// English fallback so the UI stays readable when rendered standalone
// (no parent i18n bridge), e.g. direct navigation or e2e smoke tests.
const EN_FALLBACK = {
    loading: 'Loading...', rbacExplorer: 'RBAC Explorer', createRole: 'Create Role',
    roles: 'Roles', users: 'Users', tenants: 'Tenants', permissions: 'Permissions', audit: 'Audit',
    id: 'ID', name: 'Name', actions: 'Actions', create: 'Create', save: 'Save', reset: 'Reset',
    delete: 'Delete', edit: 'Edit', roleIdPlaceholder: 'role-id', roleNamePlaceholder: 'Role name',
    rolePermsPlaceholder: 'vm.view,lxc.view', idAndNameRequired: 'id and name are required',
    roleCreated: 'Role created', roleDeleted: 'Role deleted', roleUpdated: 'Role updated',
    deleteRoleConfirm: 'Delete role {id}?', error: 'Error: {msg}',
    noRoles: 'No roles.', noUsers: 'No users.', noTenants: 'No tenants.', noPerms: 'No permissions.',
    noAudit: 'No audit events.', retry: 'Retry', loadError: 'Failed to load data.',
    username: 'Username', role: 'Role', action: 'Action', target: 'Target', actor: 'Actor',
    time: 'Time', effectivePerms: 'Effective Permissions', statusError: 'Error',
};
const t = (k, p) => {
    let s;
    if (i18n) s = i18n.getT('rbac-explorer')(k, p ? { params: p } : undefined);
    if (!s || s === k) {
        s = EN_FALLBACK[k] || k;
        if (p) Object.keys(p).forEach(key => { s = s.replaceAll(`{${key}}`, p[key]); });
    }
    return s;
};
if (i18n) i18n.loadPluginNamespaceFull('rbac-explorer', '/api/plugins/rbac-explorer/i18n');

function toast(message, type = 'success') {
    const el = document.createElement('div');
    el.className = `message ${type}`;
    el.textContent = message;
    $('toasts').appendChild(el);
    setTimeout(() => el.remove(), 4000);
}

function esc(text) {
    const div = document.createElement('div');
    div.textContent = text == null ? '' : text;
    return div.innerHTML;
}

function setLoading(id) { $(id).innerHTML = `<p class="empty">${esc(t('loading'))}</p>`; }
// Error state keeps a working Retry button instead of leaving a stale/blank panel.
function setLoadError(id, retry) {
    const c = $(id); c.innerHTML = '';
    const p = document.createElement('p'); p.className = 'empty'; p.textContent = t('loadError');
    const b = document.createElement('button'); b.className = 'secondary'; b.textContent = t('retry');
    b.addEventListener('click', retry);
    c.appendChild(p); c.appendChild(b);
}

async function fetchJson(path, options = {}) {
    const res = await fetch(`${base}/${path}`, { credentials: 'same-origin', ...options });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(data.error || `HTTP ${res.status}`);
    return data;
}

function applyI18n() {
    document.querySelectorAll('[data-i18n]').forEach(el => { el.textContent = t(el.dataset.i18n); });
    document.querySelectorAll('[data-i18n-ph]').forEach(el => { el.placeholder = t(el.dataset.i18nPh); });
}

async function loadStatus() {
    try {
        const data = await fetchJson('status');
        $('status').textContent = `${data.status} | ${data.roles_count} ${t('roles').toLowerCase()}`;
    } catch (e) { $('status').textContent = t('statusError'); }
}

const state = { roles: [] };

async function loadRoles() {
    setLoading('rolesList');
    try {
        const data = await fetchJson('roles');
        state.roles = data.roles || [];
        const c = $('rolesList');
        if (!state.roles.length) { c.innerHTML = `<p class="empty">${esc(t('noRoles'))}</p>`; return; }
        let html = `<table><thead><tr><th scope="col">${esc(t('id'))}</th><th scope="col">${esc(t('name'))}</th><th scope="col">${esc(t('permissions'))}</th><th scope="col">${esc(t('actions'))}</th></tr></thead><tbody>`;
        for (const role of state.roles) {
            html += `<tr>
                    <td class="muted">${esc(role.id)}</td>
                    <td class="muted">${esc(role.name)}</td>
                    <td class="muted">${esc((role.permissions || []).join(', '))}</td>
                    <td class="actions">
                        <button class="secondary" data-edit="${esc(role.id)}">${esc(t('edit'))}</button>
                        <button class="danger" data-del="${esc(role.id)}">${esc(t('delete'))}</button>
                    </td>
                </tr>`;
        }
        c.innerHTML = DOMPurify.sanitize(html + '</tbody></table>');
        c.querySelectorAll('button[data-edit]').forEach(btn => btn.addEventListener('click', () => editRole(btn.dataset.edit)));
        c.querySelectorAll('button[data-del]').forEach(btn => btn.addEventListener('click', () => deleteRole(btn.dataset.del)));
    } catch (e) { setLoadError('rolesList', loadRoles); toast(t('error', { msg: e.message }), 'error'); }
}

function editRole(id) {
    const role = state.roles.find(r => r.id === id);
    if (!role) return;
    $('roleEditId').value = role.id;
    $('roleId').value = role.id;
    $('roleId').disabled = true;
    $('roleName').value = role.name;
    $('rolePerms').value = (role.permissions || []).join(', ');
}

function resetForm() {
    $('roleForm').reset();
    $('roleEditId').value = '';
    $('roleId').disabled = false;
    $('roleError').textContent = '';
}

async function saveRole(e) {
    e.preventDefault();
    $('roleError').textContent = '';
    const editing = $('roleEditId').value;
    const id = $('roleId').value.trim();
    const name = $('roleName').value.trim();
    const perms = $('rolePerms').value.split(',').map(s => s.trim()).filter(Boolean);
    if (!id || !name) { $('roleError').textContent = t('idAndNameRequired'); return; }
    const body = JSON.stringify({ id, name, permissions: perms });
    try {
        if (editing) {
            await fetchJson('update', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body });
            toast(t('roleUpdated'));
        } else {
            await fetchJson('create', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body });
            toast(t('roleCreated'));
        }
        resetForm();
        loadStatus();
        loadRoles();
    } catch (err) { $('roleError').textContent = err.message; toast(t('error', { msg: err.message }), 'error'); }
}

async function deleteRole(id) {
    if (!confirm(t('deleteRoleConfirm', { id }))) return;
    try {
        await fetchJson('delete', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id }) });
        toast(t('roleDeleted'));
        loadStatus();
        loadRoles();
    } catch (err) { toast(t('error', { msg: err.message }), 'error'); }
}

async function loadUsers() {
    setLoading('usersList');
    try {
        const data = await fetchJson('users');
        const rows = data.users || [];
        const c = $('usersList');
        if (!rows.length) { c.innerHTML = `<p class="empty">${esc(t('noUsers'))}</p>`; return; }
        let html = `<table><thead><tr><th scope="col">${esc(t('id'))}</th><th scope="col">${esc(t('username'))}</th><th scope="col">${esc(t('role'))}</th></tr></thead><tbody>`;
        rows.forEach(u => { html += `<tr><td class="muted">${esc(u.id)}</td><td class="muted">${esc(u.username)}</td><td class="muted">${esc(u.role)}</td></tr>`; });
        c.innerHTML = DOMPurify.sanitize(html + '</tbody></table>');
    } catch (e) { setLoadError('usersList', loadUsers); toast(t('error', { msg: e.message }), 'error'); }
}

async function loadTenants() {
    setLoading('tenantsList');
    try {
        const data = await fetchJson('tenants');
        const rows = data.tenants || [];
        const c = $('tenantsList');
        if (!rows.length) { c.innerHTML = `<p class="empty">${esc(t('noTenants'))}</p>`; return; }
        let html = `<table><thead><tr><th scope="col">${esc(t('id'))}</th><th scope="col">${esc(t('name'))}</th></tr></thead><tbody>`;
        rows.forEach(u => { html += `<tr><td class="muted">${esc(u.id)}</td><td class="muted">${esc(u.name)}</td></tr>`; });
        c.innerHTML = DOMPurify.sanitize(html + '</tbody></table>');
    } catch (e) { setLoadError('tenantsList', loadTenants); toast(t('error', { msg: e.message }), 'error'); }
}

async function loadPerms() {
    setLoading('permsList');
    try {
        const data = await fetchJson('permissions');
        const rows = data.permissions || [];
        const c = $('permsList');
        if (!rows.length) { c.innerHTML = `<p class="empty">${esc(t('noPerms'))}</p>`; return; }
        c.innerHTML = DOMPurify.sanitize(`<ul>${rows.map(p => `<li class="muted">${esc(p)}</li>`).join('')}</ul>`);
    } catch (e) { setLoadError('permsList', loadPerms); toast(t('error', { msg: e.message }), 'error'); }
}

async function loadAudit() {
    setLoading('auditList');
    try {
        const data = await fetchJson('audit');
        const rows = data.data || [];
        const c = $('auditList');
        if (!rows.length) { c.innerHTML = `<p class="empty">${esc(t('noAudit'))}</p>`; return; }
        let html = `<table><thead><tr><th scope="col">${esc(t('action'))}</th><th scope="col">${esc(t('target'))}</th><th scope="col">${esc(t('actor'))}</th><th scope="col">${esc(t('time'))}</th></tr></thead><tbody>`;
        rows.forEach(a => { html += `<tr><td class="muted">${esc(a.action)}</td><td class="muted">${esc(a.target)}</td><td class="muted">${esc(a.actor || '—')}</td><td class="muted">${a.at ? new Date(a.at).toLocaleString() : '—'}</td></tr>`; });
        c.innerHTML = DOMPurify.sanitize(html + '</tbody></table>');
    } catch (e) { setLoadError('auditList', loadAudit); toast(t('error', { msg: e.message }), 'error'); }
}

function switchTab(name) {
    document.querySelectorAll('.tab').forEach(tb => tb.setAttribute('aria-selected', String(tb.dataset.tab === name)));
    document.querySelectorAll('.tab-panel').forEach(p => { p.hidden = (p.id !== 'panel-' + name); });
    if (name === 'users') loadUsers();
    if (name === 'tenants') loadTenants();
    if (name === 'perms') loadPerms();
    if (name === 'audit') loadAudit();
}

function wireEvents() {
    document.querySelectorAll('.tab').forEach(tb => tb.addEventListener('click', () => switchTab(tb.dataset.tab)));
    $('roleForm').addEventListener('submit', saveRole);
    $('roleReset').addEventListener('click', resetForm);
}

(async () => {
    if (i18n) await i18n.loadPluginNamespaceFull('rbac-explorer', '/api/plugins/rbac-explorer/i18n');
    applyI18n();
    wireEvents();
    loadStatus();
    loadRoles();
})();
