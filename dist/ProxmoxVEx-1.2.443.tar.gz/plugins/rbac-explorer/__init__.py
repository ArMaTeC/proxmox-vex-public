# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        plugins/rbac-explorer/__init__.py
# Project:     ProxmoxVEx
# Version:     1.2.437
# Build:       2026.09.12
# Description: RBAC Explorer - full UI management backend.
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-12
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""RBAC Explorer - full UI management backend."""

import json
import logging
import re
from datetime import datetime, timezone
from pathlib import Path

from flask import g, jsonify, request, send_file

from ProxmoxVEx.api.plugins import register_plugin_route

PLUGIN_ID = "rbac-explorer"
log = logging.getLogger(f"plugin.{PLUGIN_ID}")
PLUGIN_DIR = Path(__file__).parent
DATA_FILE = PLUGIN_DIR / "state.json"

DEFAULT_STATE = {
    "roles": [
        {"id": "admin", "name": "Admin", "permissions": ["*"]},
        {"id": "user", "name": "User", "permissions": ["vm.view", "lxc.view"]},
        {"id": "viewer", "name": "Viewer", "permissions": ["vm.view"]},
    ],
    "users": [
        {"id": "admin", "username": "admin", "role": "admin"},
    ],
    "tenants": [
        {"id": "default", "name": "Default"},
    ],
}


def _err(code, message, status=400):
    """Stable machine-readable error envelope so clients can branch on `code`."""
    return jsonify({"error": message, "code": code}), status


def _require_manage():
    """Role mutations require plugins.manage on top of the proxy's plugins.view.

    The shared plugin proxy only enforces the read-level permission declared on
    the catch-all route, so write handlers re-check here. API tokens are capped
    at their bound role so a token never outranks its role floor.
    """
    from ProxmoxVEx.models.permissions import ROLE_ADMIN, ROLE_USER, ROLE_VIEWER
    from ProxmoxVEx.utils.rbac import has_permission

    try:
        user = getattr(g, "current_user", None)
        session = getattr(request, "session", None) or {}
    except RuntimeError:
        user = None
        session = {}
    if user and session.get("api_token"):
        hierarchy = {ROLE_ADMIN: 3, ROLE_USER: 2, ROLE_VIEWER: 1}
        eff = min(hierarchy.get(session.get("role"), 1), hierarchy.get(user.get("role"), 1))
        role = next((r for r, lvl in hierarchy.items() if lvl == eff), ROLE_VIEWER)
        user = {**user, "role": role, "permissions": []}
    if not has_permission(user, "plugins.manage"):
        return _err("forbidden", "Permission denied", 403)
    return None


def _actor():
    try:
        user = getattr(g, "current_user", None) or {}
        return user.get("username") or user.get("id") or "system"
    except RuntimeError:
        return "system"


def _audit(state, action, target, detail=None):
    """Append an audit entry; role changes must be attributable for recovery."""
    state.setdefault("audit", []).insert(0, {
        "action": action,
        "target": target,
        "actor": _actor(),
        "at": datetime.now(timezone.utc).isoformat(),
        "detail": detail or {},
    })
    state["audit"] = state["audit"][:1000]


_ROLE_ID_RE = re.compile(r"^[a-zA-Z0-9_-]{1,64}$")


def _valid_permissions(perms):
    return isinstance(perms, list) and all(
        isinstance(p, str) and re.match(r"^[a-zA-Z0-9_.*-]{1,64}$", p) for p in perms
    )


def _load_state():
    if not DATA_FILE.exists():
        return json.loads(json.dumps(DEFAULT_STATE))
    try:
        with open(DATA_FILE, encoding="utf-8") as f:
            data = json.load(f)
    except (json.JSONDecodeError, OSError) as e:
        log.warning("[%s] Failed to load state: %s", PLUGIN_ID, e)
        return json.loads(json.dumps(DEFAULT_STATE))
    for key, value in DEFAULT_STATE.items():
        if key not in data:
            data[key] = value
    return data


def _save_state(data):
    try:
        DATA_FILE.parent.mkdir(parents=True, exist_ok=True)
        with open(DATA_FILE, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)
    except OSError as e:
        log.error("[%s] Failed to save state: %s", PLUGIN_ID, e)


def _get_status():
    state = _load_state()
    return {
        "plugin": PLUGIN_ID,
        "status": "running",
        "roles_count": len(state.get("roles", [])),
        "users_count": len(state.get("users", [])),
        "tenants_count": len(state.get("tenants", [])),
        "routes": ["status", "roles", "users", "permissions", "tenants"],
    }


def _get_roles():
    state = _load_state()
    return {"roles": state.get("roles", [])}


def _get_users():
    state = _load_state()
    return {"users": state.get("users", [])}


def _get_tenants():
    state = _load_state()
    return {"tenants": state.get("tenants", [])}


def _get_permissions():
    state = _load_state()
    perms = set()
    for role in state.get("roles", []):
        perms.update(role.get("permissions", []))
    return {"permissions": sorted(perms)}


def _create_role():
    denied = _require_manage()
    if denied:
        return denied
    body = request.get_json(silent=True) or {}
    role_id = (body.get("id") or "").strip()
    name = (body.get("name") or "").strip()
    permissions = body.get("permissions") or []
    if not role_id or not name:
        return _err("missing_field", "id and name are required")
    if not _ROLE_ID_RE.match(role_id):
        return _err("invalid_id", "role id must be 1-64 chars of [a-zA-Z0-9_-]")
    if not _valid_permissions(permissions):
        return _err("invalid_permissions", "permissions must be a list of permission strings")
    state = _load_state()
    if any(r["id"] == role_id for r in state["roles"]):
        return _err("conflict", "role already exists", 409)
    state["roles"].append({"id": role_id, "name": name, "permissions": permissions})
    _audit(state, "role.create", role_id, {"name": name})
    _save_state(state)
    return {"role": state["roles"][-1]}


def _update_role():
    denied = _require_manage()
    if denied:
        return denied
    body = request.get_json(silent=True) or {}
    role_id = (body.get("id") or "").strip()
    if not role_id:
        return _err("missing_id", "id is required")
    state = _load_state()
    for role in state.get("roles", []):
        if role.get("id") == role_id:
            role["name"] = (body.get("name") or role["name"]).strip()
            if "permissions" in body:
                if not _valid_permissions(body.get("permissions")):
                    return _err("invalid_permissions", "permissions must be a list of permission strings")
                role["permissions"] = body.get("permissions")
            _audit(state, "role.update", role_id, {"name": role["name"]})
            _save_state(state)
            return {"role": role}
    return _err("not_found", "role not found", 404)


def _delete_role():
    denied = _require_manage()
    if denied:
        return denied
    body = request.get_json(silent=True) or {}
    role_id = (body.get("id") or "").strip()
    if not role_id:
        return _err("missing_id", "id is required")
    state = _load_state()
    before = len(state.get("roles", []))
    state["roles"] = [r for r in state.get("roles", []) if r.get("id") != role_id]
    if len(state["roles"]) == before:
        return _err("not_found", "role not found", 404)
    _audit(state, "role.delete", role_id)
    _save_state(state)
    return {"deleted": role_id}


def _get_audit():
    state = _load_state()
    return {"data": state.get("audit", [])[:200]}


def _get_ui():
    """Serve the RBAC Explorer HTML interface"""
    return send_file(PLUGIN_DIR / "ui.html", mimetype="text/html")


def register(app):
    register_plugin_route(PLUGIN_ID, "status", _get_status)
    register_plugin_route(PLUGIN_ID, "roles", _get_roles)
    register_plugin_route(PLUGIN_ID, "users", _get_users)
    register_plugin_route(PLUGIN_ID, "permissions", _get_permissions)
    register_plugin_route(PLUGIN_ID, "tenants", _get_tenants)
    register_plugin_route(PLUGIN_ID, "create", _create_role)
    register_plugin_route(PLUGIN_ID, "update", _update_role)
    register_plugin_route(PLUGIN_ID, "delete", _delete_role)
    register_plugin_route(PLUGIN_ID, "audit", _get_audit)
    register_plugin_route(PLUGIN_ID, "ui", _get_ui)
    log.info("[PLUGINS] %s plugin registered", PLUGIN_ID)
