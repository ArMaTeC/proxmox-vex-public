/* --- ProxmoxVEx auto-header start ---
 * -------------------------------------------------------------------
 * File:        web/src/noise.js
 * Project:     ProxmoxVEx
 * Version:     1.2.403
 * Build:       2026.09.09
 * Description: Noise JS source
 * Docs:        https://proxmoxvex.local/docs
 * Generated:   2026-09-09
 * -------------------------------------------------------------------
 * --- ProxmoxVEx auto-header end --- */
try { if (localStorage.getItem('ProxmoxVEx-noise') === 'off') document.body.setAttribute('data-noise', 'off'); } catch (_) { }
