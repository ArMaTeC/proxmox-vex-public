# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/native/vyos/vyos_src/__init__.py
# Project:     ProxmoxVEx
# Version:     1.2.403
# Build:       2026.09.09
# Description: VyOS source package.
# Docs:        https://proxmoxvex.local/docs
# Generated:   2026-09-09
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""VyOS source package."""

from __future__ import annotations
