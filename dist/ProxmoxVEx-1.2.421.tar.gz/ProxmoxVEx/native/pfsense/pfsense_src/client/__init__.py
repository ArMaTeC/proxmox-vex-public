# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/native/pfsense/pfsense_src/client/__init__.py
# Project:     ProxmoxVEx
# Version:     1.2.403
# Build:       2026.09.09
# Description: Package initializer for client
# Docs:        https://proxmoxvex.local/docs
# Generated:   2026-09-09
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
from .pfsense_client import (  # noqa: F401
    PFsenseAuthError,
    PFsenseClient,
    PFsenseError,
    PFsenseHost,
    PFsenseTimeoutError,
)
