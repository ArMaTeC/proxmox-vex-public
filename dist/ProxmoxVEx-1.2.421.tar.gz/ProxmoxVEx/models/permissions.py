# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/models/permissions.py
# Project:     ProxmoxVEx
# Version:     1.2.403
# Build:       2026.09.09
# Description: ProxmoxVEx Permissions & Roles - Layer 0
# Docs:        https://proxmoxvex.local/docs
# Generated:   2026-09-09
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""
ProxmoxVEx Permissions & Roles - Layer 0
No ProxmoxVEx imports allowed.
"""

# User roles
ROLE_ADMIN = "admin"
ROLE_USER = "user"
ROLE_VIEWER = "viewer"

# Builtin roles - cannot be deleted
BUILTIN_ROLES = [ROLE_ADMIN, ROLE_USER, ROLE_VIEWER]

PERMISSIONS = {
    # vm stuff
    "vm.view": "View VMs and containers",
    "vm.start": "Start VMs and containers",
    "vm.stop": "Stop VMs and containers",
    "vm.restart": "Restart VMs and containers",
    "vm.console": "Access VM console",
    "vm.migrate": "Migrate VMs between nodes",
    "vm.clone": "Clone VMs",
    "vm.delete": "Delete VMs and containers",
    "vm.create": "Create new VMs and containers",
    "vm.config": "Modify VM configuration",
    "vm.snapshot": "Create/delete snapshots",
    "vm.backup": "Backup VMs",
    "vm.template": "Convert to/from template",
    # Converter permissions
    "converter.view": "View conversion/resize jobs and presets",
    "converter.run": "Run conversion/resize jobs",
    "converter.admin": "Manage converter presets, hooks, and cancel any job",
    # Cluster permissions
    "cluster.view": "View cluster info",
    "cluster.add": "Add new clusters",
    "cluster.delete": "Remove clusters",
    "cluster.config": "Modify cluster settings",
    "cluster.join": "Join nodes to cluster",
    "cluster.admin": "Full cluster administration (join/remove nodes)",
    # Node permissions
    "node.view": "View node status",
    "node.shell": "Access node shell",
    "node.maintenance": "Toggle maintenance mode",
    "node.update": "Update node packages",
    "node.reboot": "Reboot nodes",
    "node.network": "Modify network config",
    "node.config": "Change node options",
    "node.certificate": "Manage SSL certificates",
    "node.power": "Shutdown/wake nodes",
    # Storage permissions
    "storage.view": "View storage",
    "storage.upload": "Upload files to storage",
    "storage.delete": "Delete files from storage",
    "storage.config": "Modify storage config",
    "storage.create": "Add new storage",
    "storage.download": "Download ISOs/templates",
    # Backup permissions
    "backup.view": "View backups",
    "backup.create": "Create backups",
    "backup.restore": "Restore from backup",
    "backup.delete": "Delete backups",
    "backup.schedule": "Manage backup schedules",
    "backup.config": "Configure backup storage",
    # HA permissions
    "ha.view": "View HA status",
    "ha.config": "Configure HA settings",
    "ha.groups": "Manage HA groups",
    "ha.resources": "Add/remove HA resources",
    # Firewall permissions
    "firewall.view": "View firewall rules",
    "firewall.edit": "Modify firewall rules",
    "firewall.aliases": "Manage aliases/IPsets",
    # Pool/Resource permissions
    "pool.view": "View resource pools",
    "pool.manage": "Create/delete pools",
    "pool.assign": "Assign VMs to pools",
    # Replication
    "replication.view": "View replication jobs",
    "replication.manage": "Create/delete replication",
    # Ceph
    "ceph.manage": "Manage Ceph OSD, pools, monitors, MDS",
    # SDN
    "sdn.manage": "Manage SDN zones, vnets, subnets, controllers",
    # Alerts
    "alert.manage": "Create, edit, delete alert rules",
    # IDS/IPS permissions
    "ids.view": "View IDS/IPS alerts, rules, and reports",
    "ids.rules": "Create, edit, and delete IDS/IPS detection rules",
    "ids.policies": "Create, edit, and delete IDS/IPS response policies",
    "ids.admin": "Manage IDS/IPS configuration and monitored segments",
    # Site Recovery - Mar 2026
    "site_recovery.view": "View recovery plans and events",
    "site_recovery.manage": "Create/edit/delete recovery plans and VMs",
    "site_recovery.failover": "Execute failover, failback and test operations",
    # Terraform / IaC permissions
    "terraform.view": "View Terraform exports",
    "terraform.export": "Export cluster state to Terraform HCL",
    # Ansible / IaC permissions
    "ansible.view": "View Ansible exports",
    "ansible.export": "Export cluster state to Ansible playbooks",
    # Packer / IaC permissions
    "packer.view": "View Packer sync status",
    "packer.sync": "Sync Packer templates and images",
    "packer.import": "Import Packer templates and images",
    "packer.library": "View Packer template library",
    "packer.widget": "View Packer dashboard widget",
    "packer.alerts": "Manage Packer alert channel",
    "packer.policy": "Manage Packer policy adapter",
    "packer.roles": "Manage Packer role mapping",
    "packer.workflow": "Manage Packer automation workflow",
    # Kubernetes / integrations permissions
    "kubernetes.view": "View Kubernetes clusters and resources",
    "kubernetes.export": "Export cluster state to Kubernetes manifests",
    "kubernetes.connector": "Manage Kubernetes connector configuration",
    "kubernetes.sync": "Sync cluster state to Kubernetes",
    "kubernetes.import": "Import Kubernetes manifests into the cluster",
    "kubernetes.library": "View Kubernetes template library",
    "kubernetes.widget": "View Kubernetes dashboard widget",
    "kubernetes.dashboard": "View Kubernetes dashboard widget",
    "kubernetes.alerts": "Manage Kubernetes alert channel",
    "kubernetes.policy": "Manage Kubernetes policy adapter",
    "kubernetes.roles": "Manage Kubernetes role mapping",
    "kubernetes.workflow": "Manage Kubernetes automation workflow",
    # Docker / integrations permissions
    "docker.export": "Export cluster state to Docker assets",
    "docker.connector": "Manage Docker connector configuration",
    # Plugin permissions
    "plugins.view": "View installed plugins",
    "plugins.manage": "Enable, disable and configure plugins",
    # LDAP permissions
    "ldap.export": "Export cluster state to LDAP assets",
    "ldap.connector": "Manage LDAP connector configuration",
    "ldap.sync": "Sync users from LDAP",
    "ldap.import": "Import users from LDAP",
    "ldap.templates": "Manage LDAP templates",
    "ldap.widget": "View LDAP dashboard widget",
    "ldap.alert": "Manage LDAP alert channel",
    "ldap.policy": "Manage LDAP policy adapter",
    "ldap.role_mapping": "Manage LDAP role mapping",
    "ldap.workflow": "Manage LDAP automation workflows",
    # Active Directory permissions
    "active_directory.export": "Export cluster state to Active Directory assets",
    "active_directory.connector": "Manage Active Directory connector configuration",
    "active_directory.sync": "Sync users from Active Directory",
    "active_directory.import": "Import users from Active Directory",
    "active_directory.templates": "Manage Active Directory templates",
    "active_directory.widget": "View Active Directory dashboard widget",
    "active_directory.alert": "Manage Active Directory alert channel",
    "active_directory.policy": "Manage Active Directory policy adapter",
    "active_directory.role_mapping": "Manage Active Directory role mapping",
    "active_directory.workflow": "Manage Active Directory automation workflows",
    "vault.export": "Export cluster state to Vault",
    "vault.connector": "Manage Vault connector configuration",
    # Admin permissions
    "admin.users": "Manage users",
    "admin.roles": "Manage custom roles",
    "admin.tenants": "Manage tenants",
    "admin.groups": "Manage cluster groups",
    "admin.settings": "Modify system settings",
    "admin.scripts": "Manage and execute custom scripts",
    "admin.audit": "View audit logs",
    "admin.api": "Manage API tokens",
    # Security permissions (2026-06-10: RBAC-ification of admin-only endpoints)
    "security.lockout.view": "View IP / user brute-force lockouts",
    "security.lockout.manage": "Clear IP / user lockouts and reset password expiry",
    "security.settings.manage": "Edit security settings (IP whitelist, CORS, key rotation, compliance)",
    "update.manage": "Run and configure the in-app updater",
    # PBS permissions
    "pbs.view": "View PBS servers and datastores",
    "pbs.config": "Modify PBS server settings",
    "pbs.datastore.view": "View datastore details and snapshots",
    "pbs.datastore.create": "Create new datastores on PBS",
    "pbs.datastore.modify": "Modify datastore configuration",
    "pbs.datastore.delete": "Delete datastores from PBS",
    "pbs.datastore.gc": "Run garbage collection on datastores",
    "pbs.datastore.verify": "Run verification on datastores",
    "pbs.datastore.prune": "Prune snapshots from datastores",
    "pbs.snapshot.delete": "Delete individual snapshots",
    "pbs.snapshot.protect": "Toggle snapshot protection",
    "pbs.snapshot.notes": "Edit snapshot/group notes",
    "pbs.snapshot.browse": "Browse and download snapshot files",
    "pbs.jobs.view": "View sync/verify/prune jobs",
    "pbs.jobs.run": "Manually trigger jobs",
    "pbs.tasks.view": "View PBS tasks",
    "pbs.tasks.stop": "Stop running PBS tasks",
    "pbs.jobs.create": "Create sync/verify/prune jobs",
    "pbs.jobs.modify": "Modify existing jobs",
    "pbs.jobs.delete": "Delete jobs",
    "pbs.notifications.view": "View notification config",
    "pbs.notifications.manage": "Create/modify/delete notifications",
    "pbs.traffic.view": "View traffic control config",
    "pbs.traffic.manage": "Create/modify/delete traffic controls",
    "pbs.disks.view": "View disk information",
    "pbs.disks.smart": "View disk SMART data",
    "pbs.subscription.view": "View subscription status",
    "pbs.subscription.set": "Set subscription key",
    # VMware/vCenter permissions
    "vmware.view": "View vCenter/ESXi servers",
    "vmware.config": "Add/edit/remove vCenter connections",
    "vmware.vm.view": "View VMware VMs and details",
    "vmware.vm.power": "Start/stop/restart VMware VMs",
    "vmware.vm.snapshot": "Create/delete VMware VM snapshots",
    "vmware.vm.migrate": "Migrate VMs to Proxmox (V2V)",
    "vmware.host.view": "View ESXi host details",
    "vmware.datastore.view": "View VMware datastores",
    "vmware.network.view": "View VMware networks",
    "vmware.vm.manage": "Modify VMware VM configuration",
    "vmware.cluster.manage": "Manage VMware cluster settings (DRS, HA)",
    "vmware.export": "Export cluster state to VMware assets",
    "vmware.connector": "Manage VMware connector configuration",
    "vmware.sync": "Sync VMware state with Proxmox cluster",
    "vmware.import": "Import VMware assets into Proxmox cluster",
    "vmware.templates": "Manage VMware template library",
    "vmware.dashboard": "View VMware dashboard widget",
    "vmware.alerts": "Manage VMware alert channel",
    "vmware.policy": "Manage VMware policy adapter",
    "vmware.roles": "Manage VMware role mapping",
    "vmware.workflow": "Manage VMware automation workflow",
}

HYPERV = {
    "hyperv.connector": "Register and manage Hyper-V connections",
    "hyperv.read": "View Hyper-V inventory and events",
    "hyperv.power": "Start, stop, pause, resume and reset Hyper-V VMs",
    "hyperv.migrate": "Migrate Hyper-V VMs and storage",
    "hyperv.checkpoint": "Create and delete Hyper-V checkpoints",
    "hyperv.provision": "Provision Hyper-V VMs",
    "hyperv.configure": "Configure Hyper-V settings",
}

PERMISSIONS.update(HYPERV)

XCP = {
    "xcp.connector": "Register and manage XCP-ng / Xen Orchestra connections and resource links",
    "xcp.viewer": "View XCP-ng pools, hosts, VMs, storage, networks, metrics and backup jobs",
    "xcp.vm.power": "Start, shutdown, reboot, suspend and resume XCP-ng VMs and manage snapshots",
    "xcp.vm.provision": "Provision XCP-ng VMs (reserved for P3 scope)",
}

PERMISSIONS.update(XCP)

NUTANIX = {
    "nutanix.viewer": "View Nutanix AHV clusters, hosts, VMs, storage, networks, categories, protection and alerts",
    "nutanix.connector": "Register, edit, test and delete Nutanix Prism connections and manage resource links",
    "nutanix.vm.power": "Power on, ACPI shutdown, power off, reboot, suspend and resume AHV VMs",
    "nutanix.vm.provision": "Provision/clone AHV VMs",
    "nutanix.alert.ack": "Acknowledge Nutanix alerts",
}

PERMISSIONS.update(NUTANIX)

VEEAM = {
    "veeam.viewer": "View Veeam jobs, sessions, protected objects, restore points, repositories, compliance and alerts",
    "veeam.connector": "Register, edit, test and delete Veeam Backup & Replication connections",
    "veeam.configure": "Configure Veeam RPO rules and alert thresholds",
    "veeam.job.run": "Start or stop Veeam backup jobs",
    "veeam.restore.view": "Browse Veeam restore points",
}

PERMISSIONS.update(VEEAM)

PORTAINER = {
    "portainer.viewer": "View Portainer endpoints, stacks, containers and images",
    "portainer.connector": "Register, edit, test and delete Portainer connections",
    "portainer.container.power": "Start, stop, restart, pause and unpause Portainer containers",
    "portainer.stack.deploy": "Deploy, start and stop Portainer stacks",
}

PERMISSIONS.update(PORTAINER)

RANCHER = {
    "rancher.viewer": "View Rancher clusters, projects, workloads and catalog apps",
    "rancher.connector": "Register, edit, test and delete Rancher connections",
    "rancher.workload.manage": "Redeploy, scale and restart Rancher workloads and delete pods",
    "rancher.app.deploy": "Deploy Rancher catalog/helm apps (reserved for P3 scope)",
}

PERMISSIONS.update(RANCHER)

# Default permissions per role
ROLE_PERMISSIONS = {
    ROLE_ADMIN: list(PERMISSIONS.keys()),
    ROLE_USER: [
        "vm.view",
        "vm.start",
        "vm.stop",
        "vm.restart",
        "vm.console",
        "vm.migrate",
        "vm.clone",
        "vm.config",
        "vm.snapshot",
        "vm.backup",
        "converter.view",
        "converter.run",
        "cluster.view",
        "node.view",
        "storage.view",
        "storage.upload",
        "storage.download",
        "backup.view",
        "backup.create",
        "backup.restore",
        "backup.delete",
        "ha.view",
        "firewall.view",
        "pool.view",
        "pool.assign",
        "replication.view",
        "site_recovery.view",
        "plugins.view",
        "pbs.view",
        "pbs.datastore.view",
        "pbs.datastore.gc",
        "pbs.datastore.verify",
        "pbs.snapshot.notes",
        "pbs.snapshot.browse",
        "pbs.jobs.view",
        "pbs.tasks.view",
        "pbs.notifications.view",
        "pbs.traffic.view",
        "pbs.disks.view",
        "pbs.subscription.view",
        "vmware.view",
        "vmware.vm.view",
        "vmware.vm.power",
        "vmware.vm.snapshot",
        "vmware.vm.migrate",
        "vmware.vm.manage",
        "vmware.host.view",
        "vmware.datastore.view",
        "vmware.network.view",
        # Kubernetes / integration permissions
        "kubernetes.view",
        "kubernetes.export",
        "kubernetes.connector",
        "kubernetes.sync",
        "kubernetes.import",
        "kubernetes.library",
        "kubernetes.widget",
        "kubernetes.dashboard",
        "kubernetes.alerts",
        "kubernetes.policy",
        "kubernetes.roles",
        "kubernetes.workflow",
        # Hyper-V / Azure Stack HCI permissions
        "hyperv.read",
        # XCP-ng / Xen Orchestra viewer access
        "xcp.viewer",
        # Veeam viewer + optional job run access
        "veeam.viewer",
        "veeam.job.run",
        # Portainer + Rancher viewer access and day-2 container/workload ops
        "portainer.viewer",
        "portainer.container.power",
        "rancher.viewer",
        "rancher.workload.manage",
    ],
    ROLE_VIEWER: [
        "vm.view",
        "vm.console",
        "converter.view",
        "cluster.view",
        "node.view",
        "storage.view",
        "backup.view",
        "ha.view",
        "firewall.view",
        "pool.view",
        "replication.view",
        "site_recovery.view",
        "plugins.view",
        "pbs.view",
        "pbs.datastore.view",
        "pbs.jobs.view",
        "pbs.tasks.view",
        "pbs.notifications.view",
        "pbs.traffic.view",
        "pbs.disks.view",
        "pbs.subscription.view",
        "vmware.view",
        "vmware.vm.view",
        "vmware.host.view",
        "vmware.datastore.view",
        "vmware.network.view",
        # Kubernetes / integration permissions (viewer access)
        "kubernetes.view",
        "kubernetes.export",
        "kubernetes.library",
        "kubernetes.widget",
        "kubernetes.dashboard",
        # Hyper-V viewer access
        "hyperv.read",
        # XCP-ng viewer access
        "xcp.viewer",
        # Veeam read-only access
        "veeam.viewer",
        # Portainer + Rancher read-only access
        "portainer.viewer",
        "rancher.viewer",
    ],
}

REDFISH = {
    "redfish.bmc.enroll": "Enroll and manage Redfish BMC connections",
    "redfish.viewer": "View Redfish BMC inventory and status",
    "redfish.connector": "Register, edit, test and delete Redfish BMC connections",
    "redfish.sensor.read": "Read Redfish thermal, power and voltage sensor data",
    "redfish.log.read": "Read Redfish System Event Log (SEL) entries",
    "redfish.host.power": "Issue chassis and system power actions",
    "redfish.event.subscribe": "Create and manage Redfish EventService subscriptions",
    "redfish.firmware.read": "Read Redfish firmware and virtual media inventory",
    "redfish.alert.ack": "Acknowledge Redfish BMC alerts",
}

PERMISSIONS.update(REDFISH)

DELL = {
    "dell.viewer": "View Dell iDRAC inventory and status",
    "dell.connector": "Register, edit, test and delete Dell iDRAC connections",
    "dell.host.power": "Issue Dell iDRAC chassis and system power actions",
    "dell.sensor.read": "Read Dell iDRAC thermal, power and voltage sensor data",
    "dell.log.read": "Read Dell iDRAC System Event Log (SEL) entries",
    "dell.job.read": "View Dell iDRAC Lifecycle Controller jobs",
    "dell.firmware.read": "Read Dell iDRAC firmware inventory",
    "dell.catalog.read": "Compare Dell iDRAC firmware against the catalog",
}

PERMISSIONS.update(DELL)

IDRAC = {
    "idrac.bmc.enroll": "Enroll and manage Dell iDRAC BMC connections",
    "idrac.viewer": "View Dell iDRAC inventory and status",
    "idrac.connector": "Register, edit, test and delete Dell iDRAC connections",
    "idrac.sensor.read": "Read Dell iDRAC thermal, power and voltage sensor data",
    "idrac.log.read": "Read Dell iDRAC System Event Log (SEL) entries",
    "idrac.host.power": "Issue Dell iDRAC chassis and system power actions",
    "idrac.job.read": "View Dell iDRAC Lifecycle Controller jobs",
    "idrac.firmware.read": "Read Dell iDRAC firmware inventory",
    "idrac.catalog.read": "Compare Dell iDRAC firmware against the catalog",
}

PERMISSIONS.update(IDRAC)

HPE = {
    "hpe.viewer": "View HPE iLO inventory and status",
    "hpe.connector": "Register, edit, test and delete HPE iLO connections",
    "hpe.host.power": "Issue HPE iLO chassis and system power actions",
    "hpe.sensor.read": "Read HPE iLO thermal, power and voltage sensor data",
    "hpe.log.read": "Read HPE iLO Integrated Management Log (IML) entries",
    "hpe.firmware.read": "Read HPE iLO firmware inventory",
    "hpe.federation.read": "Read HPE iLO Federation group health",
    "hpe.security.read": "Read HPE iLO security dashboard and Silicon Root of Trust",
    "hpe.bmc.enroll": "Enroll and manage HPE iLO BMC connections",
    "hpe.alert.ack": "Acknowledge HPE iLO alerts",
}

PERMISSIONS.update(HPE)

ILO = {
    "ilo.bmc.enroll": "Enroll and manage HPE iLO BMC connections",
    "ilo.viewer": "View HPE iLO inventory and status",
    "ilo.connector": "Register, edit, test and delete HPE iLO connections",
    "ilo.sensor.read": "Read HPE iLO thermal, power and voltage sensor data",
    "ilo.log.read": "Read HPE iLO Integrated Management Log (IML) entries",
    "ilo.host.power": "Issue HPE iLO chassis and system power actions",
    "ilo.federation.read": "Read HPE iLO Federation group health",
    "ilo.firmware.read": "Read HPE iLO firmware inventory",
    "ilo.security.read": "Read HPE iLO security dashboard and Silicon Root of Trust",
    "ilo.alert.ack": "Acknowledge HPE iLO alerts",
}

PERMISSIONS.update(ILO)


LENOVO = {
    "lenovo.viewer": "View Lenovo XClarity inventory and status",
    "lenovo.connector": "Register, edit, test and delete Lenovo XClarity connections",
    "lenovo.alert.ack": "Acknowledge Lenovo XClarity alerts",
    "xcc.bmc.enroll": "Enroll and manage XCC Redfish BMC connections",
    "xcc.sensor.read": "Read XCC thermal, power and voltage sensor data",
    "xcc.log.read": "Read XCC System Event Log (SEL) entries",
    "xcc.host.power": "Issue XCC chassis and system power actions",
    "xcc.firmware.read": "Read XCC firmware inventory",
    "xcc.compliance.read": "Read XCC firmware compliance status",
    "xcc.lxca.read": "Read LXCA fleet and managed node data",
}

XCLARITY = {
    "lxca.discover": "Discover and import LXCA managed nodes",
}

PERMISSIONS.update(LENOVO)
PERMISSIONS.update(XCLARITY)

IPMI = {
    "ipmi.bmc.enroll": "Enroll and manage Generic IPMI BMC connections",
    "ipmi.viewer": "View Generic IPMI inventory and status",
    "ipmi.connector": "Register, edit, test and delete Generic IPMI connections",
    "ipmi.sensor.read": "Read Generic IPMI thermal, power, voltage and current sensor data",
    "ipmi.log.read": "Read Generic IPMI System Event Log (SEL) entries",
    "ipmi.host.power": "Issue Generic IPMI chassis and system power actions",
    "ipmi.watchdog.read": "Read Generic IPMI watchdog status",
    "ipmi.firmware.read": "Read Generic IPMI firmware and FRU inventory",
    "ipmi.alert.ack": "Acknowledge Generic IPMI alerts",
}

PERMISSIONS.update(IPMI)

APC = {
    "apc.viewer": "View APC / Schneider UPS inventory and status",
    "apc.connector": "Register, edit, test and delete APC / Schneider UPS connections",
    "apc.ups.read": "View APC / Schneider UPS device details and metrics",
    "apc.ups.write": "Create, edit and delete APC / Schneider UPS devices",
    "apc.outlet.read": "View APC / Schneider UPS outlet and outlet group status",
    "apc.outlet.write": "Control APC / Schneider UPS outlets and outlet groups",
    "apc.alert.ack": "Acknowledge APC / Schneider UPS alerts",
}

PERMISSIONS.update(APC)
