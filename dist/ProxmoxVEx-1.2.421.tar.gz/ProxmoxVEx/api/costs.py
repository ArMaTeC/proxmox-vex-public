# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/api/costs.py
# Project:     ProxmoxVEx
# Version:     1.2.403
# Build:       2026.09.09
# Description: Cost Dashboard / Chargeback
# Docs:        https://proxmoxvex.local/docs
# Generated:   2026-09-09
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""
Cost Dashboard / Chargeback

Computes monthly cost per VM/CT and per-cluster aggregates from the existing
metrics_history snapshots. Rates are admin-configurable: global default plus
per-cluster overrides (different hardware tiers, different price plans, etc.).

Cost model — keep it explainable. Marketing won't beat us up if the numbers
are slightly off, but they will if we can't explain how we got them:

    cost_cpu     = avg_cpu_pct/100 × hours_window × maxcpu × cpu_per_core_h
    cost_memory  = avg_mem_pct/100 × hours_window × (maxmem_gb) × mem_per_gb_h
    cost_storage = sum(disk_size_gb)              × storage_per_gb_month × (days/30)
    cost_total   = cost_cpu + cost_memory + cost_storage

Defaults (~AWS m6i.large utilization-equivalent prices, in EUR — adjust per
deployment):
    cpu_per_core_h        = 0.012
    mem_per_gb_h          = 0.0035
    storage_per_gb_month  = 0.10

If a VM has only a couple of samples we still cost it (avg_cpu/mem of those
samples), with a "low_data" flag in the response so the UI can show a warning
icon. Better than refusing to display anything.
"""

import logging
import threading
import time
from datetime import datetime

from flask import Blueprint, jsonify, request

from ProxmoxVEx.api.helpers import check_cluster_access, load_metrics_window
from ProxmoxVEx.core.db import get_db
from ProxmoxVEx.globals import cluster_managers
from ProxmoxVEx.models.permissions import ROLE_ADMIN
from ProxmoxVEx.utils.auth import require_auth
from ProxmoxVEx.utils.sanitization import sanitize_csv_field

bp = Blueprint("costs", __name__)


_DEFAULT_RATES = {
    "cpu_per_core_h": 0.012,
    "mem_per_gb_h": 0.0035,
    "storage_per_gb_month": 0.10,
    "currency": "EUR",
    "notes": "",
}


def _row_to_rates(row):
    return {
        "cluster_id": row["cluster_id"],
        "cpu_per_core_h": float(row["cpu_per_core_h"] or 0),
        "mem_per_gb_h": float(row["mem_per_gb_h"] or 0),
        "storage_per_gb_month": float(row["storage_per_gb_month"] or 0),
        "currency": row["currency"] or "EUR",
        "notes": row["notes"] or "",
        "updated_at": row["updated_at"],
        "updated_by": row["updated_by"] or "",
    }


def _get_rates(cluster_id):
    """Return effective rates: cluster override → fallback to __default__ row → fallback to constants."""
    db = get_db()
    c = db.conn.cursor()
    try:
        c.execute("SELECT * FROM cost_rates WHERE cluster_id IN ('__default__', ?)", (cluster_id,))
        rows = {r["cluster_id"]: r for r in c.fetchall()}
    except Exception as e:
        logging.warning(f"[costs] rates fetch failed: {e}")
        rows = {}

    if cluster_id in rows:
        return _row_to_rates(rows[cluster_id])
    if "__default__" in rows:
        return _row_to_rates(rows["__default__"])
    return {**_DEFAULT_RATES, "cluster_id": "__default__"}


def _current_user():
    try:
        u = request.session.get("user") if hasattr(request, "session") else ""
        if isinstance(u, dict):
            return u.get("username", "") or ""
        return u or ""
    except Exception:
        return ""


def _load_history(cluster_id, days=30):
    """Pull all snapshots for a cluster. Fetch+parse run off-hub + cached in
    load_metrics_window (shared with insights/power); we just filter."""
    out = []
    try:
        for ts_unix, clusters in load_metrics_window(days):
            cd = clusters.get(cluster_id)
            if cd:
                out.append((ts_unix, cd))
    except Exception as e:
        logging.warning(f"[costs] history load failed for {cluster_id}: {e}")
    return out


def _compute_per_vm(snapshots, mgr, rates, hours_window):
    """Aggregate per-VM utilization across snapshots → cost rows."""
    # vmid -> {cpu_samples, mem_samples, name, node, type, maxmem, maxcpu, running_samples, total_samples}
    by_vm = {}

    for _ts, cd in snapshots:
        for vmid, v in (cd.get("vms") or {}).items():
            entry = by_vm.setdefault(
                vmid,
                {
                    "cpu_samples": [],
                    "mem_samples": [],
                    "maxmem": 0,
                    "maxcpu": 0,
                    "t": v.get("t"),
                    "r_count": 0,
                    "total": 0,
                },
            )
            entry["total"] += 1
            if v.get("r"):
                entry["r_count"] += 1
            if v.get("cpu") is not None:
                entry["cpu_samples"].append(v["cpu"])
            if v.get("mem") is not None:
                entry["mem_samples"].append(v["mem"])
            if v.get("maxmem"):
                entry["maxmem"] = max(entry["maxmem"], v["maxmem"])
            if v.get("maxcpu"):
                entry["maxcpu"] = max(entry["maxcpu"], v["maxcpu"])

    # Enrich with current name / node / disk size from live mgr
    name_by_vmid = {}
    node_by_vmid = {}
    disk_by_vmid = {}
    try:
        for r in mgr.get_vm_resources() or []:
            vid = str(r.get("vmid", ""))
            if not vid:
                continue
            name_by_vmid[vid] = r.get("name", "")
            node_by_vmid[vid] = r.get("node", "")
            disk = int(r.get("maxdisk", 0) or 0)
            disk_by_vmid[vid] = disk
    except Exception as e:
        logging.debug(f"[costs] enrich failed: {e}")

    rows = []
    for vmid, vm in by_vm.items():
        cpu_samples = vm["cpu_samples"] or [0]
        mem_samples = vm["mem_samples"] or [0]
        avg_cpu_pct = sum(cpu_samples) / len(cpu_samples)
        avg_mem_pct = sum(mem_samples) / len(mem_samples)
        running_ratio = (vm["r_count"] / vm["total"]) if vm["total"] else 0
        # only count utilization for the time the VM was running
        active_h = hours_window * running_ratio

        maxcpu = vm["maxcpu"] or 0
        # snapshot's maxmem is bytes — convert to GB
        maxmem_gb = (vm["maxmem"] or 0) / (1024**3)
        disk_gb = (disk_by_vmid.get(vmid, 0) or 0) / (1024**3)

        cost_cpu = (avg_cpu_pct / 100.0) * active_h * maxcpu * rates["cpu_per_core_h"]
        cost_mem = (avg_mem_pct / 100.0) * active_h * maxmem_gb * rates["mem_per_gb_h"]
        # storage billed regardless of running state
        days = hours_window / 24.0
        cost_storage = disk_gb * rates["storage_per_gb_month"] * (days / 30.0)
        total = cost_cpu + cost_mem + cost_storage

        rows.append({
            "vmid": vmid,
            "name": name_by_vmid.get(vmid, vmid),
            "node": node_by_vmid.get(vmid, ""),
            "type": vm["t"],
            "avg_cpu_pct": round(avg_cpu_pct, 1),
            "avg_mem_pct": round(avg_mem_pct, 1),
            "running_ratio": round(running_ratio, 3),
            "cores": maxcpu,
            "memory_gb": round(maxmem_gb, 2),
            "disk_gb": round(disk_gb, 2),
            "cost_cpu": round(cost_cpu, 2),
            "cost_memory": round(cost_mem, 2),
            "cost_storage": round(cost_storage, 2),
            "cost_total": round(total, 2),
            "low_data": vm["total"] < 12,  # <12 samples = <1h history, surface in UI
        })

    rows.sort(key=lambda r: r["cost_total"], reverse=True)
    return rows


# ──────────────────────────────────────────────────────────────────────────
# Endpoints
# ──────────────────────────────────────────────────────────────────────────


@bp.route("/api/cost/rates", methods=["GET"])
@require_auth()
def list_rates():
    """All cost rate configs (global default + per-cluster overrides)."""
    try:
        c = get_db().conn.cursor()
        c.execute("SELECT * FROM cost_rates ORDER BY cluster_id")
        return jsonify({"rates": [_row_to_rates(r) for r in c.fetchall()]})
    except Exception:
        logging.exception("handler error in costs.py")
        return jsonify({"error": "internal error"}), 500


@bp.route("/api/cost/rates/<cluster_id>", methods=["GET"])
@require_auth()
def get_one_rate(cluster_id):
    return jsonify(_get_rates(cluster_id))


@bp.route("/api/cost/rates/<cluster_id>", methods=["PUT"])
@require_auth(roles=[ROLE_ADMIN])
def upsert_rate(cluster_id):
    """Admin-only — update rates for a cluster (or '__default__' for global)."""
    body = request.get_json(silent=True) or {}
    try:
        cpu = float(body.get("cpu_per_core_h", _DEFAULT_RATES["cpu_per_core_h"]))
        mem = float(body.get("mem_per_gb_h", _DEFAULT_RATES["mem_per_gb_h"]))
        sto = float(body.get("storage_per_gb_month", _DEFAULT_RATES["storage_per_gb_month"]))
    except (TypeError, ValueError):
        return jsonify({"error": "rates must be numeric"}), 400
    currency = (body.get("currency") or "EUR").strip()[:8]
    notes = (body.get("notes") or "").strip()[:500]

    try:
        c = get_db().conn.cursor()
        c.execute(
            """
            INSERT INTO cost_rates (cluster_id, cpu_per_core_h, mem_per_gb_h,
                                    storage_per_gb_month, currency, notes,
                                    updated_at, updated_by)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(cluster_id) DO UPDATE SET
                cpu_per_core_h=excluded.cpu_per_core_h,
                mem_per_gb_h=excluded.mem_per_gb_h,
                storage_per_gb_month=excluded.storage_per_gb_month,
                currency=excluded.currency,
                notes=excluded.notes,
                updated_at=excluded.updated_at,
                updated_by=excluded.updated_by
        """,
            (cluster_id, cpu, mem, sto, currency, notes, datetime.now().isoformat(), _current_user()),
        )
        get_db().conn.commit()
        return jsonify({"ok": True, "rates": _get_rates(cluster_id)})
    except Exception:
        logging.exception("handler error in costs.py")
        return jsonify({"error": "internal error"}), 500


@bp.route("/api/cost/rates/<cluster_id>", methods=["DELETE"])
@require_auth(roles=[ROLE_ADMIN])
def delete_rate(cluster_id):
    """Drop a per-cluster override (defaults take over). __default__ stays."""
    if cluster_id == "__default__":
        return jsonify({"error": "cannot delete default rates"}), 400
    try:
        c = get_db().conn.cursor()
        c.execute("DELETE FROM cost_rates WHERE cluster_id = ?", (cluster_id,))
        get_db().conn.commit()
        return jsonify({"ok": True})
    except Exception:
        logging.exception("handler error in costs.py")
        return jsonify({"error": "internal error"}), 500


@bp.route("/api/clusters/<cluster_id>/costs/summary", methods=["GET"])
@require_auth(perms=["cluster.view"])
def cluster_summary(cluster_id):
    """Summary tiles + per-VM cost breakdown for a cluster.
    Query: ?days=30 (default 30, max 30 because that's our retention)."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return err
    if cluster_id not in cluster_managers:
        return jsonify({"error": "cluster not found"}), 404

    try:
        days = int(request.args.get("days", "30"))
        days = max(1, min(days, 30))
    except Exception:
        days = 30

    rates = _get_rates(cluster_id)
    snapshots = _load_history(cluster_id, days=days)
    if not snapshots:
        return jsonify({
            "enough_data": False,
            "cluster_id": cluster_id,
            "rates": rates,
            "days": days,
        })

    hours_window = days * 24
    mgr = cluster_managers[cluster_id]
    rows = _compute_per_vm(snapshots, mgr, rates, hours_window)

    total = sum(r["cost_total"] for r in rows)
    cpu = sum(r["cost_cpu"] for r in rows)
    mem = sum(r["cost_memory"] for r in rows)
    sto = sum(r["cost_storage"] for r in rows)

    # extrapolate to monthly if window < 30 days
    factor = 30.0 / days if days < 30 else 1.0
    monthly_total = total * factor
    monthly_cpu = cpu * factor
    monthly_mem = mem * factor
    monthly_sto = sto * factor

    by_node = {}
    for r in rows:
        n = r.get("node") or "unknown"
        by_node[n] = by_node.get(n, 0.0) + r["cost_total"]

    return jsonify({
        "enough_data": True,
        "cluster_id": cluster_id,
        "days": days,
        "snapshots_count": len(snapshots),
        "rates": rates,
        "total_window": round(total, 2),
        "monthly_total": round(monthly_total, 2),
        "monthly_breakdown": {
            "cpu": round(monthly_cpu, 2),
            "memory": round(monthly_mem, 2),
            "storage": round(monthly_sto, 2),
        },
        "by_node": {k: round(v * factor, 2) for k, v in by_node.items()},
        "top_spenders": rows[:10],
        "vm_count": len(rows),
    })


@bp.route("/api/clusters/<cluster_id>/costs/per-vm", methods=["GET"])
@require_auth(perms=["cluster.view"])
def per_vm(cluster_id):
    """Full per-VM cost table — paginate-friendly enough for now (sorted by total desc)."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return err
    if cluster_id not in cluster_managers:
        return jsonify({"error": "cluster not found"}), 404
    try:
        days = max(1, min(int(request.args.get("days", "30")), 30))
    except Exception:
        days = 30

    rates = _get_rates(cluster_id)
    snapshots = _load_history(cluster_id, days=days)
    if not snapshots:
        return jsonify({"enough_data": False, "rates": rates, "rows": []})
    mgr = cluster_managers[cluster_id]
    rows = _compute_per_vm(snapshots, mgr, rates, days * 24)
    factor = 30.0 / days if days < 30 else 1.0
    for r in rows:
        # also expose monthly extrapolation per row for direct UI display
        r["monthly_total"] = round(r["cost_total"] * factor, 2)
    return jsonify({
        "enough_data": True,
        "cluster_id": cluster_id,
        "days": days,
        "rates": rates,
        "rows": rows,
    })


@bp.route("/api/tenants/<tenant_id>/chargeback", methods=["GET"])
@require_auth(perms=["admin.tenants"])
def tenant_chargeback(tenant_id):
    """#502 — per-tenant cost rollup (chargeback/showback). Aggregates per-VM
    costs across the tenant's clusters into a statement: per-cluster subtotals +
    a per-VM breakdown + a monthly extrapolation. On-demand (no persistence).
    Query: ?days=1..30 (default 30), ?format=csv for a CSV download."""
    try:
        import ProxmoxVEx.utils.rbac as _rbac

        try:
            days = max(1, min(int(request.args.get("days", "30")), 30))
        except Exception:
            days = 30
        fmt = (request.args.get("format") or "json").lower()

        # #502 - refresh the cached tenants global so get_user_clusters() below
        # sees the tenant's current cluster assignment (it goes stale after an edit).
        _rbac.tenants_db = _rbac.load_tenants()
        tenant = (_rbac.tenants_db or {}).get(tenant_id)
        if not tenant:
            return jsonify({"error": "tenant not found"}), 404

        # (sec-review) - admin.tenants can be a tenant-scoped custom role;
        # scope to the caller's own tenant unless a real admin, else one tenant could
        # read another tenant's full VM inventory + per-VM cost breakdown (BOLA).
        if request.session.get("role") != _rbac.ROLE_ADMIN:
            _caller = get_db().get_user(request.session.get("user", "")) or {}
            if tenant_id != _caller.get("tenant_id", _rbac.DEFAULT_TENANT_ID):
                return jsonify({"error": "Access denied to this tenant"}), 403
        allowed = _rbac.get_user_clusters({"role": _rbac.ROLE_VIEWER, "tenant_id": tenant_id})  # None = all clusters

        factor = 30.0 / days if days < 30 else 1.0
        by_cluster = []
        all_rows = []
        grand_total = 0.0
        currency = "EUR"
        for cid, mgr in cluster_managers.items():
            if allowed is not None and cid not in allowed:
                continue
            cname = getattr(getattr(mgr, "config", None), "name", cid) or cid
            try:
                rates = _get_rates(cid)
                currency = rates.get("currency", currency) or currency
                snaps = _load_history(cid, days=days)
                if not snaps:
                    by_cluster.append({
                        "cluster_id": cid,
                        "cluster_name": cname,
                        "subtotal": 0.0,
                        "monthly_subtotal": 0.0,
                        "vm_count": 0,
                        "enough_data": False,
                    })
                    continue
                rows = _compute_per_vm(snaps, mgr, rates, days * 24)
                for r in rows:
                    r["cluster_id"] = cid
                    r["cluster_name"] = cname
                    r["monthly_total"] = round(r["cost_total"] * factor, 2)
                sub = round(sum(r["cost_total"] for r in rows), 2)
                grand_total += sub
                all_rows.extend(rows)
                by_cluster.append({
                    "cluster_id": cid,
                    "cluster_name": cname,
                    "subtotal": sub,
                    "monthly_subtotal": round(sub * factor, 2),
                    "vm_count": len(rows),
                    "enough_data": True,
                })
            except Exception as ce:
                logging.warning(f"[chargeback] cluster {cid} failed: {ce}")
        grand_total = round(grand_total, 2)
        all_rows.sort(key=lambda r: r.get("cost_total", 0), reverse=True)

        if fmt == "csv":
            import csv
            import io

            from flask import Response

            buf = io.StringIO()
            w = csv.writer(buf)
            w.writerow([
                "cluster",
                "vmid",
                "name",
                "type",
                "cores",
                "memory_gb",
                "disk_gb",
                "cost_cpu",
                "cost_memory",
                "cost_storage",
                f"cost_total_{days}d",
                "monthly_total",
                "currency",
            ])
            for r in all_rows:
                # #502 - neutralise CSV formula injection (CWE-1236) on the
                # user-controlled string cells (VM/cluster names); numbers stay raw
                w.writerow([
                    sanitize_csv_field(r.get("cluster_name")),
                    r.get("vmid"),
                    sanitize_csv_field(r.get("name")),
                    sanitize_csv_field(r.get("type")),
                    r.get("cores"),
                    r.get("memory_gb"),
                    r.get("disk_gb"),
                    r.get("cost_cpu"),
                    r.get("cost_memory"),
                    r.get("cost_storage"),
                    r.get("cost_total"),
                    r.get("monthly_total"),
                    currency,
                ])
            return Response(
                buf.getvalue(),
                mimetype="text/csv",
                headers={"Content-Disposition": f'attachment; filename="chargeback-{tenant_id}-{days}d.csv"'},
            )

        return jsonify({
            "tenant_id": tenant_id,
            "tenant_name": tenant.get("name", tenant_id),
            "days": days,
            "currency": currency,
            "total": grand_total,
            "monthly_total": round(grand_total * factor, 2),
            "by_cluster": by_cluster,
            "rows": all_rows,
        })
    except Exception:
        logging.exception("handler error in costs.py (chargeback)")
        return jsonify({"error": "internal error"}), 500


# 956-caching-for-cost-engine: cache expensive cost engine computations.
COST_ENGINE_CACHE_TTL = 300
_cost_engine_cache = {}
_cost_engine_cache_lock = threading.Lock()


def _cost_cache_key(cluster_id, days):
    """Build a stable cache key for a cluster/day cost query."""
    return f"{cluster_id}:{days}"


def get_cached_cost_data(cluster_id, days, compute_func):
    """Return cached cost data for `cluster_id`/`days`, computing on cache miss.

    956-caching-for-cost-engine: avoids recomputing cost windows within the TTL.
    """
    key = _cost_cache_key(cluster_id, days)
    now = time.time()
    with _cost_engine_cache_lock:
        entry = _cost_engine_cache.get(key)
        if entry and now - entry["ts"] < COST_ENGINE_CACHE_TTL:
            return entry["data"]
        data = compute_func()
        _cost_engine_cache[key] = {"ts": now, "data": data}
    return data


# 957-lazy-loading-for-cost-engine: paginated cost engine row loading.
COST_ENGINE_LAZY_LOADING = True
COST_ENGINE_PAGINATION_MAX = 100


def get_cost_data_lazy(rows, page=1, per_page=COST_ENGINE_PAGINATION_MAX):
    """Return a paginated slice of cost engine rows.

    957-lazy-loading-for-cost-engine: avoids sending the entire cost table
    at once by returning a bounded `page`/`per_page` window.
    """
    if not isinstance(rows, list):
        return {"page": page, "per_page": per_page, "total": 0, "rows": []}

    per_page = max(1, min(int(per_page), COST_ENGINE_PAGINATION_MAX))
    page = max(1, int(page))
    total = len(rows)
    start = (page - 1) * per_page
    end = start + per_page
    return {
        "page": page,
        "per_page": per_page,
        "total": total,
        "rows": rows[start:end],
    }


# 958-pagination-for-cost-engine: dedicated paginated cost engine helper.
COST_ENGINE_PAGINATION = True


def get_cost_data_paginated(rows, page, per_page):
    """Return a paginated window of cost engine rows.

    958-pagination-for-cost-engine: applies stable pagination to the cost table,
    exposing `page`/`per_page` metadata for the UI.
    """
    return get_cost_data_lazy(rows, page, per_page)


# 959-batching-for-cost-engine: fixed-size batch fetching for cost engine rows.
COST_ENGINE_BATCHING = True
COST_ENGINE_BATCH_SIZE = 50


def get_cost_data_batched(rows, batch_size=None):
    """Return the next fixed-size batch of cost engine rows.

    959-batching-for-cost-engine: breaks large cost tables into fixed-size
    chunks so callers can stream updates without loading everything.
    """
    if batch_size is None:
        batch_size = COST_ENGINE_BATCH_SIZE
    batch_size = max(1, min(int(batch_size), COST_ENGINE_PAGINATION_MAX))
    if not isinstance(rows, list):
        return {"batch": 1, "batch_size": batch_size, "total": 0, "rows": []}
    return {
        "batch": 1,
        "batch_size": batch_size,
        "total": len(rows),
        "rows": rows[:batch_size],
    }


# 960-indexing-for-cost-engine: build an in-memory index for cost engine rows.
COST_ENGINE_INDEXING = True


def get_cost_data_indexed(rows, field):
    """Return an in-memory index of cost engine rows by `field`.

    960-indexing-for-cost-engine: groups cost rows by the supplied `field`
    so callers can do O(1) lookups instead of scanning the full table.
    """
    if not isinstance(rows, list):
        return {"field": field, "total": 0, "index": {}}
    index = {}
    for row in rows:
        if isinstance(row, dict) and field in row:
            index.setdefault(row[field], []).append(row)
        elif hasattr(row, field):
            index.setdefault(getattr(row, field), []).append(row)
    return {"field": field, "total": len(rows), "index": index}


# 961-compression-for-cost-engine: gzip-compressed cost engine payloads.
COST_ENGINE_COMPRESSION = True


def get_cost_data_compressed(rows):
    """Return a gzip/base64-compressed cost engine payload.

    961-compression-for-cost-engine: reduces wire size for large cost tables
    by returning a gzip-compressed, base64-encoded payload.
    """
    import base64
    import gzip
    import json

    if not isinstance(rows, list):
        rows = []
    payload = json.dumps(rows).encode("utf-8")
    compressed = base64.b64encode(gzip.compress(payload)).decode("ascii")
    return {
        "compressed": True,
        "encoding": "base64",
        "format": "gzip",
        "total": len(rows),
        "data": compressed,
    }


# 962-connection-pooling-for-cost-engine: reusable connection pool for cost engine.
class CostEngineConnectionPool:
    """Thread-safe reusable connection pool for cost engine fetch workers."""

    def __init__(self, maxsize=20):
        self._maxsize = maxsize
        self._pool = []
        self._lock = threading.Lock()

    def acquire(self, factory=None):
        with self._lock:
            if self._pool:
                return self._pool.pop()
        if factory:
            return factory()
        return None

    def release(self, conn):
        if conn is None:
            return
        with self._lock:
            if len(self._pool) < self._maxsize:
                self._pool.append(conn)


_cost_engine_pool = CostEngineConnectionPool()


def get_cost_data(key, fetch_func):
    """Fetch raw cost engine data for `key` using `fetch_func`."""
    return fetch_func()


def get_cost_data_pooled(key, fetch_func):
    """Fetch cost data using a reusable pooled connection.

    962-connection-pooling-for-cost-engine: avoids repeated expensive connection
    creation by reusing handles from `_cost_engine_pool`.
    """
    handle = _cost_engine_pool.acquire(factory=fetch_func)
    try:
        return get_cost_data(key, handle) if handle is not None else None
    finally:
        _cost_engine_pool.release(handle)


# 963-async-workers-for-cost-engine: offload cost engine fetches to background.
COST_ENGINE_ASYNC_WORKERS = True


def get_cost_data_async(key, fetch_func, executor=None):
    """Offload cost engine data fetching to a background thread pool.

    963-async-workers-for-cost-engine: returns a Future so the request thread is
    not blocked while the cost data is being fetched.
    """
    import concurrent.futures

    def _fetch():
        return get_cost_data(key, fetch_func)

    if executor is None:
        executor = concurrent.futures.ThreadPoolExecutor(max_workers=4)
    return executor.submit(_fetch)


# 964-memory-optimisation-for-cost-engine: cap in-memory cost data size.
COST_ENGINE_MEMORY_OPTIMISATION = True
COST_ENGINE_MEMORY_MAX_POINTS = 1000


def get_cost_data_optimised(rows, max_points=None):
    """Cap in-memory cost engine data to the most recent `max_points` rows.

    964-memory-optimisation-for-cost-engine: prevents unbounded in-memory cost
    table growth by returning only the most recent rows.
    """
    if max_points is None:
        max_points = COST_ENGINE_MEMORY_MAX_POINTS
    max_points = max(1, int(max_points))
    if not isinstance(rows, list):
        return {"max_points": max_points, "total": 0, "rows": []}
    return {
        "max_points": max_points,
        "total": len(rows),
        "rows": rows[-max_points:],
    }


# 965-incremental-updates-for-cost-engine: only return new cost rows since a timestamp.
COST_ENGINE_INCREMENTAL_UPDATES = True


def get_cost_data_incremental(rows, since, timestamp_field="ts"):
    """Filter cost engine rows to only those newer than `since`.

    965-incremental-updates-for-cost-engine: reduces payload size by sending only
    cost datapoints with a timestamp greater than the supplied `since` value.
    """
    since = int(since)
    if not isinstance(rows, list):
        return {"since": since, "total": 0, "rows": []}
    new_rows = [
        row
        for row in rows
        if isinstance(row, dict)
        and timestamp_field in row
        and int(row[timestamp_field]) > since
    ]
    return {"since": since, "total": len(new_rows), "rows": new_rows}
