# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/core/__init__.py
# Project:     ProxmoxVEx
# Version:     1.2.383
# Build:       2026.09.05
# Description: Package initializer for core
# Docs:        https://proxmoxvex.local/docs
# Generated:   2026-09-05
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
