# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/native/opnsense/opnsense_src/client/__init__.py
# Project:     ProxmoxVEx
# Version:     1.2.383
# Build:       2026.09.05
# Description: Package initializer for client
# Docs:        https://proxmoxvex.local/docs
# Generated:   2026-09-05
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
from .cluster import OPNsenseClusterClient  # noqa: F401
from .opnsense_client import (  # noqa: F401
    OPNsenseAuthError,
    OPNsenseClient,
    OPNsenseError,
    OPNsenseHost,
    OPNsenseTimeoutError,
)
