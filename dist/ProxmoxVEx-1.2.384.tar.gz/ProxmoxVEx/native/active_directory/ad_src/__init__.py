# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/native/active_directory/ad_src/__init__.py
# Project:     ProxmoxVEx
# Version:     1.2.383
# Build:       2026.09.05
# Description: Active Directory source package.
# Docs:        https://proxmoxvex.local/docs
# Generated:   2026-09-05
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Active Directory source package."""

from __future__ import annotations
