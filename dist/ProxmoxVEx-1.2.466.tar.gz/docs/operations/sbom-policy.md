# SBOM Update Policy

## Scope

This document describes how the Software Bill of Materials (SBOM) for ProxmoxVEx is maintained.

## Files

- `sbom.json` — CycloneDX JSON SBOM of the runtime Python dependencies.

## Generation

The SBOM is generated from the deployed virtual environment using `cyclonedx-py`:

```bash
python3 -m venv .venv
.venv/bin/pip install -r requirements.txt -r requirements-dev.txt
.venv/bin/pip install cyclonedx-bom
.venv/bin/cyclonedx-py environment .venv/bin/python \
  -o sbom.json \
  --of JSON \
  --pyproject pyproject.toml \
  --output-reproducible
```

## Update cadence

1. **Every release**: The SBOM is regenerated and committed as part of the release branch.
2. **After dependency changes**: When `requirements.txt`, `requirements-dev.txt`, or `pyproject.toml` change, the SBOM must be regenerated in the same pull request.
3. **On-demand**: Before compliance reviews or customer export requests.

## Validation

- The SBOM must be valid CycloneDX JSON.
- The root component should reference `ProxmoxVEx` from `pyproject.toml`.
- License fields should be reviewed for high-risk or missing entries before release.

## Distribution

- The SBOM is published with each GitHub release.
- Customers may request the SBOM in SPDX format by opening an issue or through support.

## Exceptions

- Vendored or bundled JavaScript libraries in `web/` and `static/` are not included in `sbom.json` and are tracked separately if required.
- Plugin dependencies are not included unless the plugin is bundled in the release image.
