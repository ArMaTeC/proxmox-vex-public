# Service Level Objectives

## Scope

These SLOs cover the core management operations of ProxmoxVEx as observed from the user interface and API. They are advisory and intended for operators who run the application in production.

## SLIs and SLOs

### Authentication and session management

| SLI                              | SLO                 | Measurement                                                   |
| -------------------------------- | ------------------- | ------------------------------------------------------------- |
| Login success rate               | >99.9% over 30 days | `login_success / login_attempts` excluding brute-force blocks |
| Session validation latency (p95) | <100 ms             | Time to validate a session token on an authenticated request  |

### Cluster discovery and listing

| SLI                        | SLO                 | Measurement                                  |
| -------------------------- | ------------------- | -------------------------------------------- |
| Cluster list availability  | >99.5% over 30 days | `/api/clusters` success rate                 |
| Cluster list latency (p95) | <500 ms             | End-to-end response time for `/api/clusters` |

### VM and container power actions

| SLI                                      | SLO                 | Measurement                                             |
| ---------------------------------------- | ------------------- | ------------------------------------------------------- |
| Power action acceptance                  | >99.5% over 30 days | Successful API submission of start/stop/restart/destroy |
| Power action task creation latency (p95) | <1 s                | Time from API request to Proxmox task ID returned       |

### Metrics and live data

| SLI                             | SLO           | Measurement                                                |
| ------------------------------- | ------------- | ---------------------------------------------------------- |
| SSE metrics stream availability | >99% per 24 h | Percentage of time the `/api/realtime` stream is reachable |
| Metrics update latency (p95)    | <5 s          | Time between data point collection and SSE push            |

### Audit logging

| SLI                            | SLO                             | Measurement                                     |
| ------------------------------ | ------------------------------- | ----------------------------------------------- |
| Audit log durability           | 100% of state-changing requests | All POST/PUT/DELETE logged with HMAC signature  |
| Audit log search latency (p95) | <2 s                            | Search + filter + paginate over 90 days of logs |

## Error budget

The error budget for any 30-day window is:

- **100% - SLO target** for the relevant SLI.
- When the error budget is exhausted, feature work pauses and reliability work is prioritized.

## Alerting

SLOs are not the same as on-call alerts. Use these SLOs to define alerting thresholds:

- **Warning**: Burn rate >10% over 6 hours.
- **Critical**: Burn rate >50% over 1 hour.
