# 0001 Cross-Origin Isolation Headers

**Date**: 2026-08-03

**Status**: Accepted

## Context

ProxmoxVEx already emitted a set of HTTP security headers (`X-Content-Type-Options`, `X-Frame-Options`, `X-XSS-Protection`, `Referrer-Policy`, `Permissions-Policy`, `Content-Security-Policy`, and `Strict-Transport-Security`). Modern browsers support additional cross-origin isolation headers that reduce side-channel and information-leakage risks:

- `Cross-Origin-Resource-Policy` (CORP): tells the browser whether the page can be loaded as a subresource from another origin.
- `Cross-Origin-Opener-Policy` (COOP): controls whether a top-level document can be opened by a cross-origin window.

The application uses same-origin plugin frontends loaded inside iframes and occasionally opens VNC/terminal popups. Any cross-origin isolation decision had to preserve those same-origin interactions while hardening the default posture.

## Decision

Add the following headers to the existing `add_security_headers` after-request hook in `ProxmoxVEx/app.py`:

- `Cross-Origin-Resource-Policy: same-origin`
- `Cross-Origin-Opener-Policy: same-origin-allow-popups`

`same-origin` for CORP means the application will not be embedded or loaded as a subresource from another origin, while still allowing same-origin plugin UI.

`same-origin-allow-popups` for COOP means popups retain limited access to the opener when same-origin, while cross-origin windows are isolated. This matches the existing `frame-ancestors 'self'` and `X-Frame-Options: SAMEORIGIN` choices for plugin frontends.

## Consequences

- **Positive**: Reduces cross-origin information leakage and side-channel attack surface.
- **Positive**: Aligns the application with modern browser security headers.
- **Negative / Risk**: If an integration legitimately embeds ProxmoxVEx from another origin, that embed will now be blocked by CORP. This is intentional; such integrations should use a documented, authenticated API or proxy rather than iframe embedding.
- **Neutral**: No JavaScript or build changes are required; the headers are added in one central Flask after-request hook.

## References

- Implementation: `ProxmoxVEx/app.py` `add_security_headers` function.
- Related decision: X-Frame-Options `SAMEORIGIN` and CSP `frame-ancestors 'self'`.
