# Architecture Decision Records (ADRs)

This directory records significant architectural decisions for the ProxmoxVEx project. Each record is a short document describing the context, the decision, and the consequences.

## Format

Use the sequential four-digit prefix `NNNN-` in filenames:

```text
docs/adr/
├── README.md
├── 0001-cross-origin-isolation-headers.md
└── 0002-example-decision.md
```

## Template

Each ADR should include the following sections:

```markdown
# [Number] [Title]

**Date**: YYYY-MM-DD

**Status**: Proposed / Accepted / Deprecated / Superseded by [number]

## Context

What problem, constraint, or requirement motivated this decision?

## Decision

What was decided?

## Consequences

What becomes easier or harder because of this decision? What alternatives were considered?

## References

Links, issues, or pull requests related to this decision.
```

## Index

| Number | Title                          | Status   |
| ------ | ------------------------------ | -------- |
| 0001   | Cross-Origin Isolation Headers | Accepted |
