# Feature Deprecation and Sunset Policy

## Purpose

This policy describes how features, settings, and plugin contracts are deprecated and removed from ProxmoxVEx. The goal is to give operators and plugin authors predictable upgrade paths while keeping the codebase maintainable.

## Definitions

- **Deprecated**: A feature or contract that is still present but no longer recommended. It continues to work and is documented as deprecated.
- **Removed / Sunset**: A deprecated feature that has been deleted and no longer exists.

## Process

1. **Announcement** — A feature is marked deprecated in the release notes and in the relevant code or manifest at least one major release before removal.
2. **Warning period** — During the deprecation period, the application emits warnings when the feature is used, where practical.
3. **Migration guide** — The release that announces deprecation includes a migration path in the release notes.
4. **Removal** — The feature is removed in a subsequent major or minor release, based on the schedule below.

## Timeline

| Type                    | Deprecation notice               | Minimum support before removal |
| ----------------------- | -------------------------------- | ------------------------------ |
| UI-only feature         | Release notes + inline notice    | 1 minor release                |
| API endpoint or setting | Release notes + warning log      | 2 minor releases               |
| Plugin contract version | Release notes + registry warning | 1 major release                |
| Authentication method   | Release notes + admin alert      | 2 major releases               |

## Exceptions

- Security-critical features may be removed or disabled immediately if they pose an active risk.
- Features with zero observed usage for two consecutive releases may be fast-tracked for removal.

## Compatibility and version numbering

ProxmoxVEx follows semantic versioning. Breaking changes, including removals, increment the major version.

## Reversibility

A removed feature is not reintroduced under the same name or path. A successor feature must use a new name or endpoint.
