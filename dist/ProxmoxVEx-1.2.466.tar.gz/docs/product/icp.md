# Ideal Customer Profile (ICP)

## Primary ICP

Organizations that run **multiple Proxmox VE and/or ESXi clusters** and need a **unified management, compliance, and automation layer** rather than operating each cluster independently.

### Firmographics

- **Size**: 50–5,000 employees
- **Industries**: Managed service providers, hosting providers, mid-to-large enterprises with private cloud, regulated industries (healthcare, finance, public sector)
- **Infrastructure**: 2–50 hypervisor nodes across 2+ clusters; mix of Proxmox VE and optionally ESXi
- **Compliance posture**: Required or aspirational SOC 2, ISO 27001, NIS2, BSI Grundschutz, or HIPAA alignment
- **Team mix**: 1–5 platform admins, 2–10 DevOps/SRE users, 1+ security/compliance reviewer

### Must-have pain points

1. **Cluster sprawl**: Operators log in to multiple Proxmox web UIs to manage workloads.
2. **Compliance evidence**: Security teams spend hours collecting proof for auditors.
3. **Drift and change control**: Configuration changes are not tracked or baselined.
4. **Tenant or chargeback needs**: Costs or access must be separated by customer, department, or project.

### Must-have buying triggers

- Preparing for an audit or security certification.
- Merging or consolidating multiple clusters after an acquisition.
- Launching a managed private-cloud or IaaS offering.
- Replacing an aging, unsupported hypervisor management tool.

### Nice-to-have signals

- Already using Prometheus/Grafana and wants a single monitoring and management UI.
- Running Ceph or ZFS and needs storage-level visibility.
- Has an existing ACME or Let's Encrypt workflow for certificates.

### Out-of-profile signals

- Single-node homelab or single-cluster deployment with no compliance needs.
- Fully public-cloud native (AWS/Azure/GCP) with no on-premise hypervisors.
- Teams that prefer CLI-only management and have no UI/audit expectations.
