# User Personas

## Alex — Platform Administrator

- **Role**: Senior sysadmin / infrastructure lead
- **Primary goal**: Keep dozens of Proxmox and ESXi clusters healthy, patched, and compliant with minimal downtime.
- **Typical workflow**: Reviews CVE dashboards, schedules rolling node updates, audits user actions, manages storage and Ceph pools, configures backup SLAs.
- **Pain points**: Context switching between many cluster UIs; alert fatigue; proving compliance to auditors; tracing who changed what.
- **Success looks like**: A single pane of glass with a clear audit trail, reliable automation, and role-based access that lets the team self-serve.

## Bailey — DevOps Engineer

- **Role**: DevOps / SRE responsible for CI/CD and VM lifecycle
- **Primary goal**: Provision, clone, and decommission VMs and templates quickly and repeatably.
- **Typical workflow**: Deploys from the Cloud-Init template library, snapshots before releases, migrates workloads for zero-downtime deploys, tracks cost/chargeback.
- **Pain points**: Manual VM configuration drift; slow provisioning; lack of API/CLI parity; cost visibility per team.
- **Success looks like**: One-click deploys, template-based reproducibility, and a clear cost breakdown per project.

## Casey — Security / Compliance Officer

- **Role**: CISO, GRC, or security auditor
- **Primary goal**: Verify that the platform meets security baselines and produces evidence for SOC 2, ISO 27001, NIS2, or BSI Grundschutz.
- **Typical workflow**: Exports compliance dashboards and CVE reports, reviews HMAC-signed audit logs, checks CIS hardening scores, inspects RBAC and 2FA status.
- **Pain points**: Evidence is scattered; audit logs are not tamper-evident; hardening drift is not visible.
- **Success looks like**: Read-only compliance views, exportable PDFs, automated drift detection, and an immutable audit log.

## Dana — MSP / Multi-Tenant Operator

- **Role**: Managed service provider running clusters for multiple customers
- **Primary goal**: Isolate tenants, bill accurately, and delegate limited self-service to customers.
- **Typical workflow**: Sets up clusters per tenant, configures custom roles and cluster whitelists, reviews chargeback dashboards, manages per-tenant storage.
- **Pain points**: Manual tenant onboarding; cross-tenant data leakage risk; per-customer cost tracking.
- **Success looks like**: Multi-tenancy boundaries, per-tenant branding and RBAC, and automated chargeback reporting.
