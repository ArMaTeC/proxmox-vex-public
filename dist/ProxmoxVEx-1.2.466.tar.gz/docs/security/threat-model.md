# Threat Model

**Scope**: ProxmoxVEx web application, API, plugin system, and outbound cluster integrations.

**Last updated**: 2026-08-03

## Threat actors

| Actor                            | Capability             | Motivation                                                |
| -------------------------------- | ---------------------- | --------------------------------------------------------- |
| Anonymous attacker               | Low                    | Defacement, credential theft, cryptomining                |
| Authenticated user (insider)     | Medium                 | Lateral movement, data exfiltration, privilege escalation |
| Cluster admin account compromise | High                   | Full cluster takeover, VM exfiltration, ransomware        |
| Malicious plugin                 | High (runs in-process) | Credential harvesting, data exfiltration, persistence     |
| Network attacker (MITM)          | Medium                 | Session hijacking, API call tampering                     |

## Data flow diagram

```text
Admin/Browser -> TLS -> Flask (ProxmoxVEx) -> SQLCipher DB
                                  |
                                  v
                     Proxmox VE / ESXi APIs
                                  |
                                  v
                       SSH / VNC / Syslog endpoints
```

## STRIDE analysis

### Spoofing

- **Threat**: Attacker brute-forces admin password or steals session token.
- **Mitigations**: 2FA, WebAuthn, session TTL, brute-force lockout, HMAC-signed audit log.

### Tampering

- **Threat**: Attacker modifies cluster API call to destroy or exfiltrate VMs.
- **Mitigations**: HTTPS to cluster APIs, TLS verification by default, audit logs, RBAC.

- **Threat**: Attacker modifies the local SQLite database.
- **Mitigations**: SQLCipher full-DB encryption, Fernet field encryption, separate master key.

### Repudiation

- **Threat**: Attacker denies performing a destructive action.
- **Mitigations**: HMAC-signed audit log, SIEM forwarding, immutable backup of audit data.

### Information disclosure

- **Threat**: Cross-origin information leakage or credential exposure in logs.
- **Mitigations**: CSP, CORP/COOP headers, Referrer-Policy, no secrets in logs, input validation.

### Denial of service

- **Threat**: Resource exhaustion via API abuse or SSH connection flood.
- **Mitigations**: Rate limiting, SSH connection pool limits, request timeouts.

### Elevation of privilege

- **Threat**: Low-privilege user gains admin access.
- **Mitigations**: RBAC, tenant isolation, VM-level ACLs, least-privilege cluster tokens.

## Plugin-specific risks

- Plugins run in the same process and can access the Flask `app` object.
- Risk: malicious or compromised plugin exfiltrates data.
- Mitigations: plugin manifest review, sandboxing plans, allowed route methods, documented security boundaries (see `docs/architecture/plugin-contract.md`).

## Out-of-scope assumptions

- Physical host security is handled by the operator.
- Network segmentation between ProxmoxVEx and cluster APIs is assumed.
- Backup media encryption is out of scope for this threat model.

## Review cadence

- Review after every major release.
- Review after adding new cluster integrations, authentication methods, or plugin capabilities.
