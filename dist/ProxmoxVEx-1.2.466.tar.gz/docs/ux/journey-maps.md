# User Journey Maps

These maps describe the primary user journeys for the personas defined in `docs/product/personas.md`. They are intended to inform UX improvements, progressive disclosure, and role-based defaults.

## Alex — Platform Administrator

**Goal**: Identify and resolve cluster health issues before they affect users.

| Step | Action                      | Feeling     | Pain point                      | Opportunity                                        |
| ---- | --------------------------- | ----------- | ------------------------------- | -------------------------------------------------- |
| 1    | Logs in                     | Neutral     | —                               | —                                                  |
| 2    | Opens the unified dashboard | Overwhelmed | Too many widgets                | Show role-aware default: cluster health + alerts   |
| 3    | Clicks through alerts       | Anxious     | Alert noise, no severity filter | Surface high-severity alerts first                 |
| 4    | Drills into a node          | Focused     | Hard to correlate metrics       | Link live metrics to the node view                 |
| 5    | Schedules a rolling update  | Cautious    | Unclear impact scope            | Show affected VMs and estimated maintenance window |
| 6    | Reviews audit log           | Confident   | Good traceability               | Maintain HMAC-signed logs                          |

## Bailey — DevOps Engineer

**Goal**: Deploy a new VM from a template in under two minutes.

| Step | Action                   | Feeling   | Pain point                          | Opportunity                                |
| ---- | ------------------------ | --------- | ----------------------------------- | ------------------------------------------ |
| 1    | Opens template library   | Excited   | Many templates, no favorites        | Add favorites and recent templates         |
| 2    | Selects a template       | Uncertain | Unclear template requirements       | Show per-template notes and dependencies   |
| 3    | Fills VM configuration   | Neutral   | Repetitive field entry              | Save form presets per project              |
| 4    | Chooses a target cluster | Anxious   | Not sure which cluster has capacity | Show capacity summary per cluster          |
| 5    | Confirms deploy          | Confident | —                                   | Provide a clear success/rollback toast     |
| 6    | Checks cost/chargeback   | Curious   | Cost not visible at deploy time     | Show estimated monthly cost before confirm |

## Casey — Security / Compliance Officer

**Goal**: Export evidence for an upcoming SOC 2 audit.

| Step | Action                            | Feeling   | Pain point                   | Opportunity                             |
| ---- | --------------------------------- | --------- | ---------------------------- | --------------------------------------- |
| 1    | Logs in as auditor role           | Neutral   | Needs read-only access       | Default dashboard to compliance view    |
| 2    | Navigates to compliance dashboard | Relieved  | Good mapping to controls     | Maintain BSI / ISO / SOC 2 mapping      |
| 3    | Exports hardening score           | Satisfied | Need PDF evidence            | Add export to PDF                       |
| 4    | Reviews CVE report                | Concerned | Severity not linked to owner | Add per-cluster owner notifications     |
| 5    | Downloads audit log               | Focused   | CSV export is too raw        | Provide filter + severity + date export |
| 6    | Verifies HMAC signature           | Confident | Good tamper evidence         | Document signature verification steps   |

## Dana — MSP / Multi-Tenant Operator

**Goal**: Create a new customer tenant and delegate limited access.

| Step | Action                       | Feeling   | Pain point                   | Opportunity                       |
| ---- | ---------------------------- | --------- | ---------------------------- | --------------------------------- |
| 1    | Opens tenant management      | Neutral   | —                            | —                                 |
| 2    | Creates tenant               | Cautious  | Unclear RBAC scoping         | Provide role templates per tenant |
| 3    | Assigns clusters             | Anxious   | Risk of cross-tenant leakage | Visual cluster/tenant boundaries  |
| 4    | Adds customer user           | Neutral   | Manual user creation         | Bulk invite via CSV               |
| 5    | Reviews chargeback dashboard | Focused   | Cost attribution unclear     | Per-tenant cost breakdown         |
| 6    | Generates monthly report     | Satisfied | —                            | Automated scheduled exports       |

## Research notes

- These maps are based on the feature set described in `README.md` and the personas in `docs/product/personas.md`.
- Validate with real users and update after interviews.
- Use the pain points to prioritize Phase 3 and Phase 4 work.
