/* --- ProxmoxVEx auto-header start ---
 * -------------------------------------------------------------------
 * File:        static/js/native-dataview.js
 * Project:     ProxmoxVEx
 * Version:     1.2.432
 * Build:       2026.09.11
 * Description: Shared read-only dataview renderer for native integrations.
 * Docs:        https://proxmoxvex.com/docs
 * Generated:   2026-09-11
 * -------------------------------------------------------------------
 * --- ProxmoxVEx auto-header end --- */
/* Shared shell + renderer for the lightweight native integrations
   (vmware_vcenter, pfsense, vyos, zabbix, active_directory). These pages all
   consume the same {ok, data, error, detail} envelope, so instead of the old
   <pre> JSON dumps each module now declares its tabs declaratively and the
   renderer below produces KPI cards, KV lists and tables. All remote values
   are rendered via textContent so API data can never inject markup. */
(function () {
    'use strict';

    // ---------- i18n ----------
    var _i18n = null;
    var _ns = 'core';
    var _localDict = null; // en.json fetched directly when not embedded in the host app
    try { _i18n = window.parent.ProxmoxVExI18n; } catch (e) { /* standalone */ }

    function t(key) {
        if (_i18n) {
            var v = _i18n.t(key, { ns: _ns });
            if (v !== key) return v;
            v = _i18n.t(key, { ns: 'core' });
            if (v !== key) return v;
        }
        if (_localDict && _localDict[key] != null) return _localDict[key];
        return key;
    }

    function tf(key) {
        var s = t(key);
        for (var i = 1; i < arguments.length; i++) {
            s = s.replace('%s', String(arguments[i])).replace('%d', String(arguments[i]));
        }
        return s;
    }

    // ---------- DOM ----------
    function el(tag, attrs) {
        var node = document.createElement(tag);
        if (attrs) {
            for (var k in attrs) {
                if (k === 'class') node.className = attrs[k];
                else if (k === 'text') node.textContent = attrs[k];
                else if (k === 'html') node.textContent = attrs[k];
                else node.setAttribute(k, attrs[k]);
            }
        }
        for (var i = 2; i < arguments.length; i++) {
            var c = arguments[i];
            if (c == null) continue;
            if (Array.isArray(c)) { c.forEach(function (x) { if (x) node.appendChild(x); }); }
            else if (typeof c === 'object') node.appendChild(c);
            else node.appendChild(document.createTextNode(String(c)));
        }
        return node;
    }

    // ---------- formatting ----------
    function titleize(key) {
        return String(key).replace(/[_-]+/g, ' ').replace(/\b\w/g, function (m) { return m.toUpperCase(); });
    }

    function fmtNum(n) {
        if (n == null || n === '') return '—';
        var v = Number(n);
        if (Number.isNaN(v)) return String(n);
        return v.toLocaleString();
    }

    function fmtBytes(n) {
        var v = Number(n);
        if (Number.isNaN(v)) return String(n);
        var u = ['B', 'KB', 'MB', 'GB', 'TB', 'PB'];
        var i = 0;
        while (v >= 1024 && i < u.length - 1) { v /= 1024; i++; }
        return v.toFixed(i > 0 ? 1 : 0) + ' ' + u[i];
    }

    function fmtAgo(v) {
        // Accepts epoch seconds/ms, ISO strings, or a negative "seconds ago" offset.
        var ms;
        var n = Number(v);
        if (!Number.isNaN(n) && v !== '') {
            if (n < 0) ms = Date.now() + n * 1000;
            else if (n < 1e12) ms = n * 1000;
            else ms = n;
        } else {
            ms = Date.parse(v);
        }
        if (Number.isNaN(ms)) return String(v);
        var diff = (Date.now() - ms) / 1000;
        if (diff < 60) return 'just now';
        if (diff < 3600) return Math.floor(diff / 60) + 'm ago';
        if (diff < 86400) return Math.floor(diff / 3600) + 'h ago';
        return Math.floor(diff / 86400) + 'd ago';
    }

    // ---------- components ----------
    var TONE_WORDS = {
        ok: ['ok', 'up', 'on', 'up2', 'enabled', 'enable', 'connected', 'poweredon', 'green', 'pass', 'true', 'yes', 'active', 'online', 'accessible', 'available', 'acknowledged', 'running', 'ready'],
        err: ['down', 'off', 'disabled', 'disable', 'disconnected', 'poweredoff', 'red', 'block', 'reject', 'false', 'no', 'error', 'failed', 'unreachable', 'critical', 'disaster', 'high'],
        warn: ['warn', 'warning', 'yellow', 'average', 'suspended', 'paused', 'degraded', 'unknown', 'maintenance'],
        info: ['info', 'information', 'blue', 'notclassified', 'not_classified']
    };

    function toneFor(value) {
        var s = String(value == null ? '' : value).toLowerCase().replace(/[\s-]+/g, '');
        for (var tone in TONE_WORDS) {
            if (TONE_WORDS[tone].indexOf(s) !== -1) return tone;
        }
        return 'muted';
    }

    function badge(text, tone) {
        return el('span', { class: 'ndv-badge ndv-badge-' + (tone || toneFor(text)), text: text == null || text === '' ? '—' : text });
    }

    function chips(list) {
        var wrap = el('span', { class: 'ndv-chips' });
        (list || []).forEach(function (x) { wrap.appendChild(el('span', { class: 'ndv-chip', text: x })); });
        return wrap;
    }

    function kpiGrid(items) {
        var grid = el('div', { class: 'ndv-kpi-grid' });
        (items || []).forEach(function (it) {
            grid.appendChild(el('div', { class: 'ndv-kpi' },
                el('div', { class: 'ndv-kpi-value' }, it.value == null ? '—' : String(it.value)),
                el('div', { class: 'ndv-kpi-label' }, it.label)));
        });
        return grid;
    }

    function kvList(pairs) {
        // pairs: object or [[label, value], ...]; nested objects render muted-JSON.
        var dl = el('dl', { class: 'ndv-kv' });
        var entries = Array.isArray(pairs) ? pairs : Object.keys(pairs || {}).map(function (k) { return [titleize(k), pairs[k]]; });
        entries.forEach(function (pair) {
            var label = pair[0], value = pair[1];
            dl.appendChild(el('dt', {}, label));
            var dd = el('dd', {});
            if (value == null || value === '') dd.appendChild(el('span', { class: 'muted', text: '—' }));
            else if (value.nodeType) dd.appendChild(value);
            else if (Array.isArray(value)) dd.appendChild(chips(value));
            else if (typeof value === 'object') dd.appendChild(el('code', { class: 'muted', text: JSON.stringify(value) }));
            else if (typeof value === 'boolean') dd.appendChild(badge(value ? t('yes') : t('no'), value ? 'ok' : 'muted'));
            else dd.textContent = String(value);
            dl.appendChild(dd);
        });
        return dl;
    }

    // Columns the renderer treats as visual states rather than plain text.
    var STATE_KEYS = /^(status|state|power_state|connection_state|enabled|accessible|acknowledged|reachable|health)$/i;
    var SKIP_KEYS = /^(mo_ref|moid|moref|_id|id)$/i;

    function dataTable(rows, columns, opts) {
        opts = opts || {};
        if (!rows || !rows.length) {
            return el('div', { class: 'empty', text: opts.emptyText || t('no_data') });
        }
        var cols = columns;
        if (!cols) {
            var keys = [];
            rows.forEach(function (r) {
                if (!r || typeof r !== 'object') return;
                Object.keys(r).forEach(function (k) { if (keys.indexOf(k) === -1) keys.push(k); });
            });
            cols = keys.map(function (k) { return { key: k, label: titleize(k) }; });
        }
        var table = el('table', { class: 'ndv-table' });
        var thead = el('thead', {}, el('tr', {}, cols.map(function (c) { return el('th', {}, c.label); })));
        var tbody = el('tbody', {});
        rows.forEach(function (row) {
            tbody.appendChild(el('tr', {}, cols.map(function (c) {
                var td = el('td', {});
                var v = row ? row[c.key] : undefined;
                if (c.render) {
                    var out = c.render(v, row);
                    if (out == null) td.appendChild(el('span', { class: 'muted', text: '—' }));
                    else if (typeof out === 'object') td.appendChild(out);
                    else td.textContent = String(out);
                } else if (v == null || v === '') {
                    td.appendChild(el('span', { class: 'muted', text: '—' }));
                } else if (STATE_KEYS.test(c.key)) {
                    td.appendChild(badge(typeof v === 'boolean' ? (v ? 'Yes' : 'No') : v));
                } else if (Array.isArray(v)) {
                    td.appendChild(chips(v));
                } else if (typeof v === 'object') {
                    td.appendChild(el('code', { class: 'muted', text: JSON.stringify(v) }));
                } else {
                    td.textContent = String(v);
                }
                return td;
            })));
        });
        table.appendChild(thead);
        table.appendChild(tbody);
        return el('div', { class: 'ndv-table-scroll' }, table);
    }

    function meter(used, total) {
        var pct = total > 0 ? Math.min(100, Math.round((used / total) * 100)) : 0;
        var tone = pct >= 90 ? 'err' : pct >= 75 ? 'warn' : 'ok';
        return el('div', { class: 'ndv-meter', title: pct + '%' },
            el('div', { class: 'ndv-meter-fill ndv-meter-' + tone, style: 'width:' + pct + '%' }));
    }

    function card(titleText) {
        var c = el('section', { class: 'card ndv-card' });
        if (titleText) c.appendChild(el('h2', { class: 'ndv-card-title', text: titleText }));
        return c;
    }

    // ---------- states ----------
    function stateCard(kind, titleText, bodyText) {
        return el('div', { class: 'ndv-state ndv-state-' + kind },
            el('div', { class: 'ndv-state-title', text: titleText }),
            bodyText ? el('div', { class: 'ndv-state-body', text: bodyText }) : null);
    }

    function renderErrorState(container, payload, status) {
        container.textContent = '';
        var err = (payload && payload.error) || 'http_' + (status || 0);
        var detail = payload && payload.detail;
        if (err === 'unconfigured') {
            container.appendChild(stateCard('warn', t('not_configured'), t('not_configured_hint')));
        } else if (err === 'auth') {
            container.appendChild(stateCard('err', t('auth_failed'), detail));
        } else if (err === 'timeout') {
            container.appendChild(stateCard('warn', t('timeout'), detail));
        } else {
            container.appendChild(stateCard('err', tf('error_generic', err), detail));
        }
    }

    // ---------- auto view ----------
    // Fallback renderer for tabs that don't need a bespoke layout: unwrap the
    // {ok,data} envelope and pick table / KV / chips based on the data shape.
    function autoRender(h, container, payload) {
        var data = payload && payload.data;
        if (data == null) {
            container.appendChild(stateCard('muted', t('no_data')));
            return;
        }
        if (Array.isArray(data)) {
            if (!data.length) { container.appendChild(stateCard('muted', t('no_data'))); return; }
            if (data.every(function (x) { return x && typeof x === 'object' && !Array.isArray(x); })) {
                container.appendChild(h.table(data));
            } else {
                container.appendChild(card()).appendChild(chips(data));
            }
            return;
        }
        if (typeof data === 'object') {
            var c = card();
            c.appendChild(h.kv(data));
            container.appendChild(c);
            return;
        }
        container.appendChild(card(t('result'))).appendChild(el('div', { text: String(data) }));
    }

    // ---------- boot ----------
    function boot(cfg) {
        _ns = cfg.ns || _ns;
        var apiBase = cfg.apiBase;
        var tabs = cfg.tabs || [];

        function buildShell() {
            var root = document.getElementById('ndv-root') || document.body;
            root.textContent = '';
            var refreshBtn = el('button', { class: 'secondary ndv-refresh', type: 'button' }, '⟳ ', t('refresh'));
            refreshBtn.addEventListener('click', function () {
                var active = document.querySelector('.ndv-tab[aria-selected="true"]');
                if (active) load(active.dataset.tab, true);
            });
            var head = el('header', { class: 'ndv-header' },
                el('h1', { 'data-i18n': 'title' }, t(cfg.titleKey || 'title')),
                refreshBtn);
            var tabBar = el('div', { class: 'ndv-tabs', role: 'tablist' });
            var main = el('main', {});
            tabs.forEach(function (tab, i) {
                var btn = el('button', {
                    class: 'ndv-tab', role: 'tab', type: 'button',
                    'data-tab': tab.id, 'aria-selected': i === 0 ? 'true' : 'false'
                }, t(tab.label || tab.id));
                btn.addEventListener('click', function () { activate(tab.id); });
                tabBar.appendChild(btn);
                var panel = el('section', { class: 'ndv-panel', id: 'ndv-panel-' + tab.id, role: 'tabpanel' });
                if (i !== 0) panel.setAttribute('hidden', '');
                main.appendChild(panel);
            });
            root.appendChild(el('div', { class: 'ndv-shell' }, head, tabBar, main));
        }

        function activate(id) {
            document.querySelectorAll('.ndv-tab').forEach(function (b) {
                b.setAttribute('aria-selected', b.dataset.tab === id ? 'true' : 'false');
            });
            document.querySelectorAll('.ndv-panel').forEach(function (p) {
                if (p.id === 'ndv-panel-' + id) p.removeAttribute('hidden'); else p.setAttribute('hidden', '');
            });
            load(id, false);
        }

        var loaded = {};
        function load(id, force) {
            var tab = null;
            for (var i = 0; i < tabs.length; i++) if (tabs[i].id === id) tab = tabs[i];
            if (!tab) return;
            if (loaded[id] && !force) return;
            var panel = document.getElementById('ndv-panel-' + id);
            var status = el('div', { class: 'ndv-status muted', text: t('loading') });
            var content = el('div', { class: 'ndv-content' });
            panel.textContent = '';
            panel.appendChild(status);
            panel.appendChild(content);
            fetch(apiBase + '/' + tab.endpoint, { credentials: 'same-origin' })
                .then(function (resp) {
                    return resp.json().catch(function () { return { ok: false, error: 'invalid_json' }; })
                        .then(function (data) { return { resp: resp, data: data }; });
                })
                .then(function (r) {
                    var payload = r.data || {};
                    if (!r.resp.ok || payload.ok === false) {
                        renderErrorState(content, payload, r.resp.status);
                        status.textContent = '';
                        loaded[id] = true; // cache errors too; Refresh clears via force
                        return;
                    }
                    status.textContent = '';
                    content.textContent = '';
                    var h = helpers(content);
                    try {
                        if (tab.render) tab.render(h, payload.data, payload);
                        else autoRender(h, content, payload);
                    } catch (e) {
                        content.textContent = '';
                        content.appendChild(stateCard('err', tf('error_generic', e.message || 'render')));
                    }
                    loaded[id] = true;
                })
                .catch(function (e) {
                    renderErrorState(content, { error: 'network', detail: e.message }, 0);
                    status.textContent = '';
                });
        }

        function helpers(content) {
            return {
                el: el, t: t, tf: tf,
                badge: badge, chips: chips, kv: kvList, table: dataTable,
                kpis: kpiGrid, meter: meter, card: card,
                fmtBytes: fmtBytes, fmtNum: fmtNum, fmtAgo: fmtAgo,
                toneFor: toneFor,
                // Convenience: append a titled card containing a table/kv/etc.
                section: function (titleText, node) {
                    var c = card(titleText);
                    c.appendChild(node);
                    content.appendChild(c);
                    return c;
                },
                root: content
            };
        }

        // i18n: load this module's namespace (en + current lang), then re-render labels.
        // Standalone (no parent bridge): fetch the module's own en.json directly so
        // labels resolve instead of showing raw keys.
        var ready = Promise.resolve();
        if (_i18n && _i18n.loadPluginNamespaceFull) {
            ready = _i18n.loadPluginNamespaceFull(_ns, cfg.i18nBase).catch(function () { });
        } else if (cfg.i18nBase) {
            ready = fetch(cfg.i18nBase + '/en.json')
                .then(function (r) { return r.ok ? r.json() : {}; })
                // no escaping needed: every t() consumer renders via
                // textContent/setAttribute/createTextNode (no HTML sinks exist
                // in this renderer), and escaping here would display literal
                // entities for strings like "Let's Encrypt" or "Cancel & exit"
                .then(function (d) { _localDict = d; })
                .catch(function () { });
        }
        ready.then(function () {
            buildShell();
            if (cfg.titleKey || cfg.title) document.title = t(cfg.titleKey || 'title') + ' - ProxmoxVEx';
            if (tabs.length) activate(tabs[0].id);
        });
    }

    window.NativeDataView = {
        boot: boot,
        // Exported for module-specific renderers.
        el: el, badge: badge, chips: chips, kv: kvList, table: dataTable,
        kpis: kpiGrid, meter: meter, card: card, stateCard: stateCard,
        fmtBytes: fmtBytes, fmtNum: fmtNum, fmtAgo: fmtAgo, titleize: titleize, toneFor: toneFor
    };
})();
