/* --- ProxmoxVEx auto-header start ---
 * -------------------------------------------------------------------
 * File:        web/src/noise.js
 * Project:     ProxmoxVEx
 * Version:     1.2.453
 * Build:       2026.09.14
 * Description: Noise JS source
 * Docs:        https://proxmoxvex.com/docs
 * Generated:   2026-09-14
 * -------------------------------------------------------------------
 * --- ProxmoxVEx auto-header end --- */
try { if (localStorage.getItem('ProxmoxVEx-noise') === 'off') document.body.setAttribute('data-noise', 'off'); } catch (_) { }
