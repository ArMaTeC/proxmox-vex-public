# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/native/fwkit/authz.py
# Project:     ProxmoxVEx
# Version:     1.2.453
# Build:       2026.09.14
# Description: Granular RBAC enforcement shared by the...
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-14
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Granular RBAC enforcement shared by the pfSense/OPNsense integrations.

Every route handler calls `require_perm(plugin_id, domain)` before doing
work; it resolves the session user, applies API-token role capping (a token
never outranks the role it was minted under), evaluates `has_permission`
tenant-aware, and — when denied — appends an audit row so blocked attempts
leave evidence, then returns the standard `forbidden` envelope.

Framework imports (flask, ProxmoxVEx.models) are deferred into the function
bodies so this module stays importable in lint/test contexts where the app
isn't loaded — same convention as the plugin `__init__` modules.

Permission families (defined in `ProxmoxVEx/models/permissions.py`):

    opnsense.{view, connector, rules, aliases, nat, dhcp, dns, vpn,
              services, ops, audit}
    pfsense.{view, connector, rules, aliases, nat, dhcp, dns, vpn,
             services, ops, audit}
"""

from __future__ import annotations

import logging
from typing import Any

log = logging.getLogger(__name__)

# Domains in the shared permission family, in display order. `view` is the
# read floor; `ops` additionally requires step-up for destructive actions.
DOMAINS = (
    "view",
    "connector",
    "rules",
    "aliases",
    "nat",
    "dhcp",
    "dns",
    "vpn",
    "services",
    "ops",
    "audit",
)


def _resolve_user() -> tuple[dict[str, Any] | None, dict[str, Any]]:
    """Return (user, session); both empty-safe outside a request context."""
    try:
        from flask import g, request

        user = getattr(g, "current_user", None)
        session = getattr(request, "session", None) or {}
    except RuntimeError:
        return None, {}
    return user, session


def _cap_token_role(user: dict[str, Any], session: dict[str, Any]) -> dict[str, Any]:
    """API tokens are capped at their bound role (mirrors the legacy plugin
    `_require_manage` behaviour): a token never outranks its mint role."""
    if not (user and session.get("api_token")):
        return user
    from ProxmoxVEx.models.permissions import ROLE_ADMIN, ROLE_USER, ROLE_VIEWER

    hierarchy = {ROLE_ADMIN: 3, ROLE_USER: 2, ROLE_VIEWER: 1}
    eff = min(
        hierarchy.get(str(session.get("role") or ""), 1),
        hierarchy.get(str(user.get("role") or ""), 1),
    )
    role = next((r for r, lvl in hierarchy.items() if lvl == eff), ROLE_VIEWER)
    return {**user, "role": role, "effective_role": role, "permissions": []}


def current_actor(default: str = "plugin") -> str:
    """Best-effort username for audit rows."""
    user, session = _resolve_user()
    if user:
        # db.get_user() rows don't carry `username`; the request session does
        # (session["user"]), so fall back to it before `default` — otherwise
        # every session/token actor lands in the audit log as "unknown".
        return str(user.get("username") or user.get("id") or session.get("user") or default)
    return default


def _tenant_id(user: dict[str, Any], session: dict[str, Any]) -> str | None:
    return session.get("tenant_id") or (user or {}).get("tenant_id")


def has_perm(plugin_id: str, domain: str, user: dict[str, Any] | None, tenant_id: str | None = None) -> bool:
    from ProxmoxVEx.utils.rbac import has_permission

    if not user:
        return False
    return bool(has_permission(user, f"{plugin_id}.{domain}", tenant_id))


def effective_permissions(plugin_id: str) -> list[str]:
    """Domains the current caller can use — embedded in the health payload so
    the UI can hide/disable controls. Server-side checks stay authoritative."""
    user, session = _resolve_user()
    if user is None:
        return []
    user = _cap_token_role(user, session)
    tenant = _tenant_id(user, session)
    return [d for d in DOMAINS if has_perm(plugin_id, d, user, tenant)]


def require_perm(
    plugin_id: str,
    domain: str,
    *,
    audit=None,
    host: str = "",
) -> tuple[int, dict[str, Any]] | None:
    """Enforce `<plugin_id>.<domain>` for the current request.

    Returns None when the caller may proceed; otherwise a `(status, payload)`
    tuple the handler must return immediately. Denials are written to the
    plugin audit log when `audit` (an fwkit AuditLog) is supplied.
    """
    from .audit import AuditEntry  # local import keeps module light

    user, session = _resolve_user()
    if user is None:
        return 401, {"ok": False, "error": "auth", "detail": "authentication required"}

    capped = _cap_token_role(user, session)
    tenant = _tenant_id(capped, session)
    perm = f"{plugin_id}.{domain}"
    if has_perm(plugin_id, domain, capped, tenant):
        return None

    # same username gap as current_actor: user rows lack `username`; the
    # session carries it under "user" — denied evidence must name the actor.
    actor = str(capped.get("username") or capped.get("id") or session.get("user") or "unknown")
    if audit is not None:
        audit.append(AuditEntry.now(
            user=actor,
            action="denied",
            target=perm,
            host=host,
            result="denied",
            duration_ms=0,
            detail=f"missing permission {perm}",
        ))
    log.info("rbac: %s denied %s (tenant=%s)", actor, perm, tenant)
    return 403, {
        "ok": False,
        "error": "forbidden",
        "detail": f"missing permission {perm}",
    }


def require_ops_stepup():
    """Step-up MFA guard for destructive appliance operations.

    Wraps `utils.stepup.require_stepup("firewall.ops")`; the category maps to
    the `*.ops` permissions in DESTRUCTIVE_CATEGORIES and can be toggled via
    the `mfa_stepup_categories` server setting like every other category.
    Returns None when the request may proceed.
    """
    try:
        from ProxmoxVEx.utils.stepup import require_stepup
    except ImportError:  # pragma: no cover - outside ProxmoxVEx host
        return None
    denied = require_stepup("firewall.ops")
    if denied is None:
        return None
    # require_stepup returns a Flask (response, status) — the native route
    # handlers return (status, payload); normalize so callers can return the
    # tuple directly.
    try:
        resp, status = denied
        payload = resp.get_json(silent=True) if hasattr(resp, "get_json") else None
        return status, payload or {"ok": False, "error": "stepup_required", "detail": "MFA step-up required"}
    except (TypeError, ValueError):
        return 403, {"ok": False, "error": "stepup_required", "detail": "MFA step-up required"}
