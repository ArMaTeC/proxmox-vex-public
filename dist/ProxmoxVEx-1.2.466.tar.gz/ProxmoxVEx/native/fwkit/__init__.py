# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/native/fwkit/__init__.py
# Project:     ProxmoxVEx
# Version:     1.2.453
# Build:       2026.09.14
# Description: Shared firewall-appliance kernel (`fwkit`).
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-14
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Shared firewall-appliance kernel (`fwkit`).

Both appliance-native plugins (pfSense via FauxAPI, OPNsense via the REST
API) share the same cross-cutting machinery so behaviour stays identical:

- `audit`      — append-only JSONL audit recorder (moved from
                 `opnsense_src/writers/audit.py`; the old module is a shim).
- `hasync`     — HA peer sync + post-write verification with backoff.
- `results`    — normalized `WriteResult` shape returned by every writer.
- `divergence` — cross-node divergence detector (extended beyond runtime
                 state to config sections: rules, aliases, NAT, DHCP, DNS).
- `normalize`  — platform payload → canonical entity dicts consumed by the
                 shared `firewall-manager.js` UI.
- `payloads`   — standard response envelopes (`unconfigured`, error mapping,
                 confirm-token extraction).
- `authz`      — `require_perm(plugin, domain)` per-route RBAC enforcement
                 with API-token role capping and denied-attempt auditing.

Importable both as `ProxmoxVEx.native.fwkit` (in-app) and, for tests, with
the plugin dir on `sys.path` — modules defer framework imports (Flask,
ProxmoxVEx.models) into function bodies so the package stays importable in
lint/test contexts.
"""

from .audit import AuditEntry, AuditLog, TimedAction, hash_payload  # noqa: F401
from .results import WriteResult  # noqa: F401
