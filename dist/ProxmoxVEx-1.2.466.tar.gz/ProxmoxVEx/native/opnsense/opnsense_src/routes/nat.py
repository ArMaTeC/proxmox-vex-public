# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/native/opnsense/opnsense_src/routes/nat.py
# Project:     ProxmoxVEx
# Version:     1.2.453
# Build:       2026.09.14
# Description: NAT route payloads — all three kinds under one route...
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-14
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""NAT route payloads — all three kinds under one route (spec 003 parity
with the pfSense `nat` route):

- `port_forward` → `/api/firewall/d_nat`   (DnatWriter)
- `outbound`     → `/api/firewall/source_nat` (NatWriter)
- `one_to_one`   → `/api/firewall/one_to_one` (OneToOneNatWriter)

GET returns a merged canonical `rules[]`; POST takes `kind` (default
`port_forward` to match the pfSense route). The legacy `one_to_one`
route keeps working — it delegates here with kind pinned.
"""

from __future__ import annotations

import dataclasses
import logging
from typing import Any

from opnsense_src._fwkit import ensure_fwkit_importable
from opnsense_src.client import OPNsenseClient, OPNsenseHost
from opnsense_src.routes._domain import dispatch_action, make_writer
from opnsense_src.writers import NatInput, NatWriter, OneToOneNatInput, OneToOneNatWriter
from opnsense_src.writers.dnat import DnatInput, DnatWriter

ensure_fwkit_importable()

from ProxmoxVEx.native.fwkit.normalize import normalize_nat  # noqa: E402
from ProxmoxVEx.native.fwkit.payloads import client_error_envelope, ok  # noqa: E402

log = logging.getLogger(__name__)

_SEARCH = {
    "port_forward": "/api/firewall/d_nat/searchRule",
    "outbound": "/api/firewall/source_nat/searchRule",
    "one_to_one": "/api/firewall/one_to_one/searchRule",
}


def build_nat_list_payload(host: OPNsenseHost) -> tuple[int, dict[str, Any]]:
    client = OPNsenseClient(host)
    try:
        rules: list[dict[str, Any]] = []
        for kind, path in _SEARCH.items():
            try:
                out = client.get(path)
            except Exception as e:
                log.warning("nat %s list failed: %s", kind, e)
                continue
            rows = out.get("rows", []) if isinstance(out, dict) else []
            for i, row in enumerate(rows):
                rules.append(normalize_nat(row, "opnsense", kind, i))
        return ok({"rules": rules, "total": len(rules)})
    except Exception as e:
        return client_error_envelope(e, log_label="opnsense nat list")


def _uuid(body: dict[str, Any]) -> str:
    uid = str(body.get("uuid", ""))
    if not uid:
        raise ValueError("uuid is required")
    return uid


def _toggle(writer: Any, input_cls: Any, body: dict[str, Any]) -> Any:
    """Flip `enabled` on a NAT row — fetch via getRule, rebuild the kind's
    Input with the flag inverted, write back via setRule (update). Matches
    the rules route's _toggle and gives OPNsense the pfSense toggle verb."""
    uid = _uuid(body)
    current = writer.get(uid)
    row = (current.get("rule") or current.get("rows") or {})
    if not isinstance(row, dict) or not row:
        raise ValueError(f"nat rule {uid} not found")
    # source_nat models disable via `disabled`; d_nat/one_to_one use `enabled`.
    if "disabled" in row:
        enabled_now = str(row["disabled"]) in ("0", "false", "no")
    else:
        enabled_now = str(row.get("enabled", "1")) in ("1", "true", "yes")
    kwargs: dict[str, Any] = {}
    for f in dataclasses.fields(input_cls):
        if f.name == "enabled" or f.name not in row:
            continue
        v = row[f.name]
        if f.type == "bool" or f.type is bool:
            v = v in (True, "1", "true", "yes")
        kwargs[f.name] = v
    kwargs["enabled"] = not enabled_now
    return writer.update(uid, input_cls(**kwargs))


def _dnat_input(body: dict[str, Any]) -> DnatInput:
    rule = body.get("rule") or {}
    if not isinstance(rule, dict):
        raise ValueError("rule must be an object")
    return DnatInput(
        interface=str(rule.get("interface", "")),
        target=str(rule.get("target", "")),
        target_port=str(rule.get("target_port", "")),
        source_net=str(rule.get("source_net", "any")) or "any",
        destination_net=str(rule.get("destination_net", "any")) or "any",
        destination_port=str(rule.get("destination_port", "")),
        protocol=str(rule.get("protocol", "tcp")),
        ipprotocol=str(rule.get("ipprotocol", "inet")),
        description=str(rule.get("description", "")),
        enabled=bool(rule.get("enabled", True)),
    )


def _nat_input(body: dict[str, Any]) -> NatInput:
    rule = body.get("rule") or {}
    if not isinstance(rule, dict):
        raise ValueError("rule must be an object")
    return NatInput(
        interface=str(rule.get("interface", "")),
        target=str(rule.get("target", "")),
        source_net=str(rule.get("source_net", "any")) or "any",
        destination_net=str(rule.get("destination_net", "any")) or "any",
        description=str(rule.get("description", "")),
        enabled=bool(rule.get("enabled", True)),
        ipprotocol=str(rule.get("ipprotocol", "inet")),
        protocol=str(rule.get("protocol", "any")),
    )


def _oto_input(body: dict[str, Any]) -> OneToOneNatInput:
    rule = body.get("rule") or {}
    if not isinstance(rule, dict):
        raise ValueError("rule must be an object")
    return OneToOneNatInput(
        interface=str(rule.get("interface", "")),
        source_net=str(rule.get("source_net", "")),
        external=str(rule.get("external") or rule.get("external_net") or rule.get("target", "")),
        destination_net=str(rule.get("destination_net", "any")) or "any",
        description=str(rule.get("description", "")),
        enabled=bool(rule.get("enabled", True)),
    )


def build_nat_action_payload(
    host: OPNsenseHost,
    plugin_dir: str,
    body: dict[str, Any],
    *,
    peer_host: OPNsenseHost | None = None,
    actor: str = "plugin",
    read_only: bool = False,  # legacy kwarg — read_only is enforced by the caller now
) -> tuple[int, dict[str, Any]]:
    kind = str(body.get("kind") or (body.get("rule") or {}).get("kind") or "port_forward")
    if kind not in _SEARCH:
        return 400, {"ok": False, "error": "bad_request", "detail": f"kind must be one of {sorted(_SEARCH)}"}

    if kind == "outbound":
        writer = make_writer(NatWriter, host, peer_host, plugin_dir, actor)
        actions = {
            "create": lambda b: writer.create(_nat_input(b)),
            "update": lambda b: writer.update(_uuid(b), _nat_input(b)),
            "delete": lambda b: writer.delete(_uuid(b)),
            "toggle": lambda b: _toggle(writer, NatInput, b),
        }
    elif kind == "one_to_one":
        writer = make_writer(OneToOneNatWriter, host, peer_host, plugin_dir, actor)
        actions = {
            "create": lambda b: writer.create(_oto_input(b)),
            "update": lambda b: writer.update(_uuid(b), _oto_input(b)),
            "delete": lambda b: writer.delete(_uuid(b)),
            "toggle": lambda b: _toggle(writer, OneToOneNatInput, b),
        }
    else:  # port_forward
        writer = make_writer(DnatWriter, host, peer_host, plugin_dir, actor)
        actions = {
            "create": lambda b: writer.create(_dnat_input(b)),
            "update": lambda b: writer.update(_uuid(b), _dnat_input(b)),
            "delete": lambda b: writer.delete(_uuid(b)),
            "toggle": lambda b: _toggle(writer, DnatInput, b),
        }

    # Legacy callers sent bare `action: create/delete` without `kind` —
    # default used to be outbound NAT. Keep that default when the body has
    # no kind hint at all and the action is a legacy verb.
    return dispatch_action(writer, body, actions)


def build_nat_legacy_payload(
    host: OPNsenseHost,
    plugin_dir: str,
    body: dict[str, Any],
    **kwargs: Any,
) -> tuple[int, dict[str, Any]]:
    """Backwards-compat entry: no `kind` in the body means outbound NAT,
    matching the pre-1.15 route semantics."""
    if "kind" not in body:
        body = {**body, "kind": "outbound"}
    return build_nat_action_payload(host, plugin_dir, body, **kwargs)
