# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/native/opnsense/opnsense_src/routes/vpn.py
# Project:     ProxmoxVEx
# Version:     1.2.453
# Build:       2026.09.14
# Description: VPN route payloads — identical wire surface to the...
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-14
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""VPN route payloads — identical wire surface to the pfSense `vpn` route
(spec 003 US5): same list keys, same action verbs.

GET → {status, wireguard[], ipsec:{phase1, phase2}, openvpn:{servers, clients}}

POST actions:
  wg_set / wg_delete                  — WireGuard peers (client rows)
  ipsec_p1_set / ipsec_p1_delete      — IPsec connections (phase-1)
  ipsec_p2_set / ipsec_p2_delete      — IPsec children (phase-2 selectors)
  openvpn_server_set / *_delete       — OpenVPN instances with role=server
  openvpn_client_set / *_delete       — OpenVPN instances with role=client
"""

from __future__ import annotations

import logging
from typing import Any

from opnsense_src._fwkit import ensure_fwkit_importable
from opnsense_src.client import OPNsenseClient, OPNsenseError, OPNsenseHost
from opnsense_src.collectors.vpn import collect_vpn
from opnsense_src.routes._domain import dispatch_action, make_writer
from opnsense_src.writers import WireguardPeerInput, WireguardPeerWriter
from opnsense_src.writers.ipsec import IpsecChildInput, IpsecConnectionInput, IpsecWriter
from opnsense_src.writers.openvpn import OpenVpnInstanceInput, OpenVpnWriter

ensure_fwkit_importable()

from ProxmoxVEx.native.fwkit.normalize import (  # noqa: E402
    normalize_ipsec_p1,
    normalize_openvpn,
    normalize_wg_peer,
)
from ProxmoxVEx.native.fwkit.payloads import client_error_envelope, ok  # noqa: E402

log = logging.getLogger(__name__)


def _search(client: OPNsenseClient, path: str) -> list[dict[str, Any]]:
    try:
        out = client.get(path)
    except OPNsenseError as e:
        log.warning("%s failed: %s", path, e)
        return []
    return out.get("rows", []) if isinstance(out, dict) else []


def build_vpn_list_payload(host: OPNsenseHost) -> tuple[int, dict[str, Any]]:
    client = OPNsenseClient(host)
    try:
        snapshot = collect_vpn(client)
        # Match the pfSense `status` block shape: {wireguard:{…,peers}, ipsec:[…], openvpn:[…]}.
        status = {
            "wireguard": {
                "enabled": snapshot["wireguard_enabled"],
                "peers": snapshot["wireguard_peers"],
            },
            "ipsec": snapshot["ipsec_phase1"],
            "openvpn": snapshot["openvpn_sessions"],
        }
        wg_cfg = _search(client, "/api/wireguard/client/searchClient")
        ipsec_conns = _search(client, "/api/ipsec/connections/searchConnection")
        ipsec_children = _search(client, "/api/ipsec/connections/searchChild")
        ovpn = _search(client, "/api/openvpn/instances/search")

        servers, clients = [], []
        for i, r in enumerate(ovpn):
            role = str(r.get("role", "server")).lower()
            (clients if role == "client" else servers).append(normalize_openvpn(r, "opnsense", role, i))

        return ok({
            "status": status,
            "wireguard": [normalize_wg_peer(r, "opnsense", i) for i, r in enumerate(wg_cfg)],
            "ipsec": {
                "phase1": [normalize_ipsec_p1(r, "opnsense", i) for i, r in enumerate(ipsec_conns)],
                "phase2": ipsec_children,
            },
            "openvpn": {"servers": servers, "clients": clients},
        })
    except Exception as e:
        return client_error_envelope(e, log_label="opnsense vpn list")


def _uuid(body: dict[str, Any]) -> str:
    uid = str(body.get("uuid", ""))
    if not uid:
        raise ValueError("uuid is required")
    return uid


def _wg_input(body: dict[str, Any]) -> WireguardPeerInput:
    peer = body.get("peer") or {}
    if not isinstance(peer, dict):
        raise ValueError("peer must be an object")
    allowed = peer.get("allowed_ips") or peer.get("tunneladdress") or ""
    if isinstance(allowed, list):
        allowed = ",".join(str(a) for a in allowed)
    return WireguardPeerInput(
        name=str(peer.get("name", "")),
        pubkey=str(peer.get("public_key") or peer.get("pubkey", "")),
        tunneladdress=str(allowed),
        keepalive=int(peer.get("keepalive", 25) or 25),
        psk=str(peer.get("psk", "")),
        enabled=bool(peer.get("enabled", True)),
    )


def _ipsec_conn_input(body: dict[str, Any]) -> IpsecConnectionInput:
    conn = body.get("connection") or body.get("tunnel") or {}
    if not isinstance(conn, dict):
        raise ValueError("connection must be an object")
    ver = str(conn.get("ike_version", "2")).replace("ikev", "")
    return IpsecConnectionInput(
        remote_addrs=str(conn.get("remote_addrs", "")),
        local_addrs=str(conn.get("local_addrs", "")),
        ike_version=ver or "2",
        auth_method=str(conn.get("auth_method", "psk")),
        proposals=str(conn.get("proposals") or conn.get("proposal") or "aes256-sha256-modp2048"),
        description=str(conn.get("description", "")),
        psk=str(conn.get("psk", "")),
        enabled=bool(conn.get("enabled", True)),
    )


def _ipsec_child_input(body: dict[str, Any]) -> IpsecChildInput:
    child = body.get("child") or {}
    if not isinstance(child, dict):
        raise ValueError("child must be an object")
    return IpsecChildInput(
        connection_uuid=str(child.get("connection_uuid") or child.get("connection") or ""),
        local_net=str(child.get("local_net") or child.get("local_ts") or ""),
        remote_net=str(child.get("remote_net") or child.get("remote_ts") or ""),
        proposals=str(child.get("proposals") or child.get("esp_proposals") or "aes256-sha256-modp2048"),
        mode=str(child.get("mode", "tunnel")),
        description=str(child.get("description", "")),
        enabled=bool(child.get("enabled", True)),
    )


def _ovpn_input(body: dict[str, Any], role: str) -> OpenVpnInstanceInput:
    inst = body.get("instance") or {}
    if not isinstance(inst, dict):
        raise ValueError("instance must be an object")
    return OpenVpnInstanceInput(
        role=role,
        protocol=str(inst.get("protocol", "udp4")),
        port=str(inst.get("port", "1194")),
        device_mode=str(inst.get("device_mode", "tun")),
        local_net=str(inst.get("local_net", "")),
        remote_net=str(inst.get("remote_net", "")),
        cert_ref=str(inst.get("cert_ref", "")),
        remote=str(inst.get("remote", "")),
        description=str(inst.get("description", "")),
        enabled=bool(inst.get("enabled", True)),
    )


def build_vpn_action_payload(
    host: OPNsenseHost,
    plugin_dir: str,
    body: dict[str, Any],
    *,
    peer_host: OPNsenseHost | None = None,
    actor: str = "plugin",
) -> tuple[int, dict[str, Any]]:
    # Lazily construct only the writer the action needs.
    def _wg(b: dict[str, Any], delete: bool):
        writer = make_writer(WireguardPeerWriter, host, peer_host, plugin_dir, actor)
        return writer.delete(_uuid(b)) if delete else writer.create(_wg_input(b))

    def _ipsec_p1(b: dict[str, Any], delete: bool):
        writer = make_writer(IpsecWriter, host, peer_host, plugin_dir, actor)
        if delete:
            return writer.delete_connection(_uuid(b))
        uuid = str(b.get("uuid", ""))
        payload = _ipsec_conn_input(b)
        return writer.update_connection(uuid, payload) if uuid else writer.create_connection(payload)

    def _ipsec_p2(b: dict[str, Any], delete: bool):
        writer = make_writer(IpsecWriter, host, peer_host, plugin_dir, actor)
        return writer.delete_child(_uuid(b)) if delete else writer.create_child(_ipsec_child_input(b))

    def _ovpn(b: dict[str, Any], role: str, delete: bool):
        writer = make_writer(OpenVpnWriter, host, peer_host, plugin_dir, actor)
        if delete:
            return writer.delete(_uuid(b))
        uuid = str(b.get("uuid", ""))
        payload = _ovpn_input(b, role)
        return writer.update(uuid, payload) if uuid else writer.create(payload)

    return dispatch_action(None, body, {
        "wg_set": lambda b: _wg(b, False),
        "wg_delete": lambda b: _wg(b, True),
        "ipsec_p1_set": lambda b: _ipsec_p1(b, False),
        "ipsec_p1_delete": lambda b: _ipsec_p1(b, True),
        "ipsec_p2_set": lambda b: _ipsec_p2(b, False),
        "ipsec_p2_delete": lambda b: _ipsec_p2(b, True),
        "openvpn_server_set": lambda b: _ovpn(b, "server", False),
        "openvpn_server_delete": lambda b: _ovpn(b, "server", True),
        "openvpn_client_set": lambda b: _ovpn(b, "client", False),
        "openvpn_client_delete": lambda b: _ovpn(b, "client", True),
    })
