# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/native/opnsense/opnsense_src/writers/services.py
# Project:     ProxmoxVEx
# Version:     1.2.453
# Build:       2026.09.14
# Description: Service control writer —...
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-14
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Service control writer — `/api/core/service/{start,stop,restart,reload}`
+ `/api/core/service/search` for status. Same audit pattern as the other
writers."""

from __future__ import annotations

import logging
import re
from typing import Any

from opnsense_src.client import OPNsenseClient, OPNsenseError

from .audit import AuditEntry, AuditLog, TimedAction, hash_payload

log = logging.getLogger(__name__)

_SVC_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.:-]{0,63}$")
_ACTIONS = ("start", "stop", "restart", "reload", "reconfigure")


class ServiceWriter:
    BASE = "/api/core/service"

    def __init__(self, client: OPNsenseClient, audit: AuditLog, actor: str = "plugin", host_name: str = "") -> None:
        self.client = client
        self.audit = audit
        self.actor = actor
        self.host_name = host_name or client.host.name

    def search(self) -> list[dict[str, Any]]:
        out = self.client.get(f"{self.BASE}/search")
        return out.get("rows", []) if isinstance(out, dict) else []

    def control(self, service: str, action: str) -> dict[str, Any]:
        """action ∈ start|stop|restart|reconfigure — OPNsense spells it
        `restartService`/`reconfigureService` style endpoints."""
        with TimedAction() as t:
            if action not in _ACTIONS:
                entry = self._record(action or "?", service, "error", t, f"action must be one of {_ACTIONS}")
                return {"ok": False, "detail": entry.detail, "audit": _entry_dict(entry)}
            if not _SVC_RE.match(service):
                entry = self._record(action, service, "error", t, "invalid service name")
                return {"ok": False, "detail": entry.detail, "audit": _entry_dict(entry)}
            try:
                self.client.post(f"{self.BASE}/{action}Service/{service}", {})
            except OPNsenseError as e:
                entry = self._record(action, service, "error", t, str(e))
                return {"ok": False, "detail": str(e), "audit": _entry_dict(entry)}
        entry = self._record(action, service, "ok", t)
        return {"ok": True, "uuid": service, "audit": _entry_dict(entry)}

    def _record(self, action: str, target: str, result: str, timer: TimedAction, detail: str = "") -> AuditEntry:
        entry = AuditEntry.now(
            user=self.actor,
            action=f"service.{action}",
            target=target,
            host=self.host_name,
            result=result,
            duration_ms=timer.elapsed_ms,
            detail=detail,
            payload_sha256=hash_payload({"service": target, "action": action}),
        )
        try:
            self.audit.append(entry)
        except OSError as e:
            log.warning("audit log write failed: %s", e)
        return entry


def _entry_dict(entry: AuditEntry) -> dict[str, Any]:
    from dataclasses import asdict

    return asdict(entry)
