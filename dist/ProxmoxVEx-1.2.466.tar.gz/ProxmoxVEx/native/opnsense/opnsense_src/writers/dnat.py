# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/native/opnsense/opnsense_src/writers/dnat.py
# Project:     ProxmoxVEx
# Version:     1.2.453
# Build:       2026.09.14
# Description: Port-forward / destination NAT CRUD writer...
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-14
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Port-forward / destination NAT CRUD writer (`/api/firewall/d_nat`).

Same lifecycle as NatWriter: addRule/setRule/delRule + apply, audit, HA
sync verify. Covers the `port_forward` kind of the canonical NatRule;
`source_nat` and `one_to_one` remain in their own writers.
"""

from __future__ import annotations

import contextlib
import logging
from dataclasses import dataclass
from typing import Any

from opnsense_src.client import OPNsenseClient, OPNsenseError

from .alias import AliasResult, alias_result_to_dict
from .audit import AuditEntry, AuditLog, TimedAction, hash_payload
from .hasync_writer import HAVerifier, SyncResult

log = logging.getLogger(__name__)


@dataclass(frozen=True)
class DnatInput:
    interface: str
    target: str  # redirect target IP/host
    target_port: str = ""
    source_net: str = "any"
    destination_net: str = "any"
    destination_port: str = ""
    protocol: str = "tcp"
    ipprotocol: str = "inet"
    description: str = ""
    enabled: bool = True

    def to_payload(self) -> dict[str, Any]:
        return {
            "rule": {
                "enabled": "1" if self.enabled else "0",
                "interface": self.interface,
                "ipprotocol": self.ipprotocol,
                "protocol": self.protocol,
                "source_net": self.source_net,
                "destination_net": self.destination_net,
                "destination_port": self.destination_port,
                "target": self.target,
                "local-port": self.target_port,
                "description": self.description,
            }
        }


DnatResult = AliasResult
dnat_result_to_dict = alias_result_to_dict


class DnatWriter:
    BASE = "/api/firewall/d_nat"

    def __init__(
        self,
        client: OPNsenseClient,
        audit: AuditLog,
        ha: HAVerifier | None = None,
        actor: str = "plugin",
        host_name: str = "",
    ) -> None:
        self.client = client
        self.audit = audit
        self.ha = ha
        self.actor = actor
        self.host_name = host_name or client.host.name

    # ----- read --------------------------------------------------------

    def search(self, phrase: str = "") -> list[dict[str, Any]]:
        params = {"searchPhrase": phrase} if phrase else {}
        out = self.client.get(f"{self.BASE}/searchRule", **params)
        return out.get("rows", []) if isinstance(out, dict) else []

    def get(self, uuid: str) -> dict[str, Any]:
        return self.client.get(f"{self.BASE}/getRule/{uuid}")

    # ----- write -------------------------------------------------------

    def create(self, payload: DnatInput) -> DnatResult:
        self._validate(payload)
        with TimedAction() as t:
            try:
                resp = self.client.post(f"{self.BASE}/addRule", payload.to_payload())
            except OPNsenseError as e:
                self._record("dnat.create", payload.interface, "error", t, str(e))
                return DnatResult(ok=False, detail=str(e))
            uuid = str(resp.get("uuid", ""))
            if not uuid:
                self._record("dnat.create", payload.interface, "error", t, "no uuid in response")
                return DnatResult(ok=False, detail="OPNsense did not return uuid")
            try:
                self._apply()
            except OPNsenseError as e:
                with contextlib.suppress(OPNsenseError):
                    self.client.post(f"{self.BASE}/delRule/{uuid}", {})
                self._record("dnat.create", uuid, "error", t, f"apply failed → rolled back: {e}")
                return DnatResult(ok=False, detail=f"apply failed → rolled back: {e}")
        sync = self._maybe_sync()
        entry = self._record(
            "dnat.create", uuid, "ok", t, payload.description, payload_sha256=hash_payload(payload.to_payload())
        )
        return DnatResult(ok=True, uuid=uuid, sync=sync, audit=entry)

    def update(self, uuid: str, payload: DnatInput) -> DnatResult:
        self._validate(payload)
        with TimedAction() as t:
            try:
                self.client.post(f"{self.BASE}/setRule/{uuid}", payload.to_payload())
                self._apply()
            except OPNsenseError as e:
                self._record("dnat.update", uuid, "error", t, str(e))
                return DnatResult(ok=False, uuid=uuid, detail=str(e))
        sync = self._maybe_sync()
        entry = self._record("dnat.update", uuid, "ok", t, payload_sha256=hash_payload(payload.to_payload()))
        return DnatResult(ok=True, uuid=uuid, sync=sync, audit=entry)

    def delete(self, uuid: str) -> DnatResult:
        with TimedAction() as t:
            try:
                self.client.post(f"{self.BASE}/delRule/{uuid}", {})
                self._apply()
            except OPNsenseError as e:
                self._record("dnat.delete", uuid, "error", t, str(e))
                return DnatResult(ok=False, uuid=uuid, detail=str(e))
        sync = self._maybe_sync()
        entry = self._record("dnat.delete", uuid, "ok", t)
        return DnatResult(ok=True, uuid=uuid, sync=sync, audit=entry)

    # ----- internals ---------------------------------------------------

    def _validate(self, payload: DnatInput) -> None:
        if not payload.interface:
            raise ValueError("interface is required")
        if not payload.target:
            raise ValueError("target is required for port-forward rules")

    def _apply(self) -> None:
        self.client.post(f"{self.BASE}/apply", {})

    def _maybe_sync(self) -> SyncResult | None:
        if self.ha is None:
            return None
        return self.ha.verify_robust(f"{self.BASE}/searchRule")

    def _record(
        self,
        action: str,
        target: str,
        result: str,
        timer: TimedAction,
        detail: str = "",
        payload_sha256: str = "",
    ) -> AuditEntry:
        entry = AuditEntry.now(
            user=self.actor,
            action=action,
            target=target,
            host=self.host_name,
            result=result,
            duration_ms=timer.elapsed_ms,
            detail=detail,
            payload_sha256=payload_sha256,
        )
        try:
            self.audit.append(entry)
        except OSError as e:
            log.warning("audit log write failed: %s", e)
        return entry
