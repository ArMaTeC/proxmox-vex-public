# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/native/pfsense/pfsense_src/configmap.py
# Project:     ProxmoxVEx
# Version:     1.2.453
# Build:       2026.09.14
# Description: pfSense config.xml section map + row helpers.
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-14
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""pfSense config.xml section map + row helpers.

pfSense has no per-object REST API — FauxAPI `config_get`/`config_patch`
operate on the whole config tree. Every pfSense writer therefore works the
same way:

1. `read_section(client, entity)` — fetch the row list for an entity.
2. mutate the list in memory (add/replace/remove/reorder).
3. `config_patch({section_path: rows})` — write it back.
4. `apply_for(entity, client)` — run the entity's apply mechanism
   (`send_event`/`function_call`/`config_reload`).
5. On apply failure → `rollback`: write the pre-mutation list back.

Row identity: pfSense rows have no uuid, so synthetic stable ids are
`<entity>-<config index>` (`pf-rule-3`). The `tracker` field is preferred
for filter rules when present (it survives reorders).

See `specs/003-pfsense-opnsense-parity/data-model.md` §config.xml section
map for the canonical mapping this table encodes.
"""

from __future__ import annotations

import logging
from typing import Any

log = logging.getLogger(__name__)


#: entity → (config path, apply mechanism)
#: apply is a tuple: ("event", "<send_event command>") |
#:                   ("function", "<php function>", [args]) |
#:                   ("reload",) → FauxAPI config_reload
SECTIONS: dict[str, dict[str, Any]] = {
    "rules": {
        "path": "filter.rule",
        "apply": ("function", "filter_configure", []),
    },
    "aliases": {
        "path": "aliases.alias",
        # urltables refresh + filter reload so references resolve
        "apply": ("function", "filter_configure", []),
    },
    "nat_forward": {
        "path": "nat.rule",
        "apply": ("function", "filter_configure", []),
    },
    "nat_outbound": {
        "path": "nat.outbound.rule",
        "apply": ("function", "filter_configure", []),
    },
    "nat_one_to_one": {
        "path": "nat.onetoone",
        "apply": ("function", "filter_configure", []),
    },
    "dhcp": {
        # per-interface dict — special-cased by read/write helpers below
        "path": "dhcpd",
        "apply": ("function", "services_dhcpd_configure", []),
    },
    "dns_hosts": {
        "path": "unbound.hosts",
        "apply": ("function", "services_unbound_configure", []),
    },
    "dns_domains": {
        "path": "unbound.domainoverrides",
        "apply": ("function", "services_unbound_configure", []),
    },
    "wireguard": {
        "path": "wireguard",
        "apply": ("function", "wg_apply_list", []),
    },
    "ipsec_p1": {
        "path": "ipsec.phase1",
        "apply": ("function", "ipsec_configure", []),
    },
    "ipsec_p2": {
        "path": "ipsec.phase2",
        "apply": ("function", "ipsec_configure", []),
    },
    "openvpn_server": {
        "path": "openvpn.openvpn-server",
        "apply": ("function", "openvpn_configure", []),
    },
    "openvpn_client": {
        "path": "openvpn.openvpn-client",
        "apply": ("function", "openvpn_configure", []),
    },
    "virtualip": {
        "path": "virtualip.vip",
        "apply": ("function", "interfaces_carp", []),
    },
    "hasync": {
        "path": "hasync",
        "apply": ("function", "filter_configure", []),
    },
}


def listify(node: Any) -> list[dict[str, Any]]:
    """pfSense XML→JSON collapses single-element lists into bare dicts —
    normalize to a list and drop non-dict noise."""
    if node is None:
        return []
    if isinstance(node, list):
        return [r for r in node if isinstance(r, dict)]
    if isinstance(node, dict):
        return [node]
    return []


def read_section(client: Any, entity: str) -> list[dict[str, Any]]:
    """Return the row list for an entity (empty list when absent)."""
    spec = SECTIONS[entity]
    node = client.config_section(spec["path"])
    return listify(node)


def read_dhcp_interfaces(client: Any) -> dict[str, dict[str, Any]]:
    """`dhcpd` is a per-interface map (`dhcpd.lan`, `dhcpd.opt1`, …), not a
    row list — return the dict as-is."""
    node = client.config_section("dhcpd")
    return node if isinstance(node, dict) else {}


def write_section(client: Any, entity: str, rows: list[dict[str, Any]]) -> None:
    """Persist a mutated row list via config_patch."""
    spec = SECTIONS[entity]
    # config_patch takes a nested dict; rebuild the path e.g.
    # "nat.outbound.rule" → {"nat": {"outbound": {"rule": rows}}}
    patch: dict[str, Any] = {}
    node = patch
    parts = spec["path"].split(".")
    for part in parts[:-1]:
        node[part] = {}
        node = node[part]
    node[parts[-1]] = rows
    client.config_patch(patch)


def write_dhcp_interfaces(client: Any, dhcpd: dict[str, Any]) -> None:
    client.config_patch({"dhcpd": dhcpd})


def apply_for(client: Any, entity: str) -> None:
    """Run the entity's apply mechanism so the change takes effect."""
    spec = SECTIONS[entity]
    mech = spec["apply"]
    kind = mech[0]
    if kind == "event":
        client.send_event(mech[1])
    elif kind == "function":
        client.function_call({"function": mech[1], "args": mech[2]})
    else:  # reload
        client.config_reload()


def synthetic_id(entity: str, index: int, row: dict[str, Any] | None = None) -> str:
    """Stable row id — prefer pfSense's own `tracker`/`if` fields when the
    row carries one, else the config index."""
    if row:
        tracker = row.get("tracker") or row.get("if") or row.get("name")
        if tracker not in (None, ""):
            return str(tracker)
    return f"pf-{entity}-{index}"
