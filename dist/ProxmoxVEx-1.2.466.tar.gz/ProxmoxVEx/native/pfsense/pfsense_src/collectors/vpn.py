# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/native/pfsense/pfsense_src/collectors/vpn.py
# Project:     ProxmoxVEx
# Version:     1.2.453
# Build:       2026.09.14
# Description: VPN collector for pfSense — enumerates WireGuard peers,...
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-14
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""VPN collector for pfSense — enumerates WireGuard peers, IPsec phase-1/2
tunnels and OpenVPN server/client instances from config.xml sections, then
normalizes each into the shared VpnPeer-ish row the UI renders."""

from __future__ import annotations

import logging
from typing import Any, TypedDict

from pfsense_src.client import PFsenseClient
from pfsense_src.configmap import listify

log = logging.getLogger(__name__)


class VPNPeer(TypedDict, total=False):
    kind: str
    name: str
    remote: str
    status: str
    enabled: bool


def _enabled(row: dict[str, Any]) -> bool:
    # pfSense marks a row disabled by the *presence* of <disabled/> (empty
    # string after XML→JSON); writers toggle by adding/removing the key.
    if "disabled" not in row:
        return True
    return str(row.get("disabled", "")).strip().lower() in ("0", "false", "no")


def collect_wireguard(client: PFsenseClient) -> tuple[bool, list[VPNPeer]]:
    """(package_present, peers). pfSense WireGuard lives in the `wireguard`
    package config section; absent package → (False, [])."""
    try:
        wg = client.config_section("wireguard")
    except Exception as e:
        log.debug("wireguard config read failed: %s", e)
        return False, []
    if not isinstance(wg, dict):
        return False, []
    peers = listify(wg.get("peers") or wg.get("peer"))
    out = [
        VPNPeer(
            kind="wireguard",
            name=str(p.get("descr") or p.get("name") or ""),
            remote=str(p.get("endpoint") or ""),
            status="unknown",
            enabled=_enabled(p),
        )
        for p in peers
    ]
    return True, out


def collect_ipsec(client: PFsenseClient) -> list[VPNPeer]:
    try:
        rows = listify(client.config_section("ipsec.phase1"))
    except Exception as e:
        log.debug("ipsec phase1 read failed: %s", e)
        return []
    return [
        VPNPeer(
            kind="ipsec",
            name=str(r.get("descr") or f"phase1-{i}"),
            remote=str(r.get("remote-gateway") or r.get("remote_gateway") or ""),
            status="unknown",
            enabled=_enabled(r),
        )
        for i, r in enumerate(rows)
    ]


def collect_openvpn(client: PFsenseClient) -> list[VPNPeer]:
    out: list[VPNPeer] = []
    for section, role in (("openvpn.openvpn-server", "server"), ("openvpn.openvpn-client", "client")):
        try:
            rows = listify(client.config_section(section))
        except Exception as e:
            log.debug("%s read failed: %s", section, e)
            continue
        for i, r in enumerate(rows):
            out.append(VPNPeer(
                kind="openvpn",
                name=str(r.get("description") or r.get("descr") or f"ovpn-{role}-{i}"),
                remote=str(r.get("server_addr") or r.get("local_port") or ""),
                status="unknown",
                enabled=_enabled(r),
            ))
    return out


def collect_vpn(client: PFsenseClient) -> dict[str, Any]:
    wg_present, wg_peers = collect_wireguard(client)
    return {
        "wireguard": {"installed": wg_present, "peers": wg_peers},
        "ipsec": collect_ipsec(client),
        "openvpn": collect_openvpn(client),
    }
