# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/native/pfsense/pfsense_src/collectors/system.py
# Project:     ProxmoxVEx
# Version:     1.2.453
# Build:       2026.09.14
# Description: System-level collector for pfSense.
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-14
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""System-level collector for pfSense.

Normalizes `system_info` + `system_stats` into the same snapshot shape the
OPNsense `collect_system` emits so the shared overview UI renders both.
"""

from __future__ import annotations

from typing import Any, TypedDict

from pfsense_src.client import PFsenseClient


class SystemSnapshot(TypedDict, total=False):
    hostname: str
    version: str
    product_id: str
    uptime_s: int
    cpu_pct: float
    mem_pct: float
    states_used: int
    states_max: int
    config_revision: str
    firmware: dict


def _unwrap(resp: Any) -> Any:
    """Return the FauxAPI ``data`` payload, or the raw response."""
    if isinstance(resp, dict):
        return resp.get("data", resp)
    return resp


def _to_int(v: Any) -> int:
    try:
        return int(float(v))
    except (TypeError, ValueError):
        return 0


def _to_float(v: Any) -> float:
    try:
        return float(v)
    except (TypeError, ValueError):
        return 0.0


def _flatten_system_info(data: Any) -> dict[str, Any]:
    """FauxAPI system_info returns a list of section dicts — flatten them."""
    if isinstance(data, dict):
        return data
    out: dict[str, Any] = {}
    for part in data or []:
        if isinstance(part, dict):
            out.update(part)
    return out


def collect_system(client: PFsenseClient) -> dict[str, Any]:
    """Normalized system snapshot (matches the OPNsense collector shape)."""
    info = _flatten_system_info(_unwrap(client.system_info()))
    try:
        stats = _unwrap(client.system_stats())
    except Exception as e:  # stats are best-effort — never fail the snapshot
        import logging

        logging.getLogger(__name__).debug("system_stats failed: %s", e)
        stats = {}
    if not isinstance(stats, dict):
        stats = {}

    config_rev = ""
    try:
        cfg = _unwrap(client.config_get()) or {}
        cfg = cfg.get("config", cfg) if isinstance(cfg, dict) else {}
        rev = cfg.get("revision") or {}
        if isinstance(rev, dict):
            config_rev = str(rev.get("time") or rev.get("description") or "")
    except Exception as e:
        import logging

        logging.getLogger(__name__).debug("config revision read failed: %s", e)

    return {
        "hostname": str(info.get("hostname") or info.get("name") or client.host.name),
        "version": str(info.get("version") or info.get("pfsense_version") or ""),
        "product_id": str(info.get("product") or "pfSense"),
        "uptime_s": _to_int(stats.get("uptime") or info.get("uptime")),
        "cpu_pct": _to_float(stats.get("cpu") or stats.get("cpu_usage")),
        "mem_pct": _to_float(stats.get("mem_usage_pct") or stats.get("memory_usage")),
        "states_used": _to_int(stats.get("states") or stats.get("pfstates")),
        "states_max": _to_int(stats.get("states_max")),
        "config_revision": config_rev,
        "firmware": {
            "current_version": str(info.get("version") or ""),
            "updates_available": [],
            "last_check": "",
        },
        "raw": info,
    }
