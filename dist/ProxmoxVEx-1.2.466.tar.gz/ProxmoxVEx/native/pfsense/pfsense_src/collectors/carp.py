# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/native/pfsense/pfsense_src/collectors/carp.py
# Project:     ProxmoxVEx
# Version:     1.2.453
# Build:       2026.09.14
# Description: CARP status collector for pfSense.
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-14
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""CARP status collector for pfSense.

No dedicated FauxAPI action exists, so the role is probed two ways:

1. `function_call` → `get_carp_status` (enabled flag) and per-VIP
   `get_carp_interface_status` / `get_single_carp_interface_status` rows,
   when the FauxAPI build permits function calls.
2. Fallback: read `virtualip.vip` from `config_get` — presence of CARP VIPs
   tells us HA is configured even when runtime probes fail (role then
   reports "unknown" rather than guessing).
"""

from __future__ import annotations

import logging
from typing import Any, Literal, TypedDict

from pfsense_src.client import PFsenseClient
from pfsense_src.configmap import listify

log = logging.getLogger(__name__)

CarpRole = Literal["master", "backup", "disabled", "unknown"]


class CarpVhid(TypedDict, total=False):
    vhid: str
    interface: str
    role: str
    advskew: Any


class CarpStatus(TypedDict):
    enabled: bool
    role: CarpRole
    maintenance_mode: bool
    demotion: int
    vhids: list[CarpVhid]


def _fn(client: PFsenseClient, name: str, *args: Any) -> Any:
    """function_call wrapper — returns the unwrapped data or None on failure."""
    try:
        out = client.function_call({"function": name, "args": list(args)})
    except Exception as e:
        log.debug("function_call %s failed: %s", name, e)
        return None
    if isinstance(out, dict):
        return out.get("data", out.get("return", out))
    return out


def _classify(vhids: list[CarpVhid], enabled: bool) -> CarpRole:
    if not enabled:
        return "disabled"
    roles = {str(v.get("role", "")).lower() for v in vhids}
    if "master" in roles and "backup" not in roles:
        return "master"
    if "backup" in roles and "master" not in roles:
        return "backup"
    if "master" in roles:
        # mixed master+backup across VIDs — treat as master (any master VIP
        # means this node is actively serving CARP addresses)
        return "master"
    return "unknown"


def collect_carp_status(client: PFsenseClient) -> CarpStatus:
    enabled_raw = _fn(client, "get_carp_status")
    enabled = bool(enabled_raw) if enabled_raw is not None else False

    vhids: list[CarpVhid] = []
    raw_vips = _fn(client, "get_carp_interface_status")
    if isinstance(raw_vips, list):
        for row in raw_vips:
            if isinstance(row, dict):
                vhids.append(CarpVhid(
                    vhid=str(row.get("vhid", "")),
                    interface=str(row.get("interface") or row.get("if") or ""),
                    role=str(row.get("status") or row.get("role") or "").lower(),
                    advskew=row.get("advskew"),
                ))
    elif isinstance(raw_vips, str) and raw_vips.strip():
        # single-status string form: "MASTER" / "BACKUP" / "DISABLED"
        vhids.append(CarpVhid(vhid="", interface="", role=raw_vips.strip().lower()))

    if not vhids:
        # Config fallback: CARP VIPs present → HA configured, role unknown.
        try:
            vips = listify(client.config_section("virtualip.vip"))
            vhids = [
                CarpVhid(
                    vhid=str(v.get("vhid", "")),
                    interface=str(v.get("interface", "")),
                    role="unknown",
                    advskew=v.get("advskew"),
                )
                for v in vips
                if str(v.get("mode", "")).lower() == "carp"
            ]
            if vhids:
                enabled = True
        except Exception as e:
            log.debug("virtualip read failed: %s", e)

    # Maintenance mode on pfSense is the "Persistent CARP Maintenance Mode"
    # flag in virtualip settings.
    maint = False
    try:
        vip_cfg = client.config_section("virtualip")
        if isinstance(vip_cfg, dict):
            maint = str(vip_cfg.get("carp_maintenancemode", "")).strip() not in ("", "0", "false")
    except Exception as e:
        log.debug("virtualip config read failed: %s", e)

    return CarpStatus(
        enabled=enabled,
        role=_classify(vhids, enabled),
        maintenance_mode=maint,
        demotion=0,
        vhids=vhids,
    )
