# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/native/pfsense/pfsense_src/collectors/routes.py
# Project:     ProxmoxVEx
# Version:     1.2.453
# Build:       2026.09.14
# Description: Static routes from config (`staticroutes.route`);...
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-14
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Static routes from config (`staticroutes.route`); neighbor tables via
`function_call` → system routing helpers when available."""

from __future__ import annotations

import logging
from typing import Any, TypedDict

from pfsense_src.client import PFsenseClient
from pfsense_src.configmap import listify

log = logging.getLogger(__name__)


class Route(TypedDict, total=False):
    destination: str
    gateway: str
    interface: str
    descr: str
    disabled: bool


def collect_routes(client: PFsenseClient) -> list[Route]:
    try:
        rows = listify(client.config_section("staticroutes.route"))
    except Exception as e:
        log.warning("staticroutes read failed: %s", e)
        return []
    return [
        Route(
            destination=str(r.get("network", "")),
            gateway=str(r.get("gateway", "")),
            interface=str(r.get("interface", "")),
            descr=str(r.get("descr") or r.get("description") or ""),
            # <disabled/> parses to "" — presence disables the route (same
            # semantics as the writers' toggle, which sets disabled="")
            disabled="disabled" in r and str(r.get("disabled", "")).strip().lower() not in ("0", "false", "no"),
        )
        for r in rows
    ]


def collect_neighbors(client: PFsenseClient) -> list[dict[str, Any]]:
    """ARP/NDP via function_call — best-effort, empty on older FauxAPI."""
    out: list[dict[str, Any]] = []
    try:
        resp = client.function_call({"function": "pfSense_get_arp_table", "args": []})
        data = resp.get("data", resp.get("return", resp)) if isinstance(resp, dict) else resp
        if isinstance(data, list):
            for r in data:
                if isinstance(r, dict):
                    out.append({
                        "ip": str(r.get("ip", "")),
                        "mac": str(r.get("mac", "")),
                        "interface": str(r.get("interface", "")),
                        "expires": r.get("expires"),
                    })
    except Exception as e:
        log.debug("arp table probe failed: %s", e)
    return out
