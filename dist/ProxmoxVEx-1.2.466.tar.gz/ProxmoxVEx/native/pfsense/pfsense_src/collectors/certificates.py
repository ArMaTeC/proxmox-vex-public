# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/native/pfsense/pfsense_src/collectors/certificates.py
# Project:     ProxmoxVEx
# Version:     1.2.453
# Build:       2026.09.14
# Description: Certificate collector for pfSense — reads `cert`/`ca`...
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-14
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Certificate collector for pfSense — reads `cert`/`ca` config sections and
extracts validity windows from the base64 X.509 payloads when the
`cryptography` package is available (guarded; expiry fields degrade to
empty rather than failing the overview)."""

from __future__ import annotations

import base64
import logging
from datetime import datetime, timezone
from typing import Any, TypedDict

from pfsense_src.client import PFsenseClient
from pfsense_src.configmap import listify

log = logging.getLogger(__name__)

try:  # pragma: no cover - optional dependency
    from cryptography import x509
    from cryptography.hazmat.backends import default_backend
except ImportError:  # pragma: no cover
    x509 = None  # type: ignore[assignment]
    default_backend = None  # type: ignore[assignment]


class CertSummary(TypedDict, total=False):
    refid: str
    descr: str
    type: str
    cn: str
    issuer: str
    valid_from: str
    valid_to: str
    days_to_expiry: int
    fingerprint: str


def _decode_cert(b64: str) -> Any:
    if x509 is None:
        return None
    try:
        pem = base64.b64decode(b64)
        return x509.load_pem_x509_certificate(pem, default_backend())
    except Exception:
        try:
            return x509.load_der_x509_certificate(base64.b64decode(b64), default_backend())
        except Exception as e:
            log.debug("cert decode failed: %s", e)
            return None


def _days_to(valid_to: str) -> int:
    if not valid_to:
        return 9999
    try:
        dt = datetime.fromisoformat(valid_to.replace("Z", "+00:00"))
        return (dt - datetime.now(timezone.utc)).days
    except ValueError:
        return 9999


def _row(raw: dict[str, Any], kind: str) -> CertSummary:
    out: CertSummary = {
        "refid": str(raw.get("refid", "")),
        "descr": str(raw.get("descr") or raw.get("name") or ""),
        "type": kind,
    }
    cert = _decode_cert(str(raw.get("crt", "")))
    if cert is not None:
        try:
            out["cn"] = cert.subject.rfc4514_string()
            out["issuer"] = cert.issuer.rfc4514_string()
            out["valid_from"] = cert.not_valid_before_utc.isoformat()
            out["valid_to"] = cert.not_valid_after_utc.isoformat()
            out["days_to_expiry"] = _days_to(out["valid_to"])
            out["fingerprint"] = cert.fingerprint(cert.signature_hash_algorithm).hex() if cert.signature_hash_algorithm else ""
        except Exception as e:
            log.debug("cert field extract failed: %s", e)
    return out


def collect_certificates(client: PFsenseClient) -> list[CertSummary]:
    out: list[CertSummary] = []
    try:
        for raw in listify(client.config_section("cert")):
            out.append(_row(raw, "cert"))
        for raw in listify(client.config_section("ca")):
            out.append(_row(raw, "ca"))
    except Exception as e:
        log.warning("certificate collect failed: %s", e)
    return out
