# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/native/pfsense/pfsense_src/writers/vpn.py
# Project:     ProxmoxVEx
# Version:     1.2.453
# Build:       2026.09.14
# Description: VPN writer for pfSense — full tunnel provisioning (spec...
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-14
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""VPN writer for pfSense — full tunnel provisioning (spec 003 US5):

- WireGuard peers   → `wireguard` package section
- IPsec phase1/2    → `ipsec.phase1`/`ipsec.phase2`
- OpenVPN server/client → `openvpn.openvpn-server`/`-client`

Secret material (PSKs, private keys) is write-only: accepted in inputs,
stored to config, never returned by read paths.
"""

from __future__ import annotations

import re
from typing import Any

from .base import SectionWriter, make_section_mutator

_WG_KEY_RE = re.compile(r"^[A-Za-z0-9+/]{43}=$")
_IFACE_RE = re.compile(r"^[a-z0-9_.:-]{1,32}$", re.I)


def _wg_to_row(peer: dict[str, Any]) -> dict[str, Any]:
    pubkey = str(peer.get("public_key") or peer.get("publickey") or "")
    if pubkey and not _WG_KEY_RE.match(pubkey):
        raise ValueError("public_key must be a base64 WireGuard key")
    allowed = peer.get("allowed_ips") or peer.get("allowedips") or []
    if isinstance(allowed, str):
        allowed = [a.strip() for a in allowed.split(",") if a.strip()]
    row = {
        "descr": str(peer.get("name") or peer.get("descr") or ""),
        "publickey": pubkey,
        "allowedips": ",".join(str(a) for a in allowed),
        "endpoint": str(peer.get("endpoint_host") or peer.get("endpoint") or ""),
        "port": str(peer.get("endpoint_port") or peer.get("port") or ""),
        "persistentkeepalive": str(peer.get("keepalive") or ""),
    }
    if not peer.get("enabled", True):
        row["disabled"] = ""
    return row


def _ipsec_p1_to_row(t: dict[str, Any]) -> dict[str, Any]:
    remote = str(t.get("remote_addrs") or t.get("remote_gateway") or "")
    if not remote:
        raise ValueError("remote_addrs (remote gateway) is required")
    row = {
        "iketype": str(t.get("ike_version") or "ikev2"),
        "remote-gateway": remote,
        "authentication_method": str(t.get("auth_method") or "pre_shared_key"),
        "descr": str(t.get("description") or t.get("descr") or ""),
        "interface": str(t.get("interface") or "wan"),
    }
    # PSK is write-only — stored but never echoed back by collectors.
    if t.get("psk"):
        row["pre-shared-key"] = str(t["psk"])
    if not t.get("enabled", True):
        row["disabled"] = ""
    return row


def _ipsec_p2_to_row(t: dict[str, Any]) -> dict[str, Any]:
    if not t.get("parent_uuid") and not t.get("ikeid"):
        raise ValueError("parent_uuid (phase-1 ikeid) is required")
    row = {
        "ikeid": str(t.get("parent_uuid") or t.get("ikeid") or ""),
        "mode": str(t.get("mode") or "tunnel"),
        "localid": {"type": "network", "address": str(t.get("local_net") or "")},
        "remoteid": {"type": "network", "address": str(t.get("remote_net") or "")},
        "protocol": str(t.get("proto") or "esp"),
        "descr": str(t.get("description") or t.get("descr") or ""),
    }
    if not t.get("enabled", True):
        row["disabled"] = ""
    return row


def _ovpn_to_row(inst: dict[str, Any]) -> dict[str, Any]:
    proto = str(inst.get("protocol") or "udp").lower()
    if proto not in ("udp", "tcp", "udp4", "udp6", "tcp4", "tcp6"):
        raise ValueError("protocol must be udp/tcp")
    row = {
        "protocol": proto.upper(),
        "dev_mode": str(inst.get("device_mode") or "tun"),
        "local_port": str(inst.get("port") or ""),
        "description": str(inst.get("description") or inst.get("descr") or ""),
        "tunnel_network": str(inst.get("local_net") or ""),
        "remote_network": str(inst.get("remote_net") or ""),
    }
    if inst.get("cert_ref"):
        row["certref"] = str(inst["cert_ref"])
    if inst.get("tls_auth"):
        row["tls"] = str(inst["tls_auth"])  # write-only secret material
    if not inst.get("enabled", True):
        row["disabled"] = ""
    return row


class _WgPeerWriter(SectionWriter):
    entity = "wireguard"
    uuid_field = "publickey"

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)
        self._mutate = make_section_mutator(self.entity, self.uuid_field, _wg_to_row)

    def mutate(self, rows, action, payload):
        return self._mutate(rows, action, payload)


class _IpsecP1Writer(SectionWriter):
    entity = "ipsec_p1"
    uuid_field = "ikeid"

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)
        self._mutate = make_section_mutator(self.entity, self.uuid_field, _ipsec_p1_to_row)

    def mutate(self, rows, action, payload):
        return self._mutate(rows, action, payload)


class _IpsecP2Writer(SectionWriter):
    entity = "ipsec_p2"
    uuid_field = "uniqid"

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)
        self._mutate = make_section_mutator(self.entity, self.uuid_field, _ipsec_p2_to_row)

    def mutate(self, rows, action, payload):
        return self._mutate(rows, action, payload)


class _OpenVpnWriter(SectionWriter):
    uuid_field = "vpnid"

    def __init__(self, *args: Any, role: str = "server", **kwargs: Any) -> None:
        self.role = role
        self.entity = "openvpn_server" if role == "server" else "openvpn_client"
        super().__init__(*args, **kwargs)
        self._mutate = make_section_mutator(self.entity, self.uuid_field, _ovpn_to_row)

    def mutate(self, rows, action, payload):
        return self._mutate(rows, action, payload)


class VpnWriter:
    """Facade over the per-technology writers."""

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        self.wg = _WgPeerWriter(*args, **kwargs)
        self.ipsec_p1 = _IpsecP1Writer(*args, **kwargs)
        self.ipsec_p2 = _IpsecP2Writer(*args, **kwargs)
        self.ovpn_server = _OpenVpnWriter(*args, role="server", **kwargs)
        self.ovpn_client = _OpenVpnWriter(*args, role="client", **kwargs)
