# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/native/pfsense/pfsense_src/writers/rule.py
# Project:     ProxmoxVEx
# Version:     1.2.453
# Build:       2026.09.14
# Description: Firewall rule writer — CRUD + toggle + reorder on...
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-14
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Firewall rule writer — CRUD + toggle + reorder on `filter.rule`."""

from __future__ import annotations

from typing import Any

from pfsense_src._fwkit import ensure_fwkit_importable

from .base import SectionWriter, make_section_mutator

ensure_fwkit_importable()

from ProxmoxVEx.native.fwkit.normalize import denormalize_rule  # noqa: E402

_ACTIONS = ("pass", "block", "reject")
_PROTOCOLS = ("any", "tcp", "udp", "tcp/udp", "icmp")


def _validate(rule: dict[str, Any]) -> None:
    if rule.get("action") not in _ACTIONS:
        raise ValueError(f"action must be one of {_ACTIONS}")
    if not rule.get("interface"):
        raise ValueError("interface is required")
    proto = str(rule.get("protocol") or "any")
    if proto not in _PROTOCOLS:
        raise ValueError(f"protocol must be one of {_PROTOCOLS}")


def _to_row(rule: dict[str, Any]) -> dict[str, Any]:
    _validate(rule)
    return denormalize_rule(rule, "pfsense")


class RuleWriter(SectionWriter):
    """CRUD/toggle/reorder for pfSense filter rules."""

    entity = "rules"
    uuid_field = "tracker"

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)
        self._mutate = make_section_mutator(self.entity, self.uuid_field, _to_row)

    def mutate(self, rows, action, payload):  # noqa: D102
        return self._mutate(rows, action, payload)

    def toggle(self, uuid: str):
        return self.run("toggle", {"uuid": uuid})

    def reorder(self, order: list[str]):
        return self.run("reorder", {"order": order})

    def move(self, uuid: str, before: str = ""):
        return self.run("move", {"uuid": uuid, "before": before})
