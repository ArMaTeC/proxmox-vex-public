# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/native/pfsense/pfsense_src/metrics/exporter.py
# Project:     ProxmoxVEx
# Version:     1.2.453
# Build:       2026.09.14
# Description: Prometheus text exposition for the pfSense plugin.
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-14
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Prometheus text exposition for the pfSense plugin.

Mirrors the OPNsense exporter — same metric inventory under the `pfsense_`
prefix, tiny custom serializer so we don't pull `prometheus_client` into
the host runtime.
"""

from __future__ import annotations

from typing import Any, Iterable

from pfsense_src.client import PFsenseClient
from pfsense_src.collectors import (
    collect_certificates,
    collect_gateways,
    collect_hasync,
    collect_interfaces,
    collect_services,
    collect_system,
    collect_vpn,
)


def _escape(label: str) -> str:
    return str(label).replace("\\", "\\\\").replace("\n", "\\n").replace('"', '\\"')


def _line(name: str, value: float, labels: dict[str, Any] | None = None) -> str:
    if labels:
        rendered = ",".join(f'{k}="{_escape(v)}"' for k, v in labels.items() if v is not None)
        return f"{name}{{{rendered}}} {value}"
    return f"{name} {value}"


def _section(name: str, kind: str, help_text: str) -> Iterable[str]:
    yield f"# HELP {name} {help_text}"
    yield f"# TYPE {name} {kind}"


def render_metrics(client: PFsenseClient, host_label: str | None = None) -> str:
    host = host_label or client.host.name
    common = {"host": host}
    out: list[str] = []

    # ---- system ----
    try:
        sys = collect_system(client)
        up = 1
    except Exception:
        out.extend(_section("pfsense_up", "gauge", "1 if the pfSense API responded successfully"))
        out.append(_line("pfsense_up", 0, common))
        return "\n".join(out) + "\n"

    out.extend(_section("pfsense_up", "gauge", "1 if the pfSense API responded successfully"))
    out.append(_line("pfsense_up", up, common))

    out.extend(_section("pfsense_pf_states_current", "gauge", "Current pf state count"))
    out.append(_line("pfsense_pf_states_current", sys.get("states_used", 0), common))
    out.extend(_section("pfsense_pf_states_limit", "gauge", "pf state table size limit"))
    out.append(_line("pfsense_pf_states_limit", sys.get("states_max", 0), common))
    out.extend(_section("pfsense_cpu_usage_ratio", "gauge", "CPU usage (0..1)"))
    out.append(_line("pfsense_cpu_usage_ratio", (sys.get("cpu_pct", 0) or 0) / 100.0, common))

    # ---- interfaces ----
    try:
        ifaces = collect_interfaces(client)
    except Exception:
        ifaces = []
    out.extend(_section("pfsense_iface_up", "gauge", "1 if the interface is up"))
    for i in ifaces:
        out.append(_line("pfsense_iface_up", 1 if i.get("link") == "up" else 0, {**common, "iface": i.get("name", "")}))
    out.extend(_section("pfsense_iface_rx_bytes_total", "counter", "Total bytes received per interface"))
    for i in ifaces:
        out.append(_line("pfsense_iface_rx_bytes_total", i.get("in_kbps", 0) or 0, {**common, "iface": i.get("name", "")}))
    out.extend(_section("pfsense_iface_tx_bytes_total", "counter", "Total bytes sent per interface"))
    for i in ifaces:
        out.append(_line("pfsense_iface_tx_bytes_total", i.get("out_kbps", 0) or 0, {**common, "iface": i.get("name", "")}))

    # ---- gateways ----
    try:
        gws = collect_gateways(client)
    except Exception:
        gws = []
    out.extend(_section("pfsense_gateway_rtt_seconds", "gauge", "Gateway monitor round-trip time in seconds"))
    for g in gws:
        out.append(_line("pfsense_gateway_rtt_seconds", (g.get("rtt_ms", 0) or 0) / 1000.0, {**common, "gw": g.get("name", "")}))
    out.extend(_section("pfsense_gateway_loss_ratio", "gauge", "Gateway monitor loss ratio (0..1)"))
    for g in gws:
        out.append(_line("pfsense_gateway_loss_ratio", (g.get("loss_pct", 0) or 0) / 100.0, {**common, "gw": g.get("name", "")}))
    out.extend(_section("pfsense_gateway_up", "gauge", "1 if the gateway monitor reports online"))
    for g in gws:
        out.append(_line("pfsense_gateway_up", 1 if g.get("status") in ("online", "up") else 0, {**common, "gw": g.get("name", "")}))

    # ---- services ----
    try:
        svc = collect_services(client)
    except Exception:
        svc = {"items": []}
    out.extend(_section("pfsense_service_running", "gauge", "1 if the service is running"))
    for s in svc.get("items", []):
        running = s.get("running")
        if running is None:
            continue  # unknown state — don't emit a misleading 0
        out.append(_line("pfsense_service_running", 1 if running else 0, {**common, "service": s.get("name", "")}))

    # ---- certs ----
    try:
        certs = collect_certificates(client)
    except Exception:
        certs = []
    out.extend(_section("pfsense_cert_expiry_seconds", "gauge", "Seconds until the certificate expires"))
    for c in certs:
        days = c.get("days_to_expiry")
        if days is None or days > 9000:
            continue
        out.append(_line("pfsense_cert_expiry_seconds", days * 86400, {**common, "cert": c.get("descr") or c.get("refid", "")}))

    # ---- VPN aggregates ----
    try:
        vpn = collect_vpn(client)
    except Exception:
        vpn = {"wireguard": {"peers": []}, "ipsec": [], "openvpn": []}
    out.extend(_section("pfsense_vpn_peers_total", "gauge", "Number of VPN peers/tunnels per engine"))
    out.append(_line("pfsense_vpn_peers_total", len(vpn.get("wireguard", {}).get("peers", [])), {**common, "type": "wireguard"}))
    out.append(_line("pfsense_vpn_peers_total", len(vpn.get("ipsec", [])), {**common, "type": "ipsec"}))
    out.append(_line("pfsense_vpn_peers_total", len(vpn.get("openvpn", [])), {**common, "type": "openvpn"}))

    # ---- HA ----
    try:
        ha = collect_hasync(client)
    except Exception:
        ha = {"enabled": False}
    out.extend(_section("pfsense_ha_enabled", "gauge", "1 if config sync (XMLRPC/pfSync) is configured"))
    out.append(_line("pfsense_ha_enabled", 1 if ha.get("enabled") else 0, common))

    return "\n".join(out) + "\n"
