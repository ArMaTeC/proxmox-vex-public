# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/native/pfsense/pfsense_src/routes/_domain.py
# Project:     ProxmoxVEx
# Version:     1.2.453
# Build:       2026.09.14
# Description: Shared action-dispatch helper — every write route does...
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-14
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Shared action-dispatch helper — every write route does the same dance:
read_only check → dispatch the action verb on the writer → map client
errors to the standard envelope → serialize the WriteResult."""

from __future__ import annotations

import logging
from typing import Any, Callable

from pfsense_src._fwkit import ensure_fwkit_importable
from pfsense_src.client import PFsenseClient, PFsenseHost

ensure_fwkit_importable()

from ProxmoxVEx.native.fwkit.audit import AuditLog  # noqa: E402
from ProxmoxVEx.native.fwkit.payloads import (  # noqa: E402
    audit_log_path,
    client_error_envelope,
    err,
)

log = logging.getLogger(__name__)


def make_writer(
    factory: Callable[..., Any],
    host: PFsenseHost,
    peer_host: PFsenseHost | None,
    plugin_dir: str,
    actor: str,
    **kwargs: Any,
) -> Any:
    """Construct a writer with the standard audit + HA peer wiring."""
    peer = PFsenseClient(peer_host) if peer_host is not None else None
    audit = AuditLog(audit_log_path(plugin_dir))
    return factory(PFsenseClient(host), audit, actor=actor, peer=peer, **kwargs)


def dispatch_action(
    writer: Any,
    body: dict[str, Any],
    actions: dict[str, Callable[..., Any]],
) -> tuple[int, dict[str, Any]]:
    """Run `actions[body["action"]]`; the callable takes the body (or the
    extracted object) and returns a WriteResult or (status, payload)."""
    action = str(body.get("action", "")).lower()
    fn = actions.get(action)
    if fn is None:
        return err("bad_request", f"action must be one of {sorted(actions)}")
    try:
        result = fn(body)
    except ValueError as e:
        return err("validation", str(e))
    except Exception as e:
        return client_error_envelope(e, log_label=f"pfsense {action}")
    if isinstance(result, tuple):
        return result
    if hasattr(result, "to_dict"):
        d = result.to_dict()
        if not result.ok:
            return 502, {"ok": False, "error": "upstream", "detail": result.detail or "write failed", "data": d}
        return 200, {"ok": True, "data": d}
    return 200, {"ok": True, "data": result}
