# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/native/pfsense/pfsense_src/routes/rules.py
# Project:     ProxmoxVEx
# Version:     1.2.453
# Build:       2026.09.14
# Description: Firewall rules route payloads for pfSense.
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-14
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Firewall rules route payloads for pfSense."""

from __future__ import annotations

import logging
from typing import Any

from pfsense_src._fwkit import ensure_fwkit_importable
from pfsense_src.client import PFsenseClient, PFsenseHost
from pfsense_src.collectors import collect_rules
from pfsense_src.routes._domain import dispatch_action, make_writer
from pfsense_src.writers import RuleWriter

ensure_fwkit_importable()

from ProxmoxVEx.native.fwkit.payloads import (  # noqa: E402
    client_error_envelope,
    ok,
)

log = logging.getLogger(__name__)


def build_rules_list_payload(host: PFsenseHost) -> tuple[int, dict[str, Any]]:
    client = PFsenseClient(host)
    try:
        rows = collect_rules(client)
        return ok({"rules": rows, "total": len(rows)})
    except Exception as e:
        return client_error_envelope(e, log_label="pfsense rules list")


def build_rules_action_payload(
    host: PFsenseHost,
    plugin_dir: str,
    body: dict[str, Any],
    *,
    peer_host: PFsenseHost | None = None,
    actor: str = "plugin",
) -> tuple[int, dict[str, Any]]:
    writer = make_writer(RuleWriter, host, peer_host, plugin_dir, actor)

    def _create(b: dict[str, Any]):
        rule = b.get("rule") or {}
        if not isinstance(rule, dict):
            raise ValueError("rule must be an object")
        return writer.create(rule)

    def _update(b: dict[str, Any]):
        rule = b.get("rule") or {}
        uuid = str(b.get("uuid") or rule.get("uuid") or "")
        if not uuid:
            raise ValueError("uuid is required")
        return writer.update(uuid, rule)

    return dispatch_action(writer, body, {
        "create": _create,
        "update": _update,
        "delete": lambda b: writer.delete(str(b.get("uuid", "")) or _need_uuid()),
        "toggle": lambda b: writer.toggle(str(b.get("uuid", "")) or _need_uuid()),
        "reorder": lambda b: writer.reorder(b.get("order") or []),
        "move": lambda b: writer.move(str(b.get("uuid", "")) or _need_uuid(), str(b.get("before", ""))),
    })


def _need_uuid() -> str:
    raise ValueError("uuid is required")
