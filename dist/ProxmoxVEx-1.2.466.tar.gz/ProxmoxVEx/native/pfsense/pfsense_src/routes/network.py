# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/native/pfsense/pfsense_src/routes/network.py
# Project:     ProxmoxVEx
# Version:     1.2.453
# Build:       2026.09.14
# Description: Network payload — interfaces, static routes, gateways,...
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-14
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Network payload — interfaces, static routes, gateways, neighbors."""

from __future__ import annotations

import logging
from concurrent.futures import ThreadPoolExecutor
from typing import Any

from pfsense_src._fwkit import ensure_fwkit_importable
from pfsense_src.client import PFsenseClient, PFsenseHost
from pfsense_src.collectors import (
    collect_gateways,
    collect_interfaces,
    collect_neighbors,
    collect_routes,
)

ensure_fwkit_importable()

from ProxmoxVEx.native.fwkit.payloads import client_error_envelope  # noqa: E402

log = logging.getLogger(__name__)


def build_network(client: PFsenseClient) -> dict[str, Any]:
    tasks = {
        "interfaces": collect_interfaces,
        "routes": collect_routes,
        "gateways": collect_gateways,
        "neighbors": collect_neighbors,
    }
    with ThreadPoolExecutor(max_workers=len(tasks), thread_name_prefix="pf-network") as ex:
        futures = {name: ex.submit(fn, client) for name, fn in tasks.items()}
        return {name: fut.result() for name, fut in futures.items()}


def build_network_payload(host: PFsenseHost) -> tuple[int, dict[str, Any]]:
    client = PFsenseClient(host)
    try:
        return 200, {"ok": True, "data": build_network(client)}
    except Exception as e:
        return client_error_envelope(e, log_label="pfsense network")
