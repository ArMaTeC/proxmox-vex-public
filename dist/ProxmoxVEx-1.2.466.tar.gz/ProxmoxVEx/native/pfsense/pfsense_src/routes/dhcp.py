# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/native/pfsense/pfsense_src/routes/dhcp.py
# Project:     ProxmoxVEx
# Version:     1.2.453
# Build:       2026.09.14
# Description: DHCP route payloads for pfSense.
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-14
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""DHCP route payloads for pfSense."""

from __future__ import annotations

import logging
from typing import Any

from pfsense_src._fwkit import ensure_fwkit_importable
from pfsense_src.client import PFsenseClient, PFsenseHost
from pfsense_src.configmap import listify, read_dhcp_interfaces
from pfsense_src.routes._domain import dispatch_action, make_writer
from pfsense_src.writers import DhcpWriter

ensure_fwkit_importable()

from ProxmoxVEx.native.fwkit.normalize import (  # noqa: E402
    normalize_dhcp_mapping,
    normalize_dhcp_scope,
)
from ProxmoxVEx.native.fwkit.payloads import client_error_envelope, ok  # noqa: E402

log = logging.getLogger(__name__)


def build_dhcp_list_payload(host: PFsenseHost) -> tuple[int, dict[str, Any]]:
    client = PFsenseClient(host)
    try:
        dhcpd = read_dhcp_interfaces(client)
        scopes: list[dict[str, Any]] = []
        mappings: list[dict[str, Any]] = []
        for i, (iface, node) in enumerate(sorted(dhcpd.items())):
            if not isinstance(node, dict):
                continue
            scopes.append(normalize_dhcp_scope({**node, "interface": iface}, "pfsense", i))
            for j, m in enumerate(listify(node.get("staticmap"))):
                mappings.append(normalize_dhcp_mapping(m, "pfsense", iface, j))
        return ok({"scopes": scopes, "mappings": mappings})
    except Exception as e:
        return client_error_envelope(e, log_label="pfsense dhcp list")


def build_dhcp_action_payload(
    host: PFsenseHost,
    plugin_dir: str,
    body: dict[str, Any],
    *,
    peer_host: PFsenseHost | None = None,
    actor: str = "plugin",
) -> tuple[int, dict[str, Any]]:
    writer = make_writer(DhcpWriter, host, peer_host, plugin_dir, actor)

    def _scope(b: dict[str, Any]) -> dict[str, Any]:
        scope = b.get("scope") or {}
        if not isinstance(scope, dict):
            raise ValueError("scope must be an object")
        return scope

    def _mapping(b: dict[str, Any]) -> dict[str, Any]:
        mapping = b.get("mapping") or {}
        if not isinstance(mapping, dict):
            raise ValueError("mapping must be an object")
        return mapping

    def _iface(b: dict[str, Any]) -> str:
        iface = str(b.get("interface") or (b.get("scope") or {}).get("interface") or "")
        if not iface:
            raise ValueError("interface is required")
        return iface

    return dispatch_action(writer, body, {
        "scope_set": lambda b: writer.set_scope(_scope(b)),
        "scope_delete": lambda b: writer.delete_scope(_iface(b)),
        "mapping_set": lambda b: writer.set_mapping(_mapping(b)),
        "mapping_delete": lambda b: writer.delete_mapping(
            str(b.get("interface") or (b.get("mapping") or {}).get("interface") or ""),
            str(b.get("uuid") or (b.get("mapping") or {}).get("mac") or ""),
        ),
    })
