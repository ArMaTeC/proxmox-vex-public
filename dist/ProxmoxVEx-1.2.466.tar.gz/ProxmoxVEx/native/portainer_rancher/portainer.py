# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/native/portainer_rancher/portainer.py
# Project:     ProxmoxVEx
# Version:     1.2.453
# Build:       2026.09.14
# Description: Portainer REST API client (CE/BE, server + edge-agent...
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-14
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Portainer REST API client (CE/BE, server + edge-agent topologies).

Auth: ``X-Api-Key: <token>`` (API access token) or OAuth-capable
username/password via ``POST /api/auth`` which returns a JWT sent as
``Authorization: Bearer``.

A ``mock://`` base URL activates the deterministic in-memory
:class:`MockPortainerSession` used by unit/contract tests.
"""

import logging
from typing import Any, Dict, List, Optional
from urllib.parse import urlparse

import requests

from . import models

log = logging.getLogger("native.portainer_rancher.portainer")

MOCK_SCHEME = "mock://"
DEFAULT_TIMEOUT = 15

ERROR_CODES = {
    "connection.unreachable": "Portainer server unreachable",
    "connection.timeout": "Portainer API unreachable (timeout)",
    "auth.forbidden": "Invalid token or insufficient scope",
    "tls.verify": "TLS verification failed",
    "notfound": "Object not found on Portainer",
    "endpoint.down": "Endpoint is down",
    "operation.failed": "Remote operation failed",
}

# Portainer endpoint Type field → our endpoint_type label.
_ENDPOINT_TYPE_MAP = {
    1: "docker",
    2: "swarm",      # agent on swarm
    3: "swarm",      # swarm (Azure/legacy)
    4: "edge_agent",
    5: "kubernetes",
    6: "kubernetes",  # agent on k8s
    7: "edge_agent",  # edge agent on k8s
}
_ENDPOINT_STATUS_MAP = {1: "up", 2: "down"}


def _map_request_error(e: Exception) -> "PortainerError":
    if isinstance(e, requests.exceptions.SSLError):
        return PortainerError("tls.verify", str(e))
    if isinstance(e, requests.exceptions.ConnectTimeout):
        return PortainerError("connection.timeout", str(e))
    if isinstance(e, requests.exceptions.ConnectionError):
        return PortainerError("connection.unreachable", str(e))
    if isinstance(e, requests.exceptions.Timeout):
        return PortainerError("connection.timeout", str(e))
    return PortainerError("operation.failed", str(e))


class PortainerError(Exception):
    """Connector error with a stable machine-readable code."""

    def __init__(self, code: str, message: str = ""):
        self.code = code
        self.message = message or ERROR_CODES.get(code, code)
        super().__init__(self.message)


class PortainerConnector:
    """Portainer REST client with API-token / OAuth auth and ``mock://`` transport."""

    def __init__(
        self,
        base_url: str,
        auth_type: str = "api_token",
        credential: Optional[Dict[str, Any]] = None,
        tls_verify: bool = True,
        timeout: int = DEFAULT_TIMEOUT,
    ):
        self.raw_base_url = (base_url or "").rstrip("/")
        self.auth_type = auth_type
        self.credential = credential or {}
        self.tls_verify = tls_verify
        self.timeout = timeout
        self._jwt: Optional[str] = None
        self._session = requests.Session()

    # -- transport -----------------------------------------------------------

    def _use_mock(self) -> bool:
        return self.raw_base_url.startswith(MOCK_SCHEME)

    def _api_base(self) -> str:
        return f"{self.raw_base_url}/api"

    def _headers(self) -> Dict[str, str]:
        if self._jwt:
            return {"Authorization": f"Bearer {self._jwt}"}
        token = self.credential.get("token", "")
        if token:
            # X-Api-Key works on both CE and BE for API access tokens.
            return {"X-Api-Key": token}
        return {}

    def login(self) -> None:
        """Authenticate via OAuth-capable username/password (POST /api/auth)."""
        if self.auth_type != "oauth" or self._jwt:
            return
        if self._use_mock():
            if self.credential.get("username") == "bad":
                raise PortainerError("auth.forbidden", "mock bad credentials")
            self._jwt = "mock-jwt"
            return
        try:
            resp = self._session.post(
                f"{self._api_base()}/auth",
                json={
                    "username": self.credential.get("username", ""),
                    "password": self.credential.get("password", ""),
                },
                verify=self.tls_verify,
                timeout=self.timeout,
            )
        except Exception as e:
            raise _map_request_error(e) from e
        if resp.status_code in (401, 403):
            raise PortainerError("auth.forbidden")
        if resp.status_code >= 400:
            raise PortainerError("operation.failed", f"auth HTTP {resp.status_code}")
        self._jwt = resp.json().get("jwt", "")

    def _request(self, method: str, path: str, _retried: bool = False, **kwargs) -> Any:
        # OAuth login applies to the mock transport too so bad-credential
        # paths are exercised in tests.
        self.login()
        if self._use_mock():
            return MockPortainerSession.request(self, method, path, **kwargs)
        url = f"{self._api_base()}{path}"
        try:
            resp = self._session.request(
                method,
                url,
                headers={**self._headers(), **kwargs.pop("headers", {})},
                verify=self.tls_verify,
                timeout=self.timeout,
                **kwargs,
            )
        except Exception as e:
            raise _map_request_error(e) from e
        if resp.status_code == 401 and not _retried and self.auth_type == "oauth":
            self._jwt = None
            return self._request(method, path, _retried=True, **kwargs)
        if resp.status_code in (401, 403):
            raise PortainerError("auth.forbidden")
        if resp.status_code == 404:
            raise PortainerError("notfound", path)
        if resp.status_code >= 400:
            raise PortainerError(
                "operation.failed", f"HTTP {resp.status_code}: {resp.text[:200]}"
            )
        if resp.status_code == 204 or not resp.content:
            return {}
        try:
            return resp.json()
        except ValueError:
            return {"raw": resp.text}

    def _get(self, path: str, params: Optional[Dict[str, Any]] = None) -> Any:
        return self._request("GET", path, params=params)

    def _post(self, path: str, body: Optional[Dict[str, Any]] = None) -> Any:
        return self._request("POST", path, json=body or {})

    # -- inventory -----------------------------------------------------------

    def get_status(self) -> Dict[str, Any]:
        """GET /api/system/status (+ /api/status fallback) → version/instance."""
        try:
            data = self._get("/system/status")
        except PortainerError as e:
            if e.code != "notfound":
                raise
            data = self._get("/status")
        return data or {}

    def test_connection(self) -> Dict[str, Any]:
        """Validate the token with an authenticated read; report version/edition."""
        status = self.get_status()
        version = status.get("version") or status.get("Version") or ""
        edition = status.get("edition") or status.get("Edition") or ""
        if not edition:
            try:
                lic = self._get("/licenses/check")
                if isinstance(lic, dict) and lic.get("valid"):
                    edition = "BE"
            except PortainerError:
                pass
        if not edition:
            edition = "CE"
        return {
            "version": version,
            "edition": edition,
            "instance_id": status.get("instanceID") or status.get("InstanceID") or "",
        }

    def list_endpoints(self) -> List[Dict[str, Any]]:
        """GET /api/endpoints → normalized endpoint dicts."""
        raw = self._get("/endpoints")
        if isinstance(raw, dict):
            raw = raw.get("data") or raw.get("endpoints") or []
        return [self._parse_endpoint(e) for e in raw or []]

    @staticmethod
    def _parse_endpoint(e: Dict[str, Any]) -> Dict[str, Any]:
        etype = _ENDPOINT_TYPE_MAP.get(e.get("Type") or 0, "unknown")
        status = _ENDPOINT_STATUS_MAP.get(e.get("Status") or 0, "unknown")
        heartbeat = None
        if e.get("LastCheckIn"):
            try:
                from datetime import datetime, timezone

                heartbeat = datetime.fromtimestamp(
                    int(e["LastCheckIn"]), tz=timezone.utc
                ).isoformat()
            except (TypeError, ValueError, OSError):
                heartbeat = None
        snapshots = e.get("Snapshots") or []
        container_count = 0
        if snapshots and isinstance(snapshots[0], dict):
            container_count = int(snapshots[0].get("RunningContainerCount") or 0)
        container_count = container_count or int(
            (e.get("DockerSnapshot") or [{}])[0].get("RunningContainerCount", 0)
            if isinstance(e.get("DockerSnapshot"), list)
            else 0
        )
        engine_id = ""
        if e.get("DockerSnapshot") and isinstance(e["DockerSnapshot"], list):
            engine_id = e["DockerSnapshot"][0].get("Info", {}).get("ID", "")
        return {
            "endpoint_id": int(e.get("Id", 0)),
            "name": e.get("Name", ""),
            "endpoint_type": etype,
            "status": status,
            "url": e.get("URL", ""),
            "engine_id": engine_id or e.get("EdgeID", ""),
            "last_heartbeat": heartbeat,
            "container_count": container_count,
            "tags": e.get("TagIds") or e.get("Tags") or [],
            "groups": [e.get("GroupId")] if e.get("GroupId") else [],
            "edge_id": e.get("EdgeID", ""),
        }

    def list_stacks(self, endpoint_id: Optional[int] = None) -> List[Dict[str, Any]]:
        """GET /api/stacks (optionally filtered to one endpoint)."""
        params = None
        if endpoint_id is not None:
            import json as _json

            params = {"filters": _json.dumps({"EndpointID": int(endpoint_id)})}
        raw = self._get("/stacks", params=params)
        if isinstance(raw, dict):
            raw = raw.get("data") or []
        out = []
        for s in raw or []:
            status_map = {1: "active", 2: "inactive"}
            out.append({
                "stack_id": int(s.get("Id", 0)),
                "endpoint_id": int(s.get("EndpointId", 0)),
                "name": s.get("Name", ""),
                "status": status_map.get(s.get("Status"), "unknown"),
                "source": {1: "compose", 2: "compose", 3: "git"}.get(
                    s.get("Type"), "unknown"
                ),
                "services": s.get("Services") or [],
            })
        return out

    def list_containers(self, endpoint_id: int, all_containers: bool = True) -> List[Dict[str, Any]]:
        """GET /api/endpoints/{id}/docker/containers/json."""
        raw = self._get(
            f"/endpoints/{int(endpoint_id)}/docker/containers/json",
            params={"all": 1 if all_containers else 0},
        )
        if isinstance(raw, dict):
            raw = raw.get("data") or []
        return [self._parse_container(c) for c in raw or []]

    @staticmethod
    def _parse_container(c: Dict[str, Any]) -> Dict[str, Any]:
        names = c.get("Names") or []
        name = c.get("Name") or (names[0].lstrip("/") if names else "")
        labels = c.get("Labels") or {}
        status_text = c.get("Status", "")
        health = "unknown"
        if "(healthy)" in status_text:
            health = "healthy"
        elif "(unhealthy)" in status_text:
            health = "unhealthy"
        return {
            "container_id": c.get("Id", ""),
            "name": name,
            "image": c.get("Image", ""),
            "state": (c.get("State") or "unknown").lower(),
            "status_text": status_text,
            "health": health,
            "restart_count": int(c.get("RestartCount") or 0),
            "stack_name": labels.get("com.docker.stack.namespace")
            or labels.get("com.docker.compose.project", ""),
            "node_name": labels.get("com.docker.swarm.node.name", ""),
            "ports": c.get("Ports") or [],
            "labels": labels,
            "created": c.get("Created"),
        }

    def list_images(self, endpoint_id: int) -> List[Dict[str, Any]]:
        raw = self._get(f"/endpoints/{int(endpoint_id)}/docker/images/json")
        if isinstance(raw, dict):
            raw = raw.get("data") or []
        out = []
        for img in raw or []:
            out.append({
                "image_id": img.get("Id", ""),
                "tags": img.get("RepoTags") or [],
                "size_bytes": int(img.get("Size") or 0),
                "in_use": bool(img.get("Containers", 0) and img["Containers"] > 0)
                or bool(img.get("Used")),
            })
        return out

    def inspect_endpoint(self, endpoint_id: int) -> Dict[str, Any]:
        return self._get(f"/endpoints/{int(endpoint_id)}")

    # -- operations ----------------------------------------------------------

    def container_action(
        self, endpoint_id: int, container_id: str, action: str
    ) -> Dict[str, Any]:
        """POST start/stop/restart/pause/unpause/kill on a container."""
        if action not in models.CONTAINER_ACTIONS:
            raise PortainerError("operation.failed", f"unsupported action {action}")
        self._post(
            f"/endpoints/{int(endpoint_id)}/docker/containers/{container_id}/{action}"
        )
        return {"action": action, "container_id": container_id, "done": True}

    def stack_action(self, stack_id: int, action: str) -> Dict[str, Any]:
        """POST /api/stacks/{id}/start|stop (BE/CE where supported)."""
        if action not in models.STACK_ACTIONS:
            raise PortainerError("operation.failed", f"unsupported stack action {action}")
        self._post(f"/stacks/{int(stack_id)}/{action}")
        return {"action": action, "stack_id": stack_id, "done": True}


def build_connector(conn: models.PortainerConnection) -> PortainerConnector:
    return PortainerConnector(
        base_url=conn.base_url,
        auth_type=conn.auth_type,
        credential=models.get_portainer_credential(conn.id or 0),
        tls_verify=conn.tls_verify,
    )


# ---------------------------------------------------------------------------
# Deterministic mock transport
# ---------------------------------------------------------------------------


class MockPortainerSession:
    """In-memory Portainer server used when base_url is ``mock://``.

    ``mock://bad`` simulates an invalid/revoked token (401 on every call).
    """

    @staticmethod
    def _check_auth(connector: "PortainerConnector") -> None:
        host = urlparse(connector.raw_base_url).hostname or ""
        if "bad" in host or connector.credential.get("token") == "bad":
            raise PortainerError("auth.forbidden", "mock invalid token")

    @staticmethod
    def request(connector: "PortainerConnector", method: str, path: str, **kwargs) -> Any:
        MockPortainerSession._check_auth(connector)

        if path in ("/system/status", "/status"):
            return {
                "version": "2.20.3",
                "edition": "CE",
                "instanceID": "mock-instance",
            }
        if path == "/licenses/check":
            return {"valid": False}

        if path == "/endpoints" and method == "GET":
            return [
                {
                    "Id": 1,
                    "Name": "local",
                    "Type": 1,
                    "Status": 1,
                    "URL": "unix:///var/run/docker.sock",
                    "GroupId": 1,
                    "Snapshots": [{"RunningContainerCount": 2}],
                    "DockerSnapshot": [{"Info": {"ID": "engine-local-1"}}],
                },
                {
                    "Id": 2,
                    "Name": "edge-site-1",
                    "Type": 4,
                    "Status": 2,
                    "LastCheckIn": 1600000000,
                    "EdgeID": "edge-abc",
                    "GroupId": 2,
                },
            ]

        if path == "/stacks":
            return [
                {
                    "Id": 10,
                    "Name": "web-stack",
                    "EndpointId": 1,
                    "Status": 1,
                    "Type": 2,
                    "Services": [{"Name": "web"}],
                }
            ]

        if path.endswith("/docker/containers/json"):
            return [
                {
                    "Id": "c1aaaaaaaabbbb",
                    "Names": ["/web-1"],
                    "Image": "nginx:1.25",
                    "State": "running",
                    "Status": "Up 2 hours (healthy)",
                    "RestartCount": 0,
                    "Labels": {"com.docker.compose.project": "web-stack"},
                    "Ports": [{"IP": "0.0.0.0", "PublicPort": 8080, "PrivatePort": 80}],
                },
                {
                    "Id": "c2ccccccccdddd",
                    "Names": ["/flaky-1"],
                    "Image": "app:latest",
                    "State": "restarting",
                    "Status": "Restarting (1) 3 seconds ago",
                    "RestartCount": 12,
                    "Labels": {},
                    "Ports": [],
                },
            ]

        if path.endswith("/docker/images/json"):
            return [
                {
                    "Id": "sha256:img1",
                    "RepoTags": ["nginx:1.25"],
                    "Size": 187000000,
                    "Containers": 1,
                },
                {
                    "Id": "sha256:img2",
                    "RepoTags": ["app:latest"],
                    "Size": 99000000,
                    "Containers": 0,
                },
            ]

        if "/docker/containers/" in path and method == "POST":
            action = path.rsplit("/", 1)[-1]
            if action not in models.CONTAINER_ACTIONS:
                raise PortainerError("notfound", path)
            return {}

        if path.startswith("/stacks/") and method == "POST":
            action = path.rsplit("/", 1)[-1]
            if action not in models.STACK_ACTIONS:
                raise PortainerError("notfound", path)
            return {}

        raise PortainerError("notfound", path)
