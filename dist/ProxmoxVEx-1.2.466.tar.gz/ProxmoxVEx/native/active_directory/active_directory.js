/* --- ProxmoxVEx auto-header start ---
 * -------------------------------------------------------------------
 * File:        ProxmoxVEx/native/active_directory/active_directory.js
 * Project:     ProxmoxVEx
 * Version:     1.2.453
 * Build:       2026.09.14
 * Description: Active Directory JS source
 * Docs:        https://proxmoxvex.com/docs
 * Generated:   2026-09-14
 * -------------------------------------------------------------------
 * --- ProxmoxVEx auto-header end --- */
/* Active Directory view: declarative tabs rendered by the shared
   NativeDataView shell (replaces the previous raw JSON <pre> dump). */
(function () {
  'use strict';

  NativeDataView.boot({
    ns: 'active_directory',
    apiBase: '/api/active_directory',
    i18nBase: '/api/native/active_directory/i18n',
    tabs: [
      {
        id: 'overview', label: 'overview', endpoint: 'overview',
        render: function (h, data) {
          var row = (data && data[0]) || {};
          h.root.appendChild(h.kpis([
            { label: h.t('users'), value: row.users_count },
            { label: h.t('groups'), value: row.groups_count }
          ]));
          h.section(h.t('connection'), h.kv([
            [h.t('host'), row.host],
            [h.t('server'), row.server],
            ['Base DN', row.base_dn],
            [h.t('users'), row.users_ok ? h.badge('OK', 'ok') : h.badge('Error', 'err')],
            [h.t('groups'), row.groups_ok ? h.badge('OK', 'ok') : h.badge('Error', 'err')]
          ]));
          var conn = row.connection || {};
          var connPairs = Object.keys(conn).map(function (k) {
            return [NativeDataView.titleize(k), conn[k]];
          });
          if (connPairs.length) h.section(h.t('connection_status'), h.kv(connPairs));
        }
      },
      {
        id: 'users', label: 'users', endpoint: 'users',
        render: function (h, data) {
          h.root.appendChild(h.table(data || [], [
            { key: 'name', label: h.t('name') },
            { key: 'username', label: h.t('username') },
            { key: 'email', label: h.t('email') },
            {
              key: 'enabled', label: h.t('enabled'),
              render: function (v) { return h.badge(v ? h.t('yes') : h.t('no'), v ? 'ok' : 'muted'); }
            },
            { key: 'groups', label: h.t('groups'), render: function (v) { return h.chips(v); } },
            {
              key: 'dn', label: 'DN',
              render: function (v) { return h.el('span', { class: 'ndv-muted ndv-mono', text: v }); }
            }
          ]));
        }
      },
      {
        id: 'groups', label: 'groups', endpoint: 'groups',
        render: function (h, data) {
          h.root.appendChild(h.table(data || [], [
            { key: 'name', label: h.t('name') },
            { key: 'members', label: h.t('members'), render: function (v) { return h.fmtNum(v); } },
            {
              key: 'dn', label: 'DN',
              render: function (v) { return h.el('span', { class: 'ndv-muted ndv-mono', text: v }); }
            }
          ]));
        }
      }
    ]
  });
})();
