# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/api/licence.py
# Project:     ProxmoxVEx
# Version:     1.2.460
# Build:       2026.09.16
# Description: Licensing API routes for the main ProxmoxVEx application.
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-16
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Licensing API routes for the main ProxmoxVEx application."""

import gzip
import json
import logging

from flask import Blueprint, jsonify, make_response, request

from ProxmoxVEx.core.db import get_db
from ProxmoxVEx.services.licensing import (
    LicensingService,
    _calculated_machine_id,
    _node_fingerprint,
)
from ProxmoxVEx.utils.auth import require_auth

bp = Blueprint("licence", __name__)
service = LicensingService()

# Simple in-memory cache for license check results.
_license_check_cache = {}


def _license_cache_key(*args):
    return "|".join(str(a) for a in args)


def get_cached_license_check(key, generator):
    """Return cached license check result or generate and cache it."""
    if key in _license_check_cache:
        return _license_check_cache[key]
    result = generator()
    _license_check_cache[key] = result
    return result


def invalidate_license_check_cache(key=None):
    """Invalidate all or one license check cache entry."""
    global _license_check_cache
    if key is None:
        _license_check_cache = {}
    else:
        _license_check_cache.pop(key, None)


class LazyLicenseCheck:
    """Lazy loader that defers license check execution until first requested."""

    def __init__(self, check_id, check_factory):
        self.check_id = check_id
        self._check_factory = check_factory
        self._result = None

    def get(self):
        if self._result is None:
            self._result = self._check_factory()
        return self._result


def load_license_check_lazy(check_id, check_factory):
    """Create a lazy wrapper for a license check operation."""
    return LazyLicenseCheck(check_id, check_factory)


def _safe_key() -> str:
    key = request.get_json(silent=True) or {}
    return (key.get("license_key") or "").strip()


def _safe_email() -> str:
    data = request.get_json(silent=True) or {}
    return (data.get("email") or "").strip()


@bp.route("/api/v1/licence/activate", methods=["POST"])
@require_auth(perms=["admin.settings"])
def activate_licence():
    """Activate a license key and cache the resulting tier."""
    license_key = _safe_key()
    if not license_key:
        return jsonify({"ok": False, "error": {"code": "INVALID_REQUEST", "message": "license_key is required"}}), 400
    email = _safe_email()
    if not email or "@" not in email or "." not in email.split("@")[-1]:
        return jsonify({"ok": False, "error": {"code": "INVALID_REQUEST", "message": "A valid registered email is required to activate the license"}}), 400

    db = get_db()
    result = service.activate(db, license_key, email)

    # After a successful tier change, reload enabled plugins so newly-licensed
    # plugins are loaded immediately instead of requiring a server restart.
    if result.get("ok") and result.get("data", {}).get("valid"):
        try:
            from ProxmoxVEx.api.plugins import (
                _current_flask_app,
                load_enabled_plugins,
                start_plugin_backgrounds,
            )

            load_enabled_plugins(_current_flask_app())
            start_plugin_backgrounds()
        except Exception as exc:
            logging.warning("[LICENCE] Plugin reload after activation failed: %s", exc)

    return jsonify(result)


@bp.route("/api/v1/licence/status", methods=["GET"])
@require_auth(perms=["admin.settings"])
def licence_status():
    """Return the currently cached license tier."""
    db = get_db()
    # The calculated machine ID is shown on the licence page so an admin can
    # tell which server a key is locked to when managing it in the portal.
    machine_id = _calculated_machine_id()
    ctx = service.get_context(db)
    if not ctx:
        return jsonify({"ok": True, "data": {"active": False, "tier": None, "machine_id": machine_id}})
    return jsonify({
        "ok": True,
        "data": {
            "active": True,
            "tier": {"slug": ctx.tier_slug, "name": ctx.tier_name},
            "billing_period": ctx.billing_period,
            "purchased_at": ctx.purchased_at.isoformat() if ctx.purchased_at else None,
            "valid_until": ctx.valid_until.isoformat() if ctx.valid_until else None,
            "last_validated_at": ctx.last_validated_at.isoformat(),
            "next_check_at": ctx.next_check_at.isoformat(),
            "machine_id": machine_id,
            "node_fingerprint": _node_fingerprint(),
        },
    })


@bp.route("/api/v1/licence/log", methods=["GET"])
@require_auth(perms=["admin.settings"])
def licence_log():
    """Return the recent license lifecycle log for this node."""
    limit = max(1, min(int(request.args.get("limit", 50)), 200))
    db = get_db()
    return jsonify({"ok": True, "data": service.get_license_log(db, limit=limit)})


@bp.route("/api/v1/licence/tiers", methods=["GET"])
@require_auth(perms=["admin.settings"])
def list_tiers():
    """Return subscription tiers from the license service."""
    currency = request.args.get("currency", "USD").strip().upper()
    return jsonify(service.get_tiers(currency))


@bp.route("/api/v1/licence/plugins/<plugin_slug>", methods=["GET"])
@require_auth(perms=["plugins.view"])
def can_use_plugin(plugin_slug: str):
    """Return whether the current license allows a given plugin."""
    db = get_db()
    allowed = service.can_use_plugin(db, plugin_slug)
    return jsonify({"ok": True, "data": {"allowed": allowed}})


@bp.route("/api/v1/licence/tier-plugins/<tier_slug>", methods=["GET"])
@require_auth(perms=["admin.settings"])
def get_tier_plugins_route(tier_slug: str):
    """Return the explicitly allowed plugin slugs for a tier."""
    db = get_db()
    plugins = service.get_allowed_plugins(db, tier_slug)
    configured = plugins is not None
    return jsonify({
        "ok": True,
        "data": {
            "tier_slug": tier_slug,
            "configured": configured,
            "plugins": plugins if configured else [],
        },
    })


@bp.route("/api/v1/licence/tier-plugins", methods=["POST"])
@require_auth(perms=["admin.settings"])
def set_tier_plugins_route():
    """Set the allowed plugin slugs for a tier (replaces existing)."""
    data = request.get_json(silent=True) or {}
    tier_slug = (data.get("tier_slug") or "").strip()
    plugins = data.get("plugins", [])
    if not tier_slug:
        return jsonify({"ok": False, "error": {"code": "INVALID_REQUEST", "message": "tier_slug is required"}}), 400
    if not isinstance(plugins, list) or any(not isinstance(p, str) for p in plugins):
        return jsonify({
            "ok": False,
            "error": {"code": "INVALID_REQUEST", "message": "plugins must be a list of slugs"},
        }), 400

    db = get_db()
    service.set_allowed_plugins(db, tier_slug, plugins)
    return jsonify({"ok": True, "data": {"tier_slug": tier_slug, "plugins": plugins}})


def _paginate(items, page, per_page):
    """Return a single page of a list."""
    start = (page - 1) * per_page
    end = start + per_page
    return items[start:end]


@bp.route("/api/v1/licence/checks", methods=["GET"])
@require_auth(perms=["admin.settings"])
def paginated_license_checks():
    """Return paginated license check results from the in-memory cache."""
    checks = [{"id": key, "result": value} for key, value in _license_check_cache.items()]
    from ProxmoxVEx.utils.sanitization import sanitize_int

    page = sanitize_int(request.args.get("page", 1), default=1, min_val=1)
    per_page = sanitize_int(request.args.get("per_page", 20), default=20, min_val=1, max_val=100)
    paginated = _paginate(checks, page, per_page)
    return jsonify({
        "ok": True,
        "data": {
            "items": paginated,
            "page": page,
            "per_page": per_page,
            "total": len(checks),
        },
    })


@bp.route("/api/v1/licence/batch-check", methods=["POST"])
@require_auth(perms=["admin.settings"])
def batch_check_licences():
    """Check multiple plugin licenses in a single batched request."""
    data = request.get_json(silent=True) or {}
    plugins = data.get("plugins", [])
    if not isinstance(plugins, list) or any(not isinstance(p, str) for p in plugins):
        return jsonify({
            "ok": False,
            "error": {"code": "INVALID_REQUEST", "message": "plugins must be a list of slugs"},
        }), 400

    db = get_db()
    results = [{"slug": slug, "allowed": service.can_use_plugin(db, slug)} for slug in plugins]
    return jsonify({
        "ok": True,
        "data": {
            "results": results,
            "checked": len(results),
        },
    })


@bp.route("/api/v1/licence/checks/<check_id>", methods=["GET"])
@require_auth(perms=["admin.settings"])
def get_license_check_by_id(check_id: str):
    """Return a single cached license check result by its index key."""
    result = _license_check_cache.get(check_id)
    if result is None:
        return jsonify({"ok": False, "error": {"code": "NOT_FOUND", "message": "check_id not found"}}), 404
    return jsonify({"ok": True, "data": {"id": check_id, "result": result}})


def _compress_license_check_data(data: dict) -> bytes:
    """Compress license check data using gzip."""
    raw = json.dumps(data).encode("utf-8")
    return gzip.compress(raw)


@bp.route("/api/v1/licence/checks/compressed/<check_id>", methods=["GET"])
@require_auth(perms=["admin.settings"])
def get_compressed_license_check(check_id: str):
    """Return a gzip-compressed license check result."""
    result = _license_check_cache.get(check_id)
    if result is None:
        return jsonify({"ok": False, "error": {"code": "NOT_FOUND", "message": "check_id not found"}}), 404
    payload = {"ok": True, "data": {"id": check_id, "result": result}}
    compressed = _compress_license_check_data(payload)
    response = make_response(compressed)
    response.headers["Content-Type"] = "application/octet-stream"
    response.headers["Content-Encoding"] = "gzip"
    return response


class LicenseConnectionPool:
    """Simple fixed-size pool for reusing license check contexts."""

    def __init__(self, size=4):
        self.size = max(1, size)
        self._available = list(range(self.size))

    def acquire(self):
        if not self._available:
            return None
        return self._available.pop()

    def release(self, context):
        if context not in self._available and len(self._available) < self.size:
            self._available.append(context)

    def status(self):
        return {
            "size": self.size,
            "available": len(self._available),
            "in_use": self.size - len(self._available),
        }


_license_pool = LicenseConnectionPool()


@bp.route("/api/v1/licence/pool-status", methods=["GET"])
@require_auth(perms=["admin.settings"])
def get_license_pool_status():
    """Return the status of the license check connection pool."""
    return jsonify({"ok": True, "data": _license_pool.status()})


class AsyncLicenseWorker:
    """Asynchronous worker that submits license check tasks in the background."""

    def __init__(self):
        self._tasks = {}
        self._counter = 0

    def submit(self, check_id, check_factory):
        self._counter += 1
        task_id = f"task-{self._counter}"
        # Run the check immediately for simplicity and store the result.
        self._tasks[task_id] = {"check_id": check_id, "status": "done", "result": check_factory()}
        return task_id

    def get(self, task_id):
        return self._tasks.get(task_id)


_license_worker = AsyncLicenseWorker()


@bp.route("/api/v1/licence/checks/async", methods=["POST"])
@require_auth(perms=["admin.settings"])
def submit_async_license_check():
    """Submit a license check to be processed asynchronously."""
    data = request.get_json(silent=True) or {}
    check_id = (data.get("check_id") or "").strip()
    if not check_id:
        return jsonify({"ok": False, "error": {"code": "INVALID_REQUEST", "message": "check_id is required"}}), 400

    task_id = _license_worker.submit(check_id, lambda: get_cached_license_check(check_id, lambda: True))
    return jsonify({"ok": True, "data": {"task_id": task_id}})


MAX_LICENSE_CACHE_ENTRIES = 256


def _trim_license_check_cache():
    """Evict oldest entries when the license check cache exceeds the memory limit."""
    global _license_check_cache
    while len(_license_check_cache) > MAX_LICENSE_CACHE_ENTRIES:
        if _license_check_cache:
            first_key = next(iter(_license_check_cache))
            _license_check_cache.pop(first_key)


@bp.route("/api/v1/licence/checks/memory", methods=["GET"])
@require_auth(perms=["admin.settings"])
def get_license_check_memory():
    """Return memory optimisation metrics for the license check cache."""
    _trim_license_check_cache()
    return jsonify({
        "ok": True,
        "data": {
            "max_entries": MAX_LICENSE_CACHE_ENTRIES,
            "current_entries": len(_license_check_cache),
        },
    })


# Incremental update version tracking for license check results.
_license_check_version = 0
_license_check_update_log = []


def _record_license_check_update(check_id, result):
    """Record an incremental update for a license check result."""
    global _license_check_version
    _license_check_version += 1
    _license_check_update_log.append({
        "version": _license_check_version,
        "check_id": check_id,
        "result": result,
    })


def _get_incremental_license_check_updates(since):
    """Return license check updates with a version greater than the given one."""
    return [u for u in _license_check_update_log if u["version"] > since]


@bp.route("/api/v1/licence/checks/incremental", methods=["GET"])
@require_auth(perms=["admin.settings"])
def get_incremental_license_check_updates():
    """Return incremental license check updates since a given version."""
    since = int(request.args.get("since", 0))
    updates = _get_incremental_license_check_updates(since)
    return jsonify({
        "ok": True,
        "data": {
            "since": since,
            "current_version": _license_check_version,
            "updates": updates,
        },
    })


@bp.route("/api/v1/licence/paypal/create-order", methods=["POST"])
@require_auth(perms=["admin.settings"])
def create_paypal_order():
    """Proxy a PayPal order creation request to the licensing service."""
    data = request.get_json(silent=True) or {}
    tier_slug = (data.get("tier_slug") or "").strip()
    billing_period = (data.get("billing_period") or "monthly").strip().lower()
    currency = (data.get("currency") or "USD").strip().upper()
    email = (data.get("email") or "").strip()
    if not tier_slug or not email:
        return jsonify({"ok": False, "error": {"code": "INVALID_REQUEST", "message": "tier_slug and email are required"}}), 400
    if billing_period not in {"monthly", "yearly"}:
        return jsonify({"ok": False, "error": {"code": "INVALID_REQUEST", "message": "billing_period must be monthly or yearly"}}), 400

    result = service.create_paypal_order(tier_slug, billing_period, currency, email)
    if result is None:
        return jsonify({"ok": False, "error": {"code": "SERVICE_ERROR", "message": "Unable to reach license service"}}), 502
    return jsonify(result)
