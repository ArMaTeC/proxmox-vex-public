# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/api/stepup.py
# Project:     ProxmoxVEx
# Version:     1.2.453
# Build:       2026.09.14
# Description: Step-up MFA endpoints (spec 038).
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-14
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Step-up MFA endpoints (spec 038).

`POST /api/auth/stepup/verify` re-verifies a second factor (TOTP code or a
WebAuthn proof minted by /api/webauthn/auth/finish) and stamps a session-bound
elevation that `require_stepup()` consults on destructive endpoints.
"""

import logging

from flask import Blueprint, jsonify, request

from ProxmoxVEx.models.permissions import DESTRUCTIVE_CATEGORIES
from ProxmoxVEx.utils.auth import TOTP_AVAILABLE, require_auth
from ProxmoxVEx.utils.ssh import check_auth_action_rate_limit
from ProxmoxVEx.utils.stepup import (
    enrolled_methods,
    grant_elevation,
    is_elevated,
    stepup_window_seconds,
)

bp = Blueprint("stepup", __name__)


def _current_user_record(username: str):
    from ProxmoxVEx.utils.stepup import _acting_user

    return _acting_user({"user": username})


@bp.route("/api/auth/stepup/status", methods=["GET"])
@require_auth()
def stepup_status():
    """Report the caller's elevation state + effective step-up policy."""
    session = request.session
    username = session.get("user", "")
    user = _current_user_record(username)

    from ProxmoxVEx.api.helpers import load_server_settings

    settings = load_server_settings() or {}
    cats = settings.get("mfa_stepup_categories") or {}
    return jsonify({
        "elevated": is_elevated(session),
        "elevated_until": session.get("elevated_until", 0),
        "required": bool(settings.get("mfa_stepup_enabled")),
        "categories": {c: bool(cats.get(c, True)) for c in DESTRUCTIVE_CATEGORIES},
        "window_minutes": stepup_window_seconds() // 60,
        "methods": enrolled_methods(username, user),
    })


@bp.route("/api/auth/stepup/verify", methods=["POST"])
@require_auth()
def stepup_verify():
    """Verify a second factor and grant a session-bound elevation."""
    session = request.session
    username = session.get("user", "")
    user = _current_user_record(username)

    # External IdP users can't satisfy a local factor — nothing to verify.
    if user.get("auth_source", "local") in ("oidc", "entra"):
        return jsonify({"error": "Step-up MFA is managed by your identity provider"}), 400

    data = request.get_json(silent=True) or {}
    code = (data.get("code") or "").strip()
    webauthn_proof = data.get("webauthn_proof") or ""

    if not code and not webauthn_proof:
        return jsonify({"error": "TOTP code or hardware-key proof required"}), 400

    methods = enrolled_methods(username, user)
    if not methods:
        return jsonify({"error": "No MFA factor enrolled", "enrollment_required": True}), 403

    # Brute-force guard — same pattern as login 2FA verify.
    if not check_auth_action_rate_limit(f"stepup_verify:{username}", max_attempts=5, window=300):
        return jsonify({"error": "Too many verification attempts. Try again in 5 minutes."}), 429

    ok = False
    method = None
    if webauthn_proof and "webauthn" in methods:
        from ProxmoxVEx.api.webauthn import consume_webauthn_proof

        ok = consume_webauthn_proof(username, webauthn_proof)
        method = "webauthn"
    elif code and "totp" in methods:
        if not TOTP_AVAILABLE:
            return jsonify({"error": "TOTP is enabled but pyotp is not installed on server"}), 500
        import pyotp

        ok = bool(pyotp.TOTP(user["totp_secret"]).verify(code, valid_window=1))
        method = "totp"
    else:
        return jsonify({"error": "Factor not enrolled for this account"}), 400

    from ProxmoxVEx.utils.audit import log_audit

    if not ok:
        logging.warning(f"stepup: invalid {method} proof for {username}")
        log_audit(username, "mfa.stepup.failed", f"Invalid {method} step-up verification")
        return jsonify({"error": "Invalid MFA code" if method == "totp" else "Invalid hardware-key proof"}), 401

    elevated_until = grant_elevation(session, method)
    logging.info(f"stepup: {username} elevated via {method} until {elevated_until}")
    log_audit(username, "mfa.stepup", f"Step-up verified via {method}")

    return jsonify({
        "success": True,
        "elevated_until": elevated_until,
        "window_minutes": stepup_window_seconds() // 60,
    })
