# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/demo/guard.py
# Project:     ProxmoxVEx
# Version:     1.2.463
# Build:       2026.09.16
# Description: Demo sandbox guard.
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-16
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Demo sandbox guard.

When demo mode is active this guard blocks all mutating API calls except
a small allow-list (login, health, demo token exchange).  It runs at the
Flask ``before_request`` stage so it catches every route uniformly.
"""

import fnmatch
import logging

from ProxmoxVEx.demo import is_demo_mode

MUTATING_METHODS = {"POST", "PUT", "PATCH", "DELETE"}

# Explicitly allowed routes when demo mode is enabled.  Everything else
# under /api/* with a mutating verb is rejected with a clear message.
# /api/sse/token only mints a read-only realtime token and /api/user/preferences
# stores harmless UI state — blocking them made the demo UI retry in a loop.
# /api/sse/subscribe only adjusts the in-memory cluster filter of an existing
# SSE client; blocking it 403-toasted demo visitors on every sidebar toggle.
_ALLOWED_DEMO_ROUTES = {
    "/api/auth/login",
    "/api/auth/logout",
    "/api/auth/check",
    "/api/demo/token",
    "/api/demo/login",
    "/api/health",
    "/api/sse/token",
    "/api/sse/subscribe",
    "/api/user/preferences",
}

# Read-only (GET) routes that still exfiltrate host file contents or produce
# downloadable artifacts. The mutating-method check cannot see these, so they
# are denied explicitly: demo visitors may browse directory listings but must
# not be able to open, download, or export files off the host.
_BLOCKED_DEMO_READ_ROUTES = {
    "/api/plugins/disk-usage-explorer/api/content",
    "/api/plugins/disk-usage-explorer/api/download",
    "/api/plugins/disk-usage-explorer/api/export",
}


def is_demo_guarded(method: str, path: str) -> bool:
    """Return True if the request should be blocked in demo mode."""
    if not is_demo_mode():
        return False
    if method == "OPTIONS":
        return False
    if not path.startswith("/api/"):
        return False
    if path in _BLOCKED_DEMO_READ_ROUTES:
        return True
    if method not in MUTATING_METHODS:
        return False
    return all(
        not (path == allowed or fnmatch.fnmatch(path, allowed + "*"))
        for allowed in _ALLOWED_DEMO_ROUTES
    )


def demo_guard_response(path: str):
    """Return a 403 response explaining that the action is disabled."""
    logging.warning(f"[DEMO_GUARD] Blocked {path} in demo mode")
    from flask import jsonify, make_response

    return make_response(
        jsonify(
            {
                "error": "demo_forbidden",
                "message": "This action is disabled in the demo sandbox.",
            }
        ),
        403,
    )
