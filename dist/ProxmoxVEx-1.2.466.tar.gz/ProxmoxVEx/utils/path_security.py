# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/utils/path_security.py
# Project:     ProxmoxVEx
# Version:     1.2.453
# Build:       2026.09.14
# Description: Path-traversal guards for user-supplied file paths.
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-14
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Path-traversal guards for user-supplied file paths."""

import logging
import os
from pathlib import Path


class PathTraversalError(ValueError):
    """Raised when a path escapes the configured allowed root."""


def safe_join_path(root: str | os.PathLike, *parts: str) -> str:
    """Safely join path components under ``root``.

    Resolves the joined path to an absolute, canonical path and verifies that
    the result is contained within ``root``. Rejects absolute ``parts``,
    parent-directory traversal (``..``), and symlink escapes.

    Returns the absolute canonical path on success. Raises
    :class:`PathTraversalError` on any violation.
    """
    root_path = Path(root).resolve()

    # Reject any absolute components outright; only relative path pieces are safe
    for part in parts:
        if os.path.isabs(part):
            logging.warning("[path-security] rejected absolute path component: %r", part)
            raise PathTraversalError(f"absolute path component not allowed: {part!r}")

    # Build a relative target and resolve it relative to the canonical root.
    target = root_path.joinpath(*parts)
    try:
        canonical = target.resolve(strict=False)
    except (OSError, ValueError) as exc:
        logging.warning("[path-security] failed to resolve path %s: %s", target, exc)
        raise PathTraversalError(f"invalid path: {exc}") from exc

    # commonpath containment defends against both '..' traversal and symlink hops
    try:
        if os.path.commonpath([str(canonical), str(root_path)]) != str(root_path):
            raise PathTraversalError(f"path {canonical!r} escapes allowed root {root_path!r}")
    except ValueError as exc:
        logging.warning("[path-security] commonpath check failed for %s", target)
        raise PathTraversalError("invalid path combination") from exc

    return str(canonical)


def is_safe_path(root: str | os.PathLike, candidate: str | os.PathLike) -> tuple[bool, str]:
    """Boolean check returning (ok, reason)."""
    try:
        safe_join_path(root, str(candidate))
        return True, "ok"
    except PathTraversalError as exc:
        return False, str(exc)
