# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/utils/qemu_guest_agent.py
# Project:     ProxmoxVEx
# Version:     1.2.453
# Build:       2026.09.14
# Description: QEMU Guest Agent installation helpers.
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-14
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""QEMU Guest Agent installation helpers.

This module maps PVE `ostype` values to the reduced VirtIO ISO variant,
install script, and guest-agent installer paths. It is used by the
`guest-agent-install` API routes and may be used by the ISO build tooling.
"""

import json
import logging
from functools import lru_cache
from pathlib import Path
from typing import Any

from ProxmoxVEx.utils.sanitization import validate_content_filename


def _qemu_iso_dir() -> Path:
    """Return the package directory that holds the ISO sources and outputs."""
    # This file is at .../ProxmoxVEx/utils/qemu_guest_agent.py; the ISOs live
    # in the sibling package under ProxmoxVEx/qemu_iso.
    return Path(__file__).resolve().parents[2] / "qemu_iso"


@lru_cache(maxsize=1)
def _load_ostype_map() -> dict[str, dict[str, Any]]:
    """Load the canonical PVE ostype mapping from the package ISO directory."""
    path = _qemu_iso_dir() / "ostype_map.json"
    with open(path, encoding="utf-8") as fh:
        return json.load(fh)


def list_supported_ostypes() -> list[str]:
    """Return all PVE ostype values that have an install ISO mapping."""
    return sorted(_load_ostype_map().keys())


def get_iso_path(iso_variant: str) -> Path:
    """Return the expected path to a built, stripped ISO for a given variant.

    ``iso_variant`` should be ``legacy`` or ``modern``. The output file is
    produced by ``ProxmoxVEx/qemu_iso/build_iso.py`` at build time.

    If the file is stored as split parts (e.g. ``.iso.gz.00.part``,
    ``.iso.gz.01.part``), they are reassembled into the ``.iso.gz`` on
    first access so the rest of the pipeline sees a single file.
    """
    target = _qemu_iso_dir() / f"virtio-win-{iso_variant}.iso.gz"
    if not target.exists():
        _reassemble_parts(target)
    return target


def _reassemble_parts(target: Path) -> None:
    """Join split .part files into the target .iso.gz if parts exist."""
    import glob

    pattern = str(target) + ".*.part"
    parts = sorted(glob.glob(pattern))
    if not parts:
        return
    logging.info(f"Reassembling {len(parts)} part(s) into {target.name}")
    with open(target, "wb") as out_fh:
        for part in parts:
            with open(part, "rb") as in_fh:
                while True:
                    chunk = in_fh.read(4 * 1024 * 1024)
                    if not chunk:
                        break
                    out_fh.write(chunk)
    logging.info(f"Reassembled {target.name} ({target.stat().st_size} bytes)")


def detect_os_from_pve_config(ostype: str | None) -> dict[str, Any]:
    """Map a PVE ``ostype`` to the installation metadata for this VM.

    Returns a dict that always contains ``supported`` (bool) and
    ``detected_ostype`` (the input value or the string ``unknown``).
    When supported, the returned dict mirrors the matching entry in
    ``ostype_map.json`` with ``supported: True`` added.
    """
    if not ostype:
        return {
            "supported": False,
            "detected_ostype": "unknown",
            "message": "No PVE ostype was found in the VM configuration.",
        }

    ostype = str(ostype).strip()
    mapping = _load_ostype_map()
    info = mapping.get(ostype)
    if not info:
        return {
            "supported": False,
            "detected_ostype": ostype,
            "message": f"PVE ostype '{ostype}' is not supported for automated guest-agent installation.",
        }

    result = dict(info)
    result["supported"] = True
    result["detected_ostype"] = ostype
    result["iso_path"] = str(get_iso_path(result["iso_variant"]))
    return result


def get_iso_source_for_variant(iso_variant: str) -> Path:
    """Return the upstream source ISO path for a build variant.

    This is the gzip-compressed upstream ISO that ``build_iso.py`` consumes.
    """
    sources = {
        "legacy": "virtio-win-0.1.109.iso.gz",
        "modern": "virtio-win-0.1.285.iso.gz",
    }
    if iso_variant not in sources:
        raise ValueError(f"Unknown ISO variant: {iso_variant!r}")
    return _qemu_iso_dir() / sources[iso_variant]


def build_strip_list() -> tuple[set[str], set[str], set[str]]:
    """Return the set of all OS directory names and the sets to keep per variant.

    The returned tuple is ``(all_os_dirs, keep_modern, keep_legacy)``.
    """
    mapping = _load_ostype_map()
    all_os_dirs: set[str] = set()
    keep_modern: set[str] = set()
    keep_legacy: set[str] = set()
    for info in mapping.values():
        for d in info.get("os_dirs", []):
            all_os_dirs.add(d)
        if info.get("iso_variant") == "modern":
            keep_modern.update(info.get("os_dirs", []))
        if info.get("iso_variant") == "legacy":
            keep_legacy.update(info.get("os_dirs", []))
    return all_os_dirs, keep_modern, keep_legacy


def safe_iso_filename(name: str) -> str | None:
    """Return a cleaned-up ISO filename or ``None`` if it is unsafe.

    Uses the existing content-filename validator so the same rules that
    protect the PVE datastore upload path also protect the guest-agent
    install flow.
    """
    candidate = name.strip()
    if not validate_content_filename(candidate):
        logging.warning(f"Rejected unsafe ISO filename: {name!r}")
        return None
    return candidate
