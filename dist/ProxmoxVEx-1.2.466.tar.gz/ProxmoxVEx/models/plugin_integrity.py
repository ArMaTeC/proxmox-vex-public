# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/models/plugin_integrity.py
# Project:     ProxmoxVEx
# Version:     1.2.453
# Build:       2026.09.14
# Description: Plugin integrity and delivery-log table helpers.
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-14
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Plugin integrity and delivery-log table helpers.

Tracks the expected and observed integrity state of downloaded paid plugins
and records every enable, download, update, and tamper event for audit.
"""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Any


def ensure_plugin_integrity_tables(conn) -> None:
    """Create plugin_integrity and plugin_delivery_log tables if missing."""
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS plugin_integrity (
            plugin_id TEXT PRIMARY KEY,
            version TEXT NOT NULL,
            artifact_hash TEXT NOT NULL,
            verified_at TEXT NOT NULL,
            status TEXT NOT NULL DEFAULT 'pending',
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        )
        """
    )
    conn.execute(
        """
        CREATE INDEX IF NOT EXISTS idx_plugin_integrity_status
        ON plugin_integrity(status)
        """
    )
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS plugin_delivery_log (
            event_id TEXT PRIMARY KEY,
            plugin_id TEXT NOT NULL,
            event_type TEXT NOT NULL,
            version TEXT NOT NULL,
            outcome TEXT NOT NULL,
            timestamp TEXT NOT NULL,
            details TEXT DEFAULT '{}'
        )
        """
    )
    conn.execute(
        """
        CREATE INDEX IF NOT EXISTS idx_plugin_delivery_log_plugin
        ON plugin_delivery_log(plugin_id, timestamp)
        """
    )


def get_plugin_integrity(conn, plugin_id: str) -> dict[str, Any] | None:
    """Return the integrity record for a plugin, or None."""
    cur = conn.execute(
        "SELECT plugin_id, version, artifact_hash, verified_at, status "
        "FROM plugin_integrity WHERE plugin_id = ?",
        (plugin_id,),
    )
    row = cur.fetchone()
    if not row:
        return None
    return {
        "plugin_id": row[0],
        "version": row[1],
        "artifact_hash": row[2],
        "verified_at": row[3],
        "status": row[4],
    }


def set_plugin_integrity(
    conn,
    plugin_id: str,
    version: str,
    artifact_hash: str,
    status: str,
) -> None:
    """Insert or replace a plugin integrity record."""
    now = datetime.now(timezone.utc).isoformat()
    conn.execute(
        """
        INSERT INTO plugin_integrity (plugin_id, version, artifact_hash, verified_at, status)
        VALUES (?, ?, ?, ?, ?)
        ON CONFLICT (plugin_id) DO UPDATE SET
            version = excluded.version,
            artifact_hash = excluded.artifact_hash,
            verified_at = excluded.verified_at,
            status = excluded.status
        """,
        (plugin_id, version, artifact_hash, now, status),
    )
    conn.commit()


def add_plugin_delivery_log(
    conn,
    event_id: str,
    plugin_id: str,
    event_type: str,
    version: str,
    outcome: str,
    details: dict[str, Any] | None = None,
) -> None:
    """Record a plugin delivery/integrity event."""
    import json

    now = datetime.now(timezone.utc).isoformat()
    conn.execute(
        """
        INSERT INTO plugin_delivery_log
        (event_id, plugin_id, event_type, version, outcome, timestamp, details)
        VALUES (?, ?, ?, ?, ?, ?, ?)
        """,
        (
            event_id,
            plugin_id,
            event_type,
            version,
            outcome,
            now,
            json.dumps(details or {}),
        ),
    )
    conn.commit()
