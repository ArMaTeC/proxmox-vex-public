# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/models/__init__.py
# Project:     ProxmoxVEx
# Version:     1.2.453
# Build:       2026.09.14
# Description: Package initializer for models
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-14
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
