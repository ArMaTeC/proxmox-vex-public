# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/models/license_log.py
# Project:     ProxmoxVEx
# Version:     1.2.453
# Build:       2026.09.14
# Description: Local audit log for license lifecycle events.
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-14
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Local audit log for license lifecycle events.

Records when a license is checked, installed, upgraded or downgraded so
support staff can see why a node changed tier.  The license key itself is
never persisted in this log; only the tier and reason code are stored.
"""

from datetime import datetime, timezone
from typing import List, Optional


def ensure_license_log_table(conn) -> None:
    """Create the license_log table if it does not yet exist."""
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS license_log (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp TEXT NOT NULL,
            node_id TEXT NOT NULL DEFAULT 'default',
            event TEXT NOT NULL,
            tier_from TEXT,
            tier_to TEXT,
            reason TEXT
        )
        """
    )
    conn.execute(
        "CREATE INDEX IF NOT EXISTS idx_license_log_timestamp ON license_log(timestamp DESC)"
    )


def add_license_log_entry(
    conn,
    event: str,
    tier_from: Optional[str] = None,
    tier_to: Optional[str] = None,
    reason: Optional[str] = None,
    node_id: str = "default",
) -> None:
    """Append a license lifecycle event to the local log."""
    conn.execute(
        """
        INSERT INTO license_log (timestamp, node_id, event, tier_from, tier_to, reason)
        VALUES (?, ?, ?, ?, ?, ?)
        """,
        (datetime.now(timezone.utc).isoformat(), node_id, event, tier_from, tier_to, reason),
    )
    conn.commit()


def get_license_log(conn, node_id: str = "default", limit: int = 50) -> List[dict]:
    """Return recent license log entries, newest first."""
    cur = conn.execute(
        """
        SELECT timestamp, event, tier_from, tier_to, reason
        FROM license_log
        WHERE node_id = ?
        ORDER BY timestamp DESC
        LIMIT ?
        """,
        (node_id, limit),
    )
    rows = []
    for row in cur.fetchall():
        rows.append(
            {
                "timestamp": row[0],
                "event": row[1],
                "tier_from": row[2],
                "tier_to": row[3],
                "reason": row[4],
            }
        )
    return rows
