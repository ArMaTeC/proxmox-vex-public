# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/models/server_access.py
# Project:     ProxmoxVEx
# Version:     1.2.454
# Build:       2026.09.15
# Description: Server Access Groups data model and audit logger.
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-15
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""
Server Access Groups data model and audit logger.
Provides CRUD for groups, memberships, server assignments, and a structured
audit log for administrative actions and authorization failures.
"""

import json
import logging
import uuid
from datetime import datetime, timezone
from typing import Any

from ProxmoxVEx.core.db import get_db

VALID_SERVER_TYPES = {"cluster", "vmware", "pbs"}
VALID_PERMISSION_LEVELS = {"view", "edit", "admin"}


def _table_has_assignments_for_type(conn, server_type: str) -> bool:
    cursor = conn.cursor()
    cursor.execute(
        "SELECT 1 FROM server_access_assignments WHERE server_type = ? LIMIT 1",
        (server_type,),
    )
    return bool(cursor.fetchone())


def has_server_access_assignments(server_type: str) -> bool:
    """Return True if any server access assignments exist for a server type.

    Used as a migration gate: while the table is empty the legacy open access
    model is preserved. As soon as the first assignment is created, the feature
    becomes active and unassigned servers are invisible to non-admins.
    """
    try:
        return _table_has_assignments_for_type(get_db().conn, server_type)
    except Exception as e:
        # Fail CLOSED: a DB error must not masquerade as "feature inactive"
        # (callers would grant legacy open access / 'admin'). Re-raise so
        # rbac wrappers return no access instead of all access.
        logging.error(f"Error checking server access assignments: {e}")
        raise


def ensure_server_access_tables(conn):
    """Create server access tables if they do not exist."""
    cursor = conn.cursor()

    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS server_access_groups (
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            description TEXT,
            created_at TEXT,
            updated_at TEXT
        )
    """
    )
    cursor.execute(
        """
        CREATE INDEX IF NOT EXISTS idx_server_access_groups_name
        ON server_access_groups(name)
    """
    )

    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS server_access_group_members (
            group_id TEXT NOT NULL,
            username TEXT NOT NULL,
            created_at TEXT,
            PRIMARY KEY (group_id, username),
            FOREIGN KEY (group_id) REFERENCES server_access_groups(id) ON DELETE CASCADE
        )
    """
    )
    cursor.execute(
        """
        CREATE INDEX IF NOT EXISTS idx_server_access_members_username
        ON server_access_group_members(username)
    """
    )

    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS server_access_assignments (
            server_type TEXT NOT NULL,
            server_id TEXT NOT NULL,
            group_id TEXT NOT NULL,
            permission_level TEXT NOT NULL,
            created_at TEXT,
            updated_at TEXT,
            PRIMARY KEY (server_type, server_id, group_id),
            FOREIGN KEY (group_id) REFERENCES server_access_groups(id) ON DELETE CASCADE
        )
    """
    )
    cursor.execute(
        """
        CREATE INDEX IF NOT EXISTS idx_server_access_assignments_server
        ON server_access_assignments(server_type, server_id)
    """
    )

    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS server_access_audit_log (
            id TEXT PRIMARY KEY,
            timestamp TEXT NOT NULL,
            actor TEXT,
            action TEXT NOT NULL,
            target_type TEXT,
            target_id TEXT,
            details TEXT,
            created_at TEXT
        )
    """
    )
    cursor.execute(
        """
        CREATE INDEX IF NOT EXISTS idx_server_access_audit_timestamp
        ON server_access_audit_log(timestamp DESC)
    """
    )
    cursor.execute(
        """
        CREATE INDEX IF NOT EXISTS idx_server_access_audit_actor
        ON server_access_audit_log(actor)
    """
    )
    cursor.execute(
        """
        CREATE INDEX IF NOT EXISTS idx_server_access_audit_action
        ON server_access_audit_log(action)
    """
    )

    logging.info("Server access tables ensured")


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _validate_server_type(server_type: str) -> None:
    if server_type not in VALID_SERVER_TYPES:
        raise ValueError(f"Invalid server_type: {server_type!r}")


def _validate_permission_level(level: str) -> None:
    if level not in VALID_PERMISSION_LEVELS:
        raise ValueError(f"Invalid permission level: {level!r}")


# ---------------------------------------------------------------------------
# Group CRUD
# ---------------------------------------------------------------------------


def save_group(data: dict) -> str:
    """Create or update a server access group."""
    db = get_db()
    cursor = db.conn.cursor()
    group_id = data.get("id") or str(uuid.uuid4())
    now = _now()
    name = data.get("name", "").strip()
    description = data.get("description", "")

    cursor.execute(
        """
        INSERT INTO server_access_groups (id, name, description, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?)
        ON CONFLICT(id) DO UPDATE SET
            name = excluded.name,
            description = excluded.description,
            updated_at = excluded.updated_at
    """,
        (group_id, name, description, now, now),
    )
    db.conn.commit()
    return group_id


def get_group(group_id: str) -> dict | None:
    db = get_db()
    cursor = db.conn.cursor()
    cursor.execute("SELECT * FROM server_access_groups WHERE id = ?", (group_id,))
    row = cursor.fetchone()
    return _group_row_to_dict(row) if row else None


def delete_group(group_id: str) -> bool:
    db = get_db()
    cursor = db.conn.cursor()
    cursor.execute("DELETE FROM server_access_groups WHERE id = ?", (group_id,))
    db.conn.commit()
    return cursor.rowcount > 0


def list_groups() -> list[dict]:
    db = get_db()
    cursor = db.conn.cursor()
    cursor.execute("SELECT * FROM server_access_groups ORDER BY name")
    return [_group_row_to_dict(row) for row in cursor.fetchall()]


# ---------------------------------------------------------------------------
# Membership CRUD
# ---------------------------------------------------------------------------


def add_member(group_id: str, username: str) -> None:
    db = get_db()
    cursor = db.conn.cursor()
    cursor.execute(
        """
        INSERT INTO server_access_group_members (group_id, username, created_at)
        VALUES (?, ?, ?)
        ON CONFLICT(group_id, username) DO NOTHING
    """,
        (group_id, username, _now()),
    )
    db.conn.commit()


def remove_member(group_id: str, username: str) -> bool:
    db = get_db()
    cursor = db.conn.cursor()
    cursor.execute(
        """
        DELETE FROM server_access_group_members WHERE group_id = ? AND username = ?
    """,
        (group_id, username),
    )
    db.conn.commit()
    return cursor.rowcount > 0


def list_members(group_id: str) -> list[str]:
    db = get_db()
    cursor = db.conn.cursor()
    cursor.execute(
        """
        SELECT username FROM server_access_group_members WHERE group_id = ? ORDER BY username
    """,
        (group_id,),
    )
    return [row["username"] for row in cursor.fetchall()]


def list_user_groups(username: str) -> list[str]:
    db = get_db()
    cursor = db.conn.cursor()
    cursor.execute(
        """
        SELECT group_id FROM server_access_group_members WHERE username = ?
    """,
        (username,),
    )
    return [row["group_id"] for row in cursor.fetchall()]


# ---------------------------------------------------------------------------
# Assignment CRUD
# ---------------------------------------------------------------------------


def set_assignment(server_type: str, server_id: str, group_id: str, permission_level: str) -> None:
    _validate_server_type(server_type)
    _validate_permission_level(permission_level)
    db = get_db()
    cursor = db.conn.cursor()
    now = _now()
    cursor.execute(
        """
        INSERT INTO server_access_assignments
        (server_type, server_id, group_id, permission_level, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, ?)
        ON CONFLICT(server_type, server_id, group_id) DO UPDATE SET
            permission_level = excluded.permission_level,
            updated_at = excluded.updated_at
    """,
        (server_type, server_id, group_id, permission_level, now, now),
    )
    db.conn.commit()


def remove_assignment(server_type: str, server_id: str, group_id: str) -> bool:
    _validate_server_type(server_type)
    db = get_db()
    cursor = db.conn.cursor()
    cursor.execute(
        """
        DELETE FROM server_access_assignments
        WHERE server_type = ? AND server_id = ? AND group_id = ?
    """,
        (server_type, server_id, group_id),
    )
    db.conn.commit()
    return cursor.rowcount > 0


def get_server_assignments(server_type: str, server_id: str) -> list[dict]:
    _validate_server_type(server_type)
    db = get_db()
    cursor = db.conn.cursor()
    cursor.execute(
        """
        SELECT a.*, g.name as group_name
        FROM server_access_assignments a
        JOIN server_access_groups g ON a.group_id = g.id
        WHERE a.server_type = ? AND a.server_id = ?
    """,
        (server_type, server_id),
    )
    return [
        {
            "server_type": row["server_type"],
            "server_id": row["server_id"],
            "group_id": row["group_id"],
            "group_name": row["group_name"],
            "permission_level": row["permission_level"],
            "created_at": row["created_at"],
            "updated_at": row["updated_at"],
        }
        for row in cursor.fetchall()
    ]


def get_group_assignments(group_id: str) -> list[dict]:
    db = get_db()
    cursor = db.conn.cursor()
    cursor.execute(
        """
        SELECT * FROM server_access_assignments WHERE group_id = ?
    """,
        (group_id,),
    )
    return [_assignment_row_to_dict(row) for row in cursor.fetchall()]


# ---------------------------------------------------------------------------
# Effective permission resolution
# ---------------------------------------------------------------------------


def get_user_server_permission(username: str, server_type: str, server_id: str) -> str | None:
    """Return the highest permission level for a user on a server, or None.

    If the server type has no assignments at all, returns 'admin' as a
    migration-safe default (the feature is not active for this type yet).
    """
    _validate_server_type(server_type)
    db = get_db()
    if not _table_has_assignments_for_type(db.conn, server_type):
        return "admin"
    cursor = db.conn.cursor()
    cursor.execute(
        """
        SELECT a.permission_level
        FROM server_access_assignments a
        JOIN server_access_group_members m ON a.group_id = m.group_id
        WHERE a.server_type = ? AND a.server_id = ? AND m.username = ?
    """,
        (server_type, server_id, username),
    )
    levels = [row["permission_level"] for row in cursor.fetchall()]
    if not levels:
        return None
    order = {"view": 0, "edit": 1, "admin": 2}
    return max(levels, key=lambda lvl: order.get(lvl, -1))


def filter_servers_for_user(username: str, server_type: str, server_ids: list[str]) -> set[str]:
    """Return the subset of server_ids the user may see for a server type.

    Fail-closed: an error returns an empty set so the user sees nothing.
    While the server type has no assignments at all, all provided IDs are
    allowed to preserve legacy access until the feature is activated.
    """
    _validate_server_type(server_type)
    if not server_ids:
        return set()
    db = get_db()
    if not _table_has_assignments_for_type(db.conn, server_type):
        return set(server_ids)
    cursor = db.conn.cursor()
    placeholders = ",".join(["?"] * len(server_ids))
    query = f"""
        SELECT DISTINCT a.server_id
        FROM server_access_assignments a
        JOIN server_access_group_members m ON a.group_id = m.group_id
        WHERE a.server_type = ? AND a.server_id IN ({placeholders}) AND m.username = ?
    """  # nosec: B608 - placeholders are only '?'
    cursor.execute(query, (server_type, *server_ids, username))
    return {row["server_id"] for row in cursor.fetchall()}


def get_user_servers(username: str, server_type: str) -> list[str] | None:
    """Return all server_ids of a given type accessible to the user."""
    _validate_server_type(server_type)
    db = get_db()
    cursor = db.conn.cursor()
    cursor.execute(
        """
        SELECT DISTINCT a.server_id
        FROM server_access_assignments a
        JOIN server_access_group_members m ON a.group_id = m.group_id
        WHERE a.server_type = ? AND m.username = ?
    """,
        (server_type, username),
    )
    rows = cursor.fetchall()
    return [row["server_id"] for row in rows] if rows else []


# ---------------------------------------------------------------------------
# Audit log
# ---------------------------------------------------------------------------


def log_server_access_event(
    actor: str, action: str, target_type: str, target_id: str, details: dict | None = None
) -> str:
    """Append an audit record and return its id."""
    db = get_db()
    cursor = db.conn.cursor()
    now = _now()
    event_id = str(uuid.uuid4())
    details_json = json.dumps(details or {})
    cursor.execute(
        """
        INSERT INTO server_access_audit_log
        (id, timestamp, actor, action, target_type, target_id, details, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    """,
        (event_id, now, actor or "system", action, target_type, target_id, details_json, now),
    )
    db.conn.commit()
    return event_id


def list_audit_events(
    actor: str | None = None,
    action: str | None = None,
    target_type: str | None = None,
    target_id: str | None = None,
    limit: int = 100,
    offset: int = 0,
) -> list[dict]:
    db = get_db()
    cursor = db.conn.cursor()
    conditions = []
    params: list[Any] = []
    if actor:
        conditions.append("actor = ?")
        params.append(actor)
    if action:
        conditions.append("action = ?")
        params.append(action)
    if target_type:
        conditions.append("target_type = ?")
        params.append(target_type)
    if target_id:
        conditions.append("target_id = ?")
        params.append(target_id)

    where = "WHERE " + " AND ".join(conditions) if conditions else ""
    query = f"""
        SELECT * FROM server_access_audit_log
        {where}
        ORDER BY timestamp DESC
        LIMIT ? OFFSET ?
    """  # nosec: B608 - where clauses built from hardcoded columns with ? placeholders
    cursor.execute(query, (*params, limit, offset))
    return [_audit_row_to_dict(row) for row in cursor.fetchall()]


# ---------------------------------------------------------------------------
# Internal row helpers
# ---------------------------------------------------------------------------


def _group_row_to_dict(row) -> dict:
    return {
        "id": row["id"],
        "name": row["name"],
        "description": row["description"],
        "created_at": row["created_at"],
        "updated_at": row["updated_at"],
    }


def _assignment_row_to_dict(row) -> dict:
    return {
        "server_type": row["server_type"],
        "server_id": row["server_id"],
        "group_id": row["group_id"],
        "permission_level": row["permission_level"],
        "created_at": row["created_at"],
        "updated_at": row["updated_at"],
    }


def _audit_row_to_dict(row) -> dict:
    details = row["details"]
    try:
        details = json.loads(details) if details else {}
    except json.JSONDecodeError:
        details = {}
    return {
        "id": row["id"],
        "timestamp": row["timestamp"],
        "actor": row["actor"],
        "action": row["action"],
        "target_type": row["target_type"],
        "target_id": row["target_id"],
        "details": details,
        "created_at": row["created_at"],
    }
