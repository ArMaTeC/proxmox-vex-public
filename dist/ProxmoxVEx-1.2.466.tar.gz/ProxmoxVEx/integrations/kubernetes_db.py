# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/integrations/kubernetes_db.py
# Project:     ProxmoxVEx
# Version:     1.2.453
# Build:       2026.09.14
# Description: Kubernetes integration database helpers.
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-14
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Kubernetes integration database helpers.

Provides idempotent schema creation and CRUD helpers for Kubernetes cluster
configuration, cached resource metadata, node-to-VM mappings, role mappings,
alert channels, policy adapters, templates and workflows.
"""

from __future__ import annotations

import contextlib
import hashlib
import json
import logging
import uuid
from datetime import datetime, timezone
from typing import Any

from ProxmoxVEx.core.db import get_db

_logger = logging.getLogger(__name__)

SUPPORTED_AUTH_TYPES = ("kubeconfig", "token", "certificate")
SUPPORTED_STATUSES = ("pending", "reachable", "degraded", "unreachable")
SUPPORTED_ENGINES = ("kyverno", "opa", "none")
SUPPORTED_VM_TYPES = ("qemu", "lxc")
SUPPORTED_STRATEGIES = ("manual", "hostname", "label")


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def ensure_kubernetes_tables(conn) -> None:
    """Create all Kubernetes-related tables and indexes (idempotent)."""
    cursor = conn.cursor()

    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS k8s_clusters (
            id TEXT PRIMARY KEY,
            cluster_id TEXT NOT NULL,
            name TEXT NOT NULL,
            api_url TEXT NOT NULL,
            auth_type TEXT NOT NULL,
            auth_blob TEXT NOT NULL,
            auth_blob_hash TEXT NOT NULL,
            namespace_default TEXT NOT NULL DEFAULT 'default',
            verify_ssl INTEGER NOT NULL DEFAULT 1,
            enabled INTEGER NOT NULL DEFAULT 1,
            status TEXT NOT NULL DEFAULT 'pending',
            last_health_check TEXT,
            health_message TEXT,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            UNIQUE(cluster_id, api_url)
        )
        """
    )
    # Migration: older installations may not have the enabled flag on k8s_clusters.
    cursor.execute(
        "ALTER TABLE k8s_clusters ADD COLUMN IF NOT EXISTS enabled INTEGER NOT NULL DEFAULT 1"
    )
    cursor.execute(
        "CREATE INDEX IF NOT EXISTS idx_k8s_clusters_cluster_id ON k8s_clusters(cluster_id)"
    )

    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS k8s_resource_cache (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            k8s_cluster_id TEXT NOT NULL,
            kind TEXT NOT NULL,
            namespace TEXT,
            name TEXT NOT NULL,
            uid TEXT NOT NULL,
            labels TEXT DEFAULT '{}',
            annotations TEXT DEFAULT '{}',
            status TEXT DEFAULT '{}',
            cached_at TEXT NOT NULL,
            UNIQUE(k8s_cluster_id, kind, namespace, name)
        )
        """
    )
    cursor.execute(
        "CREATE INDEX IF NOT EXISTS idx_k8s_resource_cache_cluster ON k8s_resource_cache(k8s_cluster_id, kind, namespace)"
    )
    cursor.execute(
        "CREATE INDEX IF NOT EXISTS idx_k8s_resource_cache_cached_at ON k8s_resource_cache(cached_at)"
    )

    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS k8s_node_vm_map (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            k8s_cluster_id TEXT NOT NULL,
            node_name TEXT NOT NULL,
            proxmox_node TEXT,
            proxmox_vmid INTEGER,
            vm_type TEXT,
            matching_strategy TEXT NOT NULL,
            UNIQUE(k8s_cluster_id, node_name)
        )
        """
    )

    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS k8s_role_mappings (
            id TEXT PRIMARY KEY,
            k8s_cluster_id TEXT NOT NULL,
            proxmox_role TEXT NOT NULL,
            k8s_role TEXT NOT NULL,
            k8s_namespace TEXT,
            enabled INTEGER NOT NULL DEFAULT 1,
            UNIQUE(k8s_cluster_id, proxmox_role)
        )
        """
    )

    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS k8s_alert_channels (
            id TEXT PRIMARY KEY,
            k8s_cluster_id TEXT NOT NULL UNIQUE,
            enabled INTEGER NOT NULL DEFAULT 0,
            webhook_url TEXT,
            events TEXT NOT NULL DEFAULT '[]',
            include_resource_labels INTEGER NOT NULL DEFAULT 0
        )
        """
    )

    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS k8s_policy_adapters (
            id TEXT PRIMARY KEY,
            k8s_cluster_id TEXT NOT NULL UNIQUE,
            enabled INTEGER NOT NULL DEFAULT 0,
            engine TEXT NOT NULL DEFAULT 'none',
            policies TEXT NOT NULL DEFAULT '[]',
            violation_count INTEGER NOT NULL DEFAULT 0
        )
        """
    )

    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS k8s_templates (
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            description TEXT,
            tags TEXT DEFAULT '[]',
            default_namespace TEXT NOT NULL DEFAULT 'default',
            parameter_schema TEXT NOT NULL DEFAULT '{}',
            manifest_template TEXT NOT NULL,
            builtin INTEGER NOT NULL DEFAULT 0
        )
        """
    )

    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS k8s_workflows (
            id TEXT PRIMARY KEY,
            k8s_cluster_id TEXT NOT NULL,
            name TEXT NOT NULL,
            enabled INTEGER NOT NULL DEFAULT 0,
            schedule TEXT NOT NULL,
            steps TEXT NOT NULL,
            last_run_status TEXT,
            last_run_at TEXT,
            task_id TEXT,
            UNIQUE(k8s_cluster_id, name)
        )
        """
    )

    # Seed a small curated template library if the table is empty.
    cursor.execute("SELECT COUNT(*) FROM k8s_templates")
    if cursor.fetchone()[0] == 0:
        _seed_builtin_templates(cursor)

    conn.commit()
    _logger.info("Kubernetes tables ensured")


def _seed_builtin_templates(cursor) -> None:
    """Insert a minimal set of curated templates on first schema creation."""
    templates: list[tuple[str, ...]] = [
        (
            "nginx-deployment",
            "NGINX Deployment",
            "Basic NGINX Deployment",
            '["web","deployment"]',
            "default",
            '{"type":"object","properties":{"appName":{"type":"string","default":"nginx"},"replicas":{"type":"integer","default":1},"image":{"type":"string","default":"nginx:1.27"}},"required":["appName","replicas","image"]}',
            'apiVersion: apps/v1\nkind: Deployment\nmetadata:\n  name: {appName}\n  namespace: {namespace}\nspec:\n  replicas: {replicas}\n  selector:\n    matchLabels:\n      app: {appName}\n  template:\n    metadata:\n      labels:\n        app: {appName}\n    spec:\n      containers:\n      - name: nginx\n        image: {image}\n        ports:\n        - containerPort: 80',
        ),
        (
            "redis-statefulset",
            "Redis StatefulSet",
            "Redis StatefulSet with persistent storage",
            '["database","statefulset"]',
            "default",
            '{"type":"object","properties":{"appName":{"type":"string","default":"redis"},"replicas":{"type":"integer","default":3},"image":{"type":"string","default":"redis:7.2"}},"required":["appName","replicas","image"]}',
            'apiVersion: apps/v1\nkind: StatefulSet\nmetadata:\n  name: {appName}\n  namespace: {namespace}\nspec:\n  serviceName: {appName}\n  replicas: {replicas}\n  selector:\n    matchLabels:\n      app: {appName}\n  template:\n    metadata:\n      labels:\n        app: {appName}\n    spec:\n      containers:\n      - name: redis\n        image: {image}\n        ports:\n        - containerPort: 6379',
        ),
    ]
    cursor.executemany(
        """
        INSERT OR IGNORE INTO k8s_templates (id, name, description, tags, default_namespace, parameter_schema, manifest_template, builtin)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """,
        [(t[0], t[1], t[2], t[3], t[4], t[5], t[6], 1) for t in templates],
    )


# ---------------------------------------------------------------------------
# k8s_clusters
# ---------------------------------------------------------------------------


def _hash_auth_blob(plaintext: str) -> str:
    """Return a non-reversible hash used for duplicate detection."""
    return hashlib.sha256(plaintext.encode("utf-8")).hexdigest()


def get_k8s_cluster(cluster_id: str) -> dict[str, Any] | None:
    """Load a single Kubernetes cluster configuration by Proxmox cluster id.

    Returns the decrypted record or None.  The auth_blob is returned encrypted;
    callers must explicitly decrypt it when needed.
    """
    db = get_db()
    row = db.query_one(
        "SELECT * FROM k8s_clusters WHERE cluster_id = ? ORDER BY updated_at DESC LIMIT 1",
        (cluster_id,),
    )
    return _row_to_cluster(row) if row else None


def _row_to_cluster(row) -> dict[str, Any] | None:
    if not row:
        return None
    return {
        "id": row["id"],
        "cluster_id": row["cluster_id"],
        "name": row["name"],
        "api_url": row["api_url"],
        "auth_type": row["auth_type"],
        "auth_blob": row["auth_blob"],
        "auth_blob_hash": row["auth_blob_hash"],
        "namespace_default": row["namespace_default"],
        "verify_ssl": bool(row["verify_ssl"]),
        "enabled": bool(row["enabled"]),
        "status": row["status"],
        "last_health_check": row["last_health_check"],
        "health_message": row["health_message"],
        "created_at": row["created_at"],
        "updated_at": row["updated_at"],
    }


def save_k8s_cluster(cluster_id: str, data: dict[str, Any]) -> str:
    """Create or update the Kubernetes connector for a Proxmox cluster.

    `data` must contain plaintext auth material under `auth_blob_plaintext`.
    It is encrypted before persistence and a hash is stored alongside it.
    """
    db = get_db()
    plaintext = data["auth_blob_plaintext"]
    encrypted = db._encrypt(plaintext)
    blob_hash = _hash_auth_blob(plaintext)

    existing = get_k8s_cluster(cluster_id)
    now = _now()
    if existing:
        k8s_id = existing["id"]
        db.execute(
            """
            UPDATE k8s_clusters SET
                name = ?, api_url = ?, auth_type = ?, auth_blob = ?, auth_blob_hash = ?,
                namespace_default = ?, verify_ssl = ?, enabled = ?, status = ?, updated_at = ?
            WHERE id = ?
            """,
            (
                data.get("name", cluster_id),
                data["api_url"],
                data["auth_type"],
                encrypted,
                blob_hash,
                data.get("namespace_default", "default"),
                1 if data.get("verify_ssl", True) else 0,
                1 if data.get("enabled", True) else 0,
                data.get("status", "pending"),
                now,
                k8s_id,
            ),
        )
        return k8s_id

    k8s_id = data.get("id") or str(uuid.uuid4())
    db.execute(
        """
        INSERT INTO k8s_clusters
        (id, cluster_id, name, api_url, auth_type, auth_blob, auth_blob_hash,
         namespace_default, verify_ssl, enabled, status, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (
            k8s_id,
            cluster_id,
            data.get("name", cluster_id),
            data["api_url"],
            data["auth_type"],
            encrypted,
            blob_hash,
            data.get("namespace_default", "default"),
            1 if data.get("verify_ssl", True) else 0,
            1 if data.get("enabled", True) else 0,
            data.get("status", "pending"),
            now,
            now,
        ),
    )
    return k8s_id


def update_k8s_cluster_status(cluster_id: str, status: str, message: str = "") -> None:
    """Update the status and health message for a Kubernetes cluster."""
    if status not in SUPPORTED_STATUSES:
        raise ValueError(f"Unsupported status: {status}")
    db = get_db()
    now = _now()
    params: tuple[Any, ...] = (status, message, now, cluster_id)
    last_health = ""
    if status in ("reachable", "degraded"):
        last_health = now
        params = (status, message, last_health, now, cluster_id)
        db.execute(
            """
            UPDATE k8s_clusters SET status = ?, health_message = ?, last_health_check = ?, updated_at = ?
            WHERE cluster_id = ?
            """,
            params,
        )
    else:
        db.execute(
            """
            UPDATE k8s_clusters SET status = ?, health_message = ?, updated_at = ?
            WHERE cluster_id = ?
            """,
            params,
        )


def delete_k8s_cluster(cluster_id: str) -> None:
    db = get_db()
    row = db.query_one("SELECT id FROM k8s_clusters WHERE cluster_id = ?", (cluster_id,))
    if not row:
        return
    k8s_id = row["id"]
    with contextlib.suppress(Exception):
        db.execute("DELETE FROM k8s_workflows WHERE k8s_cluster_id = ?", (k8s_id,))
    with contextlib.suppress(Exception):
        db.execute("DELETE FROM k8s_role_mappings WHERE k8s_cluster_id = ?", (k8s_id,))
    with contextlib.suppress(Exception):
        db.execute("DELETE FROM k8s_alert_channels WHERE k8s_cluster_id = ?", (k8s_id,))
    with contextlib.suppress(Exception):
        db.execute("DELETE FROM k8s_policy_adapters WHERE k8s_cluster_id = ?", (k8s_id,))
    with contextlib.suppress(Exception):
        db.execute("DELETE FROM k8s_node_vm_map WHERE k8s_cluster_id = ?", (k8s_id,))
    with contextlib.suppress(Exception):
        db.execute("DELETE FROM k8s_resource_cache WHERE k8s_cluster_id = ?", (k8s_id,))
    db.execute("DELETE FROM k8s_clusters WHERE id = ?", (k8s_id,))


def decrypt_auth_blob(cluster_id: str) -> str:
    """Decrypt the authentication blob for an in-memory connection only."""
    db = get_db()
    row = db.query_one("SELECT auth_blob FROM k8s_clusters WHERE cluster_id = ?", (cluster_id,))
    if not row:
        raise ValueError("Kubernetes connector not configured for this cluster")
    return db._decrypt(row["auth_blob"])


# ---------------------------------------------------------------------------
# k8s_resource_cache
# ---------------------------------------------------------------------------


def prune_k8s_resource_cache(k8s_cluster_id: str, max_age_seconds: int = 300) -> None:
    """Remove cached resource rows older than the configured TTL."""
    db = get_db()
    cutoff = datetime.now(timezone.utc).isoformat()
    db.execute(
        "DELETE FROM k8s_resource_cache WHERE k8s_cluster_id = ? AND cached_at < ?",
        (k8s_cluster_id, cutoff),
    )


def upsert_k8s_resource(k8s_cluster_id: str, kind: str, namespace: str | None, name: str, data: dict[str, Any]) -> None:
    uid = data.get("uid", "")
    labels = json.dumps(data.get("labels", {}), default=str)
    annotations = json.dumps(data.get("annotations", {}), default=str)
    status = json.dumps(data.get("status", {}), default=str)
    now = _now()
    db = get_db()
    db.execute(
        """
        INSERT INTO k8s_resource_cache
        (k8s_cluster_id, kind, namespace, name, uid, labels, annotations, status, cached_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        ON CONFLICT(k8s_cluster_id, kind, namespace, name) DO UPDATE SET
            uid = excluded.uid,
            labels = excluded.labels,
            annotations = excluded.annotations,
            status = excluded.status,
            cached_at = excluded.cached_at
        """,
        (k8s_cluster_id, kind, namespace, name, uid, labels, annotations, status, now),
    )


def list_k8s_resource_cache(k8s_cluster_id: str, kind: str | None = None, namespace: str | None = None) -> list[dict[str, Any]]:
    db = get_db()
    query = "SELECT * FROM k8s_resource_cache WHERE k8s_cluster_id = ?"
    params: list[Any] = [k8s_cluster_id]
    if kind:
        query += " AND kind = ?"
        params.append(kind)
    if namespace is not None:
        query += " AND namespace = ?"
        params.append(namespace)
    query += " ORDER BY kind, namespace, name"
    rows = db.query(query, tuple(params))
    return [_row_to_resource(r) for r in rows]


def _row_to_resource(row) -> dict[str, Any]:
    return {
        "id": row["id"],
        "k8s_cluster_id": row["k8s_cluster_id"],
        "kind": row["kind"],
        "namespace": row["namespace"],
        "name": row["name"],
        "uid": row["uid"],
        "labels": json.loads(row["labels"] or "{}"),
        "annotations": json.loads(row["annotations"] or "{}"),
        "status": json.loads(row["status"] or "{}"),
        "cached_at": row["cached_at"],
    }


# ---------------------------------------------------------------------------
# node-vm map
# ---------------------------------------------------------------------------


def get_k8s_node_vm_map(k8s_cluster_id: str, node_name: str | None = None) -> list[dict[str, Any]]:
    db = get_db()
    query = "SELECT * FROM k8s_node_vm_map WHERE k8s_cluster_id = ?"
    params: tuple[Any, ...] = (k8s_cluster_id,)
    if node_name:
        query += " AND node_name = ?"
        params = (k8s_cluster_id, node_name)
    rows = db.query(query, params)
    return [_row_to_node_map(r) for r in rows]


def _row_to_node_map(row) -> dict[str, Any]:
    return {
        "id": row["id"],
        "k8s_cluster_id": row["k8s_cluster_id"],
        "node_name": row["node_name"],
        "proxmox_node": row["proxmox_node"],
        "proxmox_vmid": row["proxmox_vmid"],
        "vm_type": row["vm_type"],
        "matching_strategy": row["matching_strategy"],
    }


def upsert_k8s_node_vm_map(k8s_cluster_id: str, node_name: str, data: dict[str, Any]) -> None:
    db = get_db()
    existing = db.query_one(
        "SELECT id FROM k8s_node_vm_map WHERE k8s_cluster_id = ? AND node_name = ?",
        (k8s_cluster_id, node_name),
    )
    if existing:
        db.execute(
            """
            UPDATE k8s_node_vm_map SET
                proxmox_node = ?, proxmox_vmid = ?, vm_type = ?, matching_strategy = ?
            WHERE id = ?
            """,
            (
                data.get("proxmox_node"),
                data.get("proxmox_vmid"),
                data.get("vm_type"),
                data.get("matching_strategy", "manual"),
                existing["id"],
            ),
        )
    else:
        db.execute(
            """
            INSERT INTO k8s_node_vm_map
            (k8s_cluster_id, node_name, proxmox_node, proxmox_vmid, vm_type, matching_strategy)
            VALUES (?, ?, ?, ?, ?, ?)
            """,
            (
                k8s_cluster_id,
                node_name,
                data.get("proxmox_node"),
                data.get("proxmox_vmid"),
                data.get("vm_type"),
                data.get("matching_strategy", "manual"),
            ),
        )


def delete_k8s_node_vm_map(k8s_cluster_id: str, node_name: str) -> None:
    db = get_db()
    db.execute(
        "DELETE FROM k8s_node_vm_map WHERE k8s_cluster_id = ? AND node_name = ?",
        (k8s_cluster_id, node_name),
    )


# ---------------------------------------------------------------------------
# role mappings
# ---------------------------------------------------------------------------


def list_k8s_role_mappings(k8s_cluster_id: str) -> list[dict[str, Any]]:
    db = get_db()
    rows = db.query(
        "SELECT * FROM k8s_role_mappings WHERE k8s_cluster_id = ? ORDER BY proxmox_role",
        (k8s_cluster_id,),
    )
    return [_row_to_role(r) for r in rows]


def _row_to_role(row) -> dict[str, Any]:
    return {
        "id": row["id"],
        "k8s_cluster_id": row["k8s_cluster_id"],
        "proxmox_role": row["proxmox_role"],
        "k8s_role": row["k8s_role"],
        "k8s_namespace": row["k8s_namespace"],
        "enabled": bool(row["enabled"]),
    }


def replace_k8s_role_mappings(k8s_cluster_id: str, roles: list[dict[str, Any]]) -> None:
    db = get_db()
    db.execute("DELETE FROM k8s_role_mappings WHERE k8s_cluster_id = ?", (k8s_cluster_id,))
    for r in roles:
        rid = r.get("id") or str(uuid.uuid4())
        db.execute(
            """
            INSERT INTO k8s_role_mappings (id, k8s_cluster_id, proxmox_role, k8s_role, k8s_namespace, enabled)
            VALUES (?, ?, ?, ?, ?, ?)
            """,
            (
                rid,
                k8s_cluster_id,
                r["proxmox_role"],
                r["k8s_role"],
                r.get("k8s_namespace"),
                1 if r.get("enabled", True) else 0,
            ),
        )


# ---------------------------------------------------------------------------
# alert channels
# ---------------------------------------------------------------------------


def get_k8s_alert_channel(k8s_cluster_id: str) -> dict[str, Any] | None:
    db = get_db()
    row = db.query_one("SELECT * FROM k8s_alert_channels WHERE k8s_cluster_id = ?", (k8s_cluster_id,))
    return _row_to_alert(row) if row else None


def _row_to_alert(row) -> dict[str, Any] | None:
    if not row:
        return None
    return {
        "id": row["id"],
        "k8s_cluster_id": row["k8s_cluster_id"],
        "enabled": bool(row["enabled"]),
        "webhook_url": row["webhook_url"],
        "events": json.loads(row["events"] or "[]"),
        "include_resource_labels": bool(row["include_resource_labels"]),
    }


def save_k8s_alert_channel(k8s_cluster_id: str, data: dict[str, Any]) -> None:
    db = get_db()
    existing = db.query_one("SELECT id FROM k8s_alert_channels WHERE k8s_cluster_id = ?", (k8s_cluster_id,))
    events = json.dumps(list(set(data.get("events", []))))
    if existing:
        db.execute(
            """
            UPDATE k8s_alert_channels SET
                enabled = ?, webhook_url = ?, events = ?, include_resource_labels = ?
            WHERE id = ?
            """,
            (
                1 if data.get("enabled", False) else 0,
                data.get("webhook_url", ""),
                events,
                1 if data.get("include_resource_labels", False) else 0,
                existing["id"],
            ),
        )
    else:
        rid = data.get("id") or str(uuid.uuid4())
        db.execute(
            """
            INSERT INTO k8s_alert_channels (id, k8s_cluster_id, enabled, webhook_url, events, include_resource_labels)
            VALUES (?, ?, ?, ?, ?, ?)
            """,
            (
                rid,
                k8s_cluster_id,
                1 if data.get("enabled", False) else 0,
                data.get("webhook_url", ""),
                events,
                1 if data.get("include_resource_labels", False) else 0,
            ),
        )


# ---------------------------------------------------------------------------
# policy adapters
# ---------------------------------------------------------------------------


def get_k8s_policy_adapter(k8s_cluster_id: str) -> dict[str, Any] | None:
    db = get_db()
    row = db.query_one("SELECT * FROM k8s_policy_adapters WHERE k8s_cluster_id = ?", (k8s_cluster_id,))
    return _row_to_policy(row) if row else None


def _row_to_policy(row) -> dict[str, Any] | None:
    if not row:
        return None
    return {
        "id": row["id"],
        "k8s_cluster_id": row["k8s_cluster_id"],
        "enabled": bool(row["enabled"]),
        "engine": row["engine"],
        "policies": json.loads(row["policies"] or "[]"),
        "violation_count": row["violation_count"],
    }


def save_k8s_policy_adapter(k8s_cluster_id: str, data: dict[str, Any]) -> None:
    db = get_db()
    existing = db.query_one("SELECT id FROM k8s_policy_adapters WHERE k8s_cluster_id = ?", (k8s_cluster_id,))
    policies = json.dumps(list(data.get("policies", [])))
    engine = data.get("engine", "none")
    if engine not in SUPPORTED_ENGINES:
        raise ValueError(f"Unsupported policy engine: {engine}")
    if existing:
        db.execute(
            """
            UPDATE k8s_policy_adapters SET
                enabled = ?, engine = ?, policies = ?, violation_count = ?
            WHERE id = ?
            """,
            (
                1 if data.get("enabled", False) else 0,
                engine,
                policies,
                int(data.get("violation_count", 0)),
                existing["id"],
            ),
        )
    else:
        rid = data.get("id") or str(uuid.uuid4())
        db.execute(
            """
            INSERT INTO k8s_policy_adapters (id, k8s_cluster_id, enabled, engine, policies, violation_count)
            VALUES (?, ?, ?, ?, ?, ?)
            """,
            (
                rid,
                k8s_cluster_id,
                1 if data.get("enabled", False) else 0,
                engine,
                policies,
                int(data.get("violation_count", 0)),
            ),
        )


# ---------------------------------------------------------------------------
# templates
# ---------------------------------------------------------------------------


def list_k8s_templates(builtin_only: bool | None = None) -> list[dict[str, Any]]:
    db = get_db()
    query = "SELECT * FROM k8s_templates"
    params: tuple[Any, ...] = ()
    if builtin_only is not None:
        query += " WHERE builtin = ?"
        params = (1 if builtin_only else 0,)
    query += " ORDER BY name"
    rows = db.query(query, params)
    return [_row_to_template(r) for r in rows]


def get_k8s_template(template_id: str) -> dict[str, Any] | None:
    db = get_db()
    row = db.query_one("SELECT * FROM k8s_templates WHERE id = ?", (template_id,))
    return _row_to_template(row) if row else None


def _row_to_template(row) -> dict[str, Any]:
    return {
        "id": row["id"],
        "name": row["name"],
        "description": row["description"],
        "tags": json.loads(row["tags"] or "[]"),
        "default_namespace": row["default_namespace"],
        "parameter_schema": json.loads(row["parameter_schema"] or "{}"),
        "manifest_template": row["manifest_template"],
        "builtin": bool(row["builtin"]),
    }


def save_k8s_template(data: dict[str, Any]) -> str:
    db = get_db()
    rid = data.get("id") or str(uuid.uuid4())
    existing = db.query_one("SELECT id FROM k8s_templates WHERE id = ?", (rid,))
    tags = json.dumps(list(data.get("tags", [])))
    schema = json.dumps(data.get("parameter_schema", {}))
    if existing:
        db.execute(
            """
            UPDATE k8s_templates SET
                name = ?, description = ?, tags = ?, default_namespace = ?, parameter_schema = ?, manifest_template = ?
            WHERE id = ?
            """,
            (
                data["name"],
                data.get("description", ""),
                tags,
                data.get("default_namespace", "default"),
                schema,
                data["manifest_template"],
                rid,
            ),
        )
    else:
        db.execute(
            """
            INSERT INTO k8s_templates (id, name, description, tags, default_namespace, parameter_schema, manifest_template, builtin)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                rid,
                data["name"],
                data.get("description", ""),
                tags,
                data.get("default_namespace", "default"),
                schema,
                data["manifest_template"],
                1 if data.get("builtin", False) else 0,
            ),
        )
    return rid


def delete_k8s_template(template_id: str) -> None:
    db = get_db()
    db.execute("DELETE FROM k8s_templates WHERE id = ? AND builtin = 0", (template_id,))


# ---------------------------------------------------------------------------
# workflows
# ---------------------------------------------------------------------------


def list_k8s_workflows(k8s_cluster_id: str) -> list[dict[str, Any]]:
    db = get_db()
    rows = db.query(
        "SELECT * FROM k8s_workflows WHERE k8s_cluster_id = ? ORDER BY name",
        (k8s_cluster_id,),
    )
    return [_row_to_workflow(r) for r in rows]


def get_k8s_workflow(k8s_cluster_id: str, workflow_id: str | None = None, name: str | None = None) -> dict[str, Any] | None:
    db = get_db()
    if workflow_id:
        row = db.query_one("SELECT * FROM k8s_workflows WHERE id = ? AND k8s_cluster_id = ?", (workflow_id, k8s_cluster_id))
    elif name:
        row = db.query_one("SELECT * FROM k8s_workflows WHERE k8s_cluster_id = ? AND name = ?", (k8s_cluster_id, name))
    else:
        return None
    return _row_to_workflow(row) if row else None


def _row_to_workflow(row) -> dict[str, Any]:
    return {
        "id": row["id"],
        "k8s_cluster_id": row["k8s_cluster_id"],
        "name": row["name"],
        "enabled": bool(row["enabled"]),
        "schedule": row["schedule"],
        "steps": json.loads(row["steps"] or "[]"),
        "last_run_status": row["last_run_status"],
        "last_run_at": row["last_run_at"],
        "task_id": row["task_id"],
    }


def save_k8s_workflow(k8s_cluster_id: str, data: dict[str, Any]) -> str:
    db = get_db()
    rid = data.get("id") or str(uuid.uuid4())
    existing = db.query_one(
        "SELECT id FROM k8s_workflows WHERE k8s_cluster_id = ? AND name = ?",
        (k8s_cluster_id, data["name"]),
    )
    steps = json.dumps(list(data.get("steps", [])))
    if existing:
        db.execute(
            """
            UPDATE k8s_workflows SET
                enabled = ?, schedule = ?, steps = ?, last_run_status = ?, last_run_at = ?, task_id = ?
            WHERE id = ?
            """,
            (
                1 if data.get("enabled", False) else 0,
                data["schedule"],
                steps,
                data.get("last_run_status"),
                data.get("last_run_at"),
                data.get("task_id"),
                existing["id"],
            ),
        )
        return existing["id"]
    db.execute(
        """
        INSERT INTO k8s_workflows (id, k8s_cluster_id, name, enabled, schedule, steps, last_run_status, last_run_at, task_id)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (
            rid,
            k8s_cluster_id,
            data["name"],
            1 if data.get("enabled", False) else 0,
            data["schedule"],
            steps,
            data.get("last_run_status"),
            data.get("last_run_at"),
            data.get("task_id"),
        ),
    )
    return rid


def update_k8s_workflow_run(k8s_cluster_id: str, workflow_id: str, status: str, run_at: str | None = None) -> None:
    db = get_db()
    db.execute(
        """
        UPDATE k8s_workflows SET last_run_status = ?, last_run_at = ?
        WHERE id = ? AND k8s_cluster_id = ?
        """,
        (status, run_at or _now(), workflow_id, k8s_cluster_id),
    )
