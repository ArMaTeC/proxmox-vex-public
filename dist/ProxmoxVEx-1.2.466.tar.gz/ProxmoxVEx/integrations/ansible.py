# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/integrations/ansible.py
# Project:     ProxmoxVEx
# Version:     1.2.453
# Build:       2026.09.14
# Description: Ansible playbook export integration for ProxmoxVEx...
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-14
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Ansible playbook export integration for ProxmoxVEx clusters."""

import html
from datetime import datetime, timezone

from flask import Blueprint, Response, jsonify

from ProxmoxVEx.api.helpers import check_cluster_access
from ProxmoxVEx.globals import cluster_managers
from ProxmoxVEx.utils.auth import require_auth

bp = Blueprint("ansible", __name__)


def _yaml_str(value):
    """Return a YAML-safe quoted string for a plain value."""
    if value is None:
        return "null"
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, (int, float)):
        return str(value)
    s = str(value)
    if any(
        c in s for c in (":", "#", "-", "[", "]", "{", "}", ",", "&", "*", "!", "|", ">", "'", '"', "%", "@", "`", "?")
    ):
        return '"' + s.replace("\\", "\\\\").replace('"', '\\"') + '"'
    return s


def _generate_playbook(cluster_id, resources, manager):
    """Generate an Ansible playbook for the given cluster resources."""
    host = "localhost"
    if manager and hasattr(manager, "config"):
        host = getattr(manager.config, "host", "localhost")

    lines = [
        "---",
        f"# Ansible playbook exported from ProxmoxVEx at {datetime.now(timezone.utc).isoformat()}",
        f"- name: Manage ProxmoxVEx resources for {cluster_id}",
        f"  hosts: {host}",
        "  gather_facts: false",
        "  vars:",
        f'    pve_api_url: "https://{host}:8006/api2/json"',
        "    pve_validate_certs: false",
        "  tasks:",
    ]

    for resource in resources:
        vmid = resource.get("vmid")
        name = resource.get("name") or f"vm{vmid}"
        node = resource.get("node") or "pve"
        rtype = resource.get("type")

        if rtype == "qemu":
            lines.append(f"    - name: Ensure QEMU VM {name} exists")
            lines.append("      community.general.proxmox_kvm:")
            lines.append(f'        api_host: "{host}"')
            lines.append('        api_user: "root@pam"')
            lines.append(f"        name: {_yaml_str(name)}")
            lines.append(f"        node: {_yaml_str(node)}")
            lines.append(f"        vmid: {vmid}")
            lines.append(f"        memory: {int(resource.get('maxmem', 1073741824)) // 1048576}")
            lines.append(f"        cores: {resource.get('maxcpu', 1)}")
            lines.append(f"        state: {resource.get('status', 'present')}")
            lines.append("      register: qemu_result")
            lines.append("")
        elif rtype == "lxc":
            lines.append(f"    - name: Ensure LXC container {name} exists")
            lines.append("      community.general.proxmox:")
            lines.append(f'        api_host: "{host}"')
            lines.append('        api_user: "root@pam"')
            lines.append(f"        hostname: {_yaml_str(name)}")
            lines.append(f"        node: {_yaml_str(node)}")
            lines.append(f"        vmid: {vmid}")
            lines.append('        ostemplate: "local:vztmpl/debian-12-standard_12.2-1_amd64.tar.zst"')
            lines.append(f"        state: {resource.get('status', 'present')}")
            lines.append("      register: lxc_result")
            lines.append("")

    return "\n".join(lines)


@bp.route("/api/clusters/<cluster_id>/ansible/export", methods=["GET"])
@require_auth(perms=["ansible.export"])
def export_ansible_playbook(cluster_id):
    """Export an Ansible playbook for the cluster's VMs and containers."""
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), 403
    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    manager = cluster_managers[cluster_id]
    resources = manager.get_vm_resources() or []
    playbook = _generate_playbook(cluster_id, resources, manager)

    safe_id = html.escape(cluster_id)
    return Response(
        playbook,
        mimetype="text/yaml",
        headers={"Content-Disposition": f'attachment; filename="proxmoxvex_{safe_id}_ansible.yml"'},
    )
