#!/usr/bin/env python3
# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/integrations/truenas.py
# Project:     ProxmoxVEx
# Version:     1.2.453
# Build:       2026.09.14
# Description: TrueNAS integration: export endpoints.
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-14
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""TrueNAS integration: export endpoints."""

import html

from flask import Blueprint, jsonify, request

from ProxmoxVEx.api.auth import require_auth
from ProxmoxVEx.api.clusters import check_cluster_access, cluster_managers
from ProxmoxVEx.utils.audit import log_audit

bp = Blueprint("truenas", __name__)


@bp.route("/api/clusters/<cluster_id>/truenas/export", methods=["GET", "POST"])
@require_auth(perms=["truenas.export"])
def truenas_export(cluster_id):
    """Return or generate a TrueNAS export for a cluster."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "export": {
                "format": "truenas",
                "datasets": [],
                "preview": True,
            },
        })

    data = request.get_json() or {}
    datasets = data.get("datasets", [])
    if not isinstance(datasets, list):
        return jsonify({"error": "datasets must be a list"}), 400

    log_audit(
        request.session.get("user", "system"),
        "truenas.export",
        f"Generated TrueNAS export for {html.escape(cluster_id)}: datasets={len(datasets)}",
        cluster=cluster_managers[cluster_id].config.name,
    )

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "export": {
            "format": "truenas",
            "datasets": datasets,
        },
    })


@bp.route("/api/clusters/<cluster_id>/truenas/connector", methods=["GET", "POST"])
@require_auth(perms=["truenas.connector"])
def truenas_connector(cluster_id):
    """Return or update the TrueNAS connector configuration."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "connector": {
                "enabled": False,
                "endpoint": "",
                "api_key": "",
            },
        })

    data = request.get_json() or {}
    connector = data.get("connector", {})
    enabled = bool(connector.get("enabled", False))
    endpoint = connector.get("endpoint", "")
    api_key = connector.get("api_key", "")

    if not isinstance(endpoint, str) or not isinstance(api_key, str):
        return jsonify({"error": "endpoint and api_key must be strings"}), 400

    log_audit(
        request.session.get("user", "system"),
        "truenas.connector",
        f"Updated TrueNAS connector for {html.escape(cluster_id)}: enabled={enabled}",
        cluster=cluster_managers[cluster_id].config.name,
    )

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "connector": {
            "enabled": enabled,
            "endpoint": endpoint,
            "api_key": "***" if api_key else "",
        },
    })


def sync_truenas_datasets(cluster_id, datasets):
    """Normalize and prepare TrueNAS datasets for sync."""
    if not isinstance(datasets, list):
        datasets = []
    return [
        {
            "name": html.escape(str(d.get("name", ""))),
            "pool": html.escape(str(d.get("pool", ""))),
            "mountpoint": html.escape(str(d.get("mountpoint", ""))),
            "comment": html.escape(str(d.get("comment", ""))),
        }
        for d in datasets
        if isinstance(d, dict)
    ]


@bp.route("/api/clusters/<cluster_id>/truenas/sync", methods=["POST"])
@require_auth(perms=["truenas.sync"])
def truenas_sync(cluster_id):
    """Run a TrueNAS sync for a cluster."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    data = request.get_json() or {}
    datasets = data.get("datasets", [])
    if not isinstance(datasets, list):
        return jsonify({"error": "datasets must be a list"}), 400

    synced = sync_truenas_datasets(cluster_id, datasets)

    log_audit(
        request.session.get("user", "system"),
        "truenas.sync",
        f"Synced TrueNAS for {html.escape(cluster_id)}: datasets={len(synced)}",
        cluster=cluster_managers[cluster_id].config.name,
    )

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "synced": synced,
    })


def import_truenas_datasets(datasets):
    """Validate and normalize a list of TrueNAS datasets for import."""
    if not isinstance(datasets, list):
        datasets = []
    imported = []
    for d in datasets:
        if not isinstance(d, dict):
            continue
        name = str(d.get("name", "")).strip()
        if not name:
            continue
        imported.append({
            "name": html.escape(name),
            "pool": html.escape(str(d.get("pool", ""))),
            "mountpoint": html.escape(str(d.get("mountpoint", ""))),
            "comment": html.escape(str(d.get("comment", ""))),
        })
    return imported


@bp.route("/api/clusters/<cluster_id>/truenas/import", methods=["POST"])
@require_auth(perms=["truenas.import"])
def truenas_import(cluster_id):
    """Import TrueNAS datasets into a cluster."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    data = request.get_json() or {}
    datasets = data.get("datasets", [])
    if not isinstance(datasets, list):
        return jsonify({"error": "datasets must be a list"}), 400

    imported = import_truenas_datasets(datasets)

    log_audit(
        request.session.get("user", "system"),
        "truenas.import",
        f"Imported TrueNAS datasets for {html.escape(cluster_id)}: datasets={len(imported)}",
        cluster=cluster_managers[cluster_id].config.name,
    )

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "imported": imported,
    })


# In-memory template library store (cluster_id -> list of templates)
_truenas_templates = {}


def get_truenas_templates(cluster_id):
    """Return TrueNAS template definitions for a cluster."""
    return _truenas_templates.get(cluster_id, [])


def save_truenas_templates(cluster_id, templates):
    """Persist TrueNAS template definitions for a cluster."""
    if not isinstance(templates, list):
        templates = []
    _truenas_templates[cluster_id] = [
        {
            "id": html.escape(str(t.get("id", ""))),
            "name": html.escape(str(t.get("name", ""))),
            "description": html.escape(str(t.get("description", ""))),
        }
        for t in templates
        if isinstance(t, dict)
    ]
    return _truenas_templates[cluster_id]


@bp.route("/api/clusters/<cluster_id>/truenas/templates", methods=["GET", "POST"])
@require_auth(perms=["truenas.templates"])
def truenas_templates(cluster_id):
    """List or save TrueNAS templates for a cluster."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "templates": get_truenas_templates(cluster_id),
        })

    data = request.get_json() or {}
    templates = data.get("templates", [])
    if not isinstance(templates, list):
        return jsonify({"error": "templates must be a list"}), 400

    saved = save_truenas_templates(cluster_id, templates)

    log_audit(
        request.session.get("user", "system"),
        "truenas.templates",
        f"Updated TrueNAS templates for {html.escape(cluster_id)}: templates={len(saved)}",
        cluster=cluster_managers[cluster_id].config.name,
    )

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "templates": saved,
    })


def get_truenas_dashboard_summary(cluster_id):
    """Return dashboard widget data for TrueNAS."""
    templates = get_truenas_templates(cluster_id)
    return {
        "cluster": html.escape(cluster_id),
        "status": "ok",
        "templates": len(templates),
        "datasets": len(templates) if cluster_id in _truenas_templates else 0,
    }


@bp.route("/api/clusters/<cluster_id>/truenas/dashboard", methods=["GET"])
@require_auth(perms=["truenas.dashboard"])
def truenas_dashboard(cluster_id):
    """Return TrueNAS dashboard widget summary for a cluster."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    summary = get_truenas_dashboard_summary(cluster_id)

    log_audit(
        request.session.get("user", "system"),
        "truenas.dashboard",
        f"Fetched TrueNAS dashboard for {html.escape(cluster_id)}",
        cluster=cluster_managers[cluster_id].config.name,
    )

    return jsonify({
        "success": True,
        "summary": summary,
    })


# In-memory alert channel store (cluster_id -> list of alerts)
_truenas_alerts = {}


def get_truenas_alerts(cluster_id):
    """Return alert channel messages for a cluster."""
    return _truenas_alerts.get(cluster_id, [])


def add_truenas_alert(cluster_id, message, severity="info"):
    """Append a sanitized alert to the cluster alert channel."""
    _truenas_alerts.setdefault(cluster_id, []).append({
        "cluster": html.escape(cluster_id),
        "message": html.escape(str(message)),
        "severity": html.escape(str(severity)),
    })
    return _truenas_alerts[cluster_id]


@bp.route("/api/clusters/<cluster_id>/truenas/alerts", methods=["GET", "POST"])
@require_auth(perms=["truenas.alerts"])
def truenas_alert(cluster_id):
    """List or add TrueNAS alert channel messages for a cluster."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "alerts": get_truenas_alerts(cluster_id),
        })

    data = request.get_json() or {}
    message = data.get("message", "")
    severity = data.get("severity", "info")
    if not isinstance(message, str) or not message.strip():
        return jsonify({"error": "message is required"}), 400

    alerts = add_truenas_alert(cluster_id, message, severity)

    log_audit(
        request.session.get("user", "system"),
        "truenas.alerts",
        f"Added TrueNAS alert for {html.escape(cluster_id)}: severity={severity}",
        cluster=cluster_managers[cluster_id].config.name,
    )

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "alerts": alerts,
    })


def apply_truenas_policy(datasets, policy):
    """Apply a simple allow/deny policy to a dataset list."""
    if not isinstance(datasets, list):
        datasets = []
    if not isinstance(policy, dict):
        policy = {}
    action = policy.get("action", "allow").lower()
    # Normalise allowed/denied filters into sets via comprehensions.
    allowed = {str(a).strip() for a in policy.get("allowed", []) if isinstance(a, str)}
    denied = {str(d).strip() for d in policy.get("denied", []) if isinstance(d, str)}

    result = []
    for d in datasets:
        if not isinstance(d, dict):
            continue
        name = str(d.get("name", d.get("dataset", ""))).strip()
        if action == "allow" and allowed and name not in allowed:
            continue
        if action == "deny" and denied and name in denied:
            continue
        result.append({
            "name": html.escape(name),
            "pool": html.escape(str(d.get("pool", ""))),
            "mountpoint": html.escape(str(d.get("mountpoint", ""))),
            "comment": html.escape(str(d.get("comment", ""))),
        })
    return result


@bp.route("/api/clusters/<cluster_id>/truenas/policy", methods=["GET", "POST"])
@require_auth(perms=["truenas.policy"])
def truenas_policy(cluster_id):
    """Return or apply the TrueNAS policy adapter for a cluster."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "policy": {
                "action": "allow",
                "allowed": [],
                "denied": [],
            },
        })

    data = request.get_json() or {}
    datasets = data.get("datasets", [])
    policy = data.get("policy", {})
    if not isinstance(datasets, list) or not isinstance(policy, dict):
        return jsonify({"error": "datasets and policy are required"}), 400

    matched = apply_truenas_policy(datasets, policy)

    log_audit(
        request.session.get("user", "system"),
        "truenas.policy",
        f"Applied TrueNAS policy for {html.escape(cluster_id)}: matched={len(matched)}",
        cluster=cluster_managers[cluster_id].config.name,
    )

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "matched": matched,
    })


# In-memory role mapping store (cluster_id -> dict)
_truenas_role_map = {}


def get_truenas_role_map(cluster_id):
    """Return the TrueNAS role mapping for a cluster."""
    return _truenas_role_map.get(cluster_id, {})


def set_truenas_role_map(cluster_id, mapping):
    """Set and sanitize the TrueNAS role mapping for a cluster."""
    if not isinstance(mapping, dict):
        mapping = {}
    sanitized = {}
    for k, v in mapping.items():
        if isinstance(k, str) and isinstance(v, str):
            sanitized[html.escape(k)] = html.escape(v)
    _truenas_role_map[cluster_id] = sanitized
    return sanitized


@bp.route("/api/clusters/<cluster_id>/truenas/roles", methods=["GET", "POST"])
@require_auth(perms=["truenas.roles"])
def truenas_roles(cluster_id):
    """Return or update TrueNAS role mapping for a cluster."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "mapping": get_truenas_role_map(cluster_id),
        })

    data = request.get_json() or {}
    mapping = data.get("mapping", {})
    if not isinstance(mapping, dict):
        return jsonify({"error": "mapping must be a dict"}), 400

    saved = set_truenas_role_map(cluster_id, mapping)

    log_audit(
        request.session.get("user", "system"),
        "truenas.roles",
        f"Updated TrueNAS role mapping for {html.escape(cluster_id)}: entries={len(saved)}",
        cluster=cluster_managers[cluster_id].config.name,
    )

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "mapping": saved,
    })


# In-memory automation workflow store (cluster_id -> list of workflows)
_truenas_workflows = {}


def get_truenas_workflows(cluster_id):
    """Return automation workflows for a cluster."""
    return _truenas_workflows.get(cluster_id, [])


def save_truenas_workflows(cluster_id, workflows):
    """Set and sanitize the TrueNAS automation workflows for a cluster."""
    if not isinstance(workflows, list):
        workflows = []
    _truenas_workflows[cluster_id] = [
        {
            "id": html.escape(str(w.get("id", ""))),
            "name": html.escape(str(w.get("name", ""))),
            "enabled": bool(w.get("enabled", False)),
            "steps": [html.escape(str(s)) for s in w.get("steps", []) if isinstance(s, str)],
        }
        for w in workflows
        if isinstance(w, dict)
    ]
    return _truenas_workflows[cluster_id]


@bp.route("/api/clusters/<cluster_id>/truenas/workflows", methods=["GET", "POST"])
@require_auth(perms=["truenas.workflows"])
def truenas_workflows(cluster_id):
    """List or save TrueNAS automation workflows for a cluster."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "workflows": get_truenas_workflows(cluster_id),
        })

    data = request.get_json() or {}
    workflows = data.get("workflows", [])
    if not isinstance(workflows, list):
        return jsonify({"error": "workflows must be a list"}), 400

    saved = save_truenas_workflows(cluster_id, workflows)

    log_audit(
        request.session.get("user", "system"),
        "truenas.workflows",
        f"Updated TrueNAS workflows for {html.escape(cluster_id)}: workflows={len(saved)}",
        cluster=cluster_managers[cluster_id].config.name,
    )

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "workflows": saved,
    })
