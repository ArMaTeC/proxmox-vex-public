#!/usr/bin/env python3
# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/integrations/git.py
# Project:     ProxmoxVEx
# Version:     1.2.453
# Build:       2026.09.14
# Description: Git integration: export endpoints.
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-14
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Git integration: export endpoints."""

import html

from flask import Blueprint, jsonify, request

from ProxmoxVEx.api.auth import require_auth
from ProxmoxVEx.api.clusters import check_cluster_access, cluster_managers
from ProxmoxVEx.utils.audit import log_audit

bp = Blueprint("git", __name__)


# In-memory Git export target store.
_git_export_targets = {}


@bp.route("/api/clusters/<cluster_id>/git/export", methods=["GET", "POST"])
@require_auth(perms=["git.export"])
def git_export(cluster_id):
    """Return or update the Git export configuration.

    880-git-export: per-cluster Git export target settings.
    """
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "export": _git_export_targets.get(
                cluster_id,
                {"enabled": False, "repo": "", "branch": ""},
            ),
        })

    data = request.get_json() or {}
    export = data.get("export", {})
    enabled = bool(export.get("enabled", False))
    repo = str(export.get("repo", ""))
    branch = str(export.get("branch", ""))

    config = {
        "enabled": enabled,
        "repo": html.escape(repo),
        "branch": html.escape(branch),
    }
    _git_export_targets[cluster_id] = config
    log_audit(
        request.session.get("user", "system"),
        "git.export",
        f"Updated Git export for {html.escape(cluster_id)}: enabled={enabled}, repo={config['repo']}",
        cluster=cluster_managers[cluster_id].config.name,
    )

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "export": config,
    })


# In-memory Git connector store.
_git_connector = {}


@bp.route("/api/clusters/<cluster_id>/git/connector", methods=["GET", "POST"])
@require_auth(perms=["git.connector"])
def git_connector(cluster_id):
    """Return or update the Git connector configuration.

    881-git-connector: per-cluster Git server credentials and connection
    settings.
    """
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "connector": _git_connector.get(
                cluster_id,
                {"enabled": False, "server": "", "token": "", "username": ""},
            ),
        })

    data = request.get_json() or {}
    connector = data.get("connector", {})
    enabled = bool(connector.get("enabled", False))
    server = str(connector.get("server", ""))
    username = str(connector.get("username", ""))
    token = str(connector.get("token", ""))

    config = {
        "enabled": enabled,
        "server": html.escape(server),
        "username": html.escape(username),
        "token": "***" if token else "",
    }
    _git_connector[cluster_id] = config
    log_audit(
        request.session.get("user", "system"),
        "git.connector",
        f"Updated Git connector for {html.escape(cluster_id)}: enabled={enabled}, server={config['server']}",
        cluster=cluster_managers[cluster_id].config.name,
    )

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "connector": config,
    })


# In-memory Git sync status store.
_git_sync_status = {}


@bp.route("/api/clusters/<cluster_id>/git/sync", methods=["GET", "POST"])
@require_auth(perms=["git.sync"])
def git_sync(cluster_id):
    """Return or update the Git sync status.

    882-git-sync: per-cluster Git sync state and last status.
    """
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "sync": _git_sync_status.get(
                cluster_id,
                {"status": "idle", "last_sync": 0, "message": ""},
            ),
        })

    data = request.get_json() or {}
    status = data.get("sync", {})
    config = {
        "status": html.escape(str(status.get("status", "idle"))),
        "last_sync": int(status.get("last_sync", 0)),
        "message": html.escape(str(status.get("message", ""))),
    }
    _git_sync_status[cluster_id] = config
    log_audit(
        request.session.get("user", "system"),
        "git.sync",
        f"Updated Git sync for {html.escape(cluster_id)}: status={config['status']}",
        cluster=cluster_managers[cluster_id].config.name,
    )

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "sync": config,
    })


# In-memory Git import status store.
_git_import_status = {}


@bp.route("/api/clusters/<cluster_id>/git/import", methods=["GET", "POST"])
@require_auth(perms=["git.import"])
def git_import(cluster_id):
    """Return or update the Git import status.

    883-git-import: per-cluster Git import state and last status.
    """
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "import": _git_import_status.get(
                cluster_id,
                {"status": "idle", "last_import": 0, "message": ""},
            ),
        })

    data = request.get_json() or {}
    status = data.get("import", {})
    config = {
        "status": html.escape(str(status.get("status", "idle"))),
        "last_import": int(status.get("last_import", 0)),
        "message": html.escape(str(status.get("message", ""))),
    }
    _git_import_status[cluster_id] = config
    log_audit(
        request.session.get("user", "system"),
        "git.import",
        f"Updated Git import for {html.escape(cluster_id)}: status={config['status']}",
        cluster=cluster_managers[cluster_id].config.name,
    )

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "import": config,
    })


# In-memory Git template library store.
_git_template_library = {}


@bp.route("/api/clusters/<cluster_id>/git/templates", methods=["GET", "POST"])
@require_auth(perms=["git.templates"])
def git_templates(cluster_id):
    """Return or update the Git template library.

    884-git-template-library: per-cluster Git templates for manifests and
    playbooks.
    """
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "templates": _git_template_library.get(cluster_id, []),
        })

    data = request.get_json() or {}
    templates = data.get("templates", [])
    if not isinstance(templates, list):
        return jsonify({"error": "templates must be a list"}), 400

    cleaned = []
    for template in templates:
        if not isinstance(template, dict):
            continue
        cleaned.append({
            "id": html.escape(str(template.get("id", ""))),
            "name": html.escape(str(template.get("name", ""))),
            "path": html.escape(str(template.get("path", ""))),
            "content": html.escape(str(template.get("content", ""))),
        })
    _git_template_library[cluster_id] = cleaned
    log_audit(
        request.session.get("user", "system"),
        "git.templates",
        f"Updated Git template library for {html.escape(cluster_id)}: {len(cleaned)} templates",
        cluster=cluster_managers[cluster_id].config.name,
    )

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "templates": cleaned,
    })


@bp.route("/api/clusters/<cluster_id>/git/dashboard-widget", methods=["GET"])
@require_auth(perms=["git.view"])
def git_dashboard_widget(cluster_id):
    """Return a summary for the Git dashboard widget.

    885-git-dashboard-widget: aggregates export, connector, sync, import and
    template status into a concise payload for the main dashboard.
    """
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    export_cfg = _git_export_targets.get(cluster_id, {"enabled": False})
    connector = _git_connector.get(cluster_id, {"enabled": False})
    sync = _git_sync_status.get(cluster_id, {"status": "idle"})
    import_status = _git_import_status.get(cluster_id, {"status": "idle"})
    templates = _git_template_library.get(cluster_id, [])
    return jsonify({
        "cluster": html.escape(cluster_id),
        "export_enabled": export_cfg.get("enabled", False),
        "connected": connector.get("enabled", False) and bool(connector.get("server", "")),
        "sync_status": sync.get("status", "idle"),
        "import_status": import_status.get("status", "idle"),
        "template_count": len(templates),
    })


# In-memory Git alert channel store.
_git_alert_channels = {}


@bp.route("/api/clusters/<cluster_id>/git/alert-channel", methods=["GET", "POST"])
@require_auth(perms=["git.alert_channel"])
def git_alert_channel(cluster_id):
    """Return or update the Git alert channel configuration.

    886-git-alert-channel: per-cluster alert routing settings for Git events.
    """
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "alert_channel": _git_alert_channels.get(
                cluster_id,
                {"enabled": False, "target": "", "events": []},
            ),
        })

    data = request.get_json() or {}
    channel = data.get("alert_channel", {})
    events = channel.get("events", [])
    if not isinstance(events, list):
        events = []

    config = {
        "enabled": bool(channel.get("enabled", False)),
        "target": html.escape(str(channel.get("target", ""))),
        "events": [html.escape(str(event)) for event in events],
    }
    _git_alert_channels[cluster_id] = config
    log_audit(
        request.session.get("user", "system"),
        "git.alert_channel",
        f"Updated Git alert channel for {html.escape(cluster_id)}: enabled={config['enabled']}, target={config['target']}",
        cluster=cluster_managers[cluster_id].config.name,
    )

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "alert_channel": config,
    })


# In-memory Git policy adapter store.
_git_policy_adapter = {}


@bp.route("/api/clusters/<cluster_id>/git/policy-adapter", methods=["GET", "POST"])
@require_auth(perms=["git.policy_adapter"])
def git_policy_adapter(cluster_id):
    """Return or update the Git policy adapter configuration.

    887-git-policy-adapter: per-cluster mapping between ProxmoxVEx
    permissions and Git branch protection rules.
    """
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "policy_adapter": _git_policy_adapter.get(
                cluster_id,
                {"enabled": False, "default_branch": "main", "rules": []},
            ),
        })

    data = request.get_json() or {}
    adapter = data.get("policy_adapter", {})
    rules = adapter.get("rules", [])
    if not isinstance(rules, list):
        rules = []

    cleaned_rules = []
    for rule in rules:
        if not isinstance(rule, dict):
            continue
        cleaned_rules.append({
            "permission": html.escape(str(rule.get("permission", ""))),
            "pattern": html.escape(str(rule.get("pattern", ""))),
            "action": html.escape(str(rule.get("action", "allow"))),
        })

    config = {
        "enabled": bool(adapter.get("enabled", False)),
        "default_branch": html.escape(str(adapter.get("default_branch", "main"))),
        "rules": cleaned_rules,
    }
    _git_policy_adapter[cluster_id] = config
    log_audit(
        request.session.get("user", "system"),
        "git.policy_adapter",
        f"Updated Git policy adapter for {html.escape(cluster_id)}: {len(cleaned_rules)} rules",
        cluster=cluster_managers[cluster_id].config.name,
    )

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "policy_adapter": config,
    })


# In-memory Git role mapping store.
_git_role_mapping = {}


@bp.route("/api/clusters/<cluster_id>/git/role-mapping", methods=["GET", "POST"])
@require_auth(perms=["git.role_mapping"])
def git_role_mapping(cluster_id):
    """Return or update the Git role mapping configuration.

    888-git-role-mapping: per-cluster mapping between ProxmoxVEx roles and
    Git access levels.
    """
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "role_mapping": _git_role_mapping.get(
                cluster_id,
                {"enabled": False, "mappings": []},
            ),
        })

    data = request.get_json() or {}
    mapping_data = data.get("role_mapping", {})
    mappings = mapping_data.get("mappings", [])
    if not isinstance(mappings, list):
        mappings = []

    cleaned = []
    for mapping in mappings:
        if not isinstance(mapping, dict):
            continue
        cleaned.append({
            "proxmox_role": html.escape(str(mapping.get("proxmox_role", ""))),
            "git_role": html.escape(str(mapping.get("git_role", ""))),
            "scopes": [html.escape(str(scope)) for scope in mapping.get("scopes", [])],
        })

    config = {
        "enabled": bool(mapping_data.get("enabled", False)),
        "mappings": cleaned,
    }
    _git_role_mapping[cluster_id] = config
    log_audit(
        request.session.get("user", "system"),
        "git.role_mapping",
        f"Updated Git role mapping for {html.escape(cluster_id)}: {len(cleaned)} mappings",
        cluster=cluster_managers[cluster_id].config.name,
    )

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "role_mapping": config,
    })


# In-memory Git automation workflow store.
_git_automation_workflows = {}


@bp.route("/api/clusters/<cluster_id>/git/automation-workflow", methods=["GET", "POST"])
@require_auth(perms=["git.automation_workflow"])
def git_automation_workflow(cluster_id):
    """Return or update the Git automation workflow configuration.

    889-git-automation-workflow: per-cluster automation workflow definitions
    triggered by Git events.
    """
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "automation_workflow": _git_automation_workflows.get(
                cluster_id,
                {"enabled": False, "workflows": []},
            ),
        })

    data = request.get_json() or {}
    workflow_data = data.get("automation_workflow", {})
    workflows = workflow_data.get("workflows", [])
    if not isinstance(workflows, list):
        workflows = []

    cleaned = []
    for workflow in workflows:
        if not isinstance(workflow, dict):
            continue
        cleaned.append({
            "id": html.escape(str(workflow.get("id", ""))),
            "name": html.escape(str(workflow.get("name", ""))),
            "trigger": html.escape(str(workflow.get("trigger", ""))),
            "action": html.escape(str(workflow.get("action", ""))),
            "enabled": bool(workflow.get("enabled", False)),
        })

    config = {
        "enabled": bool(workflow_data.get("enabled", False)),
        "workflows": cleaned,
    }
    _git_automation_workflows[cluster_id] = config
    log_audit(
        request.session.get("user", "system"),
        "git.automation_workflow",
        f"Updated Git automation workflow for {html.escape(cluster_id)}: {len(cleaned)} workflows",
        cluster=cluster_managers[cluster_id].config.name,
    )

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "automation_workflow": config,
    })
