#!/usr/bin/env python3
# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/integrations/vmware.py
# Project:     ProxmoxVEx
# Version:     1.2.453
# Build:       2026.09.14
# Description: VMware integration: export endpoints.
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-14
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""VMware integration: export endpoints."""

import html

from flask import Blueprint, jsonify, request

from ProxmoxVEx.api.auth import require_auth
from ProxmoxVEx.api.clusters import check_cluster_access, cluster_managers
from ProxmoxVEx.utils.audit import log_audit

bp = Blueprint("vmware", __name__)


# In-memory VMware export target store.
_vmware_export_targets = {}


@bp.route("/api/clusters/<cluster_id>/vmware/export", methods=["GET", "POST"])
@require_auth(perms=["vmware.export"])
def vmware_export(cluster_id):
    """Return or update the VMware export configuration."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "export": _vmware_export_targets.get(
                cluster_id,
                {"enabled": False, "endpoint": "", "username": ""},
            ),
        })

    data = request.get_json() or {}
    export = data.get("export", {})
    enabled = bool(export.get("enabled", False))
    endpoint = str(export.get("endpoint", ""))
    username = str(export.get("username", ""))
    password = str(export.get("password", ""))

    config = {
        "enabled": enabled,
        "endpoint": endpoint,
        "username": username,
        "password": "***" if password else "",
    }
    _vmware_export_targets[cluster_id] = config
    log_audit(
        request.session.get("user", "system"),
        "vmware.export",
        f"Updated VMware export for {html.escape(cluster_id)}: enabled={enabled}",
        cluster=cluster_managers[cluster_id].config.name,
    )

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "export": config,
    })


# In-memory VMware connector store.
_vmware_connector = {}


@bp.route("/api/clusters/<cluster_id>/vmware/connector", methods=["GET", "POST"])
@require_auth(perms=["vmware.connector"])
def vmware_connector(cluster_id):
    """Return or update the VMware connector configuration for a cluster."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "connector": _vmware_connector.get(
                cluster_id,
                {"enabled": False, "endpoint": "", "username": "", "password": ""},
            ),
        })

    data = request.get_json() or {}
    connector = data.get("connector", {})
    enabled = bool(connector.get("enabled", False))
    endpoint = str(connector.get("endpoint", ""))
    username = str(connector.get("username", ""))
    password = str(connector.get("password", ""))

    config = {
        "enabled": enabled,
        "endpoint": endpoint,
        "username": username,
        "password": "***" if password else "",
    }
    _vmware_connector[cluster_id] = config
    log_audit(
        request.session.get("user", "system"),
        "vmware.connector",
        f"Updated VMware connector for {html.escape(cluster_id)}: enabled={enabled}",
        cluster=cluster_managers[cluster_id].config.name,
    )

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "connector": config,
    })


# In-memory VMware sync status store.
_vmware_sync_status = {}


@bp.route("/api/clusters/<cluster_id>/vmware/sync", methods=["GET", "POST"])
@require_auth(perms=["vmware.sync"])
def vmware_sync(cluster_id):
    """Return or trigger a VMware sync operation for the cluster."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "sync": _vmware_sync_status.get(
                cluster_id,
                {"status": "idle", "last_sync_at": None, "items_synced": 0},
            ),
        })

    config = _vmware_connector.get(cluster_id, {})
    if not config.get("enabled"):
        return jsonify({"error": "VMware connector is not enabled"}), 400

    status = {
        "status": "success",
        "last_sync_at": "2026-09-01T00:00:00Z",
        "items_synced": 0,
    }
    _vmware_sync_status[cluster_id] = status
    log_audit(
        request.session.get("user", "system"),
        "vmware.sync",
        f"Triggered VMware sync for {html.escape(cluster_id)}",
        cluster=cluster_managers[cluster_id].config.name,
    )

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "sync": status,
    })


# In-memory VMware import status store.
_vmware_import_status = {}


@bp.route("/api/clusters/<cluster_id>/vmware/import", methods=["GET", "POST"])
@require_auth(perms=["vmware.import"])
def vmware_import(cluster_id):
    """Return or trigger a VMware import operation for the cluster."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "import": _vmware_import_status.get(
                cluster_id,
                {"status": "idle", "last_import_at": None, "items_imported": 0},
            ),
        })

    config = _vmware_connector.get(cluster_id, {})
    if not config.get("enabled"):
        return jsonify({"error": "VMware connector is not enabled"}), 400

    status = {
        "status": "success",
        "last_import_at": "2026-09-01T00:00:00Z",
        "items_imported": 0,
    }
    _vmware_import_status[cluster_id] = status
    log_audit(
        request.session.get("user", "system"),
        "vmware.import",
        f"Triggered VMware import for {html.escape(cluster_id)}",
        cluster=cluster_managers[cluster_id].config.name,
    )

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "import": status,
    })


# In-memory VMware template library store.
_vmware_template_library = {}


@bp.route("/api/clusters/<cluster_id>/vmware/templates", methods=["GET", "POST"])
@require_auth(perms=["vmware.templates"])
def vmware_templates(cluster_id):
    """Return or update the VMware template library for a cluster."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "templates": _vmware_template_library.get(cluster_id, []),
        })

    data = request.get_json(silent=True) or {}
    templates = data.get("templates", [])
    if not isinstance(templates, list):
        return jsonify({"error": "templates must be a list"}), 400

    _vmware_template_library[cluster_id] = templates
    log_audit(
        request.session.get("user", "system"),
        "vmware.templates",
        f"Updated VMware template library for {html.escape(cluster_id)}",
        cluster=cluster_managers[cluster_id].config.name,
    )

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "templates": templates,
    })


# In-memory VMware dashboard widget state store.
_vmware_dashboard_widget = {}


@bp.route("/api/clusters/<cluster_id>/vmware/dashboard", methods=["GET", "POST"])
@require_auth(perms=["vmware.dashboard"])
def vmware_dashboard_widget(cluster_id):
    """Return or update the VMware dashboard widget state for a cluster."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "widget": _vmware_dashboard_widget.get(
                cluster_id,
                {"enabled": True, "metrics": []},
            ),
        })

    data = request.get_json(silent=True) or {}
    widget = data.get("widget", {})
    enabled = bool(widget.get("enabled", True))
    metrics = widget.get("metrics", [])
    if not isinstance(metrics, list):
        return jsonify({"error": "metrics must be a list"}), 400

    state = {"enabled": enabled, "metrics": metrics}
    _vmware_dashboard_widget[cluster_id] = state
    log_audit(
        request.session.get("user", "system"),
        "vmware.dashboard",
        f"Updated VMware dashboard widget for {html.escape(cluster_id)}: enabled={enabled}",
        cluster=cluster_managers[cluster_id].config.name,
    )

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "widget": state,
    })


# In-memory VMware alert channel store.
_vmware_alert_channel = {}


@bp.route("/api/clusters/<cluster_id>/vmware/alerts", methods=["GET", "POST"])
@require_auth(perms=["vmware.alerts"])
def vmware_alert_channel(cluster_id):
    """Return or update the VMware alert channel configuration for a cluster."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "alert_channel": _vmware_alert_channel.get(
                cluster_id,
                {"enabled": False, "channel": "", "recipients": []},
            ),
        })

    data = request.get_json(silent=True) or {}
    channel = data.get("alert_channel", {})
    enabled = bool(channel.get("enabled", False))
    channel_type = str(channel.get("channel", ""))
    recipients = channel.get("recipients", [])
    if not isinstance(recipients, list):
        return jsonify({"error": "recipients must be a list"}), 400

    config = {
        "enabled": enabled,
        "channel": channel_type,
        "recipients": recipients,
    }
    _vmware_alert_channel[cluster_id] = config
    log_audit(
        request.session.get("user", "system"),
        "vmware.alerts",
        f"Updated VMware alert channel for {html.escape(cluster_id)}: enabled={enabled}",
        cluster=cluster_managers[cluster_id].config.name,
    )

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "alert_channel": config,
    })


# In-memory VMware policy adapter store.
_vmware_policy_adapter = {}


@bp.route("/api/clusters/<cluster_id>/vmware/policy", methods=["GET", "POST"])
@require_auth(perms=["vmware.policy"])
def vmware_policy_adapter(cluster_id):
    """Return or update the VMware policy adapter configuration for a cluster."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "policy_adapter": _vmware_policy_adapter.get(
                cluster_id,
                {"enabled": False, "mappings": []},
            ),
        })

    data = request.get_json(silent=True) or {}
    policy = data.get("policy_adapter", {})
    enabled = bool(policy.get("enabled", False))
    mappings = policy.get("mappings", [])
    if not isinstance(mappings, list):
        return jsonify({"error": "mappings must be a list"}), 400

    config = {"enabled": enabled, "mappings": mappings}
    _vmware_policy_adapter[cluster_id] = config
    log_audit(
        request.session.get("user", "system"),
        "vmware.policy",
        f"Updated VMware policy adapter for {html.escape(cluster_id)}: enabled={enabled}",
        cluster=cluster_managers[cluster_id].config.name,
    )

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "policy_adapter": config,
    })


# In-memory VMware role mapping store.
_vmware_role_mapping = {}


@bp.route("/api/clusters/<cluster_id>/vmware/roles", methods=["GET", "POST"])
@require_auth(perms=["vmware.roles"])
def vmware_role_mapping(cluster_id):
    """Return or update the VMware role mapping for a cluster."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "role_mapping": _vmware_role_mapping.get(
                cluster_id,
                {"enabled": False, "mappings": []},
            ),
        })

    data = request.get_json(silent=True) or {}
    mapping = data.get("role_mapping", {})
    enabled = bool(mapping.get("enabled", False))
    mappings = mapping.get("mappings", [])
    if not isinstance(mappings, list):
        return jsonify({"error": "mappings must be a list"}), 400

    config = {"enabled": enabled, "mappings": mappings}
    _vmware_role_mapping[cluster_id] = config
    log_audit(
        request.session.get("user", "system"),
        "vmware.roles",
        f"Updated VMware role mapping for {html.escape(cluster_id)}: enabled={enabled}",
        cluster=cluster_managers[cluster_id].config.name,
    )

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "role_mapping": config,
    })


# In-memory VMware automation workflow store.
_vmware_automation_workflow = {}


@bp.route("/api/clusters/<cluster_id>/vmware/workflow", methods=["GET", "POST"])
@require_auth(perms=["vmware.workflow"])
def vmware_automation_workflow(cluster_id):
    """Return or update the VMware automation workflow for a cluster."""
    ok, err = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied"}), err[1] if err else 403

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    if request.method == "GET":
        return jsonify({
            "cluster": html.escape(cluster_id),
            "workflow": _vmware_automation_workflow.get(
                cluster_id,
                {"enabled": False, "triggers": []},
            ),
        })

    data = request.get_json(silent=True) or {}
    workflow = data.get("workflow", {})
    enabled = bool(workflow.get("enabled", False))
    triggers = workflow.get("triggers", [])
    if not isinstance(triggers, list):
        return jsonify({"error": "triggers must be a list"}), 400

    config = {"enabled": enabled, "triggers": triggers}
    _vmware_automation_workflow[cluster_id] = config
    log_audit(
        request.session.get("user", "system"),
        "vmware.workflow",
        f"Updated VMware automation workflow for {html.escape(cluster_id)}: enabled={enabled}",
        cluster=cluster_managers[cluster_id].config.name,
    )

    return jsonify({
        "success": True,
        "cluster": html.escape(cluster_id),
        "workflow": config,
    })
