# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/ids/policies.py
# Project:     ProxmoxVEx
# Version:     1.2.453
# Build:       2026.09.14
# Description: Detection and response policy engine for the IDS/IPS...
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-14
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Detection and response policy engine for the IDS/IPS module."""

import logging
from datetime import datetime, timedelta, timezone
from typing import Any, Dict

from ProxmoxVEx.ids import models

logger = logging.getLogger(__name__)


def get_default_action(alert: Dict[str, Any]) -> str:
    """Return the default prevention action for an alert."""
    if alert.get("severity") == "critical":
        return "block"
    return "alert"


def _within_window(created_at: str, seconds: int) -> bool:
    try:
        dt = datetime.fromisoformat(created_at)
        return dt > datetime.now(timezone.utc) - timedelta(seconds=seconds)
    except Exception:
        return False


def should_suppress(alert: Dict[str, Any], tolerance: int = 3, window_seconds: int = 300) -> bool:
    """Return True if this alert appears to be a false positive based on recent history."""
    recent = [
        a
        for a in models.list_alerts(segment_id=alert.get("segment_id"), limit=100)
        if a.get("threat_type") == alert.get("threat_type")
        and a.get("source") == alert.get("source")
        and _within_window(a.get("created_at", ""), window_seconds)
    ]
    if len(recent) >= tolerance:
        logger.info(
            "Suppressing potential false positive: %s from %s (count %s)",
            alert.get("threat_type"),
            alert.get("source"),
            len(recent),
        )
        return True
    return False


def resolve_action(alert: Dict[str, Any], policy: Dict[str, Any] = None) -> str:
    """Determine the action to take for an alert based on policy and default."""
    if policy and policy.get("default_action"):
        return policy["default_action"]
    return get_default_action(alert)
