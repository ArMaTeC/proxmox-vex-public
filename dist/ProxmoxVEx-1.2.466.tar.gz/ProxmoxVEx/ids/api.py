# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/ids/api.py
# Project:     ProxmoxVEx
# Version:     1.2.460
# Build:       2026.09.16
# Description: Flask blueprint for the IDS/IPS module.
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-16
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Flask blueprint for the IDS/IPS module."""

import json
import logging
from datetime import datetime, timedelta, timezone
from typing import Optional

from flask import Blueprint, jsonify, request
from flask.globals import app_ctx

from ProxmoxVEx.core.db import get_db
from ProxmoxVEx.ids import actions, capture, converter, feed, models, reports, rules, scheduler
from ProxmoxVEx.utils.auth import require_auth

logger = logging.getLogger(__name__)

bp = Blueprint("ids", __name__)


def _actor() -> str:
    return getattr(request, "session", {}).get("username", "unknown")


def _json_body():
    """Parse the request JSON body.

    Returns (data, error_response). Distinguishes a malformed body (400,
    "Invalid JSON") from an absent one ({}) so callers don't conflate a
    parse failure with empty input, and rejects non-object JSON that would
    crash `data.keys()`/`data.get()` downstream. On error paths data is
    still a dict (callers return early on error_response) so the return
    type stays non-Optional for static checkers.
    """
    data = request.get_json(silent=True)
    if data is None:
        if request.data:
            return {}, (jsonify({"error": "Invalid JSON body"}), 400)
        return {}, None
    if not isinstance(data, dict):
        return {}, (jsonify({"error": "JSON body must be an object"}), 400)
    return data, None


def _bool_to_int(value) -> int:
    return 1 if value else 0


def _segment_to_dict(row: dict) -> dict:
    return {
        "id": row["id"],
        "name": row["name"],
        "node_id": row["node_id"],
        "bridge": row["bridge"],
        "vlan": row["vlan"],
        "interface": row["interface"],
        "capture_mode": row["capture_mode"],
        "enabled": bool(row["enabled"]),
        "created_at": row["created_at"],
        "updated_at": row["updated_at"],
    }


@bp.route("/api/ids/status", methods=["GET"])
@require_auth()
def get_ids_status():
    """Health check endpoint for the IDS/IPS module."""
    return jsonify({"status": "ok", "module": "ids"})


@bp.route("/api/ids/segments", methods=["GET"])
@require_auth()
def list_segments():
    """List all monitored segments."""
    try:
        rows = models.list_segments()
        return jsonify([_segment_to_dict(r) for r in rows])
    except Exception:
        logger.exception("Failed to list IDS segments")
        return jsonify({"error": "Failed to list segments"}), 500


@bp.route("/api/ids/segments", methods=["POST"])
@require_auth()
def create_segment():
    """Create a new monitored segment and start capture if enabled."""
    data, _json_err = _json_body()
    if _json_err:
        return _json_err
    required = {"name"}
    missing = required - set(data.keys())
    if missing:
        return jsonify({"error": f"Missing fields: {', '.join(missing)}"}), 400

    try:
        segment_id = models.create_segment(data)
        if data.get("enabled", True):
            capture.start_capture_for_segment(segment_id, data.get("node_id", ""))
        log_ids_event("segment.created", _actor(), {"segment_id": segment_id, "name": data.get("name")})
        return jsonify({"id": segment_id}), 201
    except Exception:
        logger.exception("Failed to create IDS segment")
        return jsonify({"error": "Failed to create segment"}), 500


@bp.route("/api/ids/segments/<int:segment_id>", methods=["GET"])
@require_auth()
def get_segment(segment_id):
    """Get a single monitored segment."""
    try:
        row = models.get_segment(segment_id)
        if not row:
            return jsonify({"error": "Segment not found"}), 404
        return jsonify(_segment_to_dict(row))
    except Exception:
        logger.exception("Failed to get IDS segment")
        return jsonify({"error": "Failed to get segment"}), 500


@bp.route("/api/ids/segments/<int:segment_id>", methods=["PUT"])
@require_auth()
def update_segment(segment_id):
    """Update a monitored segment."""
    data, _json_err = _json_body()
    if _json_err:
        return _json_err
    try:
        if not models.get_segment(segment_id):
            return jsonify({"error": "Segment not found"}), 404
        changed = models.update_segment(segment_id, data)
        if not changed:
            return jsonify({"error": "No valid fields to update"}), 400
        row = models.get_segment(segment_id)
        if row is None:
            return jsonify({"error": "Segment not found"}), 404
        if row["enabled"]:
            capture.start_capture_for_segment(segment_id, row.get("node_id", ""))
        else:
            capture.stop_capture_for_segment(segment_id, "disabled")
        log_ids_event("segment.updated", _actor(), {"segment_id": segment_id})
        return jsonify(_segment_to_dict(row))
    except Exception:
        logger.exception("Failed to update IDS segment")
        return jsonify({"error": "Failed to update segment"}), 500


@bp.route("/api/ids/segments/<int:segment_id>", methods=["DELETE"])
@require_auth()
def delete_segment(segment_id):
    """Delete a monitored segment and stop capture."""
    try:
        if not models.get_segment(segment_id):
            return jsonify({"error": "Segment not found"}), 404
        capture.stop_capture_for_segment(segment_id, "deleted")
        models.delete_segment(segment_id)
        log_ids_event("segment.deleted", _actor(), {"segment_id": segment_id})
        return jsonify({"deleted": True})
    except Exception:
        logger.exception("Failed to delete IDS segment")
        return jsonify({"error": "Failed to delete segment"}), 500


def _alert_to_dict(row: dict) -> dict:
    return {
        "id": row["id"],
        "segment_id": row["segment_id"],
        "rule_id": row["rule_id"],
        "threat_type": row["threat_type"],
        "severity": row["severity"],
        "source": row["source"],
        "source_ip": row["source"],
        "destination": row["destination"],
        "target_ip": row["destination"],
        "context": row["context"],
        "action_taken": row["action_taken"],
        "created_at": row["created_at"],
        "resolved_at": row["resolved_at"],
    }


@bp.route("/api/ids/alerts", methods=["GET"])
@require_auth()
def list_alerts():
    """List IDS/IPS alerts with optional filters."""
    try:
        segment_id = request.args.get("segment_id", type=int)
        severity = request.args.get("severity")
        rows = models.list_alerts(segment_id=segment_id, severity=severity)
        return jsonify([_alert_to_dict(r) for r in rows])
    except Exception:
        logger.exception("Failed to list IDS alerts")
        return jsonify({"error": "Failed to list alerts"}), 500


@bp.route("/api/ids/alerts/<int:alert_id>", methods=["GET"])
@require_auth()
def get_alert(alert_id):
    """Get a single alert."""
    try:
        row = models.get_alert(alert_id)
        if not row:
            return jsonify({"error": "Alert not found"}), 404
        return jsonify(_alert_to_dict(row))
    except Exception:
        logger.exception("Failed to get IDS alert")
        return jsonify({"error": "Failed to get alert"}), 500


@bp.route("/api/ids/segments/<int:segment_id>/analyze", methods=["POST"])
@require_auth()
def analyze_segment(segment_id):
    """Run an analysis pass on supplied packet/flow data for a segment."""
    data, _json_err = _json_body()
    if _json_err:
        return _json_err
    packets = data.get("packets", [])
    if not packets:
        return jsonify({"error": "No packets provided"}), 400
    try:
        count = capture.process_packets(segment_id, packets)
        return jsonify({"alerts_created": count})
    except Exception:
        logger.exception("Failed to analyze segment %s", segment_id)
        return jsonify({"error": "Failed to analyze segment"}), 500


def _rule_to_dict(row: dict) -> dict:
    return {
        "id": row["id"],
        "name": row["name"],
        "enabled": bool(row["enabled"]),
        "rule_type": row["rule_type"],
        "signature": row["signature"],
        "anomaly_config": row["anomaly_config"],
        "severity": row["severity"],
        "threat_type": row["threat_type"],
        "description": row["description"],
        "created_by": row["created_by"],
        "updated_at": row["updated_at"],
    }


def _policy_to_dict(row: dict) -> dict:
    return {
        "id": row["id"],
        "name": row["name"],
        "segment_id": row["segment_id"],
        # rule_ids is stored as a JSON string, so decode it for the UI.
        "rule_ids": json.loads(row["rule_ids"] or "[]"),
        "default_action": row["default_action"],
        "enabled": bool(row["enabled"]),
        "created_at": row["created_at"],
        "updated_at": row["updated_at"],
    }


@bp.route("/api/ids/rules", methods=["GET"])
@require_auth()
def list_rules():
    """List IDS/IPS detection rules. Supports optional limit/offset pagination and search."""
    try:
        limit = request.args.get("limit", type=int)
        offset = request.args.get("offset", type=int)
        search = request.args.get("q", "").strip() or None
        if limit is not None and limit > 0:
            rows = models.list_rules(enabled_only=False, limit=limit, offset=offset or 0, search=search)
            total = models.count_rules(enabled_only=False, search=search)
            return jsonify({"rules": [_rule_to_dict(r) for r in rows], "total": total})
        rows = models.list_rules(enabled_only=False, search=search)
        return jsonify([_rule_to_dict(r) for r in rows])
    except Exception:
        logger.exception("Failed to list IDS rules")
        return jsonify({"error": "Failed to list rules"}), 500


@bp.route("/api/ids/rules/import", methods=["POST"])
@require_auth()
def import_rules():
    """Import a rule set. If no JSON body is supplied, the bundled default rule set is used."""
    data, _json_err = _json_body()
    if _json_err:
        return _json_err
    try:
        ruleset = data if data.get("rules") else rules.load_ruleset()
        count = rules.import_ruleset(ruleset, _actor())
        log_ids_event("rules.imported", _actor(), {"count": count})
        return jsonify({"imported": count})
    except Exception:
        logger.exception("Failed to import IDS rule set")
        return jsonify({"error": "Failed to import rule set"}), 500


def _version_is_newer(upstream: Optional[str], installed: Optional[str]) -> bool:
    """Return True when the upstream feed version is newer than the installed one."""
    if not upstream or not installed:
        return False
    try:
        return int(upstream) > int(installed)
    except ValueError:
        return upstream > installed


def _import_ruleset_archive(app, archive, created_by):
    """Run the heavy ruleset import in a real OS thread, inside an app context."""
    with app.app_context():
        return feed.import_ruleset_archive(archive, created_by)


@bp.route("/api/ids/feed/status", methods=["GET"])
@require_auth()
def feed_status():
    """Return the current state and upstream version of the IDS rule feed."""
    try:
        version = feed.get_latest_version()
        rule_count = models.count_rules(enabled_only=False)
        installed = scheduler.get_status().get("last_version")
        return jsonify({
            "available": version is not None,
            "version": version,
            "installed_version": installed,
            "newer": _version_is_newer(version, installed),
            "local_rule_count": rule_count,
            "default_url": feed.DEFAULT_RULESET_URL,
            "version_url": feed.DEFAULT_VERSION_URL,
        })
    except Exception:
        logger.exception("Failed to get IDS feed status")
        return jsonify({"error": "Failed to get feed status"}), 500


@bp.route("/api/ids/feed/update", methods=["POST"])
@require_auth()
def feed_update():
    """Download the latest ruleset and import it off the gevent hub so the server stays responsive."""
    data, _json_err = _json_body()
    if _json_err:
        return _json_err
    try:
        version = feed.get_latest_version(data.get("version_url", feed.DEFAULT_VERSION_URL))
        archive = feed.fetch_ruleset(data.get("ruleset_url", feed.DEFAULT_RULESET_URL))
        if archive is None:
            scheduler.record_import(version, 0, "Failed to download feed")
            return jsonify({"error": "Failed to download feed", "version": version}), 502
        # Unwrap the real Flask app via app_ctx.app — current_app is a
        # LocalProxy annotated as Flask in the Flask 3 stubs, so
        # _get_current_object() fails type checking; the import below runs
        # on a hub threadpool where an unbound proxy would raise anyway.
        app = app_ctx.app
        try:
            from gevent import get_hub  # type: ignore  # gevent ships no stubs; mypy ignores it via pyproject overrides

            result = get_hub().threadpool.apply(_import_ruleset_archive, (app, archive, _actor()))
        except Exception:
            # Gevent hub not available (e.g. CLI context); run inline as a fallback.
            result = _import_ruleset_archive(app, archive, _actor())
        result["version"] = version
        scheduler.record_import(version, result.get("imported", 0), result.get("error"))
        if "error" in result:
            return jsonify(result), 502
        log_ids_event("feed.updated", _actor(), {"imported": result.get("imported"), "version": result.get("version")})
        return jsonify(result)
    except Exception:
        logger.exception("Failed to update IDS rule feed")
        return jsonify({"error": "Failed to update rule feed"}), 500


@bp.route("/api/ids/feed/convert", methods=["POST"])
@require_auth()
def feed_convert():
    """Convert a Suricata/Snort .rules text without importing."""
    data, _json_err = _json_body()
    if _json_err:
        return _json_err
    text = data.get("rules_text", "")
    if not text:
        return jsonify({"error": "No rules_text provided"}), 400
    try:
        converted, skipped = converter.convert_rules(text)
        return jsonify({
            "imported": 0,
            "converted": len(converted),
            "skipped": len(skipped),
            "rules": converted[:100],
            "skipped_reasons": skipped[:20],
        })
    except Exception:
        logger.exception("Failed to convert IDS rules text")
        return jsonify({"error": "Failed to convert rules"}), 500


@bp.route("/api/ids/feed/schedule", methods=["GET"])
@require_auth()
def feed_schedule_status():
    """Return the IDS rule feed auto-update schedule status."""
    try:
        return jsonify(scheduler.get_status())
    except Exception:
        logger.exception("Failed to get IDS feed schedule status")
        return jsonify({"error": "Failed to get schedule status"}), 500


@bp.route("/api/ids/feed/schedule", methods=["POST"])
@require_auth()
def feed_schedule_update():
    """Enable or disable automatic rule feed updates."""
    data, _json_err = _json_body()
    if _json_err:
        return _json_err
    try:
        status = scheduler.configure(
            enabled=bool(data.get("enabled", True)),
            interval_hours=int(data.get("interval_hours", 24)),
        )
        log_ids_event("feed.schedule", _actor(), status)
        return jsonify(status)
    except Exception:
        logger.exception("Failed to update IDS feed schedule")
        return jsonify({"error": "Failed to update schedule"}), 500


@bp.route("/api/ids/rules", methods=["POST"])
@require_auth()
def create_rule():
    """Create a new detection rule."""
    data, _json_err = _json_body()
    if _json_err:
        return _json_err
    if not data.get("name"):
        return jsonify({"error": "Missing rule name"}), 400
    try:
        rule_id = models.create_rule(data, _actor())
        log_ids_event("rule.created", _actor(), {"rule_id": rule_id})
        return jsonify({"id": rule_id}), 201
    except Exception:
        logger.exception("Failed to create IDS rule")
        return jsonify({"error": "Failed to create rule"}), 500


@bp.route("/api/ids/rules/<int:rule_id>", methods=["PUT"])
@require_auth()
def update_rule(rule_id):
    """Update a detection rule."""
    data, _json_err = _json_body()
    if _json_err:
        return _json_err
    try:
        if not models.get_rule(rule_id):
            return jsonify({"error": "Rule not found"}), 404
        models.update_rule(rule_id, data)
        log_ids_event("rule.updated", _actor(), {"rule_id": rule_id})
        row = models.get_rule(rule_id)
        if row is None:
            return jsonify({"error": "Rule not found"}), 404
        return jsonify(_rule_to_dict(row))
    except Exception:
        logger.exception("Failed to update IDS rule")
        return jsonify({"error": "Failed to update rule"}), 500


@bp.route("/api/ids/rules/<int:rule_id>", methods=["DELETE"])
@require_auth()
def delete_rule(rule_id):
    """Delete a detection rule."""
    try:
        if not models.get_rule(rule_id):
            return jsonify({"error": "Rule not found"}), 404
        models.delete_rule(rule_id)
        log_ids_event("rule.deleted", _actor(), {"rule_id": rule_id})
        return jsonify({"deleted": True})
    except Exception:
        logger.exception("Failed to delete IDS rule")
        return jsonify({"error": "Failed to delete rule"}), 500


@bp.route("/api/ids/policies", methods=["GET"])
@require_auth()
def list_policies():
    """List IDS/IPS response policies."""
    try:
        rows = models.list_policies()
        return jsonify([_policy_to_dict(r) for r in rows])
    except Exception:
        logger.exception("Failed to list IDS policies")
        return jsonify({"error": "Failed to list policies"}), 500


@bp.route("/api/ids/policies", methods=["POST"])
@require_auth()
def create_policy():
    """Create a new response policy."""
    data, _json_err = _json_body()
    if _json_err:
        return _json_err
    if not data.get("name"):
        return jsonify({"error": "Missing policy name"}), 400
    try:
        policy_id = models.create_policy(data)
        log_ids_event("policy.created", _actor(), {"policy_id": policy_id})
        return jsonify({"id": policy_id}), 201
    except Exception:
        logger.exception("Failed to create IDS policy")
        return jsonify({"error": "Failed to create policy"}), 500


@bp.route("/api/ids/policies/<int:policy_id>", methods=["PUT"])
@require_auth()
def update_policy(policy_id):
    """Update a response policy."""
    data, _json_err = _json_body()
    if _json_err:
        return _json_err
    try:
        if not models.get_policy(policy_id):
            return jsonify({"error": "Policy not found"}), 404
        models.update_policy(policy_id, data)
        log_ids_event("policy.updated", _actor(), {"policy_id": policy_id})
        row = models.get_policy(policy_id)
        if row is None:
            return jsonify({"error": "Policy not found"}), 404
        return jsonify(_policy_to_dict(row))
    except Exception:
        logger.exception("Failed to update IDS policy")
        return jsonify({"error": "Failed to update policy"}), 500


@bp.route("/api/ids/policies/<int:policy_id>", methods=["DELETE"])
@require_auth()
def delete_policy(policy_id):
    """Delete a response policy."""
    try:
        if not models.get_policy(policy_id):
            return jsonify({"error": "Policy not found"}), 404
        models.delete_policy(policy_id)
        log_ids_event("policy.deleted", _actor(), {"policy_id": policy_id})
        return jsonify({"deleted": True})
    except Exception:
        logger.exception("Failed to delete IDS policy")
        return jsonify({"error": "Failed to delete policy"}), 500


@bp.route("/api/ids/alerts/<int:alert_id>/actions", methods=["POST"])
@require_auth()
def take_alert_action(alert_id):
    """Apply a manual action to an alert."""
    data, _json_err = _json_body()
    if _json_err:
        return _json_err
    action = data.get("action")
    if not action:
        return jsonify({"error": "Missing action"}), 400
    try:
        if not models.get_alert(alert_id):
            return jsonify({"error": "Alert not found"}), 404
        ok = actions.apply_action(alert_id, action, _actor(), data.get("reason"))
        if not ok:
            return jsonify({"error": "Failed to apply action"}), 500
        log_ids_event("alert.action", _actor(), {"alert_id": alert_id, "action": action})
        return jsonify({"applied": True})
    except Exception:
        logger.exception("Failed to take action on alert %s", alert_id)
        return jsonify({"error": "Failed to take action"}), 500


@bp.route("/api/ids/segments/<int:segment_id>/re-evaluate", methods=["POST"])
@require_auth()
def re_evaluate_segment(segment_id):
    """Re-evaluate a segment with optional threshold overrides."""
    data, _json_err = _json_body()
    if _json_err:
        return _json_err
    packets = data.get("packets", [])
    thresholds = data.get("thresholds")
    if not packets:
        return jsonify({"error": "No packets provided"}), 400
    try:
        detected = rules.re_evaluate(segment_id, packets, thresholds)
        return jsonify({"alerts": detected})
    except Exception:
        logger.exception("Failed to re-evaluate segment %s", segment_id)
        return jsonify({"error": "Failed to re-evaluate segment"}), 500


@bp.route("/api/ids/rules/<int:rule_id>/tune", methods=["PUT"])
@require_auth()
def tune_rule(rule_id):
    """Update a rule's anomaly sensitivity thresholds."""
    data, _json_err = _json_body()
    if _json_err:
        return _json_err
    thresholds = data.get("thresholds", {})
    try:
        if not models.get_rule(rule_id):
            return jsonify({"error": "Rule not found"}), 404
        ok = rules.tune_rule(rule_id, thresholds)
        if not ok:
            return jsonify({"error": "Failed to tune rule"}), 400
        log_ids_event("rule.tuned", _actor(), {"rule_id": rule_id, "thresholds": thresholds})
        row = models.get_rule(rule_id)
        if row is None:
            return jsonify({"error": "Rule not found"}), 404
        return jsonify(_rule_to_dict(row))
    except Exception:
        logger.exception("Failed to tune rule %s", rule_id)
        return jsonify({"error": "Failed to tune rule"}), 500


def _report_window():
    start = request.args.get("start")
    end = request.args.get("end")
    hours = request.args.get("hours", type=float)
    if not start or not end:
        if not hours:
            return None, None
        now = datetime.now(timezone.utc)
        end = now.isoformat()
        start = (now - timedelta(hours=hours)).isoformat()
    return start, end


@bp.route("/api/ids/reports/summary", methods=["GET"])
@require_auth()
def report_summary():
    """Return a summary report for a time window."""
    start, end = _report_window()
    if not start or not end:
        return jsonify({"error": "Missing start/end or hours"}), 400
    try:
        return jsonify(reports.generate_summary(start, end))
    except Exception:
        logger.exception("Failed to generate summary report")
        return jsonify({"error": "Failed to generate report"}), 500


@bp.route("/api/ids/reports/timeline", methods=["GET"])
@require_auth()
def report_timeline():
    """Return a timeline of events for a time window."""
    start, end = _report_window()
    if not start or not end:
        return jsonify({"error": "Missing start/end or hours"}), 400
    try:
        return jsonify(reports.generate_timeline(start, end))
    except Exception:
        logger.exception("Failed to generate timeline report")
        return jsonify({"error": "Failed to generate report"}), 500


@bp.route("/api/ids/reports/export", methods=["GET"])
@require_auth()
def report_export():
    """Return a downloadable export for a time window."""
    start, end = _report_window()
    fmt = request.args.get("format", "json")
    if not start or not end:
        return jsonify({"error": "Missing start/end or hours"}), 400
    try:
        return jsonify(reports.generate_export(start, end, fmt))
    except Exception:
        logger.exception("Failed to generate export report")
        return jsonify({"error": "Failed to generate report"}), 500


@bp.route("/api/ids/audit", methods=["GET"])
@require_auth()
def list_audit():
    """Return the IDS/IPS audit log."""
    try:
        conn = get_db().conn
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM ids_audit_log ORDER BY id DESC")
        return jsonify([dict(row) for row in cursor.fetchall()])
    except Exception:
        logger.exception("Failed to list IDS audit log")
        return jsonify({"error": "Failed to list audit log"}), 500


def log_ids_event(event_type: str, actor: str, details: dict) -> None:
    """Record an IDS audit event."""
    try:
        models.log_ids_event(event_type, actor, details)
    except Exception:
        logger.exception("Failed to write IDS audit event")
