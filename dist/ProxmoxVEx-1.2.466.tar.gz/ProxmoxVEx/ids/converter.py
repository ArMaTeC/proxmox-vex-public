# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/ids/converter.py
# Project:     ProxmoxVEx
# Version:     1.2.453
# Build:       2026.09.14
# Description: Convert Suricata/Snort .rules files into ProxmoxVEx...
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-14
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Convert Suricata/Snort .rules files into ProxmoxVEx IDS/IPS JSON rules.

The converter extracts simple, port-based signatures. Rules that rely on
content/flow/PCRE options are skipped because the current engine matches on
packet/flow fields (source, destination, dport, sport, payload_size).
"""

import io
import logging
import re
import tarfile
from typing import Any, Dict, List, Tuple

logger = logging.getLogger(__name__)

# Port variables commonly found in ET/Snort rules.
_PORT_VARS = {
    "$HTTP_PORTS": [80, 81, 82, 83, 88, 443, 5555, 8000, 8080, 8081, 8443, 8888],
    "$HTTPS_PORTS": [443, 8443],
    "$SSH_PORTS": [22],
    "$TELNET_PORTS": [23],
    "$FTP_PORTS": [21, 20],
    "$DNS_PORTS": [53],
    "$SMTP_PORTS": [25, 465, 587],
    "$SHTTP_PORTS": [443],
    "$ORACLE_PORTS": [1521],
    "$MSSQL_PORTS": [1433],
    "$MYSQL_PORTS": [3306],
    "$POSTGRES_PORTS": [5432],
    "$SNMP_PORTS": [161, 162],
    "$LDAP_PORTS": [389, 636],
    "$SIP_PORTS": [5060, 5061],
    "$RDP_PORTS": [3389],
    "$VNC_PORTS": [5900, 5901, 5902],
    "$REDIS_PORTS": [6379],
    "$MONGO_PORTS": [27017, 27018, 27019],
    "$ELASTIC_PORTS": [9200, 9300],
    "$SMB_PORTS": [139, 445],
    "$NFS_PORTS": [2049],
    "$ISCSI_PORTS": [3260],
    "$KUBERNETES_PORTS": [6443],
    "$DOCKER_PORTS": [2375, 2376],
    "$ETCD_PORTS": [2379, 2380],
    "$KAFKA_PORTS": [9092],
    "$RABBIT_PORTS": [5672],
    "$PROMETHEUS_PORTS": [9090],
    "$GRAFANA_PORTS": [3000],
    "$JENKINS_PORTS": [8080, 8443],
    "$ZOOKEEPER_PORTS": [2181],
    "$MODBUS_PORTS": [502],
    "$BACNET_PORTS": [47808],
    "$IPMI_PORTS": [623],
    "$WINRM_PORTS": [5985, 5986],
    "$NTP_PORTS": [123],
}

# Severity mapping by classtype; lower index = more severe.
_SEVERITY_BY_CLASS = {
    "trojan-activity": "critical",
    "successful-admin": "high",
    "unsuccessful-admin": "high",
    "attempted-admin": "high",
    "successful-user": "high",
    "attempted-user": "medium",
    "network-scan": "medium",
    "denial-of-service": "high",
    "misc-attack": "medium",
    "web-application-attack": "high",
    "web-application-activity": "medium",
    "attempted-recon": "low",
    "misc-activity": "low",
    "policy-violation": "low",
    "protocol-anomaly": "medium",
    "attempted-dos": "high",
    "successful-dos": "critical",
    "attempted-recon-largescale": "medium",
    "not-suspicious": "low",
    "unknown": "low",
}

# Header: action proto src_var src_port dir dst_var dst_port
_HEADER_RE = re.compile(
    r"^(?P<action>\w+)\s+"
    r"(?P<proto>\w+)\s+"
    r"(?P<src>[^\s]+)\s+"
    r"(?P<sport>[^\s]+)\s+"
    r"(?P<dir>->|<>)\s+"
    r"(?P<dst>[^\s]+)\s+"
    r"(?P<dport>[^\s]+)\s*\((?P<options>.*)\)\s*$"
)


def _parse_options(options: str) -> Dict[str, str]:
    """Parse Suricata rule options into a dict (last duplicate wins)."""
    parsed: Dict[str, str] = {}
    # Semi-colon separated, but values may contain quoted semi-colons; keep simple.
    for part in re.split(r"(?<!');", options):
        part = part.strip()
        if not part:
            continue
        if ":" in part:
            key, value = part.split(":", 1)
            parsed[key.strip()] = value.strip().strip('"').strip("'")
    return parsed


def _resolve_port(token: str, direction: str) -> List[int]:
    """Return a list of integer ports if the token can be mapped for this direction."""
    token = token.strip()
    if token in _PORT_VARS:
        return _PORT_VARS[token]
    if token in ("any", "$HOME_NET", "$EXTERNAL_NET", "$HOME_NET", "$HTTP_SERVERS", "$SQL_SERVERS"):
        return []
    # Literal single port
    try:
        return [int(token)]
    except ValueError:
        # Port range like 1:1024 or list like [80,443]
        try:
            return [int(p) for p in re.split(r"[:,]", token) if p.strip().isdigit()]
        except ValueError:
            return []


def _severity(classtype: str, priority: str) -> str:
    if priority:
        try:
            p = int(priority)
            if p <= 1:
                return "critical"
            if p <= 2:
                return "high"
            if p <= 3:
                return "medium"
            return "low"
        except ValueError:
            pass
    return _SEVERITY_BY_CLASS.get(classtype, "medium")


def _threat_type(msg: str, classtype: str) -> str:
    # Prefer a short token from the message or classtype.
    if classtype:
        return classtype.split("-")[0]
    tokens = [t for t in re.split(r"[^a-zA-Z0-9_]", msg) if t]
    for t in tokens:
        if t.lower() in (
            "malware",
            "trojan",
            "c2",
            "scan",
            "brute",
            "ddos",
            "dos",
            "exploit",
            "shell",
            "web",
            "sql",
            "xss",
            "rce",
            "recon",
        ):
            return t.lower()
    return "suspicious"


def convert_rule(line: str) -> Dict[str, Any]:
    """Convert a single Suricata/Snort rule line into a ProxmoxVEx rule dict."""
    line = line.strip()
    if not line or line.startswith("#") or line.startswith("//"):
        raise ValueError("Comment or empty line")

    m = _HEADER_RE.match(line)
    if not m:
        raise ValueError("Could not parse rule header")

    options = _parse_options(m.group("options"))
    msg = options.get("msg", "Unknown rule")
    classtype = options.get("classtype", "")
    priority = options.get("priority", "")
    sid = options.get("sid", "")
    rev = options.get("rev", "")

    # PCRE, http_ and file.data options are not supported by the current engine.
    has_unsupported = any(k in options for k in ("pcre", "uricontent", "file.data", "http_"))
    if has_unsupported:
        raise ValueError("Rule uses PCRE/http_/file.data options not supported by the current engine")

    dports = _resolve_port(m.group("dport"), "dport")
    sports = _resolve_port(m.group("sport"), "sport")
    content = options.get("content", "")
    flow = options.get("flow", "")

    # Try to build a simple signature. Prefer dport, fall back to sport.
    conditions = []
    if dports:
        conditions.append(",".join(f"dport={p}" for p in dports))
    elif sports:
        conditions.append(",".join(f"sport={p}" for p in sports))

    if not conditions and not content:
        raise ValueError("No usable literal port or content in rule header")

    if content:
        conditions.append(f"content={content}")
    if flow and "to_server" in flow:
        conditions.append("flow=to_server")
    elif flow and "to_client" in flow:
        conditions.append("flow=to_client")

    signature = ";".join(conditions)

    sev = _severity(classtype, priority)
    threshold = 1 if sev in ("critical", "high") else 5 if sev == "medium" else 20

    return {
        "name": f"ET {sid}: {msg}"[:120] if sid else msg[:120],
        "enabled": True,
        "rule_type": "signature",
        "signature": signature,
        "anomaly_config": {"threshold": threshold, "source": "ET Open"},
        "severity": sev,
        "threat_type": _threat_type(msg, classtype),
        "description": f"{msg} (sid:{sid} rev:{rev}, classtype:{classtype})",
    }


def convert_rules(text: str) -> Tuple[List[Dict[str, Any]], List[Dict[str, str]]]:
    """Convert a multi-line .rules file. Returns (converted, skipped)."""
    converted: List[Dict[str, Any]] = []
    skipped: List[Dict[str, str]] = []
    seen_names = set()
    for line in text.splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        try:
            rule = convert_rule(line)
            # Deduplicate by name.
            if rule["name"] in seen_names:
                continue
            seen_names.add(rule["name"])
            converted.append(rule)
        except ValueError as e:
            skipped.append({"line": line[:120], "reason": str(e)})
    return converted, skipped


def convert_ruleset_archive(archive_bytes: bytes) -> Tuple[List[Dict[str, Any]], List[Dict[str, str]], List[str]]:
    """Extract and convert rules from a Suricata .tar.gz archive.

    Returns (converted_rules, skipped_infos, filenames).
    """
    converted: List[Dict[str, Any]] = []
    skipped: List[Dict[str, str]] = []
    filenames: List[str] = []
    seen_names = set()

    with tarfile.open(fileobj=io.BytesIO(archive_bytes), mode="r:gz") as tar:
        for member in tar.getmembers():
            if not member.isfile() or not member.name.endswith(".rules"):
                continue
            filenames.append(member.name)
            f = tar.extractfile(member)
            if not f:
                continue
            text = f.read().decode("utf-8", errors="replace")
            for line in text.splitlines():
                line = line.strip()
                if not line or line.startswith("#"):
                    continue
                try:
                    rule = convert_rule(line)
                    if rule["name"] in seen_names:
                        continue
                    seen_names.add(rule["name"])
                    converted.append(rule)
                except ValueError as e:
                    skipped.append({"file": member.name, "line": line[:120], "reason": str(e)})

    return converted, skipped, filenames
