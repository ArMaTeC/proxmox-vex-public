# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/ids/actions.py
# Project:     ProxmoxVEx
# Version:     1.2.460
# Build:       2026.09.16
# Description: Prevention action orchestration and audit logging for...
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-16
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Prevention action orchestration and audit logging for the IDS/IPS module."""

import logging
from datetime import datetime, timezone
from typing import Any, Dict, Optional

from ProxmoxVEx.core.db import get_db
from ProxmoxVEx.globals import _notification_handlers
from ProxmoxVEx.ids import models

logger = logging.getLogger(__name__)


def _fire_notification(alert: Dict[str, Any]) -> None:
    """Send the alert through any registered notification handlers."""
    if _notification_handlers:
        payload = {
            "id": str(alert.get("id", "")),
            "title": f"IDS Alert: {alert.get('threat_type', 'unknown')}",
            "body": f"Severity {alert.get('severity', 'unknown')} from {alert.get('source', '')}",
            "severity": alert.get("severity", "low"),
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }
        for handler in _notification_handlers:
            try:
                handler(payload)
            except Exception as e:
                logger.warning("Notification handler failed: %s", e)


def apply_action(alert_id: int, action: str, operator: Optional[str] = None, reason: Optional[str] = None) -> bool:
    """Apply a prevention action and log it."""
    logger.info("Applying %s for alert %s", action, alert_id)
    try:
        conn = get_db().conn
        cursor = conn.cursor()
        now = datetime.now(timezone.utc).isoformat()
        cursor.execute(
            "INSERT INTO ids_prevention_actions (alert_id, action_type, status, operator, reason, created_at, applied_at) VALUES (?, ?, ?, ?, ?, ?, ?)",
            (alert_id, action, "applied", operator, reason, now, now),
        )
        cursor.execute(
            "UPDATE ids_alerts SET action_taken = ? WHERE id = ?",
            (action, alert_id),
        )
        conn.commit()
        if action == "block":
            alert = models.get_alert(alert_id)
            if alert and alert.get("source"):
                models.block_ip(alert["source"], alert_id)
        alert = models.get_alert(alert_id)
        if alert:
            models.log_ids_event(
                "action.applied", operator or "system", {"alert_id": alert_id, "action": action, "reason": reason}
            )
            _fire_notification(alert)
        return True
    except Exception:
        logger.exception("Failed to apply action %s for alert %s", action, alert_id)
        return False


def log_action(alert_id: int, action: str, actor: str, details: Dict[str, Any]) -> None:
    """Record an immutable audit log for an action."""
    logger.info("Audit: %s on alert %s by %s", action, alert_id, actor)
    try:
        models.log_ids_event("action.audit", actor, {"alert_id": alert_id, "action": action, **details})
    except Exception:
        logger.exception("Failed to log action for alert %s", alert_id)
