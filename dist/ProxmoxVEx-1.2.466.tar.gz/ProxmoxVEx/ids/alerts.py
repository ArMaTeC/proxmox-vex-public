# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/ids/alerts.py
# Project:     ProxmoxVEx
# Version:     1.2.453
# Build:       2026.09.14
# Description: Alert creation and lifecycle helpers for the IDS/IPS...
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-14
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Alert creation and lifecycle helpers for the IDS/IPS module."""

import logging
from typing import Any, Dict

from ProxmoxVEx.ids import models, policies

logger = logging.getLogger(__name__)


def create_alert(alert_data: Dict[str, Any]) -> int:
    """Create a new alert and return its ID."""
    logger.info("Creating alert: %s", alert_data.get("threat_type"))
    if policies.should_suppress(alert_data):
        return 0
    try:
        return models.create_alert(alert_data)
    except Exception:
        logger.exception("Failed to create alert")
        return 0
