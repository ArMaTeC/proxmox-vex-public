# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/background/plugin_updates.py
# Project:     ProxmoxVEx
# Version:     1.2.460
# Build:       2026.09.16
# Description: Paid-plugin update checks against the license server.
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-16
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Paid-plugin update checks against the license server.

The "Check for updates" button in Settings → Plugins calls
``check_paid_plugin_updates``/``apply_paid_plugin_updates`` through the
``/api/plugins/updates/*`` endpoints. When ``plugin_auto_update`` is enabled
in server_settings, ``start_plugin_update_thread`` runs the same cycle every
``plugin_auto_update_interval_hours`` (default 24h): poll the license server
for newer artifacts, download and install them, and reload the affected
plugins in place.

Status is written back into server_settings (``plugin_updates_last_check_at``
/ ``plugin_updates_last_result``) so the UI can show when the last automatic
check ran and what it did.
"""

from __future__ import annotations

import json
import logging
import threading
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

# Re-read settings at this cadence so interval/enabled changes made in the UI
# take effect promptly instead of waiting out the full check interval.
_TICK_SECONDS = 60

# Give startup plugin reconciliation (load_enabled_plugins) and licence
# activation a head start before the first automatic check.
_STARTUP_DELAY_SECONDS = 120

_plugin_update_thread: threading.Thread | None = None
_stop_event = threading.Event()


def _load_settings() -> dict[str, Any]:
    from ProxmoxVEx.api.helpers import load_server_settings

    try:
        return load_server_settings() or {}
    except Exception:
        return {}


def _save_settings(settings: dict[str, Any]) -> None:
    from ProxmoxVEx.api.helpers import save_server_settings

    try:
        save_server_settings(settings)
    except Exception as exc:
        logger.warning("[PLUGINS] Could not persist plugin update status: %s", exc)


def _paid_plugin_candidates(db) -> list[dict[str, Any]]:
    """Paid catalog plugins worth checking: enabled in plugin_state or on disk.

    Enabled-but-missing plugins are included deliberately — for them the
    "update" is the initial license-verified download, so the apply pass also
    repairs plugins wiped by a container recreate.
    """
    from ProxmoxVEx.constants import PLUGINS_DIR

    catalog_file = Path(PLUGINS_DIR) / "directory.json"
    if not catalog_file.exists():
        return []
    try:
        catalog = json.loads(catalog_file.read_text(encoding="utf-8"))
    except Exception as exc:
        logger.warning("[PLUGINS] Could not read plugin catalog for update check: %s", exc)
        return []

    rows = db.query("SELECT plugin_id, enabled FROM plugin_state") or []
    enabled_ids = {r["plugin_id"] for r in rows if r.get("enabled")}

    candidates = []
    for entry in catalog.get("plugins", []):
        slug = entry.get("slug")
        if not slug or not (entry.get("is_paid") or entry.get("download_required")):
            continue
        installed = (Path(PLUGINS_DIR) / slug / "manifest.json").exists()
        enabled = slug in enabled_ids
        if installed or enabled:
            candidates.append({"id": slug, "installed": installed, "enabled": enabled})
    return candidates


def check_paid_plugin_updates(db, license_key: str) -> dict[str, dict[str, Any]]:
    """Check every enabled/installed paid plugin for a newer artifact.

    Returns ``{plugin_id: {update_available, latest_version, current_version,
    installed, enabled, error?}}``.
    """
    from ProxmoxVEx.models.plugin_integrity import get_plugin_integrity
    from ProxmoxVEx.services.plugin_delivery import PluginDeliveryService

    delivery = PluginDeliveryService()
    results: dict[str, dict[str, Any]] = {}
    for cand in _paid_plugin_candidates(db):
        pid = cand["id"]
        current = get_plugin_integrity(db.conn, pid)
        info = delivery.check_for_update(db, pid, license_key)
        entry: dict[str, Any] = {
            "update_available": bool(info.get("update_available")),
            "latest_version": info.get("latest_version"),
            "current_version": current["version"] if current else None,
            "installed": cand["installed"],
            "enabled": cand["enabled"],
        }
        if info.get("error"):
            entry["error"] = info["error"]
        results[pid] = entry
    return results


def apply_paid_plugin_updates(
    app,
    db,
    license_key: str,
    plugin_ids: list[str] | None = None,
) -> dict[str, dict[str, Any]]:
    """Download and install updates for the given plugins (or all pending).

    Plugins that were enabled (or loaded) are reloaded in place so the new
    artifact takes effect without a restart; their enabled state is preserved.
    Disabled-but-installed plugins get the new files but stay unloaded.
    """
    from ProxmoxVEx.services.plugin_delivery import PluginDeliveryService

    if plugin_ids is None:
        checks = check_paid_plugin_updates(db, license_key)
        targets = [pid for pid, r in checks.items() if r.get("update_available")]
    else:
        targets = list(plugin_ids)

    delivery = PluginDeliveryService()
    results: dict[str, dict[str, Any]] = {}
    for pid in targets:
        ok, err = delivery.install_update(db, pid, license_key)
        if ok:
            ok, err = _reload_if_enabled(app, db, pid)
        results[pid] = {"success": ok, "error": err or ""}
    return results


def _reload_if_enabled(app, db, pid: str) -> tuple[bool, str]:
    """Reload a plugin in place if it is enabled/was loaded; leave disabled ones alone."""
    # Imported lazily: api.plugins imports this module's helpers from endpoint
    # handlers, and a top-level import here would create a cycle.
    from ProxmoxVEx.api.plugins import (
        _loaded_plugins,
        _plugin_lock,
        _set_plugin_state,
        load_plugin,
        unload_plugin,
    )

    row = db.query_one("SELECT enabled FROM plugin_state WHERE plugin_id = ?", (pid,)) or {}
    with _plugin_lock:
        was_loaded = pid in _loaded_plugins
    if not was_loaded and not row.get("enabled"):
        return True, ""
    unload_plugin(pid, app)
    ok, err = load_plugin(app, pid)
    _set_plugin_state(pid, True, error=err)
    return ok, err


def run_plugin_update_cycle(app) -> dict[str, Any]:
    """One check+apply pass; records the outcome into server_settings."""
    from ProxmoxVEx.core.db import get_db
    from ProxmoxVEx.services.licensing import LicensingService

    settings = _load_settings()
    settings["plugin_updates_last_check_at"] = datetime.now(timezone.utc).isoformat()

    try:
        db = get_db()
    except Exception as exc:
        settings["plugin_updates_last_result"] = f"skipped: database unavailable ({exc})"
        _save_settings(settings)
        return {"skipped": "database unavailable"}

    ctx = LicensingService().get_context(db)
    if not ctx or not ctx.license_key:
        settings["plugin_updates_last_result"] = "skipped: no active license"
        _save_settings(settings)
        return {"skipped": "no active license"}

    checks = check_paid_plugin_updates(db, ctx.license_key)
    pending = [pid for pid, r in checks.items() if r.get("update_available")]
    results = apply_paid_plugin_updates(app, db, ctx.license_key, plugin_ids=pending)
    failed = {pid: r.get("error") for pid, r in results.items() if not r.get("success")}

    if pending:
        summary = f"{len(pending) - len(failed)} plugin update(s) applied"
        if failed:
            summary += f"; {len(failed)} failed ({', '.join(failed)})"
    else:
        summary = "all plugins up to date"
    settings["plugin_updates_last_result"] = summary
    _save_settings(settings)
    logger.info("[PLUGINS] Auto-update cycle finished: %s", summary)
    return {"checked": len(checks), "applied": results}


def _auto_update_loop(app) -> None:
    time.sleep(_STARTUP_DELAY_SECONDS)
    while not _stop_event.wait(_TICK_SECONDS):
        try:
            settings = _load_settings()
            if not settings.get("plugin_auto_update"):
                continue
            interval = max(1, int(settings.get("plugin_auto_update_interval_hours", 24) or 24))
            last_raw = settings.get("plugin_updates_last_check_at") or ""
            try:
                last = datetime.fromisoformat(last_raw) if last_raw else None
                if last and last.tzinfo is None:
                    last = last.replace(tzinfo=timezone.utc)
            except ValueError:
                last = None
            if last and (datetime.now(timezone.utc) - last).total_seconds() < interval * 3600:
                continue
            run_plugin_update_cycle(app)
        except Exception as exc:
            logger.warning("[PLUGINS] Auto-update cycle failed: %s", exc)


def start_plugin_update_thread(app) -> None:
    """Start the daemon thread that polls the license server for plugin updates."""
    global _plugin_update_thread
    if _plugin_update_thread is None or not _plugin_update_thread.is_alive():
        _stop_event.clear()
        _plugin_update_thread = threading.Thread(
            target=_auto_update_loop,
            args=(app,),
            daemon=True,
            name="plugin-update-check",
        )
        _plugin_update_thread.start()
        logging.info("Plugin auto-update thread started")
