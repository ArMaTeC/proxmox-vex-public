/* --- ProxmoxVEx auto-header start ---
 * -------------------------------------------------------------------
 * File:        plugins/client_portal/portal.js
 * Project:     ProxmoxVEx
 * Version:     1.2.453
 * Build:       2026.09.14
 * Description: Portal JS source
 * Docs:        https://proxmoxvex.com/docs
 * Generated:   2026-09-14
 * -------------------------------------------------------------------
 * --- ProxmoxVEx auto-header end --- */
const params = new URLSearchParams(window.location.search);
document.body.dataset.theme = params.get('theme') || 'modern-dark';

const API = window.location.origin + '/api/plugins/client_portal/api';
let cfg = {};
let vms = [];

const app = document.getElementById('app');
const panel = document.getElementById('panel');
const brandingBtn = document.getElementById('brandingBtn');

const i18n = window.parent && window.parent.ProxmoxVExI18n;
const t = (k, p) => i18n ? i18n.getT('client_portal')(k, p ? { params: p } : undefined) : k;
if (i18n) i18n.loadPluginNamespaceFull('client_portal', '/api/plugins/client_portal/i18n');

function showError(msg) {
    const el = document.getElementById('error');
    if (el) el.textContent = msg;
}

async function api(url, opts = {}) {
    const res = await fetch(url, {
        credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        ...opts
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(data.error || res.statusText);
    return data;
}

function allowed(action) {
    return (cfg.allowed_actions || []).includes(action);
}

async function load() {
    try {
        cfg = await api(API + '/config');
        const data = await api(API + '/my-vms');
        if (data.redirect) {
            app.innerHTML = '<div class="info">' + t('clientOnly') + '</div>';
            return;
        }
        vms = data.vms || [];
        const userEl = document.getElementById('user');
        if (userEl) userEl.textContent = t('loggedInAs', { user: data.user || t('unknown') });
        const titleEl = document.getElementById('title');
        if (titleEl) titleEl.textContent = cfg.portal_title || t('title');
        if (brandingBtn) {
            brandingBtn.textContent = t('branding');
            brandingBtn.onclick = openBranding;
        }
        if (panel) panel.innerHTML = '';
        render();
    } catch (e) {
        showError(t('error', { msg: e.message }));
    }
}

function render() {
    if (!vms.length) {
        app.innerHTML = '<div class="info">' + t('noAssignedVms') + '</div>';
        return;
    }
    app.innerHTML = DOMPurify.sanitize('<div class="grid">' + vms.map(vm => {
        const ips = (vm.ips || []).join(', ');
        const statusClass = 'status ' + (vm.status === 'running' ? 'running' : 'stopped');
        const usage = cfg.show_resource_usage
            ? `${t('cpu')}: ${escapeHtml(vm.cpu_percent || 0)}% · ${t('ram')}: ${escapeHtml(vm.mem_percent || 0)}%`
            : '';
        return `<div class="card" data-vmid="${escapeHtml(vm.vmid)}">
                    <div class="title">${escapeHtml(vm.name)} <span class="meta">(VMID ${escapeHtml(vm.vmid)})</span></div>
                    <div class="meta">${escapeHtml(vm.cluster_name)} · ${escapeHtml(vm.node)}</div>
                    <div class="${statusClass}">${escapeHtml(vm.status)}</div>
                    <div class="meta">${usage}</div>
                    ${ips ? '<div class="meta">' + t('ip') + ': ' + escapeHtml(ips) + '</div>' : ''}
                    <div class="actions">
                        ${allowed('vm.start') ? `<button data-action="start" data-name="${escapeHtml(vm.name)}" data-cluster="${escapeHtml(vm.cluster_id)}" data-vmid="${escapeHtml(vm.vmid)}">${t('start')}</button>` : ''}
                        ${allowed('vm.stop') ? `<button class="secondary" data-action="stop" data-name="${escapeHtml(vm.name)}" data-cluster="${escapeHtml(vm.cluster_id)}" data-vmid="${escapeHtml(vm.vmid)}">${t('stop')}</button>` : ''}
                        ${allowed('vm.start') ? `<button class="secondary" data-action="reboot" data-name="${escapeHtml(vm.name)}" data-cluster="${escapeHtml(vm.cluster_id)}" data-vmid="${escapeHtml(vm.vmid)}">${t('reboot')}</button>` : ''}
                        ${allowed('vm.console') ? `<button class="secondary" data-action="console" data-name="${escapeHtml(vm.name)}" data-cluster="${escapeHtml(vm.cluster_id)}" data-vmid="${escapeHtml(vm.vmid)}">${t('console')}</button>` : ''}
                        ${cfg.allow_snapshots ? `<button class="secondary" data-action="snapshots" data-name="${escapeHtml(vm.name)}" data-cluster="${escapeHtml(vm.cluster_id)}" data-vmid="${escapeHtml(vm.vmid)}">${t('snapshots')}</button>` : ''}
                    </div>
                </div>`;
    }).join('') + '</div>');
    wireButtons();
}

function wireButtons() {
    app.querySelectorAll('button[data-action]').forEach(btn => {
        btn.addEventListener('click', function (e) {
            const clusterId = e.currentTarget.dataset.cluster;
            const vmid = parseInt(e.currentTarget.dataset.vmid, 10);
            const action = e.currentTarget.dataset.action;
            const name = e.currentTarget.dataset.name;
            if (action === 'console') openConsole(clusterId, vmid);
            else if (action === 'snapshots') openSnapshots(clusterId, vmid);
            else power(clusterId, vmid, action, name);
        });
    });
}

function escapeHtml(s) {
    const div = document.createElement('div');
    div.textContent = s;
    return div.innerHTML;
}

function confirmAction(action, name) {
    const key = action === 'reboot' ? 'confirmReboot' : 'confirmStop';
    return window.confirm(t(key, { name: name || '' }));
}

async function power(clusterId, vmid, action, name) {
    if (['stop', 'shutdown', 'reboot'].includes(action)) {
        if (!confirmAction(action, name)) return;
    }
    try {
        await api(API + '/vm/power', {
            method: 'POST',
            body: JSON.stringify({ cluster_id: clusterId, vmid: vmid, action })
        });
        if (panel) panel.innerHTML = '';
        await load();
    } catch (e) {
        showError(e.message);
    }
}

function isAllowedUrl(u) {
    try {
        const parsed = new URL(u, window.location.href);
        return parsed.protocol === 'http:' || parsed.protocol === 'https:';
    } catch (_) {
        return false;
    }
}

async function openConsole(clusterId, vmid) {
    try {
        const data = await api(API + '/console/handoff', {
            method: 'POST',
            body: JSON.stringify({
                cluster_id: clusterId,
                vmid: vmid,
                origin: window.parent && window.parent.location ? window.parent.location.origin : window.location.origin,
                target_cluster: clusterId,
                target_vmid: vmid
            })
        });
        const consoleUrl = data.console_url || data.url;
        if (consoleUrl && isAllowedUrl(consoleUrl)) {
            window.open(consoleUrl, '_blank', 'noopener,noreferrer');
        } else if (consoleUrl) {
            showError(t('consoleRejected'));
        } else {
            showError(t('consoleNotAvailable'));
        }
    } catch (e) {
        showError(e.message);
    }
}

async function openSnapshots(clusterId, vmid) {
    try {
        const data = await api(API + '/vm/snapshot-quota?cluster_id=' + encodeURIComponent(clusterId) + '&vmid=' + encodeURIComponent(vmid));
        const list = (data.snapshots || []).map(s => '<li>' + escapeHtml(s.name || s.snapname || 'snapshot') + '</li>').join('');
        const quota = t('snapshotQuota', { count: data.count || 0, max: data.max || 0 });
        if (panel) {
            panel.innerHTML = DOMPurify.sanitize(
                '<div class="panel-header"><strong>' + t('snapshots') + ' (VMID ' + escapeHtml(vmid) + ')</strong></div>' +
                '<div class="meta">' + escapeHtml(quota) + '</div>' +
                (list ? '<ul>' + list + '</ul>' : '<div class="info">' + t('noSnapshots') + '</div>')
            );
        }
    } catch (e) {
        showError(e.message);
    }
}

async function openBranding() {
    try {
        const data = await api(API + '/branding');
        const actions = (data.allowed_actions || []).map(a => '<li>' + escapeHtml(a) + '</li>').join('');
        if (panel) {
            panel.innerHTML = DOMPurify.sanitize(
                '<div class="panel-header"><strong>' + escapeHtml(data.portal_title || t('title')) + '</strong></div>' +
                '<div class="meta">' + t('allowedActions') + '</div>' +
                (actions ? '<ul>' + actions + '</ul>' : '<div class="info">' + t('noAssignedVms') + '</div>')
            );
        }
    } catch (e) {
        showError(e.message);
    }
}

(async () => {
    if (i18n) await i18n.loadPluginNamespaceFull('client_portal', '/api/plugins/client_portal/i18n');
    await load();
    setInterval(load, (cfg.refresh_interval || 30) * 1000);
})();
