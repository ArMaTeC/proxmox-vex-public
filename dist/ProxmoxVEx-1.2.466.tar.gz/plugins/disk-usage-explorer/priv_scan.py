# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        plugins/disk-usage-explorer/priv_scan.py
# Project:     ProxmoxVEx
# Version:     1.2.453
# Build:       2026.09.14
# Description: Long-lived privileged scandir helper for the Disk Usage...
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-14
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Long-lived privileged scandir helper for the Disk Usage Explorer plugin.

Started once by fs_scan.py via sudo and kept alive for the lifetime of the
scan. Reads JSON requests from stdin, each containing a path to list, and
writes a single JSON response line with the directory entries and their stat
info. Never follows symlinks.
"""

import fnmatch
import json
import os
import sys


def _is_excluded(name, patterns):
    return any(fnmatch.fnmatch(name, p) for p in patterns)


def _scan(path, excluded):
    entries = []
    try:
        with os.scandir(path) as it:
            for e in it:
                if _is_excluded(e.name, excluded):
                    continue
                try:
                    s = e.stat(follow_symlinks=False)
                except OSError:
                    continue
                entries.append({
                    "name": e.name,
                    "path": e.path,
                    "st_mode": s.st_mode,
                    "st_size": s.st_size,
                    "st_mtime": s.st_mtime,
                    "st_blocks": getattr(s, "st_blocks", None),
                })
    except OSError as exc:
        return {"error": str(exc)}
    return {"entries": entries}


def main():
    # Readiness sentinel: the parent waits for this line so any noise sudo/PAM
    # writes to stdout before the helper starts (e.g. "sudo: unable to resolve
    # host ...") is consumed during startup instead of corrupting responses.
    print(json.dumps({"ready": True}), flush=True)
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        try:
            req = json.loads(line)
        except json.JSONDecodeError:
            continue
        if req.get("cmd") == "close":
            break
        path = req.get("path")
        excluded = req.get("excluded") or []
        if path is None:
            print(json.dumps({"error": "missing path", "path": None}), flush=True)
            continue
        resp = _scan(path, excluded)
        # Echo the requested path so the parent can detect a desynchronized
        # stream instead of silently attributing one directory's listing to
        # another.
        resp["path"] = path
        print(json.dumps(resp), flush=True)


if __name__ == "__main__":
    main()
