This is the default sandboxed root for the Disk Usage Explorer plugin.
Add real host paths to 'allowed_roots' in this plugin's settings to browse more.
