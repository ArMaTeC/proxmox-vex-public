# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/native/zabbix/zabbix_src/collectors/hosts.py
# Project:     ProxmoxVEx
# Version:     1.2.535
# Build:       2026.09.26
# Description: Hosts collector for Zabbix.
# Usage:       import
#              ProxmoxVEx.native.zabbix.zabbix_src.collectors.hosts
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-26
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Hosts collector for Zabbix."""

from __future__ import annotations

from typing import Any

from zabbix_src.client import ZabbixClient


def collect_hosts(client: ZabbixClient) -> dict[str, Any]:
    """Return Zabbix hosts as an ``{'ok': True, 'data': [...]}`` shape."""
    return client.list_hosts()
