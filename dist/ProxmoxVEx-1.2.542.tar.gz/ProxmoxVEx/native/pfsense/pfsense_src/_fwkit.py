# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/native/pfsense/pfsense_src/_fwkit.py
# Project:     ProxmoxVEx
# Version:     1.2.535
# Build:       2026.09.26
# Description: Resolve `ProxmoxVEx.native.fwkit` for the pfSense
#              plugin modules.
# Usage:       import ProxmoxVEx.native.pfsense.pfsense_src._fwkit
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-26
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Resolve `ProxmoxVEx.native.fwkit` for the pfSense plugin modules.

Inside the app `ProxmoxVEx` is already importable; in unit-test/lint
contexts only the plugin dir is on sys.path, so we add the repo project
root (the dir that contains the `ProxmoxVEx` package) ourselves.
"""

import os
import sys


def ensure_fwkit_importable() -> None:
    try:
        import ProxmoxVEx.native.fwkit  # noqa: F401

        return
    except ImportError:
        pass
    # file: native/pfsense/pfsense_src/_fwkit.py → project root is 5 levels up
    root = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", "..", ".."))
    if root not in sys.path:
        sys.path.insert(0, root)
