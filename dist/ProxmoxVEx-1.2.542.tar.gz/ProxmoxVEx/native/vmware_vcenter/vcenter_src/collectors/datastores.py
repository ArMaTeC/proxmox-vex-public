# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/native/vmware_vcenter/vcenter_src/collectors/datastores.py
# Project:     ProxmoxVEx
# Version:     1.2.535
# Build:       2026.09.26
# Description: Datastore collector for vCenter.
# Usage:       import ProxmoxVEx.native.vmware_vcenter.vcenter_src.col
#              lectors.datastores
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-26
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Datastore collector for vCenter."""

from __future__ import annotations

from typing import Any

from vcenter_src.client import VCenterClient


def collect_datastores(client: VCenterClient) -> dict[str, Any]:
    """Return all vCenter datastores."""
    return client.list_datastores()
