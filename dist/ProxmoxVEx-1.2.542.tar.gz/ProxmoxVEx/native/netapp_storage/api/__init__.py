# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/native/netapp_storage/api/__init__.py
# Project:     ProxmoxVEx
# Version:     1.2.535
# Build:       2026.09.26
# Description: Package initializer for api
# Usage:       import ProxmoxVEx.native.netapp_storage.api
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-26
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
