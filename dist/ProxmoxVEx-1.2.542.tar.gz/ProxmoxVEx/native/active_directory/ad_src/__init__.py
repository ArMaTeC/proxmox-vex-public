# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/native/active_directory/ad_src/__init__.py
# Project:     ProxmoxVEx
# Version:     1.2.535
# Build:       2026.09.26
# Description: Active Directory source package.
# Usage:       import ProxmoxVEx.native.active_directory.ad_src
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-26
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Active Directory source package."""

from __future__ import annotations
