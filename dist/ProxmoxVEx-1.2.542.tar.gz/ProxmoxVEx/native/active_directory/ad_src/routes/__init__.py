# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/native/active_directory/ad_src/routes/__init__.py
# Project:     ProxmoxVEx
# Version:     1.2.535
# Build:       2026.09.26
# Description: Read-only route payload builders for Active Directory.
# Usage:       import ProxmoxVEx.native.active_directory.ad_src.routes
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-26
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Read-only route payload builders for Active Directory."""

from __future__ import annotations

from .overview import (  # noqa: F401
    build_groups_payload,
    build_overview_payload,
    build_users_payload,
)
