# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/native/active_directory/ad_src/client/__init__.py
# Project:     ProxmoxVEx
# Version:     1.2.535
# Build:       2026.09.26
# Description: Active Directory LDAP client package.
# Usage:       import ProxmoxVEx.native.active_directory.ad_src.client
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-26
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Active Directory LDAP client package."""

from __future__ import annotations

from .ldap_client import (  # noqa: F401
    ADClient,
    ADHost,
)
