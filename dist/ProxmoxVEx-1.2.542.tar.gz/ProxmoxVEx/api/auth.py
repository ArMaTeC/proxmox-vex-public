# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/api/auth.py
# Project:     ProxmoxVEx
# Version:     1.2.535
# Build:       2026.09.26
# Description: auth routes (login, logout, 2FA, OIDC, API tokens) -
#              split from monolith dec 2025
# Usage:       import ProxmoxVEx.api.auth
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-26
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""auth routes (login, logout, 2FA, OIDC, API tokens) - split from monolith dec 2025,"""

import base64
import contextlib
import hashlib
import logging
import secrets
import time
from datetime import datetime

# Removed add_allowed_origin import (no longer auto-adding on login)
import requests
from flask import Blueprint, jsonify, make_response, request

from ProxmoxVEx.api.helpers import (
    effective_reverse_proxy,
    get_login_settings,
    get_session_timeout,
    load_server_settings,
)
from ProxmoxVEx.constants import RESERVED_ADMIN_USERNAME, ProxmoxVEx_VERSION
from ProxmoxVEx.core.db import get_db
from ProxmoxVEx.globals import (
    cluster_managers,
    login_attempts_by_ip,
    login_attempts_by_user,
)
from ProxmoxVEx.models.permissions import ROLE_ADMIN, ROLE_VIEWER
from ProxmoxVEx.utils.audit import get_client_ip, log_audit
from ProxmoxVEx.utils.auth import (
    TOTP_AVAILABLE,
    create_api_token,
    create_initial_admin,
    create_session,
    dummy_verify_password,
    ensure_api_tokens_table,
    get_user_record,
    hash_password,
    invalidate_all_sessions,
    invalidate_all_user_sessions,
    invalidate_session,
    is_initialized,
    list_user_tokens,
    mark_admin_initialized,
    needs_password_rehash,
    require_auth,
    revoke_api_token,
    save_user_record,
    save_users,
    validate_password_policy,
    validate_session,
    verify_password,
)
from ProxmoxVEx.utils.ldap import get_ldap_settings, ldap_authenticate, ldap_provision_user
from ProxmoxVEx.utils.oidc import (
    get_oidc_endpoints,
    get_oidc_settings,
    oidc_build_auth_url,
    oidc_decode_id_token,
    oidc_exchange_code,
    oidc_get_user_groups,
    oidc_get_user_info,
    oidc_map_groups_to_role,
    oidc_provision_user,
)
from ProxmoxVEx.utils.rbac import DEFAULT_TENANT_ID, get_user_permissions
from ProxmoxVEx.utils.sanitization import sanitize_identifier, sanitize_log_message, sanitize_username
from ProxmoxVEx.utils.ssh import check_auth_action_rate_limit
from ProxmoxVEx.utils.trusted_devices import (
    check_trusted_device,
    issue_trusted_device,
    revoke_all_trusted_devices,
    revoke_trusted_devices,
)
from ProxmoxVEx.utils.url_security import SsrfError, sanitize_outbound_url

# Optional 2FA deps (pyotp/qrcode/io) are imported locally at each use site,
# after the TOTP_AVAILABLE guard — that keeps the names unconditionally bound
# where used (module-level try/except imports leave them possibly unbound).
bp = Blueprint("auth", __name__)


def _req_session() -> dict:
    # require_auth attaches request.session at runtime (utils/auth.py); the
    # attribute isn't on Flask's Request type, so read it via getattr.
    return getattr(request, "session", {}) or {}


def _user_has_mfa_factor(username, user) -> bool:
    """True when the user has any usable second factor (TOTP or a WebAuthn
    credential). Must agree with _mfa_enrollment_block's notion of enrolled so
    the requires_2fa_setup flag and the server-side confinement don't diverge."""
    if user.get("totp_enabled") and user.get("totp_secret"):
        return True
    try:
        row = get_db().query_one(
            "SELECT COUNT(*) AS n FROM webauthn_credentials WHERE username = ?", (username,)
        )
        return bool(row and row["n"] > 0)
    except Exception:
        return False


def _safe_user_tour(username) -> dict:
    """Guided-tour blob for auth payloads. Non-critical enrichment: a DB
    hiccup must not break login/session-restore, so any failure yields {}."""
    try:
        return get_db().get_user_tour(username)
    except Exception:
        return {}


def _requires_2fa_setup(username, user, role, settings) -> bool:
    """Spec 038 global force_2fa + spec 088 role-scoped enforcement.

    force_2fa_exclude_admins only relaxes the global switch; a role listed in
    force_2fa_roles is deliberate and always enforced."""
    if not TOTP_AVAILABLE:
        return False
    if user.get("auth_source", "local") in ("oidc", "entra"):
        return False
    is_admin = role == ROLE_ADMIN
    enforced = (
        bool(settings.get("force_2fa")) and not (is_admin and settings.get("force_2fa_exclude_admins"))
    ) or (role in (settings.get("force_2fa_roles") or []))
    return enforced and not _user_has_mfa_factor(username, user)


_RECOVERY_CODE_COUNT = 8


def _generate_recovery_codes():
    """Return (plaintext_codes, sha256_hashes). 10-hex-char codes are visually
    distinct from 6-digit TOTP; only hashes are stored so a users-db leak
    doesn't hand out working factors."""
    plain = [secrets.token_hex(5) for _ in range(_RECOVERY_CODE_COUNT)]
    return plain, [hashlib.sha256(c.encode()).hexdigest() for c in plain]


def _consume_recovery_code(user, code) -> bool:
    """Burn a stored recovery-code hash — each works exactly once (SC-002)."""
    hashes = user.get("totp_recovery_codes") or []
    digest = hashlib.sha256(str(code).strip().lower().encode()).hexdigest()
    if digest not in hashes:
        return False
    hashes.remove(digest)
    user["totp_recovery_codes"] = hashes
    return True


# ============================================================================


@bp.route("/api/auth/oidc/authorize", methods=["GET"])
def oidc_authorize():
    """Initiate OIDC login flow - redirects user to identity provider

    Generates CSRF state, stores in session, redirects to IdP
    """
    config = get_oidc_settings()
    if not config["enabled"] or not config["client_id"]:
        return jsonify({"error": "OIDC authentication is not configured"}), 400

    # Auto-detect redirect URI if not configured
    # never use Origin header - attacker can spoof it to steal OAuth tokens
    if not config.get("redirect_uri"):
        from ProxmoxVEx.utils.audit import _is_trusted_proxy

        base_url = request.host_url.rstrip("/")
        # Only honour X-Forwarded-* when the direct peer is a trusted proxy —
        # otherwise a client can spoof these headers and turn the OIDC
        # callback into an open redirect / phishing surface.
        if _is_trusted_proxy(request.remote_addr) and request.headers.get("X-Forwarded-Proto") == "https":
            fwd_host = request.headers.get("X-Forwarded-Host") or request.headers.get("Host") or request.host
            base_url = f"https://{fwd_host.split(',')[0].strip()}"
        config["redirect_uri"] = f"{base_url}/oidc/callback"
        logging.info(f"[OIDC] Auto-detected redirect_uri: {config['redirect_uri']}")

    # Generate state for CSRF protection
    state = secrets.token_urlsafe(32)

    # Store state in a temporary way (cookie-based since no session yet)
    auth_url, nonce, code_verifier = oidc_build_auth_url(config, state)

    # lgtm[py/server-information-exposure]
    response = make_response(jsonify({"auth_url": auth_url}))
    from ProxmoxVEx.utils.audit import _is_trusted_proxy

    is_secure = request.is_secure or (
        _is_trusted_proxy(request.remote_addr) and request.headers.get("X-Forwarded-Proto") == "https"
    )

    # #188: store state + nonce + PKCE code_verifier in cookie
    # Append redirect_after for portal OIDC flow
    # 2026-05-31 - defense-in-depth: `startswith('/')` allows `//attacker.com`
    # (protocol-relative URL), bypassing the intent. Require single leading
    # slash + reject any embedded `//`, `\\`, control chars, or fragment-like
    # constructs. Net effect: only same-origin internal paths get persisted.
    def _safe_internal_path(p):
        return (
            p
            and isinstance(p, str)
            and len(p) <= 200
            and p.startswith("/")
            and not p.startswith("//")
            and not p.startswith("/\\")
            and not any(c in p for c in ("\r", "\n", "\t", "\\"))
        )

    redirect_after = request.args.get("redirect_after", "")
    cookie_val = f"{state}:{nonce}:{code_verifier}"
    if _safe_internal_path(redirect_after):
        cookie_val += f":{redirect_after}"
    response.set_cookie("oidc_state", cookie_val, httponly=True, secure=is_secure, samesite="Lax", max_age=600)
    return response


@bp.route("/api/auth/oidc/callback", methods=["GET"])
def oidc_callback_redirect():
    """Safety net - if IdP sends GET to API callback URL, redirect to frontend SPA route"""
    from flask import redirect as flask_redirect

    return flask_redirect(f"/oidc/callback?{request.query_string.decode()}")


@bp.route("/api/auth/oidc/callback", methods=["POST"])
def oidc_callback():
    """Handle OIDC callback - exchange code for tokens and create session

    Called by frontend after redirect back from IdP
    Frontend sends: {code, state} from URL query params
    """
    # Use centralized IP resolution (respects trusted_proxies)
    client_ip = get_client_ip()
    oidc_cb_key = f"oidc_cb_{client_ip}"
    if oidc_cb_key in login_attempts_by_ip:
        attempts = login_attempts_by_ip[oidc_cb_key].get("attempts", [])
        recent = [t for t in attempts if time.time() - t < 60]
        if len(recent) >= 10:
            logging.warning(f"[OIDC] Rate limit hit for callback from {client_ip}")
            return jsonify({"error": "Too many attempts. Try again later."}), 429
        login_attempts_by_ip[oidc_cb_key] = {"attempts": recent + [time.time()]}
    else:
        login_attempts_by_ip[oidc_cb_key] = {"attempts": [time.time()]}

    config = get_oidc_settings()
    if not config["enabled"]:
        return jsonify({"error": "OIDC authentication is not configured"}), 400

    # Auto-detect redirect URI if not configured (must match what was sent in authorize!)
    if not config.get("redirect_uri"):
        from ProxmoxVEx.utils.audit import _is_trusted_proxy

        base_url = request.host_url.rstrip("/")
        # Same trusted-proxy gate as the authorize endpoint — never trust
        # client-supplied X-Forwarded-* headers from arbitrary clients.
        if _is_trusted_proxy(request.remote_addr) and request.headers.get("X-Forwarded-Proto") == "https":
            fwd_host = request.headers.get("X-Forwarded-Host") or request.headers.get("Host") or request.host
            base_url = f"https://{fwd_host.split(',')[0].strip()}"
        config["redirect_uri"] = f"{base_url}/oidc/callback"

    data = request.get_json() or {}
    code = data.get("code", "")
    state = data.get("state", "")

    if not code:
        return jsonify({"error": "Authorization code is required"}), 400

    # Verify CSRF state + extract nonce + PKCE verifier
    stored_cookie = request.cookies.get("oidc_state", "")
    # #188: verbose logging for debugging cookie issues behind reverse proxy
    if not stored_cookie:
        logging.warning(
            "[OIDC] oidc_state cookie MISSING — browser didn't send it back. Check proxy cookie forwarding."
        )
    else:
        logging.debug(f"[OIDC] oidc_state cookie present ({len(stored_cookie)} chars)")
    stored_nonce = None
    stored_verifier = None
    cookie_parts = stored_cookie.split(":")
    stored_state = cookie_parts[0] if cookie_parts else ""
    if len(cookie_parts) >= 2:
        stored_nonce = cookie_parts[1]
    if len(cookie_parts) >= 3:
        stored_verifier = cookie_parts[2]
    # Redirect_after for portal OIDC flow
    stored_redirect_after = cookie_parts[3] if len(cookie_parts) >= 4 else ""
    if not stored_state or stored_state != state:
        logging.warning(
            # state is client-controlled — sanitize before logging (CWE-117)
            f"[OIDC] State mismatch — stored={sanitize_log_message(stored_state[:8]) if stored_state else 'EMPTY'}..., received={sanitize_log_message(state[:8]) if state else 'EMPTY'}..."
        )
        return jsonify({
            "error": "Invalid state parameter (CSRF protection). Your browser may not be sending cookies — check reverse proxy configuration."
        }), 400

    # Step 1: Exchange code for tokens (with PKCE verifier if available)
    token_data = oidc_exchange_code(config, code, code_verifier=stored_verifier)
    if "error" in token_data:
        logging.warning(f"[OIDC] Token exchange failed: {token_data['error']}")
        return jsonify({"error": "Authentication failed - please try again"}), 401

    access_token = token_data.get("access_token", "")
    id_token_raw = token_data.get("id_token", "")

    if not access_token:
        return jsonify({"error": "No access token received"}), 401

    # Step 2: Decode ID token for claims (with nonce + exp validation - Feb 2026)
    id_claims = {}
    if id_token_raw:
        id_claims = oidc_decode_id_token(id_token_raw, expected_nonce=stored_nonce, config=config)
        if "error" in id_claims:
            logging.warning(f"[OIDC] ID token validation failed: {id_claims['error']}")
            # snyk:ignore:Cross-site Scripting (XSS)
            return jsonify({"error": f"Authentication failed - {id_claims['error']}"}), 401

    # Step 3: Get user info from provider
    user_info = oidc_get_user_info(config, access_token)
    if not user_info:
        # Fallback to ID token claims
        user_info = id_claims

    if not user_info or not (user_info.get("preferred_username") or user_info.get("email") or user_info.get("sub")):
        return jsonify({"error": "Could not retrieve user information from provider"}), 401

    # Step 4: Get group memberships for role mapping
    groups = oidc_get_user_groups(config, access_token)
    role_mapping = oidc_map_groups_to_role(config, groups, id_claims)

    # Step 5: Provision/update local user
    if not config["auto_create_users"]:
        # Check if user already exists
        # This has to match the logic in oidc_provision_user or we get mismatches
        # (had a bug where "john.doe" here vs "johndoe" in provision caused 403s)
        email = user_info.get("email") or user_info.get("preferred_username", "")
        raw_username = user_info.get("preferred_username") or email
        check_username = raw_username.split("@")[0].lower() if "@" in raw_username else raw_username.lower()
        check_username = "".join(c for c in check_username if c.isalnum() or c in "._-")
        if not check_username:
            check_username = f"oidc_{user_info.get('sub', 'unknown')[:12]}"
        # (perf) indexed single-row fetch — load_users() scanned/decrypted all users
        if not get_user_record(check_username):
            return jsonify({"error": "User account does not exist. Contact an administrator."}), 403

    # Determine auth_source label
    provider = config.get("provider", "oidc")
    auth_source = "entra" if provider == "entra" else "oidc"

    user = oidc_provision_user(user_info, role_mapping, auth_source=auth_source)

    # SECURITY - oidc_provision_user returns None if local account would be overwritten
    if not user:
        return jsonify({"error": "A local account with this username already exists. Contact an administrator."}), 403

    username = user.get("username", "")

    # Check if user is enabled
    # (perf) indexed single-row fetch — load_users() scanned/decrypted all users
    fresh_record = get_user_record(username)
    if fresh_record and not fresh_record.get("enabled", True):
        return jsonify({"error": "Account is disabled"}), 403

    # Step 6: Create session via create_session() for proper session rotation + limits
    # Create_session() handles max 3 sessions per user, session rotation, save_sessions()
    # (#086) kill the presented pre-auth session id first — same fixation
    # defense as the password login path.
    prior_sid = request.headers.get("X-Session-ID") or request.cookies.get("session_id")
    if prior_sid:
        invalidate_session(prior_sid)
    session_token = create_session(username, user.get("role", ROLE_VIEWER))

    log_audit(username, "auth.oidc.login", f"OIDC login via {provider} from {client_ip}")

    # Include portal_only so client portal can validate OIDC users
    fresh_user = fresh_record or user
    resp_data = {
        "success": True,
        "user": username,
        "role": user.get("role", ROLE_VIEWER),
        "display_name": user.get("display_name", username),
        "auth_source": auth_source,
        "session_id": session_token,
        "portal_only": fresh_user.get("portal_only", False),
    }
    if stored_redirect_after:
        resp_data["redirect_after"] = stored_redirect_after
    response = make_response(jsonify(resp_data))

    # Set session cookie (same pattern as regular login)
    from ProxmoxVEx.utils.audit import _is_trusted_proxy

    is_secure = request.is_secure or (
        _is_trusted_proxy(request.remote_addr) and request.headers.get("X-Forwarded-Proto") == "https"
    )
    response.set_cookie(
        "session_id", session_token, httponly=True, samesite="Strict", secure=is_secure, max_age=get_session_timeout()
    )
    # Clear OIDC state cookie
    response.delete_cookie("oidc_state")

    return response


@bp.route("/api/auth/oidc/config", methods=["GET"])
def oidc_get_public_config():
    """Return public OIDC config (non-sensitive) for login page

    Frontend needs to know if OIDC is enabled and button text
    No auth required - this is used on the login page
    """
    config = get_oidc_settings()
    return jsonify({
        "enabled": config["enabled"],
        "provider": config.get("provider", "entra"),
        "button_text": config.get("button_text", "Sign in with Microsoft"),
    })


@bp.route("/api/settings/oidc/test", methods=["POST"])
@require_auth(roles=[ROLE_ADMIN])
def oidc_test_connection():
    """Test OIDC configuration by verifying endpoints are reachable

    Tests connectivity to OIDC discovery and token endpoints
    """
    data = request.get_json() or {}
    config = get_oidc_settings()

    # Override with test data
    for key in ["oidc_client_id", "oidc_tenant_id", "oidc_provider", "oidc_authority", "oidc_cloud_environment"]:
        if key in data:
            short_key = key.replace("oidc_", "")
            config[short_key] = data[key]
    # (#188 follow-up): accept `oidc_issuer` as an alias for
    # `oidc_authority`. The OIDC spec calls it the "issuer", and external
    # clients / CLI testers / future-Authentik-templates may send the
    # standard term. Drop it onto `config['authority']` so the rest of the
    # endpoint-resolution code (which reads `config.get('authority')`)
    # picks it up unchanged.
    if "oidc_issuer" in data and not config.get("authority"):
        config["authority"] = data["oidc_issuer"]

    results = []

    # Step 1: Check endpoints exist
    endpoints = get_oidc_endpoints(config) or {}
    cloud_env = config.get("cloud_environment", "commercial")
    env_label = {"commercial": "Commercial", "gcc": "GCC", "gcc_high": "GCC High", "dod": "DoD"}.get(
        cloud_env, cloud_env
    )
    results.append({
        "step": "Configuration",
        "status": "ok",
        "detail": f"Provider: {config.get('provider', 'unknown')}, Tenant: {config.get('tenant_id') or 'N/A'}, Cloud: {env_label}",
    })

    # (#188 follow-up): if endpoint resolution failed outright
    # (e.g. authority is empty / malformed → SSRF guard rejects discovery URL,
    # or Entra config has no tenant), surface a clean error instead of
    # cascading into AttributeError/KeyError on the empty endpoints dict.
    if endpoints.get("_error"):
        results.append({
            "step": "Endpoint Resolution",
            "status": "error",
            "detail": endpoints.get("_error_detail") or endpoints["_error"],
        })
        return jsonify({"success": False, "results": results})

    if not endpoints.get("authorization") and not endpoints.get("jwks"):
        results.append({
            "step": "Endpoint Resolution",
            "status": "error",
            "detail": "Could not derive authorization/JWKS URLs. Check that the "
            "OIDC authority/issuer URL is set and reachable, and (for Entra) "
            "that the tenant_id is configured.",
        })
        return jsonify({"success": False, "results": results})

    # (#188) - surface whether discovery succeeded so admins immediately see when
    # ProxmoxVEx is using the (often wrong) issuer-relative fallback.
    if config.get("provider") != "entra":
        if endpoints.get("_discovery_used"):
            results.append({
                "step": "Discovery",
                "status": "ok",
                "detail": "OIDC discovery succeeded — using endpoints from .well-known",
            })
        else:
            results.append({
                "step": "Discovery",
                "status": "warning",
                "detail": f"Discovery doc not reachable at {config.get('authority', '').rstrip('/')}/.well-known/openid-configuration; "
                f"using issuer-relative guesses. If this is Authentik/Keycloak/non-Entra, the auth endpoint will likely be wrong.",
            })

    # Step 2: Test authorization endpoint
    try:
        skip_ssl = bool(config.get("oidc_skip_ssl_verify", False))
        # SSRF guard. Same pattern as utils/oidc.py (token/discovery/jwks).
        # admin-only endpoint, but Authentik/Keycloak-style on-prem realms run on private
        # nets, so honour the existing oidc_allow_private_ip toggle.
        allow_private_ip = bool(config.get("oidc_allow_private_ip", False))
        try:
            # (CodeAnt #504) - use normalised URL returned by the guard
            # instead of the raw input so the request hits exactly what was validated.
            validated_auth_url = sanitize_outbound_url(endpoints["authorization"], allow_private=allow_private_ip)
        except SsrfError:
            logging.exception("SSRF guard rejected OIDC authorization URL")
            hint = ""
            if not allow_private_ip:
                hint = ' (set "Allow private IP" in OIDC settings if this is intentional)'
            results.append({
                "step": "Authorization Endpoint",
                "status": "error",
                "detail": f"URL rejected by SSRF guard; check the authority/issuer URL{hint}",
            })
            # lgtm[py/server-information-exposure]
            # snyk:ignore:python/ServerInformationExposure
            return jsonify({"success": False, "results": results})
        resp = requests.get(validated_auth_url, allow_redirects=False, timeout=10, verify=not skip_ssl)
        # Auth endpoint should return 200 or redirect
        if resp.status_code in [200, 302, 400]:
            results.append({"step": "Authorization Endpoint", "status": "ok", "detail": endpoints["authorization"]})
        else:
            hint = ""
            if resp.status_code == 404 and not endpoints.get("_discovery_used"):
                hint = " (discovery failed → using issuer-relative URL; for Authentik the authorize endpoint is one path level above the issuer)"
            results.append({
                "step": "Authorization Endpoint",
                "status": "error",
                "detail": f"HTTP {resp.status_code}{hint}",
            })
    except Exception:
        logging.exception("Authorization Endpoint test failed")
        results.append({
            "step": "Authorization Endpoint",
            "status": "error",
            "detail": "Authorization Endpoint test failed",
        })

    # Step 3: Test JWKS endpoint
    try:
        # Same SSRF guard, same allow-private toggle.
        allow_private_ip = bool(config.get("oidc_allow_private_ip", False))
        try:
            # (CodeAnt #504) - same normalisation as Step 2 above.
            validated_jwks_url = sanitize_outbound_url(endpoints["jwks"], allow_private=allow_private_ip)
        except SsrfError:
            logging.exception("SSRF guard rejected OIDC JWKS URL")
            hint = ""
            if not allow_private_ip:
                hint = ' (set "Allow private IP" in OIDC settings if this is intentional)'
            results.append({
                "step": "JWKS Endpoint",
                "status": "error",
                "detail": f"URL rejected by SSRF guard; check the authority/issuer URL{hint}",
            })
            # lgtm[py/server-information-exposure]
            # snyk:ignore:python/ServerInformationExposure
            return jsonify({"success": False, "results": results})
        resp = requests.get(validated_jwks_url, timeout=10)
        if resp.status_code == 200:
            keys = resp.json().get("keys", [])
            results.append({"step": "JWKS Endpoint", "status": "ok", "detail": f"Found {len(keys)} signing keys"})
        else:
            results.append({"step": "JWKS Endpoint", "status": "error", "detail": f"HTTP {resp.status_code}"})
    except Exception:
        logging.exception("JWKS Endpoint test failed")
        results.append({
            "step": "JWKS Endpoint",
            "status": "error",
            "detail": "JWKS Endpoint test failed",
        })

    # Step 4: Check client_id is set
    client_id = config.get("client_id") or ""
    if client_id:
        results.append({"step": "Client ID", "status": "ok", "detail": f"{client_id[:8]}..."})
    else:
        results.append({"step": "Client ID", "status": "warning", "detail": "Not configured"})

    # Step 5: Check redirect URI
    if config.get("redirect_uri"):
        results.append({"step": "Redirect URI", "status": "ok", "detail": config["redirect_uri"]})
    else:
        results.append({"step": "Redirect URI", "status": "warning", "detail": "Not configured - will auto-detect"})

    all_ok = all(r["status"] == "ok" for r in results)
    # lgtm[py/server-information-exposure]
    # snyk:ignore:python/ServerInformationExposure
    return jsonify({"success": all_ok, "results": results})


# First-run setup endpoint. Reachable only while the install
# is uninitialised; closes itself once the first admin is created. Replaces
# the old auto-bootstrapped `ProxmoxVEx/admin` default that exposed every
# fresh install to a network-attacker race.
_setup_attempts_by_ip = {}  # very light rate-limit, IP → list[ts]


@bp.route("/api/auth/setup", methods=["POST"])
def auth_setup():
    if is_initialized():
        # already done, no replay
        return jsonify({
            "error": "ProxmoxVEx is already initialised",
            "code": "ALREADY_INITIALIZED",
        }), 409

    client_ip = get_client_ip()
    now = time.time()
    # crude per-IP rate-limit: max 5 attempts / 60s. Mostly hygiene; the real
    # race-window protection is the operator firewalling 5000 until setup
    # completes. Document that in the install guide.
    window = [t for t in _setup_attempts_by_ip.get(client_ip, []) if now - t < 60]
    if len(window) >= 5:
        logging.warning(f"[SETUP] rate-limited setup attempt from {client_ip}")
        return jsonify({"error": "Too many attempts, slow down"}), 429
    window.append(now)
    _setup_attempts_by_ip[client_ip] = window

    data = request.get_json() or {}
    username = sanitize_username(str(data.get("username", "")).strip().lower(), max_length=64)
    password = data.get("password", "")
    display_name = sanitize_identifier(str(data.get("display_name", "")).strip(), max_length=128)
    email = str(data.get("email", "")).strip()[:254]

    if not username or len(username) < 2:
        return jsonify({"error": "Username must be at least 2 characters"}), 400
    # don't let setup conflict with the legacy default-admin name
    # avoids confusion in audit logs across the upgrade boundary
    # lgtm[py/hardcoded-credentials]
    if username == RESERVED_ADMIN_USERNAME.lower():
        # snyk:ignore:Cross-site Scripting (XSS)
        return jsonify({"error": f"Choose a different username ('{RESERVED_ADMIN_USERNAME}' is reserved)"}), 400
    if not password:
        return jsonify({"error": "Password required"}), 400
    ok, err = validate_password_policy(password)
    if not ok:
        return jsonify({"error": err}), 400

    # build, save, mark — order matters: if mark fails the next request
    # would re-allow setup and double-create, so the audit log catches it.
    try:
        admin = create_initial_admin(username, password, display_name=display_name, email=email)
        save_users(admin)
        mark_admin_initialized()
    except Exception as e:
        logging.error(f"[SETUP] failed to create initial admin: {e}")
        return jsonify({"error": "Setup failed, check server logs"}), 500

    log_audit(username, "admin.initial_setup", f"First admin '{username}' created via setup wizard from {client_ip}")
    logging.info(f"[SETUP] initial admin '{username}' created from {client_ip}")

    return jsonify({
        "success": True,
        "message": "Setup complete, you can now log in",
        "username": username,
    })


@bp.route("/api/auth/login", methods=["POST"])
def auth_login():
    """login endpoint -"""
    global login_attempts_by_ip, login_attempts_by_user

    # First-run safety gate. Before the setup wizard runs there
    # is no admin to authenticate against; refusing /login here closes the old
    # hardcoded-creds path (`ProxmoxVEx/admin` was bootstrapped automatically
    # which let any network-reachable fresh install be taken over).
    if not is_initialized():
        return jsonify({
            "error": "ProxmoxVEx is not initialised — run the setup wizard first",
            "code": "NOT_INITIALIZED",
        }), 503

    # get settings
    login_settings = get_login_settings()
    max_attempts = login_settings["max_attempts"]
    lockout_time = login_settings["lockout_time"]
    attempt_window = login_settings["attempt_window"]
    # (#087) ceiling for exponential lockout escalation + the quiet period
    # after which a tracker's escalation count is forgiven.
    max_lockout = login_settings["max_lockout"]

    # Centralized IP resolution, handles trusted proxies + IPv6 normalization
    client_ip = get_client_ip()

    current_time = time.time()

    # check if ip is locked
    if client_ip in login_attempts_by_ip:
        attempt_info = login_attempts_by_ip[client_ip]
        if attempt_info.get("locked_until", 0) > current_time:
            remaining = int(attempt_info["locked_until"] - current_time)
            logging.warning(f"locked ip tried to login: {client_ip}")
            # 2026-04-24 - uniform 401 (audit #5 applied here too). Previously
            # returned 429 with a distinctive body, which let an observer distinguish
            # IP-lockout vs. user-lockout vs. bad credentials.
            resp = jsonify({"error": "Invalid credentials", "locked": True, "retry_after": remaining})
            resp.headers["Retry-After"] = str(remaining)
            return resp, 401
        # cleanup old attempts
        attempt_info["attempts"] = [t for t in attempt_info.get("attempts", []) if current_time - t < attempt_window]
        # (#087) escalation decay — a tracker quiet for longer than
        # max_lockout is forgiven: last year's attack shouldn't double
        # today's fat-finger lockout.
        if attempt_info.get("locked_until") and current_time - attempt_info["locked_until"] > max_lockout:
            attempt_info["lock_count"] = 0

    data = request.get_json()
    if not data:
        return jsonify({"error": "Invalid request body"}), 400

    # sanitize inputs (security stuff)
    username = sanitize_username(data.get("username", "").strip().lower(), max_length=64)
    password = data.get("password", "")[:256]  # limit to prevent DoS
    totp_code = sanitize_identifier(data.get("totp_code", ""), max_length=10)
    # WebAuthn proof token from a prior /api/webauthn/auth/finish
    webauthn_proof = (data.get("webauthn_proof") or "")[:256]
    # Trusted-device pair ("remember this computer" for 2FA): the client
    # sends its stable device_id plus the key the server issued after a
    # previous fully-verified login. trust_device asks the server to mint
    # a fresh pair once THIS login clears its second factor.
    device_id = sanitize_identifier(data.get("device_id", ""), max_length=64)
    device_token = sanitize_identifier(data.get("device_token", ""), max_length=128)
    trust_device = bool(data.get("trust_device"))

    if not username or not password:
        return jsonify({"error": "Username and password required"}), 400

    if len(username) < 2:
        return jsonify({"error": "Username too short"}), 400

    # Check if username is locked out (additional protection against distributed attacks).
    # 2026-04-24 - security audit: uniform 401 response here prevents username
    # enumeration. Previously returned 429 "Account temporarily locked" which let an
    # attacker probe whether a username existed (locked vs unknown gave different
    # status codes). Now looks identical to "invalid credentials" to the caller;
    # Retry-After header + retry_after body key tell the UI to show a cooldown timer.
    if username in login_attempts_by_user:
        user_attempt_info = login_attempts_by_user[username]
        if user_attempt_info.get("locked_until", 0) > current_time:
            remaining = int(user_attempt_info["locked_until"] - current_time)
            logging.warning(f"Login attempt for locked user: {username} from {client_ip}, {remaining}s remaining")
            # (#087/SC-002) burn the same ~100ms as the unknown-user path —
            # without it a locked account answers instantly while a
            # nonexistent one takes a dummy-verify, a free existence oracle.
            dummy_verify_password(password)
            resp = jsonify({
                "error": "Invalid credentials",
                "locked": True,  # UI hint — not status-code-leaky
                "retry_after": remaining,
            })
            resp.headers["Retry-After"] = str(remaining)
            return resp, 401
        # Clean up old attempts
        user_attempt_info["attempts"] = [
            t for t in user_attempt_info.get("attempts", []) if current_time - t < attempt_window
        ]
        # (#087) escalation decay — same forgiveness rule as the IP tracker.
        if user_attempt_info.get("locked_until") and current_time - user_attempt_info["locked_until"] > max_lockout:
            user_attempt_info["lock_count"] = 0

    # Helper function to record failed attempt (both IP and username)
    # Also logs to audit trail now (was missing, security audit finding)
    def record_failed_attempt(target_username=None):
        """Track a failed login by source IP and by submitted username.

        (#087) The username tracker deliberately includes nonexistent names:
        a 'locked' response must be reachable for unknown users too, or the
        locked flag itself becomes an account-existence oracle (FR-003).
        Lockout duration escalates exponentially per tracker — lock_count
        doubles the base lockout each cycle, capped at max_lockout (FR-002).
        """
        locked = False
        # Indexed lookup keeps the unknown-user audit marker honest without a
        # whole-table scan per failed attempt.
        known = bool(target_username and get_user_record(target_username))
        log_audit(
            target_username or "unknown",
            "auth.login_failed",
            f"Failed login from {client_ip}"
            + (f" for user '{target_username}'" if target_username else "")
            + ("" if known or not target_username else " (unknown user)"),
        )

        def _escalate(entry):
            """Stamp a new lockout with a duration that doubles per cycle."""
            entry["lock_count"] = entry.get("lock_count", 0) + 1
            duration = min(lockout_time * (2 ** (entry["lock_count"] - 1)), max_lockout)
            entry["locked_until"] = current_time + duration
            return duration

        # Track by IP
        if client_ip not in login_attempts_by_ip:
            login_attempts_by_ip[client_ip] = {"attempts": [], "locked_until": 0, "lock_count": 0}
        login_attempts_by_ip[client_ip]["attempts"].append(current_time)
        recent_ip = [t for t in login_attempts_by_ip[client_ip]["attempts"] if current_time - t < attempt_window]
        if len(recent_ip) >= max_attempts:
            duration = _escalate(login_attempts_by_ip[client_ip])
            logging.warning(f"IP {client_ip} locked out after {len(recent_ip)} failed attempts for {duration}s")
            log_audit(
                target_username or "unknown",
                "auth.ip_locked",
                f"IP {client_ip} locked for {duration}s (cycle {login_attempts_by_ip[client_ip]['lock_count']})",
            )
            locked = True

        # Track by submitted username — real OR nonexistent. See docstring:
        # tracking only real names made `locked: true` an existence oracle.
        if target_username:
            # Bound tracker growth: credential-stuffing random names could
            # otherwise grow this dict without limit.
            if len(login_attempts_by_user) > 10000:
                stale = [
                    u
                    for u, e in login_attempts_by_user.items()
                    if e.get("locked_until", 0) <= current_time
                    and not any(current_time - t < attempt_window for t in e.get("attempts", []))
                ]
                for u in stale[: len(stale) // 2 + 1]:
                    login_attempts_by_user.pop(u, None)
            if target_username not in login_attempts_by_user:
                login_attempts_by_user[target_username] = {"attempts": [], "locked_until": 0, "lock_count": 0}
            login_attempts_by_user[target_username]["attempts"].append(current_time)
            recent_user = [
                t for t in login_attempts_by_user[target_username]["attempts"] if current_time - t < attempt_window
            ]
            # Use slightly higher threshold for username (10 attempts) — this
            # is the distributed-attack tier; same-IP bursts hit the IP lock first.
            if len(recent_user) >= max_attempts * 2:
                duration = _escalate(login_attempts_by_user[target_username])
                logging.warning(
                    f"User '{target_username}' locked out after {len(recent_user)} failed attempts for {duration}s"
                )
                log_audit(
                    target_username,
                    "auth.user_locked",
                    f"User '{target_username}' locked for {duration}s"
                    f" (cycle {login_attempts_by_user[target_username]['lock_count']})",
                )
                locked = True

        if not locked:
            return 0
        # Return the effective lock end so the 401's Retry-After reflects the
        # escalated duration, not the base lockout_time constant.
        until = login_attempts_by_ip.get(client_ip, {}).get("locked_until", 0)
        if target_username:
            until = max(until, login_attempts_by_user.get(target_username, {}).get("locked_until", 0))
        return until

    def _locked_response(locked_until):
        """Uniform 401 for a freshly-triggered lockout — Retry-After carries
        the real (possibly escalated) remaining time."""
        remaining = max(1, int(locked_until - current_time))
        resp = jsonify({"error": "Invalid credentials", "locked": True, "retry_after": remaining})
        resp.headers["Retry-After"] = str(remaining)
        return resp, 401

    # (perf) only this login's username is ever read — a lazy indexed fetch
    # replaces the whole-table load_users() scan/decrypt per login attempt.
    # Each call re-reads the row, so JIT-provisioned users in the LDAP step
    # below are visible without an explicit "reload after provisioning".
    def _login_user():
        return get_user_record(username)

    # =================================================================
    # LDAP Authentication (tried before local auth)
    # Flow: LDAP enabled? → Try LDAP bind → JIT provision → session
    # If LDAP fails or disabled → fall through to local password auth
    # =================================================================
    ldap_config = get_ldap_settings()
    ldap_authenticated = False

    if ldap_config["enabled"]:
        ldap_result = ldap_authenticate(username, password)

        if ldap_result.get("success"):
            # LDAP auth succeeded - provision/update local user
            if ldap_config["auto_create_users"] or _login_user():
                user = ldap_provision_user(ldap_result)
                if user is None:
                    # Local account exists - fall through to local auth
                    logging.info(f"[LDAP] User '{username}' has local account, skipping LDAP provisioning")
                else:
                    ldap_authenticated = True
                    logging.info(f"[LDAP] User '{username}' authenticated via LDAP from {client_ip}")
            else:
                logging.warning(f"[LDAP] User '{username}' found in LDAP but auto-create is disabled")
                return jsonify({"error": "User not authorized in ProxmoxVEx. Contact admin."}), 401
        elif ldap_result.get("error") == "User not found in LDAP":
            # User not in LDAP - fall through to local auth
            logging.debug(f"[LDAP] User '{username}' not in LDAP, trying local auth")
        elif "Invalid LDAP credentials" in ldap_result.get("error", ""):
            # User found in LDAP but wrong password - check if also local user
            _lu = _login_user()
            if _lu and _lu.get("auth_source") == "ldap":
                # Pure LDAP user - don't fall through to local auth
                logging.warning(f"[LDAP] Failed login for LDAP user '{username}' from {client_ip}")
                locked_until = record_failed_attempt(username)
                if locked_until:
                    # Uniform 401 - retry timing via header, not status code (audit
                    return _locked_response(locked_until)
                return jsonify({"error": "Invalid credentials"}), 401
            # Else: user exists locally too, fall through to local auth
        else:
            # LDAP server error - log but fall through to local auth
            ldap_err = ldap_result.get("error", "")
            logging.warning(f"[LDAP] Server error during auth: {ldap_err}")
            # TLS errors should be surfaced for LDAP-only users
            # but still fall through for local users so they aren't locked out
            _lu2 = _login_user()
            if (
                ("TLS" in ldap_err or "certificate" in ldap_err.lower())
                and _lu2
                and _lu2.get("auth_source") == "ldap"
            ):
                return jsonify({"error": ldap_err}), 401

    # =================================================================
    # Local Authentication (skipped if LDAP already authenticated)
    # =================================================================
    if not ldap_authenticated:
        # check user exists
        user = _login_user()
        if not user:
            # 2026-04-24 - equalize login timing. Without this the unknown-user branch
            # returns in <1ms while verify_password() takes ~100ms, which is a free
            # username-enumeration oracle via response-time measurement.
            dummy_verify_password(password)
            logging.warning(f"Login attempt for unknown user: {username} from {client_ip}")
            # (#087) DO track unknown names — the locked response must be
            # reachable for nonexistent users or it leaks account existence.
            locked_until = record_failed_attempt(username)
            if locked_until:
                return _locked_response(locked_until)
            return jsonify({"error": "Invalid credentials"}), 401

        # check user is enabled
        if not user.get("enabled", True):
            # burn the same ~100ms even on disabled accounts so existence isn't leaked
            dummy_verify_password(password)
            logging.warning(f"Login attempt for disabled user: {username} from {client_ip}")
            return jsonify({"error": "Invalid credentials"}), 401

        # LDAP-only users cannot login with local password
        if user.get("auth_source") == "ldap" and not user.get("password_hash"):
            dummy_verify_password(password)
            logging.warning(f"LDAP user '{username}' tried local login but has no local password")
            return jsonify({"error": "Please use LDAP credentials to sign in"}), 401

        # Verify password
        if not verify_password(password, user["password_salt"], user["password_hash"]):
            logging.warning(f"Failed login attempt for user: {username} from {client_ip}")
            locked_until = record_failed_attempt(username)
            if locked_until:
                return _locked_response(locked_until)
            return jsonify({"error": "Invalid credentials"}), 401
    else:
        user = _login_user()

        # check user is enabled (even LDAP users can be disabled locally)
        if not user.get("enabled", True):
            logging.warning(f"LDAP user '{username}' is disabled locally")
            return jsonify({"error": "Invalid credentials"}), 401

    # 2FA: TOTP and/or WebAuthn. If a user has EITHER registered,
    # they must pass ONE of them. WebAuthn short-circuits TOTP when a fresh
    # proof token is supplied.
    has_totp = bool(user.get("totp_enabled") and user.get("totp_secret"))
    has_webauthn = False
    try:
        _db_probe = get_db()
        _cnt_row = _db_probe.query_one("SELECT COUNT(*) AS n FROM webauthn_credentials WHERE username = ?", (username,))
        has_webauthn = bool(_cnt_row and _cnt_row["n"] > 0)
    except Exception:
        has_webauthn = False

    if has_totp or has_webauthn:
        # Path 0: a still-valid trusted-device key satisfies the second
        # factor — but only for the same username + device_id + source IP
        # the key was issued to. Any drift falls through to a real factor.
        device_trusted = bool(
            device_id
            and device_token
            and check_trusted_device(username, device_id, device_token, client_ip)
        )
        if device_trusted:
            log_audit(username, "2fa.trusted_device", f"2FA skipped via trusted device from {client_ip}")
        # Path A: caller submitted a WebAuthn proof (from /api/webauthn/auth/finish)
        elif webauthn_proof and has_webauthn:
            from ProxmoxVEx.api.webauthn import consume_webauthn_proof

            if not consume_webauthn_proof(username, webauthn_proof):
                logging.warning(f"Invalid WebAuthn proof for user: {username} from {client_ip}")
                locked_until = record_failed_attempt(username)
                if locked_until:
                    return _locked_response(locked_until)
                return jsonify({"error": "Invalid hardware-key proof"}), 401
            # proof OK — skip TOTP entirely
        # Path B: caller submitted a TOTP code
        elif totp_code and has_totp:
            if TOTP_AVAILABLE:
                import pyotp  # local import: optional dep guarded by TOTP_AVAILABLE

                totp = pyotp.TOTP(user["totp_secret"])
                if not totp.verify(totp_code, valid_window=1):
                    # Spec 088 FR-003: a stored one-time recovery code also
                    # satisfies the second factor (burned on use).
                    if _consume_recovery_code(user, totp_code):
                        save_user_record(username, user)
                        remaining = len(user.get("totp_recovery_codes") or [])
                        logging.warning(f"Recovery code used for {username} from {client_ip} ({remaining} left)")
                        log_audit(username, "2fa.recovery_used", f"Recovery code used; {remaining} remaining")
                    else:
                        logging.warning(f"Invalid 2FA code for user: {username} from {client_ip}")
                        locked_until = record_failed_attempt(username)
                        if locked_until:
                            return _locked_response(locked_until)
                        return jsonify({"error": "Invalid 2FA code"}), 401
            else:
                return jsonify({"error": "2FA is enabled but pyotp is not installed on server"}), 500
        # Path C: nothing provided yet — tell the UI what's possible
        else:
            methods = []
            if has_totp:
                methods.append("totp")
            if has_webauthn:
                methods.append("webauthn")
            return jsonify({
                "requires_2fa": True,
                "message": "2FA required",
                "methods": methods,
            }), 200

    # Clear failed attempts on successful login (both IP and username)
    if client_ip in login_attempts_by_ip:
        del login_attempts_by_ip[client_ip]
    if username in login_attempts_by_user:
        del login_attempts_by_user[username]

    # Auto-migrate password to Argon2id if using old PBKDF2 format
    # Only rehash for locally-authenticated users - LDAP passwords must NEVER be stored locally
    if not ldap_authenticated and needs_password_rehash(user.get("password_salt", ""), user.get("password_hash", "")):
        try:
            new_salt, new_hash = hash_password(password)
            user["password_salt"] = new_salt
            user["password_hash"] = new_hash
            save_user_record(username, user)
            logging.info(f"Migrated password for user '{username}' to Argon2id (Military Grade)")
        except Exception as e:
            logging.warning(f"Failed to migrate password for {username}: {e}")

    # Create session
    # (#086) Session-fixation defense: whatever session id the client
    # presented pre-login dies here — a planted or stale id can never ride
    # into the authenticated state. The fresh id below is the only survivor.
    prior_sid = request.headers.get("X-Session-ID") or request.cookies.get("session_id")
    if prior_sid:
        invalidate_session(prior_sid)
    remember = data.get("remember", False)
    session_id = create_session(username, user["role"], remember=bool(remember))

    # Update last login — single-row write; save_users(users_db) rewrote every
    # row on each login
    user["last_login"] = datetime.now().isoformat()
    save_user_record(username, user)

    logging.info(f"User '{username}' logged in successfully")
    log_audit(username, "user.login", "User logged in" + (" (with 2FA)" if user.get("totp_enabled") else ""))

    # Removed auto-allow CORS origin on login (security audit)
    # Was allowing any authenticated origin permanently. Use PROXMOXVEX_ALLOWED_ORIGINS env var instead.

    # Get default theme for response
    settings = load_server_settings()
    default_theme = settings.get("default_theme", "proxmoxDark")

    # Check if user needs to set up 2FA (force_2fa + spec 088 role scoping)
    requires_2fa_setup = _requires_2fa_setup(username, user, user["role"], settings)

    # Trusted-device pair: when the caller asked to remember this computer
    # AND the account actually has a second factor, mint a fresh key. The
    # client stores it in localStorage; we keep only the hash. Reaching this
    # line means the login passed (factor verified or trusted device), so a
    # device key is only ever minted on a fully authenticated request.
    device_key = None
    if trust_device and device_id and (has_totp or has_webauthn):
        device_key = issue_trusted_device(username, device_id, client_ip)
        if device_key:
            log_audit(username, "2fa.device_trusted", f"Trusted device registered from {client_ip}")

    # Debug log for theme sync issues
    user_theme = user.get("theme", "") or default_theme
    logging.info(f"[LOGIN] User {username} theme from DB: '{user.get('theme', '')}', using: '{user_theme}'")

    response = jsonify({
        "success": True,
        "user": {
            "username": username,
            "role": user["role"],
            "display_name": user.get("display_name", username),
            "email": user.get("email", ""),
            "avatar_url": user.get("avatar_url", ""),
            "auth_source": user.get("auth_source", "local"),  # For LDAP/Entra/OIDC badge
            "permissions": get_user_permissions(user),  # Frontend can hide/show buttons
            "tenant_id": user.get("tenant_id", DEFAULT_TENANT_ID),
            "totp_enabled": user.get("totp_enabled", False),
            "theme": user_theme,  # Use default if empty
            "language": user.get("language", ""),
            "ui_layout": user.get("ui_layout", "modern"),
            "taskbar_auto_expand": user.get("taskbar_auto_expand", True),  # Feb 2026
            "taskbar_visible": user.get("taskbar_visible", True),
            "taskbar_expanded": user.get("taskbar_expanded", False),
            "sidebar_show_vmid": user.get("sidebar_show_vmid", False),  # Corporate sidebar VMIDs
            "layout_chosen": user.get("layout_chosen", False),
            "portal_only": user.get("portal_only", False),
            # (spec 092/US020) guided-tour state must ride the login payload —
            # GuidedTour reads user.tour, and without it here the saved
            # {done:true} from "Don't show again" never reached the client, so
            # the tour relaunched on every login.
            "tour": _safe_user_tour(username),
        },
        "session_id": session_id,
        "portal_only": user.get("portal_only", False),
        # One-shot trusted-device key for the client's localStorage (the
        # server kept only its hash). Null unless trust_device was requested
        # on an account that has a second factor.
        "device_key": device_key,
        "default_theme": default_theme,  # Include for frontend fallback
        "reverse_proxy_enabled": effective_reverse_proxy(settings),
        "air_gap_mode": settings.get("air_gap_mode", False),
        "requires_2fa_setup": requires_2fa_setup,  # Force 2FA
        # Security warning if using default password
        "security_warning": "DEFAULT_PASSWORD" if (user["role"] == ROLE_ADMIN and password == "admin") else None,
        "requires_password_change": bool(user.get("force_password_change")),
    })

    # Set session cookie with security flags
    # Secure flag only when using HTTPS (important for production!)
    from ProxmoxVEx.utils.audit import _is_trusted_proxy

    is_secure = request.is_secure or (
        _is_trusted_proxy(request.remote_addr) and request.headers.get("X-Forwarded-Proto") == "https"
    )
    response.set_cookie(
        "session_id",
        session_id,
        httponly=True,  # JS cant access this cookie
        samesite="Strict",  # CSRF protection
        secure=is_secure,  # only send over HTTPS
        max_age=get_session_timeout(),
    )

    return response


# Session self-service. Admins could see all sessions via the users API
# already, but regular users had no way to find "where am I still logged in" or revoke
# a lost browser. These two endpoints scope strictly to the caller's own username.


def _revocation_token_for(sess):
    """Stable per-session opaque token used in /api/user/sessions and DELETE.
    Generated lazily and stored on the session itself so subsequent listings
    return the same token.  replaces returning
    the full session id as 'full_id', which let JS read otherwise-HttpOnly
    credentials and would have been a privilege-escalation vector via XSS."""
    import secrets

    if not sess.get("revocation_token"):
        sess["revocation_token"] = secrets.token_urlsafe(24)
    return sess["revocation_token"]


@bp.route("/api/user/sessions", methods=["GET"])
def list_own_sessions():
    """Return the caller's active sessions, newest first."""
    session_id = request.headers.get("X-Session-ID") or request.cookies.get("session_id")
    current = validate_session(session_id)
    if not current:
        return jsonify({"error": "not authenticated"}), 401
    from ProxmoxVEx.utils.auth import active_sessions, sessions_lock

    username = current["user"]
    out = []
    with sessions_lock:
        for sid, sess in active_sessions.items():
            if sess.get("user") != username:
                continue
            out.append({
                # show a short prefix for display only — full sid never leaves
                # the cookie. revoke_token is the opaque handle the UI passes
                # back to DELETE /api/user/sessions/<token>.
                "id": sid[:8] + "…",
                "revoke_token": _revocation_token_for(sess),
                "ip": sess.get("ip"),
                "user_agent": sess.get("user_agent"),
                "created_at": sess.get("created_at"),
                "last_activity": sess.get("last_activity"),
                "remember": bool(sess.get("remember")),
                "is_current": sid == session_id,
            })
    out.sort(key=lambda s: s.get("last_activity") or 0, reverse=True)
    return jsonify({"sessions": out, "total": len(out)})


@bp.route("/api/user/sessions/<token>", methods=["DELETE"])
def revoke_own_session(token):
    """Revoke a session by its opaque revocation token.
    Was previously by-full-sid; now by token (M-5 fix)."""
    session_id = request.headers.get("X-Session-ID") or request.cookies.get("session_id")
    current = validate_session(session_id)
    if not current:
        return jsonify({"error": "not authenticated"}), 401
    import hmac as _hmac

    from ProxmoxVEx.utils.auth import active_sessions, sessions_lock

    username = current["user"]

    target_sid = None
    with sessions_lock:
        for sid, sess in active_sessions.items():
            tok = sess.get("revocation_token") or ""
            if tok and _hmac.compare_digest(tok, token) and sess.get("user") == username:
                target_sid = sid
                break
    if not target_sid:
        return jsonify({"error": "session not found"}), 404
    invalidate_session(target_sid)
    with contextlib.suppress(Exception):
        log_audit(username, "user.session_revoke", f"revoked session {target_sid[:8]}…")
    is_self = target_sid == session_id
    resp = jsonify({"success": True, "revoked": target_sid[:8] + "…", "self_logout": is_self})
    if is_self:
        resp.delete_cookie("session_id")
    return resp


@bp.route("/api/auth/sessions/kill-all", methods=["POST"])
@require_auth(roles=[ROLE_ADMIN])
def kill_all_sessions():
    """Admin panic button: invalidate every active session for every user,
    including the admin's own current one. Sessions already persist across
    restarts, so this is the counterpart for "log everyone out right now"
    during a suspected credential compromise, without needing a restart.
    """
    actor = _req_session()["user"]
    count = invalidate_all_sessions()
    # A full session clear also burns every trusted-device key — after a
    # suspected compromise nobody should be able to re-enter without 2FA.
    revoke_all_trusted_devices()
    log_audit(actor, "auth.sessions_kill_all", f"Killed all {count} active session(s) system-wide")
    response = jsonify({"success": True, "sessions_killed": count})
    # The caller's own session just died too - clear their cookie so the
    # frontend doesn't keep sending a dead session_id.
    response.delete_cookie("session_id")
    return response


@bp.route("/api/auth/logout", methods=["POST"])
def auth_logout():
    """Logout user and invalidate session"""
    session_id = request.headers.get("X-Session-ID") or request.cookies.get("session_id")

    if session_id:
        session = validate_session(session_id)
        if session:
            logging.info(f"User '{session['user']}' logged out")
            log_audit(session["user"], "user.logout", "User logged out")
        invalidate_session(session_id)

    response = jsonify({"success": True})
    response.delete_cookie("session_id")
    return response


@bp.route("/api/health", methods=["GET"])
def health_check():
    """Unauthenticated health endpoint for Docker/LB probes"""
    from ProxmoxVEx.demo import (
        DEMO_CAPACITY,
        DEMO_RESET_INTERVAL,
        is_demo_mode,
    )

    payload: dict[str, object] = {
        "status": "ok",
        "version": ProxmoxVEx_VERSION,
        "demo_mode": is_demo_mode(),
    }
    if is_demo_mode():
        payload["mode"] = "demo"
        payload["reset_in_seconds"] = DEMO_RESET_INTERVAL
        payload["capacity"] = DEMO_CAPACITY
    return jsonify(payload)


@bp.route("/api/auth/check", methods=["GET"])
def auth_check():
    """Check if current session is valid"""
    session_id = request.headers.get("X-Session-ID") or request.cookies.get("session_id")

    session = validate_session(session_id)
    if not session:
        # Include LDAP/OIDC status so login page can show indicators
        settings = load_server_settings()
        ldap_enabled = settings.get("ldap_enabled", False)
        oidc_enabled = settings.get("oidc_enabled", False)
        oidc_button_text = settings.get("oidc_button_text", "Sign in with Microsoft")
        login_background = settings.get("login_background", "")
        # First-run signal so the React shell can show the setup
        # wizard instead of the login form on an uninitialised install.
        # Return 200 with authenticated=False so the login page does not spam
        # the browser console with "Failed to load resource" 401 messages.
        return jsonify({
            "authenticated": False,
            "initialized": is_initialized(),
            "ldap_enabled": ldap_enabled,
            "oidc_enabled": oidc_enabled,
            "oidc_button_text": oidc_button_text,
            "login_background": login_background,
        }), 200

    # Get user info - always fresh from database
    # (perf) indexed single-row fetch — load_users() scanned/decrypted all users
    user = get_user_record(session["user"])

    # If user was disabled while session is active, force logout
    if not user or not user.get("enabled", True):
        logging.info(f"[AUTH_CHECK] User '{session['user']}' is disabled or deleted, invalidating session")
        invalidate_session(session_id)
        return jsonify({"authenticated": False, "reason": "account_disabled"}), 200

    logging.debug(f"auth_check for {session['user']}: ui_layout = {user.get('ui_layout')}")

    # Check password expiry status
    password_expiry = None
    settings = load_server_settings()

    # Check if user should be subject to password expiry
    # Admins are exempt by default, but can opt-in via settings
    # LDAP/OIDC users are ALWAYS exempt - they don't have local passwords
    is_admin = session["role"] == ROLE_ADMIN
    is_external_auth = user.get("auth_source", "local") in ("ldap", "oidc", "entra")
    include_admins = settings.get("password_expiry_include_admins", False)
    should_check_expiry = (
        settings.get("password_expiry_enabled") and not is_external_auth and (not is_admin or include_admins)
    )

    if should_check_expiry:
        expiry_days = settings.get("password_expiry_days", 90)
        warning_days = settings.get("password_expiry_warning_days", 14)

        changed_at = user.get("password_changed_at")
        if changed_at:
            try:
                changed_date = datetime.fromisoformat(changed_at.replace("Z", "+00:00"))
                # handle naive datetime
                if changed_date.tzinfo:
                    changed_date = changed_date.replace(tzinfo=None)
                days_since = (datetime.now() - changed_date).days
                days_until_expiry = expiry_days - days_since

                password_expiry = {
                    "enabled": True,
                    "days_until_expiry": days_until_expiry,
                    "expired": days_until_expiry <= 0,
                    "warning": days_until_expiry <= warning_days and days_until_expiry > 0,
                    "expiry_days": expiry_days,
                }
            except Exception:
                pass  # couldn't parse date, skip
        else:
            # no password_changed_at means old user, treat as expired
            password_expiry = {
                "enabled": True,
                "days_until_expiry": 0,
                "expired": True,
                "warning": False,
                "expiry_days": expiry_days,
            }

    # Get default theme from settings
    default_theme = settings.get("default_theme", "proxmoxDark")

    # Debug log for theme sync issues
    user_theme = user.get("theme", "") or default_theme
    logging.debug(
        f"[AUTH_CHECK] User {session['user']} theme from DB: '{user.get('theme', '')}', using: '{user_theme}'"
    )

    # Always check database for latest role, session might be stale if admin changed it
    # This ensures role changes by admin take effect immediately
    fresh_role = user.get("role", session["role"])
    if fresh_role != session["role"]:
        # Update session to match database (avoids stale role in session)
        old_role = session["role"]
        session["role"] = fresh_role
        logging.info(f"[AUTH_CHECK] Updated stale session role for {session['user']}: {old_role} → {fresh_role}")

    # Get effective permissions for UI visibility
    user_permissions = get_user_permissions(user)

    # Check if user needs to set up 2FA (force_2fa + spec 088 role scoping)
    requires_2fa_setup = _requires_2fa_setup(session["user"], user, fresh_role, settings)

    return jsonify({
        "authenticated": True,
        "session_id": session_id,
        "user": {
            "username": session["user"],
            "role": fresh_role,
            "display_name": user.get("display_name", session["user"]),
            "email": user.get("email", ""),
            "avatar_url": user.get("avatar_url", ""),
            "auth_source": user.get("auth_source", "local"),  # For LDAP/Entra/OIDC badge
            "tenant_id": user.get("tenant_id", DEFAULT_TENANT_ID),  # For multi-tenant UI
            "permissions": user_permissions,  # So frontend knows what buttons to show
            "theme": user_theme,
            "language": user.get("language", ""),
            "ui_layout": user.get("ui_layout", "modern"),
            "taskbar_auto_expand": user.get("taskbar_auto_expand", True),  # Feb 2026
            "taskbar_visible": user.get("taskbar_visible", True),
            "taskbar_expanded": user.get("taskbar_expanded", False),
            "sidebar_show_vmid": user.get("sidebar_show_vmid", False),  # Corporate sidebar VMIDs
            "totp_enabled": user.get("totp_enabled", False),
            "layout_chosen": user.get("layout_chosen", False),
            "portal_only": user.get("portal_only", False),
            # Same as the login payload: session-restored users need the saved
            # tour state or Skip/'Don't show again' is lost on every reload.
            "tour": _safe_user_tour(session["user"]),
        },
        "password_expiry": password_expiry,
        "requires_2fa_setup": requires_2fa_setup,
        "reverse_proxy_enabled": effective_reverse_proxy(settings),
        "air_gap_mode": settings.get("air_gap_mode", False),
        "default_theme": default_theme,
    })


@bp.route("/api/auth/validate", methods=["GET"])
def auth_validate():
    """Simple session validation for WebSocket auth (shell, VNC)

    Shell/VNC WebSocket needs a simple endpoint to validate session
    Returns 200 if valid, 401 if not
    """
    # Check both cookie (sent via requests.get with cookies=) and header
    session_id = (
        request.cookies.get("session") or request.cookies.get("session_id") or request.headers.get("X-Session-ID")
    )

    if not session_id:
        return jsonify({"valid": False, "error": "No session"}), 401

    session = validate_session(session_id)
    if not session:
        return jsonify({"valid": False, "error": "Invalid session"}), 401

    return jsonify({"valid": True, "user": session["user"], "role": session["role"]})


@bp.route("/api/internal/cluster-creds/<cluster_id>", methods=["GET"])
def get_cluster_creds_internal(cluster_id):
    """Internal endpoint for shell/VNC WebSocket to get node connection info

    Returns node IPs for SSH connections
    For single-node setups, we use the cluster host directly
    """
    # Check session from cookie
    session_id = request.cookies.get("session") or request.cookies.get("session_id")

    if not session_id:
        return jsonify({"error": "No session"}), 401

    session = validate_session(session_id)
    if not session:
        return jsonify({"error": "Invalid session"}), 401

    # Check_cluster_access reads request.session['user'], which
    # @require_auth normally sets. This endpoint does its own cookie-based session
    # validation (no decorator), so we have to attach the session to the request
    # explicitly. Without this the call below raises AttributeError and the SSH-WS
    # shell flow breaks (cluster-creds 500 -> Method 1 falls through -> no node IPs).
    with contextlib.suppress(Exception):
        # setattr is deliberate: `session` isn't a declared Request attribute
        # (attached at runtime by require_auth), so plain assignment trips type checkers.
        setattr(request, "session", session)  # noqa: B010

    # Check if cluster exists
    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    mgr = cluster_managers[cluster_id]

    # Mar 2026: use standard cluster access check (validates user's cluster assignments + tenant)
    from ProxmoxVEx.api.helpers import check_cluster_access

    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return jsonify({"error": "Access denied to this cluster"}), 403

    # Check permissions - Feb 2026
    # (perf) indexed single-row fetch — load_users() scanned/decrypted all users
    user_data = get_user_record(session["user"])
    # 2026-06-10 (RBAC): gate on node.shell only - admin holds it via all-perms, so the
    # explicit admin bypass was redundant; a custom role with node.shell now works too.
    user_perms = get_user_permissions(user_data)
    if "node.shell" not in user_perms:
        logging.warning(f"[CLUSTER-CREDS] User {session['user']} lacks node.shell permission")
        return jsonify({"error": "Permission denied"}), 403

    # Get node IPs - the cluster_host is our reliable fallback
    node_ips = {}
    cluster_host, cluster_port = mgr.host, mgr.api_port

    logging.info(f"[CLUSTER-CREDS] Getting node IPs for cluster {cluster_id}, host={cluster_host}")

    # (PR #324): ?node=<name> resolves only the requested node.
    # The WS shell calls this on every connect; resolving every node on a
    # big cluster would blow past the WS server's 10s request timeout.
    requested_node = (request.args.get("node") or "").strip()

    def _resolve_node(nname):
        try:
            ip = mgr._get_node_ip(nname)
        except Exception as e:
            logging.warning(f"[CLUSTER-CREDS] _get_node_ip({nname}) raised: {e}")
            ip = None
        if ip:
            node_ips[nname] = ip
            node_ips[nname.lower()] = ip
            logging.info(f"[CLUSTER-CREDS] {nname} -> {ip}")
        else:
            logging.warning(f"[CLUSTER-CREDS] no reachable IP for {nname}")

    try:
        if requested_node:
            _resolve_node(requested_node)
        else:
            # Bulk path -- UIs that want the full mapping.
            # Re-use _cached_nodes populated by get_cluster_nodes(),
            # otherwise hit /api2/json/nodes directly. mgr.get_nodes()
            nodes = getattr(mgr, "_cached_nodes", None)
            if not nodes:
                try:
                    r = mgr._create_session().get(f"https://{cluster_host}:{cluster_port}/api2/json/nodes", timeout=10)
                    if r.status_code == 200:
                        nodes = r.json().get("data", []) or []
                        with contextlib.suppress(Exception):
                            mgr._cached_nodes = nodes
                except Exception as e:
                    logging.warning(f"[CLUSTER-CREDS] /nodes REST failed: {e}")
                    nodes = []
            for n in nodes or []:
                nn = n.get("node") or n.get("name") or ""
                if nn:
                    _resolve_node(nn)
    except Exception as e:
        logging.error(f"[CLUSTER-CREDS] Error getting node IPs: {e}")

    # Final fallback: if no nodes found, use cluster host
    if not node_ips:
        node_ips["_default"] = cluster_host
        logging.info(f"[CLUSTER-CREDS] No nodes found, using default: {cluster_host}")

    # Feb 2026: Never expose Proxmox password via API - shell proxy handles auth server-side
    # Mar 2026: removed user field from response, only SSH proxy needs it internally
    # Apr 2026: expose ssh_port so the WS server can honor non-22 configs
    # 2026-06-04: expose verify_pve_tls so the SSH-WS subprocess can decide
    # whether to disable cert/hostname verification for the PVE wss:8006/vncwebsocket
    # proxy. Mirrors the per-cluster ssl_verify flag (default False because PVE
    # ships self-signed certs by default; admins flip it on in cluster settings
    # once they've installed a real cert + uploaded the CA).
    ssh_port = getattr(getattr(mgr, "config", None), "ssh_port", 22) or 22
    verify_pve_tls = bool(getattr(mgr, "ssl_verify", False))
    # 2026-06-05 (C-1): the termproxy WS proxy gets the PVE session cookie
    # from here (server-side) instead of the browser. Mint fresh; None for
    # token-only clusters. Other consumers (SSH) ignore the field.
    resp = {
        "host": cluster_host,
        "node_ips": node_ips,
        "ssh_port": ssh_port,
        "verify_pve_tls": verify_pve_tls,
    }
    try:
        _tk = mgr.mint_console_auth_ticket()
        if _tk:
            resp["pve_auth_ticket"] = _tk
    except Exception:
        pass
    return jsonify(resp)


@bp.route("/api/auth/verify-password", methods=["POST"])
@require_auth()
def verify_password_api():
    """Verify current user's password — for re-auth before sensitive ops (#256)"""
    # Security audit - rate limit to prevent brute-force after session compromise
    from ProxmoxVEx.utils.audit import get_client_ip

    client_ip = get_client_ip()
    vp_key = f"verify_pw_{client_ip}"
    if vp_key in login_attempts_by_ip:
        attempts = login_attempts_by_ip[vp_key].get("attempts", [])
        recent = [t for t in attempts if time.time() - t < 300]
        if len(recent) >= 5:
            return jsonify({"error": "Too many attempts. Try again in 5 minutes."}), 429
        login_attempts_by_ip[vp_key] = {"attempts": recent + [time.time()]}
    else:
        login_attempts_by_ip[vp_key] = {"attempts": [time.time()]}

    data = request.get_json() or {}
    password = data.get("password", "")

    username = _req_session()["user"]
    # (perf) indexed single-row fetch — load_users() scanned/decrypted all users
    user = get_user_record(username)

    auth_source = user.get("auth_source", "local")
    # (#587): OIDC/Entra admins have no local password - they re-auth via the
    # ladder below (WebAuthn / TOTP / session fallback). The old unconditional
    # "Password required" 400 fired before we even knew the auth source, so the
    # Re-Configure Cluster flow just hung for SSO admins. Only require it for local/ldap.
    if not password and auth_source in ("local", "ldap"):
        return jsonify({"error": "Password required"}), 400

    if auth_source == "local":
        if not user.get("password_hash") or not verify_password(
            password, user.get("password_salt", ""), user["password_hash"]
        ):
            return jsonify({"error": "Invalid password"}), 401
    elif auth_source == "ldap":
        from ProxmoxVEx.utils.ldap import ldap_authenticate

        result = ldap_authenticate(username, password)
        if "error" in result:
            return jsonify({"error": "Invalid password"}), 401
    elif auth_source in ("oidc", "entra"):
        # May 2026: stolen-cookie replay risk - the original "session valid → accept"
        # made re-auth a no-op for OIDC users. attacker with the cookie passes the gate
        # for sensitive ops (delete cluster, rotate creds, etc).
        # (v0.9.9.1 follow-up) - TOTP step-up was wrong as a hard
        # requirement: ProxmoxVEx blocks OIDC users from enrolling TOTP at /2fa/setup
        # ("2FA is managed by your OIDC provider"), so a strict TOTP gate locks
        # OIDC admins out of re-auth-gated ops entirely. Correct ladder:
        #   1. WebAuthn proof (works regardless of auth_source — independent enrolment)
        #   2. TOTP if the user happens to have one (e.g. ex-local user converted to OIDC)
        #   3. Fall back to session-validity acceptance + warning log so the
        #      admin can see the soft state in the audit trail.
        # Properly fixing #3 requires an OIDC `prompt=login` redirect flow which
        # is a bigger piece of work — tracked separately.
        if user.get("role") != "admin":
            return jsonify({"error": "Admin access required"}), 403

        # Path A: WebAuthn proof token (preferred for OIDC users)
        webauthn_proof = (data.get("webauthn_proof") or "")[:256]
        try:
            db = get_db()
            wa_row = db.query("SELECT COUNT(*) AS n FROM webauthn_credentials WHERE username = ?", (username,))
            has_webauthn = bool(wa_row and wa_row[0]["n"] > 0)
        except Exception:
            has_webauthn = False

        if has_webauthn:
            if not webauthn_proof:
                return jsonify({
                    "error": "WebAuthn verification required for re-authentication",
                    "requires_webauthn": True,
                }), 401
            from ProxmoxVEx.api.webauthn import consume_webauthn_proof

            if not consume_webauthn_proof(username, webauthn_proof):
                logging.warning(f"[AUTH] OIDC re-auth bad WebAuthn proof for admin '{username}'")
                return jsonify({"error": "Invalid WebAuthn proof"}), 401
            logging.info(f"[AUTH] OIDC re-auth via WebAuthn for admin '{username}'")

        # Path B: TOTP if available (ex-local users still carry a totp_secret)
        elif user.get("totp_secret"):
            totp_code = (data.get("totp_code") or "").strip()
            if not totp_code:
                return jsonify({
                    "error": "TOTP code required for re-authentication",
                    "requires_totp": True,
                }), 401
            try:
                import pyotp

                if not pyotp.TOTP(user["totp_secret"]).verify(totp_code, valid_window=1):
                    logging.warning(f"[AUTH] OIDC re-auth bad TOTP for admin '{username}'")
                    return jsonify({"error": "Invalid TOTP code"}), 401
            except Exception as e:
                logging.error(f"[AUTH] TOTP verify error for '{username}': {e}")
                return jsonify({"error": "TOTP verification failed"}), 500
            logging.info(f"[AUTH] OIDC re-auth via TOTP for admin '{username}'")

        # Path C: nothing local enrolled — accept on session validity, but log it
        # loudly. OIDC admins who care about replay-resistance should register a
        # WebAuthn credential (Settings → Account → Security keys).
        else:
            logging.warning(
                f"[AUTH] OIDC re-auth on session-validity only for admin '{username}' "
                "(no WebAuthn / TOTP enrolled — recommend WebAuthn enrolment)"
            )
    else:
        return jsonify({"error": "Password verification not supported for this account type"}), 400

    return jsonify({"success": True})


@bp.route("/api/auth/change-password", methods=["POST"])
@require_auth()
def auth_change_password():
    """Change current user's password

    Security feature - invalidates all other sessions after password change
    This way if someone stole your session, changing password kicks them out
    """
    data = request.get_json()
    current_password = data.get("current_password", "")
    new_password = data.get("new_password", "")

    if not current_password or not new_password:
        return jsonify({"error": "Current and new password required"}), 400

    # Validate password policy
    is_valid, error_msg = validate_password_policy(new_password)
    if not is_valid:
        return jsonify({"error": error_msg}), 400

    username = _req_session()["user"]

    # Rate limit this - someone with a stolen session could brute-force the current password
    if not check_auth_action_rate_limit(f"pwd_change:{username}", max_attempts=5, window=300):
        return jsonify({"error": "Too many password change attempts. Try again in 5 minutes."}), 429

    # (perf) indexed single-row fetch — load_users() scanned/decrypted all users
    user = get_user_record(username)

    if not user:
        return jsonify({"error": "User not found"}), 404


    # LDAP/OIDC users cannot change their password here - they must change it in their identity provider
    if user.get("auth_source", "local") in ("ldap", "oidc", "entra"):
        provider_name = {
            "ldap": "LDAP/Active Directory",
            "oidc": "your OIDC provider",
            "entra": "Microsoft Entra ID",
        }.get(user["auth_source"], "your identity provider")
        # snyk:ignore:Cross-site Scripting (XSS)
        return jsonify({"error": f"Password is managed by {provider_name}. Please change it there."}), 400

    # Verify current password
    if not verify_password(current_password, user["password_salt"], user["password_hash"]):
        log_audit(username, "user.password_change_failed", "Incorrect current password")
        return jsonify({"error": "Current password is incorrect"}), 401

    # Update password
    salt, password_hash = hash_password(new_password)
    user["password_salt"] = salt
    user["password_hash"] = password_hash
    user["password_changed_at"] = datetime.now().isoformat()  # Reset expiry timer

    # Clear forced password change flag (#144)
    if user.get("force_password_change"):
        user["force_password_change"] = False

    # Mark admin initialized if this is the default admin
    if user.get("is_default"):
        user["is_default"] = False
        mark_admin_initialized()

    save_user_record(username, user)

    # 2026-04-24 - security audit finding #1: invalidate ALL sessions including the
    # caller's current one. If a stolen cookie is the one changing the password, we don't
    # want it to keep access. Frontend reads relogin_required and redirects to /login.
    sessions_removed = invalidate_all_user_sessions(username)  # no except_session — all go
    # A credential change also drops every trusted-device key: the new
    # password era must start with a fresh 2FA proof on each device.
    revoke_trusted_devices(username)

    logging.info(f"User '{username}' changed their password — all sessions invalidated")
    log_audit(
        username,
        "user.password_changed",
        f"Password changed, {sessions_removed} session(s) invalidated (incl. current)",
    )

    resp = jsonify({
        "success": True,
        "sessions_invalidated": sessions_removed,
        "relogin_required": True,  # UI hint
    })
    # drop the session cookie so the browser stops sending the now-dead SID
    resp.delete_cookie("session_id")
    return resp


# ============================================
# TOTP 2FA API Routes
# ============================================


@bp.route("/api/auth/2fa/setup", methods=["POST"])
@require_auth()
def setup_2fa():
    """Generate TOTP secret and QR code for 2FA setup"""

    if not TOTP_AVAILABLE:
        return jsonify({
            "error": "2FA not available. Please install pyotp and qrcode: pip install pyotp qrcode[pil]"
        }), 500

    # Optional deps imported after the availability guard so the names are
    # unconditionally bound here (module-level try/except left them unbound).
    import io as _io

    import pyotp
    import qrcode

    username = _req_session()["user"]
    logging.info(f"2FA setup requested for user: {username}")  # Debug
    # (perf) indexed single-row fetch — load_users() scanned/decrypted all users
    user = get_user_record(username)

    if not user:
        logging.warning(f"2FA setup failed - user not found: {username}")
        return jsonify({"error": "User not found"}), 404


    # OIDC/Entra users should use their IdP's MFA, not ProxmoxVEx 2FA
    # ProxmoxVEx 2FA only works for login form (LDAP + local), not OIDC redirect flow
    if user.get("auth_source", "local") in ("oidc", "entra"):
        provider_name = "Microsoft Entra ID" if user.get("auth_source") == "entra" else "your OIDC provider"
        # snyk:ignore:Cross-site Scripting (XSS)
        return jsonify({"error": f"2FA is managed by {provider_name}. Please enable MFA there instead."}), 400

    # Generate new secret
    secret = pyotp.random_base32()

    # Store pending secret (not activated yet)
    user["totp_pending_secret"] = secret
    save_user_record(username, user)
    logging.info(f"2FA setup: saved pending secret for user {username}")  # Debug

    # Generate provisioning URI
    totp = pyotp.TOTP(secret)
    uri = totp.provisioning_uri(name=username, issuer_name="ProxmoxVEx")

    # Generate QR code as base64
    qr = qrcode.QRCode(version=1, box_size=10, border=5)
    qr.add_data(uri)
    qr.make(fit=True)
    img = qr.make_image(fill_color="black", back_color="white")

    buffer = _io.BytesIO()
    try:
        # qrcode's pure-python PyPNGImage (no PIL) lacks the `format` kwarg —
        # the except TypeError retry below is intentional, not a bug.
        img.save(buffer, format="PNG")  # type: ignore
    except TypeError:
        img.save(buffer)
    qr_base64 = base64.b64encode(buffer.getvalue()).decode()

    return jsonify({"secret": secret, "qr_code": f"data:image/png;base64,{qr_base64}", "uri": uri})


@bp.route("/api/auth/2fa/verify", methods=["POST"])
@require_auth()
def verify_2fa_setup():
    """Verify TOTP code and activate 2FA"""

    if not TOTP_AVAILABLE:
        return jsonify({"error": "2FA not available"}), 500

    import pyotp  # local import: optional dep guarded by TOTP_AVAILABLE

    data = request.get_json()
    code = data.get("code", "") if data else ""

    if not code:
        logging.warning("2FA verify: no code provided")  # Debug
        return jsonify({"error": "TOTP code required"}), 400

    username = _req_session()["user"]

    # Only 1M possible 6-digit codes, easy to brute force without this
    # Tightened from 5/300s to 3/120s - reduces brute-force success probability
    if not check_auth_action_rate_limit(f"totp_verify:{username}", max_attempts=3, window=120):
        return jsonify({"error": "Too many verification attempts. Try again in 2 minutes."}), 429

    logging.info(f"2FA verify requested for user: {username}, code length: {len(code)}")  # Debug
    # (perf) indexed single-row fetch — load_users() scanned/decrypted all users
    user = get_user_record(username)

    if not user:
        logging.warning(f"2FA verify: user not found: {username}")
        return jsonify({"error": "User not found"}), 404

    pending_secret = user.get("totp_pending_secret")

    if not pending_secret:
        logging.warning(f"2FA verify: no pending secret for user {username}. User keys: {list(user.keys())}")  # Debug
        return jsonify({"error": "No pending 2FA setup"}), 400

    # Verify the code
    totp = pyotp.TOTP(pending_secret)
    if not totp.verify(code, valid_window=1):
        return jsonify({"error": "Invalid TOTP code"}), 401

    # Activate 2FA
    user["totp_secret"] = pending_secret
    user["totp_enabled"] = True
    del user["totp_pending_secret"]

    # Spec 088 FR-003: issue one-time recovery codes at enrollment — the
    # escape hatch that keeps a broken authenticator from locking the last
    # admin out. Plaintext is returned exactly once; only hashes persist.
    recovery_plain, recovery_hashes = _generate_recovery_codes()
    user["totp_recovery_codes"] = recovery_hashes
    save_user_record(username, user)

    logging.info(f"User '{username}' enabled 2FA")
    log_audit(username, "2fa.enabled", "User enabled 2FA")

    return jsonify({"success": True, "message": "2FA enabled", "recovery_codes": recovery_plain})


@bp.route("/api/auth/2fa/disable", methods=["POST"])
@require_auth()
def disable_2fa():
    """Disable 2FA for current user"""

    data = request.get_json()
    password = data.get("password", "")

    if not password:
        return jsonify({"error": "Password required to disable 2FA"}), 400

    username = _req_session()["user"]

    # Same issue as pwd change - stolen session + unlimited guesses = bad
    if not check_auth_action_rate_limit(f"2fa_disable:{username}", max_attempts=5, window=300):
        return jsonify({"error": "Too many attempts. Try again in 5 minutes."}), 429

    # (perf) indexed single-row fetch — load_users() scanned/decrypted all users
    user = get_user_record(username)

    if not user:
        return jsonify({"error": "User not found"}), 404


    # OIDC/Entra users manage MFA through their IdP - shouldn't have ProxmoxVEx 2FA
    if user.get("auth_source", "local") in ("oidc", "entra"):
        return jsonify({"error": "2FA is managed by your identity provider"}), 400

    # LDAP users verify against LDAP (they have no local password hash)
    if user.get("auth_source") == "ldap":
        ldap_result = ldap_authenticate(username, password)
        if not ldap_result.get("success"):
            return jsonify({"error": "Invalid LDAP password"}), 401
    else:
        # Local users verify against local password hash
        if not verify_password(password, user["password_salt"], user["password_hash"]):
            return jsonify({"error": "Invalid password"}), 401

    # Disable 2FA — also burn any recovery codes so they can't outlive the
    # factor they recover.
    user["totp_enabled"] = False
    user.pop("totp_secret", None)
    user.pop("totp_pending_secret", None)
    user.pop("totp_recovery_codes", None)
    save_user_record(username, user)
    # Burn trusted-device keys too — they exist to satisfy a factor that no
    # longer exists, and must not survive a re-enable.
    revoke_trusted_devices(username)

    logging.info(f"User '{username}' disabled 2FA")
    log_audit(username, "2fa.disabled", "User disabled 2FA")

    return jsonify({"success": True, "message": "2FA disabled"})


@bp.route("/api/auth/2fa/status", methods=["GET"])
@require_auth()
def get_2fa_status():
    """Get 2FA status for current user"""
    username = _req_session()["user"]
    # (perf) indexed single-row fetch — load_users() scanned/decrypted all users
    user = get_user_record(username)

    if not user:
        return jsonify({"error": "User not found"}), 404


    return jsonify({
        "enabled": user.get("totp_enabled", False),
        "available": TOTP_AVAILABLE,
        "recovery_codes_remaining": len(user.get("totp_recovery_codes") or []),
    })


# =====================================================
# USER PREFERENCES - # Per-user settings (theme, language)
# =====================================================

# =============================================================================
# API Token Management Endpoints
# Users can create tokens for CI/CD, scripts, monitoring integrations
# Admins can see all tokens, users can only manage their own
# =============================================================================


@bp.route("/api/auth/tokens", methods=["GET"])
@require_auth()
def list_api_tokens():
    """List API tokens for current user (or all users for admin)"""
    ensure_api_tokens_table()
    username = _req_session()["user"]
    _req_session().get("role", ROLE_VIEWER)

    # 2026-06-10 (RBAC): the admin.api perm (not the admin role) sees all tokens - admin holds it via all-perms.
    from ProxmoxVEx.utils.rbac import has_permission as _has_perm

    if _has_perm(get_user_record(username), "admin.api") and request.args.get("all") == "true":
        try:
            db = get_db()
            cursor = db.conn.cursor()
            cursor.execute("""
                SELECT id, token_prefix, username, name, role, permissions, scopes, expires_at,
                       last_used_at, last_used_ip, created_at, revoked
                FROM api_tokens ORDER BY created_at DESC
            """)
            tokens = [dict(row) for row in cursor.fetchall()]
            return jsonify({"tokens": tokens})
        except Exception:
            logging.exception("Failed to list tokens")
            return jsonify({"error": "Failed to list tokens"}), 500

    tokens = list_user_tokens(username)
    return jsonify({"tokens": tokens})


@bp.route("/api/auth/tokens", methods=["POST"])
@require_auth()
def create_api_token_endpoint():
    """Create a new API token for the current user"""
    username = _req_session()["user"]
    data = request.get_json() or {}

    token_name = data.get("name", "").strip()
    if not token_name:
        return jsonify({"error": "Token name is required"}), 400

    if len(token_name) > 64:
        return jsonify({"error": "Token name too long (max 64 chars)"}), 400

    # Check for duplicate names
    existing = list_user_tokens(username)
    active_names = [t["name"] for t in existing if not t.get("revoked")]
    if token_name in active_names:
        # snyk:ignore:Cross-site Scripting (XSS)
        return jsonify({"error": f'Token name "{token_name}" already exists'}), 400

    # Max 10 active tokens per user
    active_count = sum(1 for t in existing if not t.get("revoked"))
    if active_count >= 1:
        return jsonify({"error": "You already have an active token. Revoke it first to create a new one."}), 400

    role = data.get("role")
    expires_days = data.get("expires_days")
    scopes = data.get("scopes")

    if expires_days is not None:
        try:
            expires_days = int(expires_days)
            if expires_days < 1 or expires_days > 365:
                return jsonify({"error": "Expiry must be between 1 and 365 days"}), 400
        except (ValueError, TypeError):
            return jsonify({"error": "Invalid expires_days value"}), 400

    # (#085) Optional scope list — absent = unscoped legacy token (full
    # access); an explicit list confines the token to <area>:<read|write>
    # grants enforced by require_auth on every request.
    if scopes is not None:
        try:
            from ProxmoxVEx.utils.scopes import validate_scopes

            scopes = validate_scopes(scopes)
        except ValueError as e:
            return jsonify({"error": str(e)}), 400

    result = create_api_token(username, token_name, role=role, expires_days=expires_days, scopes=scopes)

    if "error" in result:
        return jsonify(result), 400

    # Audit log
    log_audit(
        username,
        "token.created",
        f"API token '{token_name}' created"
        + (f" with scopes {scopes}" if scopes is not None else " (unscoped)"),
    )

    return jsonify(result)


@bp.route("/api/auth/token-scopes", methods=["GET"])
@require_auth()
def token_scope_catalog():
    """(#085) Return the selectable scope catalog for the token-create UI.

    The map is a display hint, not an allowlist — required_scope() derives
    areas dynamically from request paths, so scopes for unlisted areas
    (e.g. native integration module ids) are valid too.
    """
    from ProxmoxVEx.utils.scopes import SCOPE_CATALOG

    return jsonify({"scopes": SCOPE_CATALOG})


@bp.route("/api/auth/tokens/<int:token_id>", methods=["DELETE"])
@require_auth()
def revoke_api_token_endpoint(token_id):
    """Revoke an API token"""
    username = _req_session()["user"]
    _req_session().get("role", ROLE_VIEWER)

    # 2026-06-10 (RBAC): the admin.api perm can revoke any token (admin holds it via all-perms).
    from ProxmoxVEx.utils.rbac import has_permission as _has_perm

    if _has_perm(get_user_record(username), "admin.api"):
        try:
            db = get_db()
            cursor = db.conn.cursor()
            cursor.execute("SELECT username, name FROM api_tokens WHERE id = ?", (token_id,))
            row = cursor.fetchone()
            if row:
                cursor.execute("UPDATE api_tokens SET revoked = 1 WHERE id = ?", (token_id,))
                db.conn.commit()
                token_owner = dict(row)["username"]
                token_name = dict(row)["name"]
                log_audit(username, "token.revoked", f"Revoked API token '{token_name}' (user: {token_owner})")
                return jsonify({"success": True})
            return jsonify({"error": "Token not found"}), 404
        except Exception:
            logging.exception("Failed to revoke token")
            return jsonify({"error": "Failed to revoke token"}), 500

    if revoke_api_token(token_id, username):
        log_audit(username, "token.revoked", f"Revoked API token id={token_id}")
        return jsonify({"success": True})
    return jsonify({"error": "Token not found or not owned by you"}), 404


# GET /api/user/preferences is in users.py (has full implementation)
