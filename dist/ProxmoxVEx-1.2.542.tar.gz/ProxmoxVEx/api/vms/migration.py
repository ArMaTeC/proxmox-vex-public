# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/api/vms/migration.py
# Project:     ProxmoxVEx
# Version:     1.2.535
# Build:       2026.09.26
# Description: migration routes for the vms API (split from
#              api/vms.py).
# Usage:       import ProxmoxVEx.api.vms.migration
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-26
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""migration routes for the vms API (split from api/vms.py)."""

import logging
import threading

from flask import jsonify

from ProxmoxVEx.api.helpers import check_cluster_access, register_task_user
from ProxmoxVEx.globals import cluster_managers
from ProxmoxVEx.utils.audit import log_audit
from ProxmoxVEx.utils.auth import get_user_record, require_auth
from ProxmoxVEx.utils.rbac import user_can_access_vm
from ProxmoxVEx.utils.realtime import broadcast_action, push_immediate_update
from ProxmoxVEx.utils.stepup import require_stepup

from .common import (
    _access_denied,
    _api_error,
    _require_vm_access,
    bp,
    request,
)


# Migration API Routes
@bp.route("/api/clusters/<cluster_id>/vms/<node>/<vm_type>/<int:vmid>/migrate", methods=["POST"])
@require_auth(perms=["vm.migrate"])
def migrate_vm_api(cluster_id, node, vm_type, vmid):
    """Migrate a VM or container to another node"""
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()
    if cluster_id not in cluster_managers:
        # lgtm[py/reflected-xss]
        return jsonify({"error": "Cluster not found"}), 404

    # Check pool permission for vm.migrate
    # (perf) indexed single-row fetch — load_users() scanned/decrypted all users
    user = get_user_record(request.session["user"])
    user["username"] = request.session["user"]
    if not user_can_access_vm(user, cluster_id, vmid, "vm.migrate", vm_type):
        # lgtm[py/reflected-xss]
        return jsonify({"error": "Permission denied: vm.migrate"}), 403

    try:
        manager = cluster_managers[cluster_id]
        data = request.json or {}
        target_node = data.get("target")
        online = data.get("online", True)

        if not target_node:
            # lgtm[py/reflected-xss]
            return jsonify({"error": "Target node is required"}), 400

        target_storage = data.get("targetstorage")
        with_local_disks = data.get("with-local-disks", False)
        force = data.get("force", False)  # For conntrack state in containers

        # Affinity rule enforcement (Issue
        from ProxmoxVEx.api.history import check_affinity_violation

        aff = check_affinity_violation(cluster_id, vmid, target_node)
        if aff.get("violation"):
            if aff.get("enforce"):
                # lgtm[py/reflected-xss]
                return jsonify({
                    "error": f"Migration blocked by affinity rule '{aff['rule']}': {aff['message']}",
                    "affinity_violation": True,
                    "rule": aff["rule"],
                }), 409
            else:
                # Just warn, don't block
                logging.warning(f"Affinity warning for VMID {vmid} -> {target_node}: {aff['message']} (not enforced)")

        migrate_options = {
            "online": online,
            "targetstorage": target_storage,
            "with_local_disks": with_local_disks,
            "force": force,
        }
        result = manager.migrate_vm_manual(node, vmid, vm_type, target_node, online, migrate_options)

        if result.get("success"):
            # Audit log
            user = getattr(request, "session", {}).get("user", "system")
            details = f"{vm_type.upper()} {vmid} migrated from {node} to {target_node}"
            if online:
                details += " (online)"
            log_audit(user, "vm.migrated", details, cluster=manager.config.name)

            # Register ProxmoxVEx user for this task
            upid = result.get("upid") or result.get("task") or result.get("data")
            if upid:
                register_task_user(upid, user, cluster_id)

            push_immediate_update(cluster_id, delay=0.5)
            # lgtm[py/reflected-xss]
            return jsonify(result)
        else:
            # lgtm[py/reflected-xss]
            return jsonify(result), 400
    except Exception as e:
        logging.error(f"[MIGRATE] Unhandled error migrating {vm_type}/{vmid}: {e}", exc_info=True)
        # lgtm[py/reflected-xss]
        return jsonify({"error": "Migration failed"}), 500


@bp.route("/api/clusters/<cluster_id>/vms/<node>/<vm_type>/<int:vmid>", methods=["DELETE"])
@require_auth(perms=["vm.delete"])
def delete_vm_api(cluster_id, node, vm_type, vmid):
    denied = require_stepup("guest.delete")
    if denied is not None:
        return denied
    # tenant check
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()

    if cluster_id not in cluster_managers:
        # lgtm[py/reflected-xss]
        return jsonify({"error": "Cluster not found"}), 404

    # Check pool permission for vm.delete
    # (perf) indexed single-row fetch — load_users() scanned/decrypted all users
    user = get_user_record(request.session["user"])
    user["username"] = request.session["user"]
    if not user_can_access_vm(user, cluster_id, vmid, "vm.delete", vm_type):
        # lgtm[py/reflected-xss]
        return jsonify({"error": "Permission denied: vm.delete"}), 403

    manager = cluster_managers[cluster_id]
    data = request.json or {}
    purge = data.get("purge", False)
    destroy_unreferenced = data.get("destroyUnreferenced", False)

    result = manager.delete_vm(node, vmid, vm_type, purge, destroy_unreferenced)

    if result.get("success"):
        usr = getattr(request, "session", {}).get("user", "system")
        log_audit(
            usr,
            "vm.deleted",
            f"{vm_type.upper()} {vmid} deleted from {node}" + (" (purged)" if purge else ""),
            cluster=manager.config.name,
        )
        broadcast_action("delete", vm_type, str(vmid), {"node": node, "purge": purge}, cluster_id, usr)

        # Register ProxmoxVEx user for this task
        upid = result.get("task") or result.get("upid") or result.get("data")
        if upid:
            register_task_user(upid, usr, cluster_id)

        # Push immediate update for live UI
        push_immediate_update(cluster_id, delay=0.5)

        # lgtm[py/reflected-xss]
        return jsonify({"message": f"{vm_type.upper()} {vmid} deleted", "task": result.get("task")})
    else:
        # lgtm[py/reflected-xss]
        return jsonify({
            "error": result.get("error", "Delete failed")
        }), 500  # snyk:ignore:Cross-site Scripting (XSS)  # snyk:ignore:Server Information Exposure


@bp.route("/api/clusters/<cluster_id>/vms/bulk-migrate", methods=["POST"])
@require_auth(perms=["vm.migrate"])
def bulk_migrate_api(cluster_id):
    """Migrate multiple VMs at once"""
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()

    if cluster_id not in cluster_managers:
        # lgtm[py/reflected-xss]
        return jsonify({"error": "Cluster not found"}), 404

    mgr = cluster_managers[cluster_id]
    data = request.json or {}
    vms = data.get("vms", [])  # List of {node, vmid, type}
    # (pentest DoS) - cap the batch so one request can't fan out unbounded
    # per-VM cluster-walk + SQLCipher work (a 10 MB body could carry tens of thousands
    # of entries). 1000 is far above any realistic bulk migrate; split larger jobs.
    if isinstance(vms, list) and len(vms) > 1000:
        # lgtm[py/reflected-xss]
        return jsonify({"error": "Too many VMs in one request (max 1000). Split into smaller batches."}), 400
    target_node = data.get("target")
    online = data.get("online", True)

    if not target_node:
        # lgtm[py/reflected-xss]
        return jsonify({"error": "Target node is required"}), 400

    if not vms:
        # lgtm[py/reflected-xss]
        return jsonify({"error": "No VMs specified"}), 400

    user = getattr(request, "session", {}).get("user", "system")
    log_audit(user, "vm.bulk_migrated", f"Bulk migration of {len(vms)} VMs to {target_node}", cluster=mgr.config.name)

    # Enforced violations skip that VM but don't abort the whole batch
    from ProxmoxVEx.api.history import check_affinity_violation

    results = []
    for vm in vms:
        # Affinity check per VM
        aff = check_affinity_violation(cluster_id, vm["vmid"], target_node)
        if aff.get("violation") and aff.get("enforce"):
            results.append({
                "vmid": vm["vmid"],
                "success": False,
                "task": None,
                "error": f"Blocked by affinity rule '{aff['rule']}': {aff['message']}",
            })
            continue
        elif aff.get("violation"):
            logging.warning(f"Affinity warning for VMID {vm['vmid']} -> {target_node}: {aff['message']} (not enforced)")

        result = mgr.migrate_vm_manual(vm["node"], vm["vmid"], vm["type"], target_node, online)

        # Register ProxmoxVEx user for each migration task
        if result.get("task") or result.get("upid"):
            register_task_user(result.get("task") or result.get("upid"), user, cluster_id)

        results.append({
            "vmid": vm["vmid"],
            "success": result.get("success", False),
            "task": result.get("task"),
            "error": result.get("error"),
        })

    # Push immediate update for live UI (all migrations started)
    push_immediate_update(cluster_id, delay=0.5)

    # lgtm[py/reflected-xss]
    return jsonify({"results": results, "total": len(vms), "successful": sum(1 for r in results if r["success"])})


@bp.route("/api/clusters/<cluster_id>/fingerprint", methods=["GET"])
@require_auth(perms=["cluster.view"])
def get_cluster_fingerprint_api(cluster_id):
    """Get cluster SSL fingerprint for remote migration"""
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()
    if cluster_id not in cluster_managers:
        # lgtm[py/reflected-xss]
        return jsonify({"error": "Cluster not found"}), 404

    manager = cluster_managers[cluster_id]
    result = manager.get_cluster_fingerprint()

    if result.get("success"):
        # lgtm[py/reflected-xss]
        return jsonify(result)
    else:
        # lgtm[py/reflected-xss]
        return jsonify({
            "error": result.get("error", "Failed: fingerprint")
        }), 500  # snyk:ignore:Cross-site Scripting (XSS)  # snyk:ignore:Server Information Exposure


@bp.route("/api/clusters/<cluster_id>/vms/<node>/<vm_type>/<int:vmid>/remote-migrate", methods=["POST"])
@require_auth(perms=["vm.migrate"])
def remote_migrate_vm_api(cluster_id, node, vm_type, vmid):
    """Cross-cluster remote migration"""
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()
    if cluster_id not in cluster_managers:
        # lgtm[py/reflected-xss]
        return jsonify({"error": "Cluster not found"}), 404

    # (route-authz contract) - cross-cluster migrate is state-changing on
    # this VM; gate it per-VM like the local migrate/clone routes (was missing).
    denied = _require_vm_access(cluster_id, vmid, "vm.migrate", vm_type)
    if denied:
        # lgtm[py/reflected-xss]
        return denied

    manager = cluster_managers[cluster_id]
    data = request.json or {}

    target_endpoint = data.get("target_endpoint")
    target_storage = data.get("target_storage")
    target_bridge = data.get("target_bridge")
    target_vmid = data.get("target_vmid")
    online = data.get("online", True)
    delete_source = data.get("delete_source", True)
    bwlimit = data.get("bwlimit")

    if not all([target_endpoint, target_storage, target_bridge]):
        # lgtm[py/reflected-xss]
        return jsonify({"error": "target_endpoint, target_storage, and target_bridge are required"}), 400

    result = manager.remote_migrate_vm(
        node, vmid, vm_type, target_endpoint, target_storage, target_bridge, target_vmid, online, delete_source, bwlimit
    )

    if result.get("success"):
        # Register ProxmoxVEx user for this task
        user = getattr(request, "session", {}).get("user", "system")
        upid = result.get("task") or result.get("upid")
        if upid:
            register_task_user(upid, user, cluster_id)

        # Push immediate update for live UI
        push_immediate_update(cluster_id, delay=0.5)

        # lgtm[py/reflected-xss]
        return jsonify({"message": f"Remote migration started for {vm_type}/{vmid}", "task": result.get("task")})
    else:
        # lgtm[py/reflected-xss]
        return jsonify({
            "error": result.get("error", "Remote migration failed")
        }), 500  # snyk:ignore:Cross-site Scripting (XSS)  # snyk:ignore:Server Information Exposure


@bp.route("/api/cross-cluster-migrate", methods=["POST"])
@require_auth(perms=["vm.migrate"])
def cross_cluster_migrate_api():
    """
    High-level cross-cluster migration API

    This is the fancy one - migrates VMs between completely separate
    Proxmox clusters using SSH tunnels. Takes care of:
    - Creating temp API tokens on target
    - Setting up SSH tunnel for migration traffic
    - Cleaning up tokens after migration

    Known issue: For large VMs (>50GB disk), online migration may fail with
    "401 Unauthorized" during RAM sync due to Proxmox WebSocket ticket timeout.
    Workaround: Use offline migration for large VMs.
    """
    data = request.json or {}

    source_cluster_id = data.get("source_cluster")
    target_cluster_id = data.get("target_cluster")
    vmid = data.get("vmid")
    vm_type = data.get("vm_type", "qemu")
    source_node = data.get("source_node")
    target_node = data.get("target_node")
    target_storage = data.get("target_storage")
    # per-storage mapping: {"local-lvm": "ceph-pool", "local": "nfs-stor"} → PVE format "local-lvm:ceph-pool,local:nfs-stor"
    storage_map = data.get("target_storage_map")
    if storage_map and isinstance(storage_map, dict):
        target_storage = ",".join(f"{s}:{t}" for s, t in storage_map.items())
    # per-NIC bridge mapping: {"vmbr0": "vmbr1", "vmbr1": "vmbr2"} → PVE format "vmbr0:vmbr1,vmbr1:vmbr2"
    # Was using = instead of : (#274), PVE remote_migrate uses same format as target-storage
    bridge_map = data.get("target_bridge_map")
    if bridge_map and isinstance(bridge_map, dict):
        target_bridge = ",".join(f"{s}:{t}" for s, t in bridge_map.items())
    else:
        target_bridge = data.get("target_bridge", "vmbr0")
    target_vmid = data.get("target_vmid")
    online = data.get("online", True)
    force_online = data.get("force_online", False)  # Override automatic offline for large disks
    delete_source = data.get("delete_source", True)
    bwlimit = data.get("bwlimit", 0)  # 0 = no limit (maximum speed to beat ticket timeout)

    if not target_node:
        # lgtm[py/reflected-xss]
        return jsonify({"error": "Target node is required for cross-cluster migration"}), 400

    if source_cluster_id not in cluster_managers:
        # lgtm[py/reflected-xss]
        return jsonify({"error": "Source cluster not found"}), 404
    if target_cluster_id not in cluster_managers:
        # lgtm[py/reflected-xss]
        return jsonify({"error": "Target cluster not found"}), 404
    # Check access to BOTH source and target cluster
    ok, err = check_cluster_access(source_cluster_id)
    if not ok:
        return _access_denied()
    ok, err = check_cluster_access(target_cluster_id)
    if not ok:
        return _access_denied()

    source_manager = cluster_managers[source_cluster_id]
    target_manager = cluster_managers[target_cluster_id]

    # Check VM disk size and warn about potential issues with online migration
    warnings = []
    try:
        vm_info = source_manager.get_vm_config(source_node, vmid, vm_type)
        if vm_info.get("success"):
            config = vm_info.get("config", {})
            total_disk_gb = 0
            for key, value in config.items():
                if key.startswith(("scsi", "virtio", "sata", "ide", "efidisk", "tpmstate")) and "size" in str(value):
                    # Extract size from disk config
                    import re

                    size_match = re.search(r"size=(\d+)([GMT])", str(value))
                    if size_match:
                        size_val = int(size_match.group(1))
                        size_unit = size_match.group(2)
                        if size_unit == "G":
                            total_disk_gb += size_val
                        elif size_unit == "T":
                            total_disk_gb += size_val * 1024
                        elif size_unit == "M":
                            total_disk_gb += size_val / 1024

            if total_disk_gb > 100 and online and not force_online:
                # Proxmox WebSocket tickets have internal timeout (~5 min)
                # Large disk migrations take longer than this, causing 401 errors
                # during RAM sync phase. Auto-switch to offline migration.
                #
                # Math: 100GB in 5 min = 333 MB/s = ~2.7 Gbit/s sustained
                # Most cross-cluster links can't sustain this.
                required_speed_mbps = (total_disk_gb * 1024) / 300  # MB/s needed for 5 min
                warnings.append(
                    f"VM has {total_disk_gb:.0f}GB disk. Would need {required_speed_mbps:.0f} MB/s ({required_speed_mbps * 8 / 1000:.1f} Gbit/s) to complete in 5 min. Automatically using offline migration."
                )
                logging.warning(
                    f"[CROSS-MIGRATE] Large VM ({total_disk_gb}GB) - forcing offline migration due to Proxmox WebSocket ticket timeout limitation"
                )
                online = False  # Force offline migration for large disks
            elif total_disk_gb > 100 and online and force_online:
                required_speed_mbps = (total_disk_gb * 1024) / 300
                warnings.append(
                    f"VM has {total_disk_gb:.0f}GB disk with forced online migration. Need {required_speed_mbps:.0f} MB/s sustained to avoid timeout. Migration may fail with '401 Unauthorized'."
                )
                logging.warning(
                    f"[CROSS-MIGRATE] Large VM ({total_disk_gb}GB) - online migration forced by user, may fail"
                )
    except Exception as e:
        logging.debug(f"Could not check VM size: {e}")

    # Generate unique token name
    import time

    token_name = f"ProxmoxVEx-migrate-{int(time.time())}"
    target_token = None

    try:
        # Step 1: Create temporary API token on TARGET cluster (without privilege separation)
        logging.info(
            f"Creating temporary API token on target cluster ({target_cluster_id}) for user {target_manager.config.user}..."
        )
        token_result = target_manager.create_api_token(token_name)
        if not token_result.get("success"):
            # lgtm[py/reflected-xss]
            # snyk:ignore:Cross-site Scripting (XSS)
            return jsonify({
                "error": f"Could not create API token on target cluster: {token_result.get('error')}"
            }), 500  # snyk:ignore:Cross-site Scripting (XSS)  # snyk:ignore:Server Information Exposure

        target_token = token_result
        logging.info(f"Created token on target cluster: {target_token['token_id']}")

        # Step 2: Get target cluster fingerprint
        fp_result = target_manager.get_cluster_fingerprint()
        if not fp_result.get("success"):
            raise Exception(f"Could not get target fingerprint: {fp_result.get('error')}")

        # Step 3: Build target endpoint string
        # Format must be exact - Proxmox is picky about this
        # Format: apitoken=PVEAPIToken=<user>!<tokenname>=<secret>,host=<host>,fingerprint=<fp>
        target_endpoint = (
            f"apitoken=PVEAPIToken={target_token['token_id']}={target_token['token_value']},"
            f"host={fp_result['host']},"
            f"fingerprint={fp_result['fingerprint']}"
        )

        logging.info(
            f"Starting remote migration of {vm_type}/{vmid} from {source_cluster_id} to {target_cluster_id}..."
        )
        logging.info(
            f"Target host: {fp_result['host']}, Token user: {target_token['token_id'].split('!')[0]}, Online: {online}"
        )

        # Step 4: Perform the migration
        result = source_manager.remote_migrate_vm(
            source_node,
            vmid,
            vm_type,
            target_endpoint,
            target_storage,
            target_bridge,
            target_vmid,
            online,
            delete_source,
            bwlimit,
        )

        if result.get("success"):
            # Log to audit
            user = request.session.get("user", "system")
            log_audit(
                user,
                "vm.cross_cluster_migrate",
                f"Cross-cluster migration: {vm_type}/{vmid} from {source_cluster_id} to {target_cluster_id}/{target_node}",
                request.remote_addr,
            )

            # Register ProxmoxVEx user for this task
            task_upid = result.get("task")
            if task_upid:
                register_task_user(task_upid, user, source_cluster_id)

            # Push immediate update for live UI (source cluster)
            # str() — source_cluster_id is already guaranteed non-None by the
            # `in cluster_managers` check above, but it arrives as JSON Any
            push_immediate_update(str(source_cluster_id), delay=0.5)

            # Schedule intelligent token cleanup - monitors task status
            def cleanup_token_when_done():
                import time

                max_wait = 7200  # Maximum 2 hours (large VMs can take a long time!)
                poll_interval = 15  # Check every 15 seconds
                elapsed = 0
                min_wait_before_assuming_done = 300  # Wait at least 5 minutes before assuming task is done

                logging.info(f"[TOKEN-CLEANUP] Monitoring task {task_upid} for completion...")

                while elapsed < max_wait:
                    try:
                        # Get task status from source cluster (where the migration task runs)
                        tasks = source_manager.get_tasks(limit=100)
                        task_found = False

                        for task in tasks:
                            if task and task.get("upid") == task_upid:
                                task_found = True
                                status = task.get("status", "")

                                # check task is finished
                                if status and status != "running":
                                    if status == "OK":
                                        logging.info("[TOKEN-CLEANUP] Migration task completed successfully!")
                                    else:
                                        logging.warning(f"[TOKEN-CLEANUP] Migration task ended with status: {status}")

                                    # Wait a bit more after task completion to be safe
                                    # The VM might still be syncing final state
                                    time.sleep(30)

                                    # Task finished - delete token
                                    target_manager.delete_api_token(token_name)
                                    logging.info(f"[TOKEN-CLEANUP] Deleted migration token: {token_name}")
                                    return
                                break

                        # Fix for Issue #19 - Don't delete token too early!
                        # If task not found, it might have completed and scrolled out of task list
                        # BUT we need to wait much longer to be safe (was 60s, now 5 min minimum)
                        if not task_found and elapsed > min_wait_before_assuming_done:
                            # Double-check: Try to verify VM exists on target cluster
                            try:
                                # Check if VM exists on target (migration successful)
                                target_vms = target_manager.get_vm_resources()
                                vm_on_target = any(
                                    v.get("vmid") == vmid or v.get("vmid") == target_vmid for v in (target_vms or [])
                                )
                                if vm_on_target:
                                    logging.info(
                                        "[TOKEN-CLEANUP] VM found on target cluster, migration likely successful"
                                    )
                                else:
                                    logging.info("[TOKEN-CLEANUP] VM not yet on target, waiting longer...")
                                    time.sleep(poll_interval)
                                    elapsed += poll_interval
                                    continue
                            except Exception as e:
                                logging.warning(f"[TOKEN-CLEANUP] Could not verify VM on target: {e}")

                            logging.info(
                                f"[TOKEN-CLEANUP] Task no longer in task list after {elapsed}s, assuming completed"
                            )
                            target_manager.delete_api_token(token_name)
                            logging.info(f"[TOKEN-CLEANUP] Deleted migration token: {token_name}")
                            return

                    except Exception as e:
                        logging.warning(f"[TOKEN-CLEANUP] Error checking task status: {e}")

                    time.sleep(poll_interval)
                    elapsed += poll_interval

                # Timeout - delete token anyway
                logging.warning(f"[TOKEN-CLEANUP] Timeout after {max_wait}s waiting for task, deleting token anyway")
                target_manager.delete_api_token(token_name)
                logging.info(f"[TOKEN-CLEANUP] Deleted migration token: {token_name}")

            cleanup_thread = threading.Thread(target=cleanup_token_when_done, daemon=True)
            cleanup_thread.start()

            response = {
                "message": f"Cross-cluster migration started: {vm_type}/{vmid} from {source_cluster_id} to {target_cluster_id}/{target_node}",
                "task": result.get("task"),
                "online": online,
                "info": "Temporary API token will be automatically cleaned up after migration completes.",
            }
            if warnings:
                response["warnings"] = warnings

            # lgtm[py/reflected-xss]
            return jsonify(response)
        else:
            # Migration failed - cleanup token immediately
            error_msg = result.get("error", "Cross-cluster migration failed")

            # Add helpful hint for 401 errors
            if "401" in error_msg or "Unauthorized" in error_msg or "Broken pipe" in error_msg:
                error_msg += ". If this persists, check ProxmoxVEx version (token cleanup timing was fixed in 0.6.2)"

            target_manager.delete_api_token(token_name)
            # lgtm[py/reflected-xss]
            return jsonify({
                "error": error_msg
            }), 500  # snyk:ignore:Cross-site Scripting (XSS)  # snyk:ignore:Server Information Exposure

    except Exception as e:
        # Cleanup token on any error
        if target_token:
            target_manager.delete_api_token(token_name)
        logging.error(f"Cross-cluster migration error: {e}")
        return _api_error("Cross-cluster migration failed", status=500)


@bp.route("/api/clusters/<cluster_id>/nodes-status", methods=["GET"])
@require_auth(perms=["node.view"])
def get_cluster_nodes_status_api(cluster_id):
    """Get list of nodes with status info - alternative endpoint with more details"""
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()
    if cluster_id not in cluster_managers:
        # lgtm[py/reflected-xss]
        return jsonify({"error": "Cluster not found"}), 404

    manager = cluster_managers[cluster_id]
    node_status = manager.get_node_status()

    # Return just the node names and basic info
    nodes = []
    for node_name, status in node_status.items():
        nodes.append({
            "node": node_name,
            "status": status.get("status", "unknown"),
            "cpu_percent": status.get("cpu_percent", 0),
            "mem_percent": status.get("mem_percent", 0),
        })

    # lgtm[py/reflected-xss]
    return jsonify(nodes)
