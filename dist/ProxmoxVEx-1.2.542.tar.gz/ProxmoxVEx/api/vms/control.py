# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/api/vms/control.py
# Project:     ProxmoxVEx
# Version:     1.2.535
# Build:       2026.09.26
# Description: control routes for the vms API (split from api/vms.py).
# Usage:       import ProxmoxVEx.api.vms.control
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-26
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""control routes for the vms API (split from api/vms.py)."""

import html
import logging

from flask import jsonify

from ProxmoxVEx.api.helpers import check_cluster_access, register_task_user
from ProxmoxVEx.globals import cluster_managers
from ProxmoxVEx.utils.audit import log_audit
from ProxmoxVEx.utils.auth import get_user_record, require_auth
from ProxmoxVEx.utils.rbac import user_can_access_vm
from ProxmoxVEx.utils.realtime import broadcast_action, push_immediate_update
from ProxmoxVEx.utils.sanitization import sanitize_log_message as _sl
from ProxmoxVEx.utils.stepup import require_stepup

from .common import _access_denied, bp, request


# VM Control API Routes
@bp.route("/api/clusters/<cluster_id>/vms/<node>/<vm_type>/<int:vmid>/<action>", methods=["POST"])
@require_auth()
def vm_action_api(cluster_id, node, vm_type, vmid, action):
    """Perform action on VM (start, stop, shutdown, reboot, reset, suspend, resume)

    Updated Dec 2025 - Now checks VM-specific ACLs
    """
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()
    logging.info(f"[VM-ACTION] Received: {action} on {vm_type}/{vmid} at {node}, cluster={cluster_id}")

    # check cluster access
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()

    if cluster_id not in cluster_managers:
        # lgtm[py/reflected-xss]
        return jsonify({"error": "Cluster not found"}), 404

    valid_actions = ["start", "stop", "shutdown", "reboot", "reset", "suspend", "resume"]
    if action not in valid_actions:
        # lgtm[py/reflected-xss]
        # snyk:ignore:Cross-site Scripting (XSS)
        return jsonify({
            "error": f"Invalid action. Valid actions: {valid_actions}"
        }), 400  # snyk:ignore:Cross-site Scripting (XSS)

    # Spec 038: state-changing power actions are destructive — step-up MFA.
    # start/resume only bring a guest up; everything else kills or resets it.
    if action in ("stop", "shutdown", "reboot", "reset", "suspend"):
        denied = require_stepup("guest.power")
        if denied is not None:
            return denied

    # check permission for action - now uses VM ACLs
    # (perf) indexed single-row fetch — load_users() scanned/decrypted all users
    user = get_user_record(request.session["user"])
    user["username"] = request.session["user"]  # Make sure username is set

    manager = cluster_managers[cluster_id]
    perm_map = {
        "start": "vm.start",
        "stop": "vm.stop",
        "shutdown": "vm.stop",
        "reboot": "vm.restart",
        "reset": "vm.restart",
        "suspend": "vm.stop",
        "resume": "vm.start",
    }
    required_perm = perm_map.get(action, "vm.start")

    # Use VM-specific ACL check instead of general permission
    # Added vm_type for pool permission check
    if not user_can_access_vm(user, cluster_id, vmid, required_perm, vm_type):
        logging.warning(f"[VM-ACTION] Permission denied for {request.session['user']}: {required_perm} on VM {vmid}")
        # lgtm[py/reflected-xss]
        return jsonify({"error": f"Permission denied: {html.escape(str(required_perm))}"}), 403

    # Check for force parameter (for force stop) - handle empty body gracefully
    force = False
    try:
        if request.is_json and request.data:
            data = request.get_json(silent=True) or {}
            force = data.get("force", False)
            logging.info(f"[VM-ACTION] Force parameter: {_sl(force)}, raw data: {request.data}")
    except Exception as e:
        logging.warning(f"[VM-ACTION] Error parsing body: {e}")

    logging.info(f"[VM-ACTION] Executing {action} with force={force}")
    manager = cluster_managers[cluster_id]
    try:
        result = manager.vm_action(node, vmid, vm_type, action, force=force)
    except Exception as e:
        logging.error(f"[VM-ACTION] Unhandled error: {action} on {vm_type}/{vmid}: {e}", exc_info=True)
        # lgtm[py/reflected-xss]
        return jsonify({"error": f"{html.escape(str(action))} failed"}), 500

    # If the manager resolved an empty/missing node from cluster resources,
    # use the resolved value for audit logs and real-time broadcasts.
    node = result.get("node", node)

    if result["success"]:
        # Audit log
        usr = getattr(request, "session", {}).get("user", "system")
        action_map = {
            "start": "vm.started",
            "stop": "vm.stopped",
            "shutdown": "vm.stopped",
            "reboot": "vm.restarted",
            "reset": "vm.restarted",
            "suspend": "vm.suspended",
            "resume": "vm.resumed",
        }
        log_audit(
            usr,
            action_map.get(action, f"vm.{action}"),
            f"{vm_type.upper()} {vmid} on {node} - {action}" + (" (force)" if force else ""),
            cluster=manager.config.name,
        )

        # Broadcast action to all clients for real-time updates
        broadcast_action(action, vm_type, str(vmid), {"node": node, "force": force}, cluster_id, usr)

        # Push immediate resource update for faster UI feedback
        push_immediate_update(cluster_id, delay=0.5)

        # Register which ProxmoxVEx user initiated this task
        upid = result.get("data")
        if upid:
            register_task_user(upid, usr, cluster_id)

        # lgtm[py/reflected-xss]
        return jsonify({"message": f"{action} successful for VM {vmid}", "data": result.get("data")})
    else:
        # Return 400 for client errors (like LXC reset), 500 for server errors
        error_msg = result.get("error", "Unknown error")
        status_code = 400 if "not supported" in error_msg.lower() else 500
        # lgtm[py/reflected-xss]
        return jsonify({
            "error": error_msg
        }), status_code  # snyk:ignore:Cross-site Scripting (XSS)  # snyk:ignore:Server Information Exposure


@bp.route("/api/clusters/<cluster_id>/nextid", methods=["GET"])
@require_auth(perms=["vm.view"])
def get_next_vmid_api(cluster_id):
    # check cluster access
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()

    if cluster_id not in cluster_managers:
        # lgtm[py/reflected-xss]
        return jsonify({"error": "Cluster not found"}), 404

    mgr = cluster_managers[cluster_id]
    result = mgr.get_next_vmid()

    if result["success"]:
        # lgtm[py/reflected-xss]
        return jsonify({"vmid": result["vmid"]})
    else:
        # lgtm[py/reflected-xss]
        return jsonify({
            "error": result["error"]
        }), 500  # snyk:ignore:Cross-site Scripting (XSS)  # snyk:ignore:Server Information Exposure


@bp.route("/api/clusters/<cluster_id>/vms/<node>/<vm_type>/<int:vmid>/clone", methods=["POST"])
@require_auth(perms=["vm.clone"])
def clone_vm_api(cluster_id, node, vm_type, vmid):
    """Clone a VM or container"""
    # tenant check
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()

    if cluster_id not in cluster_managers:
        # lgtm[py/reflected-xss]
        return jsonify({"error": "Cluster not found"}), 404

    # Check pool permission for vm.clone
    # (perf) indexed single-row fetch — load_users() scanned/decrypted all users
    user = get_user_record(request.session["user"])
    user["username"] = request.session["user"]
    if not user_can_access_vm(user, cluster_id, vmid, "vm.clone", vm_type):
        # lgtm[py/reflected-xss]
        return jsonify({"error": "Permission denied: vm.clone"}), 403

    manager = cluster_managers[cluster_id]
    data = request.json or {}

    newid = data.get("newid")
    if not newid:
        # Get next available VMID
        next_result = manager.get_next_vmid()
        if next_result["success"]:
            newid = next_result["vmid"]
        else:
            # lgtm[py/reflected-xss]
            return jsonify({"error": "Could not get next VMID"}), 500

    result = manager.clone_vm(
        node=node,
        vmid=vmid,
        vm_type=vm_type,
        newid=int(newid),
        name=data.get("name"),
        full=data.get("full", True),
        target_node=data.get("target_node"),
        target_storage=data.get("target_storage"),
        description=data.get("description"),
    )

    if result["success"]:
        # #194: apply Cloud-Init config to cloned QEMU VM (before first boot)
        if vm_type == "qemu":
            ci_params = {}
            for ci_key in ("ciuser", "cipassword", "sshkeys", "ipconfig0", "ipconfig1", "nameserver", "searchdomain"):
                if data.get(ci_key):
                    ci_params[ci_key] = data[ci_key]
            if ci_params:
                try:
                    upid = result.get("data")
                    if upid:
                        manager._wait_for_task(node, upid, timeout=600)
                    clone_node = data.get("target_node") or node
                    ci_url = (
                        f"https://{manager.host}:{manager.api_port}/api2/json/nodes/{clone_node}/qemu/{newid}/config"
                    )
                    manager._api_post(ci_url, data=ci_params)
                    logging.info(f"[CLONE] Applied Cloud-Init config to VM {newid}: {list(ci_params.keys())}")
                except Exception as e:
                    logging.warning(f"[CLONE] Cloud-Init config failed for {newid}: {e}")

        # Audit log
        user = getattr(request, "session", {}).get("user", "system")
        log_audit(
            user,
            "vm.cloned",
            f"{vm_type.upper()} {vmid} cloned to {newid}" + (f" as '{data.get('name')}'" if data.get("name") else ""),
            cluster=manager.config.name,
        )

        # Register ProxmoxVEx user for this task
        upid = result.get("data")
        if upid:
            register_task_user(upid, user, cluster_id)

        # Push immediate update for live UI
        push_immediate_update(cluster_id, delay=0.5)

        # lgtm[py/reflected-xss]
        return jsonify({"message": f"Clone gestartet: {vmid} -> {newid}", "newid": newid, "data": result.get("data")})
    else:
        # lgtm[py/reflected-xss]
        return jsonify({
            "error": result["error"]
        }), 500  # snyk:ignore:Cross-site Scripting (XSS)  # snyk:ignore:Server Information Exposure
