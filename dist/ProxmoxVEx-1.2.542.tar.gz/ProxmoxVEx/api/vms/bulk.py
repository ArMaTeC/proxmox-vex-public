# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/api/vms/bulk.py
# Project:     ProxmoxVEx
# Version:     1.2.535
# Build:       2026.09.26
# Description: bulk routes for the vms API (split from api/vms.py).
# Usage:       import ProxmoxVEx.api.vms.bulk
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-26
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""bulk routes for the vms API (split from api/vms.py)."""

import gzip
import json
import logging
from datetime import datetime

from flask import jsonify, make_response

from ProxmoxVEx.api.helpers import check_cluster_access
from ProxmoxVEx.background.bulk_actions import VALID_BULK_ACTIONS, get_bulk_job, start_bulk_job
from ProxmoxVEx.globals import cluster_managers
from ProxmoxVEx.utils.auth import get_user_record, require_auth
from ProxmoxVEx.utils.rbac import user_can_access_vm
from ProxmoxVEx.utils.stepup import require_stepup

from .common import _access_denied, bp, request

# =====================================================
# Bulk VM/LXC action routes
# 003-ux-bulk-selection
# =====================================================


@bp.route("/api/clusters/<cluster_id>/vms/bulk", methods=["POST"])
@require_auth()
def bulk_vm_action_api(cluster_id):
    """Enqueue a bulk start/stop/restart action against a list of guests."""
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()

    if cluster_id not in cluster_managers:
        return jsonify({"error": "Cluster not found"}), 404

    data = request.get_json(silent=True) or {}
    action = str(data.get("action", "")).strip().lower()
    if action not in VALID_BULK_ACTIONS:
        return jsonify({"error": f"Invalid action. Valid actions: {VALID_BULK_ACTIONS}"}), 400

    # Spec 089 SC-002: destructive bulk actions need a step-up grant — one
    # challenge covers the whole batch (the job runs inside the window).
    if action in ("stop", "shutdown", "reboot", "reset", "suspend"):
        denied = require_stepup("guest.power")
        if denied is not None:
            return denied

    guests = data.get("guests", [])
    if not isinstance(guests, list) or not guests:
        return jsonify({"error": "guests must be a non-empty list"}), 400
    # spec 092/US016: bound the batch so one request can't flood the cluster
    # manager or the per-item result list
    if len(guests) > 500:
        return jsonify({"error": "guests must not exceed 500 items"}), 400

    # Validate list items and per-VM permissions
    # (perf) indexed single-row fetch — load_users() scanned/decrypted all users
    user = get_user_record(request.session["user"])
    user["username"] = request.session["user"]

    perm_map = {
        "start": "vm.start",
        "stop": "vm.stop",
        "shutdown": "vm.stop",
        "reboot": "vm.restart",
        "reset": "vm.restart",
        "suspend": "vm.stop",
        "resume": "vm.start",
    }
    required_perm = perm_map.get(action, "vm.start")

    # spec 092/US016 SC-032: a permission-denied guest is a failed ITEM, not a
    # batch abort — split the list and let the job report it per-item.
    allowed_guests, denied_guests = [], []
    for guest in guests:
        if not isinstance(guest, dict) or not guest.get("vmid") or not guest.get("node") or not guest.get("type"):
            return jsonify({"error": "Each guest must include vmid, node and type"}), 400

        vmid = guest["vmid"]
        vm_type = guest["type"]
        if not user_can_access_vm(user, cluster_id, vmid, required_perm, vm_type):
            logging.warning(f"[BULK-ACTION] Permission denied for {user['username']}: {required_perm} on VM {vmid}")
            denied_guests.append(guest)
            continue
        allowed_guests.append(guest)

    if not allowed_guests:
        return jsonify({"error": "Permission denied for all requested guests"}), 403

    raw_batch = data.get("batch_size")
    try:
        batch_size = int(raw_batch) if raw_batch is not None else None
    except (TypeError, ValueError):
        batch_size = None
    if batch_size is not None and (batch_size < 1 or batch_size > 200):
        return jsonify({"error": "batch_size must be between 1 and 200"}), 400
    params = {"force": data.get("force", False)}
    if batch_size is not None:
        params["batch_size"] = batch_size
    task = start_bulk_job(cluster_id, action, allowed_guests, params, request.session["user"], denied_guests=denied_guests)
    return jsonify({
        "job_id": task.id,
        "status": task.status,
        "total": task.total,
        # surfaced so the UI can report denied items immediately (SC-032)
        "denied": [g["vmid"] for g in denied_guests],
    }), 202


@bp.route("/api/clusters/<cluster_id>/vms/bulk/<job_id>", methods=["GET"])
@require_auth()
def get_bulk_vm_action_api(cluster_id, job_id):
    """Get status of an enqueued bulk action job."""
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()

    task = get_bulk_job(job_id)
    if not task:
        return jsonify({"error": "Job not found"}), 404

    return jsonify(task.to_dict())


@bp.route("/api/clusters/<cluster_id>/vms/bulk/<job_id>/cancel", methods=["POST"])
@require_auth()
def cancel_bulk_vm_action_api(cluster_id, job_id):
    """spec 092/US016 FR-046: cancel queued-but-not-started items of a bulk
    job. The in-flight batch runs to completion; the rest are recorded as
    cancelled and never dispatched. Cancel is non-destructive — no step-up.
    """
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()

    task = get_bulk_job(job_id)
    if not task or task.cluster_id != cluster_id:
        return jsonify({"error": "Job not found"}), 404
    if task.status in ("completed", "failed", "completed_with_errors", "cancelled"):
        return jsonify({"error": "Job already finished", "status": task.status}), 409

    task.request_cancel()
    logging.info(f"[BULK-ACTION] Job {job_id} cancel requested by {request.session.get('user')}")
    return jsonify({"job_id": job_id, "status": "cancelling"}), 202


BULK_OPS_CACHE_TTL = 30.0


# 858-memory-optimisation-for-bulk-operations: cap the in-memory bulk status cache
# to prevent completed bulk jobs from accumulating in the API worker over time.
BULK_OPS_CACHE_MAX_SIZE = 100


_bulk_ops_cache = {}


def _prune_bulk_cache_if_needed():
    """Drop the oldest half of the cache when it exceeds the configured limit."""
    if len(_bulk_ops_cache) <= BULK_OPS_CACHE_MAX_SIZE:
        return
    oldest = sorted(_bulk_ops_cache.items(), key=lambda kv: kv[1]["time"])
    for key, _ in oldest[: len(oldest) // 2]:
        del _bulk_ops_cache[key]


def _get_cached_bulk_status(cluster_id, job_id):
    """Return the cached bulk job status if it has not expired."""
    import time as _t

    cached = _bulk_ops_cache.get(f"{cluster_id}:{job_id}")
    if cached is not None and (_t.monotonic() - cached["time"]) < BULK_OPS_CACHE_TTL:
        return cached["status"]
    return None


def _set_cached_bulk_status(cluster_id, job_id, status):
    """Cache the bulk job status for fast lookups."""
    import time as _t

    _prune_bulk_cache_if_needed()
    _bulk_ops_cache[f"{cluster_id}:{job_id}"] = {"status": status, "time": _t.monotonic()}


@bp.route("/api/clusters/<cluster_id>/vms/bulk-cache/<job_id>", methods=["GET"])
@require_auth()
def get_bulk_vm_action_cached(cluster_id, job_id):
    """Return cached bulk job status if available, otherwise refresh from the task queue."""
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()
    cached = _get_cached_bulk_status(cluster_id, job_id)
    if cached is not None:
        return jsonify({"ok": True, "data": {"cached": True, "status": cached}})
    task = get_bulk_job(job_id)
    if not task:
        return jsonify({"error": "Job not found"}), 404
    status = task.to_dict()
    _set_cached_bulk_status(cluster_id, job_id, status)
    return jsonify({"ok": True, "data": {"cached": False, "status": status}})


def _load_bulk_job_lazy(job_id, page=1, per_page=20):
    """Lazily load a paginated summary of a bulk job without full guest details."""
    task = get_bulk_job(job_id)
    if not task:
        return None
    summary = task.to_dict()
    guests = summary.get("guests", [])
    total = len(guests)
    per_page = max(1, min(int(per_page), 100))
    page = max(1, int(page))
    start = (page - 1) * per_page
    end = start + per_page
    summary["guests"] = guests[start:end]
    summary["pagination"] = {
        "page": page,
        "per_page": per_page,
        "total": total,
        "pages": max(1, (total + per_page - 1) // per_page),
    }
    summary["is_partial"] = True
    return summary


@bp.route("/api/clusters/<cluster_id>/vms/bulk-lazy/<job_id>", methods=["GET"])
@require_auth()
def get_bulk_vm_action_lazy(cluster_id, job_id):
    """Return a lazily loaded, paginated summary of a bulk job."""
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()
    page = request.args.get("page", 1, type=int)
    per_page = request.args.get("per_page", 20, type=int)
    summary = _load_bulk_job_lazy(job_id, page=page, per_page=per_page)
    if summary is None:
        return jsonify({"error": "Job not found"}), 404
    return jsonify({"ok": True, "data": summary})


@bp.route("/api/clusters/<cluster_id>/vms/bulk-index/<job_id>", methods=["GET"])
@require_auth()
def get_bulk_vm_action_index(cluster_id, job_id):
    """Return bulk job results indexed by vmid for fast lookups."""
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()
    # 854-indexing-for-bulk-operations: build an O(1) lookup table of per-guest results.
    task = get_bulk_job(job_id)
    if not task:
        return jsonify({"error": "Job not found"}), 404
    indexed = {str(r.get("vmid")): r for r in task.results if r.get("vmid") is not None}
    return jsonify({"ok": True, "data": {"total": len(indexed), "index": indexed}})


@bp.route("/api/clusters/<cluster_id>/vms/bulk-compressed/<job_id>", methods=["GET"])
@require_auth()
def get_bulk_vm_action_compressed(cluster_id, job_id):
    """Return a gzip-compressed bulk job status payload."""
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()
    # 855-compression-for-bulk-operations: reduce payload size for large bulk results.
    task = get_bulk_job(job_id)
    if not task:
        return jsonify({"error": "Job not found"}), 404
    payload = json.dumps({"ok": True, "data": task.to_dict()}, default=str).encode("utf-8")
    compressed = gzip.compress(payload)
    resp = make_response(compressed)
    resp.headers["Content-Type"] = "application/json"
    resp.headers["Content-Encoding"] = "gzip"
    resp.headers["Content-Length"] = str(len(compressed))
    return resp


@bp.route("/api/clusters/<cluster_id>/vms/bulk-updates/<job_id>", methods=["GET"])
@require_auth()
def get_bulk_vm_action_updates(cluster_id, job_id):
    """Return bulk job results that have a timestamp newer than the provided `since` value."""
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()
    # 859-incremental-updates-for-bulk-operations: only return new results
    # to reduce bandwidth and client-side memory churn on long-running jobs.
    task = get_bulk_job(job_id)
    if not task:
        return jsonify({"error": "Job not found"}), 404

    since = request.args.get("since", "")
    if not since:
        return jsonify({"error": "since timestamp query parameter is required"}), 400

    try:
        since_dt = datetime.fromisoformat(since)
    except ValueError:
        return jsonify({"error": "since must be a valid ISO-8601 timestamp"}), 400

    updated = [r for r in task.results if datetime.fromisoformat(r["timestamp"]) > since_dt]
    return jsonify({"ok": True, "data": {"since": since, "total": len(updated), "results": updated}})
