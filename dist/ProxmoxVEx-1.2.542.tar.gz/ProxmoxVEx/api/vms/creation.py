# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/api/vms/creation.py
# Project:     ProxmoxVEx
# Version:     1.2.535
# Build:       2026.09.26
# Description: creation routes for the vms API (split from
#              api/vms.py).
# Usage:       import ProxmoxVEx.api.vms.creation
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-26
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""creation routes for the vms API (split from api/vms.py)."""

import contextlib
import gzip
import hashlib
import logging
import os
import shutil
import tempfile
import time

from flask import jsonify

from ProxmoxVEx.api.helpers import check_cluster_access, get_connected_manager
from ProxmoxVEx.globals import cluster_managers
from ProxmoxVEx.utils.audit import log_audit
from ProxmoxVEx.utils.auth import get_user_record, require_auth
from ProxmoxVEx.utils.qemu_guest_agent import detect_os_from_pve_config, get_iso_path, safe_iso_filename
from ProxmoxVEx.utils.realtime import broadcast_action, push_immediate_update
from ProxmoxVEx.utils.sanitization import validate_storage_name

from .common import (
    _access_denied,
    _require_vm_access,
    bp,
    request,
)


@bp.route("/api/hardware-options", methods=["GET"])
@require_auth(perms=["node.view"])
def get_hardware_options():
    """Get available hardware options (CPU types, SCSI controllers, etc.)

    Extended Dec 2025 with machine types
    """
    # Use any manager to get options
    if cluster_managers:
        manager = list(cluster_managers.values())[0]
        # lgtm[py/reflected-xss]
        return jsonify({
            "cpu_types": manager.get_cpu_types(),
            "scsi_controllers": manager.get_scsi_controllers(),
            "network_models": manager.get_network_models(),
            "disk_bus_types": manager.get_disk_bus_types(),
            "cache_modes": manager.get_cache_modes(),
            "machine_types": manager.get_machine_types(),
        })
    else:
        # Return defaults if no cluster configured
        # lgtm[py/reflected-xss]
        return jsonify({
            "cpu_types": ["host", "kvm64", "qemu64", "x86-64-v2-AES"],
            "scsi_controllers": [{"value": "virtio-scsi-pci", "label": "VirtIO SCSI"}],
            "network_models": [{"value": "virtio", "label": "VirtIO"}],
            "disk_bus_types": [{"value": "scsi", "label": "SCSI", "max": 30}],
            "cache_modes": [{"value": "", "label": "Default"}],
            "machine_types": [
                {"value": "", "label": "Default"},
                {"value": "q35", "label": "q35 (Latest)"},
                {"value": "pc-q35-11.0+pve1", "label": "q35 11.0+pve1"},
                {"value": "pc-q35-10.1", "label": "q35 10.1"},
                {"value": "pc-q35-9.2+pve1", "label": "q35 9.2+pve1"},
                {"value": "pc-q35-8.2", "label": "q35 8.2"},
                {"value": "i440fx", "label": "i440fx (Latest)"},
                {"value": "pc-i440fx-11.0+pve1", "label": "i440fx 11.0+pve1"},
                {"value": "pc-i440fx-10.1", "label": "i440fx 10.1"},
                {"value": "pc-i440fx-9.2+pve1", "label": "i440fx 9.2+pve1"},
                {"value": "pc-i440fx-8.2", "label": "i440fx 8.2"},
            ],
        })


# VM/CT Creation API Routes
@bp.route("/api/clusters/<cluster_id>/nodes/<node>/nextid", methods=["GET"])
@require_auth(perms=["vm.view"])
def get_next_vmid_for_node_api(cluster_id, node):
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()

    if cluster_id not in cluster_managers:
        # lgtm[py/reflected-xss]
        return jsonify({"error": "Cluster not found"}), 404

    manager = cluster_managers[cluster_id]
    result = manager.get_next_vmid()

    if result.get("success"):
        # lgtm[py/reflected-xss]
        return jsonify({"vmid": result["vmid"]})
    else:
        # lgtm[py/reflected-xss]
        return jsonify(result), 400


@bp.route("/api/clusters/<cluster_id>/nodes/<node>/templates", methods=["GET"])
@require_auth(perms=["storage.view"])
def get_templates_api(cluster_id, node):
    """Get available templates for VM/CT creation"""
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()
    if cluster_id not in cluster_managers:
        # lgtm[py/reflected-xss]
        return jsonify({"error": "Cluster not found"}), 404

    manager = cluster_managers[cluster_id]

    templates = manager.get_templates(node)
    # lgtm[py/reflected-xss]
    return jsonify(templates)


@bp.route("/api/clusters/<cluster_id>/nodes/<node>/qemu", methods=["POST"])
@require_auth(perms=["vm.create"])
def create_vm_api(cluster_id, node):
    """Create a new VM on a node"""
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()

    if cluster_id not in cluster_managers:
        # lgtm[py/reflected-xss]
        return jsonify({"error": "Cluster not found"}), 404

    manager = cluster_managers[cluster_id]

    vm_config = request.json or {}

    # #502 - tenant quota pre-flight (fail-open: a quota bug must never block a create)
    try:
        from ProxmoxVEx.utils.rbac import DEFAULT_TENANT_ID, check_tenant_quota

        _qu = get_user_record(request.session.get("user", ""))
        _tid = _qu.get("tenant_id") or DEFAULT_TENANT_ID
        _qcores = int(vm_config.get("cores") or 1) * int(vm_config.get("sockets") or 1)
        _qmem = float(vm_config.get("memory") or 0) / 1024.0  # MB → GB
        _qchk = check_tenant_quota(_tid, add_cores=_qcores, add_mem_gb=_qmem, add_vms=1)
        if not _qchk["ok"] and _qchk.get("enforce") == "block":
            # lgtm[py/reflected-xss]
            return jsonify({
                "error": f"Tenant quota exceeded ({', '.join(_qchk['violations'])}) — "
                f"usage {_qchk['usage']} vs quota {_qchk['quota']}",
                "quota": _qchk,
            }), 403
    except Exception as _qe:
        logging.debug(f"[quota] qemu pre-flight skipped: {_qe}")

    result = manager.create_vm(node, vm_config)

    if result.get("success"):
        # Audit log
        user = getattr(request, "session", {}).get("user", "unknown")
        vmid = vm_config.get("vmid") or result.get("vmid") or result.get("data", {}).get("vmid", "unknown")
        vm_name = vm_config.get("name", f"vm-{vmid}")
        log_audit(user, "vm.create", f"Created VM {vmid} ({vm_name}) on {node}", cluster=manager.config.name)

        # Broadcast to all clients
        broadcast_action("create", "qemu", str(vmid), {"node": node, "name": vm_name}, cluster_id, user)

        # Push immediate update for live UI
        push_immediate_update(cluster_id, delay=0.5)

        # lgtm[py/reflected-xss]
        return jsonify(result)
    else:
        # lgtm[py/reflected-xss]
        return jsonify(result), 400


@bp.route("/api/clusters/<cluster_id>/nodes/<node>/lxc", methods=["POST"])
@require_auth(perms=["vm.create"])
def create_container_api(cluster_id, node):
    """Create a new container on a node"""
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()

    if cluster_id not in cluster_managers:
        # lgtm[py/reflected-xss]
        return jsonify({"error": "Cluster not found"}), 404

    manager = cluster_managers[cluster_id]
    ct_config = request.json or {}

    # #502 - tenant quota pre-flight (fail-open)
    try:
        from ProxmoxVEx.utils.rbac import DEFAULT_TENANT_ID, check_tenant_quota

        _qu = get_user_record(request.session.get("user", ""))
        _tid = _qu.get("tenant_id") or DEFAULT_TENANT_ID
        _qcores = int(ct_config.get("cores") or 1)
        _qmem = float(ct_config.get("memory") or 0) / 1024.0  # MB → GB
        _qchk = check_tenant_quota(_tid, add_cores=_qcores, add_mem_gb=_qmem, add_vms=1)
        if not _qchk["ok"] and _qchk.get("enforce") == "block":
            # lgtm[py/reflected-xss]
            return jsonify({
                "error": f"Tenant quota exceeded ({', '.join(_qchk['violations'])}) — "
                f"usage {_qchk['usage']} vs quota {_qchk['quota']}",
                "quota": _qchk,
            }), 403
    except Exception as _qe:
        logging.debug(f"[quota] lxc pre-flight skipped: {_qe}")

    result = manager.create_container(node, ct_config)

    if result.get("success"):
        # Audit log
        user = getattr(request, "session", {}).get("user", "unknown")
        vmid = ct_config.get("vmid") or result.get("data", {}).get("vmid", "unknown")
        ct_name = ct_config.get("hostname", f"ct-{vmid}")
        log_audit(user, "container.create", f"Created CT {vmid} ({ct_name}) on {node}", cluster=manager.config.name)

        # Broadcast to all clients
        broadcast_action("create", "lxc", str(vmid), {"node": node, "name": ct_name}, cluster_id, user)

        # Push immediate update for live UI
        push_immediate_update(cluster_id, delay=0.5)

        # lgtm[py/reflected-xss]
        return jsonify(result)
    else:
        # lgtm[py/reflected-xss]
        return jsonify(result), 400


# ---------------------------------------------------------------------------
# QEMU Guest Agent automated install endpoints
# ---------------------------------------------------------------------------


@bp.route("/api/clusters/<cluster_id>/vms/<node>/<vm_type>/<int:vmid>/guest-agent-install/prepare", methods=["POST"])
@require_auth(perms=["vm.view"])
def guest_agent_install_prepare_api(cluster_id, node, vm_type, vmid):
    """Detect the guest OS and return the matching ISO/script metadata."""
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()

    denied = _require_vm_access(cluster_id, vmid, "vm.view", vm_type)
    if denied:
        return denied

    manager, err = get_connected_manager(cluster_id)
    if not manager:
        return err

    if vm_type != "qemu":
        # lgtm[py/reflected-xss]
        return jsonify({"error": "Guest agent install is only supported for QEMU VMs"}), 400

    try:
        cfg_result = manager.get_vm_config(node, vmid, vm_type)
        if not cfg_result.get("success"):
            logging.warning(f"Failed to read VM config for {vm_type}/{vmid}: {cfg_result.get('error')}")
            # lgtm[py/reflected-xss]
            return jsonify({"error": cfg_result.get("error", "Could not read VM config")}), 500

        raw = cfg_result.get("config", {}).get("raw", {})
        ostype = raw.get("ostype")
        info = detect_os_from_pve_config(ostype)
        info["vmid"] = vmid
        info["node"] = node
        info["vm_type"] = vm_type

        # Include ISO-capable storages so the frontend can render a dropdown
        # with free/total sizes instead of a raw text input.
        try:
            all_storages = manager.get_storage_list(node)
            iso_storages = []
            for s in all_storages:
                content = s.get("content", "")
                # PVE content field is comma-separated, e.g. "iso,vztmpl,backup"
                if "iso" in content.split(","):
                    iso_storages.append({
                        "storage": s.get("storage"),
                        "type": s.get("type", "unknown"),
                        "total": s.get("total", 0),
                        "used": s.get("used", 0),
                        "avail": s.get("avail", 0),
                        "enabled": s.get("enabled", 1),
                        "active": s.get("active", 1),
                    })
            info["storages"] = iso_storages
        except Exception as e_stor:
            logging.warning(f"Could not fetch storages for node {node}: {e_stor}")
            info["storages"] = []

        # lgtm[py/reflected-xss]
        return jsonify(info)
    except Exception as e:
        logging.error(f"Error preparing guest-agent install for {vm_type}/{vmid}: {e}")
        # lgtm[py/reflected-xss]
        return jsonify({"error": f"Internal error: {e}"}), 500


@bp.route("/api/clusters/<cluster_id>/vms/<node>/<vm_type>/<int:vmid>/guest-agent-install/mount", methods=["POST"])
@require_auth(perms=["vm.config"])
def guest_agent_install_mount_api(cluster_id, node, vm_type, vmid):
    """Upload the reduced ISO to a PVE datastore and attach it to the VM CD-ROM."""
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()

    denied = _require_vm_access(cluster_id, vmid, "vm.config", vm_type)
    if denied:
        return denied

    if cluster_id not in cluster_managers:
        # lgtm[py/reflected-xss]
        return jsonify({"error": "Cluster not found"}), 404

    manager = cluster_managers[cluster_id]
    if not manager.is_connected:
        conn_err = manager.connection_error or "Cluster not connected"
        # lgtm[py/reflected-xss]
        return jsonify({"error": conn_err, "offline": True}), 503

    if vm_type != "qemu":
        # lgtm[py/reflected-xss]
        return jsonify({"error": "Guest agent install is only supported for QEMU VMs"}), 400

    storage = request.args.get("storage", "local")
    if not validate_storage_name(storage):
        # lgtm[py/reflected-xss]
        return jsonify({"error": f"Invalid storage name: {storage}"}), 400

    replace = request.args.get("replace", "").lower() in ("1", "true", "yes")
    create_cdrom = request.args.get("create_cdrom", "").lower() in ("1", "true", "yes")
    reboot = request.args.get("reboot", "").lower() in ("1", "true", "yes")
    power_cycle = request.args.get("power_cycle", "").lower() in ("1", "true", "yes")
    tmp_iso = None

    try:
        cfg_result = manager.get_vm_config(node, vmid, vm_type)
        if not cfg_result.get("success"):
            logging.warning(f"Failed to read VM config for {vm_type}/{vmid}: {cfg_result.get('error')}")
            # lgtm[py/reflected-xss]
            return jsonify({"error": cfg_result.get("error", "Could not read VM config")}), 500

        raw = cfg_result.get("config", {}).get("raw", {})
        ostype = raw.get("ostype")
        info = detect_os_from_pve_config(ostype)
        if not info.get("supported"):
            # lgtm[py/reflected-xss]
            return jsonify({"error": info.get("message", "Unsupported guest OS"), "os_info": info}), 400

        iso_path = get_iso_path(info["iso_variant"])
        if not iso_path.exists():
            logging.error(f"Reduced ISO missing for variant {info['iso_variant']}: {iso_path}")
            # lgtm[py/reflected-xss]
            return jsonify({"error": f"Reduced ISO not found for {info['iso_variant']}"}), 500

        cdrom_key = "ide2"
        current_cdrom = raw.get(cdrom_key)
        is_cdrom = isinstance(current_cdrom, str) and ("media=cdrom" in current_cdrom or current_cdrom == "none")

        # If the VM has no ide2 CD-ROM device, the PVE config API will refuse an
        # ISO mount. Offer to create the device first when create_cdrom is not set.
        if not current_cdrom and not create_cdrom:
            # lgtm[py/reflected-xss]
            return jsonify({
                "error": f"{cdrom_key} CD-ROM device is not configured on this VM.",
                "device": cdrom_key,
                "needs_cdrom": True,
            }), 409

        # If the ide2 slot exists but is not a CD-ROM (could be a disk), need explicit
        # replace permission to overwrite it.
        if current_cdrom and not is_cdrom and not replace:
            # lgtm[py/reflected-xss]
            return jsonify({
                "error": f"{cdrom_key} is already occupied by {current_cdrom}.",
                "device": cdrom_key,
                "needs_replace": True,
            }), 409

        # When create_cdrom is requested (or the slot is missing), ensure ide2 is
        # an empty CD-ROM before mounting the ISO.
        if not current_cdrom or (current_cdrom and not is_cdrom):
            create_value = "none,media=cdrom"
            create_result = manager.update_vm_config(
                node,
                vmid,
                vm_type,
                {cdrom_key: create_value},
            )
            if not create_result.get("success"):
                # lgtm[py/reflected-xss]
                return jsonify({
                    "error": create_result.get("error", f"Failed to create {cdrom_key} CD-ROM device"),
                    "device": cdrom_key,
                    "needs_cdrom": True,
                }), 500

        # Build a stable, safe filename that includes a short content hash.
        iso_hash = hashlib.sha256(str(iso_path).encode("utf-8")).hexdigest()[:8]
        filename = safe_iso_filename(f"proxmoxvex-virtio-{info['iso_variant']}-{iso_hash}.iso")
        if not filename:
            # lgtm[py/reflected-xss]
            return jsonify({"error": "Generated ISO filename was rejected as unsafe"}), 500

        # Decompress the built .iso.gz to a temporary .iso for upload.
        # Reuse the same temp directory the datastore upload endpoint uses.
        upload_tmp_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))), "tmp")  # one extra level: module lives in api/vms/
        os.makedirs(upload_tmp_dir, mode=0o700, exist_ok=True)
        fd, tmp_iso = tempfile.mkstemp(dir=upload_tmp_dir, suffix=".iso")
        # os.fdopen takes ownership of `fd`; exiting the `with` block closes it.
        # Do NOT call os.close(fd) again afterwards.
        try:
            with os.fdopen(fd, "wb") as out_fh, gzip.open(iso_path, "rb") as in_fh:
                shutil.copyfileobj(in_fh, out_fh)
        except Exception:
            # If os.fdopen itself failed (unlikely), fd may still be open.
            with contextlib.suppress(OSError):
                os.close(fd)
            raise

        # Upload the .iso to the selected PVE storage on the target node.
        host, port = manager.host, manager.api_port
        upload_url = f"https://{host}:{port}/api2/json/nodes/{node}/storage/{storage}/upload"
        with open(tmp_iso, "rb") as fh:
            from requests_toolbelt.multipart.encoder import MultipartEncoder

            encoder = MultipartEncoder(
                fields=[
                    ("content", "iso"),
                    ("filename", (filename, fh, "application/octet-stream")),
                ]
            )
            response = manager._api_post(
                upload_url,
                data=encoder,
                headers={"Content-Type": encoder.content_type},
                timeout=3600,
            )

        if response.status_code != 200:
            logging.error(f"ISO upload to {storage} failed for {vmid}: {response.text}")
            # lgtm[py/reflected-xss]
            return jsonify({"error": f"Failed to upload ISO to storage '{storage}': {response.text}"}), 500

        # Attach the uploaded ISO to the VM CD-ROM and ensure the QEMU guest agent
        # is enabled in the PVE VM config. Without this, PVE returns "No QEMU guest
        # agent configured" even if the guest has the agent installed and running.
        # PVE requires the explicit `media=cdrom` option on ISO images.
        agent_val = raw.get("agent", "")
        agent_enabled = isinstance(agent_val, str) and (agent_val == "1" or "enabled=1" in agent_val)
        config_updates = {cdrom_key: f"{storage}:iso/{filename},media=cdrom"}
        if not agent_enabled:
            config_updates["agent"] = "enabled=1"
            logging.info(f"Enabling QEMU guest agent for {vm_type}/{vmid}: agent was {agent_val!r}")
        update_result = manager.update_vm_config(node, vmid, vm_type, config_updates)
        if not update_result.get("success"):
            # lgtm[py/reflected-xss]
            return jsonify({"error": update_result.get("error", "Failed to attach ISO to VM")}), 500

        # Optionally reboot or full power-cycle the VM so the newly added CD-ROM is
        # detected by the guest. PVE config changes with pending restart require a
        # full stop+start to apply; a `reboot` leaves the config pending.
        reboot_result = None
        if power_cycle:
            stop_result = manager.stop_vm(node, vmid, vm_type)
            if stop_result and stop_result.get("success"):
                # Give PVE a moment to release the VM lock before starting again.
                time.sleep(2)
                start_result = manager.start_vm(node, vmid, vm_type)
                reboot_result = {
                    "success": start_result and start_result.get("success"),
                    "stop": stop_result,
                    "start": start_result,
                }
                if not start_result.get("success"):
                    logging.warning(f"Start after power-cycle for {vm_type}/{vmid} failed: {start_result.get('error')}")
            else:
                reboot_result = {"success": False, "error": stop_result.get("error", "Stop failed before power-cycle")}
                logging.warning(f"Stop for power-cycle of {vm_type}/{vmid} failed: {reboot_result.get('error')}")
        elif reboot:
            reboot_result = manager.restart_vm(node, vmid, vm_type)
            if not reboot_result.get("success"):
                logging.warning(f"Reboot after ISO mount for {vm_type}/{vmid} failed: {reboot_result.get('error')}")

        # Audit the action.
        user = request.session.get("user", "unknown")
        log_audit(
            user,
            "vm.config_changed",
            f"Mounted guest-agent install ISO for {vm_type} {vmid}: {filename}",
            cluster=manager.config.name,
        )

        # lgtm[py/reflected-xss]
        response = {
            "success": True,
            "device": cdrom_key,
            "filename": filename,
            "storage": storage,
            "script_name": info["script_name"],
            "os_pretty_name": info["os_pretty_name"],
        }
        if power_cycle:
            if reboot_result and reboot_result.get("success"):
                response["power_cycled"] = True
                response["message"] = (
                    "ISO mounted and VM power-cycled. The CD drive will be visible after the guest starts."
                )
            else:
                response["power_cycled"] = False
                response["reboot_error"] = reboot_result.get("error") if reboot_result else "Power-cycle attempt failed"
                response["message"] = (
                    "ISO mounted, but the power-cycle failed. Stop and start the VM manually and run the install script from the CD drive."
                )
        elif reboot:
            if reboot_result and reboot_result.get("success"):
                response["rebooted"] = True
                response["message"] = (
                    "ISO mounted and VM rebooted. The CD drive will be visible after the guest starts."
                )
            else:
                response["rebooted"] = False
                response["reboot_error"] = reboot_result.get("error") if reboot_result else "Reboot attempt failed"
                response["message"] = (
                    "ISO mounted, but the VM reboot failed. Reboot manually and run the install script from the CD drive."
                )
        else:
            response["message"] = (
                "ISO uploaded and mounted. Open the VM console, browse the CD drive, and run the install script."
            )
        # lgtm[py/reflected-xss]
        return jsonify(response)
    except Exception as e:
        logging.error(f"Error mounting guest-agent ISO for {vm_type}/{vmid}: {e}")
        # lgtm[py/reflected-xss]
        return jsonify({"error": f"Internal error: {e}"}), 500
    finally:
        if tmp_iso:
            with contextlib.suppress(Exception):
                os.unlink(tmp_iso)
