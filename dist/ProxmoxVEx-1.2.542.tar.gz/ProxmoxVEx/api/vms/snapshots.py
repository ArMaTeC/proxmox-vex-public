# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/api/vms/snapshots.py
# Project:     ProxmoxVEx
# Version:     1.2.535
# Build:       2026.09.26
# Description: snapshots routes for the vms API (split from
#              api/vms.py).
# Usage:       import ProxmoxVEx.api.vms.snapshots
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-26
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""snapshots routes for the vms API (split from api/vms.py)."""

import contextlib
import logging
import time
from datetime import UTC, datetime

from flask import jsonify

from ProxmoxVEx.api.helpers import check_cluster_access
from ProxmoxVEx.globals import cluster_managers
from ProxmoxVEx.models.permissions import ROLE_ADMIN
from ProxmoxVEx.utils.audit import log_audit
from ProxmoxVEx.utils.auth import get_user_record, require_auth
from ProxmoxVEx.utils.rbac import user_can_access_vm
from ProxmoxVEx.utils.stepup import require_stepup

from .common import (
    _access_denied,
    _api_error,
    _require_vm_access,
    bp,
    request,
)

# ==================== SNAPSHOT API ROUTES ====================


@bp.route("/api/clusters/<cluster_id>/vms/<node>/<vm_type>/<int:vmid>/snapshot-capability", methods=["GET"])
@require_auth(perms=["vm.view"])
def check_snapshot_capability_api(cluster_id, node, vm_type, vmid):
    """Check if VM/CT can create snapshots and why not"""
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()
    denied = _require_vm_access(cluster_id, vmid, "vm.view", vm_type)
    if denied:
        # lgtm[py/reflected-xss]
        return denied
    if cluster_id not in cluster_managers:
        # lgtm[py/reflected-xss]
        return jsonify({"error": "Cluster not found"}), 404

    manager = cluster_managers[cluster_id]
    result = manager.check_snapshot_capability(node, vmid, vm_type)
    # lgtm[py/reflected-xss]
    return jsonify(result)


@bp.route("/api/clusters/<cluster_id>/vms/<node>/<vm_type>/<int:vmid>/snapshots", methods=["GET"])
@require_auth(perms=["vm.view"])
def get_snapshots_api(cluster_id, node, vm_type, vmid):
    """Get list of snapshots for a VM/CT"""
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()
    if cluster_id not in cluster_managers:
        # lgtm[py/reflected-xss]
        return jsonify({"error": "Cluster not found"}), 404
    denied = _require_vm_access(cluster_id, vmid, "vm.view", vm_type)
    if denied:
        # lgtm[py/reflected-xss]
        return denied

    manager = cluster_managers[cluster_id]
    snapshots = manager.get_snapshots(node, vmid, vm_type)
    # lgtm[py/reflected-xss]
    return jsonify(snapshots)


@bp.route("/api/clusters/<cluster_id>/vms/<node>/<vm_type>/<int:vmid>/snapshots", methods=["POST"])
@require_auth(perms=["vm.snapshot"])
def create_snapshot_api(cluster_id, node, vm_type, vmid):
    # tenant check
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()

    if cluster_id not in cluster_managers:
        # lgtm[py/reflected-xss]
        return jsonify({"error": "Cluster not found"}), 404

    # Check pool permission for vm.snapshot
    # (perf) indexed single-row fetch — load_users() scanned/decrypted all users
    user = get_user_record(request.session["user"])
    user["username"] = request.session["user"]
    if not user_can_access_vm(user, cluster_id, vmid, "vm.snapshot", vm_type):
        # lgtm[py/reflected-xss]
        return jsonify({"error": "Permission denied: vm.snapshot"}), 403

    mgr = cluster_managers[cluster_id]
    data = request.json or {}

    snapname = data.get("snapname", f"snap_{int(time.time())}")
    description = data.get("description", "")
    vmstate = data.get("vmstate", False)

    result = mgr.create_snapshot(node, vmid, vm_type, snapname, description, vmstate)

    if result["success"]:
        usr = getattr(request, "session", {}).get("user", "system")
        log_audit(
            usr,
            "snapshot.created",
            f"{vm_type.upper()} {vmid} - snapshot '{snapname}' created" + (" (with RAM)" if vmstate else ""),
            cluster=mgr.config.name,
        )
        # lgtm[py/reflected-xss]
        return jsonify({"message": f"Snapshot {snapname} erstellt", "task": result.get("task")})
    else:
        # lgtm[py/reflected-xss]
        return jsonify({
            "error": result["error"]
        }), 500  # snyk:ignore:Cross-site Scripting (XSS)  # snyk:ignore:Server Information Exposure


@bp.route("/api/clusters/<cluster_id>/vms/<node>/<vm_type>/<int:vmid>/snapshots/<snapname>", methods=["DELETE"])
@require_auth(perms=["vm.snapshot"])
def delete_snapshot_api(cluster_id, node, vm_type, vmid, snapname):
    denied = require_stepup("snapshot")
    if denied is not None:
        return denied
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()

    if cluster_id not in cluster_managers:
        # lgtm[py/reflected-xss]
        return jsonify({"error": "Cluster not found"}), 404

    # Check pool permission for vm.snapshot
    # (perf) indexed single-row fetch — load_users() scanned/decrypted all users
    user = get_user_record(request.session["user"])
    user["username"] = request.session["user"]
    if not user_can_access_vm(user, cluster_id, vmid, "vm.snapshot", vm_type):
        # lgtm[py/reflected-xss]
        return jsonify({"error": "Permission denied: vm.snapshot"}), 403

    mgr = cluster_managers[cluster_id]
    result = mgr.delete_snapshot(node, vmid, vm_type, snapname)

    if result["success"]:
        usr = getattr(request, "session", {}).get("user", "system")
        log_audit(
            usr,
            "snapshot.deleted",
            f"{vm_type.upper()} {vmid} - snapshot '{snapname}' deleted",
            cluster=mgr.config.name,
        )
        # lgtm[py/reflected-xss]
        return jsonify({"message": "Snapshot deleted", "task": result.get("task")})
    else:
        # lgtm[py/reflected-xss]
        return jsonify({
            "error": result["error"]
        }), 500  # snyk:ignore:Cross-site Scripting (XSS)  # snyk:ignore:Server Information Exposure


@bp.route("/api/clusters/<cluster_id>/vms/<node>/<vm_type>/<int:vmid>/snapshots/<snapname>/rollback", methods=["POST"])
@require_auth(perms=["vm.snapshot"])
def rollback_snapshot_api(cluster_id, node, vm_type, vmid, snapname):
    denied = require_stepup("snapshot")
    if denied is not None:
        return denied
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()

    if cluster_id not in cluster_managers:
        # lgtm[py/reflected-xss]
        return jsonify({"error": "Cluster not found"}), 404

    # Check pool permission for vm.snapshot
    # (perf) indexed single-row fetch — load_users() scanned/decrypted all users
    user = get_user_record(request.session["user"])
    user["username"] = request.session["user"]
    if not user_can_access_vm(user, cluster_id, vmid, "vm.snapshot", vm_type):
        # lgtm[py/reflected-xss]
        return jsonify({"error": "Permission denied: vm.snapshot"}), 403

    mgr = cluster_managers[cluster_id]
    result = mgr.rollback_snapshot(node, vmid, vm_type, snapname)

    if result["success"]:
        # Audit log
        user = getattr(request, "session", {}).get("user", "system")
        log_audit(
            user,
            "snapshot.restored",
            f"{vm_type.upper()} {vmid} - rolled back to snapshot '{snapname}'",
            cluster=mgr.config.name,
        )
        # lgtm[py/reflected-xss]
        return jsonify({"message": f"Rollback zu {snapname} gestartet", "task": result.get("task")})
    else:
        # lgtm[py/reflected-xss]
        return jsonify({
            "error": result["error"]
        }), 500  # snyk:ignore:Cross-site Scripting (XSS)  # snyk:ignore:Server Information Exposure


# Snapshot config + diff endpoints. Backs the Snapshot Comparison
# UI: pick two snapshots of the same VM, see config-level diff.
@bp.route("/api/clusters/<cluster_id>/vms/<node>/<vm_type>/<int:vmid>/snapshots/<snapname>/config", methods=["GET"])
@require_auth(perms=["vm.view"])
def get_snapshot_config_api(cluster_id, node, vm_type, vmid, snapname):
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()
    if cluster_id not in cluster_managers:
        # lgtm[py/reflected-xss]
        return jsonify({"error": "Cluster not found"}), 404
    denied = _require_vm_access(cluster_id, vmid, "vm.view", vm_type)
    if denied:
        # lgtm[py/reflected-xss]
        return denied
    mgr = cluster_managers[cluster_id]
    if not mgr.is_connected:
        # lgtm[py/reflected-xss]
        return jsonify({"error": "Cluster offline"}), 503
    if vm_type not in ("qemu", "lxc"):
        # lgtm[py/reflected-xss]
        return jsonify({"error": "Invalid vm_type"}), 400
    try:
        url = f"https://{mgr.host}:{mgr.api_port}/api2/json/nodes/{node}/{vm_type}/{vmid}/snapshot/{snapname}/config"
        r = mgr._api_get(url)
        if r is None or r.status_code != 200:
            # lgtm[py/reflected-xss]
            # snyk:ignore:Cross-site Scripting (XSS)
            return jsonify({
                "error": f"Failed to fetch snapshot config (status {getattr(r, 'status_code', '?')})"
            }), 502  # snyk:ignore:Cross-site Scripting (XSS)
        # lgtm[py/reflected-xss]
        return jsonify(r.json().get("data", {}) or {})
    except Exception:
        return _api_error("Failed to get snapshot config", status=500)


@bp.route("/api/clusters/<cluster_id>/vms/<node>/<vm_type>/<int:vmid>/snapshots/diff", methods=["GET"])
@require_auth(perms=["vm.view"])
def diff_snapshots_api(cluster_id, node, vm_type, vmid):
    """Compare two snapshot configs. Query: ?a=<snapA>&b=<snapB>"""
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()
    denied = _require_vm_access(cluster_id, vmid, "vm.view", vm_type)
    if denied:
        # lgtm[py/reflected-xss]
        return denied
    if cluster_id not in cluster_managers:
        # lgtm[py/reflected-xss]
        return jsonify({"error": "Cluster not found"}), 404
    a = (request.args.get("a") or "").strip()
    b = (request.args.get("b") or "").strip()
    if not a or not b:
        # lgtm[py/reflected-xss]
        return jsonify({"error": "Both ?a and ?b query params are required"}), 400
    # disallow path-traversal-ish stuff
    for s in (a, b):
        if "/" in s or "\x00" in s or len(s) > 64:
            # lgtm[py/reflected-xss]
            return jsonify({"error": "Invalid snapshot name"}), 400

    mgr = cluster_managers[cluster_id]
    if not mgr.is_connected:
        # lgtm[py/reflected-xss]
        return jsonify({"error": "Cluster offline"}), 503
    if vm_type not in ("qemu", "lxc"):
        # lgtm[py/reflected-xss]
        return jsonify({"error": "Invalid vm_type"}), 400

    def _fetch(snap):
        # 'current' is a synthetic name in PVE — request via ?current=1 endpoint
        if snap.lower() == "current":
            url = f"https://{mgr.host}:{mgr.api_port}/api2/json/nodes/{node}/{vm_type}/{vmid}/config?current=1"
        else:
            url = f"https://{mgr.host}:{mgr.api_port}/api2/json/nodes/{node}/{vm_type}/{vmid}/snapshot/{snap}/config"
        r = mgr._api_get(url)
        if r is None or r.status_code != 200:
            # lgtm[py/reflected-xss]
            return None, f"fetch failed for {snap} (status {getattr(r, 'status_code', '?')})"
        # lgtm[py/reflected-xss]
        return r.json().get("data") or {}, None

    cfg_a, err_a = _fetch(a)
    if err_a:
        # lgtm[py/reflected-xss]
        return jsonify({
            "error": err_a
        }), 502  # snyk:ignore:Cross-site Scripting (XSS)  # snyk:ignore:Server Information Exposure
    cfg_b, err_b = _fetch(b)
    if err_b:
        # lgtm[py/reflected-xss]
        return jsonify({
            "error": err_b
        }), 502  # snyk:ignore:Cross-site Scripting (XSS)  # snyk:ignore:Server Information Exposure

    # _fetch returns None as its first element on failure — re-default so the
    # diff below can rely on dicts once the err checks have passed.
    cfg_a = cfg_a or {}
    cfg_b = cfg_b or {}
    keys = sorted(set(cfg_a.keys()) | set(cfg_b.keys()))
    diffs = []
    for k in keys:
        va = cfg_a.get(k)
        vb = cfg_b.get(k)
        if va == vb:
            kind = "same"
        elif k not in cfg_a:
            kind = "added"
        elif k not in cfg_b:
            kind = "removed"
        else:
            kind = "changed"
        diffs.append({"key": k, "a": va, "b": vb, "kind": kind})

    summary = {
        "added": sum(1 for d in diffs if d["kind"] == "added"),
        "removed": sum(1 for d in diffs if d["kind"] == "removed"),
        "changed": sum(1 for d in diffs if d["kind"] == "changed"),
        "same": sum(1 for d in diffs if d["kind"] == "same"),
    }
    # lgtm[py/reflected-xss]
    return jsonify({
        "a": a,
        "b": b,
        "config_a": cfg_a,
        "config_b": cfg_b,
        "diffs": diffs,
        "summary": summary,
    })


# ==================== EFFICIENT (LVM COW) SNAPSHOT API ====================
# Space-efficient snapshot endpoints


@bp.route("/api/clusters/<cluster_id>/vms/<node>/<vm_type>/<int:vmid>/efficient-snapshots", methods=["GET"])
@require_auth(perms=["vm.snapshot"])
def get_efficient_snapshots_api(cluster_id, node, vm_type, vmid):
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()

    if cluster_id not in cluster_managers:
        # lgtm[py/reflected-xss]
        return jsonify({"error": "Cluster not found"}), 404

    # (perf) indexed single-row fetch — load_users() scanned/decrypted all users
    user = get_user_record(request.session["user"])
    user["username"] = request.session["user"]
    if not user_can_access_vm(user, cluster_id, vmid, "vm.snapshot", vm_type):
        # lgtm[py/reflected-xss]
        return jsonify({"error": "Permission denied: vm.snapshot"}), 403

    mgr = cluster_managers[cluster_id]
    refresh = request.args.get("refresh", "false").lower() == "true"
    snapshots = mgr.get_efficient_snapshots(cluster_id, vmid, refresh_usage=refresh)
    # lgtm[py/reflected-xss]
    return jsonify(snapshots)


@bp.route("/api/clusters/<cluster_id>/vms/<node>/<vm_type>/<int:vmid>/efficient-snapshots", methods=["POST"])
@require_auth(perms=["vm.snapshot"])
def create_efficient_snapshot_api(cluster_id, node, vm_type, vmid):
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()

    if cluster_id not in cluster_managers:
        # lgtm[py/reflected-xss]
        return jsonify({"error": "Cluster not found"}), 404

    # (perf) indexed single-row fetch — load_users() scanned/decrypted all users
    user = get_user_record(request.session["user"])
    user["username"] = request.session["user"]
    if not user_can_access_vm(user, cluster_id, vmid, "vm.snapshot", vm_type):
        # lgtm[py/reflected-xss]
        return jsonify({"error": "Permission denied: vm.snapshot"}), 403

    mgr = cluster_managers[cluster_id]
    data = request.json or {}

    snapname = data.get("snapname", f"snap_{int(time.time())}")
    description = data.get("description", "")
    snap_size_gb = data.get("snap_size_gb")

    result = mgr.create_efficient_snapshot(node, vmid, vm_type, snapname, description, snap_size_gb)

    if result["success"]:
        usr = getattr(request, "session", {}).get("user", "system")
        savings = result.get("space_savings", {})
        log_audit(
            usr,
            "snapshot.efficient_created",
            f"{vm_type.upper()} {vmid} - efficient snapshot '{snapname}' created "
            f"({savings.get('efficient_size_gb', 0):.1f} GB vs {savings.get('normal_size_gb', 0):.1f} GB normal, "
            f"{savings.get('savings_percent', 0)}% savings)",
            cluster=mgr.config.name,
        )
        # lgtm[py/reflected-xss]
        return jsonify({
            "message": f"Platzsparender Snapshot {snapname} erstellt",
            "snap_id": result["snap_id"],
            "space_savings": result["space_savings"],
        })
    else:
        # lgtm[py/reflected-xss]
        return jsonify({
            "error": result["error"]
        }), 500  # snyk:ignore:Cross-site Scripting (XSS)  # snyk:ignore:Server Information Exposure


@bp.route(
    "/api/clusters/<cluster_id>/vms/<node>/<vm_type>/<int:vmid>/efficient-snapshots/<snap_id>", methods=["DELETE"]
)
@require_auth(perms=["vm.snapshot"])
def delete_efficient_snapshot_api(cluster_id, node, vm_type, vmid, snap_id):
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()

    if cluster_id not in cluster_managers:
        # lgtm[py/reflected-xss]
        return jsonify({"error": "Cluster not found"}), 404

    # (perf) indexed single-row fetch — load_users() scanned/decrypted all users
    user = get_user_record(request.session["user"])
    user["username"] = request.session["user"]
    if not user_can_access_vm(user, cluster_id, vmid, "vm.snapshot", vm_type):
        # lgtm[py/reflected-xss]
        return jsonify({"error": "Permission denied: vm.snapshot"}), 403

    mgr = cluster_managers[cluster_id]
    result = mgr.delete_efficient_snapshot(node, vmid, snap_id)

    if result["success"]:
        usr = getattr(request, "session", {}).get("user", "system")
        log_audit(
            usr,
            "snapshot.efficient_deleted",
            f"{vm_type.upper()} {vmid} - efficient snapshot deleted",
            cluster=mgr.config.name,
        )
        # lgtm[py/reflected-xss]
        return jsonify({"message": "Platzsparender Snapshot gelöscht"})
    else:
        # lgtm[py/reflected-xss]
        return jsonify({
            "error": result["error"]
        }), 500  # snyk:ignore:Cross-site Scripting (XSS)  # snyk:ignore:Server Information Exposure


@bp.route(
    "/api/clusters/<cluster_id>/vms/<node>/<vm_type>/<int:vmid>/efficient-snapshots/<snap_id>/rollback",
    methods=["POST"],
)
@require_auth(perms=["vm.snapshot"])
def rollback_efficient_snapshot_api(cluster_id, node, vm_type, vmid, snap_id):
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()

    if cluster_id not in cluster_managers:
        # lgtm[py/reflected-xss]
        return jsonify({"error": "Cluster not found"}), 404

    # (perf) indexed single-row fetch — load_users() scanned/decrypted all users
    user = get_user_record(request.session["user"])
    user["username"] = request.session["user"]
    if not user_can_access_vm(user, cluster_id, vmid, "vm.snapshot", vm_type):
        # lgtm[py/reflected-xss]
        return jsonify({"error": "Permission denied: vm.snapshot"}), 403

    mgr = cluster_managers[cluster_id]
    result = mgr.rollback_efficient_snapshot(node, vmid, vm_type, snap_id)

    if result["success"]:
        usr = getattr(request, "session", {}).get("user", "system")
        log_audit(
            usr,
            "snapshot.efficient_rollback",
            f"{vm_type.upper()} {vmid} - efficient snapshot rollback started",
            cluster=mgr.config.name,
        )
        # lgtm[py/reflected-xss]
        return jsonify({"message": result.get("message", "Rollback gestartet")})
    else:
        # lgtm[py/reflected-xss]
        return jsonify({
            "error": result["error"]
        }), 500  # snyk:ignore:Cross-site Scripting (XSS)  # snyk:ignore:Server Information Exposure


# ==================== SNAPSHOT OVERVIEW API ====================


@bp.route("/api/snapshots/overview", methods=["GET", "POST"])
@require_auth(perms=["vm.view"])
def snapshots_overview():
    """Get overview of old snapshots across all clusters or a specific cluster

    Returns snapshots older than specified date, sorted by age

    Added cluster_id filter - when provided, only shows snapshots from that cluster
    """
    from ProxmoxVEx.utils.concurrent import run_concurrent

    user = request.session.get("user", "")
    # (perf) indexed single-row fetch — load_users() scanned/decrypted all users
    user_data = get_user_record(user)
    user_data["username"] = user
    data = request.get_json(silent=True) or {}
    # Don't filter by date unless user explicitly sets one - old default hid today's snapshots
    date_filter = data.get("date")
    filter_limit = data.get("limit", 200)
    filter_cluster = data.get("cluster_id")
    is_admin = user_data.get("role") == ROLE_ADMIN
    user_clusters = user_data.get("clusters", [])

    cutoff_date = None
    if date_filter:
        with contextlib.suppress(ValueError):
            cutoff_date = datetime.strptime(date_filter, "%Y-%m-%d").replace(tzinfo=UTC)

    all_vms = []
    for cluster_id, mgr in cluster_managers.items():
        if not mgr.is_connected:
            continue
        if filter_cluster and cluster_id != filter_cluster:
            continue
        if not is_admin and user_clusters and cluster_id not in user_clusters:
            continue
        try:
            for r in mgr.get_vm_resources():
                vmid = r.get("vmid")
                node = r.get("node")
                if vmid and node:
                    all_vms.append((cluster_id, node, vmid, r.get("name", ""), r.get("type", "qemu")))
        except Exception as e:
            logging.warning(f"[Snapshots] Failed to list VMs for {cluster_id}: {e}")

    # Fetch snapshots in parallel instead of sequential - huge speedup
    def _fetch_snap(args):
        cid, node, vmid, vm_name, vm_type = args
        try:
            mgr = cluster_managers.get(cid)
            if not mgr:
                # lgtm[py/reflected-xss]
                return []
            raw = mgr.get_snapshots(node, vmid, vm_type)
            results = []
            now = datetime.now(UTC)
            for snap in raw:
                snap_name = snap.get("name")
                snap_ts = snap.get("snaptime")
                if not snap_name or not snap_ts or snap_name == "current":
                    continue
                snap_dt = datetime.fromtimestamp(snap_ts, tz=UTC)
                if cutoff_date and snap_dt >= cutoff_date:
                    continue
                age_s = int((now - snap_dt).total_seconds())
                age = (
                    f"{age_s // 60} min"
                    if age_s < 3600
                    else f"{age_s // 3600} h"
                    if age_s < 86400
                    else f"{age_s // 86400} days"
                )
                results.append({
                    "vmid": vmid,
                    "vm_name": vm_name,
                    "vm_type": vm_type,
                    "node": node,
                    "snapshot_name": snap_name,
                    "snapshot_date": snap_dt.strftime("%Y-%m-%d %H:%M"),
                    "age": age,
                    "cluster_id": cid,
                })
            # lgtm[py/reflected-xss]
            return results
        except Exception as _e:
            # lgtm[py/reflected-xss]
            return []

    tasks = [lambda a=vm: _fetch_snap(a) for vm in all_vms]
    parallel_results = run_concurrent(tasks, timeout=25.0)

    snapshots = []
    for batch in parallel_results:
        if batch:
            snapshots.extend(batch)

    snapshots.sort(key=lambda s: s["snapshot_date"], reverse=False)
    snapshots = snapshots[:filter_limit]

    # lgtm[py/reflected-xss]
    return jsonify({"snapshots": snapshots})


@bp.route("/api/snapshots/delete", methods=["POST"])
@require_auth(perms=["vm.view", "vm.snapshot"])
def snapshots_overview_delete():
    """Delete multiple snapshots at once

    Bulk delete for snapshot cleanup
    """
    user = request.session.get("user", "")
    # (perf) indexed single-row fetch — load_users() scanned/decrypted all users
    user_data = get_user_record(user)
    user_data["username"] = user
    data = request.get_json(silent=True) or {}
    snapshots = data.get("snapshots", [])
    is_admin = user_data.get("role") == ROLE_ADMIN
    user_clusters = user_data.get("clusters", [])

    deleted_count = 0
    errors = []
    result = {"success": False}

    for snapshot in snapshots:
        try:
            cluster_id = snapshot.get("cluster_id")
            node = snapshot.get("node")
            vmid = snapshot.get("vmid")
            snapname = snapshot.get("snapshot_name")
            vm_type = snapshot.get("vm_type", "qemu")

            if cluster_id not in cluster_managers:
                errors.append(f"Cluster {cluster_id} not found")
                continue

            mgr = cluster_managers[cluster_id]

            if not mgr.is_connected:
                errors.append(f"Cluster {cluster_id} not connected")
                continue

            if not is_admin and user_clusters and cluster_id not in user_clusters:
                errors.append(f"No access to cluster {cluster_id}")
                continue

            # VM-level ACL check for snapshot delete
            if not user_can_access_vm(user_data, cluster_id, vmid, "vm.snapshot", vm_type):
                errors.append(f"Permission denied: vm.snapshot for VM {vmid}")
                continue

            result = mgr.delete_snapshot(node, vmid, vm_type, snapname)

            if result.get("success"):
                deleted_count += 1
                log_audit(
                    user,
                    "snapshot.deleted",
                    f"{vm_type.upper()} {vmid} - snapshot '{snapname}' deleted",
                    cluster=mgr.config.name,
                )
            else:
                errors.append(f"Failed to delete {snapname}: {result.get('error', 'Unknown error')}")

        except Exception as e:
            errors.append("Error deleting snapshot")
            logging.debug(f"Snapshot deletion failed: {e}")

    if deleted_count > 0:
        # lgtm[py/reflected-xss]
        return jsonify({
            "success": True,
            "message": f"{deleted_count} snapshot(s) deleted",
            "deleted": deleted_count,
            "errors": errors if errors else None,
        })
    else:
        # lgtm[py/reflected-xss]
        return jsonify({
            "success": False,
            "error": "No snapshots deleted",
            "errors": errors,
        }), 500  # snyk:ignore:Cross-site Scripting (XSS)  # snyk:ignore:Server Information Exposure
