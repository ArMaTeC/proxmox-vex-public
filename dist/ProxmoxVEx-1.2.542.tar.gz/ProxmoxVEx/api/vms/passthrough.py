# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/api/vms/passthrough.py
# Project:     ProxmoxVEx
# Version:     1.2.535
# Build:       2026.09.26
# Description: passthrough routes for the vms API (split from
#              api/vms.py).
# Usage:       import ProxmoxVEx.api.vms.passthrough
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-26
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""passthrough routes for the vms API (split from api/vms.py)."""

import html
import logging

from flask import jsonify

from ProxmoxVEx.api.helpers import check_cluster_access, get_connected_manager
from ProxmoxVEx.globals import cluster_managers
from ProxmoxVEx.utils.audit import log_audit
from ProxmoxVEx.utils.auth import require_auth

from .common import (
    _access_denied,
    _api_error,
    _cluster_not_connected,
    _cluster_not_found,
    _pve_error,
    _require_vm_access,
    bp,
    request,
)

# =====================================================
# PCI / USB / SERIAL PASSTHROUGH API
# =====================================================


@bp.route("/api/clusters/<cluster_id>/nodes/<node>/hardware/pci", methods=["GET"])
@require_auth(perms=["node.view"])
def get_node_pci_devices(cluster_id, node):
    """Get available PCI devices on a node for passthrough"""
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()
    manager, _ = get_connected_manager(cluster_id)
    if not manager:
        if cluster_id not in cluster_managers:
            return _cluster_not_found()
        return _cluster_not_connected()

    try:
        host, port = manager.host, manager.api_port
        url = f"https://{host}:{port}/api2/json/nodes/{node}/hardware/pci"
        response = manager._create_session().get(url, timeout=10)

        if response.status_code == 200:
            devices = response.json().get("data", [])
            # Enhance device info with friendly names
            for device in devices:
                device["display_name"] = (
                    f"{device.get('vendor_name', 'Unknown')} {device.get('device_name', device.get('id', 'Unknown'))}"
                )
                device["passthrough_capable"] = device.get("iommugroup", -1) >= 0
            # lgtm[py/reflected-xss]
            return jsonify(devices)
        # lgtm[py/reflected-xss]
        return jsonify([])
    except Exception as e:
        logging.error(f"Error getting PCI devices: {e}")
        return _api_error("Failed to get PCI devices", status=500)


@bp.route("/api/clusters/<cluster_id>/nodes/<node>/hardware/usb", methods=["GET"])
@require_auth(perms=["node.view"])
def get_node_usb_devices(cluster_id, node):
    """Get available USB devices on a node for passthrough"""
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()
    manager, _ = get_connected_manager(cluster_id)
    if not manager:
        if cluster_id not in cluster_managers:
            return _cluster_not_found()
        return _cluster_not_connected()

    try:
        host, port = manager.host, manager.api_port
        url = f"https://{host}:{port}/api2/json/nodes/{node}/hardware/usb"
        response = manager._create_session().get(url, timeout=10)

        if response.status_code == 200:
            devices = response.json().get("data", [])
            # Add display name
            for device in devices:
                vendor = device.get("manufacturer", device.get("vendid", "Unknown"))
                product = device.get("product", device.get("prodid", "Unknown"))
                device["display_name"] = f"{vendor} - {product}"
            # lgtm[py/reflected-xss]
            return jsonify(devices)
        # lgtm[py/reflected-xss]
        return jsonify([])
    except Exception as e:
        logging.error(f"Error getting USB devices: {e}")
        return _api_error("Failed to get USB devices", status=500)


# Recover the QEMU --args after the user changed disk bus type
# (scsi0 → sata0 etc.) via the Proxmox UI. The static sector-size args we wrote
# at V2P-migration time reference the original bus, so QEMU refuses to start
# ("there is no device 'scsi0' defined"). This endpoint reads the current VM
# config, regenerates the matching -set device.<bus><idx>.{logical,physical}_block_size
# from the actual disk attachments, and writes them back via `qm set --args`.
# No node-side artifacts (deliberately not a hookscript), one-shot recovery.
@bp.route("/api/clusters/<cluster_id>/vms/<node>/qemu/<int:vmid>/fix-args", methods=["POST"])
@require_auth(perms=["vm.config"])
def fix_vm_qemu_args(cluster_id, node, vmid):
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()
    denied = _require_vm_access(cluster_id, vmid, "vm.config", "qemu")
    if denied:
        # lgtm[py/reflected-xss]
        return denied
    manager, _ = get_connected_manager(cluster_id)
    if not manager:
        if cluster_id not in cluster_managers:
            return _cluster_not_found()
        return _cluster_not_connected()
    try:
        from ProxmoxVEx.core.v2p import _rebuild_sector_args

        changed, new_args, problem = _rebuild_sector_args(manager, node, vmid)
        if problem:
            # lgtm[py/reflected-xss]
            return jsonify({
                "ok": False,
                "error": problem,
                "args": new_args,
            }), 400  # snyk:ignore:Cross-site Scripting (XSS)
        log_audit(
            request.session.get("user", "admin"),
            "vm.fix_args",
            f"vmid={vmid} node={node} cluster={cluster_id} changed={changed}",
        )
        # lgtm[py/reflected-xss]
        return jsonify({
            "ok": True,
            "changed": changed,
            "args": new_args,
            "message": "args updated" if changed else "args already match current disks",
        })
    except Exception:
        logging.exception("Failed to get VM RRD data")
        return jsonify({
            "ok": False,
            "error": "An internal error occurred",
        }), 500


@bp.route("/api/clusters/<cluster_id>/vms/<node>/qemu/<int:vmid>/passthrough", methods=["GET"])
@require_auth(perms=["vm.view"])
def get_vm_passthrough_devices(cluster_id, node, vmid):
    """Get current passthrough devices configured for a VM"""
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()
    denied = _require_vm_access(cluster_id, vmid, "vm.view", "qemu")
    if denied:
        # lgtm[py/reflected-xss]
        return denied

    manager, _ = get_connected_manager(cluster_id)
    if not manager:
        if cluster_id not in cluster_managers:
            return _cluster_not_found()
        return _cluster_not_connected()

    try:
        host, port = manager.host, manager.api_port
        url = f"https://{host}:{port}/api2/json/nodes/{node}/qemu/{vmid}/config"
        r = manager._create_session().get(url, timeout=10)

        if r.status_code != 200:
            # lgtm[py/reflected-xss]
            return jsonify({"error": "Failed: VM config"}), 500

        config = r.json().get("data", {})

        # extract passthrough devices
        passthrough = {"pci": [], "usb": [], "serial": []}

        for key, value in config.items():
            # PCI devices
            if key.startswith("hostpci"):
                slot = key.replace("hostpci", "")
                passthrough["pci"].append({
                    "slot": slot,
                    "key": key,
                    "value": value,
                    "parsed": _parse_pci_config(value),
                })

            # USB devices
            if key.startswith("usb") and key[3:].isdigit():
                slot = key.replace("usb", "")
                passthrough["usb"].append({
                    "slot": slot,
                    "key": key,
                    "value": value,
                    "parsed": _parse_usb_config(value),
                })

            # Serial ports
            if key.startswith("serial"):
                slot = key.replace("serial", "")
                passthrough["serial"].append({"slot": slot, "key": key, "value": value})

        # lgtm[py/reflected-xss]
        return jsonify(passthrough)
    except Exception:
        return _api_error("Failed to get passthrough devices", status=500)


@bp.route("/api/clusters/<cluster_id>/vms/<node>/qemu/<int:vmid>/passthrough/pci", methods=["POST"])
@require_auth(perms=["vm.config"])
def add_pci_passthrough(cluster_id, node, vmid):
    """Add a PCI device passthrough to a VM"""
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()
    denied = _require_vm_access(cluster_id, vmid, "vm.config", "qemu")
    if denied:
        # lgtm[py/reflected-xss]
        return denied

    manager, _ = get_connected_manager(cluster_id)
    if not manager:
        if cluster_id not in cluster_managers:
            return _cluster_not_found()
        return _cluster_not_connected()

    data = request.json or {}
    device_id = data.get("device_id")

    if not device_id:
        # lgtm[py/reflected-xss]
        return jsonify({"error": "device_id required"}), 400

    try:
        host, port = manager.host, manager.api_port

        # Find next available hostpci slot
        config_url = f"https://{host}:{port}/api2/json/nodes/{node}/qemu/{vmid}/config"
        config_response = manager._create_session().get(config_url, timeout=10)
        config = config_response.json().get("data", {}) if config_response.status_code == 200 else {}

        # Find free slot (0-15)
        used_slots = [int(k.replace("hostpci", "")) for k in config if k.startswith("hostpci")]
        next_slot = 0
        while next_slot in used_slots and next_slot < 16:
            next_slot += 1

        if next_slot >= 16:
            # lgtm[py/reflected-xss]
            return jsonify({"error": "No free PCI slots available"}), 400

        # Build PCI passthrough config
        pci_config = device_id
        if data.get("pcie"):
            pci_config += ",pcie=1"
        if data.get("rombar") is False:
            pci_config += ",rombar=0"
        if data.get("x-vga"):
            pci_config += ",x-vga=1"

        # Update VM config
        update_url = f"https://{host}:{port}/api2/json/nodes/{node}/qemu/{vmid}/config"
        update_data = {f"hostpci{next_slot}": pci_config}
        response = manager._create_session().put(update_url, data=update_data, timeout=15)

        if response.status_code == 200:
            user = getattr(request, "session", {}).get("user", "system")
            log_audit(
                user,
                "vm.pci_added",
                f"VM {vmid}: Added PCI device {device_id} at slot {next_slot}",
                cluster=manager.config.name,
            )
            # lgtm[py/reflected-xss]
            return jsonify({"message": f"PCI device added at hostpci{next_slot}", "slot": next_slot})
        else:
            # lgtm[py/reflected-xss]
            return _pve_error(response, 500)

    except Exception as e:
        logging.error(f"Error adding PCI passthrough: {e}")
        return _api_error("Failed to add PCI passthrough", status=500)


@bp.route("/api/clusters/<cluster_id>/vms/<node>/qemu/<int:vmid>/passthrough/usb", methods=["POST"])
@require_auth(perms=["vm.config"])
def add_usb_passthrough(cluster_id, node, vmid):
    """Add a USB device passthrough to a VM"""
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()
    denied = _require_vm_access(cluster_id, vmid, "vm.config", "qemu")
    if denied:
        # lgtm[py/reflected-xss]
        return denied
    manager, _ = get_connected_manager(cluster_id)
    if not manager:
        if cluster_id not in cluster_managers:
            return _cluster_not_found()
        return _cluster_not_connected()

    data = request.json or {}

    # USB can be specified by vendor:product ID or by host bus/port
    vendor_id = data.get("vendorid")
    product_id = data.get("productid")
    host_bus = data.get("hostbus")
    host_port = data.get("hostport")

    if not ((vendor_id and product_id) or (host_bus and host_port)):
        # lgtm[py/reflected-xss]
        return jsonify({"error": "Either vendorid+productid or hostbus+hostport required"}), 400

    try:
        host, port = manager.host, manager.api_port

        # Find next available usb slot
        config_url = f"https://{host}:{port}/api2/json/nodes/{node}/qemu/{vmid}/config"
        config_response = manager._create_session().get(config_url, timeout=10)
        config = config_response.json().get("data", {}) if config_response.status_code == 200 else {}

        # Find free slot (0-4)
        used_slots = [int(k.replace("usb", "")) for k in config if k.startswith("usb") and k[3:].isdigit()]
        next_slot = 0
        while next_slot in used_slots and next_slot < 5:
            next_slot += 1

        if next_slot >= 5:
            # lgtm[py/reflected-xss]
            return jsonify({"error": "No free USB slots available (max 5)"}), 400

        # Build USB config
        usb_config = f"host={vendor_id}:{product_id}" if vendor_id and product_id else f"host={host_bus}-{host_port}"

        if data.get("usb3"):
            usb_config += ",usb3=1"

        # Update VM config
        update_url = f"https://{host}:{port}/api2/json/nodes/{node}/qemu/{vmid}/config"
        update_data = {f"usb{next_slot}": usb_config}
        response = manager._create_session().put(update_url, data=update_data, timeout=15)

        if response.status_code == 200:
            user = getattr(request, "session", {}).get("user", "system")
            log_audit(
                user, "vm.usb_added", f"VM {vmid}: Added USB device at slot {next_slot}", cluster=manager.config.name
            )
            # lgtm[py/reflected-xss]
            return jsonify({"message": f"USB device added at usb{next_slot}", "slot": next_slot})
        else:
            # lgtm[py/reflected-xss]
            return _pve_error(response, 500)

    except Exception as e:
        logging.error(f"Error adding USB passthrough: {e}")
        return _api_error("Failed to add USB passthrough", status=500)


@bp.route("/api/clusters/<cluster_id>/vms/<node>/qemu/<int:vmid>/passthrough/serial", methods=["POST"])
@require_auth(perms=["vm.config"])
def add_serial_port(cluster_id, node, vmid):
    """Add a serial port to a VM"""
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()
    denied = _require_vm_access(cluster_id, vmid, "vm.config", "qemu")
    if denied:
        # lgtm[py/reflected-xss]
        return denied
    manager, _ = get_connected_manager(cluster_id)
    if not manager:
        if cluster_id not in cluster_managers:
            return _cluster_not_found()
        return _cluster_not_connected()

    data = request.json or {}
    serial_type = data.get("type", "socket")  # socket, pty, or /dev/xxx

    try:
        host, port = manager.host, manager.api_port

        # Find next available serial slot
        config_url = f"https://{host}:{port}/api2/json/nodes/{node}/qemu/{vmid}/config"
        config_response = manager._create_session().get(config_url, timeout=10)
        config = config_response.json().get("data", {}) if config_response.status_code == 200 else {}

        # Find free slot (0-3)
        used_slots = [int(k.replace("serial", "")) for k in config if k.startswith("serial")]
        next_slot = 0
        while next_slot in used_slots and next_slot < 4:
            next_slot += 1

        if next_slot >= 4:
            # lgtm[py/reflected-xss]
            return jsonify({"error": "No free serial slots available (max 4)"}), 400

        # Update VM config
        update_url = f"https://{host}:{port}/api2/json/nodes/{node}/qemu/{vmid}/config"
        update_data = {f"serial{next_slot}": serial_type}
        response = manager._create_session().put(update_url, data=update_data, timeout=15)

        if response.status_code == 200:
            user = getattr(request, "session", {}).get("user", "system")
            log_audit(
                user,
                "vm.serial_added",
                f"VM {vmid}: Added serial port at slot {next_slot}",
                cluster=manager.config.name,
            )
            # lgtm[py/reflected-xss]
            return jsonify({"message": f"Serial port added at serial{next_slot}", "slot": next_slot})
        else:
            # lgtm[py/reflected-xss]
            return _pve_error(response, 500)

    except Exception as e:
        logging.error(f"Error adding serial port: {e}")
        return _api_error("Failed to add serial port", status=500)


@bp.route("/api/clusters/<cluster_id>/vms/<node>/qemu/<int:vmid>/passthrough/<device_type>/<key>", methods=["DELETE"])
@require_auth(perms=["vm.config"])
def remove_passthrough_device(cluster_id, node, vmid, device_type, key):
    """Remove a passthrough device from a VM"""
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()
    denied = _require_vm_access(cluster_id, vmid, "vm.config", "qemu")
    if denied:
        # lgtm[py/reflected-xss]
        return denied
    manager, _ = get_connected_manager(cluster_id)
    if not manager:
        if cluster_id not in cluster_managers:
            return _cluster_not_found()
        return _cluster_not_connected()

    # Validate device type and key
    valid_prefixes = {"pci": "hostpci", "usb": "usb", "serial": "serial"}
    if device_type not in valid_prefixes:
        # lgtm[py/reflected-xss]
        return jsonify({"error": "Invalid device type"}), 400

    # Key should be like hostpci0, usb1, serial0
    expected_prefix = valid_prefixes[device_type]
    if not key.startswith(expected_prefix):
        # lgtm[py/reflected-xss]
        return jsonify({"error": f"Invalid key for {html.escape(str(device_type))}"}), 400

    try:
        host, port = manager.host, manager.api_port

        # Delete by setting to empty/delete
        update_url = f"https://{host}:{port}/api2/json/nodes/{node}/qemu/{vmid}/config"
        update_data = {"delete": key}
        response = manager._create_session().put(update_url, data=update_data, timeout=15)

        if response.status_code == 200:
            user = getattr(request, "session", {}).get("user", "system")
            log_audit(user, f"vm.{device_type}_removed", f"VM {vmid}: Removed {key}", cluster=manager.config.name)
            # lgtm[py/reflected-xss]
            return jsonify({"message": f"Device {key} removed"})
        else:
            # lgtm[py/reflected-xss]
            return _pve_error(response, 500)

    except Exception as e:
        logging.error(f"Error removing passthrough device: {e}")
        return _api_error("Failed to remove passthrough device", status=500)


def _parse_pci_config(config_str):
    """Parse PCI passthrough config string"""
    result = {"device": None, "options": {}}
    if not config_str:
        # lgtm[py/reflected-xss]
        return jsonify(result)

    parts = config_str.split(",")
    result["device"] = parts[0]

    for part in parts[1:]:
        if "=" in part:
            key, value = part.split("=", 1)
            result["options"][key] = value

    # lgtm[py/reflected-xss]
    return jsonify(result)


def _parse_usb_config(config_str):
    """Parse USB passthrough config string"""
    result = {"host": None, "options": {}}
    if not config_str:
        # lgtm[py/reflected-xss]
        return jsonify(result)

    parts = config_str.split(",")
    for part in parts:
        if "=" in part:
            key, value = part.split("=", 1)
            if key == "host":
                result["host"] = value
            else:
                result["options"][key] = value

    # lgtm[py/reflected-xss]
    return jsonify(result)
