# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/api/vms/datastores.py
# Project:     ProxmoxVEx
# Version:     1.2.535
# Build:       2026.09.26
# Description: datastores routes for the vms API (split from
#              api/vms.py).
# Usage:       import ProxmoxVEx.api.vms.datastores
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-26
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""datastores routes for the vms API (split from api/vms.py)."""

import contextlib
import html
import logging
import os
import re
import time

import requests
from flask import jsonify

from ProxmoxVEx.api.helpers import check_cluster_access, get_connected_manager
from ProxmoxVEx.core.cache import cached_get
from ProxmoxVEx.globals import cluster_managers
from ProxmoxVEx.utils.audit import log_audit
from ProxmoxVEx.utils.auth import require_auth

from .common import (
    _access_denied,
    _api_error,
    _cluster_not_connected,
    _cluster_not_found,
    bp,
    request,
)


# Storage API
@bp.route("/api/clusters/<cluster_id>/datacenter/storage", methods=["GET"])
@require_auth(perms=["storage.view"])
@cached_get(ttl=15)
def get_storage_list(cluster_id):
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()

    manager, _ = get_connected_manager(cluster_id)
    if not manager:
        if cluster_id not in cluster_managers:
            return _cluster_not_found()
        return _cluster_not_connected()

    try:
        host, port = manager.host, manager.api_port
        url = f"https://{host}:{port}/api2/json/storage"
        r = manager._create_session().get(url, timeout=5)

        if r.status_code == 200:
            # lgtm[py/reflected-xss]
            return jsonify(r.json().get("data", []))
        # lgtm[py/reflected-xss]
        return jsonify([])
    except Exception as _e:
        # lgtm[py/reflected-xss]
        return jsonify([])


# (SSE-perf): short per-cluster cache for the datastores aggregate.
# get_datastores fans out /nodes/<node>/storage per ONLINE node (O(nodes), 8-wide,
# ~13 serial waves at 100 nodes) with no cache, and since 0548dc3/32486a6 it rides
# BOTH the 15s selected-cluster poll AND a 30s per-expanded-sidebar-cluster loop
# so the heavy fan-out fired several times a minute per cluster. Storage totals move
# on grow/add, not per-15s, so a small snapshot collapses the overlapping pollers
# (and multiple browser tabs) onto one fan-out per window. Keyed per cluster; the
# payload is cluster-global + already storage.view-gated by the caller above.
_datastores_cache = {}


_DATASTORES_TTL = 12.0


@bp.route("/api/clusters/<cluster_id>/datastores", methods=["GET"])
@require_auth(perms=["storage.view"])
@cached_get(ttl=15)
def get_datastores(cluster_id):
    """Get all datastores with usage info"""
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()

    manager, _ = get_connected_manager(cluster_id)
    if not manager:
        if cluster_id not in cluster_managers:
            return _cluster_not_found()
        return _cluster_not_connected()

    _dc = _datastores_cache.get(cluster_id)
    if _dc and (time.time() - _dc[0]) < _DATASTORES_TTL:
        # lgtm[py/reflected-xss]
        return jsonify(_dc[1])

    try:
        host, port = manager.host, manager.api_port
        sess = manager._create_session()

        # get storage configs
        storage_url = f"https://{host}:{port}/api2/json/storage"
        storage_resp = sess.get(storage_url, timeout=5)
        storage_configs = {}
        if storage_resp.status_code == 200:
            for s in storage_resp.json().get("data", []):
                storage_configs[s["storage"]] = s

        # Fetch nodes via /cluster/resources to get the *online* flag.
        # /api2/json/nodes alone doesn't tell us which are reachable; if we then
        # try to fetch /storage from a dead node we waste 10s per offline node.
        nodes = []  # [(name, status), ...]
        try:
            cr_resp = sess.get(f"https://{host}:{port}/api2/json/cluster/resources", params={"type": "node"}, timeout=5)
            if cr_resp.status_code == 200:
                for n in cr_resp.json().get("data", []):
                    nm = n.get("node")
                    if nm:
                        nodes.append((nm, n.get("status", "unknown")))
        except Exception as _e:
            pass
        if not nodes:
            # fallback to /nodes (no online flag, still iterate but trust try/except)
            nodes_resp = sess.get(f"https://{host}:{port}/api2/json/nodes", timeout=5)
            if nodes_resp.status_code == 200:
                nodes = [(n["node"], n.get("status", "unknown")) for n in nodes_resp.json().get("data", [])]

        online_nodes = [n for n, st in nodes if st == "online"]
        offline_nodes = [n for n, st in nodes if st != "online"]
        all_node_names = [n for n, _ in nodes]

        shared_storages = {}
        local_storages = {}

        # Fetch all online nodes' storage in parallel; gevent
        # patches threading so this is cheap. Each call has its own short
        # timeout so a slow node doesn't drag the whole response.
        from concurrent.futures import ThreadPoolExecutor, as_completed

        def _probe_node(node):
            try:
                u = f"https://{host}:{port}/api2/json/nodes/{node}/storage"
                r = sess.get(u, timeout=8)
                if r.status_code == 200:
                    # lgtm[py/reflected-xss]
                    return node, r.json().get("data", []), None
                # lgtm[py/reflected-xss]
                return node, [], f"HTTP {r.status_code}"
            except Exception as e:
                # lgtm[py/reflected-xss]
                return node, [], str(e)

        results = []
        if online_nodes:
            with ThreadPoolExecutor(max_workers=min(8, len(online_nodes))) as ex:
                futures = [ex.submit(_probe_node, n) for n in online_nodes]
                for fut in as_completed(futures, timeout=15):
                    try:
                        results.append(fut.result())
                    except Exception as e:
                        logging.debug(f"[datastores] future error: {e}")

        for node, storages, err in results:
            if err:
                logging.debug(f"[datastores] node {node} unreachable: {err}")
                continue
            for storage in storages:
                storage_name = storage.get("storage")
                config = storage_configs.get(storage_name, {})
                is_shared = config.get("shared", 0) == 1
                is_active_here = storage.get("active", 1) == 1 and storage.get("enabled", 1) == 1

                storage_info = {
                    "storage": storage_name,
                    "type": storage.get("type", config.get("type", "unknown")),
                    "content": storage.get("content", config.get("content", "")),
                    "total": storage.get("total", 0),
                    "used": storage.get("used", 0),
                    "avail": storage.get("avail", 0),
                    "used_fraction": storage.get("used_fraction", 0),
                    "active": storage.get("active", 1),
                    "enabled": storage.get("enabled", 1),
                    "shared": is_shared,
                    "path": config.get("path", ""),
                    "nodes": config.get("nodes", ""),
                }

                if is_shared:
                    if storage_name not in shared_storages:
                        shared_storages[storage_name] = dict(storage_info)
                        shared_storages[storage_name]["active_on"] = []
                        shared_storages[storage_name]["inactive_on"] = []
                    entry = shared_storages[storage_name]
                    (entry["active_on"] if is_active_here else entry["inactive_on"]).append(node)
                    # Always prefer the largest-known total (any reachable
                    # node should report the same number for shared, but rounding +
                    # transient zero values can flap).
                    if is_active_here and storage.get("total", 0) > entry.get("total", 0):
                        entry.update({
                            "total": storage.get("total", 0),
                            "used": storage.get("used", 0),
                            "avail": storage.get("avail", 0),
                            "used_fraction": storage.get("used_fraction", 0),
                        })
                    if is_active_here:
                        entry["active"] = 1
                        entry["enabled"] = 1
                else:
                    if node not in local_storages:
                        local_storages[node] = []
                    local_storages[node].append(storage_info)

        # For offline nodes: surface their last-known storages from the
        # cluster's storage config so the UI can render "this node has these storages,
        # node is currently offline" instead of an empty space. We can't get current
        # used/avail without contacting the node, so we mark them as `node_offline`.
        for off_node in offline_nodes:
            local_storages.setdefault(off_node, [])
            for sname, cfg in storage_configs.items():
                if cfg.get("shared", 0) == 1:
                    continue
                node_filter = cfg.get("nodes", "")
                # apply if node_filter is empty (= all nodes) or contains this node
                if node_filter and off_node not in node_filter.split(","):
                    continue
                local_storages[off_node].append({
                    "storage": sname,
                    "type": cfg.get("type", "unknown"),
                    "content": cfg.get("content", ""),
                    "total": 0,
                    "used": 0,
                    "avail": 0,
                    "used_fraction": 0,
                    "active": 0,
                    "enabled": cfg.get("disable", 0) != 1,
                    "shared": False,
                    "path": cfg.get("path", ""),
                    "nodes": node_filter,
                    "node_offline": True,
                })

        # also include shared storages from config that didn't appear (no online node mounted them)
        for sname, cfg in storage_configs.items():
            if sname not in shared_storages and cfg.get("shared", 0) == 1:
                shared_storages[sname] = {
                    "storage": sname,
                    "type": cfg.get("type", "unknown"),
                    "content": cfg.get("content", ""),
                    "total": 0,
                    "used": 0,
                    "avail": 0,
                    "used_fraction": 0,
                    "active": 0,
                    "enabled": cfg.get("disable", 0) != 1,
                    "shared": True,
                    "path": cfg.get("path", ""),
                    "nodes": cfg.get("nodes", ""),
                    "active_on": [],
                    "inactive_on": list(all_node_names),
                }

        payload = {
            "shared": list(shared_storages.values()),
            "local": local_storages,
            "nodes": all_node_names,
            "offline_nodes": offline_nodes,
        }
        _datastores_cache[cluster_id] = (time.time(), payload)
        # lgtm[py/reflected-xss]
        return jsonify(payload)
    except (requests.exceptions.ConnectionError, requests.exceptions.Timeout) as e:
        logging.warning(f"[API] Cluster {cluster_id} unreachable for datastores: {e}")
        # lgtm[py/reflected-xss]
        return jsonify({"error": "Cluster temporarily unreachable", "offline": True}), 503
    except Exception:
        return _api_error("Failed to get storage list", status=500)


def _fmt_size_human(size):
    size = size or 0
    if size >= 1024**4:
        # lgtm[py/reflected-xss]
        return f"{size / 1024**4:.2f} TB"
    if size >= 1024**3:
        # lgtm[py/reflected-xss]
        return f"{size / 1024**3:.2f} GB"
    if size >= 1024**2:
        # lgtm[py/reflected-xss]
        return f"{size / 1024**2:.2f} MB"
    if size >= 1024:
        # lgtm[py/reflected-xss]
        return f"{size / 1024:.2f} KB"
    # lgtm[py/reflected-xss]
    return f"{int(size)} B"


def _pve_size_to_bytes(s):
    # '32G' / '500M' / '1.5T' -> bytes; a bare number is already bytes
    if not s:
        # lgtm[py/reflected-xss]
        return 0
    s = str(s).strip().upper()
    mult = {"K": 1024, "M": 1024**2, "G": 1024**3, "T": 1024**4, "P": 1024**5}
    if s and s[-1] in mult:
        try:
            # lgtm[py/reflected-xss]
            return int(float(s[:-1]) * mult[s[-1]])
        except ValueError:
            # lgtm[py/reflected-xss]
            return 0
    try:
        # lgtm[py/reflected-xss]
        return int(float(s))
    except ValueError:
        # lgtm[py/reflected-xss]
        return 0


# Shared SAN/LVM (and the StarWind starlvm plugin) only report a
# volume's real size on the node whose host currently has the LV active. Browse
# the datastore "from" any other node and the disk shows up but reads 0 bytes
# (Nico hit this on a multi-node shared LVM). The true size still lives
# cluster-wide in the owning guest's config as size=NNG, so backfill the zeros
# from there. No-op on file/thick-LVM storages that already hand us a size.
def _backfill_zero_datastore_sizes(manager, host, port, content):
    zero = [it for it in content if not (it.get("size") or 0) and it.get("vmid")]
    if not zero:
        return
    rr = manager._create_session().get(f"https://{host}:{port}/api2/json/cluster/resources?type=vm", timeout=8)
    if rr.status_code != 200:
        return
    vm_loc = {}
    for r in rr.json().get("data", []):
        vm_loc[r.get("vmid")] = (r.get("node"), "lxc" if r.get("type") == "lxc" else "qemu")

    # distinct guests we still need a config from — capped so a 10k-VM estate
    # can't turn one datastore click into thousands of config calls
    want, seen = [], set()
    for it in zero:
        vid = it.get("vmid")
        if vid in vm_loc and vid not in seen:
            seen.add(vid)
            want.append(vid)
    CAP = 250
    if len(want) > CAP:
        logging.info(
            f"[datastore] size-backfill capped at {CAP}/{len(want)} guests — some remote disks will still read 0"
        )
        want = want[:CAP]

    def _fetch(vid):
        node, vtype = vm_loc[vid]
        try:
            cr = manager._create_session().get(
                f"https://{host}:{port}/api2/json/nodes/{node}/{vtype}/{vid}/config", timeout=6
            )
            if cr.status_code == 200:
                # lgtm[py/reflected-xss]
                return vid, cr.json().get("data", {})
        except Exception as _e:
            pass
        # lgtm[py/reflected-xss]
        return vid, None

    from ProxmoxVEx.utils.concurrent import run_concurrent

    got = run_concurrent([lambda v=v: _fetch(v) for v in want], timeout=25)

    # volume-basename -> bytes, harvested from every disk line across those configs
    size_by_vol = {}
    for pair in got:
        if not pair or not pair[1]:
            continue
        for _key, val in pair[1].items():
            if not isinstance(val, str) or ":" not in val or "size=" not in val:
                continue
            base = val.split(",", 1)[0].split(":", 1)[1].split("/")[-1]  # vm-100-disk-0
            m = re.search(r"size=([0-9.]+[KMGTP]?)", val)
            if m and base:
                size_by_vol[base] = _pve_size_to_bytes(m.group(1))

    for it in zero:
        volid = it.get("volid") or ""
        base = (volid.split(":", 1)[1] if ":" in volid else volid).split("/")[-1]
        b = size_by_vol.get(base)
        if b:
            it["size"] = b
            it["size_from_config"] = True  # UI could badge this later if we want


@bp.route("/api/clusters/<cluster_id>/datastores/<storage_name>/content", methods=["GET"])
@require_auth(perms=["storage.view"])
def get_datastore_content(cluster_id, storage_name):
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()

    manager, _ = get_connected_manager(cluster_id)
    if not manager:
        if cluster_id not in cluster_managers:
            return _cluster_not_found()
        return _cluster_not_connected()

    try:
        host, port = manager.host, manager.api_port
        node = request.args.get("node")

        # If no node specified, find first node that has this storage
        if not node:
            nodes_url = f"https://{host}:{port}/api2/json/nodes"
            nodes_response = manager._create_session().get(nodes_url, timeout=5)
            if nodes_response.status_code == 200:
                for n in nodes_response.json().get("data", []):
                    node = n["node"]
                    break

        if not node:
            # lgtm[py/reflected-xss]
            return jsonify({"error": "No node available"}), 400

        # Get storage content
        content_url = f"https://{host}:{port}/api2/json/nodes/{node}/storage/{storage_name}/content"
        response = manager._create_session().get(content_url, timeout=5)

        if response.status_code == 200:
            content = response.json().get("data", [])
            for item in content:
                item["storage"] = storage_name
                item["node"] = node
                item["in_use"] = bool(item.get("vmid"))

            # backfill sizes PVE reported as 0 for disks whose LV is active on
            # another node (shared SAN/LVM, starlvm) — see helper above
            try:
                _backfill_zero_datastore_sizes(manager, host, port, content)
            except Exception as e:
                logging.debug(f"[datastore] size backfill skipped: {e}")

            for item in content:
                item["size_human"] = _fmt_size_human(item.get("size") or 0)

            # lgtm[py/reflected-xss]
            return jsonify(content)
        # lgtm[py/reflected-xss]
        return jsonify([])
    except (requests.exceptions.ConnectionError, requests.exceptions.Timeout) as e:
        logging.warning(f"[API] Cluster {cluster_id} unreachable for storage content: {e}")
        # lgtm[py/reflected-xss]
        return jsonify({"error": "Cluster temporarily unreachable", "offline": True}), 503
    except Exception as e:
        logging.error(f"Error getting datastore content: {e}")
        return _api_error("Failed to get datastore content", status=500)


@bp.route("/api/clusters/<cluster_id>/datastores/<storage_name>/content/<path:volid>", methods=["DELETE"])
@require_auth(perms=["storage.delete"])
def delete_datastore_content(cluster_id, storage_name, volid):
    """Delete content from a datastore (ISO, backup, etc.)"""
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()
    manager, _ = get_connected_manager(cluster_id)
    if not manager:
        if cluster_id not in cluster_managers:
            return _cluster_not_found()
        return _cluster_not_connected()

    try:
        host, port = manager.host, manager.api_port
        node = request.args.get("node")

        if not node:
            # Find a node that has this storage
            nodes_url = f"https://{host}:{port}/api2/json/nodes"
            nodes_response = manager._create_session().get(nodes_url, timeout=5)
            if nodes_response.status_code == 200:
                for n in nodes_response.json().get("data", []):
                    node = n["node"]
                    break

        if not node:
            # lgtm[py/reflected-xss]
            return jsonify({"error": "No node available"}), 400

        # check volume is in use by any VM or Container
        resources_url = f"https://{host}:{port}/api2/json/cluster/resources?type=vm"
        resources_response = manager._create_session().get(resources_url, timeout=5)

        if resources_response.status_code == 200:
            for vm in resources_response.json().get("data", []):
                vm_node = vm.get("node")
                vmid = vm.get("vmid")
                vm_type = "qemu" if vm.get("type") == "qemu" else "lxc"

                # Get VM/CT config to check disks and mounted ISOs
                config_url = f"https://{host}:{port}/api2/json/nodes/{vm_node}/{vm_type}/{vmid}/config"
                config_response = manager._create_session().get(config_url, timeout=5)
                if config_response.status_code == 200:
                    config = config_response.json().get("data", {})

                    # Check all config entries for volume reference
                    for key, value in config.items():
                        if not isinstance(value, str):
                            continue

                        # Check for disk images
                        if volid in value:
                            resource_name = "VM" if vm_type == "qemu" else "Container"
                            # lgtm[py/reflected-xss]
                            return jsonify({
                                "error": f"Volume is in use by {resource_name} {vmid} ({key})",
                                "in_use": True,
                                "vmid": vmid,
                                "type": vm_type,
                            }), 400

                        # Check for mounted ISOs (ide*, sata*, scsi* with media=cdrom)
                        if volid.endswith(".iso"):
                            # check this ISO is mounted
                            iso_name = volid.split("/")[-1] if "/" in volid else volid
                            if iso_name in value or volid in value:
                                # lgtm[py/reflected-xss]
                                return jsonify({
                                    "error": f"ISO is mounted in VM {vmid} ({key})",
                                    "in_use": True,
                                    "vmid": vmid,
                                    "type": "qemu",
                                }), 400

                    # For containers, also check mount points
                    if vm_type == "lxc":
                        for key, value in config.items():
                            if key.startswith("mp") and isinstance(value, str) and volid in value:
                                # lgtm[py/reflected-xss]
                                return jsonify({
                                    "error": f"Volume is mounted in Container {vmid} ({key})",
                                    "in_use": True,
                                    "vmid": vmid,
                                    "type": "lxc",
                                }), 400

        # Delete the volume
        # URL encode the volid properly
        encoded_volid = volid.replace("/", "%2F")
        delete_url = f"https://{host}:{port}/api2/json/nodes/{node}/storage/{storage_name}/content/{encoded_volid}"
        response = manager._create_session().delete(delete_url, timeout=10)

        if response.status_code == 200:
            user = request.session.get("user", "unknown")
            log_audit(
                user, "storage.content_deleted", f"Deleted {volid} from {storage_name}", cluster=manager.config.name
            )
            # lgtm[py/reflected-xss]
            return jsonify({"success": True, "message": f"Deleted {volid}"})
        else:
            error_msg = response.json().get("errors", response.text) if response.text else "Delete failed"
            # lgtm[py/reflected-xss]
            return (
                jsonify({"error": html.escape(str(error_msg))}),
                response.status_code,
            )

    except Exception as e:
        logging.error(f"Error deleting content: {e}")
        return _api_error("Failed to delete datastore content", status=500)


@bp.route("/api/clusters/<cluster_id>/datastores/<storage_name>/upload", methods=["POST"])
@require_auth(perms=["storage.upload"])
def upload_to_datastore(cluster_id, storage_name):
    """Upload ISO or other content to a datastore"""
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()
    manager, _ = get_connected_manager(cluster_id)
    if not manager:
        if cluster_id not in cluster_managers:
            return _cluster_not_found()
        return _cluster_not_connected()

    tmp_path = None
    try:
        host, port = manager.host, manager.api_port
        node = request.form.get("node") or request.args.get("node")
        content_type = request.form.get("content", "iso")  # iso, vztmpl, etc.

        if not node:
            # Pick an online node, not just the first one
            try:
                nodes_resp = manager._api_get(f"https://{host}:{port}/api2/json/nodes")
                if nodes_resp.status_code == 200:
                    for n in nodes_resp.json().get("data", []):
                        if n.get("status") == "online":
                            node = n["node"]
                            break
                    # fallback: first node if none reported online
                    if not node:
                        ndata = nodes_resp.json().get("data", [])
                        if ndata:
                            node = ndata[0]["node"]
            except Exception as e:
                logging.warning(f"Node lookup for upload failed: {e}")

        if not node:
            # lgtm[py/reflected-xss]
            return jsonify({"error": "No node available"}), 400

        if "file" not in request.files:
            # lgtm[py/reflected-xss]
            return jsonify({"error": "No file provided"}), 400

        file = request.files["file"]
        if not file.filename:
            # lgtm[py/reflected-xss]
            return jsonify({"error": "No file selected"}), 400

        # Allow disk images alongside ISOs
        filename = os.path.basename(file.filename)  # strip directory components
        if not filename or filename.startswith(".") or "/" in filename or "\\" in filename:
            # lgtm[py/reflected-xss]
            return jsonify({"error": "Invalid filename"}), 400
        _allowed_ext = {
            "iso": (".iso",),
            "import": (".vmdk", ".qcow2", ".img", ".raw"),
            "vztmpl": (".tar.gz", ".tar.xz", ".tar.zst"),
        }
        allowed = _allowed_ext.get(content_type)
        if allowed and not filename.lower().endswith(allowed):
            # lgtm[py/reflected-xss]
            # snyk:ignore:Cross-site Scripting (XSS)
            return jsonify({
                "error": f"Invalid file type. Allowed: {', '.join(allowed)}"
            }), 400  # snyk:ignore:Cross-site Scripting (XSS)
        # Reject filenames with null bytes or shell metacharacters
        if any(c in filename for c in "\x00;|&$`"):
            # lgtm[py/reflected-xss]
            return jsonify({"error": "Invalid characters in filename"}), 400

        # Save to temp file first, SpooledTemporaryFile + requests is unreliable
        # across werkzeug versions. Temp file is cleaned up in finally block.
        # #119: use app dir for temp, not /tmp (LXC tmpfs is often too small for ISOs)
        import tempfile

        upload_tmp_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))), "tmp")  # one extra level: module lives in api/vms/
        os.makedirs(upload_tmp_dir, mode=0o700, exist_ok=True)
        # don't include user extension in temp filename
        fd, tmp_path = tempfile.mkstemp(dir=upload_tmp_dir)
        try:
            # (pentest DoS) - the /upload route permits a very large body
            # (100 GB cap); refuse up front if the appliance temp dir can't hold it
            # (disk-exhaustion DoS) instead of filling the disk mid-write. 256 MB reserve.
            import shutil as _shutil

            _clen = request.content_length or 0
            if _clen and (_clen + 256 * 1024 * 1024) > _shutil.disk_usage(upload_tmp_dir).free:
                os.close(fd)
                with contextlib.suppress(Exception):
                    os.unlink(tmp_path)
                # lgtm[py/reflected-xss]
                return jsonify({"error": "Insufficient free space on the appliance to buffer this upload"}), 507
            file.save(tmp_path)
        except Exception as _e:
            os.close(fd)
            raise
        else:
            os.close(fd)

        upload_url = f"https://{host}:{port}/api2/json/nodes/{node}/storage/{storage_name}/upload"

        with open(tmp_path, "rb") as fh:
            # 2026-06-04 (#525 ccesario): switched from `files=` (which
            # makes requests run fp.read() to encode the whole multipart
            # body into memory before sending — OOMs the appliance for
            # 2+ GB ISOs with MemoryError out of requests.models._encode_files)
            # to MultipartEncoder, which exposes a file-like body that
            # requests streams chunk-by-chunk over the wire. Memory
            # footprint becomes constant in the file size — a 50 GB ISO
            # uses the same RAM as a 5 MB one.
            from requests_toolbelt.multipart.encoder import MultipartEncoder

            # 2026-06-17 - field ORDER matters here: Proxmox's upload parser needs the
            # `content` param to arrive BEFORE the file part, otherwise it rejects the whole
            # request with "content: property is missing and it is not optional". The #525
            # switch to MultipartEncoder passed a dict with the file field first, which flipped
            # the order vs the old files=/data= path (data fields came first there) and
            # regressed *every* ISO/template upload. Use an ordered list, content first.
            encoder = MultipartEncoder(
                fields=[
                    ("content", content_type),
                    ("filename", (filename, fh, "application/octet-stream")),
                ]
            )
            # Use _api_post for auto-reconnect tracking, 1h timeout for large ISOs
            response = manager._api_post(
                upload_url,
                data=encoder,
                headers={"Content-Type": encoder.content_type},
                timeout=3600,
            )

        if response.status_code == 200:
            result = response.json()
            user = request.session.get("user", "unknown")
            log_audit(user, "storage.upload", f"Uploaded {filename} to {storage_name}", cluster=manager.config.name)
            # lgtm[py/reflected-xss]
            return jsonify({"success": True, "message": f"Upload started: {filename}", "upid": result.get("data")})
        else:
            # Safe error parsing, Proxmox sometimes returns HTML on 5xx
            try:
                pve = response.json()
                errs = pve.get("errors")
                # 2026-06-08 (#524 ccesario): PVE returns field errors as a dict
                # (e.g. {'filename': 'invalid format - ...'} when a name carries chars
                # it won't accept, like parentheses). Flatten it — handing the dict
                # straight through showed up as "[object Object]" in the upload alert.
                if isinstance(errs, dict):
                    error_msg = "; ".join(f"{k}: {v}" for k, v in errs.items()) or pve.get("message") or "Upload failed"
                else:
                    error_msg = errs or pve.get("message") or response.text or "Upload failed"
            except Exception as _e:
                error_msg = response.text[:500] if response.text else "Upload failed"
            logging.error(f"Upload to {storage_name} failed: HTTP {response.status_code} - {error_msg}")
            # lgtm[py/reflected-xss]
            return (
                jsonify({"error": html.escape(str(error_msg))}),
                response.status_code,
            )

    except Exception as e:
        logging.error(f"Error uploading to {storage_name}: {e}")
        return _api_error("Failed to upload to datastore", status=500)
    finally:
        if tmp_path and os.path.exists(tmp_path):
            with contextlib.suppress(Exception):
                os.unlink(tmp_path)


# Download ISO from URL
# Like Proxmox's "Download from URL" feature
# Tracks download progress in memory (for status polling)
_url_downloads = {}  # task_id -> { status, percent, message, ... }


@bp.route("/api/clusters/<cluster_id>/datastores/<storage_name>/download-url", methods=["POST"])
@require_auth(perms=["storage.upload"])
def download_iso_from_url(cluster_id, storage_name):
    """Download ISO/image from URL to storage (like Proxmox)"""
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()
    manager, _ = get_connected_manager(cluster_id)
    if not manager:
        if cluster_id not in cluster_managers:
            return _cluster_not_found()
        return _cluster_not_connected()

    try:
        data = request.json or {}
        url = data.get("url", "").strip()
        filename = data.get("filename", "").strip()
        node = data.get("node", "").strip()

        if not url:
            # lgtm[py/reflected-xss]
            return jsonify({"error": "URL is required"}), 400

        # (pentest HIGH) - the previous hand-rolled filter FAILED OPEN on an
        # unresolvable host ("let proxmox handle it") and missed multicast / CGNAT /
        # metadata-by-hostname. Delegate to the central guard, which fails CLOSED
        # (require_resolution) and blocks private/loopback/link-local/metadata. The URL is
        # fetched by the Proxmox node, so this SSRF would fire from the PVE management LAN.
        from ProxmoxVEx.utils.url_security import SsrfError, sanitize_outbound_url

        try:
            url = sanitize_outbound_url(url, allowed_schemes=("https", "http"))
        except SsrfError as _ssrf:
            return _api_error("URL rejected by SSRF guard", status=400)

        # Extract filename from URL if not provided
        if not filename:
            from urllib.parse import unquote, urlparse

            parsed = urlparse(url)
            filename = unquote(parsed.path.split("/")[-1]) or "download.iso"

        # Ensure proper extension
        if not any(filename.lower().endswith(ext) for ext in [".iso", ".img", ".qcow2", ".raw"]):
            filename += ".iso"

        host, port = manager.host, manager.api_port

        # Find node if not specified
        if not node:
            nodes_url = f"https://{host}:{port}/api2/json/nodes"
            nodes_response = manager._create_session().get(nodes_url, timeout=5)
            if nodes_response.status_code == 200:
                for n in nodes_response.json().get("data", []):
                    node = n["node"]
                    break

        if not node:
            # lgtm[py/reflected-xss]
            return jsonify({"error": "No node available"}), 400

        # Try using Proxmox's native download-url API (PVE 7.0+)
        download_url = f"https://{host}:{port}/api2/json/nodes/{node}/storage/{storage_name}/download-url"

        download_data = {"url": url, "filename": filename, "content": "iso"}

        # Check if it's HTTPS and might need checksum verification disabled
        if url.startswith("https://"):
            download_data["verify-certificates"] = 0  # Skip SSL verification for downloads

        response = manager._create_session().post(download_url, data=download_data, timeout=30)

        if response.status_code == 200:
            result = response.json()
            upid = result.get("data")

            # Generate task ID for tracking
            task_id = f"dl_{int(time.time())}_{os.urandom(4).hex()}"

            _url_downloads[task_id] = {
                "status": "downloading",
                "percent": 0,
                "message": f"Downloading {filename}...",
                "upid": upid,
                "cluster_id": cluster_id,
                "node": node,
                "filename": filename,
                "started": time.time(),
            }

            # Start background thread to poll Proxmox task status
            def poll_download_status():
                try:
                    while task_id in _url_downloads:
                        task_info = _url_downloads[task_id]
                        if task_info["status"] in ["completed", "error"]:
                            break

                        # Poll Proxmox task status
                        status_url = f"https://{host}:{port}/api2/json/nodes/{node}/tasks/{upid}/status"
                        try:
                            status_resp = manager._create_session().get(status_url, timeout=10)
                            if status_resp.status_code == 200:
                                status_data = status_resp.json().get("data", {})

                                if status_data.get("status") == "stopped":
                                    if status_data.get("exitstatus") == "OK":
                                        _url_downloads[task_id] = {
                                            "status": "completed",
                                            "percent": 100,
                                            "message": f"Download complete: {filename}",
                                        }
                                    else:
                                        _url_downloads[task_id] = {
                                            "status": "error",
                                            "percent": 0,
                                            "message": status_data.get("exitstatus", "Download failed"),
                                        }
                                    break
                                else:
                                    # Still running - try to get progress from task log
                                    log_url = f"https://{host}:{port}/api2/json/nodes/{node}/tasks/{upid}/log"
                                    log_resp = manager._create_session().get(log_url, timeout=10)
                                    if log_resp.status_code == 200:
                                        log_data = log_resp.json().get("data", [])
                                        for entry in reversed(log_data):
                                            text = entry.get("t", "")
                                            # Look for progress percentage in log
                                            import re

                                            match = re.search(r"(\d+(?:\.\d+)?)\s*%", text)
                                            if match:
                                                _url_downloads[task_id]["percent"] = float(match.group(1))
                                                _url_downloads[task_id]["message"] = f"Downloading... {match.group(1)}%"
                                                break
                        except Exception as e:
                            logging.debug(f"Error polling download status: {e}")

                        time.sleep(2)

                    # Cleanup old entries after 5 minutes
                    time.sleep(300)
                    if task_id in _url_downloads:
                        del _url_downloads[task_id]

                except Exception as e:
                    logging.error(f"Error in download status poll: {e}")
                    if task_id in _url_downloads:
                        _url_downloads[task_id] = {"status": "error", "percent": 0, "message": str(e)}

            import threading

            threading.Thread(target=poll_download_status, daemon=True).start()

            user = request.session.get("user", "unknown")
            log_audit(
                user,
                "storage.download",
                f"Started download: {filename} from {url[:50]}...",
                cluster=manager.config.name,
            )

            # lgtm[py/reflected-xss]
            return jsonify({"success": True, "task_id": task_id, "message": f"Download started: {filename}"})
        else:
            # Proxmox API error
            try:
                error_data = response.json()
                error_msg = error_data.get("errors", {})
                if isinstance(error_msg, dict):
                    error_msg = ", ".join(f"{k}: {v}" for k, v in error_msg.items())
                elif not error_msg:
                    error_msg = response.text or "Download failed"
            except Exception as _e:
                error_msg = response.text or "Download failed"

            error_detail = html.escape(str(error_msg))
            return (
                jsonify({"error": f"Proxmox API error: {error_detail}"}),
                response.status_code,
            )

    except Exception as e:
        logging.error(f"Error starting download: {e}")
        return _api_error("Failed to start URL download", status=500)


@bp.route("/api/clusters/<cluster_id>/datastores/<storage_name>/download-status/<task_id>", methods=["GET"])
@require_auth(perms=["storage.upload"])
def get_download_status(cluster_id, storage_name, task_id):
    """Get status of URL download task"""
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()
    if task_id not in _url_downloads:
        # lgtm[py/reflected-xss]
        return jsonify({"status": "unknown", "message": "Task not found"}), 404

    # lgtm[py/reflected-xss]
    return jsonify(_url_downloads[task_id])
