# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/api/vms/__init__.py
# Project:     ProxmoxVEx
# Version:     1.2.535
# Build:       2026.09.26
# Description: VM operations, snapshots, backups, replication &
#              console routes (facade; split from monolith).
# Usage:       import ProxmoxVEx.api.vms
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-26
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""VM operations, snapshots, backups, replication & console routes (facade; split from monolith)."""

from . import (
    backups,  # noqa: F401  # route registration
    bulk,  # noqa: F401  # route registration
    config,  # noqa: F401  # route registration
    console,  # noqa: F401  # route registration
    control,  # noqa: F401  # route registration
    creation,  # noqa: F401  # route registration
    datacenter,  # noqa: F401  # route registration
    datastores,  # noqa: F401  # route registration
    devices,  # noqa: F401  # route registration
    firewall,  # noqa: F401  # route registration
    migration,  # noqa: F401  # route registration
    node_mgmt,  # noqa: F401  # route registration
    passthrough,  # noqa: F401  # route registration
    replication,  # noqa: F401  # route registration
    snapshots,  # noqa: F401  # route registration
    ssh_ws,  # noqa: F401  # route registration
)
from .common import (
    _HOST_RE,
    _WS_FALLBACK_HOST,
    BULK_OPERATIONS_SESSION,
    VNC_PVE_CONNECT_TIMEOUT,
    _access_denied,
    _api_error,
    _apply_vnc_socket_options,
    _cluster_not_connected,
    _cluster_not_found,
    _pve_error,
    _pve_url,
    _require_vm_access,
    _safe_vnc_passthrough,
    _SessionRequest,
    _validate_host,
    bp,
    request,
)
from .console import start_vnc_websocket_server
from .replication import _execute_local_replication, _execute_replication, _wait_for_task
from .ssh_ws import start_ssh_websocket_server

__all__ = (
    "BULK_OPERATIONS_SESSION",
    "VNC_PVE_CONNECT_TIMEOUT",
    "_HOST_RE",
    "_SessionRequest",
    "_WS_FALLBACK_HOST",
    "_access_denied",
    "_api_error",
    "_apply_vnc_socket_options",
    "_cluster_not_connected",
    "_cluster_not_found",
    "_execute_local_replication",
    "_execute_replication",
    "_pve_error",
    "_pve_url",
    "_require_vm_access",
    "_safe_vnc_passthrough",
    "_validate_host",
    "_wait_for_task",
    "bp",
    "request",
    "start_ssh_websocket_server",
    "start_vnc_websocket_server",
)
