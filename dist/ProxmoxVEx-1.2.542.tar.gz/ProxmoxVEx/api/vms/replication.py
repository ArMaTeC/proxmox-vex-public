# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/api/vms/replication.py
# Project:     ProxmoxVEx
# Version:     1.2.535
# Build:       2026.09.26
# Description: replication routes for the vms API (split from
#              api/vms.py).
# Usage:       import ProxmoxVEx.api.vms.replication
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-26
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""replication routes for the vms API (split from api/vms.py)."""

import contextlib
import logging
import threading
import time
import uuid
from datetime import datetime

from flask import g, jsonify

from ProxmoxVEx.api.helpers import check_cluster_access, get_connected_manager
from ProxmoxVEx.core.db import get_db
from ProxmoxVEx.globals import cluster_managers
from ProxmoxVEx.utils.audit import log_audit
from ProxmoxVEx.utils.auth import require_auth

from .common import (
    _access_denied,
    _api_error,
    _cluster_not_connected,
    _cluster_not_found,
    bp,
    request,
)


@bp.route("/api/clusters/<cluster_id>/datacenter/replication", methods=["GET"])
@require_auth(perms=["cluster.view"])
def get_replication_jobs(cluster_id):
    """Get all replication jobs (datacenter-level view)"""
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()
    manager, _ = get_connected_manager(cluster_id)
    if not manager:
        if cluster_id not in cluster_managers:
            return _cluster_not_found()
        return _cluster_not_connected()
    # (#333) - go through manager.get_replication_jobs() which merges
    # per-node runtime data (last_sync/last_try/state/error/fail_count) onto the
    # cluster-level job definitions. The plain /cluster/replication endpoint
    # only returns config so the datacenter view used to show "Last sync = Never"
    # for jobs that were running fine.
    try:
        # lgtm[py/reflected-xss]
        return jsonify(manager.get_replication_jobs())
    except Exception:
        return _api_error("Failed to get replication jobs", status=500)


# ==================== REPLICATION API ROUTES ====================


@bp.route("/api/clusters/<cluster_id>/replication", methods=["GET"])
@require_auth(perms=["cluster.view"])
def get_replication_jobs_api(cluster_id):
    """Get all replication jobs"""
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()
    if cluster_id not in cluster_managers:
        # lgtm[py/reflected-xss]
        return jsonify({"error": "Cluster not found"}), 404

    manager = cluster_managers[cluster_id]
    vmid = request.args.get("vmid", type=int)
    jobs = manager.get_replication_jobs(vmid)
    # lgtm[py/reflected-xss]
    return jsonify(jobs)


@bp.route("/api/clusters/<cluster_id>/replication", methods=["POST"])
@require_auth(perms=["cluster.config"])
def create_replication_job_api(cluster_id):
    """Create a replication job"""
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()
    if cluster_id not in cluster_managers:
        # lgtm[py/reflected-xss]
        return jsonify({"error": "Cluster not found"}), 404

    manager = cluster_managers[cluster_id]
    data = request.json or {}

    vmid = data.get("vmid")
    target_node = data.get("target")
    schedule = data.get("schedule", "*/15")
    rate = data.get("rate")
    comment = data.get("comment", "")

    if not vmid or not target_node:
        # lgtm[py/reflected-xss]
        return jsonify({"error": "vmid and target are required"}), 400

    result = manager.create_replication_job(vmid, target_node, schedule, rate, comment)

    if result["success"]:
        # Audit log
        user = getattr(request, "session", {}).get("user", "system")
        log_audit(
            user,
            "replication.created",
            f"VM {vmid} replication to {target_node} (schedule: {schedule})",
            cluster=manager.config.name,
        )
        # lgtm[py/reflected-xss]
        return jsonify({"message": "Replication Job erstellt", "job_id": result.get("job_id")})
    else:
        # lgtm[py/reflected-xss]
        return jsonify({
            "error": result["error"]
        }), 500  # snyk:ignore:Cross-site Scripting (XSS)  # snyk:ignore:Server Information Exposure


@bp.route("/api/clusters/<cluster_id>/replication/<job_id>", methods=["DELETE"])
@require_auth(perms=["cluster.config"])
def delete_replication_job_api(cluster_id, job_id):
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()

    if cluster_id not in cluster_managers:
        # lgtm[py/reflected-xss]
        return jsonify({"error": "Cluster not found"}), 404

    manager = cluster_managers[cluster_id]
    data = request.json or {}
    keep = data.get("keep", False)
    force = data.get("force", False)

    result = manager.delete_replication_job(job_id, keep, force)

    if result["success"]:
        # Audit log
        user = getattr(request, "session", {}).get("user", "system")
        log_audit(user, "replication.deleted", f"Replication job {job_id} deleted", cluster=manager.config.name)
        # lgtm[py/reflected-xss]
        return jsonify({"message": "Replication Job deleted"})
    else:
        # lgtm[py/reflected-xss]
        return jsonify({
            "error": result["error"]
        }), 500  # snyk:ignore:Cross-site Scripting (XSS)  # snyk:ignore:Server Information Exposure


@bp.route("/api/clusters/<cluster_id>/replication/<job_id>/run", methods=["POST"])
@require_auth(perms=["cluster.config"])
def run_replication_now_api(cluster_id, job_id):
    """Trigger immediate replication"""
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()
    if cluster_id not in cluster_managers:
        # lgtm[py/reflected-xss]
        return jsonify({"error": "Cluster not found"}), 404

    manager = cluster_managers[cluster_id]
    result = manager.run_replication_now(job_id)

    if result["success"]:
        # Audit log
        user = getattr(request, "session", {}).get("user", "system")
        log_audit(
            user, "replication.triggered", f"Replication job {job_id} manually triggered", cluster=manager.config.name
        )
        # lgtm[py/reflected-xss]
        return jsonify({"message": "Replication gestartet"})
    else:
        # lgtm[py/reflected-xss]
        return jsonify({
            "error": result["error"]
        }), 500  # snyk:ignore:Cross-site Scripting (XSS)  # snyk:ignore:Server Information Exposure


def _resolve_vm_node(mgr, vmid, vm_type="qemu"):
    """Authoritatively locate which node a VMID lives on by probing each node's
    status endpoint directly. /cluster/resources is fed by pmxcfs and lags by
    several seconds — right after a migrate it can still point at the old node,
    which is fatal for a destructive op (we'd delete the wrong/empty side and
    leave the real replica behind). Returns (node, info_dict) or (None, None).
    (#552)."""
    try:
        nresp = mgr._api_get(f"https://{mgr.host}:{mgr.api_port}/api2/json/nodes")
        nodes = [n.get("node") for n in nresp.json().get("data", [])] if nresp.status_code == 200 else []
    except Exception as _e:
        nodes = []
    for node in nodes:
        if not node:
            continue
        try:
            r = mgr._api_get(
                f"https://{mgr.host}:{mgr.api_port}/api2/json/nodes/{node}/{vm_type}/{vmid}/status/current"
            )
            if r.status_code == 200:
                info = r.json().get("data", {}) or {}
                info["node"] = node
                # lgtm[py/reflected-xss]
                return (node, info)
        except Exception as _e:
            continue
    # lgtm[py/reflected-xss]
    return (None, None)


def _free_local_target_vmid(mgr, tgt_vmid, src_vmid, vm_type, target_node):
    """For a pinned local-replication target VMID: if a VM already sits on it,
    remove it ONLY when it is EXACTLY this job's prior replica — the name ProxmoxVEx
    writes is `repl-<src>-<target_node>` (clone_label), so match that exactly rather
    than a loose prefix. Refuse to touch anything else so we never clobber an
    unrelated VM. Returns (ok, error_message). #552 (exact-match hardening sec-review)
    """
    try:
        node, existing = _resolve_vm_node(mgr, tgt_vmid, vm_type)
        if not existing:
            # lgtm[py/reflected-xss]
            return (True, "")  # free, go ahead

        vname = existing.get("name", "") or ""
        if vname != f"repl-{src_vmid}-{target_node}":
            # lgtm[py/reflected-xss]
            return (
                False,
                (
                    f'Target VMID {tgt_vmid} is in use by "{vname or "unknown"}" which is not a '
                    f"replica of VM {src_vmid}. Pick a free VMID or remove that VM first."
                ),
            )

        # it's our old replica — stop (if running) and delete
        if existing.get("status") == "running":
            try:
                mgr._api_post(
                    f"https://{mgr.host}:{mgr.api_port}/api2/json/nodes/{node}/{vm_type}/{tgt_vmid}/status/stop",
                    data={},
                )
                time.sleep(5)
            except Exception as _e:
                pass
        del_resp = mgr._api_delete(
            f"https://{mgr.host}:{mgr.api_port}/api2/json/nodes/{node}/{vm_type}/{tgt_vmid}",
            params={"purge": 1, "destroy-unreferenced-disks": 1},
        )
        if del_resp.status_code != 200:
            # lgtm[py/reflected-xss]
            return (False, f"Could not remove old replica {tgt_vmid}: {del_resp.text[:200]}")
        del_task = del_resp.json().get("data")
        if del_task:
            ok, detail = _wait_for_task(mgr, del_task, timeout=600)
            if not ok:
                # lgtm[py/reflected-xss]
                return (False, f"Delete of old replica {tgt_vmid} failed: {detail}")
        logging.info(f"[REPL] Freed pinned target VMID {tgt_vmid} (old replica '{vname}' removed)")
        # lgtm[py/reflected-xss]
        return (True, "")
    except Exception:
        logging.exception("Error freeing target VMID %s", tgt_vmid)
        # lgtm[py/reflected-xss]
        return (False, f"Error freeing target VMID {tgt_vmid}")


def _execute_local_replication(job):
    """Run snapshot-based replication within the same cluster (no ZFS needed)."""
    db = get_db()
    job_id = job["id"]
    vmid = int(job["vmid"])
    vm_type = job.get("vm_type", "qemu") or "qemu"
    cluster_id = job["source_cluster"]
    target_node = job.get("target_node", "")
    target_storage = job.get("target_storage", "") or "local-lvm"

    mgr = cluster_managers.get(cluster_id)
    if not mgr:
        _update_repl_status(db, job_id, "error", "Cluster not found")
        return

    if not mgr.is_connected:
        _update_repl_status(db, job_id, "error", "Cluster not connected")
        return

    snap_name = f"repl-{job_id}-{int(time.time())}"
    clone_vmid = None
    source_node = None

    try:
        # 1. find source node
        res = mgr._api_get(f"https://{mgr.host}:{mgr.api_port}/api2/json/cluster/resources", params={"type": "vm"})
        if res.status_code == 200:
            for r in res.json().get("data", []):
                if int(r.get("vmid", 0)) == vmid:
                    source_node = r.get("node")
                    break

        if not source_node:
            _update_repl_status(db, job_id, "error", f"VM {vmid} not found")
            return

        if not target_node:
            _update_repl_status(db, job_id, "error", "No target node configured")
            return

        logging.info(f"[REPL] Job {job_id}: replicating {vm_type}/{vmid} from {source_node} to {target_node}")

        # 2. create snapshot
        snap_url = f"https://{mgr.host}:{mgr.api_port}/api2/json/nodes/{source_node}/{vm_type}/{vmid}/snapshot"
        snap_resp = mgr._api_post(
            snap_url, data={"snapname": snap_name, "description": f"Snapshot replication {job_id}"}
        )
        if snap_resp.status_code != 200:
            _update_repl_status(db, job_id, "error", f"Snapshot failed: {snap_resp.text}")
            return

        snap_task = snap_resp.json().get("data")
        snap_ok, snap_detail = _wait_for_task(mgr, snap_task)
        if not snap_ok:
            _update_repl_status(db, job_id, "error", f"Snapshot failed: {snap_detail}")
            return

        # 3. pick the replica VMID
        # #552 - if the operator pinned a target VMID, reuse it every run (so the
        # replica keeps a stable ID) instead of leaking a fresh nextid each time.
        # A pinned ID means last run's replica is sitting on it -> clear it first,
        # but only if it's actually one of ours (name-matched, never a foreign VM).
        tgt_vmid = int(job.get("target_vmid") or 0)
        if tgt_vmid:
            freed, free_err = _free_local_target_vmid(mgr, tgt_vmid, vmid, vm_type, target_node)
            if not freed:
                _cleanup_snapshot(mgr, source_node, vmid, vm_type, snap_name)
                _update_repl_status(db, job_id, "error", free_err)
                return
            clone_vmid = tgt_vmid
        else:
            nextid_resp = mgr._api_get(f"https://{mgr.host}:{mgr.api_port}/api2/json/cluster/nextid")
            if nextid_resp.status_code != 200:
                _cleanup_snapshot(mgr, source_node, vmid, vm_type, snap_name)
                _update_repl_status(db, job_id, "error", "Could not get next VMID")
                return
            clone_vmid = int(nextid_resp.json().get("data"))

        # 4. clone — check storage type for snapshot compatibility (#192)
        clone_url = f"https://{mgr.host}:{mgr.api_port}/api2/json/nodes/{source_node}/{vm_type}/{vmid}/clone"
        # Verified against PVE storage plugins (copy+snap feature matrix)
        # rbd DOES support snap clone. lvm only supports qcow2 snap clone (VMs are raw).
        # zfs (iSCSI) and zfspool (local) both lack snap support. LXC uses rsync, not affected.
        _no_snap_clone_types = {"zfspool", "zfs", "lvm", "iscsi", "iscsidirect"}
        use_snap_clone = True
        try:
            stor_resp = mgr._api_get(f"https://{mgr.host}:{mgr.api_port}/api2/json/storage")
            if stor_resp.status_code == 200:
                stor_types = {s["storage"]: s.get("type", "") for s in stor_resp.json().get("data", [])}
                vm_stor = mgr._get_vm_storage(source_node, vmid, vm_type)
                if vm_type == "qemu" and vm_stor and stor_types.get(vm_stor) in _no_snap_clone_types:
                    use_snap_clone = False
                    logging.info(f"[REPL] Storage '{vm_stor}' is {stor_types.get(vm_stor)} — direct clone (#192)")
        except Exception as _e:
            pass

        # (#448) - same hostname-vs-name fix as the xcrepl path.
        # annotate as plain dict — hostname/name/snapname/storage keys below
        # are strings, so the inferred dict[str, int] is too narrow
        clone_data: dict = {
            "newid": clone_vmid,
            "full": 1,
        }
        clone_label = f"repl-{vmid}-{target_node}"
        if vm_type == "lxc":
            clone_data["hostname"] = clone_label
        else:
            clone_data["name"] = clone_label
        if use_snap_clone:
            clone_data["snapname"] = snap_name
        if target_storage:
            clone_data["storage"] = target_storage

        clone_resp = mgr._api_post(clone_url, data=clone_data)
        if clone_resp.status_code != 200:
            _cleanup_snapshot(mgr, source_node, vmid, vm_type, snap_name)
            _update_repl_status(db, job_id, "error", f"Clone failed: {clone_resp.text}")
            return

        clone_task = clone_resp.json().get("data")
        clone_ok, clone_detail = _wait_for_task(mgr, clone_task, timeout=1800)
        if not clone_ok:
            _cleanup_snapshot(mgr, source_node, vmid, vm_type, snap_name)
            _update_repl_status(db, job_id, "error", f"Clone failed: {clone_detail}")
            return

        logging.info(f"[REPL] Job {job_id}: clone {clone_vmid} created")

        # 5. migrate clone to target node (if on different node)
        if source_node != target_node:
            mig_result = mgr.migrate_vm_manual(
                node=source_node,
                vmid=clone_vmid,
                vm_type=vm_type,
                target_node=target_node,
                online=False,
                options={"targetstorage": target_storage} if target_storage else {},
            )
            if not mig_result.get("success"):
                # cleanup clone + snap
                _cleanup_clone_and_snap(mgr, source_node, clone_vmid, vmid, vm_type, snap_name)
                _update_repl_status(db, job_id, "error", f"Migration failed: {mig_result.get('error')}")
                return

            mig_task = mig_result.get("task")
            if mig_task:
                mig_ok, mig_detail = _wait_for_task(mgr, mig_task, timeout=3600)
                if not mig_ok:
                    _cleanup_clone_and_snap(mgr, source_node, clone_vmid, vmid, vm_type, snap_name)
                    _update_repl_status(db, job_id, "error", f"Migration failed: {mig_detail}")
                    return

        logging.info(f"[REPL] Job {job_id}: clone migrated to {target_node}")

        # 6. delete old replica if exists, rename new one
        # check for previous replica VMs with name pattern repl-{vmid}-{target_node}
        try:
            all_vms = mgr._api_get(
                f"https://{mgr.host}:{mgr.api_port}/api2/json/cluster/resources", params={"type": "vm"}
            )
            if all_vms.status_code == 200:
                for v in all_vms.json().get("data", []):
                    vname = v.get("name", "")
                    vid = int(v.get("vmid", 0))
                    # delete previous replicas but not the one we just created
                    if vname == f"repl-{vmid}-{target_node}" and vid != clone_vmid:
                        old_node = v.get("node", target_node)
                        try:
                            # stop if running
                            if v.get("status") == "running":
                                mgr._api_post(
                                    f"https://{mgr.host}:{mgr.api_port}/api2/json/nodes/{old_node}/{vm_type}/{vid}/status/stop",
                                    data={},
                                )
                                time.sleep(5)
                            mgr._api_delete(
                                f"https://{mgr.host}:{mgr.api_port}/api2/json/nodes/{old_node}/{vm_type}/{vid}"
                            )
                            logging.info(f"[REPL] Deleted old replica VM {vid}")
                        except Exception as del_e:
                            logging.warning(f"[REPL] Could not delete old replica {vid}: {del_e}")
        except Exception as _e:
            pass

        # 7. cleanup snapshot on source
        _cleanup_snapshot(mgr, source_node, vmid, vm_type, snap_name)
        _update_repl_status(db, job_id, "ok", "")
        logging.info(f"[REPL] Job {job_id}: replication complete")

    except Exception as e:
        logging.error(f"[REPL] Job {job_id}: error: {e}")
        _update_repl_status(db, job_id, "error", str(e))
        if clone_vmid:
            with contextlib.suppress(Exception):
                _cleanup_clone_and_snap(mgr, source_node, clone_vmid, vmid, vm_type, snap_name)


# Snapshot-based replication between clusters
# Proxmox native replication only works intra-cluster, so for DR across
# separate clusters we use snapshot + clone + remote-migrate approach.

# (#456 @DarmokNoob) - net interface MAC tokens vary by VM type:
# LXC uses `hwaddr=<mac>`, QEMU uses `<model>=<mac>` where model is virtio/e1000/etc.
_QEMU_NIC_MODELS = (
    "virtio",
    "e1000",
    "e1000-82540em",
    "e1000-82544gc",
    "e1000-82545em",
    "e1000e",
    "i82551",
    "i82557b",
    "i82559er",
    "ne2k_isa",
    "ne2k_pci",
    "pcnet",
    "rtl8139",
    "vmxnet3",
)


def _extract_nic_mac(nic_value):
    """Return the MAC from a PVE net interface config string (or None)."""
    if not isinstance(nic_value, str):
        # lgtm[py/reflected-xss]
        return None
    for part in nic_value.split(","):
        if "=" not in part:
            continue
        key, val = part.split("=", 1)
        if key == "hwaddr":
            # lgtm[py/reflected-xss]
            return val
        if key in _QEMU_NIC_MODELS:
            # lgtm[py/reflected-xss]
            return val
    # lgtm[py/reflected-xss]
    return None


def _swap_nic_mac(nic_value, new_mac):
    """Rewrite a PVE net interface config to use new_mac, preserving every other token."""
    if not isinstance(nic_value, str) or not new_mac:
        # lgtm[py/reflected-xss]
        return nic_value
    parts = []
    replaced = False
    for part in nic_value.split(","):
        if "=" not in part:
            parts.append(part)
            continue
        key, val = part.split("=", 1)
        if key == "hwaddr":
            parts.append(f"hwaddr={new_mac}")
            replaced = True
        elif key in _QEMU_NIC_MODELS:
            parts.append(f"{key}={new_mac}")
            replaced = True
        else:
            parts.append(part)
    # lgtm[py/reflected-xss]
    return ",".join(parts) if replaced else nic_value


def _capture_vm_identity(mgr, node, vmid, vm_type):
    """Pull hostname/name + per-NIC MAC from a VM's config so the xcrepl flow can
    restore them on the target replica after clone+migrate destroyed both."""
    out = {"hostname": None, "name": None, "nets": {}}
    try:
        cfg_url = f"https://{mgr.host}:{mgr.api_port}/api2/json/nodes/{node}/{vm_type}/{vmid}/config"
        resp = mgr._api_get(cfg_url)
        if resp.status_code != 200:
            logging.debug(f"[XCREPL] _capture_vm_identity: GET {cfg_url} -> {resp.status_code}")
            # lgtm[py/reflected-xss]
            return out
        cfg = resp.json().get("data", {})
        if vm_type == "lxc":
            out["hostname"] = cfg.get("hostname")
        else:
            out["name"] = cfg.get("name")
        for k, v in cfg.items():
            if k.startswith("net") and k[3:].isdigit():
                mac = _extract_nic_mac(v)
                if mac:
                    out["nets"][k] = mac
    except Exception as e:
        logging.debug(f"[XCREPL] _capture_vm_identity error: {e}")
    # lgtm[py/reflected-xss]
    return out


def _restore_vm_identity(mgr, node, vmid, vm_type, identity):
    """Apply the source's hostname/name + per-NIC MAC to a freshly-migrated replica.

    Reads the target's current net config so we preserve bridge / firewall / VLAN-tag /
    rate-limit tokens that the migration set — only the MAC token gets swapped back to
    the source value.
    """
    if not identity:
        return
    cfg_url = f"https://{mgr.host}:{mgr.api_port}/api2/json/nodes/{node}/{vm_type}/{vmid}/config"
    payload = {}

    if vm_type == "lxc" and identity.get("hostname"):
        payload["hostname"] = identity["hostname"]
    elif vm_type == "qemu" and identity.get("name"):
        payload["name"] = identity["name"]

    if identity.get("nets"):
        try:
            cur_resp = mgr._api_get(cfg_url)
            if cur_resp.status_code == 200:
                cur_cfg = cur_resp.json().get("data", {})
                for netname, src_mac in identity["nets"].items():
                    cur_val = cur_cfg.get(netname)
                    if cur_val:
                        rebuilt = _swap_nic_mac(cur_val, src_mac)
                        if rebuilt != cur_val:
                            payload[netname] = rebuilt
        except Exception as e:
            logging.debug(f"[XCREPL] could not read target config for MAC restore: {e}")

    if not payload:
        return

    put_resp = mgr._api_put(cfg_url, data=payload)
    if put_resp.status_code == 200:
        logging.info(
            f"[XCREPL] Restored identity on {vm_type}/{vmid}: "
            f"{'hostname' if vm_type == 'lxc' else 'name'}={payload.get('hostname') or payload.get('name')}, "
            f"{sum(1 for k in payload if k.startswith('net'))} NIC(s) MAC-swapped"
        )
    else:
        logging.warning(f"[XCREPL] Identity PUT returned {put_resp.status_code}: {put_resp.text[:200]}")


# (#413 @blackshocks) - Replica safety gate. The earlier xcrepl flow
# deleted any VM on the target that happened to share the source VMID, on the
# assumption that the VMID-collision had to be a previous run of this same job.
# Real-world scenario: two freshly-paired clusters where the target already had
# an UNRELATED VM at the same VMID — the delete destroyed user data.
#
# Replicas are now tagged with a job-specific marker after a successful migration,
# and the safety gate refuses to delete anything that isn't tagged for THIS job.
# That also prevents cross-job blast: two unrelated xcrepl jobs colliding on the
# same target VMID won't nuke each other's replicas.
ProxmoxVEx_REPLICA_TAG = "ProxmoxVEx-replica"


def _job_tag(job_id):
    # lgtm[py/reflected-xss]
    return f"xcrepl-job-{job_id}"


def _read_target_tags(mgr, node, vmid, vm_type):
    """Return the set of tags on a VM, or None if config fetch failed."""
    try:
        cfg_url = f"https://{mgr.host}:{mgr.api_port}/api2/json/nodes/{node}/{vm_type}/{vmid}/config"
        resp = mgr._api_get(cfg_url)
        if resp.status_code != 200:
            # lgtm[py/reflected-xss]
            return None
        cfg = resp.json().get("data", {})
        tags_raw = cfg.get("tags", "") or ""
        # PVE separates tags by ';' for both LXC and QEMU.
        # lgtm[py/reflected-xss]
        return {t.strip() for t in tags_raw.split(";") if t.strip()}
    except Exception as _e:
        # lgtm[py/reflected-xss]
        return None


def _is_replica_of_job(mgr, node, vmid, vm_type, job_id):
    """True iff the target VM is tagged as a replica of THIS specific xcrepl job."""
    tags = _read_target_tags(mgr, node, vmid, vm_type)
    if tags is None:
        # lgtm[py/reflected-xss]
        return False
    # lgtm[py/reflected-xss]
    return _job_tag(job_id) in tags


def _tag_as_replica(mgr, node, vmid, vm_type, job_id):
    """Mark the freshly-migrated replica with the job-specific + general
    ProxmoxVEx-replica tags. Preserves any pre-existing tags so users' own
    organisation tags stay intact."""
    cfg_url = f"https://{mgr.host}:{mgr.api_port}/api2/json/nodes/{node}/{vm_type}/{vmid}/config"
    try:
        resp = mgr._api_get(cfg_url)
        if resp.status_code != 200:
            return
        cfg = resp.json().get("data", {})
        tags_raw = cfg.get("tags", "") or ""
        existing = [t.strip() for t in tags_raw.split(";") if t.strip()]
        want = [ProxmoxVEx_REPLICA_TAG, _job_tag(job_id)]
        merged = list(existing)
        for t in want:
            if t not in merged:
                merged.append(t)
        if merged == existing:
            # lgtm[py/reflected-xss]
            return  # nothing to do
        new_tags = ";".join(merged)
        put = mgr._api_put(cfg_url, data={"tags": new_tags})
        if put.status_code == 200:
            logging.info(f"[XCREPL] Tagged replica {vm_type}/{vmid} on {node} with {want}")
        else:
            logging.warning(f"[XCREPL] tag PUT returned {put.status_code}: {put.text[:200]}")
    except Exception as e:
        logging.warning(f"[XCREPL] Could not tag replica {vmid}: {e}")


def _execute_replication(job):
    """
    Run a single cross-cluster replication cycle for one job.

    Steps: snapshot source VM -> clone from snapshot -> remote-migrate clone
    to target cluster -> cleanup snapshot + clone on source.

    This is basically the same flow as manual cross-cluster migration,
    but we snapshot first so the source VM stays untouched. The clone gets
    migrated and then deleted on the source side.
    """
    db = get_db()
    job_id = job["id"]
    vmid = int(job["vmid"])
    vm_type = job.get("vm_type", "qemu") or "qemu"
    source_cid = job["source_cluster"]
    target_cid = job["target_cluster"]
    target_storage = job.get("target_storage", "") or "local-lvm"
    target_bridge = job.get("target_bridge", "vmbr0") or "vmbr0"
    target_node = job.get("target_node", "")
    # #552 - replica VMID is operator-pinned if set, else mirror the source VMID
    # (PVE remote-migrate still needs an explicit target-vmid either way).
    tgt_vmid = int(job.get("target_vmid") or 0) or vmid

    source_mgr = cluster_managers.get(source_cid)
    target_mgr = cluster_managers.get(target_cid)

    if not source_mgr or not target_mgr:
        _update_repl_status(db, job_id, "error", "Source or target cluster not found")
        return

    if not source_mgr.is_connected or not target_mgr.is_connected:
        _update_repl_status(db, job_id, "error", "Cluster not connected")
        return

    # Auto-detect target node if not configured
    if not target_node:
        try:
            nodes_resp = target_mgr._api_get(f"https://{target_mgr.host}:{target_mgr.api_port}/api2/json/nodes")
            if nodes_resp.status_code == 200:
                for n in nodes_resp.json().get("data", []):
                    if n.get("status") == "online":
                        target_node = n["node"]
                        break
        except Exception as _e:
            pass
        if not target_node:
            _update_repl_status(db, job_id, "error", "No online node found on target cluster")
            return

    snap_name = f"xcrepl-{job_id}-{int(time.time())}"
    clone_vmid = None
    # bound before the try so the outer except's best-effort cleanup can
    # reference it even if the resources call raises first
    source_node = None

    try:
        # 1. find which node the VM lives on
        resources = source_mgr._api_get(
            f"https://{source_mgr.host}:{source_mgr.api_port}/api2/json/cluster/resources", params={"type": "vm"}
        )
        if resources.status_code == 200:
            for r in resources.json().get("data", []):
                if int(r.get("vmid", 0)) == vmid:
                    source_node = r.get("node")
                    break

        if not source_node:
            _update_repl_status(db, job_id, "error", f"VM {vmid} not found on source cluster")
            return

        logging.info(
            f"[XCREPL] Job {job_id}: replicating {vm_type}/{vmid} from {source_node} -> {target_node} ({target_cid})"
        )

        # (#456 @DarmokNoob) - capture source identity (hostname/name +
        # per-NIC hwaddr) BEFORE the clone overwrites the label and PVE re-rolls the MAC.
        # Replica is supposed to be a drop-in copy of the source for DR — the replica's
        # hostname + DHCP-MAC need to match or Site Recovery failover lands on the wrong
        # network identity.
        source_identity = _capture_vm_identity(source_mgr, source_node, vmid, vm_type)

        # 2. create snapshot
        snap_url = (
            f"https://{source_mgr.host}:{source_mgr.api_port}/api2/json/nodes/{source_node}/{vm_type}/{vmid}/snapshot"
        )
        snap_resp = source_mgr._api_post(
            snap_url, data={"snapname": snap_name, "description": f"Cross-cluster replication {job_id}"}
        )
        if snap_resp.status_code != 200:
            _update_repl_status(db, job_id, "error", f"Snapshot failed: {snap_resp.text}")
            return

        snap_task = snap_resp.json().get("data")
        snap_ok, snap_detail = _wait_for_task(source_mgr, snap_task)
        if not snap_ok:
            _update_repl_status(db, job_id, "error", f"Snapshot failed: {snap_detail}")
            return

        logging.info(f"[XCREPL] Job {job_id}: snapshot '{snap_name}' created")

        # 3. get next free VMID for clone
        nextid_resp = source_mgr._api_get(f"https://{source_mgr.host}:{source_mgr.api_port}/api2/json/cluster/nextid")
        if nextid_resp.status_code != 200:
            _cleanup_snapshot(source_mgr, source_node, vmid, vm_type, snap_name)
            _update_repl_status(db, job_id, "error", "Could not get next VMID")
            return

        clone_vmid = int(nextid_resp.json().get("data"))
        logging.debug(f"[XCREPL] Using clone VMID {clone_vmid}")

        # 4. clone — detect storage type first to choose correct strategy (#192)
        # ZFS and RBD don't support full clone from snapshot, must clone directly
        clone_url = (
            f"https://{source_mgr.host}:{source_mgr.api_port}/api2/json/nodes/{source_node}/{vm_type}/{vmid}/clone"
        )
        # Check if storage supports full clone from snapshot
        # Verified against PVE storage plugins (copy+snap feature matrix)
        # rbd DOES support snap clone. lvm only supports qcow2 snap clone (VMs are raw).
        # zfs (iSCSI) and zfspool (local) both lack snap support. LXC uses rsync, not affected.
        _no_snap_clone_types = {"zfspool", "zfs", "lvm", "iscsi", "iscsidirect"}
        use_snap_clone = True
        try:
            stor_resp = source_mgr._api_get(f"https://{source_mgr.host}:{source_mgr.api_port}/api2/json/storage")
            if stor_resp.status_code == 200:
                stor_types = {s["storage"]: s.get("type", "") for s in stor_resp.json().get("data", [])}
                # get the VM's primary storage
                vm_stor = source_mgr._get_vm_storage(source_node, vmid, vm_type)
                if vm_type == "qemu" and vm_stor and stor_types.get(vm_stor) in _no_snap_clone_types:
                    use_snap_clone = False
                    logging.info(
                        f"[XCREPL] Storage '{vm_stor}' is {stor_types.get(vm_stor)} — using direct clone without snapshot (#192)"
                    )
        except Exception as e:
            logging.debug(f"[XCREPL] Could not detect storage type: {e}")

        # (#448 @DarmokNoob) - PVE clone schema differs by VM type:
        # QEMU (`/qemu/{vmid}/clone`) accepts `name=` for the clone label;
        # LXC  (`/lxc/{vmid}/clone`)  rejects `name=` as "property is not
        # defined in schema" and wants `hostname=` instead. Confirmed via
        # pvesh + curl by the reporter. Earlier this function always sent
        # `name`, so every cross-cluster LXC DR job 400'd at the clone step.
        # annotate as plain dict — hostname/name/snapname keys below are
        # strings, so the inferred dict[str, int] is too narrow
        clone_data: dict = {
            "newid": clone_vmid,
            "full": 1,
        }
        clone_label = f"xcrepl-{vmid}-tmp"
        if vm_type == "lxc":
            clone_data["hostname"] = clone_label
        else:
            clone_data["name"] = clone_label
        if use_snap_clone:
            clone_data["snapname"] = snap_name

        clone_resp = source_mgr._api_post(clone_url, data=clone_data)
        if clone_resp.status_code != 200:
            _cleanup_snapshot(source_mgr, source_node, vmid, vm_type, snap_name)
            _update_repl_status(db, job_id, "error", f"Clone failed: {clone_resp.text}")
            return

        clone_task = clone_resp.json().get("data")
        clone_ok, clone_detail = _wait_for_task(source_mgr, clone_task, timeout=1800)
        if not clone_ok:
            _cleanup_snapshot(source_mgr, source_node, vmid, vm_type, snap_name)
            _update_repl_status(db, job_id, "error", f"Clone failed: {clone_detail}")
            return

        logging.info(f"[XCREPL] Job {job_id}: clone {clone_vmid} created from snapshot")

        # 5. build storage mapping from clone's actual disks -> target storage
        # Mar 2026: PVE remote_migrate needs "source_stor:target_stor" format
        # when source and target storage names differ (#192)
        storage_mapping = target_storage  # fallback: plain name
        try:
            cfg_url = f"https://{source_mgr.host}:{source_mgr.api_port}/api2/json/nodes/{source_node}/{vm_type}/{clone_vmid}/config"
            cfg_resp = source_mgr._api_get(cfg_url)
            if cfg_resp.status_code == 200:
                clone_cfg = cfg_resp.json().get("data", {})
                source_storages = set()
                for k, v in clone_cfg.items():
                    if (
                        k.startswith(("scsi", "virtio", "ide", "sata", "efidisk", "tpmstate", "rootfs", "mp"))
                        and isinstance(v, str)
                        and ":" in v
                    ):
                        stor = v.split(":")[0]
                        if stor and stor != "none":
                            source_storages.add(stor)
                if source_storages:
                    # map each source storage to the target
                    mappings = [f"{s}:{target_storage}" for s in source_storages]
                    storage_mapping = ",".join(mappings)
                    logging.info(f"[XCREPL] Job {job_id}: storage mapping: {storage_mapping}")
        except Exception as e:
            logging.warning(f"[XCREPL] Job {job_id}: could not build storage mapping, using plain: {e}")

        # remote-migrate clone to target cluster
        # same token/fingerprint flow as cross_cluster_lb.py
        token_name = f"xcrepl-{job_id}-{int(time.time()) % 100000}"
        token = target_mgr.create_api_token(token_name)
        if not token.get("success"):
            _cleanup_clone_and_snap(source_mgr, source_node, clone_vmid, vmid, vm_type, snap_name)
            _update_repl_status(db, job_id, "error", f"Token creation failed: {token.get('error')}")
            return

        try:
            fp = target_mgr.get_cluster_fingerprint()
            if not fp.get("success"):
                target_mgr.delete_api_token(token_name)
                _cleanup_clone_and_snap(source_mgr, source_node, clone_vmid, vmid, vm_type, snap_name)
                _update_repl_status(db, job_id, "error", f"Fingerprint failed: {fp.get('error')}")
                return

            endpoint = (
                f"apitoken=PVEAPIToken={token['token_id']}={token['token_value']},"
                f"host={fp['host']},fingerprint={fp['fingerprint']}"
            )

            # Apr 2026: #321 - second+ replication run fails because VM exists on target.
            # A replication job's whole point is to REPLACE the old copy, so remove it here
            # before remote_migrate tries to create-from-empty (which errors on existing VMID).
            existing_target_node = None
            try:
                tgt_res = target_mgr._api_get(
                    f"https://{target_mgr.host}:{target_mgr.api_port}/api2/json/cluster/resources",
                    params={"type": "vm"},
                )
                if tgt_res.status_code == 200:
                    for r in tgt_res.json().get("data", []):
                        if int(r.get("vmid", 0)) == tgt_vmid:
                            existing_target_node = r.get("node")
                            break
            except Exception as e:
                logging.warning(f"[XCREPL] Job {job_id}: target existence check failed: {e}")

            if existing_target_node:
                # (#413 @blackshocks) - refuse to delete unless the existing
                # target VM is tagged as a replica of THIS job. Without this gate, freshly
                # paired clusters with an unrelated VM at the matching VMID lose data.
                if not _is_replica_of_job(target_mgr, existing_target_node, tgt_vmid, vm_type, job_id):
                    target_mgr.delete_api_token(token_name)
                    _cleanup_clone_and_snap(source_mgr, source_node, clone_vmid, vmid, vm_type, snap_name)
                    err_msg = (
                        f"Target VM {tgt_vmid} on node {existing_target_node} is not tagged as a replica "
                        f"of this job ({_job_tag(job_id)} tag missing). Refusing to overwrite to "
                        f"prevent data loss. If this is a stranded replica from a previous run or "
                        f"manual clone, tag it with `{_job_tag(job_id)}` and re-run. If it is an "
                        f"unrelated VM, pick a different target VMID for the job."
                    )
                    _update_repl_status(db, job_id, "error", err_msg)
                    logging.error(f"[XCREPL] Job {job_id}: ABORT — {err_msg}")
                    return

                logging.info(
                    f"[XCREPL] Job {job_id}: VM {tgt_vmid} already on target node {existing_target_node}, removing old replica (tag verified)"
                )
                try:
                    # stop first so PVE lets us delete it (ignore errors if already stopped)
                    stop_url = (
                        f"https://{target_mgr.host}:{target_mgr.api_port}/api2/json/nodes/{existing_target_node}"
                        f"/{vm_type}/{tgt_vmid}/status/stop"
                    )
                    try:
                        stop_resp = target_mgr._api_post(stop_url, data={})
                        if stop_resp.status_code == 200:
                            stop_task = stop_resp.json().get("data")
                            if stop_task:
                                _wait_for_task(target_mgr, stop_task, timeout=60)
                    except Exception as _e:
                        pass

                    # delete the VM and its disks (purge removes replication jobs, destroy removes unreferenced disks)
                    del_url = (
                        f"https://{target_mgr.host}:{target_mgr.api_port}/api2/json/nodes/{existing_target_node}"
                        f"/{vm_type}/{tgt_vmid}"
                    )
                    del_resp = target_mgr._api_delete(del_url, params={"purge": 1, "destroy-unreferenced-disks": 1})
                    if del_resp.status_code == 200:
                        del_task = del_resp.json().get("data")
                        if del_task:
                            del_ok, del_detail = _wait_for_task(target_mgr, del_task, timeout=600)
                            if not del_ok:
                                raise RuntimeError(f"delete task failed: {del_detail}")
                        logging.info(f"[XCREPL] Job {job_id}: old replica {tgt_vmid} removed from target")
                    else:
                        raise RuntimeError(f"delete request failed: {del_resp.status_code} {del_resp.text[:200]}")
                except Exception as e:
                    logging.error(f"[XCREPL] Job {job_id}: could not remove old replica: {e}")
                    target_mgr.delete_api_token(token_name)
                    _cleanup_clone_and_snap(source_mgr, source_node, clone_vmid, vmid, vm_type, snap_name)
                    _update_repl_status(db, job_id, "error", f"Could not remove old replica on target: {e}")
                    return

            # migrate the clone (offline, delete source clone after)
            result = source_mgr.remote_migrate_vm(
                node=source_node,
                vmid=clone_vmid,
                vm_type=vm_type,
                target_endpoint=endpoint,
                target_storage=storage_mapping,
                target_bridge=target_bridge,
                target_vmid=tgt_vmid,
                online=False,
                delete_source=True,
            )

            if result.get("success"):
                mig_task = result.get("task")
                mig_ok, mig_detail = _wait_for_task(source_mgr, mig_task, timeout=3600)
                if mig_ok:
                    logging.info(f"[XCREPL] Job {job_id}: migration complete")
                    # (#456) - restore source identity on the replica so
                    # DR failover lands on the right hostname + DHCP-MAC. Best-effort
                    # don't fail the whole replication if this trips.
                    try:
                        _restore_vm_identity(target_mgr, target_node, tgt_vmid, vm_type, source_identity)
                    except Exception as e:
                        logging.warning(f"[XCREPL] Job {job_id}: identity restoration failed: {e}")
                    # (#413) - tag the replica so the safety gate on the next
                    # run recognises it as ours and can cycle it without operator action.
                    try:
                        _tag_as_replica(target_mgr, target_node, tgt_vmid, vm_type, job_id)
                    except Exception as e:
                        logging.warning(f"[XCREPL] Job {job_id}: replica-tag write failed: {e}")
                    _update_repl_status(db, job_id, "ok", "")
                else:
                    logging.error(f"[XCREPL] Job {job_id}: migration task failed: {mig_detail}")
                    _update_repl_status(db, job_id, "error", f"Migration task failed: {mig_detail}")
            else:
                _update_repl_status(db, job_id, "error", f"Migration failed: {result.get('error')}")

        except Exception as e:
            logging.error(f"[XCREPL] Job {job_id}: migration error: {e}")
            _update_repl_status(db, job_id, "error", str(e))
        finally:
            # always clean up token
            with contextlib.suppress(Exception):
                target_mgr.delete_api_token(token_name)

        # 6. cleanup snapshot on source (clone auto-deleted by delete_source=True)
        _cleanup_snapshot(source_mgr, source_node, vmid, vm_type, snap_name)

        # Handle retention - delete oldest replicas on target if over limit
        retention = int(job.get("retention", 3) or 3)
        _enforce_retention(target_mgr, tgt_vmid, vm_type, snap_name, retention)

    except Exception as e:
        logging.error(f"[XCREPL] Job {job_id}: unexpected error: {e}")
        _update_repl_status(db, job_id, "error", str(e))
        # best-effort cleanup
        if clone_vmid:
            with contextlib.suppress(Exception):
                _cleanup_clone_and_snap(source_mgr, source_node, clone_vmid, vmid, vm_type, snap_name)


def _update_repl_status(db, job_id, status, error=""):
    """Update job status in DB after a replication run."""
    try:
        db.execute(
            "UPDATE cross_cluster_replications SET last_run = ?, last_status = ?, last_error = ?, updated_at = ? WHERE id = ?",
            (datetime.now().isoformat(), status, error or "", datetime.now().isoformat(), job_id),
        )
    except Exception as e:
        logging.warning(f"[XCREPL] Could not update status for {job_id}: {e}")
    # (audit completeness) - emit terminal audit event so the bundle's
    # audit_log captures the outcome of every xcrepl run, not just `replication.triggered`.
    # Mirrors the gap that surfaced via #438 on the v2p side: started-only audit forces
    # log archaeology on every silent-failure investigation.
    try:
        if status == "ok":
            log_audit("system", "replication.completed", f"xcrepl job {job_id} succeeded")
        elif status == "error":
            log_audit("system", "replication.failed", f"xcrepl job {job_id} failed: {error or 'no detail'}")
    except Exception as _e:
        pass


def _wait_for_task(mgr, task_upid, timeout=600, poll=5):
    """Poll Proxmox task status until it finishes or times out.
    Similar to the cleanup thread logic but blocking.
    Returns (success: bool, detail: str) — detail has PVE status or error info.
    """
    if not task_upid:
        # lgtm[py/reflected-xss]
        return (False, "no task UPID")
    elapsed = 0
    while elapsed < timeout:
        try:
            tasks = mgr.get_tasks(limit=100)
            for t in tasks:
                if t and t.get("upid") == task_upid:
                    st = t.get("status", "")
                    if st and st != "running":
                        ok = st in ("OK", "WARNINGS")
                        detail = st if ok else (t.get("exitstatus") or st)
                        # lgtm[py/reflected-xss]
                        return (ok, detail)
                    break
        except Exception as _e:
            pass
        time.sleep(poll)
        elapsed += poll
    # lgtm[py/reflected-xss]
    return (False, f"timed out after {timeout}s")


def _cleanup_snapshot(mgr, node, vmid, vm_type, snap_name):
    """Delete a snapshot, best-effort, with NFS/ESTALE recovery.

    (#422 depedro-ai): On NetApp / NFS qcow2 storage, the underlying
    `qemu-img snapshot -d` can fail with ESTALE ("Stale file handle") even
    though PVE issued the DELETE successfully. When that happens, PVE leaves
    the VM in `lock = snapshot-delete` state and refuses *all* subsequent
    operations (shutdown, migrate, failover) with "VM is locked
    (snapshot-delete)" — which is exactly the silent-failure depedro-ai hit.

    Fix: always pass `force=1` so PVE removes the snapshot config entry even
    if the on-disk delete fails. Then, if the VM is still locked afterwards
    (defence in depth), explicitly unlock via the PVE API. xcrepl snapshots
    are ours from end to end — operator never cares about the orphan .qcow2
    internal slot that may be left on storage; what matters is the VM gets
    out of the locked state cleanly.
    """
    url = f"https://{mgr.host}:{mgr.api_port}/api2/json/nodes/{node}/{vm_type}/{vmid}/snapshot/{snap_name}"
    try:
        # `force=1` tells PVE: remove config entry even if qemu-img delete fails.
        # Without it, NFS ESTALE → VM stuck at lock=snapshot-delete indefinitely.
        mgr._api_delete(url, params={"force": 1})
        logging.debug(f"[XCREPL] Deleted snapshot {snap_name} on {vmid} (force=1)")
    except Exception as e:
        logging.warning(f"[XCREPL] Could not delete snapshot {snap_name}: {e}")

    # Defence in depth: explicitly check + clear the lock if still set.
    # `qm unlock` via the API is `POST /nodes/<node>/<type>/<vmid>/status/current`
    # with `lock=` body — actually no, that's setting. The right one is the
    # config endpoint with `delete=lock`. Use that.
    try:
        cfg_url = f"https://{mgr.host}:{mgr.api_port}/api2/json/nodes/{node}/{vm_type}/{vmid}/config"
        cfg_resp = mgr._api_get(cfg_url)
        if cfg_resp is not None and cfg_resp.status_code == 200:
            cfg = (cfg_resp.json() or {}).get("data", {}) or {}
            current_lock = cfg.get("lock")
            if current_lock == "snapshot-delete":
                logging.warning(
                    f"[XCREPL] VM {vmid} still locked at 'snapshot-delete' after cleanup — "
                    f"clearing lock so subsequent operations don't silently fail (#422)"
                )
                # PUT /config with delete=lock removes the lock field
                from ProxmoxVEx.utils.audit import log_audit

                try:
                    mgr._api_put(cfg_url, data={"delete": "lock"})
                    log_audit(
                        user="system",
                        action="vm.unlock_after_xcrepl",
                        details=f"vmid={vmid} lock=snapshot-delete cleared after cross-cluster replication cleanup",
                        ip_address="127.0.0.1",
                    )
                except Exception as unlock_err:
                    logging.warning(f"[XCREPL] Could not auto-unlock VM {vmid}: {unlock_err}")
    except Exception as e:
        logging.debug(f"[XCREPL] Lock-state recheck on {vmid} failed (non-fatal): {e}")


def _cleanup_clone_and_snap(mgr, node, clone_vmid, orig_vmid, vm_type, snap_name):
    """Remove leftover clone VM + snapshot after failure."""
    # delete clone
    try:
        url = f"https://{mgr.host}:{mgr.api_port}/api2/json/nodes/{node}/{vm_type}/{clone_vmid}"
        mgr._api_delete(url)
    except Exception as _e:
        pass
    # delete snapshot
    _cleanup_snapshot(mgr, node, orig_vmid, vm_type, snap_name)


def _enforce_retention(target_mgr, vmid, vm_type, current_snap, retention):
    """
    Remove old xcrepl snapshots on target if we exceed retention count.
    We only manage snapshots we created (prefixed with 'xcrepl-').
    """
    try:
        # find the target node for this VM
        resources = target_mgr._api_get(
            f"https://{target_mgr.host}:{target_mgr.api_port}/api2/json/cluster/resources", params={"type": "vm"}
        )
        if resources.status_code != 200:
            return

        target_node = None
        for r in resources.json().get("data", []):
            if int(r.get("vmid", 0)) == vmid:
                target_node = r.get("node")
                break
        if not target_node:
            return

        snap_url = (
            f"https://{target_mgr.host}:{target_mgr.api_port}/api2/json/nodes/{target_node}/{vm_type}/{vmid}/snapshot"
        )
        snap_resp = target_mgr._api_get(snap_url)
        if snap_resp.status_code != 200:
            return

        xcrepl_snaps = [
            s
            for s in snap_resp.json().get("data", [])
            if s.get("name", "").startswith("xcrepl-") and s.get("name") != "current"
        ]
        # sort by name (contains timestamp) so oldest first
        xcrepl_snaps.sort(key=lambda s: s.get("name", ""))

        while len(xcrepl_snaps) > retention:
            oldest = xcrepl_snaps.pop(0)
            try:
                del_url = (
                    f"https://{target_mgr.host}:{target_mgr.api_port}/api2/json/nodes/{target_node}"
                    f"/{vm_type}/{vmid}/snapshot/{oldest['name']}"
                )
                target_mgr._api_delete(del_url)
                logging.info(f"[XCREPL] Retention: deleted old snapshot {oldest['name']} on target")
            except Exception as e:
                logging.warning(f"[XCREPL] Retention cleanup failed for {oldest['name']}: {e}")
    except Exception as e:
        logging.debug(f"[XCREPL] Retention check skipped: {e}")


@bp.route("/api/cross-cluster-replications", methods=["GET"])
@require_auth(perms=["cluster.view"])
def get_cross_cluster_replications():
    """List cross-cluster replication jobs, optionally filtered by vmid."""
    db = get_db()
    vmid = request.args.get("vmid", type=int)

    if vmid:
        rows = db.query("SELECT * FROM cross_cluster_replications WHERE vmid = ?", (vmid,))
    else:
        rows = db.query("SELECT * FROM cross_cluster_replications")

    # (sec-review) - don't expose other tenants' job rows (ids, clusters,
    # target VMIDs). Filter to clusters the caller can actually reach; admins/untenanted
    # users get None (= everything), unchanged.
    from ProxmoxVEx.utils.rbac import get_user_clusters

    user = getattr(g, "current_user", None)
    if user is None:
        user = db.get_user(request.session.get("user", "")) or {}
    allowed = get_user_clusters(user)
    out = []
    for r in rows:
        d = dict(r)
        if allowed is None or d.get("source_cluster") in allowed or d.get("target_cluster") in allowed:
            out.append(d)
    # lgtm[py/reflected-xss]
    return jsonify(out)


@bp.route("/api/cross-cluster-replications", methods=["POST"])
@require_auth(perms=["cluster.config"])
def create_cross_cluster_replication():
    """Create a new cross-cluster replication job."""
    data = request.json or {}

    source_cluster = data.get("source_cluster")
    target_cluster = data.get("target_cluster")
    vmid = data.get("vmid")

    if not source_cluster or not target_cluster or not vmid:
        # lgtm[py/reflected-xss]
        return jsonify({"error": "source_cluster, target_cluster and vmid are required"}), 400

    if source_cluster not in cluster_managers:
        # lgtm[py/reflected-xss]
        return jsonify({"error": "Source cluster not found"}), 404
    if target_cluster not in cluster_managers:
        # lgtm[py/reflected-xss]
        return jsonify({"error": "Target cluster not found"}), 404

    # (sec-review) - cluster.config is a GLOBAL perm; the tenant/ACL
    # boundary in this codebase is check_cluster_access. The cross-cluster MIGRATION
    # endpoint gates both sides, so replication (which can overwrite/destroy a VM on
    # the target) must too — else a tenant-scoped operator could drive a job into a
    # cluster they don't own.
    for _cid in (source_cluster, target_cluster):
        ok, err = check_cluster_access(_cid)
        if not ok:
            return _access_denied()

    # Same-cluster snapshot replication for non-ZFS (Issue
    # target_node required when source == target cluster
    target_node = data.get("target_node", "")
    if source_cluster == target_cluster and not target_node:
        # lgtm[py/reflected-xss]
        return jsonify({"error": "target_node is required for same-cluster replication"}), 400

    job_id = str(uuid.uuid4())[:8]
    now = datetime.now().isoformat()
    db = get_db()

    # MatthieuTr #532 — per-NIC bridge mapping. PVE's target-bridge takes a
    # "src:tgt,src:tgt" list, so a multi-NIC VM keeps each card on its own
    # destination bridge (same encoding the cross-cluster migration endpoint uses).
    # Validate every iface name (defence-in-depth) so nothing smuggles extra map
    # entries / commas into the PVE target-bridge param.
    def _ok_iface(n):
        # lgtm[py/reflected-xss]
        return isinstance(n, str) and 1 <= len(n) <= 32 and n[0].isalpha() and all(c.isalnum() or c in "_.-" for c in n)

    bridge_map = data.get("target_bridge_map")
    if isinstance(bridge_map, dict) and bridge_map:
        if len(bridge_map) > 64:
            # lgtm[py/reflected-xss]
            return jsonify({"error": "target_bridge_map has too many entries"}), 400
        if not all(_ok_iface(s) and _ok_iface(t) for s, t in bridge_map.items()):
            # lgtm[py/reflected-xss]
            return jsonify({"error": "target_bridge_map contains an invalid bridge name"}), 400
        target_bridge = ",".join(f"{s}:{t}" for s, t in bridge_map.items())
    else:
        target_bridge = data.get("target_bridge", "vmbr0") or "vmbr0"
        if not _ok_iface(target_bridge):
            # lgtm[py/reflected-xss]
            return jsonify({"error": "invalid target_bridge"}), 400

    # helppp #552 — optional fixed replica VMID (NULL = let PVE pick at run time).
    # Parse defensively: garbage must 400, not crash the route with a 500.
    tv = data.get("target_vmid")
    if tv in (None, "", 0, "0"):
        target_vmid = None
    else:
        try:
            target_vmid = int(tv)
        except (TypeError, ValueError):
            # lgtm[py/reflected-xss]
            return jsonify({"error": "target_vmid must be an integer"}), 400
        if not (100 <= target_vmid <= 999999999):
            # lgtm[py/reflected-xss]
            return jsonify({"error": "target_vmid out of range (100–999999999)"}), 400
    delete_target = 1 if data.get("delete_target") else 0

    db.execute(
        """
        INSERT INTO cross_cluster_replications
        (id, source_cluster, target_cluster, vmid, vm_type, schedule, retention,
         target_storage, target_bridge, target_node, target_vmid, delete_target,
         enabled, created_by, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?, ?)
    """,
        (
            job_id,
            source_cluster,
            target_cluster,
            int(vmid),
            data.get("vm_type", "qemu"),
            data.get("schedule", "0 */6 * * *"),
            int(data.get("retention", 3)),
            data.get("target_storage", ""),
            target_bridge,
            target_node,
            target_vmid,
            delete_target,
            getattr(request, "session", {}).get("user", "system"),
            now,
            now,
        ),
    )

    usr = getattr(request, "session", {}).get("user", "system")
    log_audit(
        usr,
        "replication.created",
        f"Cross-cluster replication {job_id}: VM {vmid} from {source_cluster} to {target_cluster} "
        f"(target VMID {target_vmid or 'auto'}{', delete-target ON' if delete_target else ''})",
    )

    # lgtm[py/reflected-xss]
    return jsonify({"success": True, "id": job_id})


def _delete_replica_target(job):
    """#552 - tear down the replica VM for a job. Only removes a VM we can prove
    is this job's replica (xcrepl: job-tag; local: repl-<src>- name prefix), so a
    mis-set target VMID never nukes a bystander. Returns (ok, detail)."""
    src_vmid = int(job["vmid"])
    tgt_vmid = int(job.get("target_vmid") or 0) or src_vmid
    vm_type = job.get("vm_type", "qemu") or "qemu"
    job_id = job["id"]
    is_local = job.get("source_cluster") == job.get("target_cluster")
    mgr = cluster_managers.get(job.get("target_cluster"))
    if not mgr:
        # lgtm[py/reflected-xss]
        return (False, "target cluster not found")
    if not mgr.is_connected:
        # lgtm[py/reflected-xss]
        return (False, "target cluster not connected")
    try:
        # authoritative node lookup — cluster/resources lags after a migrate (#552)
        node, found = _resolve_vm_node(mgr, tgt_vmid, vm_type)
        if not found:
            # lgtm[py/reflected-xss]
            return (True, "replica not present")
        # ownership check — never delete a VM that isn't provably ours.
        # local: EXACT replica name repl-<src>-<target_node> (not a loose prefix);
        # xcrepl: the job-specific replica tag.
        if is_local:
            vname = found.get("name", "") or ""
            owned = vname == f"repl-{src_vmid}-{job.get('target_node', '')}"
        else:
            owned = _is_replica_of_job(mgr, node, tgt_vmid, vm_type, job_id)
        if not owned:
            # lgtm[py/reflected-xss]
            return (False, f"VMID {tgt_vmid} is not tagged/named as this job's replica — left untouched")

        if found.get("status") == "running":
            try:
                stop = mgr._api_post(
                    f"https://{mgr.host}:{mgr.api_port}/api2/json/nodes/{node}/{vm_type}/{tgt_vmid}/status/stop",
                    data={},
                )
                st = stop.json().get("data") if stop.status_code == 200 else None
                if st:
                    _wait_for_task(mgr, st, timeout=60)
            except Exception as _e:
                pass
        dr = mgr._api_delete(
            f"https://{mgr.host}:{mgr.api_port}/api2/json/nodes/{node}/{vm_type}/{tgt_vmid}",
            params={"purge": 1, "destroy-unreferenced-disks": 1},
        )
        if dr.status_code != 200:
            # lgtm[py/reflected-xss]
            return (False, f"delete failed: {dr.text[:160]}")
        dt = dr.json().get("data")
        if dt:
            # bounded wait — this teardown runs inline in the request greenlet, so
            # don't let one delete pin a worker for 10 min (sec-review). A replica
            # qmdestroy is quick; if it ever exceeds this, PVE still finishes it and
            # a retry sees 'replica not present'.
            ok, detail = _wait_for_task(mgr, dt, timeout=180)
            if not ok:
                # lgtm[py/reflected-xss]
                return (False, f"delete task failed: {detail}")
        # lgtm[py/reflected-xss]
        return (True, f"VM {tgt_vmid} removed")
    except Exception as e:
        # lgtm[py/reflected-xss]
        return (False, str(e))


def _wants_delete_target(job):
    """Resolve whether the replica VM should be torn down on job delete.
    Per-request override (query ?delete_target=1 or JSON body) wins; otherwise
    fall back to the flag stored on the job."""
    raw = request.args.get("delete_target")
    if raw is None:
        # #563 — silent parse: a DELETE with an empty body but a JSON content-type
        # (what the fetch wrapper sends) used to make request.json throw a 400.
        body = request.get_json(silent=True) or {}
        if isinstance(body, dict) and "delete_target" in body:
            raw = body.get("delete_target")
    if raw is None:
        raw = job.get("delete_target")
    if isinstance(raw, bool):
        # lgtm[py/reflected-xss]
        return raw
    # lgtm[py/reflected-xss]
    return str(raw).strip().lower() in ("1", "true", "yes", "on")


@bp.route("/api/cross-cluster-replications/<job_id>", methods=["DELETE"])
@require_auth(perms=["cluster.config"])
def delete_cross_cluster_replication(job_id):
    """Delete a cross-cluster replication job (optionally its replica VM too)."""
    db = get_db()
    existing = db.query_one("SELECT * FROM cross_cluster_replications WHERE id = ?", (job_id,))
    if not existing:
        # lgtm[py/reflected-xss]
        return jsonify({"error": "Replication job not found"}), 404
    job = dict(existing)

    # (sec-review) - per-cluster access gate (same boundary as create/run).
    # Without it, a tenant-scoped cluster.config holder could destroy another tenant's
    # replica VM via delete_target, or tamper with their job config.
    for _cid in (job.get("source_cluster"), job.get("target_cluster")):
        # #563 — a cluster that no longer exists can't be tenant-owned anymore and its
        # replica is gone with it, so its absence must not block cleanup of the orphaned
        # job. Still gate clusters that DO exist (the BOLA boundary the comment below means).
        if _cid and _cid in cluster_managers:
            ok, _ = check_cluster_access(_cid)
            if not ok:
                return _access_denied()

    want_teardown = _wants_delete_target(job)

    # Don't race an in-flight run: tearing the replica down mid-run just lets the run
    # re-create it (we hit exactly this during testing). Same _claim_job set the run
    # + scheduler use.
    if want_teardown:
        from ProxmoxVEx.background.cross_cluster_replication import is_job_inflight

        if is_job_inflight(job_id):
            # lgtm[py/reflected-xss]
            return jsonify({
                "error": "Replication job is running",
                "detail": "Wait for the current run to finish before deleting with target teardown.",
            }), 409

    target_detail = ""
    target_deleted = False
    if want_teardown:
        _tgt = job.get("target_cluster")
        if _tgt and _tgt not in cluster_managers:
            # #563 — target cluster was removed; the replica died with it, there's
            # nothing left to tear down. Drop the job rather than wedging on a teardown
            # that can never succeed.
            logging.info(f"[XCREPL] Job {job_id}: target cluster {_tgt} gone, dropping job without teardown")
            target_detail = " (target cluster removed — replica gone with it)"
        else:
            ok, detail = _delete_replica_target(job)
            if not ok:
                # teardown genuinely failed — keep the job row so the operator keeps the
                # handle and can retry (or delete without teardown to just drop the job).
                logging.warning(f"[XCREPL] Job {job_id}: replica teardown failed, keeping job: {detail}")
                # lgtm[py/reflected-xss]
                return jsonify({"error": "Replica teardown failed — replication job kept", "detail": detail}), 409
            target_deleted = True
            target_detail = f" (replica: {detail})"

    db.execute("DELETE FROM cross_cluster_replications WHERE id = ?", (job_id,))

    usr = getattr(request, "session", {}).get("user", "system")
    log_audit(usr, "replication.deleted", f"Cross-cluster replication {job_id} deleted{target_detail}")

    # lgtm[py/reflected-xss]
    return jsonify({"success": True, "target_deleted": target_deleted, "target_detail": target_detail.strip()})


@bp.route("/api/cross-cluster-replications/<job_id>/run", methods=["POST"])
@require_auth(perms=["cluster.config"])
def run_cross_cluster_replication(job_id):
    """Trigger a cross-cluster replication job immediately (async)."""
    db = get_db()
    job = db.query_one("SELECT * FROM cross_cluster_replications WHERE id = ?", (job_id,))
    if not job:
        # lgtm[py/reflected-xss]
        return jsonify({"error": "Replication job not found"}), 404

    # (sec-review) - gate per-cluster access before kicking off a run that
    # migrates into / overwrites the replica on these clusters (same boundary as create).
    _job = dict(job)
    for _cid in (_job.get("source_cluster"), _job.get("target_cluster")):
        if _cid:
            ok, _ = check_cluster_access(_cid)
            if not ok:
                return _access_denied()

    # (#455 @DarmokNoob) - block duplicate triggers while a previous
    # run is still in-flight. The scheduler uses the same _claim_job() guard.
    from ProxmoxVEx.background.cross_cluster_replication import _claim_job, _release_job, _tracked_run

    if not _claim_job(job_id):
        # lgtm[py/reflected-xss]
        return jsonify({
            "error": "Replication job is already running",
            "detail": "Wait for the current run to finish, then retry.",
        }), 409

    # kick off in background so the API responds right away
    # Detect same-cluster -> use local replication
    job_dict = dict(job)
    is_local = job_dict.get("source_cluster") == job_dict.get("target_cluster")
    handler = _execute_local_replication if is_local else _execute_replication
    try:
        threading.Thread(target=_tracked_run, args=(handler, job_dict), daemon=True).start()
    except Exception:
        _release_job(job_id)
        logging.exception("Failed to start replication")
        # lgtm[py/reflected-xss]
        return jsonify({"error": "Failed to start replication"}), 500

    usr = getattr(request, "session", {}).get("user", "system")
    log_audit(
        usr,
        "replication.triggered",
        f"{'Local' if is_local else 'Cross-cluster'} replication {job_id} manually triggered",
    )

    # lgtm[py/reflected-xss]
    return jsonify({"success": True, "message": "Replication started"})


# Get snapshot replication jobs filtered by cluster
@bp.route("/api/clusters/<cluster_id>/snapshot-replications", methods=["GET"])
@require_auth(perms=["cluster.view"])
def get_snapshot_replications_for_cluster(cluster_id):
    """Get snapshot-based replication jobs where this cluster is source or target."""
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()

    db = get_db()
    rows = db.query(
        "SELECT * FROM cross_cluster_replications WHERE source_cluster = ? OR target_cluster = ?",
        (cluster_id, cluster_id),
    )
    # lgtm[py/reflected-xss]
    return jsonify([dict(r) for r in rows])
