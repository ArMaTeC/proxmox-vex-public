# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/api/vms/datacenter.py
# Project:     ProxmoxVEx
# Version:     1.2.535
# Build:       2026.09.26
# Description: datacenter routes for the vms API (split from
#              api/vms.py).
# Usage:       import ProxmoxVEx.api.vms.datacenter
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-26
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""datacenter routes for the vms API (split from api/vms.py)."""

import hashlib
import logging
import socket
import ssl

import requests
from flask import jsonify

from ProxmoxVEx.api.helpers import (
    check_cluster_access,
    etag_json,
    get_connected_manager,
    paginated_envelope,
    pagination_requested,
)
from ProxmoxVEx.core.cache import cached_get, vm_list_cache
from ProxmoxVEx.globals import cluster_managers
from ProxmoxVEx.utils.auth import require_auth
from ProxmoxVEx.utils.validation import validate_body

from .common import (
    _access_denied,
    _api_error,
    _cluster_not_connected,
    _cluster_not_found,
    _pve_error,
    bp,
    request,
)

# =====================================================
# DATACENTER / CLUSTER CONFIGURATION API
# =====================================================


@bp.route("/api/clusters/<cluster_id>/datacenter/status", methods=["GET"])
@require_auth(perms=["cluster.view"])
@cached_get(ttl=10)
def get_datacenter_status(cluster_id):
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()

    manager, _ = get_connected_manager(cluster_id)
    if not manager:
        if cluster_id not in cluster_managers:
            return _cluster_not_found()
        return _cluster_not_connected()

    try:
        host, port = manager.host, manager.api_port

        # Cluster-wide aggregates ([cluster/status] + [cluster/resources])
        # are genuinely expensive on big clusters (PVE walks every node to build the
        # response). 10s was too tight; bump to 15s and mark the host as cold on
        # timeout so subsequent calls roll over to a fallback host via the
        # connect_to_proxmox skip-cache.
        status_url = f"https://{host}:{port}/api2/json/cluster/status"
        resources_url = f"https://{host}:{port}/api2/json/cluster/resources"
        # (SSE-perf): these two full node-walks were issued SERIALLY, so
        # the route's wall-time was the SUM of two heavy aggregations. Fire them
        # concurrently (shared pooled session) → wall-time is the MAX. run_concurrent
        # swallows per-task exceptions into None, so we detect a failed walk and keep
        # the original cold-host + reconnect failover.
        from ProxmoxVEx.utils.concurrent import run_concurrent

        sess = manager._create_session()
        status_resp, resources_resp = run_concurrent(
            [
                lambda: sess.get(status_url, timeout=15),
                lambda: sess.get(resources_url, timeout=15),
            ],
            timeout=20,
        )
        if status_resp is None or resources_resp is None:
            # a walk timed out / errored — mark the primary cold AND force an
            # immediate reconnect so manager.host pivots to a warm fallback for the
            # next request (otherwise the host pointer still points at the dead one).
            manager._mark_host_failure(host)
            try:
                manager.is_connected = False
                manager.connect_to_proxmox()
            except Exception as _e:
                pass  # best-effort; user sees the offline state this round
            # lgtm[py/reflected-xss]
            return jsonify({"error": "Cluster temporarily unreachable", "offline": True}), 503

        status_data = status_resp.json().get("data", []) if status_resp.status_code == 200 else []
        resources_data = resources_resp.json().get("data", []) if resources_resp.status_code == 200 else []

        # calc summary
        nodes_online = sum(1 for s in status_data if s.get("type") == "node" and s.get("online", 0) == 1)
        nodes_offline = sum(1 for s in status_data if s.get("type") == "node" and s.get("online", 0) == 0)
        cluster_info = next((s for s in status_data if s.get("type") == "cluster"), None)
        is_standalone = cluster_info is None

        vms_running = sum(1 for r in resources_data if r.get("type") == "qemu" and r.get("status") == "running")
        vms_stopped = sum(1 for r in resources_data if r.get("type") == "qemu" and r.get("status") == "stopped")
        cts_running = sum(1 for r in resources_data if r.get("type") == "lxc" and r.get("status") == "running")
        cts_stopped = sum(1 for r in resources_data if r.get("type") == "lxc" and r.get("status") == "stopped")

        # Calculate total resources
        total_cpu = sum(r.get("maxcpu", 0) for r in resources_data if r.get("type") == "node")
        used_cpu = sum(r.get("cpu", 0) * r.get("maxcpu", 0) for r in resources_data if r.get("type") == "node")
        total_mem = sum(r.get("maxmem", 0) for r in resources_data if r.get("type") == "node")
        used_mem = sum(r.get("mem", 0) for r in resources_data if r.get("type") == "node")
        total_disk = sum(r.get("maxdisk", 0) for r in resources_data if r.get("type") == "storage")
        used_disk = sum(r.get("disk", 0) for r in resources_data if r.get("type") == "storage")

        # Single-node Proxmox doesn't return a cluster entry, was showing red X for no reason
        if is_standalone:
            node_name = next((s.get("name", "") for s in status_data if s.get("type") == "node"), manager.config.name)
            cluster_result = {"name": node_name, "quorate": None, "standalone": True, "version": 0}
        else:
            cluster_result = {
                "name": cluster_info.get("name", "Unknown"),
                "quorate": cluster_info.get("quorate", 0) == 1,
                "standalone": False,
                "version": cluster_info.get("version", 0),
            }

        # lgtm[py/reflected-xss]
        return jsonify({
            "cluster": cluster_result,
            "nodes": {"online": nodes_online, "offline": nodes_offline, "total": nodes_online + nodes_offline},
            "guests": {
                "vms": {"running": vms_running, "stopped": vms_stopped},
                "containers": {"running": cts_running, "stopped": cts_stopped},
            },
            "resources": {
                "cpu": {
                    "total": total_cpu,
                    "used": used_cpu,
                    "percent": round(used_cpu / total_cpu * 100, 1) if total_cpu > 0 else 0,
                },
                "memory": {
                    "total": total_mem,
                    "used": used_mem,
                    "percent": round(used_mem / total_mem * 100, 1) if total_mem > 0 else 0,
                },
                "storage": {
                    "total": total_disk,
                    "used": used_disk,
                    "percent": round(used_disk / total_disk * 100, 1) if total_disk > 0 else 0,
                },
            },
        })
    except (requests.exceptions.ConnectionError, requests.exceptions.Timeout) as e:
        logging.warning(f"[API] Cluster {cluster_id} unreachable for datacenter/status: {e}")
        # lgtm[py/reflected-xss]
        return jsonify({"error": "Cluster temporarily unreachable", "offline": True}), 503
    except Exception:
        return _api_error("Failed to get datacenter status", status=500)


@bp.route("/api/clusters/<cluster_id>/vms", methods=["GET"])
@require_auth(perms=["vm.view"])
def get_cluster_vms_list(cluster_id):
    """Get all VMs and containers in a cluster

    Added Dec 2025 for VM ACL management
    Returns simple list with vmid, name, node, type
    """
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()

    manager, _ = get_connected_manager(cluster_id)
    if not manager:
        if cluster_id not in cluster_managers:
            return _cluster_not_found()
        return _cluster_not_connected()

    # 009-perf-cached-vm-list: serve cached VM list when available
    user_id = request.session.get("user")
    cached = vm_list_cache.get_scoped(cluster_id, user_id)
    if cached is not None:
        # spec 092/US035: ?page=/per_page= opts into the standard envelope
        if pagination_requested():
            return etag_json(paginated_envelope(cached))
        # spec 092/US036: ETag/304 conditional GET — hash the vms content only:
        # from_cache legitimately varies between identical resources.
        return etag_json({"vms": cached, "from_cache": True}, etag_of=cached)

    # Use manager method instead of raw API call - handles timeouts gracefully
    resources = manager.get_vm_resources()
    vms = []
    for r in resources:
        if r.get("type") in ["qemu", "lxc"] and r.get("vmid"):
            vms.append({
                "vmid": r.get("vmid"),
                "name": r.get("name", ""),
                "node": r.get("node"),
                "type": r.get("type"),
                "status": r.get("status", "unknown"),
            })
    vms.sort(key=lambda x: x.get("vmid", 0))
    vm_list_cache.set_scoped(cluster_id, user_id, vms)
    # lgtm[py/reflected-xss]
    if pagination_requested():
        return etag_json(paginated_envelope(vms))
    return etag_json({"vms": vms, "from_cache": False}, etag_of=vms)


@bp.route("/api/clusters/<cluster_id>/vms/status", methods=["GET"])
@require_auth(perms=["vm.view"])
@cached_get(ttl=5)
def get_cluster_vms_status(cluster_id):
    """Batched guest-status snapshot: {nodes: {node: {vmid: {status, type}}}}.

    (spec 092/US005) - one manager.get_vm_resources() walk (a single upstream
    /cluster/resources call) serves every guest's status; the alternative —
    per-VM /status/current calls — is an N-request storm on large clusters.
    Callers may pass ?max_age=<s> to reuse the broadcast loop's fresh snapshot
    instead of firing a redundant walk inside the same poll window.
    """
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()
    manager, _ = get_connected_manager(cluster_id)
    if not manager:
        if cluster_id not in cluster_managers:
            return _cluster_not_found()
        return _cluster_not_connected()
    try:
        max_age = max(0.0, min(300.0, float(request.args.get("max_age", 0) or 0)))
    except (TypeError, ValueError):
        max_age = 0.0
    nodes = {}
    count = 0
    for r in manager.get_vm_resources(max_age=max_age) or []:
        if r.get("type") not in ("qemu", "lxc") or not r.get("vmid"):
            continue
        nodes.setdefault(r.get("node") or "unknown", {})[str(r["vmid"])] = {
            "status": r.get("status", "unknown"),
            "type": r["type"],
        }
        count += 1
    return jsonify({"nodes": nodes, "count": count})


@bp.route("/api/clusters/<cluster_id>/datacenter/cluster-info", methods=["GET"])
@require_auth(perms=["cluster.view"])
@cached_get(ttl=30)
def get_cluster_info(cluster_id):
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()

    manager, _ = get_connected_manager(cluster_id)
    if not manager:
        if cluster_id not in cluster_managers:
            return _cluster_not_found()
        return _cluster_not_connected()

    try:
        host, port = manager.host, manager.api_port
        session = manager._create_session()

        # Try corosync config first (has ring0_addr for join info)
        nodes = []
        try:
            url = f"https://{host}:{port}/api2/json/cluster/config/nodes"
            r = session.get(url, timeout=5)
            if r.status_code == 200:
                nodes = r.json().get("data", [])
        except Exception as _e:
            pass

        # Merge with /nodes to get online status (corosync config doesn't have it)
        # Also serves as fallback for standalone nodes without corosync
        try:
            nodes_url = f"https://{host}:{port}/api2/json/nodes"
            nr = session.get(nodes_url, timeout=5)
            if nr.status_code == 200:
                api_nodes = {n.get("node", n.get("name", "")): n for n in nr.json().get("data", [])}

                if nodes:
                    # Merge online status into corosync nodes
                    for node in nodes:
                        name = node.get("name", "")
                        if name in api_nodes:
                            node["online"] = 1 if api_nodes[name].get("status") == "online" else 0
                            node["node"] = name
                else:
                    # No corosync data - use /nodes as primary source
                    nodes = [
                        {
                            "name": n.get("node", ""),
                            "node": n.get("node", ""),
                            "online": 1 if n.get("status") == "online" else 0,
                        }
                        for n in nr.json().get("data", [])
                    ]
        except Exception as _e:
            pass

        # lgtm[py/reflected-xss]
        return jsonify(nodes)
    except Exception as _e:
        # lgtm[py/reflected-xss]
        return jsonify([])


@bp.route("/api/clusters/<cluster_id>/datacenter/join-info", methods=["GET"])
@require_auth(perms=["cluster.view"])
def get_join_info(cluster_id):
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()

    manager, _ = get_connected_manager(cluster_id)
    if not manager:
        if cluster_id not in cluster_managers:
            return _cluster_not_found()
        return _cluster_not_connected()

    try:
        host, port = manager.host, manager.api_port

        # try to get join info
        url = f"https://{host}:{port}/api2/json/cluster/config/join"
        r = manager._create_session().get(url, timeout=5)

        if r.status_code == 200:
            data = r.json().get("data", {})
            if "preferred_node" not in data:
                data["preferred_node"] = host
            # Proxmox returns fingerprint as 'pve_fp' per node,
            # but frontend expects top-level 'fingerprint'. Extract it.
            if not data.get("fingerprint"):
                for node_entry in data.get("nodelist", []):
                    if isinstance(node_entry, dict) and node_entry.get("pve_fp"):
                        data["fingerprint"] = node_entry["pve_fp"]
                        break
            # Still no fingerprint? Get from SSL cert
            if not data.get("fingerprint"):
                try:
                    context = ssl.create_default_context()
                    context.check_hostname = False
                    context.verify_mode = ssl.CERT_NONE
                    with socket.create_connection((host, 8006), timeout=5) as sock, context.wrap_socket(
                        sock, server_hostname=host
                    ) as ssock:
                        cert_der = ssock.getpeercert(binary_form=True)
                        # getpeercert(binary_form=True) may return None if the peer
                        # presented no certificate — don't hash a bogus fingerprint.
                        if cert_der:
                            fp_hex = hashlib.sha256(cert_der).hexdigest()
                            data["fingerprint"] = ":".join(
                                fp_hex[i : i + 2].upper() for i in range(0, len(fp_hex), 2)
                            )
                except Exception as _e:
                    pass
            # lgtm[py/reflected-xss]
            return jsonify(data)

        # fallback
        result = {"cluster_name": None, "fingerprint": None, "preferred_node": host, "nodelist": []}

        status_url = f"https://{host}:{port}/api2/json/cluster/status"
        status_resp = manager._create_session().get(status_url, timeout=5)

        if status_resp.status_code == 200:
            status_data = status_resp.json().get("data", [])
            cluster_info = next((s for s in status_data if s.get("type") == "cluster"), {})
            nodes = [s for s in status_data if s.get("type") == "node"]

            result["cluster_name"] = cluster_info.get("name", "Unknown")
            result["nodelist"] = [
                {"name": n.get("name"), "ip": n.get("ip"), "online": n.get("online", 0)} for n in nodes
            ]

        # get nodes config
        nodes_url = f"https://{host}:{port}/api2/json/cluster/config/nodes"
        nodes_resp = manager._create_session().get(nodes_url, timeout=5)

        if nodes_resp.status_code == 200:
            nodes_data = nodes_resp.json().get("data", [])
            for node in nodes_data:
                # Update nodelist with ring0_addr
                for n in result["nodelist"]:
                    if n["name"] == node.get("name"):
                        n["ring0_addr"] = node.get("ring0_addr")
                        n["pve_addr"] = node.get("pve_addr")

        # Try to get fingerprint via SSL certificate
        try:
            context = ssl.create_default_context()
            context.check_hostname = False
            context.verify_mode = ssl.CERT_NONE

            with socket.create_connection((host, 8006), timeout=5) as sock, context.wrap_socket(
                sock, server_hostname=host
            ) as ssock:
                cert_der = ssock.getpeercert(binary_form=True)
                # getpeercert(binary_form=True) may return None if the peer
                # presented no certificate — don't hash a bogus fingerprint.
                if cert_der:
                    fingerprint = hashlib.sha256(cert_der).hexdigest()
                    # Format as colon-separated uppercase
                    result["fingerprint"] = ":".join(
                        fingerprint[i : i + 2].upper() for i in range(0, len(fingerprint), 2)
                    )
        except Exception as e:
            logging.debug(f"Could not get SSL fingerprint: {e}")
            result["fingerprint"] = f'Run "pvecm status" on {host} to get fingerprint'

        # lgtm[py/reflected-xss]
        return jsonify(result)

    except (requests.exceptions.ConnectionError, requests.exceptions.Timeout) as e:
        logging.warning(f"[API] Cluster {cluster_id} unreachable for join-info: {e}")
        # lgtm[py/reflected-xss]
        return jsonify({"error": "Cluster temporarily unreachable", "offline": True}), 503
    except Exception:
        return _api_error("Failed to get cluster info", status=500)


@bp.route("/api/clusters/<cluster_id>/datacenter/options", methods=["GET"])
@require_auth(perms=["cluster.view"])
def get_datacenter_options(cluster_id):
    """Get datacenter options"""
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()
    manager, _ = get_connected_manager(cluster_id)
    if not manager:
        if cluster_id not in cluster_managers:
            return _cluster_not_found()
        return _cluster_not_connected()

    try:
        host, port = manager.host, manager.api_port
        url = f"https://{host}:{port}/api2/json/cluster/options"
        response = manager._create_session().get(url, timeout=5)

        if response.status_code == 200:
            # lgtm[py/reflected-xss]
            return jsonify(response.json().get("data", {}))
        # lgtm[py/reflected-xss]
        return jsonify({})
    except Exception:
        return _api_error("Failed to get datacenter options", status=500)


@bp.route("/api/clusters/<cluster_id>/datacenter/options", methods=["PUT"])
@require_auth(perms=["cluster.config"])
@validate_body({
    k: {"required": False}
    for k in {
        "keyboard",
        "language",
        "console",
        "email_from",
        "max_workers",
        "migration",
        "migration_unsecure",
        "ha",
        "fencing",
        "mac_prefix",
        "bwlimit",
        "u2f",
        "webauthn",
        "description",
        "tag-style",
        "notify",
        "registered-tags",
        "user-tag-access",
        "crs",
    }
})
def set_datacenter_options(cluster_id):
    """Update datacenter options"""
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()
    manager, _ = get_connected_manager(cluster_id)
    if not manager:
        if cluster_id not in cluster_managers:
            return _cluster_not_found()
        return _cluster_not_connected()

    # Allowlist of valid datacenter options to prevent mass assignment
    ALLOWED_DC_OPTIONS = {
        "keyboard",
        "language",
        "console",
        "email_from",
        "max_workers",
        "migration",
        "migration_unsecure",
        "ha",
        "fencing",
        "mac_prefix",
        "bwlimit",
        "u2f",
        "webauthn",
        "description",
        "tag-style",
        "notify",
        "registered-tags",
        "user-tag-access",
        "crs",
    }
    try:
        host, port = manager.host, manager.api_port
        url = f"https://{host}:{port}/api2/json/cluster/options"
        raw_data = request.json or {}
        data = {k: v for k, v in raw_data.items() if k in ALLOWED_DC_OPTIONS}

        # Version-gate the crs sub-keys. Live-probed PVE 9.2.2:
        #   scheduling=basic  → 400 "property is not defined in schema"
        #   ha-rebalance-on-start=1 → 200 OK
        #   ha-auto-rebalance=1     → 200 OK
        #   ha-auto-rebalance-{threshold,method,margin,hold-duration} → 200 OK
        # Any one rejected sub-key tanks the whole crs PUT — so a UI that
        # picks "Basic" in the Scheduling Mode dropdown blocked every other
        # CRS field too. Strip `scheduling=` on 9.2+ so admins can still
        # save the auto-rebalance settings.
        # (Pre-9.2 keeps scheduling — it's still in the schema there.)
        if "crs" in data and isinstance(data["crs"], str) and data["crs"]:
            pve_ver = manager.get_pve_version_tuple()
            if pve_ver is not None and pve_ver >= (9, 2):
                kept = []
                dropped = []
                for part in data["crs"].split(","):
                    key = part.split("=", 1)[0].strip()
                    if key == "scheduling":
                        dropped.append(part)
                        continue
                    kept.append(part)
                if dropped:
                    data["crs"] = ",".join(kept)
                    if not data["crs"]:
                        data.pop("crs", None)
                    try:
                        from ProxmoxVEx.utils.audit import log_audit

                        log_audit(
                            request.session.get("user", "system"),
                            "datacenter.crs.stripped",
                            f"PVE {pve_ver[0]}.{pve_ver[1]} — dropped {dropped}",
                            cluster=manager.config.name,
                        )
                    except Exception as _e:
                        pass

        # /cluster/options PUT can legitimately take 15-25s on
        # busy clusters (PVE writes datacenter.cfg, ipcc-syncs to all nodes,
        # restarts pveproxy on each). The old 10s was tight enough to fail
        # consistently on the ESXi-Test-Env lab; bump to 30s. If it still
        # times out the host is genuinely wedged — mark it cold so the next
        # request goes via fallback instead of waiting 30s again.
        try:
            response = manager._create_session().put(url, data=data, timeout=30)
        except requests.exceptions.Timeout:
            manager._mark_host_failure(host)
            try:
                manager.is_connected = False
                manager.connect_to_proxmox()
            except Exception as _e:
                pass
            raise

        if response.status_code == 200:
            # lgtm[py/reflected-xss]
            return jsonify({"success": True, "message": "Options updated"})
        # lgtm[py/reflected-xss]
        return _pve_error(response)
    except requests.exceptions.Timeout:
        # Map to 504 so the frontend knows it's a slow-PVE thing, not a code bug.
        # Settings *may* have applied — pveproxy on busy clusters sometimes
        # commits the write but doesn't reply in time. Operator should re-load.
        # lgtm[py/reflected-xss]
        return jsonify({
            "error": "PVE took too long to apply datacenter options. The change may still have been written — reload the page to verify.",
            "timeout": True,
        }), 504
    except Exception:
        return _api_error("Failed to set datacenter options", status=500)


# HA Manager Status API
@bp.route("/api/clusters/<cluster_id>/datacenter/ha/status", methods=["GET"])
@require_auth(perms=["cluster.view"])
def get_ha_manager_status(cluster_id):
    """Get Proxmox HA manager status (quorum, master, lrm nodes)"""
    ok, _ = check_cluster_access(cluster_id)
    if not ok:
        return _access_denied()

    manager, _ = get_connected_manager(cluster_id)
    if not manager:
        if cluster_id not in cluster_managers:
            return _cluster_not_found()
        return _cluster_not_connected()

    try:
        host, port = manager.host, manager.api_port

        # Get manager status (quorum, master, lrm for each node)
        url = f"https://{host}:{port}/api2/json/cluster/ha/status/manager_status"
        resp = manager._create_session().get(url, timeout=30)

        if resp.status_code == 200:
            data = resp.json().get("data", {})
            # lgtm[py/reflected-xss]
            return jsonify(data)
        else:
            # Fallback to current status
            url2 = f"https://{host}:{port}/api2/json/cluster/ha/status/current"
            resp2 = manager._create_session().get(url2, timeout=30)
            if resp2.status_code == 200:
                # lgtm[py/reflected-xss]
                return jsonify(resp2.json().get("data", []))
            # lgtm[py/reflected-xss]
            return jsonify([])
    except Exception as e:
        logging.error(f"Error getting HA manager status: {e}")
        # lgtm[py/reflected-xss]
        return jsonify([])
