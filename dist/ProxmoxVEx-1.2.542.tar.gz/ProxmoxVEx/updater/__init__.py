# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/updater/__init__.py
# Project:     ProxmoxVEx
# Version:     1.2.535
# Build:       2026.09.26
# Description: Updater package: check for GitHub releases and publish
#              new ones.
# Usage:       import ProxmoxVEx.updater
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-26
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""Updater package: check for GitHub releases and publish new ones."""

from ProxmoxVEx.updater.checker import check_for_update
from ProxmoxVEx.updater.uploader import upload_release

__all__ = ["check_for_update", "upload_release"]
