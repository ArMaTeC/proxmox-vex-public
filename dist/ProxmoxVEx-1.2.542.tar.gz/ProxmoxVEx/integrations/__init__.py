# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/integrations/__init__.py
# Project:     ProxmoxVEx
# Version:     1.2.535
# Build:       2026.09.26
# Description: ProxmoxVEx Integrations package.
# Usage:       import ProxmoxVEx.integrations
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-26
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""ProxmoxVEx Integrations package."""

# Spec 092/US057: re-export the shared retry helper so non-native integration
# code uses the same backoff policy as ProxmoxVEx.native clients.
from ProxmoxVEx.native import TransientError, with_retry

__all__ = ["TransientError", "with_retry"]
