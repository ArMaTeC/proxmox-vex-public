# --- ProxmoxVEx auto-header start ---
# --------------------------------------------------------------------
# File:        ProxmoxVEx/services/plugin_delivery.py
# Project:     ProxmoxVEx
# Version:     1.2.471
# Build:       2026.09.17
# Description: License-gated plugin artifact delivery and integrity.
# Docs:        https://proxmoxvex.com/docs
# Generated:   2026-09-17
# --------------------------------------------------------------------
# --- ProxmoxVEx auto-header end ---
"""License-gated plugin artifact delivery and integrity.

Downloads compressed paid plugin artifacts from the license server,
verifies artifact and per-file SHA-256 hashes, unpacks the plugin into the
runtime `plugins/` directory, and detects unauthorized changes.
"""

from __future__ import annotations

import contextlib
import hashlib
import json
import logging
import os
import shutil
import tarfile
import tempfile
import uuid
from pathlib import Path
from typing import Any

import requests

from ProxmoxVEx.models.plugin_integrity import (
    add_plugin_delivery_log,
    get_plugin_integrity,
    set_plugin_integrity,
)

logger = logging.getLogger(__name__)


def _default_base_url() -> str:
    return os.environ.get(
        "LICENCE_SERVICE_URL", "https://licensing.proxmoxvex.com"
    ).rstrip("/")


def _api_key() -> str:
    return os.environ.get("LICENCE_SERVICE_API_KEY", "").strip()


def _auth_headers() -> dict[str, str]:
    headers = {}
    if _api_key():
        headers["Authorization"] = f"Bearer {_api_key()}"
    return headers


class PluginDeliveryService:
    """Client for paid plugin artifact delivery and integrity checks."""

    def __init__(
        self,
        base_url: str | None = None,
        timeout: int = 30,
        plugins_dir: str | Path | None = None,
    ) -> None:
        self.base_url = (base_url or _default_base_url()).rstrip("/")
        self.timeout = timeout
        if plugins_dir is None:
            from ProxmoxVEx.constants import PLUGINS_DIR

            self.plugins_dir = Path(PLUGINS_DIR)
        else:
            self.plugins_dir = Path(plugins_dir)

    @staticmethod
    def _response_detail(exc: requests.exceptions.RequestException) -> str:
        """Extract the server's error body so license-denial reasons are visible."""
        if exc.response is None:
            return ""
        try:
            return str(exc.response.json().get("detail") or exc.response.text)[:300]
        except ValueError:
            return exc.response.text[:300]

    def _post(self, path: str, payload: dict[str, Any]) -> dict[str, Any] | None:
        try:
            response = requests.post(
                f"{self.base_url}{path}",
                json=payload,
                headers=_auth_headers(),
                timeout=self.timeout,
            )
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as exc:
            logger.error("Plugin delivery request failed for %s: %s %s", path, exc, self._response_detail(exc))
            return None

    def _get(self, path: str, params: dict[str, Any] | None = None) -> dict[str, Any] | None:
        try:
            response = requests.get(
                f"{self.base_url}{path}",
                params=params,
                headers=_auth_headers(),
                timeout=self.timeout,
            )
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as exc:
            logger.error("Plugin delivery request failed for %s: %s %s", path, exc, self._response_detail(exc))
            return None

    def _log(
        self,
        conn,
        plugin_id: str,
        event_type: str,
        version: str,
        outcome: str,
        details: dict[str, Any] | None = None,
    ) -> None:
        add_plugin_delivery_log(
            conn,
            str(uuid.uuid4()),
            plugin_id,
            event_type,
            version,
            outcome,
            details,
        )

    @staticmethod
    def _sha256_file(path: Path) -> str:
        h = hashlib.sha256()
        with open(path, "rb") as f:
            for chunk in iter(lambda: f.read(8192), b""):
                h.update(chunk)
        return h.hexdigest()

    def _artifact_manifest_path(self, plugin_dir: Path) -> Path:
        return plugin_dir / "integrity.json"

    def is_paid_plugin(self, plugin_id: str) -> bool:
        """Return True if the plugin is marked paid in the generated directory."""
        # Resolve against self.plugins_dir (PLUGINS_DIR) rather than a fixed
        # parents[2] path — the two diverge when the process CWD is not the
        # project root, which silently disabled paid-plugin downloads.
        catalog = self.plugins_dir / "directory.json"
        if not catalog.exists():
            return False
        try:
            data = json.loads(catalog.read_text(encoding="utf-8"))
            for entry in data.get("plugins", []):
                if entry.get("slug") == plugin_id:
                    return bool(entry.get("is_paid") or entry.get("download_required"))
        except Exception:
            logger.warning("Could not read plugin directory catalog for %s", plugin_id)
        return False

    def get_installed_integrity(self, db, plugin_id: str) -> dict[str, Any] | None:
        return get_plugin_integrity(db.conn, plugin_id)

    def verify_installed_files(self, db, plugin_id: str) -> dict[str, Any]:
        """Recompute hashes of installed files and compare to the expected manifest.

        Returns a dict with `ok`, `status`, and `mismatched_files`.
        """
        plugin_dir = self.plugins_dir / plugin_id
        manifest_path = self._artifact_manifest_path(plugin_dir)
        if not manifest_path.exists():
            return {
                "ok": False,
                "status": "missing",
                "mismatched_files": ["integrity.json"],
            }

        try:
            manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        except Exception as exc:
            logger.error("Failed to read integrity manifest for %s: %s", plugin_id, exc)
            return {
                "ok": False,
                "status": "tampered",
                "mismatched_files": ["integrity.json"],
            }

        # Skip interpreter bytecode in BOTH directions: manifests generated
        # before scripts/package_paid_plugins.py excluded __pycache__ still
        # list .pyc entries whose hashes can never match — the cached bytecode
        # embeds the source mtime and is regenerated at import time. A real
        # tamper is still caught because the .py source is hash-checked.
        expected_files = {
            f["path"]: f["hash"]
            for f in manifest.get("files", [])
            if "__pycache__" not in Path(f["path"]).parts
            and Path(f["path"]).suffix not in (".pyc", ".pyo")
        }
        mismatched: list[str] = []
        found_files: set[str] = set()

        for path, expected_hash in expected_files.items():
            file_path = plugin_dir / path
            if not file_path.is_file():
                mismatched.append(path)
                continue
            found_files.add(path)
            actual = self._sha256_file(file_path)
            if actual != expected_hash:
                mismatched.append(path)

        # Detect extra files not in the manifest (excluding the integrity manifest).
        for item in plugin_dir.rglob("*"):
            if item.is_file() and item.name != "integrity.json":
                rel = item.relative_to(plugin_dir).as_posix()
                # Python bytecode caches (__pycache__/*.pyc) are written next to
                # plugin sources at import time — they are runtime artifacts,
                # not delivered content. Counting them flagged every paid
                # plugin as tampered as soon as the interpreter cached bytecode.
                if "__pycache__" in item.relative_to(plugin_dir).parts or item.suffix in (".pyc", ".pyo"):
                    continue
                if rel not in found_files:
                    mismatched.append(rel)

        ok = not mismatched
        status = "valid" if ok else "tampered"
        return {
            "ok": ok,
            "status": status,
            "mismatched_files": mismatched,
        }

    def _verify_artifact(self, archive_path: Path, expected_hash: str) -> bool:
        return self._sha256_file(archive_path) == expected_hash

    def _unpack_artifact(self, archive_path: Path, dest_dir: Path) -> None:
        """Extract a .tar.gz archive, blocking path traversal."""
        if dest_dir.exists():
            shutil.rmtree(dest_dir)
        dest_dir.mkdir(parents=True, exist_ok=True)

        with tarfile.open(archive_path, "r:gz") as tar:
            dest_resolved = dest_dir.resolve()
            members = tar.getmembers()
            for member in members:
                target = dest_dir / member.name
                try:
                    target.resolve().relative_to(dest_resolved)
                except ValueError:
                    raise ValueError(f"Archive member escapes plugin directory: {member.name}") from None
                # Validating names alone is insufficient: a symlink member
                # earlier in the archive would let a later member write
                # outside dest_dir through the link, and this loop runs before
                # any extraction happens. Delivered artifacts only ever
                # contain plain files/dirs (scripts/package_paid_plugins.py),
                # so reject links, devices and other special members.
                if not (member.isfile() or member.isdir()):
                    raise ValueError(f"Archive member has disallowed type: {member.name}")
            # Manual member-by-member extraction is used instead of
            # tar.extractall: static analyzers flag extractall as a tar-slip
            # sink regardless of the pre-validation above, and writing only
            # plain files/dirs directly also eliminates the symlink-ordering
            # attack surface that extractall's 'data' filter (PEP 706) only
            # partially mitigates. Every member reaching this loop is a file
            # or dir whose resolved target stays inside dest_dir.
            for member in members:
                target = dest_dir / member.name
                if member.isdir():
                    target.mkdir(parents=True, exist_ok=True)
                    continue
                src = tar.extractfile(member)
                if src is None:
                    continue
                # Some archives omit intermediate directory members — make
                # sure the parent exists before writing the file.
                target.parent.mkdir(parents=True, exist_ok=True)
                with src, open(target, "wb") as dst:
                    shutil.copyfileobj(src, dst)
                # Preserve the executable bit on plugin scripts; the mode is
                # masked to permission bits only so an archive cannot smuggle
                # setuid/setgid or sticky bits through.
                with contextlib.suppress(OSError):
                    os.chmod(target, member.mode & 0o777)

    def _download_artifact(self, download_url: str, dest_path: Path) -> None:
        with requests.get(download_url, stream=True, timeout=self.timeout) as resp:
            resp.raise_for_status()
            with open(dest_path, "wb") as f:
                for chunk in resp.iter_content(chunk_size=8192):
                    if chunk:
                        f.write(chunk)

    def download_and_install(
        self,
        db,
        plugin_id: str,
        license_key: str,
        version: str | None = None,
    ) -> tuple[bool, str]:
        """Download, verify, and unpack a paid plugin artifact.

        Returns (ok, error_message).
        """
        self._log(db.conn, plugin_id, "download", version or "latest", "pending")

        manifest = self._get(
            f"/v1/plugins/{plugin_id}/manifest",
            {"version": version} if version else None,
        )
        if not manifest:
            self._log(db.conn, plugin_id, "download", version or "latest", "failure", {"reason": "no_manifest"})
            return False, "Could not retrieve plugin manifest from license server"
        if not manifest.get("success"):
            err = manifest.get("error", "License server rejected manifest request")
            self._log(db.conn, plugin_id, "download", version or "latest", "failure", {"reason": err})
            return False, err

        data = manifest.get("data", {})
        version = version or data.get("version")
        artifact_hash = data.get("artifact_hash")
        if not version or not artifact_hash:
            return False, "Manifest missing version or artifact hash"

        download_resp = self._post(
            f"/v1/plugins/{plugin_id}/download",
            {"license_key": license_key, "version": version},
        )
        if not download_resp or not download_resp.get("success"):
            err = (download_resp or {}).get("error", "License server denied download")
            self._log(db.conn, plugin_id, "download", version, "failure", {"reason": err})
            return False, err

        download_url = download_resp.get("data", {}).get("download_url")
        if not download_url:
            return False, "License server did not provide a download URL"

        with tempfile.TemporaryDirectory() as tmp:
            archive_path = Path(tmp) / f"{plugin_id}-{version}.tar.gz"
            try:
                self._download_artifact(download_url, archive_path)
            except requests.exceptions.RequestException as exc:
                logger.error("Failed to download plugin artifact for %s: %s", plugin_id, exc)
                self._log(db.conn, plugin_id, "download", version, "failure", {"reason": "download_failed"})
                return False, f"Failed to download plugin artifact: {exc}"

            if not self._verify_artifact(archive_path, artifact_hash):
                self._log(db.conn, plugin_id, "download", version, "failure", {"reason": "artifact_hash_mismatch"})
                return False, "Downloaded plugin artifact hash does not match manifest"

            plugin_dir = self.plugins_dir / plugin_id
            try:
                self._unpack_artifact(archive_path, plugin_dir)
            except Exception as exc:
                logger.exception("Failed to unpack plugin %s: %s", plugin_id, exc)
                self._log(db.conn, plugin_id, "download", version, "failure", {"reason": "unpack_failed"})
                return False, f"Failed to unpack plugin artifact: {exc}"

            verify = self.verify_installed_files(db, plugin_id)
            if not verify["ok"]:
                set_plugin_integrity(db.conn, plugin_id, version, artifact_hash, verify["status"])
                # _log/add_plugin_delivery_log expect the raw connection — it
                # calls conn.commit() which the wrapper class does not expose.
                self._log(
                    db.conn,
                    plugin_id,
                    "download",
                    version,
                    "failure",
                    {"reason": "integrity_mismatch", "mismatched_files": verify["mismatched_files"]},
                )
                return False, f"Plugin integrity check failed: {', '.join(verify['mismatched_files'])}"

            set_plugin_integrity(db.conn, plugin_id, version, artifact_hash, "valid")
            self._log(db.conn, plugin_id, "download", version, "success")
            return True, ""

    def check_for_update(self, db, plugin_id: str, license_key: str) -> dict[str, Any]:
        """Return whether a newer artifact is available on the license server."""
        current = get_plugin_integrity(db.conn, plugin_id)
        installed_version = current["version"] if current else None

        manifest = self._get(
            f"/v1/plugins/{plugin_id}/updates",
            {"installed_version": installed_version} if installed_version else None,
        )
        if not manifest or not manifest.get("success"):
            return {"update_available": False, "error": "Could not check for updates"}

        data = manifest.get("data", {})
        return {
            "update_available": data.get("update_available", False),
            "latest_version": data.get("latest_version"),
            "artifact_hash": data.get("artifact_hash"),
        }

    def install_update(
        self,
        db,
        plugin_id: str,
        license_key: str,
    ) -> tuple[bool, str]:
        """Download and install the latest version of a paid plugin."""
        info = self.check_for_update(db, plugin_id, license_key)
        if not info.get("update_available"):
            return True, "No update available"
        return self.download_and_install(db, plugin_id, license_key, info.get("latest_version"))

    def verify_and_remediate(
        self,
        db,
        plugin_id: str,
        license_key: str | None,
    ) -> dict[str, Any]:
        """Verify a loaded paid plugin and, if tampered, disable it.

        Returns a status dict with `ok`, `status`, and `action`.
        """
        result = self.verify_installed_files(db, plugin_id)
        current = get_plugin_integrity(db.conn, plugin_id)
        version = current["version"] if current else "unknown"

        # "missing" means no integrity.json baseline on disk. When no baseline
        # was ever recorded either (no artifact hash in plugin_integrity), the
        # plugin was installed from source — a dev checkout or the E2E harness —
        # not delivered through the license server, so there is nothing to
        # verify against. Treat it as unverifiable rather than tampered;
        # disabling here broke every source-installed paid plugin.
        if result["status"] == "missing" and not (current and current.get("artifact_hash")):
            return {**result, "action": "none"}

        if not result["ok"]:
            set_plugin_integrity(db.conn, plugin_id, version, current["artifact_hash"] if current else "", "tampered")
            self._log(
                db.conn,
                plugin_id,
                "tamper",
                version,
                "failure",
                {"mismatched_files": result["mismatched_files"]},
            )
            self.report_tamper(plugin_id, version, result["mismatched_files"], license_key)
            return {**result, "action": "disable"}

        if current:
            # set_plugin_integrity calls conn.commit(); the wrapper class does
            # not expose commit(), so pass the raw connection.
            set_plugin_integrity(
                db.conn,
                plugin_id,
                current["version"],
                current["artifact_hash"],
                "valid",
            )
        return {**result, "action": "none"}

    def report_tamper(
        self,
        plugin_id: str,
        version: str,
        mismatched_files: list[str],
        license_key: str | None = None,
    ) -> dict[str, Any] | None:
        """Report a tamper event to the license server."""
        payload = {
            "plugin_id": plugin_id,
            "version": version,
            "mismatched_files": mismatched_files,
        }
        if license_key:
            payload["license_key"] = license_key
        return self._post(f"/v1/plugins/{plugin_id}/tamper", payload)
